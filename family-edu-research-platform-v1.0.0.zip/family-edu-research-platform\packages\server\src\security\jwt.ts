/**
 * Minimal, dependency-free JWT (HS256) implementation.
 *
 * Only HS256 is supported and the algorithm is pinned on verification: a token
 * whose header claims any other algorithm is rejected outright, which closes
 * the classic "alg: none" and algorithm-confusion attacks. Signature
 * comparison is constant-time.
 */

import { createHmac, timingSafeEqual } from 'node:crypto';

export interface JwtPayload {
  /** Subject — the researcher id. */
  sub: string;
  /** Issued at (seconds since epoch). */
  iat: number;
  /** Expiry (seconds since epoch). */
  exp: number;
  /** Token version, compared against researchers.token_version for revocation. */
  tv: number;
  /** Optional e-mail claim, convenient for the client without another request. */
  email?: string;
  [key: string]: unknown;
}

export type JwtVerifyResult =
  | { valid: true; payload: JwtPayload }
  | { valid: false; error: 'malformed' | 'bad_algorithm' | 'bad_signature' | 'expired' | 'not_yet_valid' };

/**
 * Claims a caller must supply. Declared as its own interface (rather than
 * `Omit<JwtPayload, ...>`) because JwtPayload carries an index signature, and
 * omitting from an index-signature type would erase the required `sub`/`tv`
 * checks that keep a token from being minted without a subject.
 */
export interface SignJwtClaims {
  sub: string;
  tv: number;
  email?: string;
  [key: string]: unknown;
}

/* ------------------------------------------------------------------ */
/* base64url helpers                                                  */
/* ------------------------------------------------------------------ */

function base64UrlEncode(input: Buffer | string): string {
  const buffer = typeof input === 'string' ? Buffer.from(input, 'utf8') : input;
  return buffer.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlDecode(input: string): Buffer | null {
  if (!/^[A-Za-z0-9_-]*$/.test(input)) return null;
  const padded = input.replace(/-/g, '+').replace(/_/g, '/');
  const remainder = padded.length % 4;
  const withPadding = remainder === 0 ? padded : padded + '='.repeat(4 - remainder);
  try {
    return Buffer.from(withPadding, 'base64');
  } catch {
    return null;
  }
}

function sign(data: string, secret: string): Buffer {
  return createHmac('sha256', secret).update(data, 'utf8').digest();
}

/* ------------------------------------------------------------------ */
/* Sign / verify                                                      */
/* ------------------------------------------------------------------ */

export function signJwt(
  claims: SignJwtClaims,
  secret: string,
  expiresInSeconds: number,
): string {
  if (!secret || secret.length === 0) throw new Error('JWT secret must not be empty');
  const now = Math.floor(Date.now() / 1000);
  const issuedAt = typeof claims['iat'] === 'number' ? (claims['iat'] as number) : now;
  const payload: JwtPayload = {
    ...claims,
    iat: issuedAt,
    exp: issuedAt + expiresInSeconds,
  };

  const header = base64UrlEncode(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = base64UrlEncode(JSON.stringify(payload));
  const signature = base64UrlEncode(sign(`${header}.${body}`, secret));
  return `${header}.${body}.${signature}`;
}

export function verifyJwt(token: string, secret: string, nowSeconds?: number): JwtVerifyResult {
  if (typeof token !== 'string') return { valid: false, error: 'malformed' };
  const segments = token.split('.');
  if (segments.length !== 3) return { valid: false, error: 'malformed' };
  const [headerPart, bodyPart, signaturePart] = segments as [string, string, string];

  const headerBuffer = base64UrlDecode(headerPart);
  const bodyBuffer = base64UrlDecode(bodyPart);
  const signatureBuffer = base64UrlDecode(signaturePart);
  if (!headerBuffer || !bodyBuffer || !signatureBuffer) return { valid: false, error: 'malformed' };

  let header: { alg?: unknown; typ?: unknown };
  try {
    header = JSON.parse(headerBuffer.toString('utf8')) as { alg?: unknown; typ?: unknown };
  } catch {
    return { valid: false, error: 'malformed' };
  }
  // Pin the algorithm — never trust the header to select it.
  if (header.alg !== 'HS256') return { valid: false, error: 'bad_algorithm' };

  const expected = sign(`${headerPart}.${bodyPart}`, secret);
  if (expected.length !== signatureBuffer.length) return { valid: false, error: 'bad_signature' };
  if (!timingSafeEqual(expected, signatureBuffer)) return { valid: false, error: 'bad_signature' };

  let payload: JwtPayload;
  try {
    payload = JSON.parse(bodyBuffer.toString('utf8')) as JwtPayload;
  } catch {
    return { valid: false, error: 'malformed' };
  }
  if (typeof payload.sub !== 'string' || payload.sub.length === 0) {
    return { valid: false, error: 'malformed' };
  }
  if (typeof payload.exp !== 'number' || typeof payload.iat !== 'number') {
    return { valid: false, error: 'malformed' };
  }

  const now = nowSeconds ?? Math.floor(Date.now() / 1000);
  if (now >= payload.exp) return { valid: false, error: 'expired' };
  // 60s leeway absorbs small clock differences between app instances.
  if (payload.iat > now + 60) return { valid: false, error: 'not_yet_valid' };

  return { valid: true, payload };
}

/** Decode without verifying — for diagnostics and tests only. */
export function decodeJwtUnsafe(token: string): JwtPayload | null {
  const segments = token.split('.');
  if (segments.length !== 3) return null;
  const buffer = base64UrlDecode(segments[1] ?? '');
  if (!buffer) return null;
  try {
    return JSON.parse(buffer.toString('utf8')) as JwtPayload;
  } catch {
    return null;
  }
}
