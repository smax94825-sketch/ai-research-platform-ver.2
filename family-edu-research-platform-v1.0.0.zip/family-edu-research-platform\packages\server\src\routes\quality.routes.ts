/**
 * Data quality and quota routes (PHASE 4).
 *
 *   GET  /api/projects/:projectId/quality                 — project quality report
 *   POST /api/projects/:projectId/quality/recompute       — re-run the engine
 *   GET  /api/projects/:projectId/quality/rules           — rule catalogue
 *   GET  /api/projects/:projectId/quota                   — progress + recommendations
 *   PUT  /api/projects/:projectId/quota                   — replace the quota config
 *   GET  /api/projects/:projectId/quota/dimensions        — valid quota dimensions
 *   GET  /api/respondents/:respondentId/quality           — one sample's flags
 *   POST /api/respondents/:respondentId/quality/recompute — re-score one sample
 *
 * Every mutation here writes flags and scores only. Nothing in this router can
 * delete or alter a stored answer.
 */

import { Router } from 'express';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import {
  evaluateRespondentQuality,
  getProjectQualityReport,
  getRespondentQualityView,
  qualityRuleCatalogue,
  recomputeProjectQuality,
} from '../services/quality.service.js';
import {
  availableQuotaDimensions,
  getQuotaStatus,
  updateQuotaConfig,
} from '../services/quota.service.js';
import { requireProject } from '../services/project.service.js';
import { ApiError, asyncHandler } from '../util/errors.js';
import { getRespondentDetail } from '../services/collection.service.js';

export interface QualityRouterContext {
  db: Db;
  config: Config;
}

/* ================================================================== */
/* Project-scoped                                                     */
/* ================================================================== */

export function createQualityRouter(ctx: QualityRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /**
   * Rule catalogue: the UI renders explanations from this, not from its own copy.
   *
   * Serialised to snake_case like every other API payload, rather than echoing
   * the internal TypeScript field names — a client should not have to know which
   * endpoint was written in which style.
   */
  router.get(
    '/:projectId/quality/rules',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      requireProject(ctx.db, req.params['projectId']!, researcher.id);
      res.json({
        data: Object.values(qualityRuleCatalogue()).map((rule) => ({
          code: rule.code,
          label: rule.label,
          description: rule.description,
          interpretation: rule.interpretation,
          default_severity: rule.defaultSeverity,
          score_impact: rule.scoreImpact,
        })),
      });
    }),
  );

  router.get(
    '/:projectId/quality',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      res.json({ data: getProjectQualityReport(ctx.db, projectId) });
    }),
  );

  /**
   * Re-run the engine over the project.
   *
   * Idempotent by construction: existing flags for the project are cleared and
   * rewritten, so running it twice yields the same scores. It never removes a
   * respondent, and it never changes an answer.
   */
  router.post(
    '/:projectId/quality/recompute',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      res.json({ data: recomputeProjectQuality(ctx.db, projectId) });
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Quota                                                            */
  /* ---------------------------------------------------------------- */

  router.get(
    '/:projectId/quota',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      res.json({ data: getQuotaStatus(ctx.db, req.params['projectId']!, researcher.id) });
    }),
  );

  router.get(
    '/:projectId/quota/dimensions',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      res.json({ data: availableQuotaDimensions(ctx.db, projectId) });
    }),
  );

  router.put(
    '/:projectId/quota',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const body = (req.body ?? {}) as Record<string, unknown>;
      if (!('quota_config' in body)) {
        throw ApiError.validation('请求体缺少 quota_config（传 null 可清除配额配置）。');
      }
      const config = updateQuotaConfig(ctx.db, projectId, researcher.id, body['quota_config']);
      res.json({ data: getQuotaStatus(ctx.db, projectId, researcher.id) });
      void config;
    }),
  );

  return router;
}

/* ================================================================== */
/* Sample-scoped                                                      */
/* ================================================================== */

export function createRespondentQualityRouter(ctx: QualityRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /** Ownership is enforced through the respondent detail lookup. */
  function assertOwned(respondentId: string, researcherId: string): void {
    getRespondentDetail(ctx.db, respondentId, researcherId);
  }

  router.get(
    '/:respondentId/quality',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const respondentId = req.params['respondentId']!;
      assertOwned(respondentId, researcher.id);
      res.json({ data: getRespondentQualityView(ctx.db, respondentId) });
    }),
  );

  /** Re-score a single sample (e.g. after a researcher edits review state). */
  router.post(
    '/:respondentId/quality/recompute',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const respondentId = req.params['respondentId']!;
      assertOwned(respondentId, researcher.id);
      const result = evaluateRespondentQuality(ctx.db, respondentId, { persist: true });
      res.json({
        data: {
          ...result,
          view: getRespondentQualityView(ctx.db, respondentId),
        },
      });
    }),
  );

  return router;
}
