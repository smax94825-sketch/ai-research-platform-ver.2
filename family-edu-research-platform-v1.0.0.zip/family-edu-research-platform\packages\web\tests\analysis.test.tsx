/**
 * Statistical analysis console tests (PHASE 6).
 *
 * The console makes claims a researcher will quote, so these tests check the
 * three things that decide whether a page can be trusted:
 *   1. the engine's numbers reach the screen (counts, coefficients, α, r, p),
 *   2. an analysis the engine reports as `available: false` shows the API's own
 *      Chinese reason instead of an empty chart,
 *   3. a transport failure surfaces as an error state rather than a blank page.
 *
 * The nominal-variable rule is asserted explicitly: a variable with no defined
 * mean must render 「—」, never a number and never a blank cell.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { click, flush, queryAll, render, text } from './render';

const { AnalysisHomePage } = await import('../src/pages/analysis/AnalysisHomePage');
const { ComparisonPage } = await import('../src/pages/analysis/ComparisonPage');
const { CorrelationPage } = await import('../src/pages/analysis/CorrelationPage');
const { DescriptivePage } = await import('../src/pages/analysis/DescriptivePage');
const { HypothesisPage } = await import('../src/pages/analysis/HypothesisPage');
const { RegressionPage } = await import('../src/pages/analysis/RegressionPage');
const { ReliabilityPage } = await import('../src/pages/analysis/ReliabilityPage');
const { ValidityPage } = await import('../src/pages/analysis/ValidityPage');

/* ================================================================== */
/* Fixtures — shaped exactly like the analysis API's responses        */
/* ================================================================== */

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育投入研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'analyzing',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

const SAMPLE = {
  respondents_total: 500,
  completed: 400,
  in_progress: 70,
  abandoned: 30,
  excluded: 50,
  analysable: 350,
  rows_loaded: 350,
  sources: [
    { source: 'wechat', total: 300 },
    { source: 'school', total: 200 },
  ],
};

const DATASET = {
  engine_version: '1.0.0',
  sample: SAMPLE,
  n_respondents: 350,
  variable_count: 9,
  derived_variable_count: 4,
  empty_variables: ['Q99'],
  variables: [
    {
      name: 'FSE',
      label: '家庭教育自我效能',
      dimension: '效能',
      question_code: 'Q10',
      data_type: 'interval',
      n: 348,
      missing: 2,
      is_derived: true,
      sources: ['Q10a', 'Q10b'],
    },
  ],
  available: {
    correlation_variables: ['FSE', 'FED', 'UI'],
    regression_dependent: 'UI',
    regression_predictors: ['DSD', 'STI'],
    comparison_factor: 'STAGE',
    comparison_dependents: ['FED', 'UI'],
  },
  note: '分析样本仅包含已完成且未被研究者排除的样本。所有统计基于整例删除（listwise），缺失值不插补。',
};

const DESCRIPTIVE = {
  engine_version: '1.0.0',
  sample: SAMPLE,
  n_respondents: 350,
  variables: [
    {
      variable: 'STAGE',
      label: '孩子学段',
      dimension: '背景',
      question_code: 'Q2',
      data_type: 'nominal',
      n: 350,
      missing: 0,
      missing_percent: 0,
      mean: null,
      median: null,
      standard_deviation: null,
      standard_error: null,
      variance: null,
      minimum: null,
      maximum: null,
      range: null,
      q1: null,
      q3: null,
      iqr: null,
      skewness: null,
      kurtosis: null,
      frequencies: [
        { value: '1', label: '学前', count: 120, percent: 34.29, percent_of_total: 34.29 },
        { value: '2', label: '小学', count: 150, percent: 42.86, percent_of_total: 42.86 },
        { value: '3', label: '初中', count: 80, percent: 22.86, percent_of_total: 22.86 },
      ],
    },
    {
      variable: 'FSE',
      label: '家庭教育自我效能',
      dimension: '效能',
      question_code: 'Q10',
      data_type: 'interval',
      n: 348,
      missing: 2,
      missing_percent: 0.57,
      mean: 3.62,
      median: 3.67,
      standard_deviation: 0.71,
      standard_error: 0.038,
      variance: 0.504,
      minimum: 1,
      maximum: 5,
      range: 4,
      q1: 3.17,
      q3: 4,
      iqr: 0.83,
      skewness: -0.32,
      kurtosis: 0.11,
      frequencies: null,
    },
  ],
  unusable_variables: [{ variable: 'Q99', reason: '该变量没有任何有效作答' }],
  note: '描述统计仅基于有效作答计算；缺失值不参与均值、标准差等计算，也不进行插补。',
};

const RELIABILITY = {
  engine_version: '1.0.0',
  scales: [
    {
      scale: 'FSE',
      label: '家庭教育自我效能',
      dimension: '效能',
      k: 3,
      n: 340,
      dropped: 10,
      cronbach_alpha: 0.842,
      standardized_alpha: 0.846,
      mean_inter_item_correlation: 0.641,
      scale_mean: 10.86,
      scale_standard_deviation: 2.13,
      alpha_reference: { excellent: 0.9, good: 0.8, acceptable: 0.7, questionable: 0.6 },
      interpretation: 'α = 0.842，内部一致性良好。',
      warnings: ['条目 Q10c 的校正后题总相关为 0.211，低于 0.30，提示该条目与量表整体关系较弱。'],
      items: [
        {
          item: 'Q10a',
          label: '我相信自己能辅导孩子学习',
          mean: 3.71,
          standard_deviation: 0.81,
          item_total_correlation: 0.712,
          alpha_if_deleted: 0.771,
          n: 340,
        },
        {
          item: 'Q10b',
          label: '我能为孩子安排合适的学习计划',
          mean: 3.58,
          standard_deviation: 0.86,
          item_total_correlation: 0.688,
          alpha_if_deleted: 0.782,
          n: 340,
        },
        {
          item: 'Q10c',
          label: '我经常感到无力应对孩子的教育问题',
          mean: 3.57,
          standard_deviation: 0.92,
          item_total_correlation: 0.211,
          alpha_if_deleted: 0.905,
          n: 340,
        },
      ],
    },
  ],
  note: "信度分析采用 Cronbach's α，基于整例删除后的完整样本计算，并在条目层面给出校正后题总相关与「删除该条目后的 α」。",
};

const VALIDITY = {
  engine_version: '1.0.0',
  overall_kmo: {
    overall: 0.834,
    per_variable: [
      { variable: 'Q10a', msa: 0.861 },
      { variable: 'Q10b', msa: 0.842 },
      { variable: 'Q10c', msa: 0.412 },
    ],
    interpretation: 'KMO 在 0.80—0.89，取样适切性良好，适合进行因素分析。',
    adequacy: 'meritorious',
  },
  overall_bartlett: {
    chi_square: 1842.31,
    degrees_of_freedom: 15,
    p_value: 0.0000001,
    determinant: 0.00321,
    interpretation: 'Bartlett 球形检验显著（p < 0.05），相关矩阵与单位矩阵存在显著差异，适合进行因素分析。',
    unavailable: false,
  },
  scale_efa: [
    {
      scale: 'FSE',
      label: '家庭教育自我效能',
      result: {
        n: 340,
        p: 3,
        extraction: 'principal_component',
        rotation: 'varimax',
        eigenvalues: [1.92, 0.61, 0.47],
        variance_explained: [0.64, 0.203, 0.157],
        cumulative_variance: [0.64, 0.843, 1],
        kaiser_factors: 1,
        factors_retained: 1,
        loadings: [
          {
            variable: 'Q10a',
            label: '我相信自己能辅导孩子学习',
            loadings: [0.871],
            communality: 0.759,
            primary_factor: 1,
            primary_loading: 0.871,
          },
          {
            variable: 'Q10b',
            label: '我能为孩子安排合适的学习计划',
            loadings: [0.845],
            communality: 0.714,
            primary_factor: 1,
            primary_loading: 0.845,
          },
          {
            variable: 'Q10c',
            label: '我经常感到无力应对孩子的教育问题',
            loadings: [0.352],
            communality: 0.124,
            primary_factor: 1,
            primary_loading: 0.352,
          },
        ],
        rotated_variance_explained: [0.64],
        rotated_cumulative_variance: 0.64,
        kmo: { overall: 0.712, per_variable: [], interpretation: '中等', adequacy: 'middling' },
        bartlett: {
          chi_square: 412.4,
          degrees_of_freedom: 3,
          p_value: 0.0000001,
          determinant: 0.221,
          interpretation: '显著。',
          unavailable: false,
        },
        scree: [
          { component: 1, eigenvalue: 1.92 },
          { component: 2, eigenvalue: 0.61 },
          { component: 3, eigenvalue: 0.47 },
        ],
        low_communality: ['Q10c'],
        cross_loading: [],
        interpretation: '提取 1 个因子，累积解释 64.00% 的方差。',
        warnings: [],
      },
    },
  ],
  note: '效度分析报告 KMO、Bartlett 球形检验与各量表的探索性因素分析结果。',
  warnings: [],
};

const CORRELATION = {
  engine_version: '1.0.0',
  available: true,
  variables: ['FSE', 'FED', 'UI'],
  labels: ['家庭教育自我效能', '家庭教育需求', '使用意向'],
  matrix: [
    [1, 0.62, 0.48],
    [0.62, 1, 0.21],
    [0.48, 0.21, 1],
  ],
  p_values: [
    [0, 0.0004, 0.0021],
    [0.0004, 0, 0.14],
    [0.0021, 0.14, 0],
  ],
  n: [
    [348, 340, 342],
    [340, 344, 336],
    [342, 336, 350],
  ],
  methods: [
    ['pearson', 'pearson', 'spearman'],
    ['pearson', 'pearson', 'spearman'],
    ['spearman', 'spearman', 'spearman'],
  ],
  pairs: [
    {
      left: 'FSE',
      right: 'FED',
      method: 'pearson',
      method_reason: '两个变量均为连续/等距测量（interval、interval），采用 Pearson 积矩相关。',
      r: 0.62,
      p_value: 0.0004,
      n: 340,
      ci_lower: 0.554,
      ci_upper: 0.679,
      shared_variance_percent: 38.44,
      effective_size: {
        value: 0.62,
        band: 'large',
        text: '效应量大（|r| = 0.62）',
        convention: 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大',
      },
      note: '',
    },
    {
      left: 'FSE',
      right: 'UI',
      method: 'spearman',
      method_reason: '至少一个变量为有序分类或计数测量，采用 Spearman 等级相关。',
      r: 0.48,
      p_value: 0.0021,
      n: 342,
      ci_lower: null,
      ci_upper: null,
      shared_variance_percent: 23.04,
      effective_size: {
        value: 0.48,
        band: 'medium',
        text: '效应量中等（|r| = 0.48）',
        convention: 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大',
      },
      note: '',
    },
    {
      left: 'FED',
      right: 'UI',
      method: 'spearman',
      method_reason: '至少一个变量为有序分类或计数测量，采用 Spearman 等级相关。',
      r: 0.21,
      p_value: 0.14,
      n: 336,
      ci_lower: null,
      ci_upper: null,
      shared_variance_percent: 4.41,
      effective_size: {
        value: 0.21,
        band: 'small',
        text: '效应量小（|r| = 0.21）',
        convention: 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大',
      },
      note: '',
    },
  ],
  mixed_methods: true,
  note: '相关系数按变量对的测量层次选择方法，并对每个变量对给出双侧显著性检验。',
};

const REGRESSION = {
  engine_version: '1.0.0',
  available: true,
  auto_selection: {
    model: 'ordinal_logit',
    categories: 5,
    reason:
      '因变量 UI 为有序分类变量（5 个类别，测量层次 ordinal），因此采用有序 Logistic 回归（比例优势模型）。' +
      '对有序因变量直接使用 OLS 会违反线性与等距假设，并可能产生超出取值范围的预测值。',
  },
  ols: {
    model: 'ols',
    dependent: 'UI',
    dependent_label: '使用意向',
    predictors: ['DSD', 'STI'],
    n: 342,
    dropped_predictors: [],
    dropped_cases: 8,
    coefficients: [
      {
        term: 'DSD',
        label: '数字素养',
        b: 0.412,
        standard_error: 0.067,
        beta: 0.371,
        t: 6.15,
        p_value: 0.0001,
        ci_lower: 0.28,
        ci_upper: 0.544,
        vif: 1.42,
        tolerance: 0.704,
      },
      {
        term: 'STI',
        label: '科技压力',
        b: -0.08,
        standard_error: 0.066,
        beta: -0.072,
        t: -1.21,
        p_value: 0.231,
        ci_lower: -0.21,
        ci_upper: 0.05,
        vif: 6.8,
        tolerance: 0.147,
      },
    ],
    r: 0.63,
    r_squared: 0.397,
    adjusted_r_squared: 0.393,
    standard_error_estimate: 0.628,
    f_statistic: 112.4,
    f_p_value: 0.000001,
    degrees_of_freedom_model: 2,
    degrees_of_freedom_residual: 339,
    diagnostics: {
      durbin_watson: 1.98,
      residual_skewness: -0.14,
      residual_kurtosis: 0.22,
      max_abs_standardized_residual: 3.12,
      outliers: [{ respondent_id: 'resp-7', standardised_residual: -3.12 }],
    },
    collinearity_warnings: [{ term: 'STI', vif: 6.8 }],
    interpretation: '模型显著，数字素养是使用意向的正向预测变量。',
    warnings: [],
    equation: 'UI = 1.235 + 0.412 × DSD - 0.080 × STI',
  },
  ordinal: {
    model: 'ordinal_logit',
    dependent: 'UI',
    dependent_label: '使用意向',
    predictors: ['DSD', 'STI'],
    categories: [
      { value: 1, label: '完全不同意', count: 20 },
      { value: 2, label: '比较不同意', count: 48 },
      { value: 3, label: '一般', count: 96 },
      { value: 4, label: '比较同意', count: 118 },
      { value: 5, label: '完全同意', count: 60 },
    ],
    n: 342,
    dropped_predictors: [],
    dropped_cases: 8,
    coefficients: [
      {
        term: 'DSD',
        label: '数字素养',
        b: 0.742,
        standard_error: 0.121,
        z: 6.13,
        p_value: 0.0001,
        odds_ratio: 2.1,
        ci_lower: 0.505,
        ci_upper: 0.979,
        odds_ratio_ci_lower: 1.657,
        odds_ratio_ci_upper: 2.662,
      },
      {
        term: 'STI',
        label: '科技压力',
        b: -0.121,
        standard_error: 0.104,
        z: -1.16,
        p_value: 0.246,
        odds_ratio: 0.886,
        ci_lower: -0.325,
        ci_upper: 0.083,
        odds_ratio_ci_lower: 0.722,
        odds_ratio_ci_upper: 1.087,
      },
    ],
    thresholds: [
      {
        threshold: -1.42,
        standard_error: 0.31,
        z: -4.58,
        p_value: 0.0000047,
        ci_lower: -2.03,
        ci_upper: -0.81,
        label: '完全不同意 | 比较不同意',
      },
      {
        threshold: -0.28,
        standard_error: 0.29,
        z: -0.97,
        p_value: 0.332,
        ci_lower: -0.85,
        ci_upper: 0.29,
        label: '比较不同意 | 一般',
      },
    ],
    minus2_log_likelihood: 812.4,
    minus2_log_likelihood_null: 906.2,
    lr_chi_square: 93.8,
    lr_degrees_of_freedom: 2,
    lr_p_value: 0.0000001,
    mcfadden_r_squared: 0.1035,
    nagelkerke_r_squared: 0.284,
    percent_correct: 52.34,
    proportional_odds_test: {
      chi_square: 4.12,
      degrees_of_freedom: 6,
      p_value: 0.66,
      interpretation: '比例优势假设检验不显著（p = 0.66），未发现违反该假设的证据。',
    },
    iterations: 7,
    converged: true,
    interpretation: '有序 Logistic 回归显示数字素养越高，使用意向落入更高类别的优势越大。',
    warnings: [],
  },
  recommendation:
    '因变量 UI 为有序分类变量，建议以有序 Logistic 回归（比例优势模型）为主要结论；' +
    '同时给出线性回归结果供对照，但线性模型对有序因变量会违反等距假设，并可能产生超出取值范围的预测值。',
};

const COMPARISONS = {
  engine_version: '1.0.0',
  factor: 'STAGE',
  available: true,
  reason: null,
  comparisons: [
    {
      dependent: 'FED',
      dependent_label: '家庭教育需求',
      factor: 'STAGE',
      factor_label: '孩子学段',
      groups: 3,
      recommended: 'nonparametric',
      recommendation_reason:
        '数据触发了组样本量或方差齐性警告，建议以 Kruskal–Wallis 检验为主要结论，以降低对分布假设的依赖。',
      screening: [
        { variable: 'FED', group: '学前', n: 120, skewness: 1.42, acceptable: false, reason: '偏度超出可接受范围且样本量不足，参数检验的正态性假设可能不成立。' },
        { variable: 'FED', group: '小学', n: 150, skewness: 0.31, acceptable: true, reason: '偏度在可接受范围内（或样本量足够大）。' },
        { variable: 'FED', group: '初中', n: 80, skewness: 0.48, acceptable: true, reason: '偏度在可接受范围内（或样本量足够大）。' },
      ],
      anova: {
        dependent: 'FED',
        dependent_label: '家庭教育需求',
        factor: 'STAGE',
        groups: [
          { group: '学前', n: 120, mean: 3.42, sd: 0.71, minimum: 1, maximum: 5 },
          { group: '小学', n: 150, mean: 3.66, sd: 0.64, minimum: 1.4, maximum: 5 },
          { group: '初中', n: 80, mean: 3.51, sd: 0.69, minimum: 1.2, maximum: 5 },
        ],
        ss_between: 4.21,
        ss_within: 158.4,
        ss_total: 162.61,
        df_between: 2,
        df_within: 347,
        ms_between: 2.105,
        ms_within: 0.4565,
        f: 4.612,
        p_value: 0.0105,
        eta_squared: 0.0259,
        partial_eta_squared: 0.0259,
        omega_squared: 0.0201,
        effect_size: {
          value: 0.0259,
          band: 'small',
          text: '效应量小（η² = 0.026）',
          convention: 'Cohen (1988) η² 惯例：.01 小、.06 中、.14 大',
        },
        post_hoc: [
          {
            group_a: '学前',
            group_b: '小学',
            mean_difference: -0.24,
            t: -3.02,
            p_raw: 0.0028,
            p_adjusted: 0.0084,
            significant: true,
          },
          {
            group_a: '学前',
            group_b: '初中',
            mean_difference: -0.09,
            t: -0.98,
            p_raw: 0.328,
            p_adjusted: 0.328,
            significant: false,
          },
        ],
        homogeneity: { statistic: 3.42, p_value: 0.033, equal_variances: false },
        interpretation: '三组均值差异显著（F(2, 347) = 4.612, p = 0.0105），效应量较小。',
        warnings: ['方差齐性检验未通过（方差不齐），F 检验结果需谨慎解读。'],
      },
      mann_whitney: null,
      kruskal_wallis: {
        dependent: 'FED',
        factor: 'STAGE',
        groups: [
          { group: '学前', n: 120, median: 3.5, mean_rank: 158.2 },
          { group: '小学', n: 150, median: 3.75, mean_rank: 189.4 },
          { group: '初中', n: 80, median: 3.6, mean_rank: 176.1 },
        ],
        h: 7.42,
        degrees_of_freedom: 2,
        p_value: 0.0244,
        epsilon_squared: 0.0155,
        effect_size: {
          value: 0.0155,
          band: 'small',
          text: '效应量小（ε² = 0.016）',
          convention: 'ε² 惯例：.01 小、.06 中、.14 大',
        },
        tie_corrected: true,
        interpretation: 'Kruskal–Wallis 检验显示组间秩分布差异显著（H = 7.42, p = 0.0244）。',
        warnings: [],
      },
    },
  ],
};

const HYPOTHESES = {
  engine_version: '1.0.0',
  summary: { total: 3, supported: 1, not_supported: 1, inconclusive: 1, untestable: 0 },
  unavailable_variables: [],
  note: '假设检验采用双侧检验，显著性水平 α = 0.05。p ≥ α 记为「证据不足」，不等同于证明假设不成立。',
  results: [
    {
      code: 'H1',
      statement: '家庭教育知识水平与家庭教育自我效能呈正向关系。',
      verdict: 'supported',
      conclusion: '数据支持该假设：显著的正向相关。',
      direction: 'positive',
      method: 'Pearson 积矩相关',
      independent: 'FEK',
      dependent: 'FSE',
      independent_label: '家庭教育知识',
      dependent_label: '家庭教育自我效能',
      r: 0.42,
      p_value: 0.0003,
      n: 336,
      ci_lower: 0.33,
      ci_upper: 0.5,
      effect_size: {
        value: 0.42,
        band: 'medium',
        text: '效应量中等（|r| = 0.42）',
        convention: 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大',
      },
      observed_direction: 'positive',
      evidence: ['统计方法：Pearson 积矩相关', 'r = 0.42', 'p = 0.0003', 'n = 336'],
      caveats: ['有效样本 n = 336。'],
    },
    {
      code: 'H2',
      statement: '家庭教育需求越高，使用意向越低。',
      verdict: 'not_supported',
      conclusion: '数据不支持该假设：相关显著但方向与假设相反。',
      direction: 'negative',
      method: 'Spearman 等级相关',
      independent: 'FED',
      dependent: 'UI',
      independent_label: '家庭教育需求',
      dependent_label: '使用意向',
      r: 0.28,
      p_value: 0.002,
      n: 340,
      ci_lower: null,
      ci_upper: null,
      effect_size: {
        value: 0.28,
        band: 'small',
        text: '效应量小（|r| = 0.28）',
        convention: 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大',
      },
      observed_direction: 'positive',
      evidence: ['统计方法：Spearman 等级相关', 'r = 0.28', 'p = 0.002', 'n = 340'],
      caveats: ['方向与假设相反，应如实报告而不得改写假设。'],
    },
    {
      code: 'H3',
      statement: '家庭社会经济地位与使用意向呈正向关系。',
      verdict: 'inconclusive',
      conclusion: '证据不足：本次检验未达到显著水平（p = 0.21）。',
      direction: 'positive',
      method: 'Spearman 等级相关',
      independent: 'SES',
      dependent: 'UI',
      independent_label: '家庭社会经济地位',
      dependent_label: '使用意向',
      r: 0.07,
      p_value: 0.21,
      n: 318,
      ci_lower: null,
      ci_upper: null,
      effect_size: {
        value: 0.07,
        band: 'negligible',
        text: '效应量可忽略（|r| = 0.07）',
        convention: 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大',
      },
      observed_direction: 'positive',
      evidence: ['统计方法：Spearman 等级相关', 'r = 0.07', 'p = 0.21', 'n = 318'],
      caveats: ['有效样本 n = 318 偏小，检验效力有限，不显著结果难以区分"无关系"与"样本不足"。'],
    },
  ],
};

const BUNDLE = {
  engine_version: '1.0.0',
  generated_at: '2026-02-01T09:30:00.000Z',
  project: { id: 'p-1', title: '家庭教育投入研究' },
  questionnaire: { id: 'q-1', title: '家庭教育投入问卷 V4.0', version: '4.0.0', question_count: 58 },
  sample: SAMPLE,
  dataset_summary: {
    n_respondents: 350,
    variable_count: 9,
    derived_variable_count: 4,
    empty_variables: ['Q99'],
    variables: [],
    composites: [],
  },
  descriptive: DESCRIPTIVE,
  reliability: RELIABILITY,
  validity: VALIDITY,
  correlation: CORRELATION,
  regression: REGRESSION,
  comparisons: COMPARISONS.comparisons,
  hypotheses: HYPOTHESES,
  caveats: [
    '本研究采用横截面问卷调查数据，所有关联结论均为变量间的共变关系，不能据此推断因果关系。',
    '分析基于 350 份已完成且未被排除的样本。',
  ],
};

const BUNDLE_UNAVAILABLE = {
  available: false,
  engine_version: '1.0.0',
  reason:
    '尚未运行过完整统计分析。请先执行「运行全部分析」，之后 AI 解释、研究报告与创业洞察才能基于真实的统计结果生成。',
};

const CORRELATION_UNAVAILABLE = {
  engine_version: '1.0.0',
  available: false,
  reason: '可用的连续/有序变量少于 2 个，或有效样本不足 4 例，无法计算相关矩阵。请先收集更多样本，或检查所选变量是否存在变异。',
};

const REGRESSION_UNAVAILABLE = {
  engine_version: '1.0.0',
  available: false,
  reason: '因变量或自变量不存在，或没有可用的自变量。',
};

interface StubOverrides {
  correlation?: unknown;
  regression?: unknown;
  bundle?: unknown;
  comparisons?: unknown;
}

function stubAnalysisApi(overrides: StubOverrides = {}) {
  return stubFetch((call: FetchCall) => {
    const url = call.url;
    if (url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
    if (url.includes('/analysis/run')) return jsonResponse({ data: BUNDLE });
    if (url.includes('/analysis/bundle')) return jsonResponse({ data: overrides.bundle ?? BUNDLE_UNAVAILABLE });
    if (url.includes('/analysis/dataset')) return jsonResponse({ data: DATASET });
    if (url.includes('/analysis/descriptive')) return jsonResponse({ data: DESCRIPTIVE });
    if (url.includes('/analysis/reliability')) return jsonResponse({ data: RELIABILITY });
    if (url.includes('/analysis/validity')) return jsonResponse({ data: VALIDITY });
    if (url.includes('/analysis/correlation')) {
      return jsonResponse({ data: overrides.correlation ?? CORRELATION });
    }
    if (url.includes('/analysis/regression')) return jsonResponse({ data: overrides.regression ?? REGRESSION });
    if (url.includes('/analysis/comparisons')) {
      return jsonResponse({ data: overrides.comparisons ?? COMPARISONS });
    }
    if (url.includes('/analysis/hypotheses')) return jsonResponse({ data: HYPOTHESES });
    return jsonResponse({ data: null });
  });
}

/** Every request fails at the transport layer. */
function stubOfflineApi() {
  return stubFetch(() => {
    throw new Error('connect ECONNREFUSED 127.0.0.1:4000');
  });
}

function rowContaining(needle: string): string {
  const row = queryAll('tr').find((element) => (element.textContent ?? '').includes(needle));
  assert.ok(row, `未找到包含「${needle}」的表格行`);
  return row!.textContent ?? '';
}

beforeEach(() => {
  clearContainer();
  window.localStorage.clear();
});

after(() => {
  closeDom();
});

/* ================================================================== */
/* Descriptive                                                        */
/* ================================================================== */

describe('描述统计页', () => {
  test('渲染描述统计表，名义变量的均值等统计量为「—」而不是数字', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(DescriptivePage)));
      await flush();

      const content = text();
      assert.match(content, /描述统计表（2 个变量）/);
      assert.match(content, /孩子学段/);
      assert.match(content, /名义（分类）/);
      assert.match(content, /3\.62/, '等距变量的均值应显示');
      assert.match(content, /-0\.32/, '偏度应显示');

      const nominalRow = rowContaining('孩子学段');
      assert.ok(nominalRow.includes('—'), '名义变量必须显示「—」');
      assert.ok(!nominalRow.includes('3.62'), '名义变量不应出现其他变量的均值');
      assert.ok(!/\b0\.00\b/.test(nominalRow), '缺失的统计量不得显示为 0.00');

      const intervalRow = rowContaining('家庭教育自我效能');
      assert.match(intervalRow, /3\.62/);
      assert.match(intervalRow, /0\.6%/, '缺失率应按一位小数显示（2/350 = 0.57% → 0.6%）');
    } finally {
      stub.restore();
    }
  });

  test('渲染分类变量频数图与不可用变量提示', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(DescriptivePage)));
      await flush();

      const content = text();
      assert.ok(content.includes('120 人 · 34.3%'), `应绘制频数图：${content}`);
      assert.ok(content.includes('150 人 · 42.9%'));
      assert.ok(content.includes('80 人 · 22.9%'), '最后一个类别不能丢失');
      assert.match(content, /以下变量没有任何有效作答/, '应如实说明未参与分析的变量');
    } finally {
      stub.restore();
    }
  });

  test('接口不可达时显示错误状态而不是空表', async () => {
    const stub = stubOfflineApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(DescriptivePage)));
      await flush();

      assert.match(text(), /无法加载研究项目/);
      assert.match(text(), /无法连接研究平台服务/);
    } finally {
      stub.restore();
    }
  });

  test('分析请求携带登录令牌', async () => {
    window.localStorage.setItem('ferp.token', 'test-token');
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(DescriptivePage)));
      await flush();

      const call = stub.calls.find((item) => item.url.includes('/analysis/descriptive'));
      assert.ok(call, '应请求描述统计接口');
      assert.equal(call!.headers['authorization'], 'Bearer test-token');
      assert.ok(call!.url.includes('project=p-1') === false, '项目编号应位于路径中而不是查询参数');
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Reliability / Validity                                             */
/* ================================================================== */

describe('信度与效度页', () => {
  test('信度页显示 α、条目诊断与判定阈值', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(ReliabilityPage)));
      await flush();

      const content = text();
      assert.match(content, /0\.842/, '应显示 Cronbach α');
      assert.match(content, /0\.846/, '应显示标准化 α');
      assert.match(content, /0\.641/, '应显示平均条目间相关');
      assert.match(content, /0\.712/, '应显示条目校正后题总相关');
      assert.match(content, /0\.905/, '应显示删除条目后的 α');
      assert.match(content, /α 判定参考阈值/);
      assert.match(content, /题总相关低于 0\.30/);
      assert.match(content, /不构成效度证据/);
    } finally {
      stub.restore();
    }
  });

  test('效度页显示 KMO、Bartlett 与因素分析结果', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(ValidityPage)));
      await flush();

      const content = text();
      assert.match(content, /0\.834/, '应显示整体 KMO');
      assert.match(content, /0\.412/, '应显示逐项 MSA');
      assert.match(content, /1842\.310/, '应显示 Bartlett χ²');
      assert.match(content, /1\.920/, '应显示特征值');
      assert.match(content, /0\.871/, '应显示因子负荷');
      assert.match(content, /共同度偏低的条目/);
      assert.match(content, /Q10c/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Correlation                                                        */
/* ================================================================== */

describe('相关分析页', () => {
  test('渲染热力图与变量对明细，并逐格标注方法', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(CorrelationPage)));
      await flush();

      const content = text();
      assert.ok(content.includes('0.62***'), `p<0.001 应标记 ***：${content}`);
      assert.ok(content.includes('0.48**'), 'p<0.01 应标记 **');
      assert.ok(content.includes('0.21') && !content.includes('0.21*'), 'p≥0.05 不应标记');
      assert.ok(!content.includes('1.00*'), '对角线不标注显著性');

      assert.match(content, /Pearson 积矩相关/);
      assert.match(content, /Spearman 等级相关/);
      assert.match(content, /两个变量均为连续\/等距测量/, '应说明方法的选用理由');
      assert.match(content, /38\.44%/, '应显示共享方差');
      assert.match(content, /\[0\.554, 0\.679\]/, 'Pearson 对应显示 95% CI');
      assert.match(content, /家庭教育自我效能/, '应显示变量全称');
    } finally {
      stub.restore();
    }
  });

  test('available: false 时渲染接口给出的中文原因', async () => {
    const stub = stubAnalysisApi({ correlation: CORRELATION_UNAVAILABLE });
    try {
      await render(createElement(MemoryRouter, null, createElement(CorrelationPage)));
      await flush();

      const content = text();
      assert.match(content, /无法计算相关矩阵/);
      assert.match(content, /可用的连续\/有序变量少于 2 个/, '必须原样展示接口原因');
      assert.ok(!content.includes('38.44%'), '不可用时不应渲染任何统计结果');
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Regression                                                         */
/* ================================================================== */

describe('回归分析页', () => {
  test('引擎选择有序 Logistic 时，它作为主要结论显示，OLS 降为对照', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(RegressionPage)));
      await flush();

      const content = text();
      assert.match(content, /有序 Logistic 回归/);
      assert.match(content, /主要结论/);
      assert.match(content, /对照结果/);
      assert.match(content, /2\.1000/, '应显示优势比 OR');
      assert.match(content, /\[1\.657, 2\.662\]/, '应显示 OR 的 95% CI');
      assert.match(content, /0\.742/, '应显示对数优势系数 b');
      assert.match(content, /93\.800/, '应显示似然比 χ²');
      assert.match(content, /比例优势假设检验不显著/, '必须报告比例优势检验');
      assert.match(content, /完全不同意 \| 比较不同意/, '应显示阈值分界');
      assert.match(content, /0\.3970/, 'OLS 的 R² 应作为对照显示');
      assert.match(content, /请勿以此作为主要结论/, 'OLS 必须被明确标为对照');
      assert.match(content, /VIF = 6\.80/, '应提示共线性');
    } finally {
      stub.restore();
    }
  });

  test('available: false 时渲染接口原因', async () => {
    const stub = stubAnalysisApi({ regression: REGRESSION_UNAVAILABLE });
    try {
      await render(createElement(MemoryRouter, null, createElement(RegressionPage)));
      await flush();

      assert.match(text(), /无法进行回归分析/);
      assert.match(text(), /因变量或自变量不存在/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Comparison                                                         */
/* ================================================================== */

describe('组间比较页', () => {
  test('引擎建议与理由突出显示，ANOVA 与非参数结果并列', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(ComparisonPage)));
      await flush();

      const content = text();
      assert.match(content, /建议以非参数检验（Kruskal–Wallis）为主要结论/);
      assert.match(content, /数据触发了组样本量或方差齐性警告/, '必须显示引擎给出的理由');
      assert.match(content, /F\(2, 347\) = 4\.612/);
      assert.match(content, /0\.0259/, '应显示 η²');
      assert.match(content, /7\.420/, '应显示 Kruskal–Wallis H');
      assert.match(content, /p = 0\.024/, '应显示非参数检验的 p 值');
      assert.match(content, /学前 — 小学/, '应显示事后比较');
      assert.match(content, /p = 0\.008/, '应显示 Holm 校正后的 p 值');
      assert.match(content, /不是四分位距/, '接口未提供四分位数时必须说明箱体含义');
      assert.match(content, /均值 ± 1 个标准差/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Hypotheses                                                         */
/* ================================================================== */

describe('假设检验页', () => {
  test('三态判定各自清楚区分，且「证据不足」不被写成证明无关', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(HypothesisPage)));
      await flush();

      const content = text();
      assert.match(content, /判定：支持/);
      assert.match(content, /判定：不支持/);
      assert.match(content, /判定：证据不足/);
      assert.match(content, /方向与假设相反/);
      assert.match(content, /不等于证明两者无关/, '证据不足不得被写成证明无关');

      assert.match(content, /H1/);
      assert.match(content, /H2/);
      assert.match(content, /H3/);
      assert.match(content, /Pearson 积矩相关/);
      assert.match(content, /0\.420/, '应显示 r');
      assert.match(content, /p < 0\.001/, '应显示显著性（低于显示下限时用 p < 0.001）');
      assert.match(content, /p = 0\.210/, '不显著的结果应显示实际 p 值');
      assert.match(content, /效应量中等/, '应显示效应量');
      assert.match(content, /统计方法：Spearman 等级相关/, '应显示判定依据');
      assert.match(content, /不支持.*方向与假设相反/s);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Home                                                               */
/* ================================================================== */

describe('分析总览页', () => {
  test('显示样本构成、漏斗流失与目标进度，并在未运行分析时给出原因', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(AnalysisHomePage)));
      await flush();

      const content = text();
      assert.match(content, /可分析样本/);
      assert.match(content, /350/, '应显示可分析样本数');
      assert.match(content, /已排除/);
      assert.match(content, /50/, '应显示被排除样本数');
      assert.match(content, /较「开始作答」减少 100 份（20\.0%）/, '应显示漏斗流失率');
      assert.match(content, /不属于上一阶段的子集/, '排除样本不得被算作漏斗流失');
      assert.match(content, /微信/, '应显示来源渠道');
      assert.match(content, /300 人 · 60\.0%/);
      assert.match(content, /350\/1000 份 · 35\.0% · 未达目标（尚缺 650 份）/, '应显示目标进度');
      assert.match(content, /尚未运行过完整统计分析/, '未保存分析结果时应显示接口原因');
      assert.match(content, /未参与分析：Q99/, '应如实列出无作答变量');
    } finally {
      stub.restore();
    }
  });

  test('点击「运行全部分析」会调用接口并报告已保存的结果', async () => {
    const stub = stubAnalysisApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(AnalysisHomePage)));
      await flush();

      const button = queryAll('button').find((element) =>
        (element.textContent ?? '').includes('运行全部分析'),
      );
      assert.ok(button, '应有运行全部分析按钮');
      await click(button!);
      await flush();
      await flush();

      const runCall = stub.calls.find((call) => call.url.includes('/analysis/run'));
      assert.ok(runCall, '应调用运行接口');
      assert.equal(runCall!.method, 'POST');

      const content = text();
      assert.match(content, /全部分析已运行并保存/);
      assert.match(content, /350 份/);
      assert.match(content, /不会修改任何作答/, '必须说明该操作不会改动数据');
    } finally {
      stub.restore();
    }
  });

  test('已有保存结果时显示生成时间、模型选择与必须说明的限制', async () => {
    const stub = stubAnalysisApi({ bundle: { available: true, ...BUNDLE } });
    try {
      await render(createElement(MemoryRouter, null, createElement(AnalysisHomePage)));
      await flush();

      const content = text();
      assert.match(content, /已保存/);
      assert.match(content, /引擎版本 1\.0\.0/);
      assert.match(content, /有序 Logistic（含 OLS 对照）/);
      assert.match(content, /结果解读必须同时说明的限制/);
      assert.match(content, /不能据此推断因果关系/);
      assert.match(content, /支持 1 \/ 不支持 1/);
    } finally {
      stub.restore();
    }
  });

  test('接口不可达时显示错误状态', async () => {
    const stub = stubOfflineApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(AnalysisHomePage)));
      await flush();

      assert.match(text(), /无法加载研究项目/);
      assert.match(text(), /无法连接研究平台服务/);
    } finally {
      stub.restore();
    }
  });
});
