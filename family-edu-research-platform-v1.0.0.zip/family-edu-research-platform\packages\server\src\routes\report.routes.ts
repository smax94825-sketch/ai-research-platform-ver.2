/**
 * Research report routes (PHASE 8).
 *
 *   GET /api/projects/:projectId/report      — the 23 structured sections + Markdown
 *   GET /api/projects/:projectId/report.md   — the same report as a Markdown download
 *
 * Both endpoints read the **last persisted analysis bundle**. Nothing is
 * recomputed here: the report is a rendering of statistics the researcher has
 * already seen, so a citation in the report and a number in the analysis console
 * can never disagree. When no bundle exists the request fails with 400 and a
 * message that says what to run first, rather than producing a report whose
 * statistics are all "not available".
 */

import { Router } from 'express';

import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import { ApiError, asyncHandler } from '../util/errors.js';
import { attachmentDisposition } from '../util/download.js';
import { getLatestBundle, loadAnalysableSample } from '../services/analysis.service.js';
import { requireProject } from '../services/project.service.js';
import { buildResearchReport, reportMarkdownFilename, type ResearchReport } from '../services/report.service.js';

export interface ReportRouterContext {
  db: Db;
  config: Config;
}

const NO_BUNDLE_MESSAGE =
  '尚未运行完整统计分析，无法生成研究报告。请先在「分析」页面执行「运行全部分析」，' +
  '报告中的每一个数字都取自该次分析的结果包。';

export function createReportRouter(ctx: ReportRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /**
   * Build the report for the latest stored analysis.
   *
   * The dataset and sample summary are loaded fresh because the report describes
   * both the statistics (from the bundle) and the variables actually collected
   * (from the dataset). If the two disagree, the report says so in its first
   * section instead of quietly preferring one of them.
   */
  function reportFor(projectId: string, researcherId: string): ResearchReport {
    requireProject(ctx.db, projectId, researcherId);

    const bundle = getLatestBundle(ctx.db, projectId, researcherId);
    if (!bundle) throw ApiError.validation(NO_BUNDLE_MESSAGE);

    const loaded = loadAnalysableSample(ctx.db, projectId);
    return buildResearchReport(bundle, loaded.dataset, loaded.summary);
  }

  router.get(
    '/:projectId/report',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      res.json({ data: reportFor(req.params['projectId']!, researcher.id) });
    }),
  );

  router.get(
    '/:projectId/report.md',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const report = reportFor(projectId, researcher.id);

      res.setHeader('content-type', 'text/markdown; charset=utf-8');
      res.setHeader('content-disposition', attachmentDisposition(reportMarkdownFilename(report)));
      res.send(Buffer.from(report.markdown, 'utf8'));
    }),
  );

  return router;
}
