/**
 * Export routes (PHASE 8).
 *
 *   GET /api/projects/:projectId/export/dataset.csv   — wide-format CSV (UTF-8 + BOM)
 *   GET /api/projects/:projectId/export/dataset.json  — data + metadata + codebook
 *   GET /api/projects/:projectId/export/codebook.csv  — variable dictionary + codebook
 *   GET /api/projects/:projectId/export/spss          — ZIP with the .sps syntax + data CSV
 *   GET /api/projects/:projectId/export/spss/syntax    — the .sps syntax file alone
 *   GET /api/projects/:projectId/export/spss/data      — the BOM-free data CSV alone
 *   GET /api/projects/:projectId/export/results.xlsx  — multi-sheet analysis workbook
 *
 * Design notes that the rest of the platform depends on:
 *
 *  - **Synchronous by design.** No job queue and no session state: every export
 *    is a pure read of the current sample (or of the last persisted analysis),
 *    produced in one request. A researcher who clicks download gets a file, not
 *    a ticket.
 *  - **The analysable sample is the base.** Excluded samples are removed and the
 *    exclusion is stated in the JSON metadata and the workbook; the CSV carries
 *    one row per exported respondent and nothing else, so a row count is a
 *    sample count.
 *  - **No `review_status` filter is offered.** The sample loader can only produce
 *    the analysable sample; offering `?review_status=all` would mean serving
 *    in-progress and excluded rows as if they were data, which no service here
 *    can honour honestly. The parameter is therefore absent rather than ignored.
 */

import { Router } from 'express';

import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import { ApiError, asyncHandler } from '../util/errors.js';
import { attachmentDisposition } from '../util/download.js';
import { exportFilenames, toExcelBuffer } from '../services/export.service.js';
import { getLatestBundle } from '../services/analysis.service.js';
import {
  analysisSheets,
  buildSpssArchive,
  buildSpssFiles,
  codebookFileText,
  datasetCsv,
  datasetJson,
  datasetMatchesBundle,
  loadExportPayload,
} from '../services/exportPayload.service.js';
import { requireProject } from '../services/project.service.js';

export interface ExportRouterContext {
  db: Db;
  config: Config;
}

/** The sample on which the stored analysis was computed, for the workbook. */
const SAMPLE_CONSISTENCY_HEADER = 'x-ferp-sample-consistent-with-bundle';

export function createExportRouter(ctx: ExportRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /** Resolve the export payload, enforcing ownership before anything is read. */
  function payloadFor(req: { params: Record<string, string | undefined> }, researcherId: string) {
    const projectId = req.params['projectId']!;
    return loadExportPayload(ctx.db, projectId, researcherId);
  }

  /* ---------------------------------------------------------------- */
  /* Dataset                                                           */
  /* ---------------------------------------------------------------- */

  router.get(
    '/:projectId/export/dataset.csv',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const payload = payloadFor(req, researcher.id);
      const filenames = exportFilenames(payload.context);

      res.setHeader('content-type', 'text/csv; charset=utf-8');
      res.setHeader('content-disposition', attachmentDisposition(filenames.csv));
      // Deliberately a Buffer rather than a string: `res.send` would encode the
      // body but must not be allowed to drop or double the BOM, which is the
      // only thing that makes Excel open a Chinese CSV as UTF-8.
      res.send(Buffer.from(datasetCsv(payload), 'utf8'));
    }),
  );

  router.get(
    '/:projectId/export/dataset.json',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const payload = payloadFor(req, researcher.id);
      const filenames = exportFilenames(payload.context);

      res.setHeader('content-type', 'application/json; charset=utf-8');
      res.setHeader('content-disposition', attachmentDisposition(filenames.json));
      res.send(Buffer.from(datasetJson(payload), 'utf8'));
    }),
  );

  router.get(
    '/:projectId/export/codebook.csv',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const payload = payloadFor(req, researcher.id);
      const filenames = exportFilenames(payload.context);

      res.setHeader('content-type', 'text/csv; charset=utf-8');
      res.setHeader(
        'content-disposition',
        attachmentDisposition(filenames.csv.replace(/\.csv$/, '-codebook.csv')),
      );
      res.send(Buffer.from(codebookFileText(payload), 'utf8'));
    }),
  );

  /* ---------------------------------------------------------------- */
  /* SPSS                                                              */
  /* ---------------------------------------------------------------- */

  /**
   * Both SPSS files as one ZIP.
   *
   * A ZIP is produced instead of a base64 JSON envelope because the two files
   * are consumed by SPSS itself: the researcher unzips them and runs the syntax,
   * which reads the CSV beside it. The archive is built with the project's own
   * stored-entry ZIP writer (`util/zip.ts`), so no dependency was added, and the
   * two files are also available individually below.
   */
  router.get(
    '/:projectId/export/spss',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const payload = payloadFor(req, researcher.id);
      const archive = buildSpssArchive(payload);

      res.setHeader('content-type', 'application/zip');
      res.setHeader('content-disposition', attachmentDisposition(archive.filename));
      res.send(archive.buffer);
    }),
  );

  router.get(
    '/:projectId/export/spss/syntax',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const payload = payloadFor(req, researcher.id);
      const files = buildSpssFiles(payload);

      res.setHeader('content-type', 'text/plain; charset=utf-8');
      res.setHeader(
        'content-disposition',
        attachmentDisposition(exportFilenames(payload.context).spssSyntax),
      );
      res.send(Buffer.from(files.syntax, 'utf8'));
    }),
  );

  /**
   * The data file the syntax reads.
   *
   * Written **without** the BOM: `/TYPE=TXT` reads the first field literally, so
   * a BOM would silently become part of the first variable name and the import
   * would fail in a way that looks like a data problem. The encoding is declared
   * inside the syntax (`/ENCODING='UTF8'`) instead.
   */
  router.get(
    '/:projectId/export/spss/data',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const payload = payloadFor(req, researcher.id);
      const files = buildSpssFiles(payload);

      res.setHeader('content-type', 'text/csv; charset=utf-8');
      res.setHeader(
        'content-disposition',
        attachmentDisposition(exportFilenames(payload.context).spssData),
      );
      res.send(Buffer.from(files.data, 'utf8'));
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Results workbook                                                  */
  /* ---------------------------------------------------------------- */

  /**
   * Multi-sheet workbook built from the **last persisted** analysis bundle.
   *
   * The bundle is used rather than a fresh run so that the workbook a researcher
   * downloads matches the numbers they already saw and can cite. When no bundle
   * exists the request is rejected with an actionable message instead of
   * producing a workbook whose analysis sheets are silently empty.
   */
  router.get(
    '/:projectId/export/results.xlsx',
    asyncHandler(async (req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);

      const bundle = getLatestBundle(ctx.db, projectId, researcher.id);
      if (!bundle) {
        throw ApiError.validation(
          '尚未运行完整统计分析，无法导出分析结果工作簿。请先在「分析」页面执行「运行全部分析」，再导出结果。',
        );
      }

      const payload = loadExportPayload(ctx.db, projectId, researcher.id);
      const buffer = await toExcelBuffer(
        payload.loaded.dataset,
        payload.context,
        analysisSheets(bundle),
      );

      res.setHeader(
        'content-type',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      );
      res.setHeader(
        'content-disposition',
        attachmentDisposition(exportFilenames(payload.context).excel),
      );
      // Stated, not hidden: the workbook pairs freshly loaded data with a stored
      // analysis, and if the sample moved in between, the reader must know.
      res.setHeader(
        SAMPLE_CONSISTENCY_HEADER,
        String(datasetMatchesBundle(payload.loaded.summary, bundle)),
      );
      res.send(buffer);
    }),
  );

  return router;
}
