/**
 * PHASE 8 test harness.
 *
 * `helpers.ts` boots the application through `createApp`, which mounts the
 * routers that existed when it was written. The PHASE 8 routers (export and
 * report) are mounted by the integrator, and `src/app.ts` is owned by them, so
 * these tests compose the same application surface themselves — including the
 * two new routers — instead of asserting against an app that cannot reach the
 * endpoints under test.
 *
 * Everything else is identical to `createTestContext`: a real HTTP server on an
 * ephemeral port against a fresh in-memory database, so the tests exercise
 * routing, JWT verification, SQL, serialisation and the binary writers rather
 * than a mocked subset. The returned object satisfies `TestContext`, so the
 * shared helpers (`api`, `registerResearcher`, …) work unchanged.
 */

import express from 'express';
import cors from 'cors';
import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';

import { loadConfig } from '../src/config.js';
import { Db } from '../src/db/index.js';
import { migrate } from '../src/db/migrate.js';
import { createErrorHandler, notFoundHandler } from '../src/middleware/error.js';
import { createAuthRouter } from '../src/routes/auth.routes.js';
import { createDashboardRouter } from '../src/routes/dashboard.routes.js';
import { createProjectRouter, createTemplateRouter } from '../src/routes/project.routes.js';
import { createPublicRouter } from '../src/routes/public.routes.js';
import { createRespondentRouter, createSampleRouter } from '../src/routes/collection.routes.js';
import {
  createQualityRouter,
  createRespondentQualityRouter,
} from '../src/routes/quality.routes.js';
import {
  createQuestionnaireRouter,
  createQuestionRouter,
} from '../src/routes/questionnaire.routes.js';
import { createAnalysisRouter } from '../src/routes/analysis.routes.js';
import { createExportRouter } from '../src/routes/export.routes.js';
import { createReportRouter } from '../src/routes/report.routes.js';
import type { TestContext } from './helpers.js';

export async function createPhase8TestContext(): Promise<TestContext> {
  const config = loadConfig({
    NODE_ENV: 'test',
    DATABASE_PATH: ':memory:',
    JWT_SECRET: 'test-secret-that-is-long-enough-for-hs256-signing',
    JWT_EXPIRES_IN: '3600',
  });

  const db = new Db(config.databasePath);
  migrate(db);

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', true);
  app.use(cors({ origin: (_origin, callback) => callback(null, true), credentials: true }));
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: false, limit: '2mb' }));

  app.use('/api/auth', createAuthRouter({ db, config }));
  app.use('/api/templates', createTemplateRouter({ db, config }));
  app.use('/api/public', createPublicRouter({ db, config }));
  app.use('/api/dashboard', createDashboardRouter({ db, config }));
  app.use('/api/projects', createProjectRouter({ db, config }));
  app.use('/api/projects', createSampleRouter({ db, config }));
  app.use('/api/projects', createQualityRouter({ db, config }));
  app.use('/api/projects', createAnalysisRouter({ db, config }));
  // PHASE 8: the routers under test.
  app.use('/api/projects', createExportRouter({ db, config }));
  app.use('/api/projects', createReportRouter({ db, config }));
  app.use('/api/respondents', createRespondentRouter({ db, config }));
  app.use('/api/respondents', createRespondentQualityRouter({ db, config }));
  app.use('/api/questionnaires', createQuestionnaireRouter({ db, config }));
  app.use('/api/questions', createQuestionRouter({ db, config }));

  app.use(notFoundHandler);
  app.use(createErrorHandler({ logUnexpected: config.env !== 'test' }));

  const server = await new Promise<Server>((resolve) => {
    const instance = app.listen(0, '127.0.0.1', () => resolve(instance));
  });
  const address = server.address() as AddressInfo;

  return {
    db,
    config,
    server,
    baseUrl: `http://127.0.0.1:${address.port}`,
    close: () =>
      new Promise<void>((resolve, reject) => {
        server.close((error) => {
          db.close();
          if (error) reject(error);
          else resolve();
        });
      }),
  };
}
