/**
 * Export API tests (PHASE 8).
 *
 * A real sample is collected through the public survey API, the analysis bundle
 * is run and persisted, and then every export format is downloaded and inspected
 * as *bytes*: a BOM is asserted on the raw response (the WHATWG `Response.text()`
 * strips it, so a text-based assertion would silently pass while Excel mangled
 * every Chinese column), and the Excel workbook is read back with `exceljs`.
 *
 * The two properties that matter most are checked explicitly rather than
 * implied:
 *  - **missing stays missing** — a null value is an empty CSV field and an empty
 *    Excel cell, never `0`;
 *  - **a sensitive refusal never leaks** — the respondent who chose 「不愿回答」
 *    on Q32 appears as a missing value, and the refusal label appears only in the
 *    codebook, where it documents the coding, never in the data file.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import ExcelJS, { type Workbook } from 'exceljs';

import {
  DICTIONARY_HEADERS,
  CODEBOOK_HEADERS,
} from '../src/services/export.service.js';
import {
  api,
  createProject,
  registerResearcher,
  type TestContext,
} from './helpers.js';
import { createPhase8TestContext } from './phase8.harness.js';
import {
  SENSITIVE_REFUSAL_LABEL,
  SENSITIVE_VARIABLE,
  collectPhase8Sample,
  runAnalysis,
  type Phase8Sample,
} from './phase8.fixture.js';

/* ================================================================== */
/* Shared fixture                                                     */
/* ================================================================== */

const SAMPLE_SIZE = 26;
const REQUIRED_SHEETS = [
  'Raw Data',
  'Variable Dictionary',
  'Codebook',
  'Data Quality',
  'Descriptive Statistics',
  'Reliability',
  'Validity',
  'Correlation',
  'Regression',
  'Hypothesis Testing',
  'Research Findings',
];

let ctx: TestContext;
let owner: string;
let sample: Phase8Sample;
let variables: { name: string; is_derived: boolean }[];

before(async () => {
  ctx = await createPhase8TestContext();
  const researcher = await registerResearcher(ctx, { name: '导出测试研究者' });
  owner = researcher.token;

  sample = await collectPhase8Sample(ctx, owner, {
    size: SAMPLE_SIZE,
    seed: 20260815,
    title: '导出测试研究',
    refusalIndex: 7,
    excludeIndex: 0,
  });

  await runAnalysis(ctx, owner, sample.projectId);

  const inventory = await api<{ variables: { name: string; is_derived: boolean }[] }>(
    ctx,
    'GET',
    `/api/projects/${sample.projectId}/analysis/dataset`,
    { token: owner },
  );
  assert.equal(inventory.status, 200, JSON.stringify(inventory.error));
  variables = inventory.data.variables;
});

after(async () => {
  await ctx.close();
});

/* ================================================================== */
/* Helpers                                                            */
/* ================================================================== */

interface RawResponse {
  status: number;
  bytes: Uint8Array;
  headers: Headers;
  /** Decoded text; `TextDecoder` strips a leading BOM, which is why the BOM is
   * asserted on `bytes` instead. */
  text: string;
}

async function raw(path: string, token?: string | null): Promise<RawResponse> {
  const response = await fetch(`${ctx.baseUrl}${path}`, {
    headers: token ? { authorization: `Bearer ${token}` } : {},
  });
  const buffer = await response.arrayBuffer();
  return {
    status: response.status,
    bytes: new Uint8Array(buffer),
    headers: response.headers,
    text: new TextDecoder('utf-8').decode(buffer),
  };
}

/** Minimal RFC 4180 reader; a field containing a comma is where a naive
 * `split(',')` would give a false pass. */
function parseCsv(text: string): string[][] {
  const source = text.startsWith('\uFEFF') ? text.slice(1) : text;
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;

  for (let index = 0; index < source.length; index += 1) {
    const character = source[index]!;
    if (quoted) {
      if (character === '"') {
        if (source[index + 1] === '"') {
          field += '"';
          index += 1;
        } else {
          quoted = false;
        }
      } else {
        field += character;
      }
      continue;
    }
    if (character === '"') {
      quoted = true;
    } else if (character === ',') {
      row.push(field);
      field = '';
    } else if (character === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else if (character !== '\r') {
      field += character;
    }
  }
  row.push(field);
  rows.push(row);
  // A trailing newline produces one empty row, which is not a record.
  return rows.filter((entry) => !(entry.length === 1 && entry[0] === ''));
}

/**
 * Read a ZIP written with the stored method.
 *
 * Parsing the archive rather than trusting it: the local headers, the sizes and
 * the end-of-central-directory record are all checked, so a corrupt archive
 * cannot pass as valid.
 */
function readStoredZip(buffer: Buffer): { name: string; data: Buffer }[] {
  assert.equal(buffer.readUInt32LE(0), 0x04034b50, '缺少 ZIP 本地文件头签名');

  const entries: { name: string; data: Buffer }[] = [];
  let offset = 0;

  while (offset + 4 <= buffer.length && buffer.readUInt32LE(offset) === 0x04034b50) {
    const method = buffer.readUInt16LE(offset + 8);
    assert.equal(method, 0, 'ZIP 条目应使用存储方式，不应压缩');
    const size = buffer.readUInt32LE(offset + 18);
    const nameLength = buffer.readUInt16LE(offset + 26);
    const extraLength = buffer.readUInt16LE(offset + 28);
    const name = buffer.subarray(offset + 30, offset + 30 + nameLength).toString('utf8');
    const dataStart = offset + 30 + nameLength + extraLength;
    entries.push({ name, data: buffer.subarray(dataStart, dataStart + size) });
    offset = dataStart + size;
  }

  // The local entries end where the central directory begins.
  const centralOffset = offset;
  assert.equal(buffer.readUInt32LE(centralOffset), 0x02014b50, '缺少 ZIP 中央目录头');

  // No archive comment is written, so the end-of-central-directory record is the
  // last 22 bytes and its offsets must agree with what was actually written.
  const end = buffer.length - 22;
  assert.equal(buffer.readUInt32LE(end), 0x06054b50, '缺少 ZIP 中央目录结束记录');
  assert.equal(buffer.readUInt16LE(end + 10), entries.length, '条目数与实际不符');
  assert.equal(buffer.readUInt32LE(end + 16), centralOffset, '中央目录偏移量不正确');
  assert.equal(
    buffer.readUInt32LE(end + 12) + centralOffset,
    end,
    '中央目录大小与偏移量不一致',
  );
  return entries;
}

async function loadWorkbook(buffer: Buffer): Promise<Workbook> {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer as unknown as ArrayBuffer);
  return workbook;
}

function sheetNames(workbook: Workbook): string[] {
  return workbook.worksheets.map((sheet) => sheet.name);
}

/** Cell values of one row as a plain array (exceljs rows are 1-based/sparse). */
function rowCells(row: { values: unknown }): unknown[] {
  return Array.from(row.values as unknown[]).slice(1);
}

function headerOf(workbook: Workbook, name: string): unknown[] {
  const sheet = workbook.getWorksheet(name);
  assert.ok(sheet, `缺少工作表 ${name}`);
  return rowCells(sheet.getRow(1));
}

/* ================================================================== */
/* CSV                                                                */
/* ================================================================== */

describe('导出：原始数据 CSV', () => {
  test('响应以 UTF-8 BOM 字节开头，并带有中文文件名', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/dataset.csv`, owner);

    assert.equal(response.status, 200);
    assert.equal(response.bytes[0], 0xef, 'CSV 缺少 UTF-8 BOM 的第一个字节');
    assert.equal(response.bytes[1], 0xbb);
    assert.equal(response.bytes[2], 0xbf);

    const disposition = response.headers.get('content-disposition') ?? '';
    assert.ok(disposition.startsWith('attachment'), `content-disposition 异常：${disposition}`);
    assert.ok(disposition.includes("filename*=UTF-8''"), '必须给出 UTF-8 文件名');
    assert.ok(disposition.includes('%E5%AF%BC%E5%87%BA'), '文件名应包含项目标题的中文');
  });

  test('表头与数据集的列顺序完全一致，每名可分析受访者一行', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/dataset.csv`, owner);
    const rows = parseCsv(response.text);
    const header = rows[0]!;

    assert.deepEqual(header, ['respondent_id', ...variables.map((variable) => variable.name)]);
    assert.equal(rows.length - 1, sample.analysable, '一个数据行必须对应一名可分析受访者');
    assert.equal(variables.length + 1, header.length);

    const ids = rows.slice(1).map((row) => row[0]!);
    assert.equal(new Set(ids).size, ids.length, '同一受访者不应出现两行');
    assert.ok(!ids.includes(sample.excludedRespondentId), '被排除的样本不得出现在导出数据中');
    for (const id of ids) assert.ok(sample.respondents.includes(id), `未知的受访者 ${id}`);
  });

  test('敏感拒答导为空字段，拒答标签不进入数据文件', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/dataset.csv`, owner);
    const rows = parseCsv(response.text);
    const header = rows[0]!;
    const column = header.indexOf(SENSITIVE_VARIABLE);
    assert.ok(column > 0, `CSV 中缺少变量 ${SENSITIVE_VARIABLE}`);

    const row = rows.find((entry) => entry[0] === sample.sensitiveRespondentId);
    assert.ok(row, '选择了「不愿回答」的受访者应仍在数据中');

    const cell = row![column]!;
    assert.equal(cell, '', '敏感拒答必须导出为空字段');
    assert.notEqual(cell, '0', '敏感拒答绝不能被写成 0');

    // A refusal is not a category: the label belongs in the codebook only.
    assert.ok(
      !response.text.includes(SENSITIVE_REFUSAL_LABEL),
      '数据文件中不得出现拒答选项的标签文本',
    );
  });
});

/* ================================================================== */
/* JSON                                                               */
/* ================================================================== */

describe('导出：JSON', () => {
  test('元数据同时给出收集总数与导出行数，二者可以不同', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/dataset.json`, owner);

    assert.equal(response.status, 200);
    const payload = JSON.parse(response.text) as {
      metadata: {
        respondents_total: number;
        respondents_exported: number;
        excluded_note: string | null;
        missing_value_note: string;
      };
      columns: string[];
      data: Record<string, string | number | null>[];
      codebook: { variable_name: string; n_valid: number; n_missing: number }[];
    };

    assert.equal(payload.metadata.respondents_total, SAMPLE_SIZE);
    assert.equal(payload.metadata.respondents_exported, sample.analysable);
    assert.notEqual(
      payload.metadata.respondents_total,
      payload.metadata.respondents_exported,
      '排除样本后两个数字必须能体现差异',
    );
    assert.ok(payload.metadata.excluded_note?.includes('已排除 1 份样本'));
    assert.ok(payload.metadata.missing_value_note.includes('缺失'));

    assert.deepEqual(payload.columns, ['respondent_id', ...variables.map((v) => v.name)]);
    assert.equal(payload.data.length, sample.analysable);
    assert.ok(
      !payload.data.some((row) => row['respondent_id'] === sample.excludedRespondentId),
      '被排除的受访者不得出现在 JSON 数据中',
    );

    const refusalRow = payload.data.find(
      (row) => row['respondent_id'] === sample.sensitiveRespondentId,
    );
    assert.ok(refusalRow, '拒答受访者应仍被导出');
    assert.equal(refusalRow![SENSITIVE_VARIABLE], null, '敏感拒答在 JSON 中必须是 null');

    // The codebook half of the same payload reports the refusal as a documented
    // coding option *and* counts it as missing, which is the honest pairing.
    const sensitiveEntry = payload.codebook.find(
      (entry) => entry.variable_name === SENSITIVE_VARIABLE,
    );
    assert.ok(sensitiveEntry);
    assert.equal(sensitiveEntry!.n_missing, 1);
    assert.equal(sensitiveEntry!.n_valid, sample.analysable - 1);
  });

  test('CSV 与 JSON 对同一单元格给出一致的取值与缺失表示', async () => {
    const csv = await raw(`/api/projects/${sample.projectId}/export/dataset.csv`, owner);
    const json = await raw(`/api/projects/${sample.projectId}/export/dataset.json`, owner);

    const rows = parseCsv(csv.text);
    const header = rows[0]!;
    const payload = JSON.parse(json.text) as {
      columns: string[];
      data: Record<string, string | number | null>[];
    };
    assert.deepEqual(payload.columns, header);

    const byId = new Map(rows.slice(1).map((row) => [row[0]!, row]));
    for (const record of payload.data) {
      const row = byId.get(String(record['respondent_id']));
      assert.ok(row, `CSV 中缺少受访者 ${record['respondent_id']}`);
      payload.columns.forEach((column, index) => {
        const value = record[column];
        const cell = row![index]!;
        if (value === null) {
          assert.equal(cell, '', `${column} 的缺失值必须是空字段而不是「${cell}」`);
        } else {
          assert.equal(cell, String(value), `${column} 的 CSV 取值与 JSON 不一致`);
        }
      });
    }
  });
});

/* ================================================================== */
/* Codebook                                                           */
/* ================================================================== */

describe('导出：变量字典与编码簿', () => {
  test('包含变量字典与选项编码两段，并如实记录拒答选项的编码处理', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/codebook.csv`, owner);

    assert.equal(response.status, 200);
    assert.deepEqual(Array.from(response.bytes.subarray(0, 3)), [0xef, 0xbb, 0xbf]);

    const rows = parseCsv(response.text);
    assert.deepEqual(rows[0], DICTIONARY_HEADERS);

    const codebookStart = rows.findIndex((row) => row.join('\u0000') === CODEBOOK_HEADERS.join('\u0000'));
    assert.ok(codebookStart > 0, '缺少编码簿表头');

    const dictionary = rows.slice(1, codebookStart).filter((row) => row.length > 1);
    const codebook = rows.slice(codebookStart + 1);
    assert.ok(dictionary.length >= variables.length, '变量字典应覆盖全部导出变量');

    const sensitiveDictionaryRow = dictionary.find((row) => row[0] === SENSITIVE_VARIABLE);
    assert.ok(sensitiveDictionaryRow, '变量字典缺少敏感题变量');
    assert.ok(
      sensitiveDictionaryRow!.join(' ').includes('敏感'),
      '变量字典必须说明敏感拒答按缺失处理',
    );

    // The label lives here — and only here — so a reader can decode the column.
    assert.ok(
      codebook.some((row) => row[0] === SENSITIVE_VARIABLE && row[4] === SENSITIVE_REFUSAL_LABEL),
      '编码簿应记录拒答选项代码与标签的对应关系',
    );
  });
});

/* ================================================================== */
/* SPSS                                                               */
/* ================================================================== */

describe('导出：SPSS', () => {
  test('归档为一个可解析的 ZIP，内含语法与配套数据两个文件', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/spss`, owner);

    assert.equal(response.status, 200);
    assert.equal(response.headers.get('content-type'), 'application/zip');

    const archive = readStoredZip(Buffer.from(response.bytes));
    assert.equal(archive.length, 2, '归档中应恰有两个文件，不能只给其中一个');

    const syntaxEntry = archive.find((entry) => entry.name.endsWith('-spss.sps'));
    const dataEntry = archive.find((entry) => entry.name.endsWith('-spss.csv'));
    assert.ok(syntaxEntry, '归档缺少 .sps 语法文件');
    assert.ok(dataEntry, '归档缺少配套数据文件');

    // The archive must carry exactly the files the individual endpoints serve.
    // The data file is byte-identical (it contains no timestamp); the syntax
    // carries its own export timestamp, so that one line is normalised before
    // comparing.
    const servedSyntax = await raw(`/api/projects/${sample.projectId}/export/spss/syntax`, owner);
    const servedData = await raw(`/api/projects/${sample.projectId}/export/spss/data`, owner);
    const withoutTimestamp = (text: string): string =>
      text.replace(/^\* 导出时间：[^\n]*$/m, '* 导出时间：（忽略）');

    assert.equal(dataEntry!.data.toString('utf8'), servedData.text);
    assert.equal(
      withoutTimestamp(syntaxEntry!.data.toString('utf8')),
      withoutTimestamp(servedSyntax.text),
    );
    assert.ok(syntaxEntry!.data.toString('utf8').includes('GET DATA'));
  });

  test('语法声明标签、只使用 SYSMIS、不虚构缺失码', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/spss/syntax`, owner);

    assert.equal(response.status, 200);
    assert.ok(response.text.includes('GET DATA'), '语法必须包含 GET DATA');
    assert.ok(response.text.includes('VARIABLE LABELS'), '语法必须包含 VARIABLE LABELS');
    assert.ok(response.text.includes('EXECUTE.'), '语法必须包含 EXECUTE.');
    assert.ok(response.text.includes('MISSING VALUES'), '语法必须声明缺失值');
    assert.ok(response.text.includes(SENSITIVE_VARIABLE), '语法必须包含数据文件中的变量');

    // Locate the MISSING VALUES *command* (the string also occurs in a comment
    // block, so the command line itself is matched).
    const lines = response.text.split('\n');
    const start = lines.findIndex((line) => line.trim() === 'MISSING VALUES');
    assert.ok(start > -1, '语法缺少 MISSING VALUES 命令');
    const block: string[] = [];
    for (let index = start + 1; index < lines.length; index += 1) {
      block.push(lines[index]!);
      if (lines[index]!.trim() === '') break;
    }
    const body = block.join('\n');

    assert.ok(body.includes('(SYSMIS)'), '缺失值必须以系统缺失 (SYSMIS) 声明');
    assert.ok(!/-1\b/.test(body), '不得声明 -1 之类的自造缺失码');
    assert.ok(!/\b99\b/.test(body), '不得声明 99 之类的自造缺失码');
    assert.ok(!/\b999\b/.test(body), '不得声明 999 之类的自造缺失码');

    // Every remaining token in the block must be a variable name, not a number.
    const tokens = body
      .split(/\s+/)
      .map((token) => token.replace(/[().]/g, ''))
      .filter((token) => token !== '' && token !== 'SYSMIS');
    for (const token of tokens) {
      assert.ok(
        !/^-?\d+(\.\d+)?$/.test(token),
        `MISSING VALUES 段出现了数字型缺失码：${token}`,
      );
    }
  });

  test('配套数据文件不带 BOM，且拒答仍是空字段', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/spss/data`, owner);

    assert.equal(response.status, 200);
    assert.ok(
      !(response.bytes[0] === 0xef && response.bytes[1] === 0xbb && response.bytes[2] === 0xbf),
      'SPSS 数据文件不能带 BOM，否则第一个变量名会被污染',
    );

    const rows = parseCsv(response.text);
    assert.equal(rows[0]![0], 'respondent_id');
    assert.equal(rows.length - 1, sample.analysable, '数据行数必须等于可分析样本量');
    assert.ok(!response.text.includes(SENSITIVE_REFUSAL_LABEL), '数据文件不得包含拒答标签');

    const column = rows[0]!.indexOf(SENSITIVE_VARIABLE);
    const row = rows.find((entry) => entry[0] === sample.sensitiveRespondentId);
    assert.ok(row);
    assert.equal(row![column], '', '拒答在 SPSS 数据文件中同样是空字段');
  });
});

/* ================================================================== */
/* Excel                                                              */
/* ================================================================== */

describe('导出：Excel 结果工作簿', () => {
  test('工作表名称与顺序固定，原始数据一人一行', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/results.xlsx`, owner);

    assert.equal(response.status, 200);
    assert.ok(
      response.headers.get('content-type')?.includes('spreadsheetml'),
      'content-type 应为 xlsx',
    );
    assert.equal(response.headers.get('x-ferp-sample-consistent-with-bundle'), 'true');

    const workbook = await loadWorkbook(Buffer.from(response.bytes));
    assert.deepEqual(sheetNames(workbook), REQUIRED_SHEETS);

    const rawSheet = workbook.getWorksheet('Raw Data');
    assert.ok(rawSheet);
    assert.equal(rawSheet.rowCount, sample.analysable + 1, 'Raw Data 应为表头 + 每名受访者一行');
    assert.deepEqual(
      headerOf(workbook, 'Raw Data'),
      ['respondent_id', ...variables.map((variable) => variable.name)],
    );
  });

  test('缺失值是空单元格而不是 0，分析表来自真实结果包', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/results.xlsx`, owner);
    const workbook = await loadWorkbook(Buffer.from(response.bytes));

    const bundle = await api<{
      descriptive: { variables: { variable: string }[] };
      hypotheses: {
        results: { code: string; verdict: string; r: number | null }[];
        summary: { total: number };
      };
    }>(ctx, 'GET', `/api/projects/${sample.projectId}/analysis/bundle`, { token: owner });
    assert.equal(bundle.status, 200, JSON.stringify(bundle.error));

    const rawSheet = workbook.getWorksheet('Raw Data')!;
    const header = headerOf(workbook, 'Raw Data').map(String);
    const idColumn = header.indexOf('respondent_id') + 1;
    const sensitiveColumn = header.indexOf(SENSITIVE_VARIABLE) + 1;
    assert.ok(sensitiveColumn > 1);

    let refusalRow = 0;
    rawSheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      if (String(row.getCell(idColumn).value) === sample.sensitiveRespondentId) {
        refusalRow = rowNumber;
      }
    });
    assert.ok(refusalRow > 1, '工作簿中应能找到拒答受访者的行');

    const cell = rawSheet.getRow(refusalRow).getCell(sensitiveColumn).value;
    assert.notEqual(cell, 0, '缺失值不得写成 0');
    assert.ok(
      cell === null || cell === undefined,
      `敏感拒答应为空单元格，实际为 ${String(cell)}`,
    );

    // Analysis sheets come from the persisted bundle, not from a second run.
    const descriptiveSheet = workbook.getWorksheet('Descriptive Statistics')!;
    assert.equal(descriptiveSheet.rowCount, bundle.data.descriptive.variables.length + 1);

    const hypothesisSheet = workbook.getWorksheet('Hypothesis Testing')!;
    assert.equal(hypothesisSheet.rowCount, bundle.data.hypotheses.results.length + 1);

    const headers = rowCells(hypothesisSheet.getRow(1)).map(String);
    const codeColumn = headers.indexOf('Hypothesis') + 1;
    const statisticColumn = headers.indexOf('Statistic') + 1;
    const decisionColumn = headers.indexOf('Decision') + 1;

    bundle.data.hypotheses.results.forEach((result, position) => {
      const row = hypothesisSheet.getRow(position + 2);
      assert.equal(row.getCell(codeColumn).value, result.code);
      assert.equal(row.getCell(statisticColumn).value, result.r, `${result.code} 的 r 应等于结果包的值`);

      const decision = String(row.getCell(decisionColumn).value);
      if (result.verdict === 'inconclusive') {
        assert.ok(decision.includes('证据不足'), '证据不足的结论必须写明');
        assert.ok(
          decision.includes('没有关系'),
          '证据不足的措辞必须避免被读成「已证明无关」',
        );
      } else {
        assert.ok(decision.length > 0);
      }
    });
  });
});

/* ================================================================== */
/* Authorisation                                                      */
/* ================================================================== */

describe('导出：访问控制', () => {
  test('未登录不能导出', async () => {
    const response = await raw(`/api/projects/${sample.projectId}/export/dataset.csv`, null);
    assert.equal(response.status, 401);
  });

  test('他人项目不可导出', async () => {
    const outsider = await registerResearcher(ctx, { name: '无关研究者' });
    for (const path of ['export/dataset.csv', 'export/dataset.json', 'export/codebook.csv', 'export/spss', 'export/results.xlsx']) {
      const response = await raw(`/api/projects/${sample.projectId}/${path}`, outsider.token);
      assert.ok(
        response.status === 403 || response.status === 404,
        `${path} 对他人项目返回了 ${response.status}`,
      );
    }
  });

  test('尚未运行分析时拒绝导出结果工作簿', async () => {
    const other = await createProject(ctx, owner, { title: '尚未分析的导出项目' });
    const response = await raw(`/api/projects/${other.id}/export/results.xlsx`, owner);

    assert.equal(response.status, 400, '没有结果包时应返回 400');
    const payload = JSON.parse(response.text) as { error: { message: string } };
    assert.ok(payload.error.message.includes('运行全部分析'), payload.error.message);
  });
});
