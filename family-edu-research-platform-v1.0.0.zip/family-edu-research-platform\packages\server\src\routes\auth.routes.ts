/**
 * Authentication routes.
 *
 * POST /api/auth/register  — create a researcher account
 * POST /api/auth/login     — exchange credentials for a JWT
 * GET  /api/auth/me        — current researcher (requires auth)
 * POST /api/auth/logout    — revoke all outstanding tokens for this account
 */

import { Router } from 'express';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { requireAuth, currentResearcher } from '../middleware/auth.js';
import { signJwt } from '../security/jwt.js';
import {
  authenticateResearcher,
  bumpTokenVersion,
  normalizeEmail,
  registerResearcher,
} from '../services/researcher.service.js';
import { toResearcher } from '../services/mappers.js';
import { ApiError, asyncHandler } from '../util/errors.js';
import { findResearcherById } from '../services/researcher.service.js';
import { clientKey, createRateLimiter } from '../util/rateLimit.js';
import { newId, nowIso } from '../util/ids.js';

export interface AuthRouterContext {
  db: Db;
  config: Config;
}

function recordAudit(db: Db, action: string, researcherId: string | null, detail: unknown): void {
  db.run(
    'INSERT INTO audit_logs (id, researcher_id, action, entity, entity_id, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [
      newId(),
      researcherId,
      action,
      'researcher',
      researcherId,
      JSON.stringify(detail ?? {}),
      nowIso(),
    ],
  );
}

export function createAuthRouter(ctx: AuthRouterContext): Router {
  const router = Router();

  // Throttle login attempts per (email + client) pair.
  const loginLimiter = createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 10,
    keyFn: (req) => {
      const email =
        typeof (req.body as { email?: unknown })?.email === 'string'
          ? normalizeEmail((req.body as { email: string }).email)
          : 'unknown';
      return `${clientKey(req)}::${email}`;
    },
    message: '登录尝试次数过多，请 15 分钟后重试。',
  });

  router.post(
    '/register',
    asyncHandler((req, res) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const researcher = registerResearcher(ctx.db, {
        name: typeof body['name'] === 'string' ? body['name'] : '',
        email: typeof body['email'] === 'string' ? body['email'] : '',
        password: typeof body['password'] === 'string' ? body['password'] : '',
        affiliation: typeof body['affiliation'] === 'string' ? body['affiliation'] : null,
      });

      const row = findResearcherById(ctx.db, researcher.id);
      const tokenVersion = row?.token_version ?? 0;
      const token = signJwt(
        { sub: researcher.id, tv: tokenVersion, email: researcher.email },
        ctx.config.jwtSecret,
        ctx.config.jwtExpiresIn,
      );

      recordAudit(ctx.db, 'researcher.register', researcher.id, { email: researcher.email });

      res.status(201).json({
        data: {
          researcher,
          token,
          token_type: 'Bearer',
          expires_in: ctx.config.jwtExpiresIn,
        },
      });
    }),
  );

  router.post(
    '/login',
    loginLimiter.middleware,
    asyncHandler((req, res) => {
      const body = (req.body ?? {}) as Record<string, unknown>;
      const email = typeof body['email'] === 'string' ? body['email'] : '';
      const password = typeof body['password'] === 'string' ? body['password'] : '';

      if (email.trim() === '' || password === '') {
        throw ApiError.validation('请填写邮箱和密码。');
      }

      const result = authenticateResearcher(ctx.db, email, password);
      if (!result) {
        // Identical message for unknown account and wrong password.
        throw new ApiError('UNAUTHORIZED', '邮箱或密码不正确。');
      }

      loginLimiter.reset(`${clientKey(req)}::${normalizeEmail(email)}`);

      const token = signJwt(
        { sub: result.researcher.id, tv: result.tokenVersion, email: result.researcher.email },
        ctx.config.jwtSecret,
        ctx.config.jwtExpiresIn,
      );

      recordAudit(ctx.db, 'researcher.login', result.researcher.id, {});

      res.json({
        data: {
          researcher: result.researcher,
          token,
          token_type: 'Bearer',
          expires_in: ctx.config.jwtExpiresIn,
        },
      });
    }),
  );

  router.get(
    '/me',
    requireAuth(ctx),
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      // Re-read so token_version changes are reflected without re-login.
      const row = findResearcherById(ctx.db, researcher.id);
      res.json({ data: row ? toResearcher(row) : researcher });
    }),
  );

  router.post(
    '/logout',
    requireAuth(ctx),
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const version = bumpTokenVersion(ctx.db, researcher.id);
      recordAudit(ctx.db, 'researcher.logout', researcher.id, { token_version: version });
      res.json({
        data: {
          ok: true,
          message: '已退出登录，此前签发的所有令牌均已失效。',
          token_version: version,
        },
      });
    }),
  );

  return router;
}
