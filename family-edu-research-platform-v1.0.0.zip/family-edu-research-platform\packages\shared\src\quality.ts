/**
 * Data quality engine (PHASE 4).
 *
 * Pure, IO-free rules so the console, the API and the tests all run the same
 * logic. The engine produces two things:
 *   1. per-rule findings (which rule fired, how badly, and the evidence)
 *   2. a 0—100 quality score derived from those findings
 *
 * Two design commitments, both load-bearing for research integrity:
 *
 *  - **The engine never deletes or modifies a sample.** It writes advisory
 *    flags; a human decides. Every function here is read-only with respect to
 *    response data.
 *  - **Explicit refusal is not low quality.** A respondent who selects
 *    "不愿回答" on a sensitive item is exercising a documented right, so refusal
 *    is deliberately NOT a rule. Scoring it would bias sensitive items towards
 *    the answers of people willing to disclose.
 */

import { SCALE_BASED_TYPES, type Question } from './types.js';
import { computeKnowledgeAccuracy } from './scoring.js';
import { isEmptyAnswer } from './answer.js';
import { isQuestionVisible, sortQuestions } from './logic.js';
import type { AnswerMap, AnswerValue } from './values.js';

export const QUALITY_ENGINE_VERSION = '1.0.0';

/* ------------------------------------------------------------------ */
/* Rule catalogue                                                     */
/* ------------------------------------------------------------------ */

export type QualityRuleCode =
  | 'SUSPICIOUS_SPEED'
  | 'LONG_STRING'
  | 'HIGH_MISSING'
  | 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'
  | 'DUPLICATE_SUBMISSION'
  | 'MATRIX_STRAIGHT_LINE'
  | 'ALTERNATING_PATTERN';

export type QualitySeverity = 'info' | 'warning' | 'critical';

export interface QualityRuleDefinition {
  code: QualityRuleCode;
  label: string;
  /** What the rule detects, in the researcher's language. */
  description: string;
  /** How to read a positive finding, including its limitations. */
  interpretation: string;
  defaultSeverity: QualitySeverity;
  /** Points subtracted from 100 when this rule fires. */
  scoreImpact: number;
}

/**
 * Rule catalogue. Score impacts are additive and clamped at 0; they are
 * heuristic weights, not probabilities, and are reported per rule so a
 * researcher can see exactly why a sample scored what it did.
 */
export const QUALITY_RULES: Record<QualityRuleCode, QualityRuleDefinition> = {
  SUSPICIOUS_SPEED: {
    code: 'SUSPICIOUS_SPEED',
    label: '完成时间过短',
    description:
      '作答用时低于研究项目设定的最短时长，或平均每题用时低于 2 秒。58 题的问卷在 35 秒内完成属于明显异常。',
    interpretation:
      '可能未认真阅读题目。但需谨慎：熟悉问卷内容的受访者、或在其他设备上已完成过相似问卷者，也可能作答很快。',
    defaultSeverity: 'critical',
    scoreImpact: 30,
  },
  LONG_STRING: {
    code: 'LONG_STRING',
    label: '连续同选项作答',
    description:
      '在连续 20 个及以上量表条目上选择完全相同的选项（矩阵题的每一行按一个条目计算）。',
    interpretation:
      '常见于机械作答。但需注意：真实的"一贯同意"或"一贯不满意"也可能产生长串相同选项，应结合开放题与作答时长判断。',
    defaultSeverity: 'warning',
    scoreImpact: 25,
  },
  HIGH_MISSING: {
    code: 'HIGH_MISSING',
    label: '缺失率过高',
    description: '在向其展示的题目中，有超过 20% 未作答。',
    interpretation:
      '可能是中途放弃或跳答。但需注意：拒答敏感题是受访者的权利，反复拒答同样会表现为高缺失率，这不等于作答不认真。' +
      '仅统计实际展示给该受访者的题目，条件跳转导致的未作答不计入。',
    defaultSeverity: 'warning',
    scoreImpact: 20,
  },
  SUBJECTIVE_OBJECTIVE_DISCREPANCY: {
    code: 'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
    label: '主客观知识矛盾',
    description:
      '受访者自评"比较了解"或"非常了解"家庭教育知识，但在客观知识题上得分极低（≤1 分）。',
    interpretation:
      '反映的是自我评估与客观测量之间的差距，本身不等于作答不认真。该模式在研究中具有独立价值，建议单独报告而非一律剔除。',
    defaultSeverity: 'info',
    scoreImpact: 15,
  },
  DUPLICATE_SUBMISSION: {
    code: 'DUPLICATE_SUBMISSION',
    label: '疑似重复提交',
    description: '与同一问卷中另一份样本的作答向量完全一致（且作答题目数量达到最低要求）。',
    interpretation:
      '可能为同一人重复提交或批量填写。但需注意：题目较少或选项较少时，不同受访者也可能产生完全一致的作答向量，' +
      '因此该标记本身只是线索，需结合来源渠道、提交时间与设备信息判断。若确认为同一人，建议保留一份并在方法部分说明；' +
      '平台不会自动删除任何一份。',
    defaultSeverity: 'critical',
    scoreImpact: 40,
  },
  MATRIX_STRAIGHT_LINE: {
    code: 'MATRIX_STRAIGHT_LINE',
    label: '矩阵题整列同一选项',
    description: '某道矩阵题的全部行均选择了同一个选项，且行数不少于 5 行。',
    interpretation:
      '矩阵题最容易出现机械作答。但若该矩阵描述的是高度一致的真实体验（例如各方面都不满意），也可能如实如此。',
    defaultSeverity: 'warning',
    scoreImpact: 15,
  },
  ALTERNATING_PATTERN: {
    code: 'ALTERNATING_PATTERN',
    label: '规律性交替作答',
    description: '量表条目上出现连续 12 项以上的 A—B—A—B 交替模式。',
    interpretation: '人类极少如此作答，通常提示由脚本或自动程序提交；但若问卷本身要求交替选择，则属于设计所致。',
    defaultSeverity: 'critical',
    scoreImpact: 20,
  },
};

/** Order used when reporting findings, so output is stable. */
export const QUALITY_RULE_ORDER: readonly QualityRuleCode[] = [
  'DUPLICATE_SUBMISSION',
  'SUSPICIOUS_SPEED',
  'LONG_STRING',
  'ALTERNATING_PATTERN',
  'MATRIX_STRAIGHT_LINE',
  'HIGH_MISSING',
  'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
];

/* ------------------------------------------------------------------ */
/* Tunable thresholds                                                 */
/* ------------------------------------------------------------------ */

export interface QualityThresholds {
  /** Minimum plausible seconds per administered question. */
  minSecondsPerQuestion: number;
  /** Default minimum total duration when the project sets none. */
  defaultMinDurationSeconds: number;
  /** Consecutive identical scale answers that constitute a long string. */
  longStringLength: number;
  /** Consecutive A—B alternations that constitute a pattern. */
  alternatingLength: number;
  /** Share of administered questions that may be missing. */
  maxMissingRate: number;
  /** Rows required before a matrix straight-line is reported. */
  matrixStraightLineMinRows: number;
  /** Answered questions required before duplicate detection applies. */
  duplicateMinAnswered: number;
  /** Self-rated knowledge at or above this counts as "claims to know". */
  subjectiveHighThreshold: number;
  /** Objective score at or below this counts as "objectively low". */
  objectiveLowThreshold: number;
}

export const DEFAULT_QUALITY_THRESHOLDS: QualityThresholds = {
  minSecondsPerQuestion: 2,
  defaultMinDurationSeconds: 90,
  longStringLength: 20,
  alternatingLength: 12,
  maxMissingRate: 0.2,
  matrixStraightLineMinRows: 5,
  duplicateMinAnswered: 10,
  subjectiveHighThreshold: 4,
  objectiveLowThreshold: 1,
};

/**
 * Which variables the subjective/objective discrepancy rule compares.
 * Absent from a questionnaire → the rule simply never fires (reported as
 * "not applicable" rather than as a pass, so the absence is visible).
 */
export interface KnowledgePairing {
  subjectiveVariable: string;
  objectiveVariable: string;
}

export const DEFAULT_KNOWLEDGE_PAIRING: KnowledgePairing = {
  subjectiveVariable: 'FEK',
  objectiveVariable: 'LKA',
};

/* ------------------------------------------------------------------ */
/* Findings                                                           */
/* ------------------------------------------------------------------ */

export interface QualityFinding {
  code: QualityRuleCode;
  label: string;
  severity: QualitySeverity;
  scoreImpact: number;
  /** Human-readable evidence, e.g. "用时 41 秒，低于阈值 90 秒". */
  detail: string;
  /** Machine-readable evidence for the UI and for later reporting. */
  evidence: Record<string, unknown>;
}

export interface QualityEvaluationInput {
  questions: Question[];
  answers: AnswerMap;
  durationSeconds: number | null;
  minDurationSeconds?: number | null;
  /** Number of respondents sharing this respondent's answer signature. */
  duplicateCount?: number;
  thresholds?: Partial<QualityThresholds>;
  pairing?: KnowledgePairing | null;
}

export interface QualityEvaluationResult {
  score: number;
  severity: QualitySeverity | 'clean';
  findings: QualityFinding[];
  /** Administered / answered counts behind the score, for transparency. */
  stats: {
    administered: number;
    answered: number;
    scale_items: number;
    missing_rate: number | null;
    seconds_per_question: number | null;
  };
  /** Rules that could not run, with the reason. */
  skipped: { code: QualityRuleCode; reason: string }[];
  engine_version: string;
}

/* ------------------------------------------------------------------ */
/* Item sequence helpers                                              */
/* ------------------------------------------------------------------ */

interface ScaleItem {
  /** Question code, or `Q35.1` for a matrix row. */
  key: string;
  questionCode: string;
  rowLabel?: string;
  code: string;
}

/**
 * Flatten the instrument into a sequence of scale items.
 *
 * Matrix rows are expanded so that a respondent who answers every row of every
 * matrix identically is detectable; treating a matrix as one item would hide
 * exactly the pattern researchers care about most.
 */
export function scaleItemSequence(questions: Question[], answers: AnswerMap): ScaleItem[] {
  const items: ScaleItem[] = [];
  for (const question of sortQuestions(questions)) {
    if (question.question_type === 'page_break') continue;
    if (!isQuestionVisible(question, answers)) continue;
    const answer = answers[question.question_code];
    if (isEmptyAnswer(answer)) continue;

    if (question.question_type === 'matrix') {
      const rows = question.options.matrix?.rows ?? [];
      const map = (answer ?? {}) as Record<string, string>;
      for (const row of rows) {
        const code = map[row.value];
        if (code === undefined || code === null || String(code).trim() === '') continue;
        items.push({
          key: `${question.question_code}.${row.value}`,
          questionCode: question.question_code,
          rowLabel: row.label,
          code: String(code),
        });
      }
      continue;
    }

    if (SCALE_BASED_TYPES.includes(question.question_type)) {
      items.push({
        key: question.question_code,
        questionCode: question.question_code,
        code: String(answer),
      });
    }
  }
  return items;
}

/** Questions actually administered to this respondent (visible + answerable). */
export function administeredQuestions(questions: Question[], answers: AnswerMap): Question[] {
  return sortQuestions(questions).filter(
    (question) => question.question_type !== 'page_break' && isQuestionVisible(question, answers),
  );
}

/** Longest run of identical option codes in the scale-item sequence. */
export function longestIdenticalRun(items: ScaleItem[]): { length: number; code: string | null; start: number } {
  let best = { length: 0, code: null as string | null, start: 0 };
  let currentLength = 0;
  let currentCode: string | null = null;
  let currentStart = 0;

  items.forEach((item, index) => {
    if (item.code === currentCode) {
      currentLength += 1;
    } else {
      currentCode = item.code;
      currentLength = 1;
      currentStart = index;
    }
    if (currentLength > best.length) {
      best = { length: currentLength, code: currentCode, start: currentStart };
    }
  });

  return best;
}

/** Longest A—B—A—B alternation run. */
export function longestAlternatingRun(items: ScaleItem[]): { length: number; start: number } {
  let best = { length: 0, start: 0 };
  if (items.length < 3) return best;

  let start = 0;
  for (let index = 2; index <= items.length; index += 1) {
    const continues =
      index < items.length &&
      items[index]!.code === items[index - 2]!.code &&
      items[index]!.code !== items[index - 1]!.code;

    if (!continues) {
      const length = index - start;
      // An alternation of length L requires at least 3 items and two distinct codes.
      const distinct = new Set([items[start]!.code, items[start + 1]?.code]).size === 2;
      if (length > best.length && length >= 3 && distinct) {
        best = { length, start };
      }
      start = index - 1;
    }
  }
  return best;
}

/* ------------------------------------------------------------------ */
/* Individual rules                                                   */
/* ------------------------------------------------------------------ */

export function evaluateSuspiciousSpeed(
  input: QualityEvaluationInput,
  thresholds: QualityThresholds,
  administered: number,
): QualityFinding | null {
  const duration = input.durationSeconds;
  if (duration === null || !Number.isFinite(duration) || administered === 0) return null;

  const minTotal = input.minDurationSeconds ?? thresholds.defaultMinDurationSeconds;
  const secondsPerQuestion = duration / administered;
  const belowTotal = duration < minTotal;
  const belowPerQuestion = secondsPerQuestion < thresholds.minSecondsPerQuestion;
  if (!belowTotal && !belowPerQuestion) return null;

  const reasons: string[] = [];
  if (belowTotal) reasons.push(`总用时 ${duration} 秒，低于最短时长 ${minTotal} 秒`);
  if (belowPerQuestion) {
    reasons.push(
      `平均每题 ${secondsPerQuestion.toFixed(1)} 秒，低于 ${thresholds.minSecondsPerQuestion} 秒`,
    );
  }

  return {
    code: 'SUSPICIOUS_SPEED',
    label: QUALITY_RULES.SUSPICIOUS_SPEED.label,
    severity: QUALITY_RULES.SUSPICIOUS_SPEED.defaultSeverity,
    scoreImpact: QUALITY_RULES.SUSPICIOUS_SPEED.scoreImpact,
    detail: `${reasons.join('；')}（共作答 ${administered} 题）。`,
    evidence: {
      duration_seconds: duration,
      min_duration_seconds: minTotal,
      seconds_per_question: Math.round(secondsPerQuestion * 100) / 100,
      administered,
    },
  };
}

export function evaluateLongString(
  items: ScaleItem[],
  thresholds: QualityThresholds,
): QualityFinding | null {
  const run = longestIdenticalRun(items);
  if (run.length < thresholds.longStringLength) return null;

  return {
    code: 'LONG_STRING',
    label: QUALITY_RULES.LONG_STRING.label,
    severity: QUALITY_RULES.LONG_STRING.defaultSeverity,
    scoreImpact: QUALITY_RULES.LONG_STRING.scoreImpact,
    detail: `在连续 ${run.length} 个量表条目上选择了相同选项（选项代码 ${run.code}）。`,
    evidence: {
      run_length: run.length,
      option_code: run.code,
      threshold: thresholds.longStringLength,
      scale_items: items.length,
    },
  };
}

export function evaluateHighMissing(
  administered: number,
  answered: number,
  thresholds: QualityThresholds,
): { finding: QualityFinding | null; missingRate: number | null } {
  if (administered === 0) return { finding: null, missingRate: null };
  const missingRate = (administered - answered) / administered;
  if (missingRate <= thresholds.maxMissingRate) return { finding: null, missingRate };

  return {
    missingRate,
    finding: {
      code: 'HIGH_MISSING',
      label: QUALITY_RULES.HIGH_MISSING.label,
      severity: QUALITY_RULES.HIGH_MISSING.defaultSeverity,
      scoreImpact: QUALITY_RULES.HIGH_MISSING.scoreImpact,
      detail: `展示 ${administered} 题，未作答 ${administered - answered} 题，缺失率 ${(missingRate * 100).toFixed(1)}%（阈值 ${(thresholds.maxMissingRate * 100).toFixed(0)}%）。`,
      evidence: {
        administered,
        answered,
        missing: administered - answered,
        missing_rate: Math.round(missingRate * 10000) / 10000,
        threshold: thresholds.maxMissingRate,
      },
    },
  };
}

export function evaluateMatrixStraightLine(
  questions: Question[],
  answers: AnswerMap,
  thresholds: QualityThresholds,
): QualityFinding | null {
  const flagged: { question_code: string; rows: number; option_code: string }[] = [];

  for (const question of sortQuestions(questions)) {
    if (question.question_type !== 'matrix') continue;
    if (!isQuestionVisible(question, answers)) continue;
    const answer = answers[question.question_code];
    if (isEmptyAnswer(answer)) continue;

    const map = (answer ?? {}) as Record<string, string>;
    const codes = Object.values(map).filter(
      (code) => code !== null && code !== undefined && String(code).trim() !== '',
    );
    if (codes.length < thresholds.matrixStraightLineMinRows) continue;

    const unique = new Set(codes.map(String));
    if (unique.size === 1) {
      flagged.push({
        question_code: question.question_code,
        rows: codes.length,
        option_code: String(codes[0]),
      });
    }
  }

  if (flagged.length === 0) return null;

  return {
    code: 'MATRIX_STRAIGHT_LINE',
    label: QUALITY_RULES.MATRIX_STRAIGHT_LINE.label,
    severity: QUALITY_RULES.MATRIX_STRAIGHT_LINE.defaultSeverity,
    scoreImpact: QUALITY_RULES.MATRIX_STRAIGHT_LINE.scoreImpact,
    detail: flagged
      .map((item) => `${item.question_code}（${item.rows} 行全部选择代码 ${item.option_code}）`)
      .join('、'),
    evidence: { questions: flagged, min_rows: thresholds.matrixStraightLineMinRows },
  };
}

export function evaluateAlternatingPattern(
  items: ScaleItem[],
  thresholds: QualityThresholds,
): QualityFinding | null {
  const run = longestAlternatingRun(items);
  if (run.length < thresholds.alternatingLength) return null;

  const codes = [items[run.start]?.code, items[run.start + 1]?.code];
  return {
    code: 'ALTERNATING_PATTERN',
    label: QUALITY_RULES.ALTERNATING_PATTERN.label,
    severity: QUALITY_RULES.ALTERNATING_PATTERN.defaultSeverity,
    scoreImpact: QUALITY_RULES.ALTERNATING_PATTERN.scoreImpact,
    detail: `检测到连续 ${run.length} 项 ${codes[0]}—${codes[1]} 交替作答。`,
    evidence: { run_length: run.length, codes, threshold: thresholds.alternatingLength },
  };
}

export function evaluateSubjectiveObjective(
  questions: Question[],
  answers: AnswerMap,
  pairing: KnowledgePairing,
  thresholds: QualityThresholds,
): QualityFinding | null {
  const subjective = questions.find((q) => q.variable_name === pairing.subjectiveVariable);
  const objectiveQuestions = questions.filter((q) => q.question_type === 'knowledge_test');
  if (!subjective || objectiveQuestions.length === 0) return null;

  const raw = answers[subjective.question_code];
  const subjectiveValue = typeof raw === 'number' ? raw : Number(String(raw ?? ''));
  if (!Number.isFinite(subjectiveValue)) return null;

  const accuracy = computeKnowledgeAccuracy(objectiveQuestions, answers);
  if (accuracy.answered === 0) return null;

  const claimsToKnow = subjectiveValue >= thresholds.subjectiveHighThreshold;
  const objectivelyLow = accuracy.total <= thresholds.objectiveLowThreshold;
  if (!claimsToKnow || !objectivelyLow) return null;

  return {
    code: 'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
    label: QUALITY_RULES.SUBJECTIVE_OBJECTIVE_DISCREPANCY.label,
    severity: QUALITY_RULES.SUBJECTIVE_OBJECTIVE_DISCREPANCY.defaultSeverity,
    scoreImpact: QUALITY_RULES.SUBJECTIVE_OBJECTIVE_DISCREPANCY.scoreImpact,
    detail:
      `自评了解程度 ${subjectiveValue}/5（${subjective.question_code}），` +
      `但客观知识题得分 ${accuracy.total}/${accuracy.maxScore}。`,
    evidence: {
      subjective_question: subjective.question_code,
      subjective_value: subjectiveValue,
      objective_total: accuracy.total,
      objective_max: accuracy.maxScore,
      objective_items: accuracy.items,
      subjective_threshold: thresholds.subjectiveHighThreshold,
      objective_threshold: thresholds.objectiveLowThreshold,
    },
  };
}

export function evaluateDuplicate(
  duplicateCount: number,
  answered: number,
  thresholds: QualityThresholds,
): QualityFinding | null {
  if (duplicateCount < 2) return null;
  if (answered < thresholds.duplicateMinAnswered) return null;

  return {
    code: 'DUPLICATE_SUBMISSION',
    label: QUALITY_RULES.DUPLICATE_SUBMISSION.label,
    severity: QUALITY_RULES.DUPLICATE_SUBMISSION.defaultSeverity,
    scoreImpact: QUALITY_RULES.DUPLICATE_SUBMISSION.scoreImpact,
    detail: `共 ${duplicateCount} 份样本的作答向量完全一致（每份作答 ${answered} 题）。`,
    evidence: { duplicate_count: duplicateCount, answered, min_answered: thresholds.duplicateMinAnswered },
  };
}

/* ------------------------------------------------------------------ */
/* Scoring                                                            */
/* ------------------------------------------------------------------ */

export function scoreFromFindings(findings: QualityFinding[]): number {
  const penalty = findings.reduce((sum, finding) => sum + finding.scoreImpact, 0);
  return Math.max(0, Math.min(100, Math.round((100 - penalty) * 100) / 100));
}

export function severityFromScore(score: number, findings: QualityFinding[]): QualitySeverity | 'clean' {
  if (findings.length === 0) return 'clean';
  if (findings.some((finding) => finding.severity === 'critical')) return 'critical';
  if (score < 60) return 'warning';
  return findings.some((f) => f.severity === 'warning') ? 'warning' : 'info';
}

/* ------------------------------------------------------------------ */
/* Full evaluation                                                    */
/* ------------------------------------------------------------------ */

export function evaluateQuality(input: QualityEvaluationInput): QualityEvaluationResult {
  const thresholds: QualityThresholds = { ...DEFAULT_QUALITY_THRESHOLDS, ...(input.thresholds ?? {}) };
  const questions = sortQuestions(input.questions);
  const administered = administeredQuestions(questions, input.answers);
  const answered = administered.filter(
    (question) => !isEmptyAnswer(input.answers[question.question_code]),
  );
  const items = scaleItemSequence(questions, input.answers);

  const findings: QualityFinding[] = [];
  const skipped: { code: QualityRuleCode; reason: string }[] = [];

  const speed = evaluateSuspiciousSpeed(input, thresholds, administered.length);
  if (speed) findings.push(speed);
  else if (input.durationSeconds === null) {
    skipped.push({ code: 'SUSPICIOUS_SPEED', reason: '会话尚未完成，没有作答时长' });
  }

  const longString = evaluateLongString(items, thresholds);
  if (longString) findings.push(longString);

  const matrix = evaluateMatrixStraightLine(questions, input.answers, thresholds);
  if (matrix) findings.push(matrix);

  const alternating = evaluateAlternatingPattern(items, thresholds);
  if (alternating) findings.push(alternating);

  const { finding: missing, missingRate } = evaluateHighMissing(
    administered.length,
    answered.length,
    thresholds,
  );
  if (missing) findings.push(missing);

  const pairing = input.pairing === undefined ? DEFAULT_KNOWLEDGE_PAIRING : input.pairing;
  if (pairing === null) {
    skipped.push({
      code: 'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
      reason: '该问卷未配置主观/客观知识变量对应关系',
    });
  } else {
    const discrepancy = evaluateSubjectiveObjective(questions, input.answers, pairing, thresholds);
    if (discrepancy) findings.push(discrepancy);
    else if (!questions.some((q) => q.variable_name === pairing.subjectiveVariable)) {
      skipped.push({
        code: 'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
        reason: `未找到变量 ${pairing.subjectiveVariable}`,
      });
    }
  }

  if (input.duplicateCount !== undefined) {
    const duplicate = evaluateDuplicate(input.duplicateCount, answered.length, thresholds);
    if (duplicate) findings.push(duplicate);
  } else {
    skipped.push({ code: 'DUPLICATE_SUBMISSION', reason: '未提供跨样本比对结果' });
  }

  findings.sort(
    (a, b) => QUALITY_RULE_ORDER.indexOf(a.code) - QUALITY_RULE_ORDER.indexOf(b.code),
  );

  const score = scoreFromFindings(findings);

  return {
    score,
    severity: severityFromScore(score, findings),
    findings,
    stats: {
      administered: administered.length,
      answered: answered.length,
      scale_items: items.length,
      missing_rate: missingRate === null ? null : Math.round(missingRate * 10000) / 10000,
      seconds_per_question:
        input.durationSeconds !== null && administered.length > 0
          ? Math.round((input.durationSeconds / administered.length) * 100) / 100
          : null,
    },
    skipped,
    engine_version: QUALITY_ENGINE_VERSION,
  };
}

/* ------------------------------------------------------------------ */
/* Signature for duplicate detection                                  */
/* ------------------------------------------------------------------ */

/**
 * Canonical signature of a respondent's answers.
 *
 * Built from the administered, answered questions in instrument order, so two
 * genuinely identical submissions hash the same while a differing answer count
 * or value does not. Arrays keep their order (a ranking answer is order-bearing).
 */
export function answerSignature(questions: Question[], answers: AnswerMap): string {
  const parts: string[] = [];
  for (const question of sortQuestions(questions)) {
    if (question.question_type === 'page_break') continue;
    const answer = answers[question.question_code];
    if (isEmptyAnswer(answer)) continue;
    parts.push(`${question.question_code}=${canonicalAnswer(answer)}`);
  }
  return parts.join('|');
}

function canonicalAnswer(answer: AnswerValue): string {
  if (Array.isArray(answer)) return `[${answer.map(String).join(',')}]`;
  if (answer && typeof answer === 'object') {
    const entries = Object.entries(answer as Record<string, string>)
      .filter(([, value]) => value !== null && value !== undefined && String(value).trim() !== '')
      .sort(([a], [b]) => a.localeCompare(b));
    return `{${entries.map(([key, value]) => `${key}:${String(value)}`).join(',')}}`;
  }
  return String(answer);
}

/* ------------------------------------------------------------------ */
/* Aggregation for the quality dashboard                              */
/* ------------------------------------------------------------------ */

export interface QualityDistributionBucket {
  label: string;
  min: number;
  max: number;
  count: number;
}

export const QUALITY_BANDS: readonly { label: string; min: number; max: number }[] = [
  { label: '90—100 未发现可疑模式', min: 90, max: 100 },
  { label: '70—89 存在轻微提示', min: 70, max: 89 },
  { label: '40—69 需要人工复核', min: 40, max: 69 },
  { label: '0—39 强烈建议复核', min: 0, max: 39 },
];

export function bucketQualityScores(scores: number[]): QualityDistributionBucket[] {
  return QUALITY_BANDS.map((band) => ({
    ...band,
    count: scores.filter((score) => score >= band.min && score <= band.max).length,
  }));
}
