/**
 * Research project API tests.
 *
 * Includes the data-isolation checks: a researcher must never be able to read,
 * modify or delete another researcher's project, and the API must not confirm
 * that the id exists.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { api, createProject, createTestContext, registerResearcher, type TestContext } from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

describe('研究模板', () => {
  test('GET /api/templates 返回 V4.0 模板元数据', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api<
      {
        key: string;
        version: string;
        question_count: number;
        section_count: number;
        default_project: { hypothesis_count: number; research_question_count: number };
      }[]
    >(ctx, 'GET', '/api/templates', { token: researcher.token });

    assert.equal(response.status, 200);
    assert.equal(response.data.length, 1);
    const template = response.data[0]!;
    assert.equal(template.key, 'family-edu-v4');
    assert.equal(template.version, 'V4.0');
    assert.equal(template.question_count, 58);
    assert.equal(template.section_count, 13);
    assert.equal(template.default_project.hypothesis_count, 8);
  });

  test('未登录无法读取模板', async () => {
    const response = await api(ctx, 'GET', '/api/templates');
    assert.equal(response.status, 401);
  });
});

describe('创建研究项目', () => {
  test('创建空白项目成功，且不包含题目', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api<{
      project: { id: string; title: string; status: string };
      questionnaire_id: string | null;
      seeded_questions: number;
    }>(ctx, 'POST', '/api/projects', {
      token: researcher.token,
      body: { title: '空白研究', target_sample_size: 300, template: null },
    });

    assert.equal(response.status, 201);
    assert.equal(response.data.project.title, '空白研究');
    assert.equal(response.data.project.status, 'draft');
    assert.equal(response.data.questionnaire_id, null);
    assert.equal(response.data.seeded_questions, 0);
  });

  test('使用 V4.0 模板创建项目会加载 58 道题', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api<{ questionnaire_id: string; seeded_questions: number }>(
      ctx,
      'POST',
      '/api/projects',
      {
        token: researcher.token,
        body: { title: '模板研究', target_sample_size: 1000, template: 'family-edu-v4' },
      },
    );

    assert.equal(response.status, 201);
    assert.equal(response.data.seeded_questions, 58);

    const instrument = await api<{ questions: unknown[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${response.data.questionnaire_id}`,
      { token: researcher.token },
    );
    assert.equal(instrument.data.questions.length, 58);
  });

  test('一键创建默认研究设计（含 H1—H8 与配额）', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api<{
      project: {
        title: string;
        hypotheses: { code: string; status: string }[];
        research_questions: string[];
        target_sample_size: number;
      };
      seeded_questions: number;
    }>(ctx, 'POST', '/api/projects/from-template', { token: researcher.token });

    assert.equal(response.status, 201);
    assert.equal(response.data.seeded_questions, 58);
    assert.equal(response.data.project.hypotheses.length, 8);
    assert.equal(response.data.project.hypotheses[0]?.code, 'H1');
    assert.equal(response.data.project.target_sample_size, 1000);
    assert.ok(response.data.project.research_questions.length >= 8);

    // 假设必须以"未检验"状态创建，不得预设结论。
    for (const hypothesis of response.data.project.hypotheses) {
      assert.equal(hypothesis.status, 'untested');
    }
  });

  test('拒绝空研究名称', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api(ctx, 'POST', '/api/projects', {
      token: researcher.token,
      body: { title: '   ' },
    });
    assert.equal(response.status, 400);
    assert.equal(response.error?.code, 'VALIDATION_ERROR');
  });

  test('拒绝非法的目标样本量', async () => {
    const researcher = await registerResearcher(ctx);
    for (const bad of [0, -10, 2.5, 'abc']) {
      const response = await api(ctx, 'POST', '/api/projects', {
        token: researcher.token,
        body: { title: '样本量测试', target_sample_size: bad },
      });
      assert.equal(response.status, 400, `样本量 ${String(bad)} 应被拒绝`);
    }
  });

  test('未知模板被拒绝并返回可用模板列表', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api<never>(ctx, 'POST', '/api/projects', {
      token: researcher.token,
      body: { title: '未知模板', template: 'no-such-template' },
    });
    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /未知的研究模板/);
    assert.deepEqual((response.error?.details as { available: string[] }).available, ['family-edu-v4']);
  });

  test('未登录不能创建项目', async () => {
    const response = await api(ctx, 'POST', '/api/projects', { body: { title: 'x' } });
    assert.equal(response.status, 401);
  });
});

describe('项目列表与检索', () => {
  test('只返回当前研究者的项目', async () => {
    const a = await registerResearcher(ctx);
    const b = await registerResearcher(ctx);
    await createProject(ctx, a.token, { title: 'A 的项目' });
    await createProject(ctx, b.token, { title: 'B 的项目' });

    const listA = await api<{ items: { title: string }[]; total: number }>(ctx, 'GET', '/api/projects', {
      token: a.token,
    });
    assert.ok(listA.data.items.some((p) => p.title === 'A 的项目'));
    assert.ok(!listA.data.items.some((p) => p.title === 'B 的项目'));
  });

  test('支持按标题检索', async () => {
    const researcher = await registerResearcher(ctx);
    await createProject(ctx, researcher.token, { title: '家庭教育公共服务需求研究' });
    await createProject(ctx, researcher.token, { title: '另一个完全不同的课题' });

    const response = await api<{ items: { title: string }[] }>(
      ctx,
      'GET',
      '/api/projects?search=公共服务',
      { token: researcher.token },
    );
    assert.equal(response.data.items.length, 1);
    assert.match(response.data.items[0]!.title, /公共服务/);
  });

  test('支持分页并返回总数', async () => {
    const researcher = await registerResearcher(ctx);
    for (let i = 0; i < 5; i += 1) {
      await createProject(ctx, researcher.token, { title: `分页项目 ${i}` });
    }
    const response = await api<{ items: unknown[]; total: number; limit: number; offset: number }>(
      ctx,
      'GET',
      '/api/projects?limit=2&offset=0',
      { token: researcher.token },
    );
    assert.equal(response.data.items.length, 2);
    assert.equal(response.data.total, 5);
    assert.equal(response.data.limit, 2);
  });

  test('按状态筛选', async () => {
    const researcher = await registerResearcher(ctx);
    await createProject(ctx, researcher.token, { title: '状态筛选项目' });
    const response = await api<{ items: { status: string }[] }>(
      ctx,
      'GET',
      '/api/projects?status=draft',
      { token: researcher.token },
    );
    assert.ok(response.data.items.every((p) => p.status === 'draft'));
  });

  test('非法状态值返回 400', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api(ctx, 'GET', '/api/projects?status=bogus', { token: researcher.token });
    assert.equal(response.status, 400);
  });
});

describe('项目详情与更新', () => {
  test('详情包含项目与其问卷列表', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '详情项目', template: 'family-edu-v4' });

    const response = await api<{ project: { title: string }; questionnaires: { id: string; version: string }[] }>(
      ctx,
      'GET',
      `/api/projects/${project.id}`,
      { token: researcher.token },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.project.title, '详情项目');
    assert.equal(response.data.questionnaires.length, 1);
    assert.equal(response.data.questionnaires[0]?.version, 'V4.0');
  });

  test('更新项目字段并写入 updated_at', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '待更新' });
    const before = await api<{ project: { updated_at: string } }>(
      ctx,
      'GET',
      `/api/projects/${project.id}`,
      { token: researcher.token },
    );

    const response = await api<{
      project: { title: string; status: string; hypotheses: unknown[]; updated_at: string };
    }>(
      ctx,
      'PATCH',
      `/api/projects/${project.id}`,
      {
        token: researcher.token,
        body: {
          title: '已更新标题',
          status: 'collecting',
          hypotheses: [{ code: 'H1', statement: '新假设', status: 'untested' }],
        },
      },
    );

    assert.equal(response.status, 200);
    assert.equal(response.data.project.title, '已更新标题');
    assert.equal(response.data.project.status, 'collecting');
    assert.equal(response.data.project.hypotheses.length, 1);
    assert.notEqual(response.data.project.updated_at, before.data.project.updated_at);
  });

  test('拒绝非法状态更新', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '状态校验' });
    const response = await api(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: researcher.token,
      body: { status: 'not-a-status' },
    });
    assert.equal(response.status, 400);
  });

  test('拒绝非法目标样本量更新', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '样本量校验' });
    const response = await api(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: researcher.token,
      body: { target_sample_size: -5 },
    });
    assert.equal(response.status, 400);
  });

  test('可以保存配额与设置（用于 PHASE 4 配额管理）', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '配额设置' });
    const response = await api<{
      project: {
        quota_config: { enabled: boolean; preserve_structure: boolean };
        settings: { anonymous: boolean };
      };
    }>(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: true,
          categories: [{ dimension: 'STAGE', category: '初中', target_n: 300 }],
        },
        settings: { anonymous: true, allow_partial: false, consent_text: '匿名自愿', min_duration_seconds: 90 },
      },
    });
    assert.equal(response.status, 200);
    assert.equal(response.data.project.quota_config.enabled, true);
    assert.equal(response.data.project.quota_config.preserve_structure, true);
    assert.equal(response.data.project.settings.anonymous, true);
  });
});

describe('数据隔离（研究者只能访问自己的数据）', () => {
  test('读取他人项目返回 404 而非 403（不泄露存在性）', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createProject(ctx, owner.token, { title: '私有项目' });

    const response = await api(ctx, 'GET', `/api/projects/${project.id}`, { token: intruder.token });
    assert.equal(response.status, 404);
    assert.equal(response.error?.code, 'NOT_FOUND');
  });

  test('无法修改他人项目', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createProject(ctx, owner.token, { title: '不可篡改' });

    const response = await api(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: intruder.token,
      body: { title: '已被篡改' },
    });
    assert.equal(response.status, 404);

    const check = await api<{ project: { title: string } }>(ctx, 'GET', `/api/projects/${project.id}`, {
      token: owner.token,
    });
    assert.equal(check.data.project.title, '不可篡改');
  });

  test('无法删除他人项目', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createProject(ctx, owner.token, { title: '不可删除' });

    const response = await api(ctx, 'DELETE', `/api/projects/${project.id}`, { token: intruder.token });
    assert.equal(response.status, 404);

    const stillThere = await api(ctx, 'GET', `/api/projects/${project.id}`, { token: owner.token });
    assert.equal(stillThere.status, 200);
  });

  test('无法读取他人项目下的问卷', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createProject(ctx, owner.token, { title: '私有问卷', template: 'family-edu-v4' });

    const response = await api(ctx, 'GET', `/api/questionnaires/${project.questionnaireId}`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });

  test('无法读取他人项目的 Dashboard', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createProject(ctx, owner.token, { title: '私有仪表盘' });

    const response = await api(ctx, 'GET', `/api/projects/${project.id}/dashboard`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });
});

describe('删除项目', () => {
  test('删除项目时级联删除问卷与题目，并返回影响范围', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, {
      title: '待删除',
      template: 'family-edu-v4',
    });

    const response = await api<{ deleted: boolean; questionnaires: number; respondents: number }>(
      ctx,
      'DELETE',
      `/api/projects/${project.id}`,
      { token: researcher.token },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.deleted, true);
    assert.equal(response.data.questionnaires, 1);
    assert.equal(response.data.respondents, 0);

    const after = await api(ctx, 'GET', `/api/projects/${project.id}`, { token: researcher.token });
    assert.equal(after.status, 404);

    const orphanQuestions = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) FROM questions WHERE questionnaire_id = ?', [
        project.questionnaireId,
      ]) ?? 0,
    );
    assert.equal(orphanQuestions, 0, '级联删除应同时清空题目');
  });

  test('删除不存在的项目返回 404', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api(ctx, 'DELETE', '/api/projects/00000000-0000-0000-0000-000000000000', {
      token: researcher.token,
    });
    assert.equal(response.status, 404);
  });
});
