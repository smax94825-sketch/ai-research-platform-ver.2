/**
 * Competition (entrepreneurship) insight routes — PHASE 9.
 *
 *   POST /api/projects/:projectId/competition/run     — build + persist the report
 *   GET  /api/projects/:projectId/competition/report  — latest persisted report
 *   GET  /api/projects/:projectId/competition/history — audit trail of every run
 *
 * The report is derived from the latest persisted analysis bundle rather than from
 * freshly computed statistics: a business claim must never be able to rest on a
 * number the researcher has not seen in the analysis console. When no bundle has
 * been run yet, `run` fails with a 400 explaining which button to press first.
 *
 * Conventions match the analysis router exactly: `{ data }` envelope, `requireAuth`,
 * `requireProject`, `asyncHandler`, Chinese messages, snake_case payloads.
 */

import { Router } from 'express';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../util/errors.js';
import {
  INSIGHT_BLOCK_TITLES,
  getLatestInsightReport,
  listInsightReports,
  runCompetitionAnalysis,
} from '../services/insight.service.js';

export interface InsightRouterContext {
  db: Db;
  config: Config;
}

export function createInsightRouter(ctx: InsightRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /**
   * Build the competition report from the latest analysis bundle and store it.
   *
   * Repeated runs append new rows instead of overwriting: two runs may differ
   * because more responses arrived in between, and an audit trail that erases the
   * earlier report would make that difference invisible.
   */
  router.post(
    '/:projectId/competition/run',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const stored = runCompetitionAnalysis(ctx.db, projectId, researcher.id);

      res.json({
        data: {
          available: true,
          report_id: stored.id,
          run_seq: stored.run_seq,
          created_at: stored.created_at,
          blocks_total: stored.blocks_total,
          blocks_available: stored.blocks_available,
          ...(stored.report ?? {}),
        },
      });
    }),
  );

  /** The most recently persisted report, or a clear signal that none exists. */
  router.get(
    '/:projectId/competition/report',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const stored = getLatestInsightReport(ctx.db, projectId, researcher.id);

      if (!stored || !stored.report) {
        res.json({
          data: {
            available: false,
            reason:
              '尚未生成创业洞察报告。请先运行「运行全部分析」得到统计结果包，' +
              '再执行「生成创业洞察」；创业洞察的所有数字都来自该结果包，不会独立计算。',
          },
        });
        return;
      }

      res.json({
        data: {
          available: true,
          report_id: stored.id,
          run_seq: stored.run_seq,
          created_at: stored.created_at,
          ...stored.report,
        },
      });
    }),
  );

  /** Audit trail: which engine produced each report, from which analysis run. */
  router.get(
    '/:projectId/competition/history',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const rows = listInsightReports(ctx.db, projectId, researcher.id);

      res.json({
        data: {
          blocks: INSIGHT_BLOCK_TITLES,
          items: rows.map((row) => ({
            id: row.id,
            run_seq: row.run_seq,
            engine_version: row.engine_version,
            analysis_engine_version: row.analysis_engine_version,
            analysis_generated_at: row.analysis_generated_at,
            sample_n: row.sample_n,
            blocks_total: row.blocks_total,
            blocks_available: row.blocks_available,
            questionnaire_id: row.questionnaire_id,
            created_by: row.created_by,
            created_at: row.created_at,
          })),
        },
      });
    }),
  );

  return router;
}
