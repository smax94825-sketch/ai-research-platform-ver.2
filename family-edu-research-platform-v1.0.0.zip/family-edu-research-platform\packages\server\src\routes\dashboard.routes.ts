/**
 * Dashboard route.
 *
 * GET /api/dashboard                 — portfolio view across all projects
 * GET /api/dashboard?project_id=...  — single-project research dashboard
 *
 * When `project_id` is supplied the ownership check runs before any
 * aggregation, so a researcher cannot read another researcher's sample counts.
 */

import { Router } from 'express';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import { getDashboardOverview } from '../services/dashboard.service.js';
import { requireProject } from '../services/project.service.js';
import { asyncHandler } from '../util/errors.js';

export interface DashboardRouterContext {
  db: Db;
  config: Config;
}

export function createDashboardRouter(ctx: DashboardRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  router.get(
    '/',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = typeof req.query['project_id'] === 'string' ? req.query['project_id'] : null;

      if (!projectId) {
        res.json({ data: getDashboardOverview(ctx.db, researcher.id) });
        return;
      }

      const project = requireProject(ctx.db, projectId, researcher.id);
      res.json({ data: getDashboardOverview(ctx.db, researcher.id, { project }) });
    }),
  );

  return router;
}
