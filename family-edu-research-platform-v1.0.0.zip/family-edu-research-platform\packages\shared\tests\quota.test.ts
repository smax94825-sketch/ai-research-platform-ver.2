/**
 * Quota and collection-recommendation tests (PHASE 4).
 *
 * The recommendation engine gives advice a researcher may act on, so the tests
 * focus on two things: the arithmetic must be right, and the advice must be
 * driven by the observed data rather than by a hardcoded script.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  buildQuotaRecommendations,
  computeQuotaProgress,
  diagnoseBalance,
  validateQuotaConfig,
  type QuotaCategory,
  type QuotaConfig,
} from '../src/index.js';

const CATEGORIES: QuotaCategory[] = [
  { dimension: 'STAGE', category: '学前（0—6岁）', target_n: 200 },
  { dimension: 'STAGE', category: '小学', target_n: 300 },
  { dimension: 'STAGE', category: '初中', target_n: 300 },
  { dimension: 'STAGE', category: '高中', target_n: 200 },
];

const ENABLED_CONFIG: QuotaConfig = {
  enabled: true,
  preserve_structure: true,
  categories: CATEGORIES,
};

/* ================================================================== */
/* Progress                                                           */
/* ================================================================== */

describe('配额进度计算', () => {
  test('逐类计算当前量与完成度', () => {
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 172,
      小学: 318,
      初中: 189,
      高中: 121,
    });

    assert.equal(summary.items.length, 4);
    const preschool = summary.items[0]!;
    assert.equal(preschool.current_n, 172);
    assert.equal(preschool.target_n, 200);
    assert.equal(preschool.percent, 86);
    assert.equal(preschool.remaining, 28);
    assert.equal(preschool.met, false);

    const primary = summary.items[1]!;
    assert.equal(primary.current_n, 318);
    assert.equal(primary.percent, 106);
    assert.equal(primary.met, true);
    assert.equal(primary.exceeded, true);
    assert.equal(primary.remaining, 0, '超额时剩余量应为 0 而非负数');
  });

  test('汇总总体完成度与达标分类数', () => {
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 172,
      小学: 318,
      初中: 189,
      高中: 121,
    });
    assert.equal(summary.total_target, 1000);
    assert.equal(summary.total_current, 800);
    assert.equal(summary.percent, 80);
    assert.equal(summary.met_categories, 1);
    assert.equal(summary.unmet_categories, 3);
  });

  test('缺口最大的分类排在最前', () => {
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 172,
      小学: 318,
      初中: 189,
      高中: 121,
    });
    // remaining: 初中 111, 高中 79, 学前 28；小学已达标故不进入缺口列表
    assert.deepEqual(
      summary.largest_shortfalls.map((item) => item.category),
      ['初中', '高中', '学前（0—6岁）'],
    );
    assert.equal(summary.largest_shortfalls[0]!.remaining, 111);
    assert.ok(
      !summary.largest_shortfalls.some((item) => item.category === '小学'),
      '已达标分类不应出现在缺口列表中',
    );
  });

  test('未出现的分类按 0 处理而不是报错', () => {
    const summary = computeQuotaProgress(CATEGORIES, {});
    assert.ok(summary.items.every((item) => item.current_n === 0));
    assert.equal(summary.percent, 0);
    assert.equal(summary.unmet_categories, 4);
  });

  test('无配额时完成度为 null 而非 0', () => {
    const summary = computeQuotaProgress([], {});
    assert.equal(summary.percent, null, '没有目标时不应声称 0% 完成');
    assert.equal(summary.total_target, 0);
  });
});

/* ================================================================== */
/* Balance                                                            */
/* ================================================================== */

describe('样本结构诊断', () => {
  test('结构均衡时不判定为失衡', () => {
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 200,
      小学: 300,
      初中: 300,
      高中: 200,
    });
    const balance = diagnoseBalance(summary);
    assert.equal(balance.imbalanced, false);
  });

  test('结构明显失衡时指出超出与不足的分类', () => {
    // 观测：学前 4.3%、小学 68.1%、初中 18.5%、高中 9.1%
    // 设计：学前 20%、小学 30%、初中 30%、高中 20%
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 20,
      小学: 320,
      初中: 87,
      高中: 43,
    });
    const balance = diagnoseBalance(summary);
    assert.equal(balance.imbalanced, true);
    assert.equal(balance.most_over?.category, '小学');
    assert.ok((balance.most_over?.deviation_pp ?? 0) > 20, `小学偏差应显著为正，实际 ${balance.most_over?.deviation_pp}`);
    assert.equal(balance.most_under?.category, '学前（0—6岁）');
    assert.ok(
      (balance.most_under?.deviation_pp ?? 0) < -10,
      `学前偏差应显著为负，实际 ${balance.most_under?.deviation_pp}`,
    );
  });

  test('用占比而非绝对数量判断，避免早期样本量小被误判', () => {
    // 只收了 4 份，但结构与设计一致
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 1,
      小学: 1,
      初中: 1,
      高中: 1,
    });
    const balance = diagnoseBalance(summary);
    assert.equal(balance.imbalanced, false, '结构一致即不应报失衡，即使总量远未达标');
  });

  test('无样本时不判定失衡', () => {
    const summary = computeQuotaProgress(CATEGORIES, {});
    assert.equal(diagnoseBalance(summary).imbalanced, false);
  });

  test('占比归一化到 100% 附近', () => {
    const summary = computeQuotaProgress(CATEGORIES, {
      '学前（0—6岁）': 172,
      小学: 318,
      初中: 189,
      高中: 121,
    });
    const total = Object.values(diagnoseBalance(summary).observed_share).reduce((a, b) => a + b, 0);
    assert.ok(Math.abs(total - 100) < 0.1, `占比合计应约为 100%，实际 ${total}`);
  });
});

/* ================================================================== */
/* Recommendations                                                    */
/* ================================================================== */

describe('动态收集建议', () => {
  function recommend(counts: Record<string, number>, config = ENABLED_CONFIG) {
    const summary = computeQuotaProgress(config.categories, counts);
    return {
      summary,
      recommendations: buildQuotaRecommendations({
        config,
        summary,
        balance: diagnoseBalance(summary),
        sourceCounts: [
          { source: 'wechat', total: 231, completed: 210 },
          { source: 'school', total: 96, completed: 90 },
        ],
        sourceLabels: { wechat: '微信', school: '学校' },
      }),
    };
  }

  test('分类不足时给出明确的继续收集建议', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 172, 小学: 318, 初中: 189, 高中: 121 });
    const shortfall = recommendations.find((item) => item.kind === 'quota_shortfall');
    assert.ok(shortfall, '应给出配额缺口建议');
    assert.match(shortfall.text, /高中/);
    assert.match(shortfall.text, /初中/);
    assert.match(shortfall.text, /建议继续收集/);
  });

  test('建议附带可核对的证据，而不只是结论', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 172, 小学: 318, 初中: 189, 高中: 121 });
    const shortfall = recommendations.find((item) => item.kind === 'quota_shortfall');
    assert.ok((shortfall?.evidence.length ?? 0) >= 2, '建议必须给出依据');
    assert.ok(
      shortfall!.evidence.some((line) => /172\/200/.test(line)),
      '证据应包含具体计数',
    );
  });

  test('结构失衡时建议优先补齐不足的分类', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 20, 小学: 320, 初中: 87, 高中: 43 });
    const structure = recommendations.find((item) => item.kind === 'structure');
    assert.ok(structure, '应给出结构失衡建议');
    assert.match(structure.text, /不均衡/);
    assert.match(structure.evidence.join('\n'), /观测占比/);
    assert.match(structure.evidence.join('\n'), /设计占比/);
  });

  test('开启「保持目标样本结构」时明确说明不会改动目标配额', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 20, 小学: 320, 初中: 87, 高中: 43 });
    const structure = recommendations.find((item) => item.kind === 'structure');
    assert.match(structure!.text, /保持目标样本结构/);
    assert.match(structure!.text, /不会调整目标配额/);
  });

  test('未开启保持结构时给出直接的调整取向', () => {
    const config: QuotaConfig = { ...ENABLED_CONFIG, preserve_structure: false };
    const { recommendations } = recommend({ '学前（0—6岁）': 20, 小学: 320, 初中: 87, 高中: 43 }, config);
    const structure = recommendations.find((item) => item.kind === 'structure');
    assert.ok(!/不会调整目标配额/.test(structure!.text));
    assert.match(structure!.text, /优先收集/);
  });

  test('渠道建议结合当前各渠道数据', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 172, 小学: 318, 初中: 189, 高中: 121 });
    const channel = recommendations.find((item) => item.kind === 'channel');
    assert.ok(channel, '应给出渠道投放建议');
    assert.match(channel.text, /下一阶段建议优先收集/);
    assert.match(channel.evidence.join('\n'), /微信 210\/231/, '证据应包含各渠道完成情况');
    assert.match(channel.evidence.join('\n'), /建议渠道/);
  });

  test('全部达标时提示继续收集可能改变样本结构', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 200, 小学: 300, 初中: 300, 高中: 200 });
    const saturated = recommendations.find((item) => item.kind === 'saturation');
    assert.ok(saturated, '达标后应给出饱和提示');
    assert.match(saturated.text, /均已达到目标配额/);
    assert.ok(!recommendations.some((item) => item.kind === 'quota_shortfall'));
  });

  test('未配置配额时不产生配额建议，并说明原因', () => {
    const summary = computeQuotaProgress([], {});
    const recommendations = buildQuotaRecommendations({
      config: null,
      summary,
      balance: diagnoseBalance(summary),
    });
    assert.equal(recommendations.length, 1);
    assert.equal(recommendations[0]?.kind, 'none');
    assert.match(recommendations[0]!.text, /未配置样本配额/);
  });

  test('配额已关闭时同样不产生配额建议', () => {
    const config: QuotaConfig = { ...ENABLED_CONFIG, enabled: false };
    const summary = computeQuotaProgress(config.categories, { 小学: 10 });
    const recommendations = buildQuotaRecommendations({
      config,
      summary,
      balance: diagnoseBalance(summary),
    });
    assert.equal(recommendations[0]?.kind, 'none');
  });

  test('尚无样本时如实说明依据不足', () => {
    const { recommendations } = recommend({});
    assert.equal(recommendations.length, 1);
    assert.equal(recommendations[0]?.kind, 'none');
    assert.match(recommendations[0]!.text, /尚未收到任何样本/);
  });

  test('完成度低于 50% 时缺口建议升级为严重', () => {
    const { recommendations } = recommend({ '学前（0—6岁）': 20, 小学: 30 });
    const shortfall = recommendations.find((item) => item.kind === 'quota_shortfall');
    assert.equal(shortfall?.severity, 'critical');
  });

  test('建议不包含任何编造的具体数字（全部可追溯到输入）', () => {
    const counts = { '学前（0—6岁）': 172, 小学: 318, 初中: 189, 高中: 121 };
    const sourceCounts = [
      { source: 'wechat', total: 231, completed: 210 },
      { source: 'school', total: 96, completed: 90 },
    ];
    const summary = computeQuotaProgress(ENABLED_CONFIG.categories, counts);
    const recommendations = buildQuotaRecommendations({
      config: ENABLED_CONFIG,
      summary,
      balance: diagnoseBalance(summary),
      sourceCounts,
      sourceLabels: { wechat: '微信', school: '学校' },
    });
    const allText = recommendations.map((item) => `${item.text}\n${item.evidence.join('\n')}`).join('\n');

    // Every "a/b" pair in the advice must trace back to an actual input:
    // a category count, a target, a source count, or a channel total.
    const traceable = new Set<string>();
    for (const item of summary.items) {
      traceable.add(`${item.current_n}/${item.target_n}`);
      traceable.add(`${item.current_n}`);
      traceable.add(`${item.target_n}`);
    }
    for (const source of sourceCounts) {
      traceable.add(`${source.completed}/${source.total}`);
      traceable.add(`${source.completed}`);
      traceable.add(`${source.total}`);
    }
    const totalTokens = new Set([
      `${summary.total_current}`,
      `${summary.total_target}`,
      `${summary.total_current}/${summary.total_target}`,
    ]);

    const pairs = allText.match(/\d+\/\d+/g) ?? [];
    assert.ok(pairs.length > 0, '建议应包含计数证据');
    for (const pair of pairs) {
      assert.ok(
        traceable.has(pair) || totalTokens.has(pair) || traceable.has(`${pair.split('/')[0]}/${pair.split('/')[1]}`),
        `建议中出现无法追溯的计数 ${pair}`,
      );
    }
  });
});

/* ================================================================== */
/* Validation                                                         */
/* ================================================================== */

describe('配额配置校验', () => {
  test('接受合法配置', () => {
    const result = validateQuotaConfig(ENABLED_CONFIG);
    assert.equal(result.valid, true);
    assert.deepEqual(result.errors, []);
  });

  test('允许 null（表示不设配额）', () => {
    assert.equal(validateQuotaConfig(null).valid, true);
    assert.equal(validateQuotaConfig(undefined).valid, true);
  });

  test('拒绝非对象配置', () => {
    assert.equal(validateQuotaConfig('nope').valid, false);
  });

  test('要求明确 enabled 与 preserve_structure', () => {
    const result = validateQuotaConfig({ categories: [] });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((error) => error.field === 'enabled'));
    assert.ok(result.errors.some((error) => error.field === 'preserve_structure'));
  });

  test('拒绝非正整数的目标数量', () => {
    for (const bad of [0, -5, 2.5]) {
      const result = validateQuotaConfig({
        enabled: true,
        preserve_structure: true,
        categories: [{ dimension: 'STAGE', category: '小学', target_n: bad }],
      });
      assert.equal(result.valid, false, `目标数量 ${bad} 应被拒绝`);
    }
  });

  test('拒绝同一维度下重复的分类', () => {
    const result = validateQuotaConfig({
      enabled: true,
      preserve_structure: true,
      categories: [
        { dimension: 'STAGE', category: '小学', target_n: 100 },
        { dimension: 'STAGE', category: '小学', target_n: 200 },
      ],
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((error) => /重复/.test(error.message)));
  });

  test('拒绝缺少维度或分类名称的条目', () => {
    const result = validateQuotaConfig({
      enabled: true,
      preserve_structure: true,
      categories: [{ dimension: '', category: '', target_n: 10 }],
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((error) => /维度/.test(error.message)));
    assert.ok(result.errors.some((error) => /分类名称/.test(error.message)));
  });

  test('启用配额但无分类时给出警告', () => {
    const result = validateQuotaConfig({ enabled: true, preserve_structure: true, categories: [] });
    assert.equal(result.valid, true);
    assert.ok(result.warnings.some((warning) => /没有任何分类/.test(warning.message)));
  });

  test('V4.0 模板的默认配额配置通过校验', () => {
    assert.equal(validateQuotaConfig(ENABLED_CONFIG).valid, true);
  });
});
