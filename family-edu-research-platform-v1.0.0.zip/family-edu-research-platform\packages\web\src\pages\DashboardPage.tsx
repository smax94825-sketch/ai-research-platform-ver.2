import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  EmptyState,
  LoadingBlock,
  Select,
  StatCard,
} from '../components/ui';
import {
  DataCompletenessNote,
  DistributionBarChart,
  LikertStack,
  QuotaProgressList,
} from '../components/DistributionChart';
import { api, ApiClientError, type DashboardOverview, type ProjectListResult } from '../lib/api';
import { formatDuration, formatNumber, formatPercent, projectStatusMeta } from '../lib/format';

export function DashboardPage(): ReactNode {
  const [searchParams, setSearchParams] = useSearchParams();
  const projectId = searchParams.get('project');

  const [projects, setProjects] = useState<ProjectListResult | null>(null);
  const [overview, setOverview] = useState<DashboardOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadProjects = useCallback(async () => {
    const result = await api.projects.list({ limit: 200 });
    setProjects(result);
    return result;
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function load(): Promise<void> {
      setLoading(true);
      setError(null);
      try {
        const list = await loadProjects();
        if (cancelled) return;

        // Default to the most recently updated project when none is selected.
        const target = projectId ?? list.items[0]?.id;
        const data = await api.dashboard.overview(target ?? undefined);
        if (cancelled) return;
        setOverview(data);
      } catch (err) {
        if (cancelled) return;
        setError(err instanceof ApiClientError ? err.message : '无法加载研究仪表盘。');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, [projectId, loadProjects]);

  const activeProjectId = useMemo(
    () => projectId ?? projects?.items[0]?.id ?? '',
    [projectId, projects],
  );

  if (loading) return <LoadingBlock label="正在汇总研究数据…" />;

  if (error) {
    return (
      <Alert tone="danger" title="加载失败">
        {error}
      </Alert>
    );
  }

  if (!projects || projects.items.length === 0) {
    return (
      <div className="space-y-6">
        <PageHeading />
        <EmptyState
          title="还没有研究项目"
          description="研究项目是数据收集、统计分析与报告生成的组织单位。您可以一键使用《家庭教育认知、实践与社会支持需求调查 V4.0》模板，自动载入完整研究设计与 58 道题目。"
          action={
            <Link to="/projects/new">
              <Button variant="primary">新建研究项目</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const sample = overview?.sample;
  const questionnaire = overview?.questionnaire;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <PageHeading />
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 text-sm text-ink-600">
            当前研究项目
            <Select
              className="min-w-56"
              value={activeProjectId}
              onChange={(event) => setSearchParams({ project: event.target.value })}
            >
              {projects.items.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </Select>
          </label>
          <Link to={`/projects/${activeProjectId}`}>
            <Button variant="secondary">项目详情</Button>
          </Link>
        </div>
      </div>

      {/* Project summary ------------------------------------------------ */}
      {overview?.project && (
        <Card>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-semibold text-ink-900">{overview.project.title}</h2>
                <Badge tone={projectStatusMeta(overview.project.status).tone}>
                  {projectStatusMeta(overview.project.status).label}
                </Badge>
              </div>
              {questionnaire && (
                <p className="mt-1 text-sm text-ink-500">
                  问卷版本 {questionnaire.version} · {questionnaire.question_count} 道题 ·{' '}
                  {questionnaire.status === 'published' ? '已发布' : '未发布'}
                </p>
              )}
            </div>
            <div className="text-right text-sm text-ink-500">
              <p>
                目标样本量：
                <span className="tabular-nums text-ink-800">
                  {formatNumber(overview.project.target_sample_size)}
                </span>
              </p>
              <p className="mt-1">统计时间：{new Date(overview.generated_at).toLocaleString('zh-CN')}</p>
            </div>
          </div>
        </Card>
      )}

      {!overview?.collection_started && (
        <Alert tone="info" title="该项目尚未收集到任何样本">
          下列指标将在收到第一份问卷后自动更新。系统不会生成任何模拟数据——所有数字都来自数据库中的真实作答。
          {questionnaire && (
            <div className="mt-2">
              <Link
                to={`/projects/${activeProjectId}/questionnaires/${questionnaire.id}/builder?tab=publish`}
                className="font-medium underline"
              >
                前往发布问卷，获取分享链接与二维码 →
              </Link>
            </div>
          )}
        </Alert>
      )}

      {/* Sample metrics ------------------------------------------------- */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-ink-700">样本概况</h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="研究项目数" value={formatNumber(overview?.projects.total ?? 0)} hint={`草稿 ${overview?.projects.draft ?? 0} · 收集中 ${overview?.projects.collecting ?? 0}`} />
          <StatCard label="总样本" value={formatNumber(sample?.total ?? 0)} hint={`今日新增 ${sample?.today_new ?? 0}`} />
          <StatCard label="有效样本" value={formatNumber(sample?.valid ?? 0)} tone="success" hint={`无效 ${sample?.invalid ?? 0} · 未评分 ${sample?.unscored ?? 0}`} />
          <StatCard
            label="有效率"
            value={formatPercent(sample?.valid_rate ?? null)}
            hint={sample && sample.valid_rate === null ? '暂无已完成样本' : '有效 / 已完成样本'}
          />
          <StatCard label="已完成问卷" value={formatNumber(sample?.completed ?? 0)} hint={`进行中 ${sample?.in_progress ?? 0} · 中途退出 ${sample?.abandoned ?? 0}`} />
          <StatCard
            label="问卷完成率"
            value={formatPercent(sample?.completion_rate ?? null)}
            hint={sample && sample.completion_rate === null ? '暂无样本' : '已完成 / 全部样本'}
          />
          <StatCard label="平均完成时间" value={formatDuration(sample?.average_duration_seconds ?? null)} hint="仅统计已完成样本" />
          <StatCard label="目标样本量" value={formatNumber(overview?.project?.target_sample_size ?? null)} hint="来自研究设计" />
        </div>
      </div>

      {/* Quota ---------------------------------------------------------- */}
      {overview && overview.quota_progress.length > 0 && (
        <Card>
          <CardHeader
            title="样本配额进度"
            description="按研究设计中的教育阶段配额实时统计。平台只提示偏差，不会自动改变目标样本结构。"
          />
          <QuotaProgressList progress={overview.quota_progress} />
          {overview.quota_alerts.length > 0 && (
            <div className="mt-4 space-y-2">
              {overview.quota_alerts.map((alert) => (
                <Alert key={alert} tone="warning">
                  {alert}
                </Alert>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Findings ------------------------------------------------------- */}
      {overview && overview.findings.length > 0 && (
        <Card>
          <CardHeader
            title="主要研究发现"
            description="以下均为事实层（FACT）陈述，可直接追溯到题目与样本量 n；不含解释性结论。"
          />
          <ul className="space-y-3">
            {overview.findings.map((finding, index) => (
              <li key={`${finding.source.question_code}-${index}`} className="rounded-md border border-ink-200 p-3">
                <p className="text-sm text-ink-800">{finding.text}</p>
                <p className="mt-1.5 font-mono text-xs text-ink-500">
                  Source: {finding.source.question_code} · n={finding.source.n} · Level 1 FACT
                </p>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Distributions -------------------------------------------------- */}
      {overview && overview.distributions.length > 0 && (
        <div>
          <h3 className="mb-3 text-sm font-semibold text-ink-700">核心变量分布</h3>
          <div className="grid gap-4 lg:grid-cols-2">
            {overview.distributions.map((distribution) => (
              <Card key={distribution.variable_name}>
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <span className="font-mono text-xs text-brand-700">{distribution.variable_name}</span>
                      <span className="text-sm font-medium text-ink-800">{distribution.question_code}</span>
                    </span>
                  }
                  description={distribution.label}
                />
                {distribution.kind === 'scale' && distribution.counts.length <= 6 ? (
                  <LikertStack distribution={distribution} />
                ) : (
                  <DistributionBarChart distribution={distribution} />
                )}
                <DataCompletenessNote distribution={distribution} />
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PageHeading(): ReactNode {
  return (
    <div>
      <h1 className="text-xl font-semibold text-ink-900">Research Dashboard</h1>
      <p className="mt-1 text-sm text-ink-500">
        样本质量、配额进度与核心变量的实时汇总，全部来自数据库真实作答。
      </p>
    </div>
  );
}
