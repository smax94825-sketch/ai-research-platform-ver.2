/**
 * Research project service.
 *
 * Every read and write is scoped by `researcher_id`. Data isolation is
 * enforced here, in one place, rather than being re-implemented per route —
 * a project belonging to another researcher is reported as 404 (not 403) so
 * the API does not confirm that someone else's project id exists.
 */

import {
  validateProjectInput,
  FAMILY_EDU_V4_TEMPLATE,
  type Hypothesis,
  type ProjectSettings,
  type ProjectStatus,
  type QuotaConfig,
  type ResearchProject,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { insertRow, updateRow } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import { toProject, type ProjectRow } from './mappers.js';
import { createQuestionnaireFromTemplate } from './questionnaire.service.js';

const PROJECT_STATUSES: readonly ProjectStatus[] = [
  'draft',
  'collecting',
  'paused',
  'analyzing',
  'completed',
  'archived',
];

/* ------------------------------------------------------------------ */
/* Reads                                                              */
/* ------------------------------------------------------------------ */

export interface ListProjectsOptions {
  status?: ProjectStatus;
  search?: string;
  limit?: number;
  offset?: number;
}

export interface ListProjectsResult {
  items: ResearchProject[];
  total: number;
  limit: number;
  offset: number;
}

export function listProjects(
  db: Db,
  researcherId: string,
  options: ListProjectsOptions = {},
): ListProjectsResult {
  const limit = Math.min(Math.max(options.limit ?? 50, 1), 200);
  const offset = Math.max(options.offset ?? 0, 0);

  const clauses = ['researcher_id = ?'];
  const params: unknown[] = [researcherId];

  if (options.status) {
    if (!PROJECT_STATUSES.includes(options.status)) {
      throw ApiError.validation(`未知的项目状态：${options.status}。`);
    }
    clauses.push('status = ?');
    params.push(options.status);
  }
  if (options.search && options.search.trim() !== '') {
    clauses.push('(title LIKE ? OR description LIKE ?)');
    const like = `%${options.search.trim()}%`;
    params.push(like, like);
  }

  const where = clauses.join(' AND ');
  const total = Number(
    db.scalar<number>(`SELECT COUNT(*) AS n FROM research_projects WHERE ${where}`, params) ?? 0,
  );
  const rows = db.all<ProjectRow>(
    `SELECT * FROM research_projects WHERE ${where} ORDER BY updated_at DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset],
  );

  return { items: rows.map(toProject), total, limit, offset };
}

/** Ownership-scoped lookup. Returns undefined when absent or not owned. */
export function findProjectForResearcher(
  db: Db,
  projectId: string,
  researcherId: string,
): ResearchProject | undefined {
  const row = db.get<ProjectRow>(
    'SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?',
    [projectId, researcherId],
  );
  return row ? toProject(row) : undefined;
}

export function requireProject(db: Db, projectId: string, researcherId: string): ResearchProject {
  const project = findProjectForResearcher(db, projectId, researcherId);
  if (!project) throw ApiError.notFound('研究项目不存在，或您没有访问权限。');
  return project;
}

/**
 * Unscoped lookup.
 *
 * ONLY for the public respondent API, where the questionnaire's share token is
 * the authorisation and there is no researcher session. Never use this in a
 * console route.
 */
export function findProjectById(db: Db, projectId: string): ResearchProject {
  const row = db.get<ProjectRow>('SELECT * FROM research_projects WHERE id = ?', [projectId]);
  if (!row) throw ApiError.notFound('研究项目不存在。');
  return toProject(row);
}

/* ------------------------------------------------------------------ */
/* Create                                                             */
/* ------------------------------------------------------------------ */

export interface CreateProjectInput {
  title: string;
  description?: string | null;
  background?: string | null;
  objectives?: string | null;
  research_questions?: string[];
  hypotheses?: Hypothesis[];
  target_population?: string | null;
  target_sample_size?: number | null;
  start_date?: string | null;
  end_date?: string | null;
  /** "blank" creates an empty instrument; a template key seeds questions. */
  template?: string | 'blank' | null;
}

export interface CreateProjectResult {
  project: ResearchProject;
  questionnaire_id: string | null;
  seeded_questions: number;
}

export function createProject(
  db: Db,
  researcherId: string,
  input: CreateProjectInput,
): CreateProjectResult {
  const validation = validateProjectInput(input);
  if (!validation.valid) {
    throw ApiError.validation(
      `研究项目信息校验失败，共 ${validation.errors.length} 处问题。`,
      validation.errors,
    );
  }

  const id = newId();
  const timestamp = nowIso();
  const useTemplate = input.template && input.template !== 'blank' ? input.template : null;

  /**
   * A template is a complete research design, not just a question list. When a
   * project is created from one, the design defaults (research questions,
   * hypotheses, target population and size, quota configuration and — critically
   * — the ethics/consent settings) come with it. Anything the caller supplied
   * explicitly still wins.
   */
  const templateDefaults =
    useTemplate === FAMILY_EDU_V4_TEMPLATE.key ? FAMILY_EDU_V4_TEMPLATE.project : null;

  const pick = <T>(explicit: T | undefined | null, fallback: T | undefined | null): T | null =>
    explicit === undefined || explicit === null ? (fallback ?? null) : explicit;

  let questionnaireId: string | null = null;
  let seededQuestions = 0;

  db.transaction(() => {
    insertRow(db, 'research_projects', {
      id,
      researcher_id: researcherId,
      title: input.title.trim(),
      description: pick(input.description, templateDefaults?.description),
      background: pick(input.background, templateDefaults?.background),
      objectives: pick(input.objectives, templateDefaults?.objectives),
      research_questions: JSON.stringify(
        pick(input.research_questions, templateDefaults?.research_questions) ?? [],
      ),
      hypotheses: JSON.stringify(pick(input.hypotheses, templateDefaults?.hypotheses) ?? []),
      target_population: pick(input.target_population, templateDefaults?.target_population),
      target_sample_size: pick(input.target_sample_size, templateDefaults?.target_sample_size),
      start_date: pick(input.start_date, templateDefaults?.start_date),
      end_date: pick(input.end_date, templateDefaults?.end_date),
      status: 'draft',
      quota_config: templateDefaults ? JSON.stringify(templateDefaults.quota_config) : null,
      settings: templateDefaults ? JSON.stringify(templateDefaults.settings) : null,
      created_at: timestamp,
      updated_at: timestamp,
    });

    if (useTemplate) {
      const questionnaire = createQuestionnaireFromTemplate(db, id, useTemplate);
      questionnaireId = questionnaire.id;
      seededQuestions = Number(
        db.scalar<number>('SELECT COUNT(*) AS n FROM questions WHERE questionnaire_id = ?', [
          questionnaire.id,
        ]) ?? 0,
      );
    }
  });

  const project = requireProject(db, id, researcherId);
  return { project, questionnaire_id: questionnaireId, seeded_questions: seededQuestions };
}

/**
 * Create a project pre-filled with the default research design (title,
 * background, objectives, research questions, H1—H8, quotas) AND the V4.0
 * questionnaire. This is the one-click "use template" path.
 */
export function createProjectFromDefaultTemplate(db: Db, researcherId: string): CreateProjectResult {
  const template = FAMILY_EDU_V4_TEMPLATE.project;
  return createProject(db, researcherId, {
    title: template.title,
    description: template.description,
    background: template.background,
    objectives: template.objectives,
    research_questions: template.research_questions,
    hypotheses: template.hypotheses,
    target_population: template.target_population,
    target_sample_size: template.target_sample_size,
    start_date: template.start_date,
    end_date: template.end_date,
    template: FAMILY_EDU_V4_TEMPLATE.key,
  });
}

/* ------------------------------------------------------------------ */
/* Update / delete                                                    */
/* ------------------------------------------------------------------ */

export interface ProjectPatch {
  title?: string;
  description?: string | null;
  background?: string | null;
  objectives?: string | null;
  research_questions?: string[];
  hypotheses?: Hypothesis[];
  target_population?: string | null;
  target_sample_size?: number | null;
  start_date?: string | null;
  end_date?: string | null;
  status?: ProjectStatus;
  quota_config?: QuotaConfig | null;
  settings?: ProjectSettings | null;
}

export function updateProject(
  db: Db,
  projectId: string,
  researcherId: string,
  patch: ProjectPatch,
): ResearchProject {
  requireProject(db, projectId, researcherId);

  if (patch.status !== undefined && !PROJECT_STATUSES.includes(patch.status)) {
    throw ApiError.validation(`未知的项目状态：${patch.status}。`);
  }
  if (patch.title !== undefined) {
    const check = validateProjectInput({ title: patch.title, target_sample_size: patch.target_sample_size });
    const titleErrors = check.errors.filter((e) => e.field === 'title');
    if (titleErrors.length > 0) throw ApiError.validation('研究名称不合法。', titleErrors);
  }
  if (patch.target_sample_size !== undefined && patch.target_sample_size !== null) {
    const check = validateProjectInput({ title: 'placeholder', target_sample_size: patch.target_sample_size });
    const sizeErrors = check.errors.filter((e) => e.field === 'target_sample_size');
    if (sizeErrors.length > 0) throw ApiError.validation('目标样本量不合法。', sizeErrors);
  }

  const update: Record<string, unknown> = { updated_at: nowIso() };
  const jsonFields = new Set(['research_questions', 'hypotheses', 'quota_config', 'settings']);

  for (const [key, value] of Object.entries(patch)) {
    if (value === undefined) continue;
    if (jsonFields.has(key)) {
      update[key] = value === null ? null : JSON.stringify(value);
    } else if (key === 'title' && typeof value === 'string') {
      update[key] = value.trim();
    } else {
      update[key] = value;
    }
  }

  updateRow(db, 'research_projects', update, { id: projectId, researcher_id: researcherId });
  return requireProject(db, projectId, researcherId);
}

export interface DeleteProjectResult {
  deleted: boolean;
  questionnaires: number;
  respondents: number;
}

/**
 * Delete a project. Cascades are declared in the schema, so questionnaires,
 * questions, respondents and responses go with it. The counts are returned so
 * the console can show the researcher exactly what was destroyed.
 */
export function deleteProject(db: Db, projectId: string, researcherId: string): DeleteProjectResult {
  requireProject(db, projectId, researcherId);

  const counts = db.transaction(() => {
    const questionnaires = Number(
      db.scalar<number>('SELECT COUNT(*) AS n FROM questionnaires WHERE project_id = ?', [projectId]) ?? 0,
    );
    const respondents = Number(
      db.scalar<number>('SELECT COUNT(*) AS n FROM respondents WHERE project_id = ?', [projectId]) ?? 0,
    );
    db.run('DELETE FROM research_projects WHERE id = ? AND researcher_id = ?', [projectId, researcherId]);
    return { questionnaires, respondents };
  });

  return { deleted: true, ...counts };
}
