/**
 * Authentication middleware.
 *
 * Verifies the Bearer token, reloads the researcher from the database and
 * checks the token version, so a token issued before a logout (or before a
 * password change) stops working immediately even though it has not expired.
 */

import type { NextFunction, Request, RequestHandler, Response } from 'express';
import type { Researcher } from '@ferp/shared';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { verifyJwt } from '../security/jwt.js';
import { toResearcher, type ResearcherRow } from '../services/mappers.js';
import { ApiError } from '../util/errors.js';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      /** Set by `requireAuth`; absent on public routes. */
      researcher?: Researcher;
    }
  }
}

export interface AuthContext {
  db: Db;
  config: Config;
}

function extractBearerToken(req: Request): string | null {
  const header = req.headers.authorization;
  if (typeof header !== 'string') return null;
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  return match ? match[1]!.trim() : null;
}

/** Resolve the researcher behind a request, or null when unauthenticated. */
export function resolveResearcher(ctx: AuthContext, req: Request): Researcher | null {
  const token = extractBearerToken(req);
  if (!token) return null;

  const result = verifyJwt(token, ctx.config.jwtSecret);
  if (!result.valid) return null;

  const row = ctx.db.get<ResearcherRow>('SELECT * FROM researchers WHERE id = ?', [result.payload.sub]);
  if (!row) return null;

  // Revocation check: a bumped token_version invalidates all older tokens.
  const tokenVersion = typeof result.payload.tv === 'number' ? result.payload.tv : 0;
  if (tokenVersion !== row.token_version) return null;

  return toResearcher(row);
}

/** Require a valid session; attaches `req.researcher`. */
export function requireAuth(ctx: AuthContext): RequestHandler {
  return (req: Request, _res: Response, next: NextFunction) => {
    const researcher = resolveResearcher(ctx, req);
    if (!researcher) {
      next(ApiError.unauthorized('登录状态无效或已过期，请重新登录。'));
      return;
    }
    req.researcher = researcher;
    next();
  };
}

/** Convenience accessor that fails loudly if the guard was forgotten. */
export function currentResearcher(req: Request): Researcher {
  if (!req.researcher) {
    throw ApiError.unauthorized('该路由需要登录，但未执行身份校验。');
  }
  return req.researcher;
}
