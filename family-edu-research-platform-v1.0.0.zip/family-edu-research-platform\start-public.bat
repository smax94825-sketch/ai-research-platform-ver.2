@echo off
rem ============================================================
rem  FERP public access launcher
rem  Starts: backend server (port 4000) + Cloudflare quick tunnel
rem  Double-click this file after reboot to restore public access.
rem
rem  BEFORE FIRST RUN — configure the environment:
rem    JWT_SECRET   REQUIRED. At least 32 characters. The server
rem                 refuses to start in production without it.
rem                 Never commit a real value to version control.
rem    FERP_NODE    Optional. Full path to node.exe.
rem                 Default: node resolved from PATH.
rem    FERP_CLOUDFLARED
rem                 Optional. Full path to cloudflared.exe.
rem                 Default: cloudflared resolved from PATH.
rem    CORS_ORIGINS Optional. Comma-separated allowed origins.
rem
rem  Paths are resolved relative to this script, so the folder can
rem  live anywhere.
rem ============================================================
setlocal
cd /d "%~dp0"

if "%JWT_SECRET%"=="" (
  echo ERROR: JWT_SECRET is not set.
  echo Set it to a random string of at least 32 characters, e.g.
  echo   set "JWT_SECRET=CHANGE_ME_TO_A_LONG_RANDOM_VALUE"
  echo or copy .env.example to .env and configure it there.
  echo.
  pause
  exit /b 1
)

set "NODE=%FERP_NODE%"
if "%NODE%"=="" set "NODE=node"
set "CLOUDFLARED=%FERP_CLOUDFLARED%"
if "%CLOUDFLARED%"=="" set "CLOUDFLARED=cloudflared"

if "%CORS_ORIGINS%"=="" set "CORS_ORIGINS=http://localhost:5173,http://127.0.0.1:5173"
set "NODE_ENV=production"
set "HOST=127.0.0.1"
set "PORT=4000"
if not exist "data" mkdir "data"

echo Starting backend server on port 4000 ...
start "ferp-api-4000" /min "%NODE%" "packages\server\dist\src\index.js"
timeout /t 2 /nobreak >nul

echo Starting Cloudflare tunnel ...
start "ferp-tunnel-4000" /min "%CLOUDFLARED%" tunnel --url http://127.0.0.1:4000 --no-autoupdate --logfile "data\tunnel-url.log"
timeout /t 10 /nobreak >nul

echo.
echo ================= PUBLIC URL =================
findstr /C:"trycloudflare.com" "data\tunnel-url.log"
echo =============================================
echo.
echo NOTE: the tunnel URL changes on every restart.
echo Append it to your deployed frontend link like this:
echo   https://YOUR-FRONTEND-URL/?api=TUNNEL_URL_FROM_ABOVE
echo (open data\tunnel-url.log if the URL above is not shown)
echo.
echo Keep this computer running. Closing these two minimized
echo windows will cut off public access.
echo.
pause
