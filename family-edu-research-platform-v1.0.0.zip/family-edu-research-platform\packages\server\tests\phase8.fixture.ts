/**
 * Shared fixture for the PHASE 8 API tests.
 *
 * Not a test file: `node --test "dist/tests/*.test.js"` never loads it. It exists
 * so the export and report test files collect their samples from *one* proven
 * instrument and data-generating process rather than two drifting copies.
 *
 * The instrument deliberately reuses the real V4.0 question codes. That is not
 * cosmetic: the analysis engine only materialises the derived construct
 * variables (FSE, DSD, UI, WTP …) and the scale definitions behind reliability
 * and validity when the questionnaire is recognised as template-derived, and
 * those variables are what the default correlation, regression and hypothesis
 * specifications refer to.
 *
 * Q32 is the real template's sensitive item ("不愿回答", option code 5, declared
 * with `sensitiveNonResponse: true`). One respondent per sample refuses it, which
 * is what makes the export tests able to prove that a refusal travels as a
 * *missing* value — an empty field — and never leaks the refusal label into the
 * data file.
 */

import {
  api,
  createPublishedQuestionnaire,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

/* ================================================================== */
/* Instrument                                                         */
/* ================================================================== */

const AGREE = [
  { value: '1', label: '非常不同意', score: 1 },
  { value: '2', label: '比较不同意', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较同意', score: 4 },
  { value: '5', label: '非常同意', score: 5 },
];

const MEAN_5 = { type: 'mean', min: 1, max: 5 };
const ORDINAL_5 = { type: 'ordinal', codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 } };

export const STAGES = ['学前（0—6岁）', '小学', '初中', '高中'];

/** The sensitive item: option 5 is an explicit refusal, not a substantive answer. */
export const SENSITIVE_QUESTION_CODE = 'Q32';
export const SENSITIVE_VARIABLE = 'FPB_PUNISH';
export const SENSITIVE_REFUSAL_LABEL = '不愿回答';

function likert(
  code: string,
  variable: string,
  dimension: string,
  rule: Record<string, unknown> = MEAN_5,
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'likert',
    required: true,
    dimension,
    variable_name: variable,
    options: { choices: AGREE, scaleMin: 1, scaleMax: 5 },
    scoring_rule: rule,
  };
}

/** A matrix question; each row becomes its own item variable. */
function matrix(
  code: string,
  variable: string,
  dimension: string,
  rowCount: number,
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'matrix',
    required: true,
    dimension,
    variable_name: variable,
    options: {
      matrix: {
        rows: Array.from({ length: rowCount }, (_, i) => ({
          value: String(i + 1),
          label: `方面${i + 1}`,
        })),
        columns: AGREE,
      },
      scaleMin: 1,
      scaleMax: 5,
    },
    scoring_rule: MEAN_5,
  };
}

const STAGE_QUESTION: Record<string, unknown> = {
  question_code: 'Q5',
  question_text: '孩子目前所处学段',
  question_type: 'single',
  required: true,
  dimension: '基本信息',
  variable_name: 'STAGE',
  options: { choices: STAGES.map((label, i) => ({ value: String(i + 1), label, score: i + 1 })) },
  scoring_rule: { type: 'categorical', codes: { '1': 1, '2': 2, '3': 3, '4': 4 } },
};

const SENSITIVE_QUESTION: Record<string, unknown> = {
  question_code: SENSITIVE_QUESTION_CODE,
  question_text: '过去12个月内，您是否曾因为孩子的行为问题而采取过身体上的惩罚？',
  question_type: 'single',
  required: false,
  dimension: '家庭教育实际行为',
  variable_name: SENSITIVE_VARIABLE,
  options: {
    choices: [
      { value: '1', label: '从未', score: 0 },
      { value: '2', label: '偶尔', score: 1 },
      { value: '3', label: '有时', score: 2 },
      { value: '4', label: '经常', score: 3 },
      { value: '5', label: SENSITIVE_REFUSAL_LABEL, sensitiveNonResponse: true },
    ],
  },
  scoring_rule: { type: 'ordinal', codes: { '1': 0, '2': 1, '3': 2, '4': 3, '5': null } },
};

const FSE_CODES = ['Q22', 'Q23', 'Q24', 'Q25', 'Q26', 'Q27', 'Q28', 'Q29', 'Q30'];

export const QUESTIONS: Record<string, unknown>[] = [
  STAGE_QUESTION,
  likert('Q6', 'FEI1', '家庭教育认知'),
  likert('Q7', 'FEI2', '家庭教育认知'),
  likert('Q8', 'FEI3', '家庭教育认知'),
  likert('Q9', 'FEK', '家庭教育认知'),
  likert('Q19', 'ISC1', '信息获取渠道'),
  likert('Q20', 'ISC2', '信息获取渠道'),
  ...FSE_CODES.map((code, i) => likert(code, `FSE${i + 1}`, '家庭教育自我效能')),
  likert('Q31', 'FPB1', '家庭教育实际行为'),
  SENSITIVE_QUESTION,
  likert('Q33', 'FPB2', '家庭教育实际行为'),
  likert('Q34', 'FPB3', '家庭教育实际行为'),
  matrix('Q35', 'FED', '家庭教育困难', 7),
  likert('Q43', 'PSA1', '政府家庭教育公共服务'),
  likert('Q44', 'PSA2', '政府家庭教育公共服务'),
  likert('Q45', 'PSU1', '政府家庭教育公共服务'),
  likert('Q46', 'PSU2', '政府家庭教育公共服务'),
  matrix('Q48', 'STI', '服务主体信任', 6),
  matrix('Q49', 'DSD', '数字化家庭教育服务需求', 6),
  likert('Q50', 'UI', 'AI家庭教育服务接受度', ORDINAL_5),
  matrix('Q51', 'PRC', 'AI服务风险认知', 5),
  likert('Q52', 'AIPV', 'AI家庭教育服务接受度'),
  likert('Q53', 'WTP', '家庭教育服务付费意愿', ORDINAL_5),
];

/* ================================================================== */
/* Data-generating process                                            */
/* ================================================================== */

/**
 * Linear congruential generator.
 *
 * A fixed seed keeps the synthetic sample identical on every run, so a failure
 * points at a code change rather than at sampling noise.
 */
function lcg(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

/** Standard normal via the Irwin–Hall approximation. */
function gaussian(rand: () => number): number {
  let sum = 0;
  for (let index = 0; index < 12; index += 1) sum += rand();
  return sum - 6;
}

function lk(value: number): number {
  return Math.min(5, Math.max(1, Math.round(value)));
}

function mean(values: number[]): number {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function matrixAnswer(values: number[]): Record<string, string> {
  const answer: Record<string, string> = {};
  values.forEach((value, index) => {
    answer[String(index + 1)] = String(value);
  });
  return answer;
}

/**
 * One synthetic respondent.
 *
 * Every construct is driven by a person-level trait plus item-level noise; that
 * structure is what gives the study's hypotheses real relationships to detect
 * (H2 efficacy → practice, H3 difficulty → digital demand, H5 trust → demand,
 * H7 risk → intention and H8 demand → willingness to pay). H6 (perceived value →
 * intention) is deliberately generated as a null, so the report has a genuine
 * "inconclusive" verdict to describe rather than only supported ones.
 *
 * `refuses` makes the respondent decline the sensitive Q32 item, which the
 * builder must turn into a missing value rather than a substantive category.
 */
function generateSample(rand: () => number, index: number, refuses: boolean): Record<string, unknown> {
  const stage = (index % STAGES.length) + 1;
  const g = (): number => gaussian(rand);

  const traitAbility = g();
  const traitDifficulty = g();
  const traitTrust = g();
  const traitRisk = g();
  const traitValue = g();
  const traitAccess = g();
  const traitDigital = g();

  const feiItems = [0, 1, 2].map(() => lk(3.2 + 0.3 * traitAbility + 0.5 * g()));
  const fek = lk(3.0 + 0.75 * traitAbility + 0.3 * g());
  const iscItems = [0, 1].map(() => lk(3.0 + 0.4 * g()));

  const fseItems = Array.from({ length: 9 }, () => lk(3.0 + 0.8 * traitAbility + 0.3 * g()));
  const fse = mean(fseItems);
  const fpbItems = [0, 1, 2].map(() => lk(0.9 + 0.6 * fse + 0.35 * g()));

  const fedRows = Array.from({ length: 7 }, () =>
    lk(1.7 + 0.35 * stage + 0.6 * traitDifficulty + 0.4 * g()),
  );
  const fed = mean(fedRows);

  const stiRows = Array.from({ length: 6 }, () => lk(2.9 + 0.75 * traitTrust + 0.45 * g()));
  const sti = mean(stiRows);

  const dsdRows = Array.from({ length: 6 }, () =>
    lk(1.3 + 0.28 * fed + 0.3 * sti + 0.5 * traitDigital + 0.4 * g()),
  );
  const dsd = mean(dsdRows);

  const psaItems = [0, 1].map(() => lk(2.9 - 0.18 * stage + 0.75 * traitAccess + 0.4 * g()));
  const psa = mean(psaItems);
  const psuItems = [0, 1].map(() => lk(1.0 + 0.6 * psa + 0.4 * g()));

  const prcRows = Array.from({ length: 5 }, () => lk(3.0 + 0.7 * traitRisk + 0.4 * g()));
  const prc = mean(prcRows);

  // traitValue shapes perceived value but deliberately does NOT enter intention.
  const aipv = lk(3.0 + 0.7 * traitValue + 0.4 * g());

  const ui = lk(3.0 + 0.4 * (sti - 3) - 0.4 * (prc - 3) + 0.5 * (dsd - 3) + 0.7 * g());
  const wtp = lk(0.6 + 0.5 * dsd + 0.35 * aipv + 0.4 * g());

  const answers: Record<string, unknown> = {
    Q5: String(stage),
    Q6: String(feiItems[0]!),
    Q7: String(feiItems[1]!),
    Q8: String(feiItems[2]!),
    Q9: String(fek),
    Q19: String(iscItems[0]!),
    Q20: String(iscItems[1]!),
    Q31: String(fpbItems[0]!),
    [SENSITIVE_QUESTION_CODE]: refuses ? '5' : String(lk(1 + 0.5 * traitDifficulty + g())),
    Q33: String(fpbItems[1]!),
    Q34: String(fpbItems[2]!),
    Q35: matrixAnswer(fedRows),
    Q43: String(psaItems[0]!),
    Q44: String(psaItems[1]!),
    Q45: String(psuItems[0]!),
    Q46: String(psuItems[1]!),
    Q48: matrixAnswer(stiRows),
    Q49: matrixAnswer(dsdRows),
    Q50: String(ui),
    Q51: matrixAnswer(prcRows),
    Q52: String(aipv),
    Q53: String(wtp),
  };

  FSE_CODES.forEach((code, position) => {
    answers[code] = String(fseItems[position]!);
  });

  return answers;
}

/* ================================================================== */
/* Collection                                                         */
/* ================================================================== */

export interface Phase8Sample {
  projectId: string;
  questionnaireId: string;
  shareToken: string;
  /** Every respondent created, in collection order. */
  respondents: string[];
  /** The completed respondent who declined the sensitive item. */
  sensitiveRespondentId: string;
  /** The completed respondent the researcher later excluded. */
  excludedRespondentId: string;
  /** Completed and not excluded — the analysis base. */
  analysable: number;
}

export interface CollectOptions {
  size: number;
  seed: number;
  title: string;
  /** Index of the respondent who refuses the sensitive item. */
  refusalIndex?: number;
  /** Index of the respondent who is excluded afterwards. */
  excludeIndex?: number;
}

/**
 * Collect a real sample through the public survey API and exclude one case.
 *
 * The exclusion is deliberate: it is the only way to prove that excluded samples
 * leave the analysis base *and* that their removal is reported, which is a
 * promise both the exports and the report make to the reader.
 */
export async function collectPhase8Sample(
  ctx: TestContext,
  token: string,
  options: CollectOptions,
): Promise<Phase8Sample> {
  const created = await createPublishedQuestionnaire(ctx, token, QUESTIONS, options.title);
  const rand = lcg(options.seed);
  const refusalIndex = options.refusalIndex ?? 3;
  const excludeIndex = options.excludeIndex ?? 0;

  const respondents: string[] = [];

  for (let index = 0; index < options.size; index += 1) {
    const answers = generateSample(rand, index, index === refusalIndex);
    const session = await startSession(ctx, created.shareToken, index % 3 === 0 ? 'wechat' : 'school');

    for (const [code, value] of Object.entries(answers)) {
      const saved = await saveAnswer(ctx, session.token, code, value);
      if (saved.status !== 200) {
        throw new Error(`保存 ${code} 失败：${saved.status} ${JSON.stringify(saved.error)}`);
      }
    }

    const submitted = await submitSession(ctx, session.token);
    if (submitted.status !== 200) {
      throw new Error(`提交失败：${submitted.status} ${JSON.stringify(submitted.error)}`);
    }
    respondents.push(session.respondentId);
  }

  const excluded = await api(ctx, 'POST', `/api/respondents/${respondents[excludeIndex]!}/review`, {
    token,
    body: { status: 'excluded', note: '作答时间异常的样本，已排除' },
  });
  if (excluded.status !== 200) {
    throw new Error(`排除样本失败：${excluded.status} ${JSON.stringify(excluded.error)}`);
  }

  return {
    projectId: created.projectId,
    questionnaireId: created.questionnaireId,
    shareToken: created.shareToken,
    respondents,
    sensitiveRespondentId: respondents[refusalIndex]!,
    excludedRespondentId: respondents[excludeIndex]!,
    analysable: options.size - 1,
  };
}

/** Run the full analysis and persist the bundle the exports and report read. */
export async function runAnalysis(ctx: TestContext, token: string, projectId: string): Promise<void> {
  const response = await api(ctx, 'POST', `/api/projects/${projectId}/analysis/run`, { token });
  if (response.status !== 200) {
    throw new Error(`运行全部分析失败：${response.status} ${JSON.stringify(response.error)}`);
  }
}
