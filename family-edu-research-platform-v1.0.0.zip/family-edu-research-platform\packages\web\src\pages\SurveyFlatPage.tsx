/**
 * Public respondent survey, single-page layout — `/research/:shareToken/all`.
 *
 * A paper-questionnaire rendering of the SAME instrument the step-by-step page
 * administers: the whole questionnaire on one scrollable page with a single
 * submit button at the bottom. It is an alternative *layout*, never a separate
 * pipeline — it resolves the instrument from the share token, keeps the
 * respondent session token under the key shared with `/research/:shareToken`,
 * autosaves through the same public API, and submits through the same
 * completion endpoint, so answers land in `respondents` / `responses` exactly as
 * the stepper's do. A respondent who switches layouts continues the same session.
 *
 * What deliberately differs from the stepper:
 *  - every visible question is rendered at once, grouped by the section the
 *    instrument declares, each numbered in questionnaire order;
 *  - validation therefore happens once, at submit, over all visible required
 *    questions (the stepper validates one question as it is left);
 *  - autosave batches every question typed inside one debounce window instead of
 *    holding a single pending answer.
 *
 * Everything else — consent gate, the shared logic engine, server-side
 * authority, error handling — mirrors `SurveyPage` on purpose: two layouts must
 * not become two rule sets.
 */

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import {
  isQuestionRequired,
  sortQuestions,
  type Question,
} from '@ferp/shared';
import { QuestionPreview, type AnswerValue } from '../components/QuestionPreview';
import { Alert, Button, Spinner } from '../components/ui';
import {
  ApiClientError,
  publicApi,
  type PublicInstrument,
  type PublicSessionState,
  type Respondent,
} from '../lib/api';
import { sessionStorageKey } from '../lib/surveySession';
import { isEmpty, querySuffix, visibleFrom } from './SurveyPage';

type Phase = 'loading' | 'closed' | 'invalid' | 'consent' | 'survey' | 'done';

/** Autosave debounce: long enough to batch fast typing, short enough to be safe. */
const AUTOSAVE_DELAY_MS = 500;

export function SurveyFlatPage(): ReactNode {
  const { shareToken = '' } = useParams();
  const [searchParams] = useSearchParams();
  const source = searchParams.get('source');

  const [phase, setPhase] = useState<Phase>('loading');
  const [instrument, setInstrument] = useState<PublicInstrument | null>(null);
  const [session, setSession] = useState<PublicSessionState | null>(null);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<string, AnswerValue>>({});
  const [error, setError] = useState<string | null>(null);
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  /** Autosave failure detail, kept apart from submit errors so a recovered save clears it. */
  const [saveError, setSaveError] = useState<string | null>(null);
  const [missingCodes, setMissingCodes] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [prunedNotice, setPrunedNotice] = useState<string[]>([]);
  /** Bumped by the retry button; re-runs the boot effect after a network failure. */
  const [bootAttempt, setBootAttempt] = useState(0);

  const saveTimerRef = useRef<number | null>(null);
  /**
   * Answers typed but not yet stored, keyed by question code so a respondent who
   * edits several questions inside one debounce window saves all of them.
   */
  const pendingRef = useRef<Map<string, unknown>>(new Map());

  /* ---------------------------------------------------------------- */
  /* Boot: load instrument, then try to resume an existing session      */
  /* ---------------------------------------------------------------- */

  useEffect(() => {
    let cancelled = false;

    async function boot(): Promise<void> {
      setPhase('loading');
      setError(null);

      try {
        const loaded = await publicApi.instrument(shareToken);
        if (cancelled) return;
        setInstrument(loaded);

        if (!loaded.accepting_responses) {
          setPhase('closed');
          return;
        }

        const stored = window.localStorage.getItem(sessionStorageKey(shareToken));
        if (stored) {
          try {
            const resumed = await publicApi.session(stored);
            if (cancelled) return;
            setSessionToken(stored);
            setSession(resumed);
            setAnswers(resumed.answers as Record<string, AnswerValue>);
            // A completed session must never be re-submitted by a refresh.
            setPhase(resumed.respondent.status === 'completed' ? 'done' : 'survey');
            return;
          } catch {
            // Stale or revoked session — fall through to consent.
            window.localStorage.removeItem(sessionStorageKey(shareToken));
          }
        }

        setPhase('consent');
      } catch (err) {
        if (cancelled) return;
        setError(
          err instanceof ApiClientError && err.status === 404
            ? '问卷链接无效或已被撤销，请向发放问卷的老师或研究者确认链接是否正确。'
            : err instanceof ApiClientError
              ? err.message
              : '无法加载问卷，请检查网络后重试。',
        );
        setPhase('invalid');
      }
    }

    void boot();
    return () => {
      cancelled = true;
    };
  }, [shareToken, bootAttempt]);

  /* ---------------------------------------------------------------- */
  /* Derived flow state — all driven by the shared logic engine         */
  /* ---------------------------------------------------------------- */

  const orderedQuestions = useMemo(
    () => (instrument ? sortQuestions(instrument.questions) : []),
    [instrument],
  );

  /** Questions on the current answer path (page breaks dropped, as in the stepper). */
  const visibleQuestions = useMemo(
    () => visibleFrom(orderedQuestions, answers),
    [orderedQuestions, answers],
  );

  const byCode = useMemo(
    () => new Map(orderedQuestions.map((question) => [question.question_code, question])),
    [orderedQuestions],
  );

  /** Sections in instrument order; questions keep the instrument's sequence. */
  const groups = useMemo(() => groupBySection(visibleQuestions), [visibleQuestions]);
  const hasSections = groups.some((group) => group.section !== null);

  /** 1-based position of each visible question, stable across layout changes. */
  const ordinals = useMemo(
    () => new Map(visibleQuestions.map((question, index) => [question.question_code, index + 1])),
    [visibleQuestions],
  );

  /** Progress counts visible questions only: hidden ones are not owed an answer. */
  const answeredVisible = visibleQuestions.filter(
    (question) => !isEmpty(answers[question.question_code]),
  ).length;

  /**
   * Missing required answers still outstanding.
   *
   * Recomputed on every render from the live answers, so a question the
   * respondent has just completed stops being reported (and one that logic has
   * just hidden stops being reported too).
   */
  const missingVisible = missingCodes.filter((code) => {
    const question = byCode.get(code);
    if (!question) return false;
    if (!visibleQuestions.some((item) => item.question_code === code)) return false;
    return isQuestionRequired(question, answers) && isEmpty(answers[code]);
  });

  /** Put the respondent in front of the first unanswered required question. */
  useEffect(() => {
    if (missingCodes.length === 0) return;
    const first = missingCodes[0];
    if (!first) return;
    focusQuestion(first);
  }, [missingCodes]);

  /* ---------------------------------------------------------------- */
  /* Autosave                                                          */
  /* ---------------------------------------------------------------- */

  const flushPending = useCallback(async (): Promise<void> => {
    if (pendingRef.current.size === 0 || !sessionToken) return;
    const queued = Array.from(pendingRef.current.entries());
    pendingRef.current.clear();
    setSaveState('saving');
    try {
      for (let index = 0; index < queued.length; index += 1) {
        const entry = queued[index];
        if (!entry) continue;
        const [code, value] = entry;
        try {
          const result = await publicApi.saveAnswer(sessionToken, code, value);
          if (result.pruned_question_codes.length > 0) {
            setPrunedNotice((current) =>
              Array.from(new Set([...current, ...result.pruned_question_codes])),
            );
            // Mirror the server's pruning so the local view stays truthful.
            setAnswers((current) => {
              const next = { ...current };
              for (const pruned of result.pruned_question_codes) delete next[pruned];
              return next;
            });
          }
        } catch (err) {
          // Re-queue this answer and everything after it so a later flush (or the
          // submit flush) retries them; a newer value typed meanwhile must win.
          for (const [pendingCode, pendingValue] of queued.slice(index)) {
            if (!pendingRef.current.has(pendingCode)) {
              pendingRef.current.set(pendingCode, pendingValue);
            }
          }
          throw err;
        }
      }
      setSaveState('saved');
      setSaveError(null);
    } catch (err) {
      setSaveState('error');
      setSaveError(err instanceof ApiClientError ? err.message : '自动保存失败，请检查网络后再试。');
    }
  }, [sessionToken]);

  const scheduleSave = useCallback(
    (code: string, value: unknown) => {
      pendingRef.current.set(code, value);
      if (saveTimerRef.current !== null) window.clearTimeout(saveTimerRef.current);
      saveTimerRef.current = window.setTimeout(() => {
        void flushPending();
      }, AUTOSAVE_DELAY_MS);
    },
    [flushPending],
  );

  // Flush any in-flight answer before the tab goes away or is backgrounded.
  useEffect(() => {
    function handleHide(): void {
      if (pendingRef.current.size > 0) void flushPending();
    }
    window.addEventListener('beforeunload', handleHide);
    window.addEventListener('pagehide', handleHide);
    window.addEventListener('visibilitychange', handleHide);
    return () => {
      window.removeEventListener('beforeunload', handleHide);
      window.removeEventListener('pagehide', handleHide);
      window.removeEventListener('visibilitychange', handleHide);
    };
  }, [flushPending]);

  useEffect(
    () => () => {
      if (saveTimerRef.current !== null) window.clearTimeout(saveTimerRef.current);
    },
    [],
  );

  /* ---------------------------------------------------------------- */
  /* Actions                                                           */
  /* ---------------------------------------------------------------- */

  async function beginSurvey(): Promise<void> {
    setError(null);
    try {
      const started = await publicApi.startSession(shareToken, source);
      window.localStorage.setItem(sessionStorageKey(shareToken), started.session_token);
      setSessionToken(started.session_token);
      setSession({
        respondent: started.respondent,
        answers: {},
        hidden_question_codes: [],
        missing_required: [],
      });
      setAnswers({});
      setMissingCodes([]);
      setPhase('survey');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法开始作答，请稍后重试。');
    }
  }

  function setAnswer(question: Question, value: AnswerValue): void {
    setAnswers((current) => {
      const next = { ...current };
      if (isEmpty(value)) delete next[question.question_code];
      else next[question.question_code] = value;
      return next;
    });
    scheduleSave(question.question_code, value);
  }

  async function submitAll(): Promise<void> {
    if (!sessionToken) return;
    setError(null);

    // Client-side gate over the whole page: report every missing required
    // question at once instead of one per screen. The server stays the authority.
    const missing = visibleQuestions
      .filter((question) => isQuestionRequired(question, answers))
      .filter((question) => isEmpty(answers[question.question_code]))
      .map((question) => question.question_code);

    if (missing.length > 0) {
      setMissingCodes(missing);
      return;
    }

    setMissingCodes([]);
    setSubmitting(true);
    try {
      // Never lose the last edit: submit flushes pending answers first.
      await flushPending();
      const result = await publicApi.complete(sessionToken);
      setSession((current) => (current ? { ...current, respondent: result.respondent } : current));
      setPhase('done');
      window.scrollTo({ top: 0 });
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 400) {
        // The server lists the exact unanswered required questions.
        setMissingCodes(
          err.fieldErrors
            .map((detail) => detail.field)
            .filter((field): field is string => typeof field === 'string' && field !== ''),
        );
        setError(err.message);
      } else {
        setError(
          err instanceof ApiClientError ? err.message : '提交失败，请检查网络后再试一次。',
        );
      }
    } finally {
      setSubmitting(false);
    }
  }

  /* ---------------------------------------------------------------- */
  /* Render                                                            */
  /* ---------------------------------------------------------------- */

  if (phase === 'loading') {
    return (
      <FlatShell>
        <div className="flex items-center justify-center gap-3 py-24 text-sm text-ink-500">
          <Spinner /> 正在加载问卷…
        </div>
      </FlatShell>
    );
  }

  if (phase === 'invalid' || phase === 'closed') {
    return (
      <FlatShell>
        <div className="rounded-xl border border-ink-200 bg-white p-8 text-center shadow-sm">
          <p className="text-lg font-semibold text-ink-900">
            {phase === 'closed' ? '本次调查已结束' : '无法打开问卷'}
          </p>
          <p className="mt-3 text-sm text-ink-600">{error ?? '感谢您的关注。'}</p>
          {phase === 'invalid' && (
            <Button variant="secondary" className="mt-6" onClick={() => setBootAttempt((n) => n + 1)}>
              重新加载
            </Button>
          )}
        </div>
      </FlatShell>
    );
  }

  if (phase === 'consent' && instrument) {
    return (
      <FlatShell>
        <div className="rounded-xl border border-ink-200 bg-white p-6 shadow-sm sm:p-8">
          <p className="text-xs font-medium uppercase tracking-wider text-brand-700">
            家庭教育调查 · {instrument.questionnaire.version}
          </p>
          <h1 className="mt-2 text-xl font-semibold leading-snug text-ink-900 sm:text-2xl">
            {instrument.questionnaire.title}
          </h1>
          {instrument.questionnaire.description && (
            <p className="mt-3 text-sm leading-relaxed text-ink-600">
              {instrument.questionnaire.description}
            </p>
          )}

          <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-lg bg-ink-50 px-3 py-2">
              <dt className="text-xs text-ink-500">题目数量</dt>
              <dd className="mt-0.5 font-semibold tabular-nums text-ink-900">
                {instrument.question_count} 题
              </dd>
            </div>
            <div className="rounded-lg bg-ink-50 px-3 py-2">
              <dt className="text-xs text-ink-500">答题方式</dt>
              <dd className="mt-0.5 font-semibold text-ink-900">整页问卷（一页答完）</dd>
            </div>
          </dl>

          <div className="mt-6 rounded-lg border border-brand-100 bg-brand-50 p-4">
            <h2 className="text-sm font-semibold text-brand-900">知情同意说明</h2>
            <p className="mt-2 text-sm leading-relaxed text-brand-900/90">{instrument.consent_text}</p>
            <ul className="mt-3 space-y-1.5">
              {instrument.ethics_points.map((point) => (
                <li key={point} className="flex gap-2 text-xs leading-relaxed text-brand-900/80">
                  <span aria-hidden="true">·</span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
            {instrument.consent_is_platform_default && (
              <p className="mt-3 text-[11px] text-brand-900/60">
                本说明为平台默认文本（研究者未填写自定义说明）。
              </p>
            )}
          </div>

          {error && (
            <div className="mt-4">
              <Alert tone="danger">{error}</Alert>
            </div>
          )}

          <Button
            variant="primary"
            className="mt-6 w-full py-3 text-base"
            onClick={() => void beginSurvey()}
          >
            我已了解，开始作答
          </Button>
          <p className="mt-3 text-center text-xs text-ink-400">
            开始时即记录您的知情同意时间。作答过程中可以随时退出。
          </p>
        </div>
      </FlatShell>
    );
  }

  if (phase === 'done') {
    const respondent: Respondent | null = session?.respondent ?? null;
    return (
      <FlatShell>
        <div className="rounded-xl border border-ink-200 bg-white p-8 text-center shadow-sm">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-50 text-2xl text-emerald-600">
            ✓
          </div>
          <h1 className="mt-4 text-xl font-semibold text-ink-900">提交成功，感谢您的参与</h1>
          <p className="mt-3 text-sm leading-relaxed text-ink-600">
            您的作答已匿名保存，仅用于研究统计，不会被单独识别。
          </p>
          {respondent && (
            <p className="mt-5 rounded-lg bg-ink-50 px-4 py-3 text-sm text-ink-700">
              您的匿名编号：
              <span className="ml-1 font-mono font-semibold text-ink-900">{respondent.anonymous_id}</span>
              <span className="mt-1 block text-xs text-ink-500">
                如需与研究方核对，可提供此编号；它不包含任何个人信息。
              </span>
            </p>
          )}
          <p className="mt-6 text-xs text-ink-400">您现在可以关闭此页面。</p>
        </div>
      </FlatShell>
    );
  }

  /* ---------------------------------------------------------------- */
  /* The single-page questionnaire                                     */
  /* ---------------------------------------------------------------- */

  const progressPercent =
    visibleQuestions.length > 0 ? Math.round((answeredVisible / visibleQuestions.length) * 100) : 0;
  const invalidCodes = new Set(missingVisible);
  const switchHref = `/research/${shareToken}${querySuffix(searchParams)}`;

  return (
    <FlatShell>
      <header className="mb-4 rounded-xl border border-ink-200 bg-white p-4 shadow-sm sm:p-5">
        <p className="text-xs font-medium uppercase tracking-wider text-brand-700">
          家庭教育调查 · {instrument?.questionnaire.version}
        </p>
        <h1 className="mt-1 text-lg font-semibold leading-snug text-ink-900 sm:text-xl">
          {instrument?.questionnaire.title}
        </h1>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-xs text-ink-500">
          <span className="tabular-nums">已答 {answeredVisible} / {visibleQuestions.length} 题</span>
          <SaveIndicator state={saveState} />
        </div>
        {saveError && <p className="mt-1 text-[11px] text-red-600">{saveError}</p>}
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink-200">
          <div
            className="h-full rounded-full bg-brand-600 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <p className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] text-ink-400">
          <Link to={switchHref} className="text-brand-700 underline underline-offset-2">
            切换为逐题模式（每题一屏）
          </Link>
          <span>全部题目显示在一页，可随时上下查看。</span>
        </p>
      </header>

      {prunedNotice.length > 0 && (
        <div className="mb-4">
          <Alert tone="info" title="已根据您修改的前置答案调整后续题目">
            因为您更改了前面的选择，以下题目在新路径下不再展示，其作答已自动清除：
            <span className="font-mono">{prunedNotice.join('、')}</span>。
          </Alert>
        </div>
      )}

      {visibleQuestions.length === 0 ? (
        <div className="rounded-xl border border-ink-200 bg-white p-8 text-center shadow-sm">
          <p className="text-sm text-ink-600">问卷没有需要作答的题目。</p>
        </div>
      ) : (
        <div>
          {groups.map((group, groupIndex) => (
            <section
              key={`${group.section ?? 'ungrouped'}-${groupIndex}`}
              className="mb-6"
              data-section={group.section ?? ''}
            >
              {hasSections && group.section && (
                <h2 className="mb-3 border-b border-ink-200 pb-1.5 text-sm font-semibold text-ink-800">
                  {group.section}
                </h2>
              )}
              <div className="space-y-4">
                {group.questions.map((question) => (
                  <article
                    key={question.question_code}
                    id={questionAnchorId(question.question_code)}
                    data-question-code={question.question_code}
                    className="scroll-mt-4"
                  >
                    {/* Sequence number for orientation; the code is rendered by
                        QuestionPreview so the researcher's reference stays visible. */}
                    <p className="mb-1 text-[11px] tabular-nums text-ink-400">
                      第 {ordinals.get(question.question_code) ?? 0} 题
                    </p>
                    <QuestionPreview
                      question={question}
                      value={answers[question.question_code] ?? null}
                      onChange={(value) => setAnswer(question, value)}
                      invalid={invalidCodes.has(question.question_code)}
                    />
                  </article>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      <div className="mt-6 rounded-xl border border-ink-200 bg-white p-4 shadow-sm sm:p-5">
        {missingVisible.length > 0 && (
          <div className="mb-3">
            <Alert tone="warning" title={`还有 ${missingVisible.length} 道必答题未作答`}>
              请完成以下必答题后再提交：
              <span className="font-mono">{missingVisible.join('、')}</span>。
            </Alert>
          </div>
        )}

        {error && (
          <div className="mb-3">
            <Alert tone="danger">{error}</Alert>
          </div>
        )}

        <Button
          variant="primary"
          loading={submitting}
          disabled={submitting}
          onClick={() => void submitAll()}
          className="w-full py-3 text-base"
        >
          提交问卷
        </Button>

        <p className="mt-3 text-center text-xs leading-relaxed text-ink-400">
          作答会自动保存，刷新或关闭页面后重新打开链接可以继续。
          <br />
          本研究为匿名调查，您可以拒绝回答任何问题。
        </p>
      </div>
    </FlatShell>
  );
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

/** Mobile-first centred column; wider than the stepper for a long single page. */
function FlatShell({ children }: { children: ReactNode }): ReactNode {
  return (
    <div className="min-h-screen bg-ink-50 px-4 py-6 sm:py-10">
      <div className="mx-auto w-full max-w-3xl">
        <p className="mb-4 text-center text-xs font-medium tracking-wide text-ink-400">
          家庭教育科研智能研究平台 · 匿名调查（整页问卷）
        </p>
        {children}
      </div>
    </div>
  );
}

function SaveIndicator({ state }: { state: 'idle' | 'saving' | 'saved' | 'error' }): ReactNode {
  if (state === 'saving') return <span className="text-ink-400">保存中…</span>;
  if (state === 'saved') return <span className="text-emerald-600">已自动保存</span>;
  if (state === 'error') return <span className="text-red-600">保存失败</span>;
  return <span />;
}

interface SectionGroup {
  /** Section label declared by the instrument, or null for an unlabelled run. */
  section: string | null;
  questions: Question[];
}

/**
 * Group questions into the sections the instrument declares, preserving order.
 *
 * A question without a section continues the preceding heading rather than
 * opening an invented one; when the instrument carries no sections at all the
 * result is a single unlabelled group, i.e. one continuous list. Grouping is by
 * consecutive run, so a questionnaire that revisits a section title does not
 * silently merge distant questions under one heading.
 */
function groupBySection(questions: Question[]): SectionGroup[] {
  const groups: SectionGroup[] = [];
  for (const question of questions) {
    const declared = question.section?.trim();
    const section = declared ? declared : null;
    const last = groups[groups.length - 1];
    if (last && (section === null || last.section === section)) {
      last.questions.push(question);
    } else {
      groups.push({ section, questions: [question] });
    }
  }
  return groups;
}

/** Stable DOM id used as the scroll/focus target for one question. */
function questionAnchorId(questionCode: string): string {
  return 'ferp-flat-question-' + questionCode;
}

/**
 * Scroll to a question and focus its first control.
 *
 * Best effort by design: the answer stays gated on submit even when the browser
 * offers no way to move the viewport, and jsdom implements no layout at all.
 */
function focusQuestion(questionCode: string): void {
  const element = document.getElementById(questionAnchorId(questionCode));
  if (!element) return;
  if (typeof element.scrollIntoView === 'function') {
    element.scrollIntoView({ block: 'center' });
  }
  const control = element.querySelector<HTMLElement>('input, textarea, select, button');
  control?.focus();
}
