/**
 * AI research assistant tests (PHASE 7).
 *
 * The AI layer is the only place on this platform where text nobody measured can
 * appear, so these tests check the four properties that keep it honest:
 *   1. the four levels render as separate groups with the API's own labels, and a
 *      FACT is not inside the RECOMMENDATION group,
 *   2. every statement shows the bundle path and the value it rests on,
 *   3. a rejected claim is shown as the guard working, quoting the offending
 *      number, and
 *   4. degraded mode is labelled as engine-derived — never as model output.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { click, flush, queryAll, render, text, typeInto } from './render';

const { AiAssistantPage } = await import('../src/pages/ai/AiAssistantPage');
const { formatDateTime } = await import('../src/lib/format');

/* ================================================================== */
/* Fixtures — shaped exactly like the AI API's responses              */
/* ================================================================== */

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育投入研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'analyzing',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

const STATUS_LIVE = {
  configured: true,
  mode: 'live',
  reason:
    '已配置 DeepSeek 接口（模型 deepseek-chat），AI 解释可用；所有解释均在统计结果包的基础上生成，并逐条校验数字来源。',
  model: 'deepseek-chat',
  base_url: 'https://api.deepseek.com/v1',
  timeout_ms: 60000,
  has_bundle: true,
  bundle_generated_at: '2026-02-01T09:30:00.000Z',
  latest_interaction_at: '2026-03-01T10:15:00.000Z',
  latest_mode: 'live',
};

const STATUS_UNCONFIGURED = {
  configured: false,
  mode: 'degraded',
  reason:
    '未配置 DEEPSEEK_API_KEY 环境变量，AI 解释功能不可用。平台不会伪造解释，而是返回由统计引擎直接生成的中文摘要（为结果包中的真实统计量）。',
  model: 'deepseek-chat',
  base_url: 'https://api.deepseek.com/v1',
  timeout_ms: 60000,
  has_bundle: true,
  bundle_generated_at: '2026-02-01T09:30:00.000Z',
  latest_interaction_at: null,
  latest_mode: null,
};

const STATUS_NO_BUNDLE = {
  ...STATUS_LIVE,
  has_bundle: false,
  bundle_generated_at: null,
};

const HYPOTHESES = {
  engine_version: '1.0.0',
  summary: { total: 1, supported: 1, not_supported: 0, inconclusive: 0, untestable: 0 },
  unavailable_variables: [],
  note: '假设检验采用双侧检验，显著性水平 α = 0.05。',
  results: [
    {
      code: 'H3',
      statement: '家庭教育困难与数字化服务需求呈正向关系。',
      verdict: 'supported',
      conclusion: '数据支持该假设。',
      direction: 'positive',
      method: 'Pearson 积矩相关',
      independent: 'FED',
      dependent: 'DSD',
      independent_label: '家庭教育困难',
      dependent_label: '数字化服务需求',
      r: 0.4123,
      p_value: 0.0032,
      n: 24,
      ci_lower: 0.21,
      ci_upper: 0.58,
      effect_size: null,
      observed_direction: 'positive',
      evidence: [],
      caveats: [],
    },
  ],
};

/** The claim the server refused, kept in one place: the audit row carries it too. */
const REJECTED_CLAIM = {
  text: '共有 87% 的家长表示愿意为服务付费。',
  code: 'untraceable_number',
  reason:
    '结果包中不存在数值 87%。AI 只能引用统计引擎计算过的数字，该数字无法溯源，因此包含它的整条陈述已被剔除。',
  quoted_number: 87,
  raw_number: '87%',
  level: 'STATISTICAL_FINDING',
};

const INTERPRETATION_LIVE = {
  mode: 'live',
  interaction_id: 'ai-1',
  generated_at: '2026-03-01T10:15:00.000Z',
  engine_version: '1.0.0',
  prompt_version: '1.0.0',
  prompt_hash: 'f1e2d3c4b5a69788796a5b4c3d2e1f00112233445566778899aabbccddeeff00',
  model: 'deepseek-chat',
  base_url: 'https://api.deepseek.com/v1',
  scope: { section: 'correlation', hypothesis_code: 'H3', focus: '服务需求量级' },
  bundle_generated_at: '2026-02-01T09:30:00.000Z',
  source_of_truth: 'analysis_bundle',
  layers: {
    facts: [
      {
        id: 'ai-st-1',
        level: 'FACT',
        text: '进入统计分析的有效样本为 350 份。',
        labelled_text: '【事实】进入统计分析的有效样本为 350 份。',
        evidence: [{ path: 'sample.analysable', value: 350, source: 'declared' }],
        label_inferred: false,
        hypothesis_code: null,
      },
    ],
    statistical_findings: [
      {
        id: 'ai-st-2',
        level: 'STATISTICAL_FINDING',
        text: 'FED 与 DSD 呈显著正相关（r = 0.4123, p = 0.0032, n = 24）。',
        labelled_text: '【统计发现】FED 与 DSD 呈显著正相关（r = 0.4123, p = 0.0032, n = 24）。',
        evidence: [
          { path: 'correlation.pairs[FED|DSD].r', value: 0.4123, source: 'declared' },
          { path: 'correlation.pairs[FED|DSD].p_value', value: 0.0032, source: 'declared' },
        ],
        label_inferred: false,
        hypothesis_code: 'H3',
      },
    ],
    interpretations: [
      {
        id: 'ai-st-3',
        level: 'INTERPRETATION',
        text: '该结果提示家庭教育困难越多，数字化服务需求可能越强。',
        labelled_text: '【解释】该结果提示家庭教育困难越多，数字化服务需求可能越强。',
        evidence: [{ path: 'correlation.pairs[FED|DSD].r', value: 0.4123, source: 'inferred' }],
        label_inferred: true,
        hypothesis_code: null,
      },
    ],
    recommendations: [
      {
        id: 'ai-st-4',
        level: 'RECOMMENDATION',
        text: '建议在服务设计上优先覆盖困难程度较高的家庭。',
        labelled_text: '【建议】建议在服务设计上优先覆盖困难程度较高的家庭。',
        evidence: [
          { path: 'correlation.pairs[FED|DSD].p_value', value: 0.0032, source: 'declared' },
        ],
        label_inferred: false,
        hypothesis_code: null,
      },
    ],
  },
  statement_count: 4,
  levels_used: ['FACT', 'STATISTICAL_FINDING', 'INTERPRETATION', 'RECOMMENDATION'],
  rejected_claims: [REJECTED_CLAIM],
  warnings: [
    '模型未完全遵守分层标签要求：1 条陈述缺少标签，已按措辞推断层级。层级推断仅供参考，请以证据留痕为准。',
  ],
  caveats: [
    '本研究采用横截面问卷调查数据，所有关联结论均为变量间的共变关系，不能据此推断因果关系。',
    '分析基于 350 份已完成且未被排除的样本。',
  ],
  truncated: false,
  ai_unavailable: null,
  engine_summary: null,
  usage: { prompt_tokens: 4821, completion_tokens: 712, total_tokens: 5533 },
  notice:
    '本结果分为四层：FACT 直接抄自统计结果包；STATISTICAL_FINDING 为统计引擎计算的统计量；' +
    'INTERPRETATION 与 RECOMMENDATION 由 AI 生成。所有被引用的数字都已逐一对结果包校验，' +
    '无法溯源的数字会使整条陈述被剔除，并记录在 rejected_claims 中。',
};

const INTERPRETATION_DEGRADED = {
  ...INTERPRETATION_LIVE,
  mode: 'degraded',
  prompt_hash: null,
  scope: { section: null, hypothesis_code: null, focus: null },
  layers: {
    facts: [
      {
        id: 'engine-st-1',
        level: 'FACT',
        text: '已完成作答 400 份样本，其中被研究者人工排除 50 份，进入统计分析的有效样本为 350 份。',
        labelled_text:
          '【事实】已完成作答 400 份样本，其中被研究者人工排除 50 份，进入统计分析的有效样本为 350 份。',
        evidence: [
          { path: 'sample.completed', value: 400, source: 'declared' },
          { path: 'sample.excluded', value: 50, source: 'declared' },
          { path: 'sample.analysable', value: 350, source: 'declared' },
        ],
        label_inferred: false,
        hypothesis_code: null,
      },
    ],
    statistical_findings: [
      {
        id: 'engine-st-2',
        level: 'STATISTICAL_FINDING',
        text: '在本次分析的变量组合中，没有出现达到显著性水平的成对相关；未达显著不等于证明两者无关。',
        labelled_text:
          '【统计发现】在本次分析的变量组合中，没有出现达到显著性水平的成对相关；未达显著不等于证明两者无关。',
        // An absence has no value to cite — the engine summary says so instead of
        // inventing a citation.
        evidence: [],
        label_inferred: false,
        hypothesis_code: null,
      },
      {
        id: 'engine-st-4',
        level: 'STATISTICAL_FINDING',
        text: 'FED 与 DSD 呈显著相关（Pearson 积差相关）：r = 0.4123，p = 0.0032，n = 24。',
        labelled_text:
          '【统计发现】FED 与 DSD 呈显著相关（Pearson 积差相关）：r = 0.4123，p = 0.0032，n = 24。',
        evidence: [{ path: 'correlation.pairs[FED|DSD].r', value: 0.4123, source: 'declared' }],
        label_inferred: false,
        hypothesis_code: null,
      },
    ],
    interpretations: [],
    recommendations: [],
  },
  statement_count: 3,
  levels_used: ['FACT', 'STATISTICAL_FINDING'],
  rejected_claims: [],
  warnings: [],
  truncated: false,
  ai_unavailable: {
    code: 'missing_api_key',
    message: '未配置 DEEPSEEK_API_KEY，AI 解释不可用；已返回由统计引擎直接生成的中文摘要。',
    provider_status: null,
  },
  engine_summary: {
    derived_by: 'statistical_engine',
    ai_generated: false,
    headline: '以下内容由统计引擎直接依据统计结果包生成，未经任何生成式模型改写。',
    text: '【事实】已完成作答 400 份样本……\n【统计发现】FED 与 DSD 呈显著相关……',
    statement_count: 3,
    sections: [
      {
        title: '一、样本情况',
        lines: ['已完成作答 400 份样本，其中被研究者人工排除 50 份，进入统计分析的有效样本为 350 份。'],
      },
      {
        title: '四、显著相关（含效应量）',
        lines: ['在本次分析的变量组合中，没有出现达到显著性水平的成对相关；未达显著不等于证明两者无关。'],
      },
    ],
  },
  usage: null,
  notice:
    'AI 解释当前不可用，因此没有生成任何解释或建议。以下内容全部由统计引擎依据统计结果包直接生成' +
    '（engine_summary.ai_generated = false），不含生成式模型的推断，也未引入结果包之外的任何数字。\n' +
    '未配置 DEEPSEEK_API_KEY，AI 解释不可用；已返回由统计引擎直接生成的中文摘要。',
};

const HISTORY = [
  {
    id: 'ai-2',
    mode: 'live',
    model: 'deepseek-chat',
    engine_version: '1.0.0',
    prompt_hash: 'aa11bb22cc33dd44ee55ff6677889900aa11bb22cc33dd44ee55ff6677889900',
    prompt_version: '1.0.0',
    prompt_tokens: 4821,
    completion_tokens: 712,
    total_tokens: 5533,
    duration_ms: 8210,
    scope: { section: 'correlation', hypothesis_code: 'H3', focus: null },
    statement_count: 4,
    rejected_claims: [REJECTED_CLAIM],
    rejected_claim_count: 1,
    error_code: null,
    error_message: null,
    raw_response: null,
    result: null,
    researcher_id: 'r-1',
    created_at: '2026-03-01T10:15:00.000Z',
  },
  {
    id: 'ai-1',
    mode: 'degraded',
    model: 'deepseek-chat',
    engine_version: '1.0.0',
    prompt_hash: '',
    prompt_version: '1.0.0',
    prompt_tokens: null,
    completion_tokens: null,
    total_tokens: null,
    duration_ms: null,
    scope: { section: null, hypothesis_code: null, focus: null },
    statement_count: 0,
    rejected_claims: [],
    rejected_claim_count: 0,
    error_code: 'missing_api_key',
    error_message: '未配置 DEEPSEEK_API_KEY，AI 解释不可用；已返回由统计引擎直接生成的中文摘要。',
    raw_response: null,
    result: null,
    researcher_id: 'r-1',
    created_at: '2026-02-28T18:02:00.000Z',
  },
];

interface StubOverrides {
  status?: unknown;
  interpretation?: unknown;
  history?: unknown;
}

function stubAiApi(overrides: StubOverrides = {}) {
  return stubFetch((call: FetchCall) => {
    const url = call.url;
    if (url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
    if (url.includes('/ai/status')) return jsonResponse({ data: overrides.status ?? STATUS_LIVE });
    if (url.includes('/ai/interpret')) {
      return jsonResponse({ data: overrides.interpretation ?? INTERPRETATION_LIVE });
    }
    if (url.includes('/ai/history')) return jsonResponse({ data: overrides.history ?? HISTORY });
    if (url.includes('/analysis/hypotheses')) return jsonResponse({ data: HYPOTHESES });
    return jsonResponse({ data: null });
  });
}

function sectionFor(label: string): Element {
  const found = queryAll('section').find((element) => (element.textContent ?? '').includes(label));
  assert.ok(found, `未找到「${label}」分组`);
  return found!;
}

/** The page loads status, history and the hypothesis list in one pass. */
async function settle(): Promise<void> {
  await flush();
  await flush();
  await flush();
}

async function renderPage(): Promise<void> {
  await render(createElement(MemoryRouter, null, createElement(AiAssistantPage)));
  await settle();
}

async function generate(): Promise<void> {
  const button = queryAll('button').find((element) =>
    (element.textContent ?? '').includes('生成 AI 解释'),
  );
  assert.ok(button, '应有「生成 AI 解释」按钮');
  await click(button!);
  await settle();
}

beforeEach(() => {
  clearContainer();
  window.localStorage.clear();
});

after(() => {
  // The suite shares one process and one jsdom: leave no token behind.
  window.localStorage.clear();
  closeDom();
});

/* ================================================================== */
/* Layers and evidence                                                */
/* ================================================================== */

describe('AI 解释页', () => {
  test('四层各自成组、使用接口给出的层级标签，且事实与建议不混在一起', async () => {
    const stub = stubAiApi();
    try {
      await renderPage();
      assert.match(text(), /已配置 DeepSeek 接口/, '状态说明应显示服务端返回的原因');

      await generate();

      const content = text();
      // Every level has its own heading, with the label the API itself uses.
      assert.match(content, /事实/);
      assert.match(content, /统计发现/);
      assert.match(content, /解释/);
      assert.match(content, /建议/);

      const factSection = sectionFor('事实');
      const findingSection = sectionFor('统计发现');
      const recommendationSection = sectionFor('建议');

      assert.ok(
        (factSection.textContent ?? '').includes('进入统计分析的有效样本为 350 份'),
        '事实层的陈述应在事实分组内',
      );
      assert.ok(
        !(recommendationSection.textContent ?? '').includes('进入统计分析的有效样本为 350 份'),
        '事实不得落入建议分组',
      );
      assert.ok(
        (recommendationSection.textContent ?? '').includes('建议在服务设计上优先覆盖困难程度较高的家庭'),
        '建议层的陈述应在建议分组内',
      );
      assert.ok(
        !(factSection.textContent ?? '').includes('建议在服务设计上优先覆盖困难程度较高的家庭'),
        '建议不得落入事实分组',
      );
      assert.ok(
        (findingSection.textContent ?? '').includes('FED 与 DSD 呈显著正相关'),
        '统计发现层的陈述应在统计发现分组内',
      );

      // The four groups must be visually distinguishable, not four identical boxes.
      assert.notEqual(
        factSection.getAttribute('class'),
        recommendationSection.getAttribute('class'),
        '事实与建议的样式必须不同，读者不能只靠文字判断层级',
      );
      assert.notEqual(findingSection.getAttribute('class'), recommendationSection.getAttribute('class'));
    } finally {
      stub.restore();
    }
  });

  test('每条陈述显示证据路径与数值，并标出层级推断与假设归属', async () => {
    const stub = stubAiApi();
    try {
      await renderPage();
      await generate();

      const content = text();
      assert.ok(
        content.includes('correlation.pairs[FED|DSD].r'),
        `应显示证据路径：${content.slice(0, 400)}`,
      );
      assert.ok(content.includes('0.4123'), '应显示证据路径上的数值');
      assert.ok(content.includes('sample.analysable'), '应显示样本量的证据路径');
      assert.ok(content.includes('350'), '应显示证据数值 350');
      assert.match(content, /模型声明的引用/);
      assert.match(content, /由正文中可溯源的数值推定/);
      assert.match(content, /模型未标注层级，按措辞推断/, '层级是推断出来的必须标出');
      assert.match(content, /假设 H3/, '应显示陈述归属的假设');
      assert.match(content, /证据留痕（可在分析页逐条核对）/);
    } finally {
      stub.restore();
    }
  });

  test('rejected_claims 非空时给出中文说明与被剔除的数字', async () => {
    const stub = stubAiApi();
    try {
      await renderPage();
      await generate();

      const content = text();
      assert.match(content, /已剔除 1 条无法溯源的模型陈述/);
      assert.match(content, /无法在统计结果包中溯源/);
      assert.match(content, /这些数字没有出现在上方的任何一层结论中/);
      assert.match(content, /这是平台的溯源保护在按设计工作，不是系统故障/);
      assert.ok(content.includes('87%'), '应原样引用模型写下的数字（含单位）');
      assert.match(content, /数字无法在结果包中溯源/);
      assert.match(content, /共有 87% 的家长表示愿意为服务付费/);
      assert.ok(
        !sectionFor('统计发现').textContent?.includes('共有 87% 的家长表示愿意为服务付费'),
        '被剔除的陈述不得出现在任何一层结论中',
      );
    } finally {
      stub.restore();
    }
  });

  test('展示用量、提示词哈希与结果包限制', async () => {
    const stub = stubAiApi();
    try {
      await renderPage();
      await generate();

      const content = text();
      assert.match(content, /提示 4,821 · 输出 712 · 合计 5,533/, '应显示 token 用量');
      assert.ok(
        content.includes('f1e2d3c4b5a69788796a5b4c3d2e1f00112233445566778899aabbccddeeff00'),
        '应显示提示词哈希以便审计',
      );
      assert.match(content, /1\.0\.0 \//, '应显示提示词版本');
      assert.match(content, /analysis_bundle/, '应声明事实来源为结果包');
      assert.match(content, /模型未完全遵守分层标签要求/, '应显示校验警告');
      assert.match(content, /不能据此推断因果关系/, '应原文显示结果包限制');
      assert.match(content, /板块：相关分析；假设：H3；关注点：服务需求量级/, '应回显本次解释范围');
    } finally {
      stub.restore();
    }
  });

  test('输出被截断时明确警告，并说明只返回了已完成的部分', async () => {
    const stub = stubAiApi({ interpretation: { ...INTERPRETATION_LIVE, truncated: true } });
    try {
      await renderPage();
      await generate();

      const content = text();
      assert.match(content, /模型输出被截断/);
      assert.match(content, /达到输出长度上限/);
      assert.match(content, /不覆盖全部分析内容/);
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Degraded mode and availability                                   */
  /* ================================================================ */

  test('降级模式明确标注为统计引擎生成，而不是模型写的', async () => {
    const stub = stubAiApi({ interpretation: INTERPRETATION_DEGRADED });
    try {
      await renderPage();
      await generate();

      const content = text();
      assert.match(content, /本次结果由统计引擎直接生成，不是模型写的/);
      assert.match(content, /以下内容由统计引擎直接依据统计结果包生成，未经任何生成式模型改写/);
      assert.match(content, /未配置 DEEPSEEK_API_KEY/);
      assert.ok(
        !content.includes('本次结果由模型生成，数字全部来自结果包'),
        '降级结果不得被标注为模型生成',
      );
      assert.match(content, /引用时请写明「由统计引擎生成」/);
      // The engine's own statements still arrive, in their own levels.
      assert.ok(content.includes('进入统计分析的有效样本为 350 份'));
      assert.match(content, /引擎摘要的原始分节/);
      // An "absence" statement carries no citation; the page must say why rather
      // than render an empty evidence list.
      assert.match(content, /该条没有可回溯的结果包引用/);
      assert.match(content, /没有出现达到显著性水平的成对相关/);
    } finally {
      stub.restore();
    }
  });

  test('未配置模型时页面如实说明将产生引擎摘要', async () => {
    const stub = stubAiApi({ status: STATUS_UNCONFIGURED });
    try {
      await renderPage();

      const content = text();
      assert.match(content, /未配置模型（不可用）/);
      assert.match(content, /未配置 DEEPSEEK_API_KEY 环境变量/);
      assert.match(content, /AI 解释当前不可用：未配置模型接口/);
      assert.match(content, /由统计引擎直接依据统计结果包生成的中文摘要/);
      assert.match(content, /engine_summary\.ai_generated = false/);
      assert.match(content, /不应被引用为 AI 生成内容/);
      assert.match(content, /degraded（引擎摘要）/, '运行模式应显示为降级');
    } finally {
      stub.restore();
    }
  });

  test('没有结果包时停用生成按钮并指向统计分析页', async () => {
    const stub = stubAiApi({ status: STATUS_NO_BUNDLE });
    try {
      await renderPage();

      const content = text();
      assert.match(content, /尚未运行过完整统计分析/);
      assert.match(content, /请先在「统计分析」页执行「运行全部分析」/);

      const button = queryAll('button').find((element) =>
        (element.textContent ?? '').includes('生成 AI 解释'),
      );
      assert.ok(button, '按钮仍应存在（并说明为何不可用）');
      assert.equal(button!.hasAttribute('disabled'), true, '没有结果包时必须停用生成按钮');
      assert.ok(!stub.calls.some((call) => call.url.includes('/ai/interpret')), '不应发出解释请求');
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Scope selector and history                                       */
  /* ================================================================ */

  test('范围选择器把 section / hypothesis_code 一并提交，且只能提出可选值', async () => {
    const stub = stubAiApi();
    try {
      await renderPage();

      const content = text();
      assert.match(content, /可选 1 条假设，取自统计分析结果。/);

      const selects = queryAll('select');
      const sectionSelect = selects.find((element) =>
        Array.from(element.querySelectorAll('option')).some((option) => option.value === 'regression'),
      );
      const hypothesisSelect = selects.find((element) =>
        Array.from(element.querySelectorAll('option')).some((option) => option.value === 'H3'),
      );
      assert.ok(sectionSelect, '应有板块选择器，且可选项来自接口声明的范围');
      assert.ok(hypothesisSelect, '应有假设选择器，可选项来自统计分析结果');
      await typeInto(sectionSelect!, 'regression');
      await typeInto(hypothesisSelect!, 'H3');

      await generate();

      const call = stub.calls.find((item) => item.url.includes('/ai/interpret'));
      assert.ok(call, '应调用解释接口');
      assert.equal(call!.method, 'POST');
      assert.deepEqual(call!.body, { section: 'regression', hypothesis_code: 'H3' });
    } finally {
      stub.restore();
    }
  });

  test('历史列表显示模式、模型、引擎版本、时间与剔除条数', async () => {
    const stub = stubAiApi();
    try {
      await renderPage();

      const content = text();
      assert.ok(content.includes(formatDateTime(HISTORY[0]!.created_at)), '应显示最近一次生成时间');
      assert.ok(content.includes(formatDateTime(HISTORY[1]!.created_at)), '应显示更早的记录');
      assert.match(content, /deepseek-chat/);
      assert.match(content, /missing_api_key/, '失败与降级运行同样留痕');

      const rows = queryAll('tr').filter((element) =>
        (element.textContent ?? '').includes('deepseek-chat'),
      );
      assert.equal(rows.length, 2, '两次运行都应有记录');

      const liveCells = rows[0]!.querySelectorAll('td');
      assert.equal(liveCells[1]?.textContent, 'live');
      assert.equal(liveCells[2]?.textContent, 'deepseek-chat');
      assert.equal(liveCells[3]?.textContent, '1.0.0');
      assert.equal(liveCells[4]?.textContent, '4', '应显示可发布陈述数');
      assert.equal(liveCells[5]?.textContent, '1', '应显示被剔除的陈述数');

      const degradedCells = rows[1]!.querySelectorAll('td');
      assert.equal(degradedCells[1]?.textContent, 'degraded');
      assert.equal(degradedCells[5]?.textContent, '0');

      const call = stub.calls.find((item) => item.url.includes('/ai/history'));
      assert.ok(call, '应请求历史接口');
    } finally {
      stub.restore();
    }
  });

  test('解释请求携带登录令牌', async () => {
    window.localStorage.setItem('ferp.token', 'test-token');
    const stub = stubAiApi();
    try {
      await renderPage();
      await generate();

      const call = stub.calls.find((item) => item.url.includes('/ai/interpret'));
      assert.ok(call);
      assert.equal(call!.headers['authorization'], 'Bearer test-token');
    } finally {
      stub.restore();
    }
  });
});
