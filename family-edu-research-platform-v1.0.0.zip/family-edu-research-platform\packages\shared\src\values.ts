/**
 * Low-level answer value helpers shared by the logic and scoring engines.
 * Kept dependency-free so both can be used from any runtime.
 */

/** A single stored answer. Matrix answers are row-value keyed maps. */
export type AnswerValue =
  | string
  | number
  | string[]
  | number[]
  | Record<string, string>
  | null
  | undefined;

/** Question code -> answer. */
export type AnswerMap = Record<string, AnswerValue>;

/** Normalise any answer shape into a flat array of scalar values. */
export function asArray(value: AnswerValue): Array<string | number> {
  if (value === null || value === undefined) return [];
  if (Array.isArray(value)) return value as Array<string | number>;
  if (typeof value === 'object') return Object.values(value);
  return [value];
}

/** True when the answer carries no information at all. */
export function isBlank(value: AnswerValue): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim() === '';
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') return Object.keys(value).length === 0;
  return false;
}

/** Coerce to a finite number, or null when the value is not numeric. */
export function asNumber(value: AnswerValue): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value === 'string' && value.trim() !== '') {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

/** Loose equality that works for string option codes and numbers alike. */
export function looseEquals(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a === null || a === undefined || b === null || b === undefined) return false;
  return String(a) === String(b);
}

/** True when the answer contains at least one substantive (non-blank) value. */
export function hasSubstantiveAnswer(value: AnswerValue): boolean {
  return !isBlank(value);
}
