/**
 * Data Collection → Samples / Responses.
 *
 * One page serves both nav entries: "Responses" is the completed-only view,
 * "Samples" is every session including in-progress and abandoned ones. They are
 * genuinely different questions ("who finished?" vs "what came in?"), so the
 * page exposes both rather than pretending they are the same list.
 *
 * The review actions here are the ONLY way a sample stops counting towards
 * analysis, and every exclusion requires a written reason.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { REVIEW_STATUS_LABELS, SOURCE_LABELS, type Respondent, type ReviewStatus } from '@ferp/shared';
import { Alert, Badge, Button, Card, CardHeader, EmptyState, Input, LoadingBlock, Modal, Select, StatCard } from '../components/ui';
import {
  api,
  ApiClientError,
  type ProjectListResult,
  type RespondentPage,
  type SourceBreakdown,
} from '../lib/api';
import { formatDateTime, formatDuration, formatPercent } from '../lib/format';

type Mode = 'samples' | 'responses';

const STATUS_LABELS: Record<string, { label: string; tone: 'neutral' | 'info' | 'success' | 'warning' | 'danger' }> = {
  in_progress: { label: '进行中', tone: 'info' },
  completed: { label: '已完成', tone: 'success' },
  abandoned: { label: '已中断', tone: 'warning' },
};

const REVIEW_TONES: Record<ReviewStatus, 'neutral' | 'info' | 'success' | 'warning' | 'danger'> = {
  unreviewed: 'neutral',
  accepted: 'success',
  flagged: 'warning',
  excluded: 'danger',
};

export function SamplesPage({ mode }: { mode: Mode }): ReactNode {
  const [searchParams, setSearchParams] = useSearchParams();

  const [projects, setProjects] = useState<ProjectListResult | null>(null);
  const [projectId, setProjectId] = useState<string>('');
  const [page, setPage] = useState<RespondentPage | null>(null);
  const [sources, setSources] = useState<SourceBreakdown | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [status, setStatus] = useState(mode === 'responses' ? 'completed' : '');
  const [source, setSource] = useState('');
  const [reviewStatus, setReviewStatus] = useState('');
  const [search, setSearch] = useState('');
  const [offset, setOffset] = useState(0);

  const [reviewTarget, setReviewTarget] = useState<Respondent | null>(null);
  const [reviewDecision, setReviewDecision] = useState<ReviewStatus>('accepted');
  const [reviewNote, setReviewNote] = useState('');

  /* Load the project list once and pick a working project. */
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const list = await api.projects.list({ limit: 200 });
        if (cancelled) return;
        setProjects(list);
        const requested = searchParams.get('project');
        const chosen = requested ?? list.items[0]?.id ?? '';
        setProjectId(chosen);
        if (!chosen) setLoading(false);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiClientError ? err.message : '无法加载研究项目。');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      const [list, sourceData] = await Promise.all([
        api.samples.list(projectId, {
          ...(status ? { status } : {}),
          ...(source ? { source } : {}),
          ...(reviewStatus ? { review_status: reviewStatus } : {}),
          ...(search.trim() ? { search: search.trim() } : {}),
          limit: 50,
          offset,
        }),
        api.samples.sources(projectId),
      ]);
      setPage(list);
      setSources(sourceData);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载样本列表。');
    } finally {
      setLoading(false);
    }
  }, [projectId, status, source, reviewStatus, search, offset]);

  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 200);
    return () => window.clearTimeout(timer);
  }, [load]);

  async function runSweep(): Promise<void> {
    if (!projectId) return;
    setBusy(true);
    setError(null);
    try {
      const result = await api.samples.sweep(projectId, 24);
      setNotice(
        result.marked === 0
          ? '没有超过 24 小时未活动的进行中样本。'
          : `已将 ${result.marked} 份超过 24 小时未活动的样本标记为「已中断」。`,
      );
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '标记失败。');
    } finally {
      setBusy(false);
    }
  }

  async function submitReview(): Promise<void> {
    if (!reviewTarget) return;
    setBusy(true);
    setError(null);
    try {
      await api.samples.review(reviewTarget.id, {
        status: reviewDecision,
        ...(reviewNote.trim() ? { note: reviewNote.trim() } : {}),
      });
      setNotice(
        `样本 ${reviewTarget.anonymous_id} 已标记为「${REVIEW_STATUS_LABELS[reviewDecision]}」。` +
          '平台不会删除该样本，其数据仍然保留，可随时改回。',
      );
      setReviewTarget(null);
      setReviewNote('');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '审核操作失败。');
    } finally {
      setBusy(false);
    }
  }

  const sourceOptions = sources?.items.map((item) => item.source) ?? [];

  if (!projects) return <LoadingBlock label="正在加载研究项目…" />;

  if (projects.items.length === 0) {
    return (
      <EmptyState
        title="还没有研究项目"
        description="数据收集需要先有研究项目与已发布的问卷。"
        action={
          <Link to="/projects/new">
            <Button variant="primary">新建研究项目</Button>
          </Link>
        }
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-ink-900">
            {mode === 'responses' ? 'Responses' : 'Samples'}
          </h1>
          <p className="mt-1 text-sm text-ink-500">
            {mode === 'responses'
              ? '已完成提交的作答记录。点击任一记录可查看该样本的全部作答。'
              : '全部作答会话，包含进行中与已中断的样本。平台不会自动删除任何样本。'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2 text-sm text-ink-600">
            当前研究项目
            <Select
              className="min-w-56"
              value={projectId}
              onChange={(event) => {
                setProjectId(event.target.value);
                setOffset(0);
                setSearchParams({ project: event.target.value });
              }}
            >
              {projects.items.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </Select>
          </label>
          <Button loading={busy} onClick={() => void runSweep()}>
            标记超时样本
          </Button>
        </div>
      </div>

      {error && (
        <Alert tone="danger" title="操作失败">
          {error}
        </Alert>
      )}
      {notice && <Alert tone="success">{notice}</Alert>}

      {/* Summary ------------------------------------------------------- */}
      {page && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <StatCard label="样本总数" value={page.summary.total} />
          <StatCard label="已完成" value={page.summary.completed} tone="success" />
          <StatCard label="进行中" value={page.summary.in_progress} tone="info" />
          <StatCard label="已中断" value={page.summary.abandoned} tone="warning" />
          <StatCard
            label="未审核"
            value={page.summary.by_review_status.unreviewed ?? 0}
            hint={`已排除 ${page.summary.by_review_status.excluded ?? 0}`}
          />
        </div>
      )}

      {/* Filters ------------------------------------------------------- */}
      <Card>
        <div className="flex flex-wrap items-end gap-3">
          <label className="min-w-56 flex-1">
            <span className="ferp-label">按匿名编号搜索</span>
            <Input
              value={search}
              placeholder="例如 A0001"
              onChange={(event) => {
                setSearch(event.target.value);
                setOffset(0);
              }}
            />
          </label>
          <label className="min-w-32">
            <span className="ferp-label">状态</span>
            <Select
              value={status}
              onChange={(event) => {
                setStatus(event.target.value);
                setOffset(0);
              }}
            >
              <option value="">全部</option>
              <option value="completed">已完成</option>
              <option value="in_progress">进行中</option>
              <option value="abandoned">已中断</option>
            </Select>
          </label>
          <label className="min-w-36">
            <span className="ferp-label">来源渠道</span>
            <Select
              value={source}
              onChange={(event) => {
                setSource(event.target.value);
                setOffset(0);
              }}
            >
              <option value="">全部渠道</option>
              {sourceOptions.map((item) => (
                <option key={item} value={item}>
                  {SOURCE_LABELS[item] ?? item}
                </option>
              ))}
            </Select>
          </label>
          <label className="min-w-32">
            <span className="ferp-label">审核状态</span>
            <Select
              value={reviewStatus}
              onChange={(event) => {
                setReviewStatus(event.target.value);
                setOffset(0);
              }}
            >
              <option value="">全部</option>
              {Object.entries(REVIEW_STATUS_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </Select>
          </label>
          <Button onClick={() => void load()}>刷新</Button>
        </div>
      </Card>

      {/* Table --------------------------------------------------------- */}
      {loading && !page ? (
        <LoadingBlock />
      ) : !page || page.items.length === 0 ? (
        <EmptyState
          title={mode === 'responses' ? '还没有已完成的作答' : '还没有任何样本'}
          description="发布问卷后，通过分享链接或二维码收到的作答会实时出现在这里。平台不会生成任何模拟数据。"
        />
      ) : (
        <Card padded={false}>
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-ink-200 px-5 py-3">
            <p className="text-sm text-ink-600">
              共 {page.total} 条记录
              {page.items.length < page.total && `，当前显示第 ${page.offset + 1}—${page.offset + page.items.length} 条`}
            </p>
            <div className="flex items-center gap-2">
              <Button
                disabled={page.offset === 0}
                onClick={() => setOffset(Math.max(0, page.offset - page.limit))}
              >
                上一页
              </Button>
              <Button
                disabled={page.offset + page.limit >= page.total}
                onClick={() => setOffset(page.offset + page.limit)}
              >
                下一页
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-sm">
              <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-4 py-2 text-left">匿名编号</th>
                  <th className="px-4 py-2 text-left">来源</th>
                  <th className="px-4 py-2 text-left">开始时间</th>
                  <th className="px-4 py-2 text-left">完成时间</th>
                  <th className="px-4 py-2 text-right">用时</th>
                  <th className="px-4 py-2 text-right">已答题数</th>
                  <th className="px-4 py-2 text-left">状态</th>
                  <th className="px-4 py-2 text-left">审核</th>
                  <th className="px-4 py-2 text-right">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {page.items.map((respondent) => {
                  const statusMeta = STATUS_LABELS[respondent.status] ?? {
                    label: respondent.status,
                    tone: 'neutral' as const,
                  };
                  const review = respondent.review_status;
                  return (
                    <tr key={respondent.id} className={review === 'excluded' ? 'bg-red-50/40' : undefined}>
                      <td className="px-4 py-2">
                        <Link
                          to={`/collection/samples/${respondent.id}`}
                          className="font-mono text-xs font-medium text-brand-700 hover:underline"
                        >
                          {respondent.anonymous_id}
                        </Link>
                      </td>
                      <td className="px-4 py-2 text-ink-700">
                        {SOURCE_LABELS[respondent.source] ?? respondent.source}
                      </td>
                      <td className="px-4 py-2 text-xs text-ink-600">
                        {formatDateTime(respondent.started_at)}
                      </td>
                      <td className="px-4 py-2 text-xs text-ink-600">
                        {formatDateTime(respondent.completed_at)}
                      </td>
                      <td className="px-4 py-2 text-right tabular-nums text-ink-700">
                        {formatDuration(respondent.duration_seconds)}
                      </td>
                      <td className="px-4 py-2 text-right tabular-nums text-ink-700">
                        {respondent.answered_count}
                      </td>
                      <td className="px-4 py-2">
                        <Badge tone={statusMeta.tone}>{statusMeta.label}</Badge>
                      </td>
                      <td className="px-4 py-2">
                        <Badge tone={REVIEW_TONES[review]}>
                          {REVIEW_STATUS_LABELS[review]}
                        </Badge>
                      </td>
                      <td className="px-4 py-2 text-right">
                        <div className="flex justify-end gap-2">
                          <Link to={`/collection/samples/${respondent.id}`}>
                            <Button variant="ghost">查看</Button>
                          </Link>
                          <Button
                            variant="ghost"
                            onClick={() => {
                              setReviewTarget(respondent);
                              setReviewDecision(respondent.review_status);
                              setReviewNote(respondent.review_note ?? '');
                            }}
                          >
                            审核
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Channel summary ---------------------------------------------- */}
      {sources && sources.items.length > 0 && (
        <Card>
          <CardHeader
            title="来源渠道概况"
            description="按分享链接的 ?source= 参数统计，用于分析不同渠道的样本来源与完成质量。"
            actions={
              <Link to={`/collection/sources?project=${projectId}`}>
                <Button>查看完整渠道分析</Button>
              </Link>
            }
          />
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {sources.items.slice(0, 4).map((item) => (
              <li key={item.source} className="rounded-lg border border-ink-200 p-3">
                <p className="text-sm font-medium text-ink-900">
                  {SOURCE_LABELS[item.source] ?? item.source}
                </p>
                <p className="mt-1 text-xl font-semibold tabular-nums text-ink-900">{item.total}</p>
                <p className="mt-0.5 text-xs text-ink-500">
                  完成率 {formatPercent(item.completion_rate)}
                </p>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Review modal -------------------------------------------------- */}
      <Modal
        open={reviewTarget !== null}
        title={`审核样本 ${reviewTarget?.anonymous_id ?? ''}`}
        onClose={() => setReviewTarget(null)}
        footer={
          <>
            <Button onClick={() => setReviewTarget(null)}>取消</Button>
            <Button variant="primary" loading={busy} onClick={() => void submitReview()}>
              保存审核结果
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <p className="text-sm text-ink-600">
            审核结果会记入样本记录，并说明该样本是否进入分析。平台
            <strong>不会删除</strong>任何样本，随时可以修改审核结论。
          </p>

          <label className="block">
            <span className="ferp-label">审核结论</span>
            <Select
              value={reviewDecision}
              onChange={(event) => setReviewDecision(event.target.value as ReviewStatus)}
            >
              {Object.entries(REVIEW_STATUS_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </Select>
          </label>

          <label className="block">
            <span className="ferp-label">
              审核说明{reviewDecision === 'excluded' && <span className="ml-1 text-red-600">*</span>}
            </span>
            <Input
              value={reviewNote}
              onChange={(event) => setReviewNote(event.target.value)}
              placeholder={
                reviewDecision === 'excluded'
                  ? '排除样本必须填写原因，将用于方法部分如实报告排除标准'
                  : '选填，例如「作答完整，用时正常」'
              }
            />
          </label>

          {reviewTarget && (
            <dl className="grid grid-cols-2 gap-2 rounded-lg bg-ink-50 p-3 text-xs">
              <div>
                <dt className="text-ink-500">状态</dt>
                <dd className="text-ink-800">
                  {STATUS_LABELS[reviewTarget.status]?.label ?? reviewTarget.status}
                </dd>
              </div>
              <div>
                <dt className="text-ink-500">用时</dt>
                <dd className="tabular-nums text-ink-800">
                  {formatDuration(reviewTarget.duration_seconds)}
                </dd>
              </div>
              <div>
                <dt className="text-ink-500">已答题数</dt>
                <dd className="tabular-nums text-ink-800">{reviewTarget.answered_count}</dd>
              </div>
              <div>
                <dt className="text-ink-500">来源</dt>
                <dd className="text-ink-800">
                  {SOURCE_LABELS[reviewTarget.source] ?? reviewTarget.source}
                </dd>
              </div>
            </dl>
          )}

          <Alert tone="info" title="关于数据质量评分">
            自动质量检测（完成时间过短、连续同选项、主客观知识矛盾等）将在 PHASE 4 上线。
            目前请依据用时与已答题数人工判断。
          </Alert>
        </div>
      </Modal>
    </div>
  );
}
