/**
 * Public respondent survey — `/research/:shareToken`.
 *
 * Constraints this page is built around:
 *  - No account, no login. The share token identifies the instrument; a
 *    per-respondent session token (kept in localStorage) identifies the session.
 *  - Answering must survive a refresh or a closed tab, so every answer is
 *    autosaved and the session is resumed on load.
 *  - The flow is driven by the SAME logic engine the builder previews, so the
 *    branch a researcher saw is the branch the respondent gets. The server
 *    re-validates every save, so this is convenience, not the integrity check.
 *  - Mobile first: one question per screen, large tap targets, no horizontal
 *    scrolling (matrix tables scroll inside their own container).
 */

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { useParams, useSearchParams, Link } from 'react-router-dom';
import {
  isQuestionRequired,
  isQuestionVisible,
  sortQuestions,
  type Question,
} from '@ferp/shared';
import { QuestionPreview, type AnswerValue } from '../components/QuestionPreview';
import { Alert, Button, Spinner } from '../components/ui';
import {
  ApiClientError,
  publicApi,
  type PublicInstrument,
  type PublicSessionState,
  type Respondent,
} from '../lib/api';
import { sessionStorageKey } from '../lib/surveySession';

type Phase = 'loading' | 'closed' | 'invalid' | 'consent' | 'survey' | 'done';

/** Autosave debounce: long enough to batch fast typing, short enough to be safe. */
const AUTOSAVE_DELAY_MS = 500;

export function SurveyPage(): ReactNode {
  const { shareToken = '' } = useParams();
  const [searchParams] = useSearchParams();
  const source = searchParams.get('source');

  const [phase, setPhase] = useState<Phase>('loading');
  const [instrument, setInstrument] = useState<PublicInstrument | null>(null);
  const [session, setSession] = useState<PublicSessionState | null>(null);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<string, AnswerValue>>({});
  const [cursor, setCursor] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [requiredWarning, setRequiredWarning] = useState(false);
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [submitting, setSubmitting] = useState(false);
  const [prunedNotice, setPrunedNotice] = useState<string[]>([]);

  const startTimerRef = useRef<number | null>(null);
  const saveTimerRef = useRef<number | null>(null);
  const pendingRef = useRef<{ code: string; value: unknown } | null>(null);

  /* ---------------------------------------------------------------- */
  /* Boot: load instrument, then try to resume an existing session      */
  /* ---------------------------------------------------------------- */

  useEffect(() => {
    let cancelled = false;

    async function boot(): Promise<void> {
      setPhase('loading');
      setError(null);

      try {
        const loaded = await publicApi.instrument(shareToken);
        if (cancelled) return;
        setInstrument(loaded);

        if (!loaded.accepting_responses) {
          setPhase('closed');
          return;
        }

        const stored = window.localStorage.getItem(sessionStorageKey(shareToken));
        if (stored) {
          try {
            const resumed = await publicApi.session(stored);
            if (cancelled) return;
            setSessionToken(stored);
            setSession(resumed);
            setAnswers(resumed.answers as Record<string, AnswerValue>);
            // Restore the respondent's position.
            const ordered = sortQuestions(resumed.answers ? loaded.questions : loaded.questions);
            const visible = visibleFrom(ordered, resumed.answers as Record<string, AnswerValue>);
            const savedIndex = visible.findIndex(
              (question) => question.question_code === resumed.respondent.current_question_code,
            );
            setCursor(savedIndex >= 0 ? savedIndex : firstUnansweredIndex(visible, resumed.answers as Record<string, AnswerValue>));
            setPhase(resumed.respondent.status === 'completed' ? 'done' : 'survey');
            return;
          } catch {
            // Stale or revoked session — fall through to consent.
            window.localStorage.removeItem(sessionStorageKey(shareToken));
          }
        }

        setPhase('consent');
      } catch (err) {
        if (cancelled) return;
        setError(
          err instanceof ApiClientError && err.status === 404
            ? '问卷链接无效或已被撤销，请向发放问卷的老师或研究者确认链接是否正确。'
            : err instanceof ApiClientError
              ? err.message
              : '无法加载问卷，请检查网络后重试。',
        );
        setPhase('invalid');
      }
    }

    void boot();
    return () => {
      cancelled = true;
    };
  }, [shareToken]);

  /* ---------------------------------------------------------------- */
  /* Derived flow state                                                */
  /* ---------------------------------------------------------------- */

  const visibleQuestions = useMemo(
    () => (instrument ? visibleFrom(sortQuestions(instrument.questions), answers) : []),
    [instrument, answers],
  );

  const current = visibleQuestions[cursor] ?? null;
  const totalQuestions = instrument?.question_count ?? 0;
  const answeredCount = Object.values(answers).filter((value) => !isEmpty(value)).length;
  const isLast = visibleQuestions.length > 0 && cursor >= visibleQuestions.length - 1;

  /* ---------------------------------------------------------------- */
  /* Autosave                                                          */
  /* ---------------------------------------------------------------- */

  const flushPending = useCallback(async (): Promise<void> => {
    const pending = pendingRef.current;
    if (!pending || !sessionToken) return;
    pendingRef.current = null;
    setSaveState('saving');
    try {
      const result = await publicApi.saveAnswer(sessionToken, pending.code, pending.value);
      if (result.pruned_question_codes.length > 0) {
        setPrunedNotice((current) => Array.from(new Set([...current, ...result.pruned_question_codes])));
        // Mirror the server's pruning so the local view stays truthful.
        setAnswers((current) => {
          const next = { ...current };
          for (const code of result.pruned_question_codes) delete next[code];
          return next;
        });
      }
      setSaveState('saved');
    } catch (err) {
      setSaveState('error');
      setError(err instanceof ApiClientError ? err.message : '自动保存失败，请检查网络。');
    }
  }, [sessionToken]);

  const scheduleSave = useCallback(
    (code: string, value: unknown) => {
      pendingRef.current = { code, value };
      if (saveTimerRef.current !== null) window.clearTimeout(saveTimerRef.current);
      saveTimerRef.current = window.setTimeout(() => {
        void flushPending();
      }, AUTOSAVE_DELAY_MS);
    },
    [flushPending],
  );

  // Flush any in-flight answer before the tab goes away.
  useEffect(() => {
    function handleHide(): void {
      if (pendingRef.current) void flushPending();
    }
    window.addEventListener('visibilitychange', handleHide);
    window.addEventListener('pagehide', handleHide);
    return () => {
      window.removeEventListener('visibilitychange', handleHide);
      window.removeEventListener('pagehide', handleHide);
    };
  }, [flushPending]);

  useEffect(
    () => () => {
      if (saveTimerRef.current !== null) window.clearTimeout(saveTimerRef.current);
      if (startTimerRef.current !== null) window.clearTimeout(startTimerRef.current);
    },
    [],
  );

  /* ---------------------------------------------------------------- */
  /* Actions                                                           */
  /* ---------------------------------------------------------------- */

  async function beginSurvey(): Promise<void> {
    setError(null);
    try {
      const started = await publicApi.startSession(shareToken, source);
      window.localStorage.setItem(sessionStorageKey(shareToken), started.session_token);
      setSessionToken(started.session_token);
      setSession({
        respondent: started.respondent,
        answers: {},
        hidden_question_codes: [],
        missing_required: [],
      });
      setAnswers({});
      setCursor(0);
      setPhase('survey');
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法开始作答，请稍后重试。');
    }
  }

  function setAnswer(question: Question, value: AnswerValue): void {
    setRequiredWarning(false);
    setAnswers((current) => {
      const next = { ...current };
      if (isEmpty(value)) delete next[question.question_code];
      else next[question.question_code] = value;
      return next;
    });
    scheduleSave(question.question_code, value);
  }

  async function goNext(): Promise<void> {
    if (!current) return;

    if (isQuestionRequired(current, answers) && isEmpty(answers[current.question_code])) {
      setRequiredWarning(true);
      return;
    }

    await flushPending();

    if (isLast) {
      await submit();
      return;
    }
    const nextIndex = cursor + 1;
    setCursor(nextIndex);
    const nextQuestion = visibleQuestions[nextIndex];
    if (nextQuestion && sessionToken) {
      void publicApi.updateProgress(sessionToken, nextQuestion.question_code).catch(() => undefined);
    }
  }

  async function goPrevious(): Promise<void> {
    await flushPending();
    setRequiredWarning(false);
    setCursor((value) => Math.max(0, value - 1));
  }

  async function submit(): Promise<void> {
    if (!sessionToken) return;
    setSubmitting(true);
    setError(null);
    try {
      await flushPending();
      const result = await publicApi.complete(sessionToken);
      setSession((current) =>
        current ? { ...current, respondent: result.respondent } : current,
      );
      setPhase('done');
      window.scrollTo({ top: 0 });
    } catch (err) {
      if (err instanceof ApiClientError && err.status === 400) {
        // Server lists the exact unanswered required questions.
        setRequiredWarning(true);
        setError(err.message);
        const details = err.fieldErrors;
        const firstMissing = details[0]?.field;
        if (firstMissing) {
          const index = visibleQuestions.findIndex((question) => question.question_code === firstMissing);
          if (index >= 0) setCursor(index);
        }
      } else {
        setError(err instanceof ApiClientError ? err.message : '提交失败，请稍后重试。');
      }
    } finally {
      setSubmitting(false);
    }
  }

  /* ---------------------------------------------------------------- */
  /* Render                                                            */
  /* ---------------------------------------------------------------- */

  if (phase === 'loading') {
    return (
      <SurveyShell>
        <div className="flex items-center justify-center gap-3 py-24 text-sm text-ink-500">
          <Spinner /> 正在加载问卷…
        </div>
      </SurveyShell>
    );
  }

  if (phase === 'invalid' || phase === 'closed') {
    return (
      <SurveyShell>
        <div className="rounded-xl border border-ink-200 bg-white p-8 text-center shadow-sm">
          <p className="text-lg font-semibold text-ink-900">
            {phase === 'closed' ? '本次调查已结束' : '无法打开问卷'}
          </p>
          <p className="mt-3 text-sm text-ink-600">
            {error ?? '感谢您的关注。'}
          </p>
        </div>
      </SurveyShell>
    );
  }

  if (phase === 'consent' && instrument) {
    return (
      <SurveyShell>
        <div className="rounded-xl border border-ink-200 bg-white p-6 shadow-sm sm:p-8">
          <p className="text-xs font-medium uppercase tracking-wider text-brand-700">
            家庭教育调查 · {instrument.questionnaire.version}
          </p>
          <h1 className="mt-2 text-xl font-semibold leading-snug text-ink-900 sm:text-2xl">
            {instrument.questionnaire.title}
          </h1>
          {instrument.questionnaire.description && (
            <p className="mt-3 text-sm leading-relaxed text-ink-600">
              {instrument.questionnaire.description}
            </p>
          )}

          <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-lg bg-ink-50 px-3 py-2">
              <dt className="text-xs text-ink-500">题目数量</dt>
              <dd className="mt-0.5 font-semibold tabular-nums text-ink-900">
                {instrument.question_count} 题
              </dd>
            </div>
            <div className="rounded-lg bg-ink-50 px-3 py-2">
              <dt className="text-xs text-ink-500">预计用时</dt>
              <dd className="mt-0.5 font-semibold text-ink-900">8—12 分钟</dd>
            </div>
          </dl>

          <div className="mt-6 rounded-lg border border-brand-100 bg-brand-50 p-4">
            <h2 className="text-sm font-semibold text-brand-900">知情同意说明</h2>
            <p className="mt-2 text-sm leading-relaxed text-brand-900/90">{instrument.consent_text}</p>
            <ul className="mt-3 space-y-1.5">
              {instrument.ethics_points.map((point) => (
                <li key={point} className="flex gap-2 text-xs leading-relaxed text-brand-900/80">
                  <span aria-hidden="true">·</span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
            {instrument.consent_is_platform_default && (
              <p className="mt-3 text-[11px] text-brand-900/60">
                本说明为平台默认文本（研究者未填写自定义说明）。
              </p>
            )}
          </div>

          {error && (
            <div className="mt-4">
              <Alert tone="danger">{error}</Alert>
            </div>
          )}

          <Button variant="primary" className="mt-6 w-full py-3 text-base" onClick={() => void beginSurvey()}>
            我已了解，开始作答
          </Button>
          <p className="mt-3 text-center text-xs text-ink-400">
            开始时即记录您的知情同意时间。作答过程中可以随时退出。
          </p>
        </div>
      </SurveyShell>
    );
  }

  if (phase === 'done') {
    const respondent: Respondent | null = session?.respondent ?? null;
    return (
      <SurveyShell>
        <div className="rounded-xl border border-ink-200 bg-white p-8 text-center shadow-sm">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-50 text-2xl text-emerald-600">
            ✓
          </div>
          <h1 className="mt-4 text-xl font-semibold text-ink-900">提交成功，感谢您的参与</h1>
          <p className="mt-3 text-sm leading-relaxed text-ink-600">
            您的作答已匿名保存，仅用于研究统计，不会被单独识别。
          </p>
          {respondent && (
            <p className="mt-5 rounded-lg bg-ink-50 px-4 py-3 text-sm text-ink-700">
              您的匿名编号：
              <span className="ml-1 font-mono font-semibold text-ink-900">{respondent.anonymous_id}</span>
              <span className="mt-1 block text-xs text-ink-500">
                如需与研究方核对，可提供此编号；它不包含任何个人信息。
              </span>
            </p>
          )}
          <p className="mt-6 text-xs text-ink-400">您现在可以关闭此页面。</p>
        </div>
      </SurveyShell>
    );
  }

  /* ---------------------------------------------------------------- */
  /* Survey flow                                                       */
  /* ---------------------------------------------------------------- */

  if (!current) {
    return (
      <SurveyShell>
        <div className="rounded-xl border border-ink-200 bg-white p-8 text-center shadow-sm">
          <p className="text-sm text-ink-600">问卷没有需要作答的题目。</p>
        </div>
      </SurveyShell>
    );
  }

  const progressPercent = visibleQuestions.length > 0 ? ((cursor + 1) / visibleQuestions.length) * 100 : 0;

  return (
    <SurveyShell>
      {/* Layout choice — the same session backs both respondent layouts. */}
      <div className="mb-3 text-right">
        <Link
          to={`/research/${shareToken}/all${querySuffix(searchParams)}`}
          className="text-xs text-brand-700 underline underline-offset-2"
        >
          切换为整页问卷（全部题目显示在一页）
        </Link>
      </div>

      {/* Progress ---------------------------------------------------- */}
      <div className="mb-4">
        <div className="flex items-baseline justify-between text-xs text-ink-500">
          <span>
            第 <span className="font-semibold tabular-nums text-ink-800">{cursor + 1}</span>/
            {visibleQuestions.length} 题
          </span>
          <span className="tabular-nums">已答 {answeredCount} 题（全卷共 {totalQuestions} 题）</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink-200">
          <div
            className="h-full rounded-full bg-brand-600 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="mt-1.5 flex items-center justify-between text-[11px] text-ink-400">
          <span>{current.section ?? ''}</span>
          <SaveIndicator state={saveState} />
        </div>
      </div>

      {prunedNotice.length > 0 && (
        <div className="mb-4">
          <Alert tone="info" title="已根据您修改的前置答案调整后续题目">
            因为您更改了前面的选择，以下题目在新路径下不再展示，其作答已自动清除：
            <span className="font-mono">{prunedNotice.join('、')}</span>。
          </Alert>
        </div>
      )}

      {error && (
        <div className="mb-4">
          <Alert tone="danger">{error}</Alert>
        </div>
      )}

      {/* Question ---------------------------------------------------- */}
      <div className="rounded-xl border border-ink-200 bg-white shadow-sm">
        <div className="p-4 sm:p-6">
          <QuestionPreview
            question={current}
            value={answers[current.question_code] ?? null}
            onChange={(value) => setAnswer(current, value)}
            invalid={requiredWarning}
          />
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-ink-100 px-4 py-4 sm:px-6">
          <Button
            variant="secondary"
            disabled={cursor === 0}
            onClick={() => void goPrevious()}
            className="min-w-24"
          >
            上一题
          </Button>

          <div className="flex items-center gap-2">
            {!isEmpty(answers[current.question_code]) && !isLast && (
              <span className="hidden text-xs text-emerald-600 sm:inline">已保存</span>
            )}
            <Button
              variant="primary"
              loading={submitting}
              onClick={() => void goNext()}
              className="min-w-28"
            >
              {isLast ? '提交问卷' : '下一题'}
            </Button>
          </div>
        </div>
      </div>

      <p className="mt-4 text-center text-xs leading-relaxed text-ink-400">
        作答会自动保存，刷新或关闭页面后重新打开链接可以继续。
        <br />
        本研究为匿名调查，您可以拒绝回答任何问题。
      </p>
    </SurveyShell>
  );
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

/** Mobile-first centred column; the survey is never wider than a phone view. */
function SurveyShell({ children }: { children: ReactNode }): ReactNode {
  return (
    <div className="min-h-screen bg-ink-50 px-4 py-6 sm:py-10">
      <div className="mx-auto w-full max-w-2xl">
        <p className="mb-4 text-center text-xs font-medium tracking-wide text-ink-400">
          家庭教育科研智能研究平台 · 匿名调查
        </p>
        {children}
      </div>
    </div>
  );
}

function SaveIndicator({ state }: { state: 'idle' | 'saving' | 'saved' | 'error' }): ReactNode {
  if (state === 'saving') return <span className="text-ink-400">保存中…</span>;
  if (state === 'saved') return <span className="text-emerald-600">已自动保存</span>;
  if (state === 'error') return <span className="text-red-600">保存失败</span>;
  return <span />;
}

export function isEmpty(value: unknown): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim() === '';
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).every(
      (item) => item === null || item === undefined || String(item).trim() === '',
    );
  }
  return false;
}

/** Questions on the current answer path, using the shared logic engine. */
export function visibleFrom(
  questions: Question[],
  answers: Record<string, unknown>,
): Question[] {
  return questions
    .filter((question) => question.question_type !== 'page_break')
    .filter((question) => isQuestionVisible(question, answers as never));
}

/** Index of the first unanswered question, so resume lands somewhere useful. */
function firstUnansweredIndex(
  questions: Question[],
  answers: Record<string, unknown>,
): number {
  const index = questions.findIndex((question) => isEmpty(answers[question.question_code]));
  return index >= 0 ? index : Math.max(questions.length - 1, 0);
}

/** Carry `?source=` (channel tracking) across the two respondent layouts. */
export function querySuffix(params: URLSearchParams): string {
  const query = params.toString();
  return query ? `?${query}` : '';
}
