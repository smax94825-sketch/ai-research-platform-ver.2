/**
 * Export service tests (PHASE 8).
 *
 * These are pure-function tests: no server, no database. Everything here is
 * built from a small `Dataset` literal so that the properties under test —
 * missing values never becoming 0, honest placeholders instead of fabricated
 * statistics, and genuinely importable SPSS syntax — can be asserted exactly.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import ExcelJS, { type Workbook } from 'exceljs';
import type { Dataset, DatasetVariable, Question } from '@ferp/shared';

import {
  ANALYSIS_NOT_RUN_NOTE,
  CODEBOOK_HEADERS,
  DICTIONARY_HEADERS,
  codebookRows,
  datasetToRows,
  exportFilenames,
  toCsv,
  toExcelBuffer,
  toJson,
  toSpssBundle,
  type ExportContext,
} from '../src/services/export.service.js';

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

/** 56 characters: longer than the 32 SPSS allows, so it must be truncated. */
const LONG_VARIABLE_NAME = 'HOUSEHOLD_EDUCATION_INVESTMENT_AND_PARENTING_STYLE_INDEX';

const REQUIRED_SHEETS = [
  'Raw Data',
  'Variable Dictionary',
  'Codebook',
  'Data Quality',
  'Descriptive Statistics',
  'Reliability',
  'Validity',
  'Correlation',
  'Regression',
  'Hypothesis Testing',
  'Research Findings',
];

/** The sheets whose content can only come from a real analysis run. */
const ANALYSIS_SHEETS = REQUIRED_SHEETS.slice(3);

function makeVariables(): DatasetVariable[] {
  return [
    {
      name: 'Q1',
      label: '受访者性别',
      dimension: '人口学',
      question_code: 'Q1',
      data_type: 'nominal',
      // 第三位受访者选择了「不愿回答」（选项代码 3），在数据集中是缺失。
      values: [1, 2, null],
      raw: ['1', '2', '3'],
      value_labels: { '1': '男', '2': '女', '3': '不愿回答' },
      is_derived: false,
      sources: ['Q1'],
    },
    {
      name: 'Q2',
      label: '亲子沟通频率',
      dimension: '亲子互动',
      question_code: 'Q2',
      data_type: 'ordinal',
      values: [4, 3, 5],
      raw: ['4', '3', '5'],
      value_labels: { '1': '从不', '2': '很少', '3': '有时', '4': '经常', '5': '总是' },
      is_derived: false,
      sources: ['Q2'],
    },
    {
      name: 'AGE',
      label: '家长年龄',
      dimension: '人口学',
      question_code: 'Q3',
      data_type: 'ratio',
      values: [34, null, 41],
      raw: [34, null, 41],
      value_labels: {},
      is_derived: false,
      sources: ['Q3'],
    },
    {
      name: 'OPEN',
      label: '您在家庭教育中最大的困惑',
      dimension: '开放题',
      question_code: 'Q4',
      data_type: 'text',
      // 文本题在数据集中没有数值编码，原始作答是唯一的记录。
      values: [null, null, null],
      raw: ['喜欢阅读，尤其是"科普"类', '暂无', null],
      value_labels: {},
      is_derived: false,
      sources: ['Q4'],
    },
    {
      name: LONG_VARIABLE_NAME,
      label: '家庭教育投入综合指数',
      dimension: '家庭投入',
      question_code: 'Q5、Q6',
      data_type: 'interval',
      values: [3.5, null, 4.25],
      raw: [3.5, null, 4.25],
      value_labels: {},
      is_derived: true,
      sources: ['Q5', 'Q6'],
    },
    {
      name: 'FEK-INDEX (self-rated)',
      label: '家长自评教育知识水平',
      dimension: '教育知识',
      question_code: 'Q7',
      data_type: 'ordinal',
      values: [3, null, 2],
      raw: ['3', null, '2'],
      value_labels: { '1': '很低', '2': '较低', '3': '一般', '4': '较高', '5': '很高' },
      is_derived: true,
      sources: ['Q7'],
    },
  ];
}

function makeDataset(): Dataset {
  const variables = makeVariables();
  return {
    respondent_ids: ['A0001', 'A0002', 'A0003'],
    variables,
    by_name: new Map(variables.map((variable) => [variable.name, variable])),
    scales: [],
    n_respondents: 3,
    empty_variables: ['OPEN'],
  };
}

function makeContext(overrides: Partial<ExportContext> = {}): ExportContext {
  return {
    projectTitle: '城市家庭 教育投入/亲子关系 研究',
    questionnaireTitle: '家庭教育与亲子关系问卷',
    questionnaireVersion: 'V4.0',
    exportedAt: '2025-03-08T09:30:00.000Z',
    respondentsTotal: 6,
    excludedNote: '已排除 3 份样本',
    ...overrides,
  };
}

/** A stored question, so the dictionary path can be exercised. */
function makeQuestion(): Question {
  return {
    id: 'question-1',
    questionnaire_id: 'questionnaire-1',
    question_code: 'Q1',
    question_text: '受访者性别',
    question_type: 'single',
    options: {
      choices: [
        { value: '1', label: '男' },
        { value: '2', label: '女' },
        { value: '3', label: '不愿回答', sensitiveNonResponse: true },
      ],
    },
    required: true,
    dimension: '人口学',
    variable_name: 'Q1',
    sort_order: 1,
    section: null,
    help_text: null,
    logic: null,
    scoring_rule: { type: 'categorical', codes: { '1': 1, '2': 2, '3': null } },
    created_at: '2025-01-01T00:00:00.000Z',
    updated_at: '2025-01-01T00:00:00.000Z',
  };
}

/**
 * Minimal RFC 4180 reader.
 *
 * Quoting is verified by parsing the file back rather than by substring
 * matching, because a field containing a comma is exactly where a naive
 * `split(',')` check would give a false pass.
 */
function parseCsv(text: string): string[][] {
  const source = text.startsWith('\uFEFF') ? text.slice(1) : text;
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;

  for (let index = 0; index < source.length; index += 1) {
    const character = source[index]!;
    if (quoted) {
      if (character === '"') {
        if (source[index + 1] === '"') {
          field += '"';
          index += 1;
        } else {
          quoted = false;
        }
      } else {
        field += character;
      }
      continue;
    }
    if (character === '"') {
      quoted = true;
    } else if (character === ',') {
      row.push(field);
      field = '';
    } else if (character === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else if (character !== '\r') {
      field += character;
    }
  }
  row.push(field);
  rows.push(row);
  return rows;
}

async function loadWorkbook(buffer: Buffer): Promise<Workbook> {
  const workbook = new ExcelJS.Workbook();
  // exceljs declares its own `Buffer` interface (an ArrayBuffer subclass) for
  // `load`; the cast only satisfies that declaration.
  await workbook.xlsx.load(buffer as unknown as ArrayBuffer);
  return workbook;
}

function sheetText(workbook: Workbook, name: string): string {
  const sheet = workbook.getWorksheet(name);
  assert.ok(sheet, `缺少工作表 ${name}`);
  const values: string[] = [];
  sheet.eachRow((row) => {
    row.eachCell({ includeEmpty: false }, (cell) => {
      if (cell.value !== null && cell.value !== undefined) values.push(String(cell.value));
    });
  });
  return values.join('\n');
}

/**
 * Cell values of one row as a plain array.
 * exceljs returns a sparse array whose index 0 is a hole (it is 1-based).
 */
function rowCells(row: { values: unknown }): unknown[] {
  return Array.from(row.values as unknown[]).slice(1);
}

/** Extract one SPSS command: from its own line to the next blank line. */
function spssCommand(syntax: string, name: string): string {
  const start = syntax.indexOf(`\n${name}`);
  assert.ok(start > -1, `语法中缺少 ${name} 命令`);
  const body = syntax.slice(start + 1);
  const end = body.search(/\n\s*\n/);
  return end === -1 ? body : body.slice(0, end);
}

/* ------------------------------------------------------------------ */
/* Wide-format rows                                                   */
/* ------------------------------------------------------------------ */

describe('导出：宽表数据', () => {
  test('缺失值导出为空（null），绝不是 0', () => {
    const dataset = makeDataset();
    const { rows } = datasetToRows(dataset);

    // 第三位受访者对 Q1 选择了「不愿回答」，第二位未填年龄与派生指数。
    assert.equal(rows[2]![1], null, '敏感拒答必须保持为缺失');
    assert.equal(rows[1]![3], null, '未作答的年龄必须是缺失');
    assert.equal(rows[1]![5], null, '缺失的派生变量不能变成 0');

    for (const row of rows) {
      for (const cell of row.slice(1)) {
        assert.notEqual(cell, 0, '缺失值不得被写成 0');
      }
    }
  });

  test('行数等于受访者数，列数等于 1 + 变量数', () => {
    const dataset = makeDataset();
    const { headers, rows } = datasetToRows(dataset);

    assert.equal(rows.length, dataset.n_respondents);
    assert.equal(headers.length, dataset.variables.length + 1);
    assert.equal(headers[0], 'respondent_id');
    assert.deepEqual(
      headers.slice(1),
      dataset.variables.map((variable) => variable.name),
    );
    assert.ok(rows.every((row) => row.length === headers.length));
  });

  test('开放题的原始文本随行导出，数值列为空的题不会丢数据', () => {
    const { rows } = datasetToRows(makeDataset());
    assert.equal(rows[0]![4], '喜欢阅读，尤其是"科普"类');
    assert.equal(rows[1]![4], '暂无');
    assert.equal(rows[2]![4], null);
  });

  test('选项代码被解码为标签，且拒答选项在码本中如实记录', () => {
    const rows = codebookRows(makeDataset());
    assert.deepEqual(rows[0], CODEBOOK_HEADERS);
    // 码本如实记录问卷里存在的选项（读者据此解码）；数据中该取值仍为缺失。
    assert.ok(
      rows.some(
        (row) => row[0] === 'Q1' && row[3] === 3 && row[4] === '不愿回答',
      ),
      '码本必须能解码拒绝回答这一选项',
    );
    // 没有选项编码的变量也要有说明行，而不是留白让人以为漏导出。
    assert.ok(rows.some((row) => row[0] === 'OPEN' && String(row[4]).includes('文本变量')));
  });
});

/* ------------------------------------------------------------------ */
/* CSV                                                                */
/* ------------------------------------------------------------------ */

describe('导出：CSV', () => {
  test('以 BOM 开头，且逗号与引号被正确转义', () => {
    const context = makeContext();
    const csv = toCsv(makeDataset(), context);

    assert.ok(csv.startsWith('\uFEFF'), 'CSV 必须以 BOM 开头，否则 Excel 会乱码');
    assert.ok(
      csv.includes('"喜欢阅读，尤其是""科普""类"'),
      '含逗号与引号的字段必须整体加引号并把引号翻倍',
    );

    const parsed = parseCsv(csv);
    assert.equal(parsed[0]!.length, 7);
    assert.equal(parsed[1]![4], '喜欢阅读，尤其是"科普"类');
  });

  test('只有表头与数据行，行数等于受访者数', () => {
    const dataset = makeDataset();
    const parsed = parseCsv(toCsv(dataset, makeContext()));

    assert.equal(parsed.length, dataset.n_respondents + 1);
    assert.ok(parsed.every((row) => row.length === 7));
  });

  test('未作答与敏感拒答导出为空字段而不是类别', () => {
    const dataset = makeDataset();
    const csv = toCsv(dataset, makeContext());
    const parsed = parseCsv(csv);

    assert.equal(parsed[3]![1], '', '拒答者的 Q1 必须是空字段');
    assert.equal(parsed[2]![3], '', '未作答的年龄必须是空字段');
    assert.ok(!csv.includes('0,'), '缺失值不得导出为 0');
    assert.ok(!csv.includes('不愿回答'), '数据文件里不能出现拒答标签');
  });
});

/* ------------------------------------------------------------------ */
/* SPSS                                                               */
/* ------------------------------------------------------------------ */

describe('导出：SPSS', () => {
  test('语法包含要求的四个段落与 EXECUTE', () => {
    const { syntax } = toSpssBundle(makeDataset(), makeContext());

    for (const keyword of [
      'GET DATA',
      '/TYPE=TXT',
      '/DELIMITERS',
      'VARIABLE LABELS',
      'VALUE LABELS',
      'MISSING VALUES',
      'EXECUTE.',
    ]) {
      assert.ok(syntax.includes(keyword), `语法缺少 ${keyword}`);
    }
  });

  test('变量名被改写成 SPSS 合法名称且不超过 32 字符', () => {
    const { syntax } = toSpssBundle(makeDataset(), makeContext());
    const block = syntax.slice(syntax.indexOf('/VARIABLES='), syntax.indexOf('/MAP.'));

    const names = block
      .split('\n')
      .slice(1)
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
      .map((line) => line.split(/\s+/)[0]!);

    assert.equal(names.length, 7);
    for (const name of names) {
      assert.match(name, /^[A-Za-z][A-Za-z0-9_]*$/, `变量名 ${name} 不合法`);
      assert.ok(name.length <= 32, `变量名 ${name} 超过 32 字符`);
    }
    assert.equal(new Set(names).size, names.length, 'SPSS 变量名必须唯一');
    assert.ok(names.includes('FEK_INDEX_self_rated'), '非法字符应被改写为下划线');
    assert.ok(
      names.some((name) => name.startsWith('HOUSEHOLD_EDUCATION_INVESTMENT_A')),
      '过长变量名应被截断',
    );
  });

  test('数值变量的缺失以 SYSMIS 声明，不引入任何人为的缺失代码', () => {
    const { syntax } = toSpssBundle(makeDataset(), makeContext());

    const block = spssCommand(syntax, 'MISSING VALUES');
    assert.ok(block.includes('(SYSMIS).'));
    // 不发明 99/-1 之类的缺失代码：这些代码在数据中并不存在，写成缺失会掩盖真实取值。
    assert.ok(!/\(\s*-?\d/.test(block), 'MISSING VALUES 只应声明 SYSMIS');
    assert.ok(block.includes('AGE'), '数值变量应被声明');
    assert.ok(!block.includes('respondent_id'), '字符串变量不能声明 SYSMIS');
    assert.ok(!block.includes('OPEN'), '文本变量不能声明 SYSMIS');
  });

  test('数据文件与语法文件配对，且数据文件不带 BOM', () => {
    const context = makeContext();
    const filenames = exportFilenames(context);
    const bundle = toSpssBundle(makeDataset(), context);

    assert.ok(bundle.syntax.includes(filenames.spssData), '语法必须指向配对的数据文件');
    assert.ok(
      !bundle.data.startsWith('\uFEFF'),
      'SPSS 的 GET DATA 会把 BOM 读进第一个变量名，因此数据文件不能带 BOM',
    );

    const parsed = parseCsv(bundle.data);
    assert.equal(parsed.length, 4);
    assert.equal(parsed[3]![1], '', '缺失在数据文件中同样是空字段');
  });
});

/* ------------------------------------------------------------------ */
/* JSON                                                               */
/* ------------------------------------------------------------------ */

describe('导出：JSON', () => {
  test('可解析，并包含元数据、码本与数据行', () => {
    const dataset = makeDataset();
    const context = makeContext();
    const payload = JSON.parse(toJson(dataset, context)) as {
      metadata: Record<string, unknown>;
      columns: string[];
      codebook: { variable_name: string; value_labels: Record<string, string> }[];
      data: Record<string, string | number | null>[];
    };

    assert.equal(payload.metadata.project_title, context.projectTitle);
    assert.equal(payload.metadata.questionnaire_version, 'V4.0');
    assert.equal(payload.metadata.respondents_total, 6);
    assert.equal(payload.metadata.respondents_exported, 3);
    assert.equal(payload.metadata.excluded_note, '已排除 3 份样本');
    assert.deepEqual(payload.metadata.empty_variables, ['OPEN']);

    assert.equal(payload.data.length, dataset.n_respondents);
    assert.deepEqual(payload.columns, ['respondent_id', ...dataset.variables.map((v) => v.name)]);

    const q1 = payload.codebook.find((entry) => entry.variable_name === 'Q1');
    assert.ok(q1);
    assert.equal(q1.value_labels['1'], '男');
  });

  test('缺失值在 JSON 中是 null，而不是 0 或空字符串类别', () => {
    const payload = JSON.parse(toJson(makeDataset(), makeContext())) as {
      data: Record<string, unknown>[];
    };

    assert.equal(payload.data[2]!.Q1, null);
    assert.equal(payload.data[1]!.AGE, null);
    assert.equal(payload.data[2]!.OPEN, null);
    for (const row of payload.data) {
      assert.notEqual(row.Q1, 0);
      assert.notEqual(row.AGE, 0);
    }
  });
});

/* ------------------------------------------------------------------ */
/* Excel                                                              */
/* ------------------------------------------------------------------ */

describe('导出：Excel', () => {
  test('缓冲区非空且以 ZIP 魔数 PK 开头', async () => {
    const buffer = await toExcelBuffer(makeDataset(), makeContext());
    assert.ok(Buffer.isBuffer(buffer));
    assert.ok(buffer.length > 0);
    assert.equal(buffer[0], 0x50);
    assert.equal(buffer[1], 0x4b);
  });

  test('包含全部要求的工作表且顺序正确', async () => {
    const workbook = await loadWorkbook(await toExcelBuffer(makeDataset(), makeContext()));
    assert.deepEqual(
      workbook.worksheets.map((sheet) => sheet.name),
      REQUIRED_SHEETS,
    );
  });

  test('未提供分析结果的工作表写出诚实的「尚未运行」，而不是编造数字', async () => {
    const workbook = await loadWorkbook(await toExcelBuffer(makeDataset(), makeContext()));

    for (const name of ANALYSIS_SHEETS) {
      const sheet = workbook.getWorksheet(name);
      assert.ok(sheet, `缺少工作表 ${name}`);
      assert.equal(sheet.actualRowCount, 2, `${name} 只应有表头与说明行`);
      assert.equal(sheet.getRow(2).getCell(1).value, ANALYSIS_NOT_RUN_NOTE);
      // 说明行之外没有任何数据单元格：不存在的统计量不会被凭空写出。
      assert.equal(sheet.getRow(2).getCell(2).value, null);
      assert.equal(sheet.getRow(2).getCell(3).value, null);
    }
  });

  test('调用方提供的分析结果合并进同名工作表，不会重复建表', async () => {
    const workbook = await loadWorkbook(
      await toExcelBuffer(makeDataset(), makeContext(), [
        {
          name: 'descriptive statistics',
          headers: ['Variable Name', 'N', 'Mean'],
          rows: [['Q2', 3, 4]],
        },
      ]),
    );

    assert.deepEqual(
      workbook.worksheets.map((sheet) => sheet.name),
      REQUIRED_SHEETS,
      '不得出现重复工作表',
    );

    const sheet = workbook.getWorksheet('Descriptive Statistics')!;
    assert.deepEqual(rowCells(sheet.getRow(1)), ['Variable Name', 'N', 'Mean']);
    assert.deepEqual(rowCells(sheet.getRow(2)), ['Q2', 3, 4]);
    assert.ok(
      !sheetText(workbook, 'Descriptive Statistics').includes(ANALYSIS_NOT_RUN_NOTE),
      '已有真实结果时不应再写「尚未运行」说明',
    );
  });

  test('未匹配到要求工作表的额外结果追加在工作簿末尾，而不是被丢弃', async () => {
    const workbook = await loadWorkbook(
      await toExcelBuffer(makeDataset(), makeContext(), [
        { name: 'Extra Notes', headers: ['Note'], rows: [['人工复核记录']] },
      ]),
    );

    assert.deepEqual(
      workbook.worksheets.map((sheet) => sheet.name),
      [...REQUIRED_SHEETS, 'Extra Notes'],
    );
    assert.deepEqual(rowCells(workbook.getWorksheet('Extra Notes')!.getRow(2)), ['人工复核记录']);
  });

  test('Raw Data 首列是 respondent_id，表头加粗并冻结首行首列', async () => {
    const workbook = await loadWorkbook(await toExcelBuffer(makeDataset(), makeContext()));
    const sheet = workbook.getWorksheet('Raw Data')!;

    assert.equal(sheet.getRow(1).getCell(1).value, 'respondent_id');
    assert.equal(sheet.getRow(1).getCell(2).value, 'Q1');
    assert.equal(sheet.getRow(1).font?.bold, true);

    const view = sheet.views[0] as { state?: string; xSplit?: number; ySplit?: number };
    assert.equal(view.state, 'frozen');
    assert.equal(view.xSplit, 1);
    assert.equal(view.ySplit, 1);
  });

  test('Excel 中的缺失是空单元格，不是 0', async () => {
    const dataset = makeDataset();
    const workbook = await loadWorkbook(await toExcelBuffer(dataset, makeContext()));
    const sheet = workbook.getWorksheet('Raw Data')!;

    // 第 3 行是第三位受访者（拒答 Q1），第 4 列对应 AGE。
    const refused = sheet.getRow(4).getCell(2).value;
    const missingAge = sheet.getRow(3).getCell(4).value;
    assert.ok(refused === null || refused === undefined || refused === '', '拒答必须是空单元格');
    assert.ok(missingAge === null || missingAge === undefined || missingAge === '', '缺失必须是空单元格');
    assert.notEqual(refused, 0);
    assert.notEqual(missingAge, 0);
  });

  test('Variable Dictionary 使用规定列，并在缺少题目定义时标注来源', async () => {
    const dataset = makeDataset();

    const withoutQuestions = await loadWorkbook(await toExcelBuffer(dataset, makeContext()));
    const plain = withoutQuestions.getWorksheet('Variable Dictionary')!;
    assert.deepEqual(rowCells(plain.getRow(1)), DICTIONARY_HEADERS);
    // 没有题目定义时，无法从 DatasetVariable 推出的列必须明确标注，而不是编造。
    const plainQ1 = rowCells(plain.getRow(2));
    assert.equal(plainQ1[5], '见变量字典接口');
    assert.equal(plainQ1[9], '否');

    const withQuestions = await loadWorkbook(
      await toExcelBuffer(dataset, makeContext({ questions: [makeQuestion()] })),
    );
    const detailed = withQuestions.getWorksheet('Variable Dictionary')!;
    const detailedQ1 = rowCells(detailed.getRow(2));
    assert.notEqual(detailedQ1[5], '见变量字典接口');
    assert.ok(String(detailedQ1[5]).includes('名义分类编码'), '编码说明应来自变量字典');
    assert.ok(String(detailedQ1[6]).includes('敏感拒答'), '缺失说明应指出敏感拒答的处理');
  });

  test('Codebook 工作表给出选项代码到标签的映射', async () => {
    const workbook = await loadWorkbook(await toExcelBuffer(makeDataset(), makeContext()));
    const sheet = workbook.getWorksheet('Codebook')!;

    assert.deepEqual(rowCells(sheet.getRow(1)), CODEBOOK_HEADERS);
    const text = sheetText(workbook, 'Codebook');
    assert.ok(text.includes('男'));
    assert.ok(text.includes('总是'));
  });
});

/* ------------------------------------------------------------------ */
/* File names                                                         */
/* ------------------------------------------------------------------ */

describe('导出：文件名', () => {
  test('剔除 Windows 非法字符并带上导出日期', () => {
    const names = exportFilenames(makeContext({ projectTitle: 'A/B:C*D?E"F<G>H|I\\J' }));

    for (const name of Object.values(names)) {
      assert.ok(!/[\\/:*?"<>|]/.test(name), `文件名仍含非法字符：${name}`);
      assert.ok(name.startsWith('A-B-C-D-E-F-G-H-I-J-2025-03-08'), name);
    }

    assert.equal(names.csv, 'A-B-C-D-E-F-G-H-I-J-2025-03-08.csv');
    assert.equal(names.json, 'A-B-C-D-E-F-G-H-I-J-2025-03-08.json');
    assert.equal(names.spssData, 'A-B-C-D-E-F-G-H-I-J-2025-03-08-spss.csv');
    assert.equal(names.spssSyntax, 'A-B-C-D-E-F-G-H-I-J-2025-03-08-spss.sps');
    assert.equal(names.excel, 'A-B-C-D-E-F-G-H-I-J-2025-03-08.xlsx');
  });

  test('不会逃出目标目录（路径分隔符与 .. 都被清理）', () => {
    const names = exportFilenames(makeContext({ projectTitle: '..\\..\\etc/passwd' }));

    for (const name of Object.values(names)) {
      assert.ok(!name.includes('/') && !name.includes('\\'), `文件名含路径分隔符：${name}`);
      assert.ok(!name.includes('..'), `文件名含目录穿越片段：${name}`);
    }
  });

  test('保留中文标题，空标题与保留设备名也有安全兜底', () => {
    const chinese = exportFilenames(makeContext({ projectTitle: '城市家庭教育研究' }));
    assert.equal(chinese.csv, '城市家庭教育研究-2025-03-08.csv');

    assert.ok(exportFilenames(makeContext({ projectTitle: '   ' })).csv.startsWith('export-'));
    assert.ok(exportFilenames(makeContext({ projectTitle: 'CON' })).csv.startsWith('_CON-'));
  });
});
