﻿/**
 * Group comparison box plot (one box per group, laid out as rows).
 *
 * IMPORTANT — what the box is made of is stated on the chart, not assumed.
 * `anova.groups` carries only n, mean, sd, min and max; medians, quartiles and
 * case-level outliers are not part of that payload. When a caller can supply
 * quartiles the box is the conventional median/Q1/Q3 box with min–max whiskers.
 * When it cannot, the component draws a mean ± 1 SD box — and says so in the
 * row label and the caption — rather than silently presenting a standard
 * deviation as if it were an interquartile range.
 */

import type { ReactNode } from 'react';
import { formatStat, truncate } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg, axisTicks } from './primitives';

export interface BoxPlotGroup {
  label: string;
  n: number;
  /** Conventional box, used when all three quartile values are present. */
  median?: number | null;
  q1?: number | null;
  q3?: number | null;
  /** Fallback basis: a mean ± 1 SD box with min–max whiskers. */
  mean?: number | null;
  sd?: number | null;
  minimum?: number | null;
  maximum?: number | null;
  /** Case-level outliers, when the caller has them. */
  outliers?: number[];
}

export interface BoxPlotProps {
  groups: BoxPlotGroup[];
  /** Value axis title, e.g. the dependent variable's name. */
  valueLabel?: string;
  emptyText?: string;
  caption?: ReactNode;
}

const WIDTH = 680;
const ROW_HEIGHT = 46;
const BOX_HEIGHT = 16;
const AXIS_HEIGHT = 30;

interface Geometry {
  basis: 'quartiles' | 'mean_sd';
  low: number;
  q1: number;
  q3: number;
  high: number;
  centre: number;
  summary: string;
}

function geometryOf(group: BoxPlotGroup): Geometry | null {
  const { median, q1, q3, mean, sd, minimum, maximum } = group;
  const hasQuartiles =
    typeof q1 === 'number' &&
    typeof q3 === 'number' &&
    typeof median === 'number' &&
    Number.isFinite(q1) &&
    Number.isFinite(q3) &&
    Number.isFinite(median);

  if (hasQuartiles) {
    const low = typeof minimum === 'number' && Number.isFinite(minimum) ? Math.min(minimum, q1!) : q1!;
    const high = typeof maximum === 'number' && Number.isFinite(maximum) ? Math.max(maximum, q3!) : q3!;
    return {
      basis: 'quartiles',
      low,
      q1: q1!,
      q3: q3!,
      high,
      centre: median!,
      summary: `n = ${group.n} · 中位数 ${formatStat(median, 2)} · Q1 ${formatStat(q1, 2)} · Q3 ${formatStat(q3, 2)}`,
    };
  }

  if (typeof mean === 'number' && Number.isFinite(mean)) {
    const spread = typeof sd === 'number' && Number.isFinite(sd) ? sd : 0;
    const low =
      typeof minimum === 'number' && Number.isFinite(minimum) ? Math.min(minimum, mean - spread) : mean - spread;
    const high =
      typeof maximum === 'number' && Number.isFinite(maximum) ? Math.max(maximum, mean + spread) : mean + spread;
    return {
      basis: 'mean_sd',
      low,
      q1: mean - spread,
      q3: mean + spread,
      high,
      centre: mean,
      summary: `n = ${group.n} · 均值 ${formatStat(mean, 2)} · SD ${formatStat(spread, 2)}`,
    };
  }

  return null;
}

export function BoxPlot({
  groups,
  valueLabel,
  emptyText = '暂无可展示的组间分布数据。',
  caption,
}: BoxPlotProps): ReactNode {
  const drawable = groups
    .map((group) => ({ group, geometry: geometryOf(group) }))
    .filter((entry): entry is { group: BoxPlotGroup; geometry: Geometry } => entry.geometry !== null);

  if (drawable.length === 0) return <ChartEmpty text={emptyText} />;

  const values = drawable.flatMap(({ geometry }) => [geometry.low, geometry.high]);
  const dataMin = Math.min(...values);
  const dataMax = Math.max(...values);
  // A little headroom so the whisker caps never sit on the plot edge.
  const padding = dataMax === dataMin ? Math.max(Math.abs(dataMax) * 0.1, 1) : (dataMax - dataMin) * 0.04;
  const min = dataMin - padding;
  const max = dataMax + padding;
  const scale = (value: number) => ((value - min) / (max - min)) * WIDTH;
  const ticks = axisTicks(min, max, 4);
  const usesMeanSd = drawable.some((entry) => entry.geometry.basis === 'mean_sd');
  const height = 4 + drawable.length * ROW_HEIGHT + AXIS_HEIGHT;

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={height} label="组间比较箱线图">
        {/* Zero reference, when the scale crosses it. */}
        {min < 0 && max > 0 && (
          <line
            x1={scale(0)}
            y1={2}
            x2={scale(0)}
            y2={4 + drawable.length * ROW_HEIGHT}
            stroke="#b1bac9"
            strokeWidth={1}
            strokeDasharray="3 3"
          />
        )}

        {drawable.map(({ group, geometry }, index) => {
          const rowTop = 4 + index * ROW_HEIGHT;
          const boxTop = rowTop + 18;
          const mid = boxTop + BOX_HEIGHT / 2;
          return (
            <g key={`${group.label}-${index}`}>
              <text x={0} y={rowTop + 11} fontSize={FONT} fill="#3a4150">
                {truncate(group.label, 28)}
              </text>
              <text x={WIDTH} y={rowTop + 11} fontSize={FONT_SMALL} fill="#535f74" textAnchor="end">
                {geometry.summary}
              </text>

              {/* Whiskers and caps. */}
              <line x1={scale(geometry.low)} y1={mid} x2={scale(geometry.high)} y2={mid} stroke="#535f74" strokeWidth={1} />
              <line x1={scale(geometry.low)} y1={mid - 5} x2={scale(geometry.low)} y2={mid + 5} stroke="#535f74" strokeWidth={1} />
              <line x1={scale(geometry.high)} y1={mid - 5} x2={scale(geometry.high)} y2={mid + 5} stroke="#535f74" strokeWidth={1} />

              {/* Box: quartiles, or mean ± 1 SD when quartiles are unavailable. */}
              <rect
                x={scale(geometry.q1)}
                y={boxTop}
                width={Math.max(scale(geometry.q3) - scale(geometry.q1), 1)}
                height={BOX_HEIGHT}
                fill={geometry.basis === 'quartiles' ? '#bcd3ff' : '#d5dae3'}
                stroke="#1f47f5"
                strokeWidth={1}
                strokeDasharray={geometry.basis === 'quartiles' ? undefined : '4 2'}
              />
              <line
                x1={scale(geometry.centre)}
                y1={boxTop}
                x2={scale(geometry.centre)}
                y2={boxTop + BOX_HEIGHT}
                stroke="#1f47f5"
                strokeWidth={2}
              />

              {(group.outliers ?? []).map((outlier) => (
                <circle
                  key={outlier}
                  cx={scale(outlier)}
                  cy={mid}
                  r={2.5}
                  fill="none"
                  stroke="#c8222c"
                  strokeWidth={1.2}
                />
              ))}
            </g>
          );
        })}

        {ticks.map((tick) => (
          <g key={tick}>
            <line
              x1={scale(tick)}
              y1={4 + drawable.length * ROW_HEIGHT}
              x2={scale(tick)}
              y2={4 + drawable.length * ROW_HEIGHT + 4}
              stroke="#b1bac9"
              strokeWidth={1}
            />
            <text
              x={scale(tick)}
              y={4 + drawable.length * ROW_HEIGHT + 16}
              fontSize={FONT_SMALL}
              fill="#68778e"
              textAnchor="middle"
            >
              {formatStat(tick, tick % 1 === 0 ? 0 : 2)}
            </text>
          </g>
        ))}
        {valueLabel && (
          <text
            x={WIDTH}
            y={4 + drawable.length * ROW_HEIGHT + 28}
            fontSize={FONT_SMALL}
            fill="#68778e"
            textAnchor="end"
          >
            {valueLabel}
          </text>
        )}
      </ResponsiveSvg>

      <ChartCaption>
        {caption ?? (
          <>
            箱体与触须按可用统计量绘制。
            {usesMeanSd && (
              <span className="text-amber-700">
                {' '}
                本接口未提供中位数与四分位数，故虚线箱体为「均值 ± 1 个标准差」，触须为最小值与最大值；
                这不是四分位距，报告中须如实说明。
              </span>
            )}
          </>
        )}
      </ChartCaption>
    </div>
  );
}
