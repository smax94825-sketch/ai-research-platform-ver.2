/**
 * Shares of a whole (donut by default).
 *
 * The legend is the primary read-out — it lists the label, the count and the
 * percentage for every slice — and the percentages are also printed inside the
 * slices that are wide enough to hold text. A pie chart that can only be read
 * by comparing angles is not a data display, so the numbers are always spelled
 * out.
 */

import type { ReactNode } from 'react';
import { truncate } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg } from './primitives';

export interface PieDatum {
  label: string;
  value: number;
}

export interface PieChartProps {
  data: PieDatum[];
  /** Denominator for the shares. Defaults to the sum of `data`. */
  total?: number;
  unit?: string;
  /** Ring vs solid pie. */
  donut?: boolean;
  emptyText?: string;
  caption?: ReactNode;
}

const SIZE = 220;
const CENTRE = SIZE / 2;
const OUTER = 92;
const INNER = 50;

const PALETTE = [
  '#1f47f5',
  '#598eff',
  '#0f9d8f',
  '#8eb6ff',
  '#c8222c',
  '#f0a13a',
  '#68778e',
  '#8b5cf6',
];

/** Slice path; angles are degrees clockwise from 12 o'clock. */
function slicePath(startAngle: number, endAngle: number, inner: number): string {
  const toPoint = (angle: number, radius: number): [number, number] => {
    const radians = ((angle - 90) * Math.PI) / 180;
    return [CENTRE + radius * Math.cos(radians), CENTRE + radius * Math.sin(radians)];
  };
  const [x1, y1] = toPoint(startAngle, OUTER);
  const [x2, y2] = toPoint(endAngle, OUTER);
  const [x3, y3] = toPoint(endAngle, inner);
  const [x4, y4] = toPoint(startAngle, inner);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return [
    `M ${x1} ${y1}`,
    `A ${OUTER} ${OUTER} 0 ${largeArc} 1 ${x2} ${y2}`,
    `L ${x3} ${y3}`,
    inner > 0 ? `A ${inner} ${inner} 0 ${largeArc} 0 ${x4} ${y4}` : `L ${CENTRE} ${CENTRE}`,
    'Z',
  ].join(' ');
}

export function PieChart({
  data,
  total,
  unit = '人',
  donut = true,
  emptyText = '暂无可展示的构成数据。',
  caption,
}: PieChartProps): ReactNode {
  const denominator = total ?? data.reduce((sum, item) => sum + item.value, 0);
  if (data.length === 0 || denominator <= 0) return <ChartEmpty text={emptyText} />;

  const inner = donut ? INNER : 0;
  let angle = 0;

  return (
    <div>
      <ResponsiveSvg width={SIZE} height={SIZE} label="构成占比饼图">
        {data.map((item, index) => {
          const share = item.value / denominator;
          const start = angle;
          const end = angle + share * 360;
          angle = end;
          const fill = PALETTE[index % PALETTE.length]!;
          const midAngle = (start + end) / 2;
          const radians = ((midAngle - 90) * Math.PI) / 180;
          const labelRadius = (OUTER + inner) / 2;
          const percent = share * 100;

          // A single slice covering everything cannot be drawn as an arc.
          if (share >= 0.9999) {
            return (
              <circle
                key={item.label}
                cx={CENTRE}
                cy={CENTRE}
                r={(OUTER + inner) / 2}
                fill="none"
                stroke={fill}
                strokeWidth={OUTER - inner}
              />
            );
          }

          return (
            <g key={item.label}>
              <path d={slicePath(start, end, inner)} fill={fill} stroke="#ffffff" strokeWidth={1} />
              {percent >= 6 && (
                <text
                  x={CENTRE + labelRadius * Math.cos(radians)}
                  y={CENTRE + labelRadius * Math.sin(radians) + 4}
                  fontSize={FONT}
                  fill="#ffffff"
                  textAnchor="middle"
                >
                  {`${percent.toFixed(1)}%`}
                </text>
              )}
            </g>
          );
        })}
        {donut && (
          <>
            <text x={CENTRE} y={CENTRE - 2} fontSize={FONT_SMALL} fill="#68778e" textAnchor="middle">
              合计
            </text>
            <text
              x={CENTRE}
              y={CENTRE + 15}
              fontSize={18}
              fill="#333945"
              textAnchor="middle"
              fontWeight="600"
            >
              {`${denominator}`}
            </text>
          </>
        )}
      </ResponsiveSvg>

      <ul className="mt-3 space-y-1 text-xs text-ink-600">
        {data.map((item, index) => {
          const percent = denominator > 0 ? (item.value / denominator) * 100 : 0;
          return (
            <li key={item.label} className="flex items-center gap-2">
              <span
                className="inline-block h-2.5 w-2.5 shrink-0 rounded-sm"
                style={{ backgroundColor: PALETTE[index % PALETTE.length]! }}
              />
              <span className="min-w-0 flex-1 truncate" title={item.label}>
                {truncate(item.label, 32)}
              </span>
              <span className="shrink-0 tabular-nums text-ink-700">
                {`${item.value} ${unit}`}
              </span>
              <span className="w-14 shrink-0 text-right tabular-nums text-ink-500">
                {`${percent.toFixed(1)}%`}
              </span>
            </li>
          );
        })}
      </ul>

      <ChartCaption>{caption ?? `合计 ${denominator} ${unit}；百分比按合计计算。`}</ChartCaption>
    </div>
  );
}
