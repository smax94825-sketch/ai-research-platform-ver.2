/**
 * Identifier and timestamp helpers.
 *
 * Entity ids are UUIDv4 so that records can be merged across devices without
 * collisions. Share tokens and anonymous respondent ids are generated
 * separately: share tokens must be unguessable, while anonymous ids are only
 * unique within a questionnaire and deliberately carry no personal meaning.
 */

import { randomBytes, randomUUID } from 'node:crypto';

export function newId(): string {
  return randomUUID();
}

export function nowIso(): string {
  return new Date().toISOString();
}

/**
 * URL-safe share token for public survey links.
 * 24 characters of base64url ≈ 144 bits of entropy, short enough to place in a
 * QR code but far beyond brute-force range.
 */
export function generateShareToken(): string {
  return randomBytes(18).toString('base64url');
}

/**
 * Anonymous respondent code, e.g. A0001.
 * Sequential within a questionnaire so researchers can reference a case in
 * reports without exposing who the respondent is.
 */
export function formatAnonymousId(sequence: number): string {
  if (!Number.isInteger(sequence) || sequence < 1) {
    throw new RangeError(`formatAnonymousId expects a positive integer, received ${sequence}`);
  }
  return `A${String(sequence).padStart(4, '0')}`;
}

/** Parse the numeric part of an anonymous id; returns 0 when not in A#### form. */
export function parseAnonymousId(anonymousId: string): number {
  const match = /^A(\d{1,8})$/.exec(anonymousId);
  return match ? Number(match[1]) : 0;
}

/**
 * Version bump helper: "V1.0" -> "V1.1", with `major` bumping to the next
 * whole number ("V1.1" -> "V2.0").
 */
export function nextVersion(current: string, kind: 'minor' | 'major' = 'minor'): string {
  const match = /^V?(\d+)\.(\d+)$/.exec(current.trim());
  if (!match) return kind === 'major' ? 'V2.0' : 'V1.1';
  const major = Number(match[1]);
  const minor = Number(match[2]);
  return kind === 'major' ? `V${major + 1}.0` : `V${major}.${minor + 1}`;
}
