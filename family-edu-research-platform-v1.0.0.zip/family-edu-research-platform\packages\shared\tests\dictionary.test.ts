/**
 * Variable dictionary and validation tests.
 *
 * The dictionary is the contract between the platform and any external
 * statistics package (SPSS / R / Stata), so its variable names, measurement
 * levels and missing-value declarations must be exactly right.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  FAMILY_EDU_V4_TEMPLATE,
  buildVariableDictionary,
  describeCoding,
  describeMissing,
  describeScoringRule,
  dictionaryToCsv,
  inferAnalysisMethod,
  inferDataType,
  validateProjectInput,
  validateQuestionInput,
  validateQuestionnaireForPublish,
  type Question,
  type QuestionSeed,
} from '../src/index.js';

const seeds: QuestionSeed[] = FAMILY_EDU_V4_TEMPLATE.questions;

function buildQuestions(): Question[] {
  return seeds.map((seed, index) => ({
    id: `seed-${seed.question_code}`,
    questionnaire_id: 'qn-v4',
    question_code: seed.question_code,
    question_text: seed.question_text,
    question_type: seed.question_type,
    options: seed.options,
    required: seed.required,
    dimension: seed.dimension,
    variable_name: seed.variable_name,
    sort_order: index + 1,
    section: seed.section,
    help_text: seed.help_text,
    logic: seed.logic,
    scoring_rule: seed.scoring_rule,
    created_at: '2025-01-01T00:00:00.000Z',
    updated_at: '2025-01-01T00:00:00.000Z',
  }));
}

const questions = buildQuestions();
const dictionary = buildVariableDictionary(questions);
const byName = new Map(dictionary.map((d) => [d.variable_name, d]));

/* ------------------------------------------------------------------ */

describe('变量字典生成', () => {
  test('每道可作答题目都在字典中有对应条目', () => {
    for (const seed of seeds) {
      if (seed.question_type === 'page_break') continue;
      const found = dictionary.some((d) => d.question_code === seed.question_code);
      assert.ok(found, `题目 ${seed.question_code} 未出现在变量字典中`);
    }
  });

  test('字典按题目顺序生成，便于人工核对', () => {
    const codes = dictionary.map((d) => d.question_code);
    const firstIndex = codes.indexOf('Q6');
    const laterIndex = codes.indexOf('Q22');
    assert.ok(firstIndex >= 0 && laterIndex > firstIndex, '字典条目应按题目顺序排列');
  });

  test('矩阵题展开为逐行变量，并额外给出维度均值变量', () => {
    const rowItems = dictionary.filter((d) => /^FED\d+$/.test(d.variable_name));
    assert.equal(rowItems.length, 7, 'Q35 应展开为 7 个行变量');
    assert.deepEqual(
      rowItems.map((d) => d.variable_name),
      ['FED1', 'FED2', 'FED3', 'FED4', 'FED5', 'FED6', 'FED7'],
    );
    const composite = byName.get('FED');
    assert.ok(composite);
    assert.equal(composite.is_derived, true);
    assert.equal(composite.data_type, 'interval');
  });

  test('矩阵行变量标记为 ordinal，符合量表测量层次', () => {
    const row = byName.get('FSE1') ?? byName.get('FED1');
    assert.ok(row);
    assert.equal(row.data_type, 'ordinal');
  });

  test('包含全部 15 个核心变量条目', () => {
    for (const name of [
      'FEI', 'FEK', 'LSK', 'LKA', 'ISC', 'FSE',
      'FPB', 'FED', 'FIU', 'PSA', 'STI', 'DSD', 'WTP', 'UI', 'QN',
    ]) {
      assert.ok(byName.has(name), `变量字典缺少核心变量 ${name}`);
    }
  });

  test('LKA 声明为派生变量并注明理论取值 0—5', () => {
    const lka = byName.get('LKA');
    assert.ok(lka);
    assert.equal(lka.is_derived, true);
    assert.equal(lka.data_type, 'interval');
    assert.match(lka.coding, /0—5|Q12/);
    assert.match(lka.question_code, /Q12/);
  });

  test('SPSS 变量名长度不超过 32 字符且以字母开头', () => {
    for (const def of dictionary) {
      assert.match(def.variable_name, /^[A-Za-z][A-Za-z0-9_]*$/, `${def.variable_name} 不是合法变量名`);
      assert.ok(def.variable_name.length <= 32, `${def.variable_name} 超过 32 字符`);
    }
  });

  test('每个条目都填写了数据类型、编码、缺失值、计分规则与分析方法', () => {
    for (const def of dictionary) {
      assert.ok(def.data_type, `${def.variable_name} 缺少数据类型`);
      assert.ok(def.coding.length > 0, `${def.variable_name} 缺少编码说明`);
      assert.ok(def.missing_value.length > 0, `${def.variable_name} 缺少缺失值说明`);
      assert.ok(def.scoring_rule.length > 0, `${def.variable_name} 缺少计分规则`);
      assert.ok(def.analysis_method.length > 0, `${def.variable_name} 缺少分析方法`);
    }
  });
});

describe('缺失值与敏感题在字典中的声明', () => {
  test('Q32 的缺失值说明明确指出拒答不等于"从未"', () => {
    const def = byName.get('FPB_PUNISH');
    assert.ok(def);
    assert.match(def.missing_value, /拒答|不愿回答/);
    assert.match(def.missing_value, /单独编码/);
  });

  test('Q32 的编码说明保留 0—3 的严重程度序列，并把拒答映射为缺失', () => {
    const def = byName.get('FPB_PUNISH');
    assert.ok(def);
    assert.match(def.coding, /5→缺失/);
    assert.match(def.coding, /1→0/);
  });

  test('Q44"不了解，无法判断"在缺失说明中被列出', () => {
    const def = byName.get('PSA2');
    assert.ok(def);
    assert.match(def.missing_value, /6|缺失/);
  });

  test('普通题目也声明未作答按缺失处理且不填补', () => {
    const def = byName.get('FSE1');
    assert.ok(def);
    assert.match(def.missing_value, /未作答＝系统缺失/);
    assert.match(def.missing_value, /不填补/);
  });
});

describe('测量层次与分析方法的匹配', () => {
  test('Likert 题为 ordinal，分析方法为非参数检验与有序回归', () => {
    const def = byName.get('UI');
    assert.ok(def);
    assert.equal(def.data_type, 'ordinal');
    assert.match(def.analysis_method, /有序 Logistic 回归/);
    assert.match(def.analysis_method, /Mann-Whitney|Kruskal-Wallis/);
  });

  test('多选题为 count 类型', () => {
    const def = byName.get('ISCB');
    assert.ok(def);
    assert.equal(def.data_type, 'count');
  });

  test('计数变量的分析方法不包含参数检验误用', () => {
    const method = inferAnalysisMethod({ question_type: 'multiple' } as Question, 'count');
    assert.match(method, /非参数/);
  });

  test('文本题声明不参与数值统计', () => {
    const def = byName.get('OPN');
    assert.ok(def);
    assert.equal(def.data_type, 'text');
    assert.match(def.analysis_method, /主题编码|文本/);
  });

  test('知识题为 interval 且编码为 0/1', () => {
    const def = byName.get('LKA1');
    assert.ok(def);
    assert.equal(def.data_type, 'interval');
    assert.match(def.coding, /答对＝1/);
    assert.match(def.coding, /不清楚/);
  });

  test('五级人口学变量被识别为 ordinal（有序映射）', () => {
    const edu = seeds.find((s) => s.question_code === 'Q3')!;
    const instrument: Question = {
      ...questions[2]!,
      question_type: edu.question_type,
      options: edu.options,
      scoring_rule: edu.scoring_rule,
    };
    assert.equal(inferDataType(instrument), 'ordinal');
  });

  test('无有序映射的四分类变量被识别为 nominal', () => {
    const role = seeds.find((s) => s.question_code === 'Q1')!;
    const instrument: Question = {
      ...questions[0]!,
      question_type: role.question_type,
      options: role.options,
      scoring_rule: role.scoring_rule,
    };
    assert.equal(inferDataType(instrument), 'nominal');
    assert.match(inferAnalysisMethod(instrument, 'nominal'), /卡方检验/);
  });

  test('反向计分规则在字典中说明反转公式', () => {
    const text = describeScoringRule({ type: 'reverse', min: 1, max: 6 });
    assert.match(text, /1＋6－原始分/);
  });

  test('知识计分规则在字典中给出完整得分口径', () => {
    const text = describeScoringRule({
      type: 'knowledge',
      correctScore: 1,
      incorrectScore: 0,
      unknownScore: 0,
      maxScore: 1,
    });
    assert.match(text, /答对＝1/);
    assert.match(text, /0—1/);
  });

  test('矩阵题的编码说明列出全部行变量代码', () => {
    const text = describeCoding(question35());
    assert.match(text, /FED1/);
    assert.match(text, /FED7/);
  });

  test('多选题的编码说明指出互斥选项被排除', () => {
    const q42 = questions.find((x) => x.question_code === 'Q42')!;
    assert.match(describeCoding(q42), /互斥/);
  });

  test('describeMissing 对无敏感选项的题目只声明系统缺失', () => {
    const q6 = questions.find((x) => x.question_code === 'Q6')!;
    const text = describeMissing(q6);
    assert.match(text, /系统缺失/);
    assert.ok(!text.includes('拒答'));
  });
});

function question35(): Question {
  const found = questions.find((x) => x.question_code === 'Q35');
  if (!found) throw new Error('Q35 missing');
  return found;
}

describe('字典导出为 CSV', () => {
  const csv = dictionaryToCsv(dictionary);
  const lines = csv.split('\n');

  test('包含规范的列标题', () => {
    assert.equal(
      lines[0],
      'Variable Name,Question Code,Question Text,Dimension,Data Type,Coding,Missing Value,Scoring Rule,Analysis Method,Derived,Note',
    );
  });

  test('行数与字典条目数一致', () => {
    assert.equal(lines.length, dictionary.length + 1);
  });

  test('含逗号或引号的字段被正确转义', () => {
    const tricky = dictionaryToCsv([
      {
        variable_name: 'X',
        question_code: 'Q1',
        question_text: '包含,逗号与"引号"的题干',
        dimension: 'D',
        data_type: 'nominal',
        coding: 'a,b',
        missing_value: '无',
        scoring_rule: '无',
        analysis_method: '无',
        is_derived: false,
        note: '',
      },
    ]);
    const row = tricky.split('\n')[1]!;
    assert.ok(row.includes('"包含,逗号与""引号""的题干"'));
  });

  test('派生变量明确标注为"是"', () => {
    const derivedIndex = dictionary.findIndex((d) => d.variable_name === 'LKA');
    const row = lines[derivedIndex + 1]!;
    assert.ok(row.includes(',是,'), '派生变量应在 Derived 列标注为是');
  });
});

describe('题目输入校验', () => {
  test('接受合法的单选题', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: '测试题',
      question_type: 'single',
      options: { choices: [{ value: '1', label: 'A' }, { value: '2', label: 'B' }] },
    });
    assert.equal(result.valid, true);
  });

  test('拒绝空题号', () => {
    const result = validateQuestionInput({ question_code: '  ', question_text: 'x', question_type: 'text' });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.field === 'question_code'));
  });

  test('拒绝未知题型', () => {
    const result = validateQuestionInput({ question_code: 'Q1', question_text: 'x', question_type: 'hologram' });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.field === 'question_type'));
  });

  test('拒绝没有选项的选择题', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'single',
      options: { choices: [] },
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.field === 'options.choices'));
  });

  test('拒绝只有一个刻度的李克特量表', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'likert',
      options: { choices: [{ value: '1', label: 'A' }] },
    });
    assert.equal(result.valid, false);
  });

  test('拒绝没有行列定义的矩阵题', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'matrix',
      options: {},
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.field.includes('matrix')));
  });

  test('拒绝没有正确答案的知识测试题', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'knowledge_test',
      options: { choices: [{ value: '1', label: '正确' }, { value: '2', label: '错误' }] },
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.message.includes('正确答案')));
  });

  test('接受标注了正确答案的知识测试题', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'knowledge_test',
      options: {
        choices: [
          { value: '1', label: '正确', isCorrect: true },
          { value: '2', label: '错误' },
          { value: '3', label: '不清楚' },
        ],
      },
      scoring_rule: {
        type: 'knowledge',
        correctScore: 1,
        incorrectScore: 0,
        unknownScore: 0,
        maxScore: 1,
      },
    });
    assert.equal(result.valid, true);
  });

  test('拒绝重复的选项代码（会静默覆盖作答）', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'single',
      options: { choices: [{ value: '1', label: 'A' }, { value: '1', label: 'B' }] },
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.message.includes('重复')));
  });

  test('拒绝非法变量名（SPSS 不兼容）', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'text',
      variable_name: '2bad-name',
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.field === 'variable_name'));
  });

  test('拒绝缺少比较值的逻辑条件', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'single',
      options: { choices: [{ value: '1', label: 'A' }] },
      logic: {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'Q2', operator: 'eq' }],
            action: { type: 'jump_to', target: 'Q3' },
          },
        ],
      },
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.message.includes('比较值')));
  });

  test('接受 answered 这类不需要比较值的运算符', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'single',
      options: { choices: [{ value: '1', label: 'A' }] },
      logic: {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'Q2', operator: 'answered' }],
            action: { type: 'require' },
          },
        ],
      },
    });
    assert.equal(result.valid, true);
  });

  test('分类编码缺少选项映射时给出错误（防止静默丢数据）', () => {
    const result = validateQuestionInput({
      question_code: 'Q1',
      question_text: 'x',
      question_type: 'single',
      options: { choices: [{ value: '1', label: 'A' }, { value: '2', label: 'B' }] },
      scoring_rule: { type: 'categorical', codes: { '1': 1 } },
    });
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.message.includes('选项 2')));
  });

  test('V4.0 模板的每道题都通过校验（含分类编码完整性）', () => {
    for (const seed of seeds) {
      const result = validateQuestionInput(seed);
      assert.equal(
        result.valid,
        true,
        `${seed.question_code} 校验失败：${result.errors.map((e) => e.message).join('; ')}`,
      );
    }
  });
});

describe('发布前问卷校验', () => {
  test('接受完整的 V4.0 问卷', () => {
    const result = validateQuestionnaireForPublish(questions);
    assert.equal(result.valid, true);
  });

  test('拒绝没有任何可作答题目的问卷', () => {
    const result = validateQuestionnaireForPublish([
      { question_code: 'P1', question_type: 'page_break', question_text: '', sort_order: 1 },
    ]);
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.message.includes('至少需要一道')));
  });

  test('拒绝题号重复的问卷', () => {
    const result = validateQuestionnaireForPublish([
      { question_code: 'Q1', question_type: 'text', question_text: 'a', sort_order: 1 },
      { question_code: 'Q1', question_type: 'text', question_text: 'b', sort_order: 2 },
    ]);
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.message.includes('重复')));
  });

  test('排序不连续时给出警告而非错误', () => {
    const result = validateQuestionnaireForPublish([
      { question_code: 'Q1', question_type: 'text', question_text: 'a', sort_order: 1 },
      { question_code: 'Q2', question_type: 'text', question_text: 'b', sort_order: 5 },
    ]);
    assert.equal(result.valid, true);
    assert.ok(result.warnings.some((w) => w.field === 'sort_order'));
  });
});

describe('研究项目输入校验', () => {
  test('接受合法项目', () => {
    const result = validateProjectInput({
      title: '家庭教育研究',
      target_sample_size: 500,
      research_questions: ['RQ1'],
      hypotheses: [{ code: 'H1', statement: 'x' }],
    });
    assert.equal(result.valid, true);
  });

  test('拒绝空研究名称', () => {
    assert.equal(validateProjectInput({ title: '   ' }).valid, false);
  });

  test('拒绝非正整数的目标样本量', () => {
    for (const bad of [0, -5, 3.5, 'abc', Number.NaN]) {
      assert.equal(validateProjectInput({ title: 'T', target_sample_size: bad }).valid, false);
    }
  });

  test('对过小样本量给出统计效力警告', () => {
    const result = validateProjectInput({ title: 'T', target_sample_size: 20 });
    assert.equal(result.valid, true);
    assert.ok(result.warnings.some((w) => w.message.includes('效力')));
  });

  test('拒绝超出平台上限的样本量', () => {
    assert.equal(validateProjectInput({ title: 'T', target_sample_size: 200000 }).valid, false);
  });

  test('缺少研究假设时给出警告（否则无法做假设检验）', () => {
    const result = validateProjectInput({ title: 'T', hypotheses: [] });
    assert.equal(result.valid, true);
    assert.ok(result.warnings.some((w) => w.message.includes('假设检验')));
  });
});
