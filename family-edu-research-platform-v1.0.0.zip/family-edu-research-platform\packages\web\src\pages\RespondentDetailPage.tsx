/**
 * One sample, with every stored answer resolved for reading.
 *
 * Sensitive refusals arrive already labelled by the shared `describeAnswer`
 * helper, so a reader can never mistake "不愿回答" for a substantive category.
 * Hidden questions (not administered on this respondent's path) are listed
 * separately, because "no answer" and "never asked" are different facts.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useParams } from 'react-router-dom';
import { REVIEW_STATUS_LABELS, SOURCE_LABELS } from '@ferp/shared';
import { Alert, Badge, Button, Card, CardHeader, LoadingBlock } from '../components/ui';
import {
  api,
  ApiClientError,
  type QualityFlagRecord,
  type RespondentDetail,
  type RespondentQualityView,
} from '../lib/api';
import { formatDateTime, formatDuration, questionTypeLabel } from '../lib/format';

export function RespondentDetailPage(): ReactNode {
  const { respondentId = '' } = useParams();
  const [detail, setDetail] = useState<RespondentDetail | null>(null);
  const [quality, setQuality] = useState<RespondentQualityView | null>(null);
  const [loading, setLoading] = useState(true);
  const [reseoring, setRescoring] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [sampleDetail, qualityView] = await Promise.all([
        api.samples.detail(respondentId),
        api.quality.respondent(respondentId),
      ]);
      setDetail(sampleDetail);
      setQuality(qualityView);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载样本详情。');
    } finally {
      setLoading(false);
    }
  }, [respondentId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function rescore(): Promise<void> {
    setRescoring(true);
    setError(null);
    try {
      const result = await api.quality.recomputeRespondent(respondentId);
      setQuality(result.view);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '重新评分失败。');
    } finally {
      setRescoring(false);
    }
  }

  if (loading) return <LoadingBlock label="正在加载样本…" />;
  if (!detail) {
    return (
      <Alert tone="danger" title="无法打开样本">
        {error ?? '样本不存在，或您没有访问权限。'}
      </Alert>
    );
  }

  const { respondent, responses, questionnaire } = detail;

  return (
    <div className="space-y-6">
      <div>
        <Link to="/collection/samples" className="text-sm text-ink-500 hover:text-ink-800">
          ← 返回样本列表
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="font-mono text-xl font-semibold text-ink-900">{respondent.anonymous_id}</h1>
          <Badge tone={respondent.status === 'completed' ? 'success' : respondent.status === 'abandoned' ? 'warning' : 'info'}>
            {respondent.status === 'completed' ? '已完成' : respondent.status === 'abandoned' ? '已中断' : '进行中'}
          </Badge>
          <Badge tone={respondent.review_status === 'excluded' ? 'danger' : respondent.review_status === 'accepted' ? 'success' : 'neutral'}>
            {REVIEW_STATUS_LABELS[respondent.review_status]}
          </Badge>
        </div>
        <p className="mt-1 text-sm text-ink-500">
          问卷「{questionnaire.title}」· 版本 {questionnaire.version}
        </p>
      </div>

      <Alert tone="info" title="匿名说明">
        本样本以匿名编号标识，平台未收集姓名、手机号、身份证号、住址或学校名称。
        来源 IP 仅以加盐哈希形式保存，用于后续识别明显的重复提交，无法还原为原始地址。
      </Alert>

      {respondent.review_note && (
        <Alert tone={respondent.review_status === 'excluded' ? 'warning' : 'info'} title="研究者审核说明">
          {respondent.review_note}
        </Alert>
      )}

      <Card>
        <CardHeader title="采集信息" />
        <dl className="grid gap-3 sm:grid-cols-3">
          <div>
            <dt className="text-xs text-ink-500">来源渠道</dt>
            <dd className="mt-0.5 text-sm text-ink-900">
              {SOURCE_LABELS[respondent.source] ?? respondent.source}
              <span className="ml-1 font-mono text-xs text-ink-400">({respondent.source})</span>
            </dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">开始时间</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{formatDateTime(respondent.started_at)}</dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">完成时间</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{formatDateTime(respondent.completed_at)}</dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">作答用时</dt>
            <dd className="mt-0.5 text-sm tabular-nums text-ink-900">
              {formatDuration(respondent.duration_seconds)}
            </dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">已保存作答</dt>
            <dd className="mt-0.5 text-sm tabular-nums text-ink-900">{detail.answered_count} 题</dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">知情同意时间</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{formatDateTime(respondent.consent_given_at)}</dd>
          </div>
        </dl>
      </Card>

      {/* Data quality ------------------------------------------------- */}
      {quality && (
        <Card>
          <CardHeader
            title="数据质量检测"
            description={`引擎版本 ${quality.engine_version ?? '—'} · 评分时间 ${formatDateTime(quality.computed_at)}`}
            actions={
              <Button loading={reseoring} onClick={() => void rescore()}>
                重新评分
              </Button>
            }
          />

          <div className="flex flex-wrap items-center gap-3">
            <div>
              <p className="text-xs text-ink-500">质量评分</p>
              <p className="text-2xl font-semibold tabular-nums text-ink-900">
                {quality.score === null ? '未评分' : quality.score}
              </p>
            </div>
            <Badge tone={qualityTone(quality.severity)}>{qualityLabel(quality.severity)}</Badge>
            <p className="text-xs text-ink-500">
              评分 = 100 − 各条命中规则的权重之和。评分低只代表<strong>需要复核</strong>，不代表作答无效。
            </p>
          </div>

          {quality.flags.length === 0 ? (
            <p className="mt-4 rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
              未命中任何质量规则，未发现可疑作答模式。
              {quality.score === null && '（该样本尚无作答，因此未评分。）'}
            </p>
          ) : (
            <ul className="mt-4 space-y-3">
              {quality.flags.map((flag) => (
                <li key={flag.rule_code} className="rounded-md border border-ink-200 p-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs text-ink-500">{flag.rule_code}</span>
                    <span className="text-sm font-medium text-ink-900">{flag.label}</span>
                    <Badge tone={qualityTone(flag.severity)}>{qualityLabel(flag.severity)}</Badge>
                    <span className="text-xs text-ink-500">扣 {flag.score_impact} 分</span>
                  </div>
                  <p className="mt-1.5 text-sm text-ink-700">{flag.detail}</p>
                  {Object.keys(flag.evidence).length > 0 && (
                    <p className="mt-1.5 break-all rounded bg-ink-50 px-2 py-1.5 font-mono text-[11px] text-ink-600">
                      {formatEvidence(flag)}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          )}

          <p className="mt-4 text-xs text-ink-500">
            是否采用该样本由您判断。如需排除，请前往
            <Link to={`/collection/samples?project=${respondent.questionnaire_id ? '' : ''}`} className="mx-1 text-brand-600 underline">
              样本列表
            </Link>
            使用「审核」填写排除原因——平台不会自动删除任何样本。
          </p>
        </Card>
      )}

      <Card padded={false}>
        <div className="border-b border-ink-200 px-5 py-4">
          <h2 className="text-base font-semibold text-ink-900">作答明细（{responses.length} 题）</h2>
          <p className="mt-1 text-sm text-ink-500">
            按问卷题目顺序排列，选项代码已解析为选项文本。
          </p>
        </div>

        {responses.length === 0 ? (
          <p className="px-5 py-8 text-center text-sm text-ink-400">该样本没有保存任何作答。</p>
        ) : (
          <ul className="divide-y divide-ink-100">
            {responses.map((response) => (
              <li key={response.question_id} className="px-5 py-3">
                <div className="flex flex-wrap items-baseline gap-2">
                  <span className="font-mono text-xs text-ink-500">{response.question_code}</span>
                  {response.variable_name && (
                    <span className="font-mono text-xs text-brand-700">{response.variable_name}</span>
                  )}
                  <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] text-ink-600">
                    {questionTypeLabel(response.question_type)}
                  </span>
                  {response.dimension && (
                    <span className="text-[10px] text-ink-400">{response.dimension}</span>
                  )}
                </div>
                <p className="mt-1 text-sm text-ink-700">{response.question_text}</p>
                <p className="mt-1.5 rounded bg-ink-50 px-2 py-1.5 text-sm text-ink-900">
                  {response.answer_label}
                </p>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {detail.hidden_question_codes.length > 0 && (
        <Card>
          <CardHeader
            title={`未被展示的题目（${detail.hidden_question_codes.length} 题）`}
            description="这些题目因该样本的作答路径（条件跳转）而未向其展示，因此没有作答——这与「未作答」是不同的情况。"
          />
          <div className="flex flex-wrap gap-1">
            {detail.hidden_question_codes.map((code) => (
              <span key={code} className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[10px] text-ink-600">
                {code}
              </span>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Presentation helpers                                               */
/* ------------------------------------------------------------------ */

function qualityTone(
  severity: string,
): 'neutral' | 'info' | 'success' | 'warning' | 'danger' {
  switch (severity) {
    case 'clean':
      return 'success';
    case 'info':
      return 'info';
    case 'warning':
      return 'warning';
    case 'critical':
      return 'danger';
    default:
      return 'neutral';
  }
}

function qualityLabel(severity: string): string {
  switch (severity) {
    case 'clean':
      return '未发现可疑模式';
    case 'info':
      return '提示';
    case 'warning':
      return '需复核';
    case 'critical':
      return '强烈建议复核';
    default:
      return '未评分';
  }
}

/** Render rule evidence compactly without hiding any of it. */
function formatEvidence(flag: QualityFlagRecord): string {
  return Object.entries(flag.evidence)
    .map(([key, value]) => `${key}=${typeof value === 'object' ? JSON.stringify(value) : String(value)}`)
    .join(' · ');
}
