﻿/**
 * Progress bars for "current vs target" (sample-size and quota tracking).
 *
 * Over/under target is encoded three ways, only one of which is colour:
 *   - the fill pattern (diagonal hatch below target, solid fill once met),
 *   - an explicit status word (未达目标 / 已达目标 / 超出目标),
 *   - and the numbers themselves (`current/target`, remaining or excess).
 * A colour-blind reader, or a greyscale printout, loses nothing.
 */

import { useId, type ReactNode } from 'react';
import { formatStat, truncate } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg } from './primitives';

export interface ProgressBarItem {
  label: string;
  current: number;
  /** The quota or planned sample size; 0 means "no target set". */
  target: number;
}

export interface ProgressBarProps {
  items: ProgressBarItem[];
  unit?: string;
  emptyText?: string;
  caption?: ReactNode;
}

const WIDTH = 680;
const ROW_HEIGHT = 44;

type Status = 'under' | 'met' | 'over' | 'no_target';

function statusOf(item: ProgressBarItem): Status {
  if (!(item.target > 0)) return 'no_target';
  if (item.current > item.target) return 'over';
  if (item.current === item.target) return 'met';
  return 'under';
}

const STATUS_LABEL: Record<Status, string> = {
  under: '未达目标',
  met: '已达目标',
  over: '超出目标',
  no_target: '未设定目标',
};

export function ProgressBar({
  items,
  unit = '份',
  emptyText = '暂无可展示的进度数据。',
  caption,
}: ProgressBarProps): ReactNode {
  const hatchId = `ferp-progress-hatch-${useId().replace(/[^a-zA-Z0-9_-]/g, '')}`;

  if (items.length === 0) return <ChartEmpty text={emptyText} />;

  const height = 4 + items.length * ROW_HEIGHT;

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={height} label="目标进度条形图">
        <defs>
          <pattern id={hatchId} width={6} height={6} patternTransform="rotate(45)" patternUnits="userSpaceOnUse">
            <rect width={6} height={6} fill="#f6f7f9" />
            <line x1={0} y1={0} x2={0} y2={6} stroke="#f0a13a" strokeWidth={3} />
          </pattern>
        </defs>

        {items.map((item, index) => {
          const rowTop = 4 + index * ROW_HEIGHT;
          const status = statusOf(item);
          const percent = item.target > 0 ? (item.current / item.target) * 100 : 0;
          const remaining = item.target - item.current;
          const barWidth = item.target > 0 ? Math.min(item.current / item.target, 1) * WIDTH : 0;

          const statusText =
            status === 'under'
              ? `${STATUS_LABEL[status]}（尚缺 ${remaining} ${unit}）`
              : status === 'over'
                ? `${STATUS_LABEL[status]}（超出 +${item.current - item.target} ${unit}）`
                : STATUS_LABEL[status];

          return (
            <g key={`${item.label}-${index}`}>
              <text x={0} y={rowTop + 11} fontSize={FONT} fill="#3a4150">
                {truncate(item.label, 26)}
              </text>
              <text x={WIDTH} y={rowTop + 11} fontSize={FONT_SMALL} fill="#535f74" textAnchor="end">
                {`${item.current}/${item.target} ${unit} · ${formatStat(percent, 1)}% · ${statusText}`}
              </text>
              <rect x={0} y={rowTop + 16} width={WIDTH} height={12} rx={3} fill="#eceef2" />
              {barWidth > 0 && (
                <rect
                  x={0}
                  y={rowTop + 16}
                  width={barWidth}
                  height={12}
                  rx={3}
                  fill={status === 'under' ? `url(#${hatchId})` : status === 'over' ? '#1a35e1' : '#0f9d8f'}
                  stroke={status === 'under' ? '#f0a13a' : 'none'}
                  strokeWidth={status === 'under' ? 1 : 0}
                />
              )}
              {barWidth > 0 && barWidth < WIDTH && (
                <line x1={barWidth} y1={rowTop + 16} x2={barWidth} y2={rowTop + 28} stroke="#333945" strokeWidth={1} />
              )}
              {status === 'no_target' && (
                <text x={WIDTH / 2} y={rowTop + 26} fontSize={FONT_SMALL} fill="#68778e" textAnchor="middle">
                  该项目未设定目标样本量
                </text>
              )}
            </g>
          );
        })}
      </ResponsiveSvg>

      <ChartCaption>
        {caption ?? '整条底色代表 100% 目标；斜纹填充表示未达目标，实心填充表示已达到或超出目标。'}
      </ChartCaption>
    </div>
  );
}
