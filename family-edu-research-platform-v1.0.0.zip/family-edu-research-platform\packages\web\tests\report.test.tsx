/**
 * Research report page tests (PHASE 8).
 *
 * The report is what a researcher submits, so these tests check that the page
 * cannot quietly turn a gap into prose:
 *   1. all 23 sections render, in the documented index order, with their titles,
 *   2. a section the platform could not fill shows the API's `unavailable_reason`
 *      and is visibly marked as needing the researcher,
 *   3. the "no analysis bundle yet" 400 is shown with the API's own Chinese
 *      message and a way to go run the analysis,
 *   4. the Markdown is downloadable (through the authenticated file helper, not a
 *      plain link) and copyable, with an honest fallback when the clipboard API
 *      is unavailable.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { fileResponse, stubDownloadHost } from './download';
import { click, flush, queryAll, render, text } from './render';

const { ReportPage } = await import('../src/pages/report/ReportPage');

/* ================================================================== */
/* Fixtures                                                           */
/* ================================================================== */

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育投入研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'analyzing',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

const CAVEATS = [
  '本研究采用横截面问卷调查数据，所有关联结论均为变量间的共变关系，不能据此推断因果关系。',
  '分析基于 350 份已完成且未被排除的样本。',
];

const LITERATURE_REASON =
  '平台在离线环境中运行，没有可检索的文献数据库，也未接入任何引文来源，因此无法自动生成文献综述。' +
  '任何自动生成的作者、年份、期刊名、卷期、页码或文献编号都无法被溯源，属于编造，平台不提供该功能。';

const REFERENCES_REASON =
  '平台不生成参考文献：离线环境没有文献来源，任何自动生成的条目都无法被溯源。' +
  '参考文献必须由研究者按目标期刊或评审要求自行撰写并逐条核对。';

interface SectionFixture {
  index: number;
  key: string;
  title: string;
  body: string;
  evidence: { path: string; value: string }[];
  available: boolean;
  unavailable_reason: string | null;
}

function filled(
  index: number,
  key: string,
  title: string,
  body: string,
  evidence: { path: string; value: string }[] = [],
): SectionFixture {
  return { index, key, title, body, evidence, available: true, unavailable_reason: null };
}

const SECTIONS: SectionFixture[] = [
  filled(
    1,
    'title_abstract',
    '标题与摘要',
    '本研究题目为「家庭教育投入研究」。本报告由平台统计引擎 1.0.0 依据结果包（分析生成时间 2026-02-01T09:30:00.000Z）自动生成，正文中的每一个数字都取自该结果包，未做任何人工调整。\n\n数据概况：共收集 500 份作答，其中已完成 400 份、作答中 70 份、中途退出 30 份；经研究者排除 50 份后，进入分析的样本为 350 份。\n\n> 本报告仅陈述数据中观察到的关系。横截面调查数据不能支持因果推断。',
    [
      { path: 'project.title', value: '家庭教育投入研究' },
      { path: 'sample.analysable', value: '350' },
    ],
  ),
  filled(2, 'background', '研究背景', '研究题目：家庭教育投入研究。所用问卷为「家庭教育投入问卷（4.0.0）」，共 58 道题目，展开为 42 个分析变量。'),
  filled(3, 'objectives', '研究目的与研究问题', '研究目的：在 350 份有效样本上，描述家长在家庭教育认知、实践、困难与服务需求等方面的现状水平，检验 3 条研究假设。'),
  filled(4, 'hypotheses', '研究假设', '本研究共登记并检验 3 条假设。\n\nH1：家庭教育知识水平与家庭教育自我效能呈正向关系（预期正向关系；方法 Pearson 积矩相关；结论：支持）。'),
  {
    index: 5,
    key: 'literature',
    title: '文献与理论依据',
    body: `本节未生成内容。原因：${LITERATURE_REASON}`,
    evidence: [],
    available: false,
    unavailable_reason: LITERATURE_REASON,
  },
  filled(6, 'method', '研究方法', '本研究采用横截面问卷调查数据。全部统计量由平台统计引擎 1.0.0 计算，可由原始数据完全复现。'),
  filled(7, 'sampling', '数据来源与抽样', '数据由研究者在平台上发布问卷后经公开作答链接收集，本次共产生作答记录 500 份。'),
  filled(8, 'sample_profile', '样本概况', '分析样本共 350 份。变量 STAGE（孩子学段），有效作答 n = 350，缺失 0：\n\n| 类别 | 编码 | 人数 | 占有效作答比例（%） |\n| --- | --- | --- | --- |\n| 学前 | 1 | 120 | 34.29 |\n| 小学 | 2 | 150 | 42.86 |\n| 初中 | 3 | 80 | 22.86 |'),
  filled(9, 'instrument', '测量工具与变量说明', '数据集共 42 个变量，来自问卷的 58 道题目，其中派生变量 12 个。'),
  filled(
    10,
    'reliability',
    '信度分析',
    '共对 4 个量表做内部一致性分析，其中 4 个给出了 Cronbach α。\n\n| 量表 | 名称 | 条目数 | n | Cronbach α |\n| --- | --- | --- | --- | --- |\n| FSE | 家庭教育自我效能 | 3 | 340 | 0.842 |\n| FED | 家庭教育困难 | 5 | 336 | 0.781 |\n\nα 最高的是 **FSE**（α = 0.842，n = 340）。',
    [
      { path: 'reliability.scales[].cronbach_alpha', value: 'FSE:0.842、FED:0.781' },
      { path: 'reliability.scales[].n', value: 'FSE:340、FED:336' },
    ],
  ),
  filled(11, 'validity', '效度分析', 'KMO 取样适切性（整体）为 0.834，Bartlett 球形检验 χ² = 1842.31，df = 15。'),
  filled(12, 'descriptive', '描述性统计', '描述统计共覆盖 42 个变量。可计算均值的变量 36 个；名义变量 6 个（不给均值）。'),
  filled(13, 'correlation', '相关分析', '相关分析覆盖 6 个变量，共 15 组变量对。在 15 组变量对中，达到 α = 0.05 显著水平的有 7 组。'),
  filled(14, 'regression', '回归分析', '有序 Logistic 回归（比例优势模型）：因变量 UI，n = 342，McFadden R² = 0.1035。'),
  filled(15, 'group_differences', '组间差异分析', '组间比较共 3 组，分组变量为 STAGE（孩子学段）。FED 的 Kruskal–Wallis H = 7.42，p = 0.0244。'),
  filled(
    16,
    'hypothesis_tests',
    '假设检验结果',
    '本节逐条报告 3 条假设的检验结果。\n\nH1　家庭教育知识水平与家庭教育自我效能呈正向关系\n　　方法：Pearson 积矩相关；r = 0.42，p < .001；结论：支持（p < α 且方向与假设一致）。\n\nH3　家庭社会经济地位与使用意向呈正向关系\n　　方法：Spearman 等级相关；r = 0.07，p = 0.21；结论：证据不足（p ≥ α，当前样本未提供证据，不能据此判断两者没有关系）。',
    [
      { path: 'hypotheses.summary.total', value: '3' },
      { path: 'hypotheses.summary.supported', value: '1' },
      { path: 'hypotheses.summary.inconclusive', value: '1' },
    ],
  ),
  filled(17, 'findings', '主要发现', '1. 本次分析的样本为 350 份，变量 42 个，缺失值整例删除且不插补。\n2. 在 3 条假设中，有 1 条获得数据支持：H1（r = 0.42）。'),
  filled(18, 'discussion', '讨论', '得到支持的关系共 1 条（共检验 3 条）。这些关系是横截面数据中的共变关系，方向性解释必须谨慎。'),
  filled(19, 'limitations', '局限性', '以下 2 条限制为结果包（analysis bundle）原文，任何引用本报告结论的下游材料都应同时引用这些限制：\n\n1. 本研究采用横截面问卷调查数据。\n2. 分析基于 350 份已完成且未被排除的样本。'),
  filled(20, 'conclusion', '结论', '第一，本研究在 350 份有效样本上完成了 3 条假设的检验，其中 1 条获得数据支持。'),
  filled(21, 'policy_recommendations', '政策与管理建议', '本节建议由平台依据上述统计结果推导得出，共 2 条；每一条都附有其依据的统计量。'),
  filled(22, 'service_recommendations', '服务优化建议', '数字化服务需求：DSD 均值为 3.86（n = 344）。功能排期应优先覆盖该项。'),
  {
    index: 23,
    key: 'references_appendix',
    title: '参考文献与附录',
    body: `参考文献部分：本报告正文不含任何文献引用，因此没有需要核对的条目。\n\n原因：${REFERENCES_REASON}`,
    evidence: [],
    available: false,
    unavailable_reason: REFERENCES_REASON,
  },
];

const REPORT = {
  report_type: 'research_report',
  project_id: 'p-1',
  project_title: '家庭教育投入研究',
  questionnaire_title: '家庭教育投入问卷',
  engine_version: '1.0.0',
  analyser_generated_at: '2026-02-01T09:30:00.000Z',
  generated_at: '2026-03-02T08:00:00.000Z',
  sections: SECTIONS,
  section_count: SECTIONS.length,
  available_sections: SECTIONS.filter((section) => section.available).length,
  unavailable_sections: SECTIONS.filter((section) => !section.available).length,
  caveats: CAVEATS,
  markdown: `# 家庭教育投入研究 研究报告\n\n## 1. 标题与摘要\n\n${SECTIONS[0]!.body}\n`,
  word_count: 6402,
};

const NO_BUNDLE_MESSAGE =
  '尚未运行完整统计分析，无法生成研究报告。请先在「分析」页面执行「运行全部分析」，' +
  '报告中的每一个数字都取自该次分析的结果包。';

function stubReportApi(options: { report?: unknown; status?: number } = {}) {
  return stubFetch((call: FetchCall) => {
    const url = call.url;
    if (url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
    if (url.includes('/report.md')) {
      return fileResponse('# 家庭教育投入研究 研究报告\n', '家庭教育投入研究-20260302-report.md');
    }
    if (url.includes('/report')) {
      if (options.status === 400) {
        return jsonResponse({ error: { code: 'VALIDATION_ERROR', message: NO_BUNDLE_MESSAGE } }, 400);
      }
      return jsonResponse({ data: options.report ?? REPORT });
    }
    return jsonResponse({ data: null });
  });
}

/** The section index/title headings, in the order they appear in the DOM. */
function sectionHeadings(): string[] {
  return queryAll('h2')
    .map((element) => element.textContent ?? '')
    .filter((content) => /^\d+\./.test(content));
}

async function renderPage(): Promise<void> {
  await render(createElement(MemoryRouter, null, createElement(ReportPage)));
  await flush();
  await flush();
}

function buttonWith(label: string): Element {
  const button = queryAll('button').find((element) => (element.textContent ?? '').includes(label));
  assert.ok(button, `未找到「${label}」按钮`);
  return button!;
}

beforeEach(() => {
  clearContainer();
  window.localStorage.clear();
});

after(() => {
  // The suite shares one process and one jsdom: leave no token behind.
  window.localStorage.clear();
  closeDom();
});

/* ================================================================== */
/* Sections                                                           */
/* ================================================================== */

describe('研究报告页', () => {
  test('23 个小节按 index 顺序渲染，并显示字数与可用计数', async () => {
    const stub = stubReportApi();
    try {
      await renderPage();

      const headings = sectionHeadings();
      assert.equal(headings.length, 23, '必须渲染全部 23 节，不因缺失而删节');
      assert.equal(headings[0], '1.标题与摘要');
      assert.equal(headings[4], '5.文献与理论依据');
      assert.equal(headings[15], '16.假设检验结果');
      assert.equal(headings[22], '23.参考文献与附录');

      // Order must be the API's index order, not the array order.
      const indexes = headings.map((heading) => Number.parseInt(heading, 10));
      assert.deepEqual(
        indexes,
        Array.from({ length: 23 }, (_value, position) => position + 1),
      );

      const content = text();
      assert.match(content, /正文字数/);
      assert.match(content, /6,402/);

      const cardText = (label: string): string => {
        const card = queryAll('div.ferp-card').find((element) =>
          (element.textContent ?? '').includes(label),
        );
        assert.ok(card, `未找到「${label}」统计卡`);
        return card!.textContent ?? '';
      };
      assert.match(cardText('章节总数'), /23/, '应显示章节总数 23');
      assert.match(cardText('由数据生成'), /21/, '应显示可用小节数 21');
      assert.match(cardText('需研究者补充'), /2/, '应显示不可用小节数 2');

      // Real numbers from the bodies reach the screen.
      assert.match(content, /共收集 500 份作答/);
      assert.match(content, /进入分析的样本为 350 份/);
      assert.match(content, /Cronbach α/);
      assert.match(content, /0\.842/);
      assert.match(content, /McFadden R² = 0\.1035/);
      assert.match(content, /不能据此推断因果关系/, '结果包限制必须出现');
    } finally {
      stub.restore();
    }
  });

  test('Markdown 正文按标题、列表、表格与引用渲染，且不注入 HTML', async () => {
    const stub = stubReportApi();
    try {
      await renderPage();

      // The reliability table became a real table with its cells.
      const table = queryAll('table').find((element) =>
        (element.textContent ?? '').includes('Cronbach α'),
      );
      assert.ok(table, '应把 Markdown 表格渲染为表格');
      assert.ok((table!.textContent ?? '').includes('家庭教育自我效能'));
      assert.equal(table!.querySelectorAll('tbody tr').length, 2, '表格应有 2 行数据');

      // `**FSE**` became emphasis rather than literal asterisks.
      const strong = queryAll('strong').map((element) => element.textContent ?? '');
      assert.ok(strong.includes('FSE'), `应渲染加粗文本：${strong.join('|')}`);
      assert.match(text(), /证据留痕|本节引用的结果包位置/);

      // The ordered list in the findings section is a real list.
      const lists = queryAll('ol').flatMap((element) =>
        Array.from(element.querySelectorAll('li')).map((item) => item.textContent ?? ''),
      );
      assert.ok(
        lists.some((item) => item.includes('缺失值整例删除且不插补')),
        '有序列表项应逐条渲染',
      );

      // Blockquote from the abstract.
      assert.equal(queryAll('blockquote').length > 0, true, '引用块应渲染为 blockquote');
    } finally {
      stub.restore();
    }
  });

  test('本节引用的结果包位置逐条给出路径与数值', async () => {
    const stub = stubReportApi();
    try {
      await renderPage();

      const content = text();
      assert.ok(content.includes('hypotheses.summary.total'), '应显示证据路径');
      assert.ok(content.includes('reliability.scales[].cronbach_alpha'));
      assert.match(content, /本节引用的结果包位置（3 条，可在分析页核对）/);
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Unavailable sections                                             */
  /* ================================================================ */

  test('available: false 的小节显示 unavailable_reason，而不是空小节', async () => {
    const stub = stubReportApi();
    try {
      await renderPage();

      const content = text();
      assert.match(content, /平台在离线环境中运行，没有可检索的文献数据库/);
      assert.match(content, /无法被溯源，属于编造，平台不提供该功能/);
      assert.match(content, /平台不生成参考文献：离线环境没有文献来源/);
      assert.match(content, /参考文献必须由研究者按目标期刊或评审要求自行撰写并逐条核对/);

      // Both gaps are announced, and neither is left looking like an empty box.
      const badges = queryAll('span').filter(
        (element) => (element.textContent ?? '') === '本平台无法生成，需研究者补充',
      );
      assert.equal(badges.length, 2, '两个不可用小节都必须明确标注');
      const notices = queryAll('p').filter(
        (element) => (element.textContent ?? '').trim() === '本节未生成内容',
      );
      assert.equal(notices.length, 2);
      assert.match(content, /平台不会用示例文字或估计值填充本节/);

      // The reason is presented inside the section it belongs to, not somewhere
      // else on the page.
      const literatureHeading = queryAll('h2').find(
        (element) => (element.textContent ?? '') === '5.文献与理论依据',
      );
      assert.ok(literatureHeading);
      const article = literatureHeading!.closest('div.ferp-card');
      assert.ok(article, '小节应位于卡片内');
      const articleText = article!.textContent ?? '';
      assert.ok(articleText.includes(LITERATURE_REASON), '未生成原因必须出现在该小节内');
      assert.ok(articleText.includes('本节未生成内容'));
    } finally {
      stub.restore();
    }
  });

  test('没有结果包时显示接口的中文原因并指向统计分析页', async () => {
    const stub = stubReportApi({ status: 400 });
    try {
      await renderPage();

      const content = text();
      assert.match(content, /尚未运行完整统计分析，无法生成研究报告/);
      assert.match(content, /请先在「分析」页面执行「运行全部分析」/);
      assert.equal(sectionHeadings().length, 0, '没有结果包时不应渲染任何小节');
      assert.ok(!content.includes('6,402'), '不应显示任何报告统计');

      const links = queryAll('a').map((element) => element.getAttribute('href'));
      assert.ok(
        links.some((href) => href?.includes('/analysis')),
        '应提供前往统计分析页的入口',
      );
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Download and copy                                                */
  /* ================================================================ */

  test('下载 Markdown 通过带令牌的文件接口，并显示服务端返回的文件名', async () => {
    window.localStorage.setItem('ferp.token', 'test-token');
    const stub = stubReportApi();
    const host = stubDownloadHost();
    try {
      await renderPage();
      await click(buttonWith('下载 Markdown'));
      await flush();

      const call = stub.calls.find((item) => item.url.includes('/report.md'));
      assert.ok(call, '应请求 report.md 接口');
      assert.equal(call!.headers['authorization'], 'Bearer test-token', '下载必须携带令牌，否则会 401');

      assert.equal(host.clicks.length, 1, '应触发一次浏览器下载');
      assert.equal(
        host.clicks[0]!.getAttribute('download'),
        '家庭教育投入研究-20260302-report.md',
        '保存的文件名应取自 content-disposition',
      );
      assert.equal(host.clicks[0]!.getAttribute('href'), 'blob:mock-1');
      assert.match(text(), /家庭教育投入研究-20260302-report\.md/);
    } finally {
      host.restore();
      stub.restore();
    }
  });

  test('剪贴板不可用时如实说明，并展开全文供手动复制', async () => {
    const stub = stubReportApi();
    try {
      await renderPage();
      await click(buttonWith('复制全文'));
      await flush();

      const content = text();
      assert.match(content, /浏览器不允许脚本写剪贴板，已展开全文供手动复制/);
      assert.ok(!content.includes('已复制全文到剪贴板'), '不得谎称已复制');

      const textarea = queryAll('textarea')[0] as HTMLTextAreaElement | undefined;
      assert.ok(textarea, '应展开全文');
      assert.equal(textarea!.value, REPORT.markdown, '展开的必须是完整 Markdown 原文');
    } finally {
      stub.restore();
    }
  });

  test('剪贴板可用时写入完整 Markdown 并确认已复制', async () => {
    const stub = stubReportApi();
    const written: string[] = [];
    Object.defineProperty(window.navigator, 'clipboard', {
      value: { writeText: async (value: string) => void written.push(value) },
      configurable: true,
    });
    try {
      await renderPage();
      await click(buttonWith('复制全文'));
      await flush();

      assert.deepEqual(written, [REPORT.markdown], '应复制完整 Markdown 原文');
      assert.match(text(), /已复制全文到剪贴板/);
      assert.equal(queryAll('textarea').length, 0, '复制成功后不必展开全文');
    } finally {
      delete (window.navigator as { clipboard?: unknown }).clipboard;
      stub.restore();
    }
  });
});
