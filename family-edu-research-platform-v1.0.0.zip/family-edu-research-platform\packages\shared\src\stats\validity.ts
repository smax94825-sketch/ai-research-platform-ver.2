/**
 * Construct validity: KMO, Bartlett's test and exploratory factor analysis
 * (PHASE 5).
 *
 * The engine deliberately stops at EFA. Confirmatory factor analysis with fit
 * indices is a different procedure with different assumptions, and presenting an
 * EFA loading matrix as if it validated a measurement model would be an
 * overclaim — so the output says what it is and what it is not.
 */

import { chiSquareUpperTailP, roundTo } from './special.js';
import { inverse, jacobiEigen, correlationMatrix, type Matrix } from './matrix.js';
import { completeCases, type Dataset } from './dataset.js';
import { resolveScaleItems } from './descriptive.js';

/* ------------------------------------------------------------------ */
/* KMO and Bartlett                                                   */
/* ------------------------------------------------------------------ */

export interface KmoResult {
  /** Overall Kaiser–Meyer–Olkin measure of sampling adequacy. */
  overall: number | null;
  /** Per-variable MSA, which shows WHICH variable is the problem. */
  per_variable: { variable: string; msa: number | null }[];
  interpretation: string;
  adequacy: 'unacceptable' | 'miserable' | 'mediocre' | 'middling' | 'meritorious' | 'marvelous' | 'unknown';
}

function interpretKmo(kmo: number | null): { text: string; adequacy: KmoResult['adequacy'] } {
  if (kmo === null) return { text: '无法计算 KMO（矩阵不可逆或变量不足）。', adequacy: 'unknown' };
  if (kmo >= 0.9) return { text: 'KMO ≥ 0.90，取样适切性极佳，非常适合进行因素分析。', adequacy: 'marvelous' };
  if (kmo >= 0.8) return { text: 'KMO 在 0.80—0.89，取样适切性良好，适合进行因素分析。', adequacy: 'meritorious' };
  if (kmo >= 0.7) return { text: 'KMO 在 0.70—0.79，取样适切性中等，可以进行因素分析。', adequacy: 'middling' };
  if (kmo >= 0.6) return { text: 'KMO 在 0.60—0.69，取样适切性勉强，结果需谨慎解读。', adequacy: 'mediocre' };
  if (kmo >= 0.5) return { text: 'KMO 在 0.50—0.59，取样适切性较差，不建议进行因素分析。', adequacy: 'miserable' };
  return { text: 'KMO < 0.50，取样适切性不可接受，不应进行因素分析。', adequacy: 'unacceptable' };
}

/**
 * Kaiser–Meyer–Olkin measure.
 *
 * The MSA is derived from the anti-image correlation matrix (the partial
 * correlations), so a single badly-behaved variable can drag the overall value
 * down. Reporting per-variable MSA is what makes the diagnostic actionable.
 */
export function kmo(correlation: Matrix, variableNames: string[]): KmoResult {
  const p = correlation.length;
  if (p < 2) {
    return { overall: null, per_variable: [], interpretation: '变量少于 2 个，无法计算 KMO。', adequacy: 'unknown' };
  }

  const inverted = inverse(correlation);
  if (inverted.singular || !inverted.matrix) {
    const { adequacy } = interpretKmo(null);
    return {
      overall: null,
      per_variable: variableNames.map((variable) => ({ variable, msa: null })),
      interpretation: '相关矩阵不可逆（存在完全共线或变量数超过样本数），无法计算 KMO。',
      adequacy,
    };
  }

  const inverseMatrix = inverted.matrix;

  // Partial correlations: -a_ij / sqrt(a_ii * a_jj)
  const partial: Matrix = correlation.map((row) => row.map(() => 0));
  for (let i = 0; i < p; i += 1) {
    for (let j = 0; j < p; j += 1) {
      if (i === j) continue;
      const denominator = Math.sqrt(inverseMatrix[i]![i]! * inverseMatrix[j]![j]!);
      partial[i]![j] = denominator === 0 ? 0 : -inverseMatrix[i]![j]! / denominator;
    }
  }

  let sumSquaredCorrelation = 0;
  let sumSquaredPartial = 0;
  for (let i = 0; i < p; i += 1) {
    for (let j = 0; j < p; j += 1) {
      if (i === j) continue;
      sumSquaredCorrelation += correlation[i]![j]! ** 2;
      sumSquaredPartial += partial[i]![j]! ** 2;
    }
  }

  const denominatorOverall = sumSquaredCorrelation + sumSquaredPartial;
  const rawOverall = denominatorOverall === 0 ? null : sumSquaredCorrelation / denominatorOverall;

  /**
   * Sanity guard.
   *
   * KMO is a ratio of squared correlations and is therefore bounded in [0, 1].
   * A near-singular correlation matrix (for example two items that are almost
   * identical) produces a numerically meaningless inverse, and the ratio can
   * fall outside that range. Reporting such a value would be worse than
   * reporting nothing, so it is rejected and explained instead.
   */
  const eigenvalueCheck = jacobiEigen(correlation).values;
  const smallestEigenvalue = eigenvalueCheck[eigenvalueCheck.length - 1] ?? 0;
  const illConditioned = smallestEigenvalue < 1e-8;

  const overallValid =
    rawOverall !== null && Number.isFinite(rawOverall) && rawOverall >= -1e-9 && rawOverall <= 1 + 1e-9;

  if (!overallValid || illConditioned) {
    return {
      overall: null,
      per_variable: variableNames.map((variable) => ({ variable, msa: null })),
      interpretation:
        '无法计算 KMO：相关矩阵接近奇异（最小特征值 ' +
        `${roundTo(smallestEigenvalue, 10)}），说明存在近乎完全共线的变量。` +
        '请检查是否有题目内容重复、或某个变量可由其他变量线性表示；此类数据不适合直接进行因素分析。',
      adequacy: 'unacceptable',
    };
  }

  const perVariable = Array.from({ length: p }, (_, index) => {
    let squaredCorrelation = 0;
    let squaredPartial = 0;
    for (let j = 0; j < p; j += 1) {
      if (j === index) continue;
      squaredCorrelation += correlation[index]![j]! ** 2;
      squaredPartial += partial[index]![j]! ** 2;
    }
    const denominator = squaredCorrelation + squaredPartial;
    if (denominator === 0) return { variable: variableNames[index] ?? `V${index + 1}`, msa: null };
    const value = squaredCorrelation / denominator;
    return {
      variable: variableNames[index] ?? `V${index + 1}`,
      // Clamp defensively: a single bad cell must not produce an impossible MSA.
      msa: roundTo(Math.max(0, Math.min(1, value)), 4),
    };
  });

  const { text, adequacy } = interpretKmo(roundTo(rawOverall, 4));
  return {
    overall: roundTo(rawOverall, 4),
    per_variable: perVariable,
    interpretation: text,
    adequacy,
  };
}

export interface BartlettResult {
  chi_square: number | null;
  degrees_of_freedom: number;
  p_value: number | null;
  /** Determinant of the correlation matrix. */
  determinant: number | null;
  interpretation: string;
  /** True when the test could not be computed (singular matrix). */
  unavailable: boolean;
}

/**
 * Bartlett's test of sphericity.
 *
 * The determinant is taken as the product of the correlation matrix's
 * eigenvalues, which is exact for a symmetric matrix and avoids a separate LU
 * factorisation. A non-positive determinant means the matrix is singular, and
 * the test is reported as unavailable rather than returning a fabricated χ².
 */
export function bartlettTest(correlation: Matrix, n: number): BartlettResult {
  const p = correlation.length;
  const degreesOfFreedom = (p * (p - 1)) / 2;

  if (p < 2) {
    return {
      chi_square: null,
      degrees_of_freedom: 0,
      p_value: null,
      determinant: null,
      interpretation: '变量少于 2 个，无法进行 Bartlett 球形检验。',
      unavailable: true,
    };
  }

  const eigenvalues = jacobiEigen(correlation).values;
  const determinant = eigenvalues.reduce((product, value) => product * value, 1);

  if (!Number.isFinite(determinant) || determinant <= 0 || n <= p + 1) {
    return {
      chi_square: null,
      degrees_of_freedom: degreesOfFreedom,
      p_value: null,
      determinant: Number.isFinite(determinant) ? determinant : null,
      interpretation:
        '无法计算 Bartlett 球形检验：相关矩阵行列式非正（存在完全共线）或样本量相对于变量数过小。' +
        '这本身即提示不适合进行因素分析。',
      unavailable: true,
    };
  }

  const chiSquare = -(n - 1 - (2 * p + 5) / 6) * Math.log(determinant);
  const pValue = chiSquareUpperTailP(chiSquare, degreesOfFreedom);

  return {
    chi_square: roundTo(chiSquare, 4),
    degrees_of_freedom: degreesOfFreedom,
    p_value: roundTo(pValue, 6),
    determinant: roundTo(determinant, 10),
    interpretation:
      pValue < 0.05
        ? 'Bartlett 球形检验显著（p < 0.05），相关矩阵与单位矩阵存在显著差异，适合进行因素分析。' +
          '注意：样本量较大时该检验极易显著，因此需结合 KMO 与取样适切性共同判断。'
        : 'Bartlett 球形检验不显著（p ≥ 0.05），变量间相关不足以支持因素分析。',
    unavailable: false,
  };
}

/* ------------------------------------------------------------------ */
/* Exploratory factor analysis                                        */
/* ------------------------------------------------------------------ */

export interface FactorLoading {
  variable: string;
  label: string;
  /** Loading on each retained factor. */
  loadings: number[];
  /** Sum of squared loadings across retained factors. */
  communality: number;
  /** Largest absolute loading, and which factor it belongs to. */
  primary_factor: number;
  primary_loading: number;
}

export interface EfaResult {
  n: number;
  p: number;
  extraction: 'principal_component';
  rotation: 'varimax' | 'none';
  /** Eigenvalues of the correlation matrix (all of them). */
  eigenvalues: number[];
  /** Proportion of variance explained by each eigenvalue. */
  variance_explained: number[];
  /** Cumulative variance explained. */
  cumulative_variance: number[];
  /** Kaiser criterion: factors with eigenvalue > 1. */
  kaiser_factors: number;
  /** Number of factors actually retained. */
  factors_retained: number;
  loadings: FactorLoading[];
  /** Variance explained per retained factor after rotation. */
  rotated_variance_explained: number[];
  rotated_cumulative_variance: number;
  kmo: KmoResult;
  bartlett: BartlettResult;
  /** Scree plot data. */
  scree: { component: number; eigenvalue: number }[];
  /** Variables that fail the common 0.40 loading convention. */
  low_communality: string[];
  /** Variables loading ≥ 0.40 on more than one factor. */
  cross_loading: { variable: string; factors: number[]; loadings: number[] }[];
  interpretation: string;
  warnings: string[];
}

/** Varimax rotation with Kaiser normalisation, applied to a loading matrix. */
export function varimax(loadings: Matrix, maxIterations = 200, tolerance = 1e-8): Matrix {
  const rows = loadings.length;
  const columns = loadings[0]?.length ?? 0;
  if (rows === 0 || columns < 2) return loadings.map((row) => [...row]);

  const result = loadings.map((row) => [...row]);

  // Kaiser normalisation: scale rows to unit communality.
  const communalities = result.map((row) => Math.sqrt(row.reduce((sum, value) => sum + value * value, 0)));
  for (let i = 0; i < rows; i += 1) {
    const scale = communalities[i]!;
    if (scale > 0) for (let j = 0; j < columns; j += 1) result[i]![j]! /= scale;
  }

  for (let iteration = 0; iteration < maxIterations; iteration += 1) {
    let rotatedSomething = false;
    for (let first = 0; first < columns - 1; first += 1) {
      for (let second = first + 1; second < columns; second += 1) {
        let a = 0;
        let b = 0;
        let c = 0;
        let d = 0;
        for (let i = 0; i < rows; i += 1) {
          const x = result[i]![first]!;
          const y = result[i]![second]!;
          const u = x * x - y * y;
          const v = 2 * x * y;
          a += u;
          b += v;
          c += u * u - v * v;
          d += 2 * u * v;
        }
        const numerator = d - (2 * a * b) / rows;
        const denominator = c - (a * a - b * b) / rows;
        const angle = 0.25 * Math.atan2(numerator, denominator);
        if (Math.abs(angle) > tolerance) rotatedSomething = true;

        const cos = Math.cos(angle);
        const sin = Math.sin(angle);
        for (let i = 0; i < rows; i += 1) {
          const x = result[i]![first]!;
          const y = result[i]![second]!;
          result[i]![first] = cos * x + sin * y;
          result[i]![second] = -sin * x + cos * y;
        }
      }
    }
    if (!rotatedSomething) break;
  }

  // Undo the Kaiser normalisation.
  for (let i = 0; i < rows; i += 1) {
    const scale = communalities[i]!;
    if (scale > 0) for (let j = 0; j < columns; j += 1) result[i]![j]! *= scale;
  }

  return result;
}

export interface EfaOptions {
  /** Force a number of factors; otherwise the Kaiser criterion is used. */
  factors?: number;
  rotate?: boolean;
  /** Loading below this is treated as "does not load" (convention: 0.40). */
  loadingThreshold?: number;
}

/**
 * Exploratory factor analysis by principal component extraction.
 *
 * Principal components is the default because it is what most social-science
 * papers report when they say "EFA"; the extraction method is stated explicitly
 * in the output so the reader is never left guessing which one was used.
 */
export function exploratoryFactorAnalysis(
  dataset: Dataset,
  variableNames: string[],
  options: EfaOptions = {},
): EfaResult {
  const warnings: string[] = [];
  const threshold = options.loadingThreshold ?? 0.4;

  const selection = completeCases(dataset, variableNames);
  const { columns, n, variable_names: used } = selection;
  const p = used.length;

  const emptyResult = (reason: string): EfaResult => ({
    n,
    p,
    extraction: 'principal_component',
    rotation: options.rotate === false ? 'none' : 'varimax',
    eigenvalues: [],
    variance_explained: [],
    cumulative_variance: [],
    kaiser_factors: 0,
    factors_retained: 0,
    loadings: [],
    rotated_variance_explained: [],
    rotated_cumulative_variance: 0,
    kmo: { overall: null, per_variable: [], interpretation: reason, adequacy: 'unknown' },
    bartlett: {
      chi_square: null,
      degrees_of_freedom: 0,
      p_value: null,
      determinant: null,
      interpretation: reason,
      unavailable: true,
    },
    scree: [],
    low_communality: [],
    cross_loading: [],
    interpretation: reason,
    warnings: [reason],
  });

  if (p < 3) return emptyResult('因素分析至少需要 3 个变量。');
  if (n < 3) return emptyResult('整例删除后有效样本不足 3 例，无法进行因素分析。');
  if (n < p + 1) {
    warnings.push(
      `有效样本 n = ${n} 少于变量数 + 1（${p + 1}），因素分析结果不可靠（建议至少 5—10 倍于变量数）。`,
    );
  }

  const correlation = correlationMatrix(columns);
  const kmoResult = kmo(correlation, used);
  const bartlettResult = bartlettTest(correlation, n);

  const eigen = jacobiEigen(correlation);
  const eigenvalues = eigen.values;
  const totalVariance = p;

  const varianceExplained = eigenvalues.map((value) => roundTo((value / totalVariance) * 100, 4));
  const cumulative: number[] = [];
  varianceExplained.reduce((sum, value) => {
    const next = roundTo(sum + value, 4);
    cumulative.push(next);
    return next;
  }, 0);

  const kaiserFactors = eigenvalues.filter((value) => value > 1).length;
  const requested = options.factors ?? kaiserFactors;
  const factorsRetained = Math.max(1, Math.min(requested, p));

  if (requested === 0) {
    warnings.push('按特征值 > 1 的准则未提取出任何公共因素，数据可能不适合因素分析。');
  }
  if (factorsRetained !== requested) {
    warnings.push(`请求提取 ${requested} 个因素，受变量数限制实际保留 ${factorsRetained} 个。`);
  }

  // Loadings from principal components: eigenvector × sqrt(eigenvalue).
  const loadingsMatrix: Matrix = Array.from({ length: p }, (_, variableIndex) =>
    Array.from({ length: factorsRetained }, (_, factorIndex) => {
      const eigenvalue = Math.max(eigenvalues[factorIndex] ?? 0, 0);
      const eigenvector = eigen.vectors[factorIndex] ?? [];
      return (eigenvector[variableIndex] ?? 0) * Math.sqrt(eigenvalue);
    }),
  );

  const rotate = options.rotate !== false;
  const rotated = rotate ? varimax(loadingsMatrix) : loadingsMatrix;

  const loadings: FactorLoading[] = used.map((name, index) => {
    const row = rotated[index] ?? [];
    const variable = dataset.by_name.get(name);
    let primaryFactor = 0;
    let primaryLoading = 0;
    row.forEach((value, factorIndex) => {
      if (Math.abs(value) > Math.abs(primaryLoading)) {
        primaryLoading = value;
        primaryFactor = factorIndex;
      }
    });
    return {
      variable: name,
      label: variable?.label ?? name,
      loadings: row.map((value) => roundTo(value, 4)),
      communality: roundTo(row.reduce((sum, value) => sum + value * value, 0), 4),
      primary_factor: primaryFactor + 1,
      primary_loading: roundTo(primaryLoading, 4),
    };
  });

  // Variance explained after rotation, per factor.
  const rotatedVariance = Array.from({ length: factorsRetained }, (_, factorIndex) => {
    const sumSquared = loadings.reduce(
      (sum, item) => sum + (item.loadings[factorIndex] ?? 0) ** 2,
      0,
    );
    return roundTo((sumSquared / totalVariance) * 100, 4);
  });
  const rotatedCumulative = roundTo(
    rotatedVariance.reduce((sum, value) => sum + value, 0),
    4,
  );

  const lowCommunality = loadings
    .filter((item) => Math.abs(item.primary_loading) < threshold || item.communality < 0.3)
    .map((item) => item.variable);

  const crossLoading = loadings
    .map((item) => {
      const significant = item.loadings
        .map((value, factorIndex) => ({ value, factorIndex }))
        .filter((entry) => Math.abs(entry.value) >= threshold);
      return {
        variable: item.variable,
        factors: significant.map((entry) => entry.factorIndex + 1),
        loadings: significant.map((entry) => entry.value),
      };
    })
    .filter((entry) => entry.factors.length > 1);

  if (lowCommunality.length > 0) {
    warnings.push(
      `以下变量的共同度或主载荷偏低（< ${threshold}）：${lowCommunality.join('、')}，` +
        '提示它们与所提取的因素关系较弱，建议检查题目内容。',
    );
  }
  if (crossLoading.length > 0) {
    warnings.push(
      `以下变量在多个因素上均有较高载荷（交叉载荷）：${crossLoading.map((entry) => entry.variable).join('、')}，` +
        '会削弱区分效度的解释。',
    );
  }

  const interpretation =
    `采用主成分法提取、${rotate ? '方差最大正交旋转（varimax）' : '不旋转'}，` +
    `按特征值 > 1 的准则可提取 ${kaiserFactors} 个因素，本次保留 ${factorsRetained} 个，` +
    `累计解释方差 ${cumulative[factorsRetained - 1] ?? 0}%（旋转后 ${rotatedCumulative}%），` +
    `有效样本 n = ${n}。` +
    '说明：探索性因素分析只能提示数据的维度结构，不能确认理论模型；' +
    '若需验证预设的测量模型，应另行进行验证性因素分析（CFA）并报告拟合指标。';

  return {
    n,
    p,
    extraction: 'principal_component',
    rotation: rotate ? 'varimax' : 'none',
    eigenvalues: eigenvalues.map((value) => roundTo(value, 4)),
    variance_explained: varianceExplained,
    cumulative_variance: cumulative,
    kaiser_factors: kaiserFactors,
    factors_retained: factorsRetained,
    loadings,
    rotated_variance_explained: rotatedVariance,
    rotated_cumulative_variance: rotatedCumulative,
    kmo: kmoResult,
    bartlett: bartlettResult,
    scree: eigenvalues.map((value, index) => ({
      component: index + 1,
      eigenvalue: roundTo(value, 4),
    })),
    low_communality: lowCommunality,
    cross_loading: crossLoading,
    interpretation,
    warnings,
  };
}

/* ------------------------------------------------------------------ */
/* Convenience: EFA per declared scale                                */
/* ------------------------------------------------------------------ */

export interface ValidityReport {
  /** Instrument-level diagnostics over every eligible variable. */
  overall_kmo: KmoResult;
  overall_bartlett: BartlettResult;
  /** One EFA per declared scale. */
  scale_efa: { scale: string; label: string; result: EfaResult }[];
  note: string;
  warnings: string[];
}

export function validityReport(dataset: Dataset): ValidityReport {
  const allItems: string[] = [];
  for (const scale of dataset.scales) {
    for (const item of resolveScaleItems(dataset, scale.question_codes)) {
      if (!allItems.includes(item)) allItems.push(item);
    }
  }

  const selection = completeCases(dataset, allItems);
  const usable = selection.variable_names.filter((name) => {
    const column = selection.columns[selection.variable_names.indexOf(name)]!;
    return new Set(column).size > 1;
  });

  const correlation =
    usable.length >= 2
      ? correlationMatrix(
          usable.map((name) => selection.columns[selection.variable_names.indexOf(name)]!),
        )
      : [];

  const overallKmo =
    usable.length >= 2
      ? kmo(correlation, usable)
      : {
          overall: null,
          per_variable: [],
          interpretation: '可用变量少于 2 个，无法计算 KMO。',
          adequacy: 'unknown' as const,
        };

  const overallBartlett =
    usable.length >= 2
      ? bartlettTest(correlation, selection.n)
      : {
          chi_square: null,
          degrees_of_freedom: 0,
          p_value: null,
          determinant: null,
          interpretation: '可用变量少于 2 个，无法进行 Bartlett 球形检验。',
          unavailable: true,
        };

  const scaleEfa = dataset.scales
    .map((scale) => {
      const items = resolveScaleItems(dataset, scale.question_codes);
      if (items.length < 3) return null;
      return {
        scale: scale.variable_name,
        label: scale.label,
        result: exploratoryFactorAnalysis(dataset, items, {}),
      };
    })
    .filter((entry): entry is { scale: string; label: string; result: EfaResult } => entry !== null);

  const warnings: string[] = [];
  if (usable.length < allItems.length) {
    warnings.push(
      `在整例删除后，${allItems.length - usable.length} 个变量因缺失过多或无变异而被排除出效度分析。`,
    );
  }

  return {
    overall_kmo: overallKmo,
    overall_bartlett: overallBartlett,
    scale_efa: scaleEfa,
    note:
      '效度分析包含 KMO 取样适切性检验、Bartlett 球形检验与探索性因素分析（主成分法 + 方差最大正交旋转）。' +
      '这些结果用于判断数据是否适合做因素分析以及维度结构是否与理论一致，均不构成因果或效度确认证据。',
    warnings,
  };
}
