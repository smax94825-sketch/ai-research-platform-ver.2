/**
 * Quota API tests (PHASE 4).
 *
 * The interesting part is not the arithmetic (covered by the shared unit tests)
 * but the counting rule: which samples count towards a quota. Getting that wrong
 * would let excluded duplicates mask a genuine shortfall, so it is pinned here.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import {
  api,
  createTestContext,
  createTemplatedProject,
  publishQuestionnaire,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

interface TemplateFixture {
  projectId: string;
  questionnaireId: string;
  shareToken: string;
  token: string;
}

async function makeTemplateFixture(title: string): Promise<TemplateFixture> {
  const researcher = await registerResearcher(ctx);
  const project = await createTemplatedProject(ctx, researcher.token, title);
  const shareToken = await publishQuestionnaire(ctx, researcher.token, project.questionnaireId!);

  // Every sample must carry a Q4 (education stage) answer for quota counting.
  return { projectId: project.id, questionnaireId: project.questionnaireId!, shareToken, token: researcher.token };
}

interface CollectedSample {
  respondentId: string;
  stage: string;
}

/**
 * Collect a complete sample whose Q4 (STAGE) answer is `stageCode`.
 * All other required questions get their first option; the flow walk respects
 * the questionnaire's skip logic.
 */
async function collectWithStage(
  fixture: TemplateFixture,
  stageCode: string,
  options: { durationSeconds?: number; submit?: boolean } = {},
): Promise<CollectedSample> {
  const instrument = await api<{
    questions: {
      question_code: string;
      question_type: string;
      required: boolean;
      options: { choices?: { value: string }[]; matrix?: { rows: { value: string }[]; columns: { value: string }[] } };
    }[];
  }>(ctx, 'GET', `/api/public/survey/${fixture.shareToken}/instrument`);

  const byCode = new Map(instrument.data.questions.map((q) => [q.question_code, q]));
  const session = await startSession(ctx, fixture.shareToken, 'wechat');

  if (options.durationSeconds !== undefined) {
    const startedAt = new Date(Date.now() - options.durationSeconds * 1000).toISOString();
    ctx.db.run('UPDATE respondents SET started_at = ? WHERE id = ?', [startedAt, session.respondentId]);
  }

  for (let guard = 0; guard < 200; guard += 1) {
    const state = await api<{ answers: Record<string, unknown>; hidden_question_codes: string[] }>(
      ctx,
      'GET',
      `/api/public/sessions/${session.token}`,
    );
    const hidden = new Set(state.data.hidden_question_codes);
    const next = instrument.data.questions.find(
      (question) =>
        question.question_type !== 'page_break' &&
        question.required &&
        !hidden.has(question.question_code) &&
        state.data.answers[question.question_code] === undefined,
    );
    if (!next) break;

    const target = byCode.get(next.question_code)!;
    let value: unknown;
    if (next.question_code === 'Q4') value = stageCode;
    else if (next.question_type === 'matrix') {
      value = Object.fromEntries(
        target.options.matrix!.rows.map((row) => [row.value, target.options.matrix!.columns[0]!.value]),
      );
    } else if (next.question_type === 'textarea' || next.question_type === 'text') value = '测试';
    else if (next.question_type === 'number') value = 1;
    else if (next.question_type === 'multiple') value = [target.options.choices![0]!.value];
    else value = target.options.choices![0]!.value;

    const saved = await saveAnswer(ctx, session.token, next.question_code, value);
    assert.equal(saved.status, 200, `${next.question_code}: ${JSON.stringify(saved.error)}`);
  }

  if (options.submit !== false) {
    const submitted = await submitSession(ctx, session.token);
    assert.equal(submitted.status, 200, JSON.stringify(submitted.error));
  }

  return { respondentId: session.respondentId, stage: stageCode };
}

/* ================================================================== */
/* Template default quota                                             */
/* ================================================================== */

describe('模板项目的默认配额', () => {
  test('随模板创建的项目自带分阶段配额', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '默认配额');

    const quota = await api<{
      enabled: boolean;
      preserve_structure: boolean;
      dimension_variable: string | null;
      dimension_question_code: string | null;
      progress: { items: { category: string; target_n: number }[]; total_target: number };
      counting_note: string;
    }>(ctx, 'GET', `/api/projects/${project.id}/quota`, { token: researcher.token });

    assert.equal(quota.status, 200);
    assert.equal(quota.data.enabled, true);
    assert.equal(quota.data.preserve_structure, true);
    assert.equal(quota.data.dimension_variable, 'STAGE');
    assert.equal(quota.data.dimension_question_code, 'Q4');
    assert.equal(quota.data.progress.total_target, 1000);
    assert.equal(quota.data.progress.items.length, 4);
    assert.match(quota.data.counting_note, /Q4/);
    assert.match(quota.data.counting_note, /排除/);
  });

  test('尚无样本时如实说明依据不足，而不是给出误导性的建议', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '空配额');

    const quota = await api<{
      progress: { total_current: number; percent: number | null };
      recommendations: { kind: string; text: string }[];
    }>(ctx, 'GET', `/api/projects/${project.id}/quota`, { token: researcher.token });

    assert.equal(quota.data.progress.total_current, 0);
    assert.equal(quota.data.progress.percent, 0);
    assert.equal(quota.data.recommendations.length, 1);
    assert.equal(quota.data.recommendations[0]?.kind, 'none');
    assert.match(quota.data.recommendations[0]!.text, /尚未收到任何样本/);
  });
});

/* ================================================================== */
/* Counting rule                                                      */
/* ================================================================== */

describe('配额统计口径', () => {
  test('按 Q4 教育阶段统计已完成样本', async () => {
    const fixture = await makeTemplateFixture('配额统计');

    // 学前(Q4=1) ×2，小学(Q4=2) ×3，初中(Q4=3) ×1
    for (const stage of ['1', '1', '2', '2', '2', '3']) {
      await collectWithStage(fixture, stage, { durationSeconds: 400 });
    }

    const quota = await api<{
      progress: {
        items: { category: string; current_n: number; target_n: number; percent: number; met: boolean }[];
        total_current: number;
      };
      counted_samples: number;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/quota`, { token: fixture.token });

    const byCategory = new Map(quota.data.progress.items.map((item) => [item.category, item]));

    assert.equal(byCategory.get('学前（0—6岁）')?.current_n, 2);
    assert.equal(byCategory.get('小学')?.current_n, 3);
    assert.equal(byCategory.get('初中')?.current_n, 1);
    assert.equal(byCategory.get('高中')?.current_n, 0);
    assert.equal(quota.data.progress.total_current, 6);
    assert.equal(quota.data.counted_samples, 6);
  });

  test('进行中的样本不计入配额', async () => {
    const fixture = await makeTemplateFixture('进行中不计入');
    await collectWithStage(fixture, '2', { durationSeconds: 400 });
    await collectWithStage(fixture, '2', { durationSeconds: 400, submit: false });

    const quota = await api<{ progress: { total_current: number }; counted_samples: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/quota`,
      { token: fixture.token },
    );
    assert.equal(quota.data.progress.total_current, 1, '未提交的样本不应计入配额');
  });

  test('被研究者排除的样本不计入配额（否则会掩盖真实缺口）', async () => {
    const fixture = await makeTemplateFixture('排除不计入');
    const first = await collectWithStage(fixture, '2', { durationSeconds: 400 });
    await collectWithStage(fixture, '2', { durationSeconds: 400 });
    await collectWithStage(fixture, '3', { durationSeconds: 400 });

    const before = await api<{ progress: { total_current: number } }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/quota`,
      { token: fixture.token },
    );
    assert.equal(before.data.progress.total_current, 3);

    await api(ctx, 'POST', `/api/respondents/${first.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'excluded', note: '重复提交，已核对' },
    });

    const after = await api<{
      progress: { total_current: number; items: { category: string; current_n: number }[] };
      excluded_samples: number;
      counted_samples: number;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/quota`, { token: fixture.token });

    assert.equal(after.data.progress.total_current, 2, '排除后应从配额中扣除');
    assert.equal(after.data.excluded_samples, 1);
    assert.equal(after.data.counted_samples, 2);

    const primary = after.data.progress.items.find((item) => item.category === '小学');
    assert.equal(primary?.current_n, 1, '小学由 2 降为 1');

    // 排除的样本仍然存在
    const stillThere = ctx.db.get<{ id: string }>('SELECT id FROM respondents WHERE id = ?', [
      first.respondentId,
    ]);
    assert.ok(stillThere, '平台不得因配额统计而删除样本');
  });
});

/* ================================================================== */
/* Recommendations                                                    */
/* ================================================================== */

describe('动态收集建议', () => {
  test('样本结构失衡时给出针对性的补样建议', async () => {
    const fixture = await makeTemplateFixture('结构失衡建议');

    // 小学 8 份、学前 1 份、初中 0、高中 0 → 小学占比畸高
    for (let index = 0; index < 8; index += 1) {
      await collectWithStage(fixture, '2', { durationSeconds: 400 });
    }
    await collectWithStage(fixture, '1', { durationSeconds: 400 });

    const quota = await api<{
      balance: { imbalanced: boolean; most_over: { category: string } | null; most_under: { category: string } | null };
      recommendations: { kind: string; severity: string; text: string; evidence: string[] }[];
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/quota`, { token: fixture.token });

    assert.equal(quota.data.balance.imbalanced, true);
    assert.equal(quota.data.balance.most_over?.category, '小学');

    const structure = quota.data.recommendations.find((item) => item.kind === 'structure');
    assert.ok(structure, '应给出结构失衡建议');
    assert.match(structure.text, /不均衡/);
    assert.match(structure.text, /保持目标样本结构/);
    assert.match(structure.text, /不会调整目标配额/);
    assert.ok(structure.evidence.some((line) => /观测占比/.test(line)));
  });

  test('建议包含优先收集的分类与建议渠道', async () => {
    const fixture = await makeTemplateFixture('补样建议');
    for (let index = 0; index < 3; index += 1) {
      await collectWithStage(fixture, '2', { durationSeconds: 400 });
    }

    const quota = await api<{
      recommendations: { kind: string; text: string; evidence: string[] }[];
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/quota`, { token: fixture.token });

    const channel = quota.data.recommendations.find((item) => item.kind === 'channel');
    assert.ok(channel, '应给出渠道建议');
    assert.match(channel.text, /下一阶段建议优先收集/);
    assert.ok(
      channel.evidence.some((line) => /建议渠道/.test(line)),
      '渠道建议应给出具体渠道',
    );
    assert.ok(
      channel.evidence.some((line) => /微信|学校|社区/.test(line)) || channel.evidence.some((line) => /渠道/.test(line)),
      '渠道证据应包含可识别的渠道名称',
    );
  });

  test('全部达标时给出饱和提示而非继续收集', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '饱和提示');

    // 把配额改小，方便在测试中达标
    await api(ctx, 'PUT', `/api/projects/${project.id}/quota`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: true,
          categories: [{ dimension: 'STAGE', category: '小学', target_n: 1 }],
        },
      },
    });

    const shareToken = await publishQuestionnaire(ctx, researcher.token, project.questionnaireId!);
    const fixture: TemplateFixture = {
      projectId: project.id,
      questionnaireId: project.questionnaireId!,
      shareToken,
      token: researcher.token,
    };
    await collectWithStage(fixture, '2', { durationSeconds: 400 });

    const quota = await api<{ recommendations: { kind: string; text: string }[] }>(
      ctx,
      'GET',
      `/api/projects/${project.id}/quota`,
      { token: researcher.token },
    );
    const saturation = quota.data.recommendations.find((item) => item.kind === 'saturation');
    assert.ok(saturation, '达标后应提示饱和');
    assert.match(saturation.text, /均已达到目标配额/);
  });
});

/* ================================================================== */
/* Configuration                                                      */
/* ================================================================== */

describe('配额配置管理', () => {
  test('可列出可作为配额维度的分类变量', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '配额维度');

    const response = await api<
      { variable: string; question_code: string; label: string; categories: string[] }[]
    >(ctx, 'GET', `/api/projects/${project.id}/quota/dimensions`, { token: researcher.token });

    assert.equal(response.status, 200);
    const variables = response.data.map((item) => item.variable);
    assert.ok(variables.includes('STAGE'), '教育阶段应可作为配额维度');
    assert.ok(variables.includes('AREA'), '地区应可作为配额维度');

    const stage = response.data.find((item) => item.variable === 'STAGE');
    assert.equal(stage?.question_code, 'Q4');
    assert.deepEqual(stage?.categories, ['学前（0—6岁）', '小学', '初中', '高中']);
  });

  test('可更新配额配置并立即反映到进度计算', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '更新配额');

    const updated = await api<{
      progress: { total_target: number; items: { category: string; target_n: number }[] };
      preserve_structure: boolean;
    }>(ctx, 'PUT', `/api/projects/${project.id}/quota`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: false,
          categories: [
            { dimension: 'STAGE', category: '小学', target_n: 500 },
            { dimension: 'STAGE', category: '初中', target_n: 500 },
          ],
        },
      },
    });

    assert.equal(updated.status, 200);
    assert.equal(updated.data.progress.total_target, 1000);
    assert.equal(updated.data.progress.items.length, 2);
    assert.equal(updated.data.preserve_structure, false);
  });

  test('拒绝非法配额配置并逐项说明原因', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '非法配额');

    const response = await api<never>(ctx, 'PUT', `/api/projects/${project.id}/quota`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: true,
          categories: [{ dimension: 'STAGE', category: '小学', target_n: 0 }],
        },
      },
    });

    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /配额配置校验失败/);
    const details = response.error?.details as { field: string; message: string }[];
    assert.ok(details.some((item) => item.field.includes('target_n')));
  });

  test('缺少 quota_config 字段时拒绝请求', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '缺少字段');

    const response = await api(ctx, 'PUT', `/api/projects/${project.id}/quota`, {
      token: researcher.token,
      body: {},
    });
    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /quota_config/);
  });

  test('传 null 可清除配额配置', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '清除配额');

    const cleared = await api<{ enabled: boolean; progress: { items: unknown[] }; recommendations: { kind: string }[] }>(
      ctx,
      'PUT',
      `/api/projects/${project.id}/quota`,
      { token: researcher.token, body: { quota_config: null } },
    );

    assert.equal(cleared.status, 200);
    assert.equal(cleared.data.enabled, false);
    assert.deepEqual(cleared.data.progress.items, []);
    assert.equal(cleared.data.recommendations[0]?.kind, 'none');

    const detail = await api<{ project: { quota_config: unknown } }>(
      ctx,
      'GET',
      `/api/projects/${project.id}`,
      { token: researcher.token },
    );
    assert.equal(detail.data.project.quota_config, null);
  });

  test('配额维度对应题目不存在时如实说明而不是静默归零', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '维度缺失');

    await api(ctx, 'PUT', `/api/projects/${project.id}/quota`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: true,
          categories: [{ dimension: 'NOT_A_VARIABLE', category: '任意', target_n: 10 }],
        },
      },
    });

    const quota = await api<{ dimension_question_code: string | null; progress: { items: { current_n: number }[] } }>(
      ctx,
      'GET',
      `/api/projects/${project.id}/quota`,
      { token: researcher.token },
    );
    assert.equal(quota.data.dimension_question_code, null, '找不到维度题目时应返回 null');
    assert.equal(quota.data.progress.items[0]?.current_n, 0);
  });
});

/* ================================================================== */
/* Isolation                                                          */
/* ================================================================== */

describe('配额数据隔离', () => {
  test('他人无法读取我的配额状态', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, owner.token, '隔离配额');

    const response = await api(ctx, 'GET', `/api/projects/${project.id}/quota`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });

  test('他人无法修改我的配额配置', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, owner.token, '隔离配额写入');

    const response = await api(ctx, 'PUT', `/api/projects/${project.id}/quota`, {
      token: intruder.token,
      body: { quota_config: null },
    });
    assert.equal(response.status, 404);

    const check = await api<{ project: { quota_config: unknown } }>(
      ctx,
      'GET',
      `/api/projects/${project.id}`,
      { token: owner.token },
    );
    assert.ok(check.data.project.quota_config !== null, '配额配置不应被他人清除');
  });

  test('未登录无法访问配额接口', async () => {
    const owner = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, owner.token, '未登录配额');
    const response = await api(ctx, 'GET', `/api/projects/${project.id}/quota`);
    assert.equal(response.status, 401);
  });
});
