/**
 * Question service — the Questionnaire Builder backend.
 *
 * Responsibilities:
 *  - create / read / update / delete / duplicate / reorder questions
 *  - validate every definition with the shared validator before persisting
 *  - refuse structural edits once the questionnaire is published (locked)
 *  - keep `sort_order` contiguous, because navigation and the codebook both
 *    depend on a dense, unambiguous order
 */

import {
  validateQuestionInput,
  type Question,
  type QuestionLogic,
  type QuestionOptions,
  type QuestionType,
  type ScoringRule,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { insertRow, updateRow } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import {
  listQuestions,
  requireQuestionnaire,
  assertEditable,
  findQuestionById,
} from './questionnaire.service.js';
import { toQuestion, type QuestionRow } from './mappers.js';

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

/** Next free `Q<n>` code for a questionnaire. */
export function suggestQuestionCode(db: Db, questionnaireId: string): string {
  const codes = db
    .all<{ question_code: string }>('SELECT question_code FROM questions WHERE questionnaire_id = ?', [
      questionnaireId,
    ])
    .map((row) => row.question_code);
  const used = new Set(codes);
  let n = codes.length + 1;
  while (used.has(`Q${n}`)) n += 1;
  return `Q${n}`;
}

/** Renumber sort_order to 1..n, preserving current relative order. */
function normalizeOrder(db: Db, questionnaireId: string): void {
  const rows = db.all<{ id: string }>(
    'SELECT id FROM questions WHERE questionnaire_id = ? ORDER BY sort_order ASC, created_at ASC',
    [questionnaireId],
  );
  const timestamp = nowIso();
  rows.forEach((row, index) => {
    updateRow(db, 'questions', { sort_order: index + 1, updated_at: timestamp }, { id: row.id });
  });
}

/** Shift sort_order of every question strictly after `afterOrder`. */
function shiftOrders(db: Db, questionnaireId: string, afterOrder: number, by = 1): void {
  db.run(
    'UPDATE questions SET sort_order = sort_order + ? WHERE questionnaire_id = ? AND sort_order > ?',
    [by, questionnaireId, afterOrder],
  );
}

/* ------------------------------------------------------------------ */
/* Validation gateway                                                 */
/* ------------------------------------------------------------------ */

function assertValidDefinition(input: {
  question_code?: unknown;
  question_text?: unknown;
  question_type?: unknown;
  options?: unknown;
  scoring_rule?: unknown;
  logic?: unknown;
  variable_name?: unknown;
}): void {
  const result = validateQuestionInput(input);
  if (!result.valid) {
    throw ApiError.validation(
      `题目定义校验失败，共 ${result.errors.length} 处问题。`,
      result.errors,
    );
  }
}

/* ------------------------------------------------------------------ */
/* Create                                                             */
/* ------------------------------------------------------------------ */

export interface CreateQuestionInput {
  question_code?: string;
  question_text: string;
  question_type: QuestionType;
  options?: QuestionOptions;
  required?: boolean;
  dimension?: string | null;
  variable_name?: string | null;
  section?: string | null;
  help_text?: string | null;
  logic?: QuestionLogic | null;
  scoring_rule?: ScoringRule | null;
  /** Insert position (1-based). Appends when omitted. */
  position?: number;
}

export function createQuestion(
  db: Db,
  questionnaireId: string,
  input: CreateQuestionInput,
): Question {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  assertEditable(questionnaire);

  const code = (input.question_code ?? '').trim() || suggestQuestionCode(db, questionnaireId);
  if (!/^[A-Za-z][A-Za-z0-9_]{0,31}$/.test(code)) {
    throw ApiError.validation('题号必须以字母开头，且只能包含字母、数字与下划线。', [
      { field: 'question_code', message: `非法题号：${code}` },
    ]);
  }
  const duplicate = db.get<{ id: string }>(
    'SELECT id FROM questions WHERE questionnaire_id = ? AND question_code = ?',
    [questionnaireId, code],
  );
  if (duplicate) {
    throw ApiError.conflict(`题号 ${code} 已存在，请使用其他题号。`);
  }

  assertValidDefinition({
    question_code: code,
    question_text: input.question_text,
    question_type: input.question_type,
    options: input.options ?? {},
    scoring_rule: input.scoring_rule ?? undefined,
    logic: input.logic ?? undefined,
    variable_name: input.variable_name ?? undefined,
  });

  const maxOrder = Number(
    db.scalar<number>('SELECT COALESCE(MAX(sort_order), 0) AS m FROM questions WHERE questionnaire_id = ?', [
      questionnaireId,
    ]) ?? 0,
  );

  const position =
    input.position === undefined ? maxOrder + 1 : Math.min(Math.max(input.position, 1), maxOrder + 1);

  const id = newId();
  const timestamp = nowIso();

  db.transaction(() => {
    if (position <= maxOrder) shiftOrders(db, questionnaireId, position - 1);
    insertRow(db, 'questions', {
      id,
      questionnaire_id: questionnaireId,
      question_code: code,
      question_text: input.question_text,
      question_type: input.question_type,
      options: JSON.stringify(input.options ?? {}),
      required: input.required === false ? 0 : 1,
      dimension: input.dimension ?? null,
      variable_name: input.variable_name ?? null,
      sort_order: position,
      section: input.section ?? null,
      help_text: input.help_text ?? null,
      logic: input.logic ? JSON.stringify(input.logic) : null,
      scoring_rule: input.scoring_rule ? JSON.stringify(input.scoring_rule) : null,
      created_at: timestamp,
      updated_at: timestamp,
    });
    normalizeOrder(db, questionnaireId);
  });

  const created = findQuestionById(db, id);
  if (!created) throw new ApiError('INTERNAL_ERROR', '创建题目后无法读取该题目。');
  return created;
}

/* ------------------------------------------------------------------ */
/* Update                                                             */
/* ------------------------------------------------------------------ */

export interface UpdateQuestionInput {
  question_code?: string;
  question_text?: string;
  question_type?: QuestionType;
  options?: QuestionOptions;
  required?: boolean;
  dimension?: string | null;
  variable_name?: string | null;
  section?: string | null;
  help_text?: string | null;
  logic?: QuestionLogic | null;
  scoring_rule?: ScoringRule | null;
}

export function updateQuestion(db: Db, questionId: string, patch: UpdateQuestionInput): Question {
  const existing = findQuestionById(db, questionId);
  if (!existing) throw ApiError.notFound('题目不存在。');

  const questionnaire = requireQuestionnaire(db, existing.questionnaire_id);
  assertEditable(questionnaire);

  const nextCode = patch.question_code?.trim() ?? existing.question_code;
  if (patch.question_code !== undefined) {
    if (nextCode === '') throw ApiError.validation('题号不能为空。');
    if (nextCode !== existing.question_code) {
      const clash = db.get<{ id: string }>(
        'SELECT id FROM questions WHERE questionnaire_id = ? AND question_code = ? AND id <> ?',
        [existing.questionnaire_id, nextCode, questionId],
      );
      if (clash) throw ApiError.conflict(`题号 ${nextCode} 已被占用。`);
    }
  }

  const merged = {
    question_code: nextCode,
    question_text: patch.question_text ?? existing.question_text,
    question_type: patch.question_type ?? existing.question_type,
    options: patch.options ?? existing.options,
    scoring_rule: (patch.scoring_rule === undefined ? existing.scoring_rule : patch.scoring_rule) ?? undefined,
    logic: (patch.logic === undefined ? existing.logic : patch.logic) ?? undefined,
    variable_name:
      (patch.variable_name === undefined ? existing.variable_name : patch.variable_name) ?? undefined,
  };

  assertValidDefinition(merged);

  const update: Record<string, unknown> = { updated_at: nowIso() };
  update['question_code'] = nextCode;
  update['question_text'] = merged.question_text;
  update['question_type'] = merged.question_type;
  update['options'] = JSON.stringify(merged.options ?? {});
  if (patch.required !== undefined) update['required'] = patch.required ? 1 : 0;
  if (patch.dimension !== undefined) update['dimension'] = patch.dimension;
  if (patch.variable_name !== undefined) update['variable_name'] = patch.variable_name;
  if (patch.section !== undefined) update['section'] = patch.section;
  if (patch.help_text !== undefined) update['help_text'] = patch.help_text;
  if (patch.logic !== undefined) update['logic'] = patch.logic ? JSON.stringify(patch.logic) : null;
  if (patch.scoring_rule !== undefined) {
    update['scoring_rule'] = patch.scoring_rule ? JSON.stringify(patch.scoring_rule) : null;
  }

  updateRow(db, 'questions', update, { id: questionId });

  const updated = findQuestionById(db, questionId);
  if (!updated) throw new ApiError('INTERNAL_ERROR', '更新题目后无法读取该题目。');
  return updated;
}

/* ------------------------------------------------------------------ */
/* Delete                                                             */
/* ------------------------------------------------------------------ */

export interface DeleteQuestionResult {
  deleted: boolean;
  /** Existing logic rules elsewhere that referenced the deleted question. */
  dangling_logic: { question_code: string; rule_id: string; message: string }[];
}

/**
 * Delete a question. Logic rules in *other* questions that referenced it are
 * reported rather than silently left broken, so the researcher can repair them
 * before publishing.
 */
export function deleteQuestion(db: Db, questionId: string): DeleteQuestionResult {
  const existing = findQuestionById(db, questionId);
  if (!existing) throw ApiError.notFound('题目不存在。');

  const questionnaire = requireQuestionnaire(db, existing.questionnaire_id);
  assertEditable(questionnaire);

  const others = listQuestions(db, existing.questionnaire_id).filter((q) => q.id !== questionId);
  const dangling: DeleteQuestionResult['dangling_logic'] = [];

  for (const question of others) {
    for (const rule of question.logic?.rules ?? []) {
      const conditions = rule.conditions ?? (rule.when ? [rule.when] : []);
      const referencesCondition = conditions.some((c) => c.questionCode === existing.question_code);
      const referencesTarget =
        rule.action.type === 'jump_to' && rule.action.target === existing.question_code;
      if (referencesCondition || referencesTarget) {
        dangling.push({
          question_code: question.question_code,
          rule_id: rule.id,
          message: `${question.question_code} 的逻辑规则引用了被删除的 ${existing.question_code}。`,
        });
      }
    }
  }

  db.transaction(() => {
    db.run('DELETE FROM questions WHERE id = ?', [questionId]);
    normalizeOrder(db, existing.questionnaire_id);
  });

  return { deleted: true, dangling_logic: dangling };
}

/* ------------------------------------------------------------------ */
/* Duplicate                                                          */
/* ------------------------------------------------------------------ */

/**
 * Duplicate a question directly after the original.
 *
 * Logic rules that referenced the *original* question code are self-references
 * once copied, so they are dropped from the clone (the researcher almost never
 * wants a duplicate that hides itself when it is answered).
 */
export function duplicateQuestion(db: Db, questionId: string): Question {
  const source = findQuestionById(db, questionId);
  if (!source) throw ApiError.notFound('题目不存在。');

  const questionnaire = requireQuestionnaire(db, source.questionnaire_id);
  assertEditable(questionnaire);

  const newCode = suggestQuestionCode(db, source.questionnaire_id);
  const cleanedLogic = source.logic
    ? {
        rules: source.logic.rules.filter((rule) => {
          const conditions = rule.conditions ?? (rule.when ? [rule.when] : []);
          if (conditions.some((c) => c.questionCode === source.question_code)) return false;
          if (rule.action.type === 'jump_to' && rule.action.target === source.question_code) return false;
          return true;
        }),
      }
    : null;

  const id = newId();
  const timestamp = nowIso();

  db.transaction(() => {
    shiftOrders(db, source.questionnaire_id, source.sort_order);
    insertRow(db, 'questions', {
      id,
      questionnaire_id: source.questionnaire_id,
      question_code: newCode,
      question_text: `${source.question_text}（副本）`,
      question_type: source.question_type,
      options: JSON.stringify(source.options ?? {}),
      required: source.required ? 1 : 0,
      dimension: source.dimension,
      // A duplicated variable name would silently merge two items in SPSS.
      variable_name: source.variable_name ? `${source.variable_name}_C` : null,
      sort_order: source.sort_order + 1,
      section: source.section,
      help_text: source.help_text,
      logic: cleanedLogic && cleanedLogic.rules.length > 0 ? JSON.stringify(cleanedLogic) : null,
      scoring_rule: source.scoring_rule ? JSON.stringify(source.scoring_rule) : null,
      created_at: timestamp,
      updated_at: timestamp,
    });
    normalizeOrder(db, source.questionnaire_id);
  });

  const created = findQuestionById(db, id);
  if (!created) throw new ApiError('INTERNAL_ERROR', '复制题目后无法读取该题目。');
  return created;
}

/* ------------------------------------------------------------------ */
/* Reorder                                                            */
/* ------------------------------------------------------------------ */

export interface ReorderResult {
  questions: Question[];
  warnings: string[];
}

/**
 * Reorder a questionnaire.
 *
 * Backward jumps are only a *warning*: legitimate instruments do loop back
 * (e.g. re-asking after a follow-up), but the researcher should be told.
 */
export function reorderQuestions(
  db: Db,
  questionnaireId: string,
  orderedIds: string[],
): ReorderResult {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  assertEditable(questionnaire);

  const current = listQuestions(db, questionnaireId);
  const currentIds = new Set(current.map((q) => q.id));
  const provided = new Set(orderedIds);

  if (orderedIds.length !== current.length) {
    throw ApiError.validation(
      `排序请求包含 ${orderedIds.length} 道题，但问卷共有 ${current.length} 道题。请提交完整且不重复的题目列表。`,
    );
  }
  if (provided.size !== orderedIds.length) {
    throw ApiError.validation('排序请求中存在重复的题目 ID。');
  }
  for (const id of orderedIds) {
    if (!currentIds.has(id)) {
      throw ApiError.validation(`题目 ${id} 不属于该问卷。`);
    }
  }

  const timestamp = nowIso();
  db.transaction(() => {
    orderedIds.forEach((id, index) => {
      updateRow(db, 'questions', { sort_order: index + 1, updated_at: timestamp }, { id });
    });
  });

  const reordered = listQuestions(db, questionnaireId);

  const orderByCode = new Map(reordered.map((q, index) => [q.question_code, index + 1]));
  const warnings: string[] = [];
  for (const question of reordered) {
    for (const rule of question.logic?.rules ?? []) {
      if (rule.action.type !== 'jump_to' || rule.action.target === 'END') continue;
      const targetOrder = orderByCode.get(rule.action.target);
      if (targetOrder !== undefined && targetOrder < question.sort_order) {
        warnings.push(
          `${question.question_code} 的跳转目标 ${rule.action.target} 现位于其之前，可能造成循环作答。`,
        );
      }
    }
  }

  return { questions: reordered, warnings };
}

/** Move a single question up or down by one position. */
export function moveQuestion(db: Db, questionId: string, direction: 'up' | 'down'): Question[] {
  const question = findQuestionById(db, questionId);
  if (!question) throw ApiError.notFound('题目不存在。');

  const questionnaire = requireQuestionnaire(db, question.questionnaire_id);
  assertEditable(questionnaire);

  const ordered = listQuestions(db, question.questionnaire_id);
  const index = ordered.findIndex((q) => q.id === questionId);
  const swapWith = direction === 'up' ? index - 1 : index + 1;
  if (swapWith < 0 || swapWith >= ordered.length) {
    // Already at the boundary — a no-op rather than an error.
    return ordered;
  }

  const ids = ordered.map((q) => q.id);
  const a = ids[index]!;
  const b = ids[swapWith]!;
  ids[index] = b;
  ids[swapWith] = a;

  return reorderQuestions(db, question.questionnaire_id, ids).questions;
}

/* ------------------------------------------------------------------ */
/* Bulk read for the builder                                          */
/* ------------------------------------------------------------------ */

export interface BuilderState {
  questions: Question[];
  suggested_next_code: string;
  editable: boolean;
  lock_reason: string | null;
}

export function getBuilderState(db: Db, questionnaireId: string): BuilderState {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  const questions = listQuestions(db, questionnaireId);
  const editable = !questionnaire.locked && questionnaire.status !== 'published';

  return {
    questions,
    suggested_next_code: suggestQuestionCode(db, questionnaireId),
    editable,
    lock_reason: editable
      ? null
      : `该问卷（${questionnaire.version}）已发布并锁定。如需修改，请建立新版本。`,
  };
}

export { toQuestion };
