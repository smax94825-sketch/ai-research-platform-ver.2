/**
 * Correlation analysis (PHASE 6).
 *
 * The heatmap and the pair table carry the same information on purpose: the
 * matrix is what makes the pattern visible, the table is what makes it citable.
 * Neither hides the method — the engine mixes Pearson and Spearman across pairs
 * depending on each variable's measurement level, so the method is printed per
 * cell and per row.
 *
 * Correlation is not causation, and with a large matrix some pair will be
 * "significant" by chance; both statements are part of the page.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Heatmap } from '../../components/charts';
import { Card, CardHeader, LoadingBlock } from '../../components/ui';
import {
  api,
  ApiClientError,
  type AnalysisCorrelationResponse,
} from '../../lib/api';
import { formatNumber, formatPValue, formatStat, significanceMark } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  UnavailableNotice,
  unavailableReason,
  useAnalysisProject,
} from './shared';

function methodName(method: string): string {
  return method === 'pearson' ? 'Pearson 积矩相关' : method === 'spearman' ? 'Spearman 等级相关' : method;
}

export function CorrelationPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisCorrelationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setData(await api.analysis.correlation(projectId));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载相关分析结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const reason = unavailableReason(data);
  const matrix = data && data.available ? data : null;

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Correlation"
          subtitle="相关分析：变量间关联的方向、强度与显著性，逐格标注所用方法。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在计算相关矩阵…" />
        ) : !data ? null : reason ? (
          <UnavailableNotice reason={reason} title="无法计算相关矩阵" />
        ) : matrix ? (
          <>
            <MethodNote>
              <p>{matrix.note}</p>
              <p>
                引擎版本 {matrix.engine_version}；矩阵包含 {matrix.variables.length} 个变量，
                共 {matrix.pairs.length} 个变量对。相关系数的正负与显著性均基于双侧检验，
                {matrix.mixed_methods
                  ? '本矩阵同时使用了 Pearson 与 Spearman 两种方法（原因见下表逐行说明）。'
                  : '本矩阵所有变量对均满足 Pearson 相关的测量层次要求。'}
              </p>
              <p>
                变量对的有效 n 各不相同（整例删除），解读时应以每格/每行报告的 n 为准；
                相关显著只说明共变关系存在，不能据此推断因果。
              </p>
            </MethodNote>

            <Card>
              <CardHeader
                title="相关矩阵"
                description="颜色表示方向与强度（蓝负红正），格内数字为相关系数，星号为显著性，格内下方字母为该方法对的所用方法。"
              />
              <Heatmap
                variables={matrix.variables}
                matrix={matrix.matrix}
                pValues={matrix.p_values}
                methods={matrix.methods}
                labels={matrix.labels}
              />
            </Card>

            <Card padded={false}>
              <div className="border-b border-ink-200 px-5 py-4">
                <h2 className="text-base font-semibold text-ink-900">
                  变量对明细（{matrix.pairs.length} 对）
                </h2>
                <p className="mt-1 text-sm text-ink-500">
                  逐对给出所用方法及其原因、有效 n、95% 置信区间与共享方差；
                  Spearman 相关不报告置信区间（其区间在等级尺度上不是分布无关的，故不近似给出）。
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] text-sm">
                  <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-4 py-2 text-left">变量对</th>
                      <th className="px-4 py-2 text-left">方法</th>
                      <th className="px-4 py-2 text-right">r</th>
                      <th className="px-4 py-2 text-left">显著性</th>
                      <th className="px-4 py-2 text-right">n</th>
                      <th className="px-4 py-2 text-right">95% CI</th>
                      <th className="px-4 py-2 text-right">共享方差</th>
                      <th className="px-4 py-2 text-left">效应量</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {matrix.pairs.map((pair) => (
                      <tr key={`${pair.left}-${pair.right}`}>
                        <td className="px-4 py-2 text-ink-900">{`${pair.left} × ${pair.right}`}</td>
                        <td className="px-4 py-2">
                          <span className="text-ink-800">{methodName(pair.method)}</span>
                          <span className="mt-0.5 block text-xs text-ink-500">{pair.method_reason}</span>
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-900">
                          {pair.r === null ? '—' : `${formatStat(pair.r, 3)}${significanceMark(pair.p_value)}`}
                        </td>
                        <td className="px-4 py-2 text-xs text-ink-700">{formatPValue(pair.p_value)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-700">{formatNumber(pair.n)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-700">
                          {pair.ci_lower === null || pair.ci_upper === null
                            ? '—'
                            : `[${formatStat(pair.ci_lower, 3)}, ${formatStat(pair.ci_upper, 3)}]`}
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-700">
                          {pair.shared_variance_percent === null
                            ? '—'
                            : `${formatStat(pair.shared_variance_percent, 2)}%`}
                        </td>
                        <td className="px-4 py-2 text-xs text-ink-600">
                          {pair.effective_size ? pair.effective_size.text : '—'}
                          {pair.effective_size && (
                            <span className="mt-0.5 block text-ink-400">{pair.effective_size.convention}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            <MethodNote title="解读时必须注意">
              <p>
                显著性标记 * p &lt; 0.05、** p &lt; 0.01、*** p &lt; 0.001（双侧，未做多重比较校正）。
                本矩阵共有 {matrix.pairs.length} 个变量对，若全部按 α = 0.05 检验，
                至少出现一次假阳性的概率约为{' '}
                {((1 - 0.95 ** Math.max(matrix.pairs.length, 1)) * 100).toFixed(1)}%，
                因此不应只挑显著的格子下结论。
              </p>
              <p>
                相关系数对取值范围和异常值敏感：若某变量取值集中、方差很小，其相关会被系统性低估；
                共享方差百分比（r²）才是两变量重叠变异的比例，比 r 本身更接近「能解释多少」。
              </p>
            </MethodNote>
          </>
        ) : null}
      </div>
    </AnalysisProjectGate>
  );
}
