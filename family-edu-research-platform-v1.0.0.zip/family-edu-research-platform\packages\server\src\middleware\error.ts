/**
 * Error handling middleware.
 *
 * Converts thrown `ApiError`s into the documented envelope
 * `{ error: { code, message, details } }`. Unexpected errors are logged with a
 * stack trace but reported to the client without internal details, so database
 * paths and SQL never leak through the API.
 */

import type { ErrorRequestHandler, RequestHandler } from 'express';
import { ApiError } from '../util/errors.js';

export const notFoundHandler: RequestHandler = (req, res) => {
  res.status(404).json({
    error: {
      code: 'NOT_FOUND',
      message: `接口不存在：${req.method} ${req.path}`,
      details: null,
    },
  });
};

export interface ErrorHandlerOptions {
  /** Print unexpected errors (kept on in dev/test, quiet in production). */
  logUnexpected?: boolean;
}

export function createErrorHandler(options: ErrorHandlerOptions = {}): ErrorRequestHandler {
  const logUnexpected = options.logUnexpected ?? true;

  return (error, _req, res, next) => {
    if (res.headersSent) {
      next(error);
      return;
    }

    if (error instanceof ApiError) {
      res.status(error.status).json({
        error: { code: error.code, message: error.message, details: error.details },
      });
      return;
    }

    // Body-parser surfaces malformed JSON as a SyntaxError with `body` set.
    if (error instanceof SyntaxError && 'body' in error) {
      res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: '请求体不是合法的 JSON。',
          details: null,
        },
      });
      return;
    }

    if (logUnexpected) {
      console.error('[ferp] Unexpected error:', error);
    }

    res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: '服务器内部错误，请稍后重试或联系管理员。',
        details: null,
      },
    });
  };
}
