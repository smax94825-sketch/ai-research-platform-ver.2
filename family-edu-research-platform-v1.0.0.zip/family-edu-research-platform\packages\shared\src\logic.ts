/**
 * Conditional questionnaire logic engine.
 *
 * Implements the researcher-editable rule model:
 *
 *     IF <question> <operator> <value>  THEN jump_to <question> | show | hide | require
 *
 * The engine is pure and side-effect free so it can be unit tested, reused by
 * the builder preview and executed identically by the respondent survey.
 */

import type {
  LogicCondition,
  LogicOperator,
  LogicRule,
  Question,
  QuestionLogic,
} from './types.js';
import { asArray, asNumber, isBlank, looseEquals, type AnswerMap, type AnswerValue } from './values.js';

export type { AnswerMap, AnswerValue };

/** Sentinel target meaning "end of questionnaire". */
export const END_OF_QUESTIONNAIRE = 'END';

/* ------------------------------------------------------------------ */
/* Condition evaluation                                               */
/* ------------------------------------------------------------------ */

export function evaluateCondition(condition: LogicCondition, answers: AnswerMap): boolean {
  const actual = answers[condition.questionCode];
  const operator: LogicOperator = condition.operator;

  switch (operator) {
    case 'answered':
      return !isBlank(actual);
    case 'not_answered':
      return isBlank(actual);
    case 'eq':
      return asArray(actual).some((v) => looseEquals(v, condition.value));
    case 'neq':
      return !asArray(actual).some((v) => looseEquals(v, condition.value));
    case 'in': {
      const list = Array.isArray(condition.value) ? condition.value : [condition.value];
      return asArray(actual).some((v) => list.some((c) => looseEquals(v, c)));
    }
    case 'not_in': {
      const list = Array.isArray(condition.value) ? condition.value : [condition.value];
      return !asArray(actual).some((v) => list.some((c) => looseEquals(v, c)));
    }
    case 'gt':
    case 'gte':
    case 'lt':
    case 'lte': {
      const left = asNumber(actual);
      const right = asNumber(condition.value as AnswerValue);
      if (left === null || right === null) return false;
      if (operator === 'gt') return left > right;
      if (operator === 'gte') return left >= right;
      if (operator === 'lt') return left < right;
      return left <= right;
    }
    case 'contains_any': {
      const list = Array.isArray(condition.value) ? condition.value : [condition.value];
      const selected = asArray(actual);
      return list.some((c) => selected.some((v) => looseEquals(v, c)));
    }
    case 'contains_all': {
      const list = Array.isArray(condition.value) ? condition.value : [condition.value];
      const selected = asArray(actual);
      return list.every((c) => selected.some((v) => looseEquals(v, c)));
    }
    default: {
      // Exhaustiveness guard: an unknown operator must never silently pass.
      const never: never = operator;
      throw new Error(`Unsupported logic operator: ${String(never)}`);
    }
  }
}

export function conditionsOf(rule: LogicRule): LogicCondition[] {
  if (rule.conditions && rule.conditions.length > 0) return rule.conditions;
  if (rule.when) return [rule.when];
  return [];
}

export function evaluateRule(rule: LogicRule, answers: AnswerMap): boolean {
  const conditions = conditionsOf(rule);
  if (conditions.length === 0) return false;
  const match = rule.match ?? 'all';
  return match === 'any'
    ? conditions.some((c) => evaluateCondition(c, answers))
    : conditions.every((c) => evaluateCondition(c, answers));
}

/* ------------------------------------------------------------------ */
/* Visibility                                                         */
/* ------------------------------------------------------------------ */

/**
 * Resolve whether a question should be shown for the given answers.
 *
 * Semantics:
 *  - `hide` rules win: if any matching `hide` rule exists the question is hidden.
 *  - If the question declares at least one `show` rule it is hidden until one
 *    of them matches (opt-in visibility).
 *  - Otherwise the question is visible.
 *
 * `page_break` questions are structural and always visible.
 */
export function isQuestionVisible(question: Question, answers: AnswerMap): boolean {
  if (question.question_type === 'page_break') return true;
  const rules = question.logic?.rules ?? [];
  if (rules.length === 0) return true;

  const hideRules = rules.filter((r) => r.action.type === 'hide');
  if (hideRules.some((r) => evaluateRule(r, answers))) return false;

  const showRules = rules.filter((r) => r.action.type === 'show');
  if (showRules.length > 0) return showRules.some((r) => evaluateRule(r, answers));

  return true;
}

/** Effective `required` flag after applying `require` rules. */
export function isQuestionRequired(question: Question, answers: AnswerMap): boolean {
  if (question.required) return true;
  const rules = question.logic?.rules ?? [];
  return rules
    .filter((r) => r.action.type === 'require')
    .some((r) => evaluateRule(r, answers));
}

/** All currently visible, answerable questions in instrument order. */
export function visibleQuestions(questions: Question[], answers: AnswerMap): Question[] {
  return questions
    .filter((q) => q.question_type !== 'page_break')
    .filter((q) => isQuestionVisible(q, answers));
}

/* ------------------------------------------------------------------ */
/* Navigation                                                         */
/* ------------------------------------------------------------------ */

export function sortQuestions(questions: Question[]): Question[] {
  return [...questions].sort((a, b) => a.sort_order - b.sort_order);
}

/**
 * Resolve the jump target declared by a question, if any rule currently matches.
 * Returns a question code, or END_OF_QUESTIONNAIRE, or null when no jump applies.
 */
export function resolveJumpTarget(question: Question, answers: AnswerMap): string | null {
  const rules = question.logic?.rules ?? [];
  for (const rule of rules) {
    if (rule.action.type !== 'jump_to') continue;
    if (evaluateRule(rule, answers)) return rule.action.target;
  }
  return null;
}

export interface NavigationResult {
  /** Index into the sorted question array, or -1 when the survey is finished. */
  index: number;
  question: Question | null;
  /** True when the flow reached END (explicit jump or past the last question). */
  finished: boolean;
}

/**
 * Compute the next question after `fromIndex`.
 *
 * Applies the current question's `jump_to` rules first; otherwise walks forward
 * skipping hidden questions. Every skipped hidden question is also dropped from
 * navigation so a hidden question can never be presented.
 */
export function nextQuestion(
  questions: Question[],
  answers: AnswerMap,
  fromIndex: number,
): NavigationResult {
  const ordered = sortQuestions(questions);

  if (fromIndex >= 0 && fromIndex < ordered.length) {
    const current = ordered[fromIndex]!;
    const target = resolveJumpTarget(current, answers);
    if (target === END_OF_QUESTIONNAIRE) return { index: -1, question: null, finished: true };
    if (target) {
      const targetIndex = ordered.findIndex((q) => q.question_code === target);
      if (targetIndex === -1) {
        throw new Error(
          `Jump target "${target}" declared on ${current.question_code} does not exist in this questionnaire.`,
        );
      }
      return walkForward(ordered, answers, targetIndex);
    }
  }

  return walkForward(ordered, answers, fromIndex + 1);
}

function walkForward(ordered: Question[], answers: AnswerMap, startIndex: number): NavigationResult {
  for (let i = Math.max(startIndex, 0); i < ordered.length; i += 1) {
    const candidate = ordered[i]!;
    if (candidate.question_type === 'page_break') continue;
    if (isQuestionVisible(candidate, answers)) return { index: i, question: candidate, finished: false };
  }
  return { index: -1, question: null, finished: true };
}

/** Compute the previous visible question, walking backwards. */
export function previousQuestion(
  questions: Question[],
  answers: AnswerMap,
  fromIndex: number,
): NavigationResult {
  const ordered = sortQuestions(questions);
  for (let i = Math.min(fromIndex - 1, ordered.length - 1); i >= 0; i -= 1) {
    const candidate = ordered[i]!;
    if (candidate.question_type === 'page_break') continue;
    if (isQuestionVisible(candidate, answers)) return { index: i, question: candidate, finished: false };
  }
  return { index: -1, question: null, finished: false };
}

/**
 * Walk the whole questionnaire from the start with the supplied answers and
 * return the ordered list of question codes an actual respondent would see.
 *
 * Stops as soon as the flow revisits a question it has already presented: a
 * questionnaire that loops back on itself would otherwise never terminate.
 * Used by the builder preview and by the logic validator.
 */
export function resolveFlowPath(questions: Question[], answers: AnswerMap): string[] {
  return walkFlowPath(questions, answers).path;
}

/**
 * Flow walk that also reports whether it terminated because of a cycle.
 * A cycle is a questionnaire-design defect, so the validator surfaces it.
 */
export function walkFlowPath(
  questions: Question[],
  answers: AnswerMap,
): { path: string[]; cycle: boolean } {
  const ordered = sortQuestions(questions);
  const path: string[] = [];
  const visited = new Set<number>();
  let index = -1;
  // Hard iteration guard in addition to cycle detection.
  const guard = ordered.length + 1;

  for (let step = 0; step <= guard; step += 1) {
    const next = nextQuestion(ordered, answers, index);
    if (next.finished || !next.question) return { path, cycle: false };
    if (next.index === index) return { path, cycle: true };
    if (visited.has(next.index)) return { path, cycle: true };
    visited.add(next.index);
    path.push(next.question.question_code);
    index = next.index;
  }
  return { path, cycle: true };
}

/* ------------------------------------------------------------------ */
/* Validation                                                         */
/* ------------------------------------------------------------------ */

export interface LogicValidationIssue {
  questionCode: string;
  ruleId: string | null;
  severity: 'error' | 'warning';
  message: string;
}

/**
 * Validate a questionnaire's logic graph: dangling jump targets, self jumps,
 * backward jumps that cannot terminate, and rules pointing at missing codes.
 */
export function validateLogic(questions: Question[]): LogicValidationIssue[] {
  const issues: LogicValidationIssue[] = [];
  const ordered = sortQuestions(questions);
  const byCode = new Map(ordered.map((q) => [q.question_code, q]));

  for (const question of ordered) {
    const ruleList: LogicRule[] = question.logic?.rules ?? [];
    for (const rule of ruleList) {
      const conditions = conditionsOf(rule);
      if (conditions.length === 0) {
        issues.push({
          questionCode: question.question_code,
          ruleId: rule.id,
          severity: 'error',
          message: '逻辑规则缺少条件，永远不会触发。',
        });
      }
      for (const condition of conditions) {
        if (!byCode.has(condition.questionCode)) {
          issues.push({
            questionCode: question.question_code,
            ruleId: rule.id,
            severity: 'error',
            message: `条件引用了不存在的题目 ${condition.questionCode}。`,
          });
        }
      }
      if (rule.action.type === 'jump_to') {
        const target = rule.action.target;
        if (target !== END_OF_QUESTIONNAIRE && !byCode.has(target)) {
          issues.push({
            questionCode: question.question_code,
            ruleId: rule.id,
            severity: 'error',
            message: `跳转目标 ${target} 不存在。`,
          });
        }
        if (target === question.question_code) {
          issues.push({
            questionCode: question.question_code,
            ruleId: rule.id,
            severity: 'error',
            message: '题目不能跳转到自身，会造成死循环。',
          });
        }
        const targetQuestion = byCode.get(target);
        if (targetQuestion && targetQuestion.sort_order < question.sort_order) {
          // A backward jump is a *warning* in general — controlled loops are a
          // legitimate design. But when the condition depends on the very
          // question being answered, the respondent is sent back the moment
          // they answer it, so the loop cannot terminate while that answer
          // stands. That is a defect, not a design choice.
          const selfDependent = conditions.some(
            (condition) => condition.questionCode === question.question_code,
          );
          issues.push({
            questionCode: question.question_code,
            ruleId: rule.id,
            severity: selfDependent ? 'error' : 'warning',
            message: selfDependent
              ? `跳转目标 ${target} 位于本题之前，且跳转条件依赖本题自身的作答，` +
                '会造成无法退出的循环作答。'
              : `跳转目标 ${target} 位于本题之前，请确认不会造成循环作答。`,
          });
        }
      }
    }
  }

  // Detect unreachable questions under the "no answers" baseline flow.
  const baseline = walkFlowPath(ordered, {});
  const reachable = new Set(baseline.path);
  for (const question of ordered) {
    if (question.question_type === 'page_break') continue;
    if (!reachable.has(question.question_code)) {
      issues.push({
        questionCode: question.question_code,
        ruleId: null,
        severity: 'warning',
        message: '在默认作答路径下该题不会被展示，请检查显示/跳转条件。',
      });
    }
  }

  // A cyclic flow means a respondent could be asked the same question twice.
  if (baseline.cycle) {
    issues.push({
      questionCode: baseline.path[baseline.path.length - 1] ?? ordered[0]?.question_code ?? '',
      ruleId: null,
      severity: 'error',
      message: '作答流程存在循环跳转，受访者可能被重复提问，请检查跳转目标。',
    });
  }

  return issues;
}

/** Human readable summary of a rule, e.g. `IF Q39 = 1 THEN jump_to Q41`. */
export function describeRule(rule: LogicRule, labels?: Record<string, string>): string {
  const conditions = conditionsOf(rule);
  const operatorText: Record<LogicOperator, string> = {
    eq: '=',
    neq: '≠',
    in: '∈',
    not_in: '∉',
    gt: '>',
    gte: '≥',
    lt: '<',
    lte: '≤',
    contains_any: '多选包含任一',
    contains_all: '多选同时包含',
    answered: '已作答',
    not_answered: '未作答',
  };

  const renderValue = (value: LogicCondition['value']): string => {
    if (value === null || value === undefined) return '';
    if (Array.isArray(value)) return value.map((v) => labels?.[String(v)] ?? String(v)).join('、');
    return labels?.[String(value)] ?? String(value);
  };

  const conditionText = conditions
    .map((c) => {
      if (c.operator === 'answered' || c.operator === 'not_answered') {
        return `${c.questionCode} ${operatorText[c.operator]}`;
      }
      return `${c.questionCode} ${operatorText[c.operator]} ${renderValue(c.value)}`;
    })
    .join(rule.match === 'any' ? ' 或 ' : ' 且 ');

  const actionText =
    rule.action.type === 'jump_to'
      ? `跳转至 ${rule.action.target}`
      : rule.action.type === 'show'
        ? '显示本题'
        : rule.action.type === 'hide'
          ? '隐藏本题'
          : '本题必答';

  return `IF ${conditionText || '(无条件)'} THEN ${actionText}`;
}

/** Normalise a stored logic blob into a well-formed QuestionLogic. */
export function normalizeLogic(input: unknown): QuestionLogic {
  if (!input || typeof input !== 'object') return { rules: [] };
  const candidate = input as Partial<QuestionLogic>;
  const rules = Array.isArray(candidate.rules) ? candidate.rules : [];
  return {
    rules: rules.filter((r): r is LogicRule => Boolean(r && typeof r === 'object' && 'action' in r)),
  };
}
