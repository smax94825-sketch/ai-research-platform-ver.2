/**
 * Competition Mode / entrepreneurship insight (PHASE 9).
 *
 * This is the only page in the console that speaks in business language, so it is
 * also the page with the most ways to mislead. Three rules shape it:
 *
 *  - **The nine blocks are rendered in the order the API reports.** A block the
 *    engine refused is shown with its Chinese `reason` as 「本区块无法给出结论」
 *    — a deliberate refusal, not a failure, and never an empty box.
 *  - **Inference is labelled as inference.** The market-opportunity block carries
 *    a prominent statement that its figures are inferences from *this sample* and
 *    are not a market-size estimate; `market_size_estimate` is rendered as an
 *    explicit refusal with no amount at all (0 would be a claim that was never
 *    made).
 *  - **Nothing is filled in for the reader.** The structured payloads are rendered
 *    by one generic renderer driven by the field names the API sends, with the
 *    raw key shown when there is no Chinese label — a field the console does not
 *    understand is displayed as itself rather than given an invented meaning.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Badge, Button, Card, CardHeader, LoadingBlock, StatCard } from '../../components/ui';
import { formatDateTime, formatNumber } from '../../lib/format';
import {
  api,
  ApiClientError,
  type CompetitionHistoryItem,
  type CompetitionReportPayload,
  type InsightBlock,
} from '../../lib/api';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from '../analysis/shared';

/**
 * How many of the leading caveats the server marks as mandatory.
 *
 * Mirrors `REQUIRED_CAVEATS` in `insight.service.ts`, which the report places
 * first. Declared here only so the page can mark them; the text itself is always
 * the API's.
 */
const REQUIRED_CAVEAT_COUNT = 4;

/** Chinese labels for the structured field names the insight blocks use. */
const FIELD_LABELS: Record<string, string> = {
  sample_size: '样本构成',
  respondents_total: '收集作答数',
  completed: '已完成',
  analysable: '进入分析',
  excluded: '研究者排除',
  in_progress: '作答中',
  abandoned: '中途退出',
  channels: '渠道',
  source: '来源',
  total: '份数',
  percent_of_sample: '占样本比例（%）',
  demographics: '人口学分布',
  variable: '变量',
  label: '名称',
  data_type: '测量层次',
  n: '有效 n',
  mean: '均值',
  mean_note: '均值说明',
  categories: '类别分布',
  value: '取值',
  count: '人数',
  percent: '占比（%）',
  primary_segment: '主要人群',
  category: '类别',
  sampling_limitation: '抽样限制',
  quality_context: '数据质量背景',
  available: '是否可用',
  note: '说明',
  scored_respondents: '已评分样本数',
  mean_score: '平均质量分',
  flagged_samples: '被标记样本数',
  metric: '口径',
  ranking: '排序',
  rank: '排序',
  severity: '严重度',
  direction: '方向',
  fed_overall: '家庭教育困难总体',
  information_environment: '信息环境',
  overall: '总体',
  items: '条目',
  knowledge: '知识',
  subjective: '自评',
  objective: '客观',
  indicative_gap_percentage_points: '自评与客观之差（百分点）',
  excluded_from_ranking: '未纳入排序',
  reason: '原因',
  chain_stage: '链条环节',
  id: '编号',
  measured: '是否测量',
  readings: '读数',
  distribution: '分布',
  notes: '提示',
  unmeasured: '未测量的供给方',
  chain_note: '链条说明',
  demand: '需求',
  provision: '供给',
  awareness_access: '知晓与获取',
  use_evaluation: '使用与评价',
  gaps: '缺口',
  formula: '计算式',
  largest_item_contrast: '最大反差',
  demand_mean: '需求均值',
  provision_mean: '供给均值',
  gap: '缺口',
  caveat: '解读限制',
  scale_midpoint: '量表中点',
  above_scale_midpoint: '高于量表中点',
  breadth_only: '仅广度测量',
  qualitative_material: '质性材料',
  providers: '供给方',
  ai_assistant: 'AI 助手',
  of: '总数',
  adoption_link: '与采用意愿的关系',
  pairs: '相关对',
  left: '变量 1',
  right: '变量 2',
  r: 'r',
  p_value: 'p',
  method: '方法',
  regression: '回归',
  term: '项',
  model: '模型',
  b: 'B',
  hypothesis: '假设',
  code: '编号',
  statement: '命题',
  verdict: '判定',
  conclusion: '结论',
  prerequisite_statement: '前提说明',
  intention: '使用意愿',
  mean_reference: '均值（仅作参考）',
  scale_note: '量表说明',
  perceived_value: '感知价值',
  risk: '风险认知',
  modelling: '建模',
  auto_selected_model: '自动选择的模型',
  ordinal_available: '有序模型可用',
  ols_available: '线性模型可用',
  drivers: '驱动因素',
  significant: '是否显著',
  risk_link: '与风险认知的关系',
  willingness: '付费意愿',
  amount_band: '金额区间',
  demand_link: '与需求的关系',
  purchase_behaviour_caveat: '购买行为限制',
  inference_label: '推断性质说明',
  sample_scope: '推断的样本范围',
  not_confirmed: '未获支持或证据不足',
  statistic: '统计量',
  effect: '效应量',
  effect_size: '效应量',
  demand_ranking: '需求排序',
  segment_findings: '分群差异',
  dependent: '因变量',
  factor: '分组变量',
  recommended: '建议口径',
  market_size_estimate: '市场规模估计',
  amount: '金额',
  currency: '币种',
  what_would_be_needed: '还需要什么',
  bounded_conclusion: '有界结论',
};

function fieldLabel(key: string): string {
  return FIELD_LABELS[key] ?? key;
}

/**
 * Chinese readings for the enumerated values the insight engine emits.
 *
 * Only closed vocabularies are translated; a free-text field (a `statistic` or a
 * `note`) is always printed verbatim, and an unknown value falls through as
 * itself rather than being given a guessed meaning.
 */
const VALUE_LABELS: Record<string, string> = {
  supported: '数据支持',
  not_supported: '方向与假设相反',
  inconclusive: '证据不足',
  untestable: '无法检验',
  direct: '直接（均值即严重度）',
  reversed: '反向（已换算）',
  parametric: '参数检验',
  nonparametric: '非参数检验',
  ordinal_logit: '有序 Logistic 回归',
  ols: '线性回归（OLS）',
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

/** A value a table cell can print without nesting. */
function isFlatLeaf(value: unknown): boolean {
  if (value === null || value === undefined) return true;
  if (Array.isArray(value)) return value.every((item) => item === null || typeof item !== 'object');
  return typeof value !== 'object';
}

/** Print a scalar exactly as the API sent it; `null` is never shown as 0. */
function scalarText(value: unknown): string {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'boolean') return value ? '是' : '否';
  if (typeof value === 'number') return String(value);
  if (Array.isArray(value)) return value.length === 0 ? '（空）' : value.map(scalarText).join('、');
  if (typeof value === 'string') return VALUE_LABELS[value] ?? value;
  return String(value);
}

/** Print a value as raw JSON, for text that quotes the field itself. */
function rawJsonText(value: unknown): string {
  if (value === undefined) return 'undefined';
  return JSON.stringify(value) ?? String(value);
}

/* ------------------------------------------------------------------ */
/* Generic structured-data rendering                                  */
/* ------------------------------------------------------------------ */

function MarketSizeRefusal({ value }: { value: Record<string, unknown> }): ReactNode {
  const reason =
    typeof value['reason'] === 'string' && value['reason'].trim() !== ''
      ? value['reason']
      : '数据集里没有价格、成本、付费转化与市场容量，平台不给出任何货币规模。';

  return (
    <div className="rounded-md border-2 border-amber-300 bg-amber-50 px-3.5 py-3">
      <p className="text-sm font-semibold text-amber-900">市场规模估计：本平台拒绝给出金额</p>
      <p className="mt-1 text-xs leading-relaxed text-amber-900">{reason}</p>
      <p className="mt-1 text-xs leading-relaxed text-amber-900">
        {`服务端该字段为 available=${rawJsonText(value['available'])}、amount=${rawJsonText(value['amount'])}、currency=${rawJsonText(value['currency'])}，`}
        因此界面不显示任何金额——<strong>不是 0</strong>：0 是一个金额，而这里没有金额。
      </p>
    </div>
  );
}

function ObjectTable({ rows }: { rows: Record<string, unknown>[] }): ReactNode {
  const columns: string[] = [];
  for (const row of rows) {
    for (const key of Object.keys(row)) {
      if (!columns.includes(key)) columns.push(key);
    }
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[560px] text-xs">
        <thead className="bg-ink-50 text-[11px] uppercase tracking-wide text-ink-500">
          <tr>
            {columns.map((column) => (
              <th key={column} className="px-2 py-1.5 text-left">
                {fieldLabel(column)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-100">
          {rows.map((row, rowIndex) => (
            <tr key={`r-${rowIndex}`}>
              {columns.map((column) => (
                <td key={`${rowIndex}-${column}`} className="px-2 py-1.5 align-top text-ink-800">
                  {scalarText(row[column])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ValueView({ value, depth }: { value: unknown; depth: number }): ReactNode {
  if (value === null || value === undefined) {
    return <p className="text-xs text-ink-500">—（结果包未报告该字段）</p>;
  }

  if (Array.isArray(value)) {
    if (value.length === 0) {
      return <p className="text-xs text-ink-500">（空：本次没有任何条目）</p>;
    }
    const records = value.filter((item) => asRecord(item) !== null).map((item) => asRecord(item)!);
    if (records.length === value.length && records.every((record) => Object.values(record).every(isFlatLeaf))) {
      return <ObjectTable rows={records} />;
    }
    if (depth >= 2) {
      return (
        <pre className="max-h-72 overflow-auto rounded bg-ink-50 p-2 font-mono text-[11px] text-ink-700">
          {JSON.stringify(value, null, 2)}
        </pre>
      );
    }
    return (
      <ul className="space-y-2">
        {value.map((item, index) => {
          const record = asRecord(item);
          return (
            <li key={`item-${index}`} className="rounded border border-ink-200 px-2.5 py-2">
              <p className="mb-1 font-mono text-[11px] text-ink-400">{`条目 ${index + 1}`}</p>
              {record ? (
                <ObjectFields record={record} depth={depth + 1} />
              ) : (
                <p className="text-xs text-ink-800">{scalarText(item)}</p>
              )}
            </li>
          );
        })}
      </ul>
    );
  }

  const record = asRecord(value);
  if (record) {
    if (depth >= 2) {
      return (
        <pre className="max-h-72 overflow-auto rounded bg-ink-50 p-2 font-mono text-[11px] text-ink-700">
          {JSON.stringify(value, null, 2)}
        </pre>
      );
    }
    return <ObjectFields record={record} depth={depth + 1} />;
  }

  const text = scalarText(value);
  // Long prose is rendered as a paragraph; a short value stays inline so tables
  // and definition lists keep their compact shape.
  if (typeof value === 'string' && text.length > 60) {
    return <p className="text-xs leading-relaxed text-ink-700">{text}</p>;
  }
  return <span className="text-xs text-ink-800">{text}</span>;
}

function ObjectFields({ record, depth }: { record: Record<string, unknown>; depth: number }): ReactNode {
  return (
    <dl className="space-y-2">
      {Object.entries(record).map(([key, value]) => (
        <div key={key}>
          <dt className="text-[11px] font-semibold uppercase tracking-wide text-ink-500">
            {fieldLabel(key)}
          </dt>
          <dd className="mt-0.5">
            {key === 'market_size_estimate' && asRecord(value) ? (
              <MarketSizeRefusal value={asRecord(value)!} />
            ) : (
              <ValueView value={value} depth={depth} />
            )}
          </dd>
        </div>
      ))}
    </dl>
  );
}

function BlockStructuredData({ block }: { block: InsightBlock }): ReactNode {
  const data = block.data;
  if (data === null || data === undefined) {
    return (
      <p className="text-xs text-ink-500">
        该区块没有结构化数据：所需变量或结果在统计结果包中缺失，因此没有可展示的数值（不是全 0）。
      </p>
    );
  }
  if (Array.isArray(data)) return <ValueView value={data} depth={0} />;
  const record = asRecord(data);
  if (record) return <ObjectFields record={record} depth={0} />;
  return <p className="text-xs text-ink-800">{scalarText(data)}</p>;
}

/* ------------------------------------------------------------------ */
/* One block                                                          */
/* ------------------------------------------------------------------ */

function BlockCard({ block }: { block: InsightBlock }): ReactNode {
  const marketOpportunity = block.key === 'market_opportunity';
  const record = asRecord(block.data);
  const inferenceLabel =
    marketOpportunity && record && typeof record['inference_label'] === 'string'
      ? String(record['inference_label'])
      : null;
  const sampleScope = marketOpportunity && record ? asRecord(record['sample_scope']) : null;

  return (
    <Card>
      <CardHeader
        title={
          <span className="flex flex-wrap items-baseline gap-2">
            <span className="tabular-nums text-ink-500">{`${block.order}.`}</span>
            {block.title}
            <span className="font-mono text-[11px] font-normal text-ink-400">{block.key}</span>
          </span>
        }
        description={`输入依赖：${block.inputs
          .map((input) => `${input.name}${input.available ? '✓' : '✗'}`)
          .join('、')}`}
        actions={
          <Badge tone={block.available ? 'success' : 'warning'}>
            {block.available ? '已给出结论' : '本区块无法给出结论'}
          </Badge>
        }
      />

      {!block.available ? (
        <Alert tone="warning" title="本区块无法给出结论">
          <p>{`原因：${block.reason ?? '结果包中缺少该区块所需的数据。'}`}</p>
          <p className="mt-1">
            这是平台的有意拒绝：宁可不给结论，也不以 0、行业均值或外部数据填补。
            下方列出该区块缺少的输入，补齐测量并重新运行分析后即可生成。
          </p>
        </Alert>
      ) : (
        <>
          {marketOpportunity && (
            <div className="mb-3 rounded-md border-2 border-amber-300 bg-amber-50 px-3.5 py-3">
              <p className="text-sm font-semibold text-amber-900">
                以下数字全部是「本样本内部」的统计推断，不是市场规模估算
              </p>
              <p className="mt-1 text-xs leading-relaxed text-amber-900">
                {inferenceLabel ??
                  '以下内容是基于本样本统计结果的推断，属于机会假设，不是市场规模估算，也不是对总体市场的描述。'}
              </p>
              {sampleScope && typeof sampleScope['note'] === 'string' && (
                <p className="mt-1 text-xs leading-relaxed text-amber-900">{String(sampleScope['note'])}</p>
              )}
              <p className="mt-1 text-xs leading-relaxed text-amber-900">
                请勿把本区块的任何比例、系数或均值乘以外部人口数：这不是市场规模，也不能作为收入预测的依据。
              </p>
            </div>
          )}

          <p className="text-sm leading-relaxed text-ink-800">{block.narrative}</p>

          <div className="mt-4">
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-ink-500">
              结构化数据（字段名与数值均来自服务端）
            </p>
            <BlockStructuredData block={block} />
          </div>
        </>
      )}

      <div className="mt-4">
        <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-ink-500">输入依赖</p>
        <ul className="space-y-1">
          {block.inputs.map((input) => (
            <li key={input.name} className="flex flex-wrap items-baseline gap-2 text-xs">
              <span className="font-mono text-[11px] text-ink-700">{input.name}</span>
              <Badge tone={input.available ? 'success' : 'warning'}>
                {input.available ? '已测量' : '缺失'}
              </Badge>
              <span className="text-ink-500">{input.role === 'primary' ? '主要输入' : '辅助输入'}</span>
              {input.note && <span className="text-ink-600">{input.note}</span>}
            </li>
          ))}
        </ul>
      </div>

      {block.evidence.length > 0 && (
        <details className="mt-3 rounded-md border border-ink-200 px-3.5 py-2.5">
          <summary className="cursor-pointer text-xs font-medium text-ink-700">
            {`证据留痕（${block.evidence.length} 条，逐条给出结果包中的位置）`}
          </summary>
          <ul className="mt-2 space-y-1">
            {block.evidence.map((item, index) => (
              <li key={`${item.path}-${index}`} className="flex flex-wrap items-baseline gap-2 text-xs">
                <code className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[11px] text-ink-700">
                  {item.path}
                </code>
                <span className="text-ink-400">=</span>
                <span className="break-all font-mono text-[11px] text-ink-900">{scalarText(item.value)}</span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </Card>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                               */
/* ------------------------------------------------------------------ */

function historyRows(items: CompetitionHistoryItem[]): ReactNode {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[880px] text-sm">
        <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
          <tr>
            <th className="px-3 py-2 text-right">运行序号</th>
            <th className="px-3 py-2 text-left">生成时间</th>
            <th className="px-3 py-2 text-left">洞察引擎版本</th>
            <th className="px-3 py-2 text-left">分析引擎版本</th>
            <th className="px-3 py-2 text-right">样本 n</th>
            <th className="px-3 py-2 text-right">可用区块</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-ink-100">
          {items.map((item) => (
            <tr key={item.id}>
              <td className="px-3 py-2 text-right tabular-nums text-ink-800">{`第 ${item.run_seq} 次`}</td>
              <td className="px-3 py-2 text-ink-800">{formatDateTime(item.created_at)}</td>
              <td className="px-3 py-2 font-mono text-xs text-ink-700">{item.engine_version}</td>
              <td className="px-3 py-2 font-mono text-xs text-ink-700">
                {`${item.analysis_engine_version ?? '—'}（${formatDateTime(item.analysis_generated_at)}）`}
              </td>
              <td className="px-3 py-2 text-right tabular-nums text-ink-800">{scalarText(item.sample_n)}</td>
              <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                {`${item.blocks_available}/${item.blocks_total}`}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function CompetitionPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [report, setReport] = useState<CompetitionReportPayload | null>(null);
  const [notGeneratedReason, setNotGeneratedReason] = useState<string | null>(null);
  const [history, setHistory] = useState<CompetitionHistoryItem[]>([]);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [runError, setRunError] = useState<string | null>(null);

  const loadHistory = useCallback(async (id: string) => {
    try {
      const response = await api.competition.history(id);
      setHistory(response.items);
      setHistoryError(null);
    } catch (err) {
      setHistory([]);
      setHistoryError(err instanceof ApiClientError ? err.message : '无法加载创业洞察历史。');
    }
  }, []);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      const response = await api.competition.report(projectId);
      if (response && response.available === false) {
        setReport(null);
        setNotGeneratedReason(response.reason);
      } else if (response) {
        setReport(response);
        setNotGeneratedReason(null);
      }
    } catch (err) {
      setReport(null);
      setError(err instanceof ApiClientError ? err.message : '无法加载创业洞察报告。');
    } finally {
      setLoading(false);
    }
    await loadHistory(projectId);
  }, [projectId, loadHistory]);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleRun(): Promise<void> {
    if (!projectId) return;
    setRunning(true);
    setRunError(null);
    try {
      const response = await api.competition.run(projectId);
      setReport(response);
      setNotGeneratedReason(null);
      await loadHistory(projectId);
    } catch (err) {
      setRunError(err instanceof ApiClientError ? err.message : '生成创业洞察失败。');
    } finally {
      setRunning(false);
    }
  }

  const blocks = report ? report.blocks.slice().sort((left, right) => left.order - right.order) : [];
  const availableBlocks = blocks.filter((block) => block.available).length;

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Insights / Competition Mode"
          subtitle="创业洞察：九个区块全部来自统计结果包，只做本样本范围内的推断，不给出市场规模。"
          state={state}
          actions={
            <Button variant="primary" loading={running} onClick={() => void handleRun()}>
              生成创业洞察
            </Button>
          }
        />

        {error && <ErrorNotice message={error} />}

        {loading && !report && !notGeneratedReason ? (
          <LoadingBlock label="正在读取创业洞察报告…" />
        ) : null}

        {runError && <ErrorNotice message={runError} />}

        {notGeneratedReason && !report && (
          <Alert tone="warning" title="尚未生成创业洞察报告">
            <p>{notGeneratedReason}</p>
            <p className="mt-1">
              创业洞察不会独立计算任何数字：它只把已保存的结果包翻译成产品与市场语言，
              因此必须先生成结果包。若结果包已经存在，请点击右上角「生成创业洞察」。
            </p>
            <p className="mt-3">
              <Link to={`/analysis?project=${projectId}`}>
                <Button variant="primary">前往统计分析并运行全部分析</Button>
              </Link>
            </p>
          </Alert>
        )}

        {report && (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard
                label="可用区块"
                value={`${availableBlocks}/${blocks.length}`}
                tone={availableBlocks === blocks.length ? 'success' : 'warning'}
                hint="不可用区块会说明原因，不以 0 填充"
              />
              <StatCard
                label="分析样本 n"
                value={formatNumber(report.sample.analysable)}
                hint="所有推断仅覆盖本次分析样本"
              />
              <StatCard label="本次运行序号" value={`第 ${report.run_seq} 次`} hint="重复运行会追加记录，不覆盖" />
              <StatCard
                label="生成时间"
                value={formatDateTime(report.generated_at)}
                hint={`洞察引擎 ${report.engine_version}`}
              />
            </div>

            <Card>
              <CardHeader
                title="报告来源"
                description="统计数字全部来自下列结果包，本页不重新计算、不改变精度。"
              />
              <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">研究项目</dt>
                  <dd className="mt-1 text-sm text-ink-800">{report.source.project_title}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">问卷</dt>
                  <dd className="mt-1 text-sm text-ink-800">{report.source.questionnaire?.title ?? '（未登记问卷）'}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">分析引擎版本</dt>
                  <dd className="mt-1 font-mono text-sm text-ink-800">
                    {`${report.source.analysis_engine_version}（结果包生成于 ${formatDateTime(report.source.analysis_generated_at)}）`}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">引擎一致性</dt>
                  <dd className="mt-1 text-sm text-ink-800">
                    {report.source.bundle_engine_matches
                      ? '结果包引擎版本与当前引擎一致'
                      : '结果包由不同版本的分析引擎生成，引用前请重新运行分析'}
                  </dd>
                </div>
              </dl>
            </Card>

            {report.staleness.stale ? (
              <Alert tone="danger" title="结果包已经过期：样本在分析之后发生了变化">
                <p>{report.staleness.note}</p>
                <p className="mt-1">
                  {`结果包记录的样本为 ${formatNumber(report.staleness.bundle_sample_n)} 份，当前可分析样本为 ${formatNumber(report.staleness.current_sample_n)} 份。`}
                  本报告的每一个数字都取自结果包，因此它描述的是结果包生成时点的样本；在重新运行分析之前，
                  不要据此报告作对外判断。
                </p>
              </Alert>
            ) : (
              <Alert tone="info" title="样本一致性">
                {`结果包与当前可分析样本一致（n = ${formatNumber(report.staleness.bundle_sample_n)}）：${report.staleness.note}`}
              </Alert>
            )}

            {report.caveats.length > 0 && (
              <MethodNote title="必须与报告同时引用的限制（前四条为平台强制声明）">
                <ol className="list-decimal space-y-1 pl-5">
                  {report.caveats.map((caveat, index) => (
                    <li key={`${index}-${caveat.slice(0, 24)}`}>
                      {index < REQUIRED_CAVEAT_COUNT ? <strong>{`【必读】${caveat}`}</strong> : caveat}
                    </li>
                  ))}
                </ol>
              </MethodNote>
            )}

            {report.notes.length > 0 && (
              <MethodNote title="生成说明（服务端原文）">
                <ul className="list-disc space-y-1 pl-5">
                  {report.notes.map((note, index) => (
                    <li key={`${index}-${note.slice(0, 24)}`}>{note}</li>
                  ))}
                </ul>
              </MethodNote>
            )}

            {blocks.map((block) => (
              <BlockCard key={block.key} block={block} />
            ))}
          </>
        )}

        <Card>
          <CardHeader
            title="创业洞察运行历史"
            description="每次运行都会追加一条记录（run_seq 递增），以便比较样本增长前后的结论差异。"
          />
          {historyError && <ErrorNotice message={historyError} />}
          {!historyError && history.length === 0 ? (
            <p className="text-sm text-ink-500">该项目还没有运行过创业洞察。</p>
          ) : (
            !historyError && historyRows(history)
          )}
        </Card>
      </div>
    </AnalysisProjectGate>
  );
}
