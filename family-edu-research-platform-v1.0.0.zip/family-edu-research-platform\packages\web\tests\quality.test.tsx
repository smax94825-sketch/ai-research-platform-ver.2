/**
 * Data quality UI tests (PHASE 4).
 *
 * The quality page makes claims about respondents, so the tests check the
 * guardrails as much as the rendering: the heuristic disclaimer, the
 * "nothing was deleted" statement, and the rule explanations that stop a
 * researcher from treating a flag as a verdict.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { click, flush, queryAll, render, text } from './render';

const { QualityPage } = await import('../src/pages/QualityPage');

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育认知研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'collecting',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

const RULES = [
  {
    code: 'SUSPICIOUS_SPEED',
    label: '完成时间过短',
    description: '作答用时低于研究项目设定的最短时长，或平均每题用时低于 2 秒。',
    interpretation: '可能未认真阅读题目。但需谨慎：熟悉问卷内容的受访者也可能作答很快。',
    default_severity: 'critical',
    score_impact: 30,
  },
  {
    code: 'LONG_STRING',
    label: '连续同选项作答',
    description: '在连续 20 个及以上量表条目上选择完全相同的选项。',
    interpretation: '常见于机械作答。但需注意：真实的"一贯同意"也可能产生长串相同选项。',
    default_severity: 'warning',
    score_impact: 25,
  },
];

const REPORT = {
  project_id: 'p-1',
  engine_version: '1.0.0',
  thresholds_note:
    '质量评分为启发式指标，用于提示需要人工复核的样本，不等同于对受访者的评价，也不构成剔除依据。',
  scored_respondents: 12,
  unscored_respondents: 2,
  mean_score: 84.5,
  median_score: 90,
  bands: [
    { label: '90—100 未发现可疑模式', min: 90, max: 100, count: 8 },
    { label: '70—89 存在轻微提示', min: 70, max: 89, count: 2 },
    { label: '40—69 需要人工复核', min: 40, max: 69, count: 1 },
    { label: '0—39 强烈建议复核', min: 0, max: 39, count: 1 },
  ],
  rule_frequency: [
    { rule_code: 'SUSPICIOUS_SPEED', label: '完成时间过短', count: 2, severity: 'critical' },
    { rule_code: 'LONG_STRING', label: '连续同选项作答', count: 1, severity: 'warning' },
  ],
  flagged_samples: [
    {
      respondent_id: 'resp-1',
      anonymous_id: 'A0003',
      score: 45,
      severity: 'critical',
      review_status: 'unreviewed',
      rule_codes: ['SUSPICIOUS_SPEED', 'LONG_STRING'],
    },
    {
      respondent_id: 'resp-2',
      anonymous_id: 'A0007',
      score: 75,
      severity: 'warning',
      review_status: 'unreviewed',
      rule_codes: ['LONG_STRING'],
    },
  ],
  excluded_samples: [
    { anonymous_id: 'A0009', note: '重复提交，已核对', reviewed_at: '2026-01-02T10:00:00.000Z' },
  ],
  inactive_rules: [],
};

function stubQualityApi(overrides: { report?: unknown; recompute?: unknown } = {}) {
  return stubFetch((call: FetchCall) => {
    if (call.url.endsWith('/api/projects?limit=200') || call.url.includes('/api/projects?')) {
      return jsonResponse({ data: PROJECTS });
    }
    if (call.url.includes('/quality/rules')) return jsonResponse({ data: RULES });
    if (call.url.includes('/quality/recompute')) {
      return jsonResponse({
        data:
          overrides.recompute ?? {
            project_id: 'p-1',
            engine_version: '1.0.0',
            respondents_scored: 12,
            flags_written: 3,
            clean_respondents: 10,
            flagged_respondents: 2,
            rule_counts: { SUSPICIOUS_SPEED: 2, LONG_STRING: 1 },
            computed_at: '2026-01-03T00:00:00.000Z',
          },
      });
    }
    if (call.url.includes('/quality')) {
      return jsonResponse({ data: overrides.report ?? REPORT });
    }
    return jsonResponse({ data: null });
  });
}

beforeEach(async () => {
  clearContainer();
  window.localStorage.clear();
});

after(() => {
  closeDom();
});

/* ================================================================== */
/* Guardrails                                                         */
/* ================================================================== */

describe('质量页的诚信提示', () => {
  test('明确指出评分不会改动任何数据、也不构成剔除依据', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /启发式指标/, '必须说明评分性质');
      assert.match(content, /不等同于对受访者的评价/, '必须说明评分不是对人的评价');
      assert.match(content, /不构成剔除依据/, '必须说明评分不能直接用于剔除');
      assert.match(content, /不会自动删除或修改任何样本/, '必须声明平台不会删除样本');
      assert.match(content, /是否排除由研究者判断/, '必须说明决定权在研究者');
    } finally {
      stub.restore();
    }
  });

  test('说明跨样本规则会随新样本回溯更新', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();
      assert.match(text(), /回溯更新/, '应说明重复提交检测的时序特性');
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Report rendering                                                   */
/* ================================================================== */

describe('质量报告渲染', () => {
  test('展示评分分布、平均分与中位数', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /已评分样本/);
      assert.match(content, /12/);
      assert.match(content, /84\.5/);
      assert.match(content, /90—100 未发现可疑模式/);
      assert.match(content, /0—39 强烈建议复核/);
      assert.match(content, /引擎版本 1\.0\.0/);
    } finally {
      stub.restore();
    }
  });

  test('展示规则命中情况，并给出检测说明与解读', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /完成时间过短/);
      assert.match(content, /每条扣 30 分/);
      assert.match(content, /平均每题用时低于 2 秒/, '应展示规则定义');
      assert.match(content, /解读：/, '应展示规则解读');
      assert.match(content, /也可能作答很快/, '解读须提示可能的误判');
    } finally {
      stub.restore();
    }
  });

  test('列出待复核样本及其命中规则', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /待复核样本（2）/);
      assert.match(content, /A0003/);
      assert.match(content, /A0007/);
      assert.match(content, /45/, '应显示评分');
    } finally {
      stub.restore();
    }
  });

  test('列出已被排除的样本与排除原因', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /已被研究者排除的样本（1）/);
      assert.match(content, /A0009/);
      assert.match(content, /重复提交，已核对/);
    } finally {
      stub.restore();
    }
  });

  test('无法运行的规则被如实列出，而不是表现为"通过"', async () => {
    const stub = stubQualityApi({
      report: {
        ...REPORT,
        inactive_rules: [
          { rule_code: 'SUBJECTIVE_OBJECTIVE_DISCREPANCY', reason: '该问卷未同时包含知识测试题与主观知识自评题。' },
        ],
      },
    });
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /以下规则对该问卷不适用/);
      assert.match(content, /SUBJECTIVE_OBJECTIVE_DISCREPANCY/);
      assert.match(content, /未同时包含知识测试题/);
    } finally {
      stub.restore();
    }
  });

  test('无任何命中时说明这可能只是样本量不足', async () => {
    const stub = stubQualityApi({
      report: {
        ...REPORT,
        rule_frequency: [],
        flagged_samples: [],
        excluded_samples: [],
      },
    });
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /尚未命中任何规则/);
      assert.match(content, /样本不足/, '应提示不要把"无命中"过度解读');
      assert.match(content, /当前没有需要复核的样本/);
    } finally {
      stub.restore();
    }
  });

  test('未评分样本被单独统计，不会被当作 0 分', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();
      assert.match(text(), /未评分样本/);
      assert.match(text(), /尚无作答，无法判断/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Recompute                                                          */
/* ================================================================== */

describe('重新运行质量检测', () => {
  test('点击后调用接口并报告运行结果与"未改动数据"', async () => {
    const stub = stubQualityApi();
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const button = queryAll('button').find((element) =>
        (element.textContent ?? '').includes('重新运行质量检测'),
      );
      assert.ok(button, '应有重新运行按钮');
      await click(button!);
      await flush();
      await flush();

      const recomputeCall = stub.calls.find((call) => call.url.includes('/quality/recompute'));
      assert.ok(recomputeCall, '应调用重算接口');
      assert.equal(recomputeCall!.method, 'POST');

      const content = text();
      assert.match(content, /质量检测已完成/);
      assert.match(content, /12 份样本/);
      assert.match(content, /本操作不会删除或修改任何样本/);
    } finally {
      stub.restore();
    }
  });

  test('接口失败时展示错误而不是静默失败', async () => {
    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
      if (call.url.includes('/quality/rules')) return jsonResponse({ data: RULES });
      if (call.url.includes('/quality/recompute')) {
        return jsonResponse(
          { error: { code: 'INTERNAL_ERROR', message: '服务器内部错误，请稍后重试。', details: null } },
          500,
        );
      }
      return jsonResponse({ data: REPORT });
    });

    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const button = queryAll('button').find((element) =>
        (element.textContent ?? '').includes('重新运行质量检测'),
      );
      await click(button!);
      await flush();
      await flush();

      assert.match(text(), /服务器内部错误/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Empty project list                                                 */
/* ================================================================== */

describe('无研究项目', () => {
  test('给出创建项目的引导而不是空白页', async () => {
    const stub = stubFetch(() =>
      jsonResponse({ data: { items: [], total: 0, limit: 200, offset: 0 } }),
    );
    try {
      await render(createElement(MemoryRouter, null, createElement(QualityPage)));
      await flush();

      const content = text();
      assert.match(content, /还没有研究项目/);
      assert.match(content, /新建研究项目/);
    } finally {
      stub.restore();
    }
  });
});
