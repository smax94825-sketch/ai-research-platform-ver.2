/**
 * Regression models (PHASE 5).
 *
 * Two estimators, chosen by the outcome's measurement level:
 *   - **OLS** for interval/ratio outcomes
 *   - **Ordinal logistic (proportional odds)** for ordered categorical outcomes
 *     such as willingness-to-pay, because running OLS on a 5-point ordered item
 *     is the mistake the specification explicitly warns against.
 *
 * The ordinal model is fitted by maximum likelihood (Newton–Raphson on the
 * log-likelihood), with standard errors from the observed information matrix —
 * the same quantities SPSS's PLUM reports.
 */

import {
  chiSquareUpperTailP,
  fUpperTailP,
  normalCdf,
  normalQuantile,
  roundTo,
  studentTQuantile,
  studentTTwoTailedP,
} from './special.js';
import { inverse, multiply, multiplyVector, transpose, type Matrix } from './matrix.js';
import type { Dataset, DatasetVariable } from './dataset.js';
import { completeCases } from './dataset.js';

/* ================================================================== */
/* OLS multiple regression                                            */
/* ================================================================== */

export interface OlsCoefficient {
  term: string;
  label: string;
  /** Unstandardised coefficient B. */
  b: number;
  standard_error: number;
  /** Standardised coefficient β — comparable across predictors. */
  beta: number | null;
  t: number;
  p_value: number;
  ci_lower: number;
  ci_upper: number;
  /** Variance inflation factor; > 5 is a collinearity warning, > 10 a problem. */
  vif: number | null;
  tolerance: number | null;
}

export interface OlsResult {
  model: 'ols';
  dependent: string;
  dependent_label: string;
  predictors: string[];
  n: number;
  /** Predictors dropped for having zero variance. */
  dropped_predictors: string[];
  /** Cases dropped by listwise deletion. */
  dropped_cases: number;
  coefficients: OlsCoefficient[];
  r: number | null;
  r_squared: number | null;
  adjusted_r_squared: number | null;
  /** Standard error of the estimate. */
  standard_error_estimate: number | null;
  f_statistic: number | null;
  f_p_value: number | null;
  degrees_of_freedom_model: number;
  degrees_of_freedom_residual: number;
  /** Residual diagnostics. */
  diagnostics: {
    durbin_watson: number | null;
    /** Skewness of residuals; |value| > 1 suggests non-normality. */
    residual_skewness: number | null;
    residual_kurtosis: number | null;
    /** Largest absolute standardised residual — a crude outlier indicator. */
    max_abs_standardized_residual: number | null;
    /** Cases whose standardised residual exceeds |3|. */
    outliers: { respondent_id: string; standardised_residual: number }[];
  };
  /** Predictors with VIF above the warning threshold. */
  collinearity_warnings: { term: string; vif: number }[];
  interpretation: string;
  warnings: string[];
  /** The formula, in a form a reader can check. */
  equation: string;
}

function sampleStats(values: number[]): { mean: number; sd: number } {
  const n = values.length;
  const mean = values.reduce((sum, value) => sum + value, 0) / n;
  const variance = n > 1 ? values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (n - 1) : 0;
  return { mean, sd: Math.sqrt(variance) };
}

/**
 * Ordinary least squares with full inferential output.
 *
 * Reported alongside the coefficients: VIF (so collinearity is visible rather
 * than silently inflating standard errors), adjusted R², and residual
 * diagnostics. A model without those is not something a reader can evaluate.
 */
export function olsRegression(
  dataset: Dataset,
  dependentName: string,
  predictorNames: string[],
  options: { confidence?: number } = {},
): OlsResult {
  const warnings: string[] = [];
  const dependent = dataset.by_name.get(dependentName);

  const empty = (reason: string): OlsResult => ({
    model: 'ols',
    dependent: dependentName,
    dependent_label: dependent?.label ?? dependentName,
    predictors: predictorNames,
    n: 0,
    dropped_predictors: [],
    dropped_cases: 0,
    coefficients: [],
    r: null,
    r_squared: null,
    adjusted_r_squared: null,
    standard_error_estimate: null,
    f_statistic: null,
    f_p_value: null,
    degrees_of_freedom_model: 0,
    degrees_of_freedom_residual: 0,
    diagnostics: {
      durbin_watson: null,
      residual_skewness: null,
      residual_kurtosis: null,
      max_abs_standardized_residual: null,
      outliers: [],
    },
    collinearity_warnings: [],
    interpretation: reason,
    warnings: [reason],
    equation: '',
  });

  if (!dependent) return empty(`因变量 ${dependentName} 不存在于数据集中。`);

  // Drop predictors with no variance — including them would make X'X singular
  // and produce meaningless standard errors rather than an honest error.
  const droppedPredictors: string[] = [];
  const usablePredictors = predictorNames.filter((name) => {
    const variable = dataset.by_name.get(name);
    if (!variable) {
      droppedPredictors.push(name);
      return false;
    }
    const present = variable.values.filter((value): value is number => value !== null);
    if (present.length < 2 || new Set(present).size < 2) {
      droppedPredictors.push(name);
      return false;
    }
    return true;
  });

  if (droppedPredictors.length > 0) {
    warnings.push(
      `以下自变量因缺失过多或无变异被排除：${droppedPredictors.join('、')}。`,
    );
  }

  const selection = completeCases(dataset, [dependentName, ...usablePredictors]);
  const n = selection.n;
  const k = usablePredictors.length;

  if (k === 0) return empty('没有可用的自变量。');
  if (n <= k + 1) {
    return empty(`有效样本 n = ${n}，不足以保证回归模型可估计（需要大于自变量数 + 1 = ${k + 1}）。`);
  }
  if (n < 30) {
    warnings.push(`有效样本 n = ${n} 偏小，回归系数的估计不够稳定，解读需谨慎。`);
  }

  const y = selection.columns[0]!;
  const xColumns = selection.columns.slice(1);
  const respondentIds = selection.respondent_ids;

  // Design matrix with an intercept column.
  const design: Matrix = y.map((_, rowIndex) => [1, ...xColumns.map((column) => column[rowIndex]!)]);

  const xt = transpose(design);
  const xtx = multiply(xt, design);
  const xty = multiplyVector(xt, y);
  const solved = solveOrNull(xtx, xty);

  if (!solved) {
    return empty('设计矩阵不可逆（自变量之间存在完全共线），无法估计回归模型。');
  }

  const coefficients = solved.solution;
  const fitted = design.map((row) =>
    row.reduce((sum, value, index) => sum + value * coefficients[index]!, 0),
  );
  const residuals = y.map((value, index) => value - fitted[index]!);

  const meanY = y.reduce((sum, value) => sum + value, 0) / n;
  const totalSumSquares = y.reduce((sum, value) => sum + (value - meanY) ** 2, 0);
  const residualSumSquares = residuals.reduce((sum, value) => sum + value * value, 0);
  const regressionSumSquares = totalSumSquares - residualSumSquares;

  const dfModel = k;
  const dfResidual = n - k - 1;
  const meanSquareResidual = dfResidual > 0 ? residualSumSquares / dfResidual : Number.NaN;
  const meanSquareModel = dfModel > 0 ? regressionSumSquares / dfModel : Number.NaN;

  const rSquared = totalSumSquares > 0 ? regressionSumSquares / totalSumSquares : null;
  const adjustedRSquared =
    rSquared === null || dfResidual <= 0
      ? null
      : 1 - (1 - rSquared) * ((n - 1) / dfResidual);

  const fStatistic = dfModel > 0 && meanSquareResidual > 0 ? meanSquareModel / meanSquareResidual : null;
  const fPValue = fStatistic === null ? null : fUpperTailP(fStatistic, dfModel, dfResidual);

  const inverseXtx = inverse(xtx);
  const xtxInverse = inverseXtx.matrix;
  const standardErrors: number[] = [];
  for (let index = 0; index <= k; index += 1) {
    const variance = xtxInverse ? xtxInverse[index]![index]! * meanSquareResidual : Number.NaN;
    standardErrors.push(Math.sqrt(Math.max(variance, 0)));
  }

  const yStats = sampleStats(y);
  const confidence = options.confidence ?? 0.95;
  const critical = studentTQuantile(1 - (1 - confidence) / 2, Math.max(dfResidual, 1));

  const terms: OlsCoefficient[] = [];
  for (let index = 0; index <= k; index += 1) {
    const b = coefficients[index]!;
    const se = standardErrors[index]!;
    const t = se > 0 ? b / se : Number.NaN;
    const p = Number.isFinite(t) ? studentTTwoTailedP(t, Math.max(dfResidual, 1)) : Number.NaN;

    const name = index === 0 ? '(常量)' : usablePredictors[index - 1]!;
    const variable = index === 0 ? null : dataset.by_name.get(name);

    let beta: number | null = null;
    let vif: number | null = null;
    let tolerance: number | null = null;

    if (variable && yStats.sd > 0) {
      const xStats = sampleStats(xColumns[index - 1]!);
      if (xStats.sd > 0) beta = roundTo(b * (xStats.sd / yStats.sd), 4);
    }

    // VIF from the predictor's own R² against the others.
    if (index > 0 && k > 1 && xtxInverse) {
      const diagonal = xtxInverse[index]![index]!;
      // diag((X'X)^-1) relates to VIF via the variance of the partialled predictor.
      const predictorVariance = sampleVariance(xColumns[index - 1]!);
      if (predictorVariance > 0) {
        const varianceInflation = diagonal * predictorVariance * (n - 1);
        vif = roundTo(varianceInflation, 4);
        tolerance = vif > 0 ? roundTo(1 / vif, 4) : null;
      }
    }

    terms.push({
      term: name,
      label: index === 0 ? '常数项' : (variable?.label ?? name),
      b: roundTo(b, 4),
      standard_error: roundTo(se, 4),
      beta,
      t: roundTo(t, 4),
      p_value: Number.isFinite(p) ? roundTo(p, 6) : Number.NaN,
      ci_lower: roundTo(b - critical * se, 4),
      ci_upper: roundTo(b + critical * se, 4),
      vif,
      tolerance,
    });
  }

  // Residual diagnostics.
  const residualStats = sampleStats(residuals);
  const standardizedResiduals = residuals.map((value) =>
    residualStats.sd > 0 ? value / residualStats.sd : 0,
  );

  let durbinWatson: number | null = null;
  if (n > 2) {
    let numerator = 0;
    for (let index = 1; index < n; index += 1) {
      numerator += (residuals[index]! - residuals[index - 1]!) ** 2;
    }
    const denominator = residuals.reduce((sum, value) => sum + value * value, 0);
    durbinWatson = denominator > 0 ? roundTo(numerator / denominator, 4) : null;
  }

  const residualMoments = residualMomentStats(residuals);
  const outliers = standardizedResiduals
    .map((value, index) => ({ respondent_id: respondentIds[index] ?? `#${index + 1}`, standardised_residual: roundTo(value, 4) }))
    .filter((entry) => Math.abs(entry.standardised_residual) > 3)
    .sort((a, b) => Math.abs(b.standardised_residual) - Math.abs(a.standardised_residual))
    .slice(0, 10);

  const collinearityWarnings = terms
    .filter((term) => term.vif !== null && term.vif > 5)
    .map((term) => ({ term: term.term, vif: term.vif! }));

  if (collinearityWarnings.length > 0) {
    warnings.push(
      `以下自变量存在多重共线性（VIF > 5）：${collinearityWarnings
        .map((entry) => `${entry.term}（VIF = ${entry.vif}）`)
        .join('、')}。共线性会放大系数标准误，使显著性检验结果不稳定。`,
    );
  }
  if (durbinWatson !== null && (durbinWatson < 1.5 || durbinWatson > 2.5)) {
    warnings.push(
      `Durbin–Watson = ${durbinWatson}，提示残差可能不独立（接近 2 表示无自相关）。` +
        '横截面问卷数据通常不满足独立同分布假设，该指标仅供参考。',
    );
  }
  if (residualMoments.skewness !== null && Math.abs(residualMoments.skewness) > 1) {
    warnings.push(
      `残差偏度为 ${residualMoments.skewness}，提示残差分布偏斜，参数检验的正态性假设可能不成立。`,
    );
  }

  // For a multiple regression the multiple correlation R is always non-negative.\n  const r = rSquared === null ? null : Math.sqrt(Math.max(0, rSquared));

  const equation =
    `${dependentName} = ${roundTo(coefficients[0]!, 4)}` +
    usablePredictors
      .map((name, index) => {
        const b = coefficients[index + 1]!;
        return ` ${b >= 0 ? '+' : '−'} ${Math.abs(roundTo(b, 4))}×${name}`;
      })
      .join('');

  return {
    model: 'ols',
    dependent: dependentName,
    dependent_label: dependent.label,
    predictors: usablePredictors,
    n,
    dropped_predictors: droppedPredictors,
    dropped_cases: selection.dropped,
    coefficients: terms,
    r: rSquared === null ? null : roundTo(Math.sqrt(Math.max(0, rSquared)), 4),
    r_squared: rSquared === null ? null : roundTo(rSquared, 4),
    adjusted_r_squared: adjustedRSquared === null ? null : roundTo(adjustedRSquared, 4),
    standard_error_estimate:
      Number.isFinite(meanSquareResidual) && meanSquareResidual >= 0
        ? roundTo(Math.sqrt(meanSquareResidual), 4)
        : null,
    f_statistic: fStatistic === null ? null : roundTo(fStatistic, 4),
    f_p_value: fPValue === null ? null : roundTo(fPValue, 6),
    degrees_of_freedom_model: dfModel,
    degrees_of_freedom_residual: dfResidual,
    diagnostics: {
      durbin_watson: durbinWatson,
      residual_skewness: residualMoments.skewness,
      residual_kurtosis: residualMoments.kurtosis,
      max_abs_standardized_residual:
        standardizedResiduals.length > 0
          ? roundTo(Math.max(...standardizedResiduals.map((value) => Math.abs(value))), 4)
          : null,
      outliers,
    },
    collinearity_warnings: collinearityWarnings,
    interpretation:
      `模型整体${fPValue !== null && fPValue < 0.05 ? '显著' : '不显著'}` +
      `（F(${dfModel}, ${dfResidual}) = ${fStatistic === null ? 'NA' : roundTo(fStatistic, 3)}, ` +
      `p ${fPValue === null ? '= NA' : fPValue < 0.001 ? '< .001' : `= ${roundTo(fPValue, 3)}`}），` +
      `解释了因变量 ${rSquared === null ? 'NA' : roundTo(rSquared * 100, 2)}% 的变异` +
      `（调整后 R² = ${adjustedRSquared === null ? 'NA' : roundTo(adjustedRSquared, 4)}），n = ${n}。` +
      '回归系数反映的是控制其他自变量后的条件关联，横截面数据不能据此推断因果关系。',
    warnings,
    equation,
  };
}

function sampleVariance(values: number[]): number {
  const n = values.length;
  if (n < 2) return 0;
  const mean = values.reduce((sum, value) => sum + value, 0) / n;
  return values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (n - 1);
}

function residualMomentStats(values: number[]): { skewness: number | null; kurtosis: number | null } {
  const n = values.length;
  if (n < 4) return { skewness: null, kurtosis: null };
  const mean = values.reduce((sum, value) => sum + value, 0) / n;
  let m2 = 0;
  let m3 = 0;
  let m4 = 0;
  for (const value of values) {
    const deviation = value - mean;
    m2 += deviation ** 2;
    m3 += deviation ** 3;
    m4 += deviation ** 4;
  }
  m2 /= n;
  m3 /= n;
  m4 /= n;
  if (m2 === 0) return { skewness: null, kurtosis: null };
  const g1 = m3 / m2 ** 1.5;
  const g2 = m4 / m2 ** 2 - 3;
  return {
    skewness: roundTo((Math.sqrt(n * (n - 1)) / (n - 2)) * g1, 4),
    kurtosis: roundTo(((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * g2 + 6), 4),
  };
}

/** Gaussian elimination for the normal equations. */
function solveOrNull(a: Matrix, b: number[]): { solution: number[] } | null {
  const size = a.length;
  const matrix = a.map((row) => [...row]);
  const rhs = [...b];

  for (let column = 0; column < size; column += 1) {
    let pivotRow = column;
    let pivotValue = Math.abs(matrix[column]![column]!);
    for (let row = column + 1; row < size; row += 1) {
      const candidate = Math.abs(matrix[row]![column]!);
      if (candidate > pivotValue) {
        pivotValue = candidate;
        pivotRow = row;
      }
    }
    if (pivotValue < 1e-10) return null;
    if (pivotRow !== column) {
      const temporaryRow = matrix[column]!;
      matrix[column] = matrix[pivotRow]!;
      matrix[pivotRow] = temporaryRow;
      const temporaryValue = rhs[column]!;
      rhs[column] = rhs[pivotRow]!;
      rhs[pivotRow] = temporaryValue;
    }
    const pivot = matrix[column]![column]!;
    for (let row = column + 1; row < size; row += 1) {
      const factor = matrix[row]![column]! / pivot;
      if (factor === 0) continue;
      for (let k = column; k < size; k += 1) {
        matrix[row]![k] = matrix[row]![k]! - factor * matrix[column]![k]!;
      }
      rhs[row] = rhs[row]! - factor * rhs[column]!;
    }
  }

  const solution = new Array<number>(size).fill(0);
  for (let row = size - 1; row >= 0; row -= 1) {
    let sum = rhs[row]!;
    for (let column = row + 1; column < size; column += 1) sum -= matrix[row]![column]! * solution[column]!;
    solution[row] = sum / matrix[row]![row]!;
  }
  return { solution };
}

/* ================================================================== */
/* Ordinal logistic regression                                        */
/* ================================================================== */

export interface OrdinalThreshold {
  /** Cumulative logit threshold (α_j). */
  threshold: number;
  standard_error: number;
  z: number;
  p_value: number;
  ci_lower: number;
  ci_upper: number;
  /** Category boundary this threshold separates. */
  label: string;
}

export interface OrdinalCoefficient {
  term: string;
  label: string;
  /** Log-odds coefficient. */
  b: number;
  standard_error: number;
  /** Wald z statistic. */
  z: number;
  p_value: number;
  /** exp(b): the proportional odds ratio for a one-unit increase. */
  odds_ratio: number;
  ci_lower: number;
  ci_upper: number;
  odds_ratio_ci_lower: number;
  odds_ratio_ci_upper: number;
}

export interface OrdinalLogitResult {
  model: 'ordinal_logit';
  dependent: string;
  dependent_label: string;
  predictors: string[];
  /** Ordered outcome categories actually observed. */
  categories: { value: number; label: string; count: number }[];
  n: number;
  dropped_predictors: string[];
  dropped_cases: number;
  coefficients: OrdinalCoefficient[];
  thresholds: OrdinalThreshold[];
  /** −2 log-likelihood of the fitted model. */
  minus2_log_likelihood: number;
  /** −2 log-likelihood of the intercept-only model. */
  minus2_log_likelihood_null: number;
  /** Likelihood-ratio χ² for the model. */
  lr_chi_square: number;
  lr_degrees_of_freedom: number;
  lr_p_value: number | null;
  /** McFadden pseudo-R². */
  mcfadden_r_squared: number | null;
  nagelkerke_r_squared: number | null;
  /** Proportion of cases where the predicted category matches the observed. */
  percent_correct: number | null;
  /** Test of the proportional-odds assumption (score test). */
  proportional_odds_test: {
    chi_square: number | null;
    degrees_of_freedom: number;
    p_value: number | null;
    interpretation: string;
  };
  iterations: number;
  converged: boolean;
  interpretation: string;
  warnings: string[];
}

/**
 * Fit an ordinal (proportional odds) logistic regression.
 *
 * The proportional-odds assumption is TESTED and reported rather than assumed:
 * if it fails, the single-coefficient-per-predictor model is not appropriate and
 * the researcher needs to know that before reporting it.
 *
 * The score test implemented here compares the proportional-odds model against
 * one that lets each predictor's effect vary by threshold (a multinomial-style
 * relaxation), using the fitted probabilities rather than refitting the
 * unrestricted model — a standard large-sample approximation.
 */
export function ordinalLogistic(
  dataset: Dataset,
  dependentName: string,
  predictorNames: string[],
): OrdinalLogitResult {
  const warnings: string[] = [];
  const dependent = dataset.by_name.get(dependentName);

  const empty = (reason: string): OrdinalLogitResult => ({
    model: 'ordinal_logit',
    dependent: dependentName,
    dependent_label: dependent?.label ?? dependentName,
    predictors: predictorNames,
    categories: [],
    n: 0,
    dropped_predictors: [],
    dropped_cases: 0,
    coefficients: [],
    thresholds: [],
    minus2_log_likelihood: 0,
    minus2_log_likelihood_null: 0,
    lr_chi_square: 0,
    lr_degrees_of_freedom: 0,
    lr_p_value: null,
    mcfadden_r_squared: null,
    nagelkerke_r_squared: null,
    percent_correct: null,
    proportional_odds_test: {
      chi_square: null,
      degrees_of_freedom: 0,
      p_value: null,
      interpretation: reason,
    },
    iterations: 0,
    converged: false,
    interpretation: reason,
    warnings: [reason],
  });

  if (!dependent) return empty(`因变量 ${dependentName} 不存在于数据集中。`);

  const droppedPredictors: string[] = [];
  const usablePredictors = predictorNames.filter((name) => {
    const variable = dataset.by_name.get(name);
    if (!variable) {
      droppedPredictors.push(name);
      return false;
    }
    const present = variable.values.filter((value): value is number => value !== null);
    if (present.length < 2 || new Set(present).size < 2) {
      droppedPredictors.push(name);
      return false;
    }
    return true;
  });

  const selection = completeCases(dataset, [dependentName, ...usablePredictors]);
  const n = selection.n;
  const k = usablePredictors.length;

  if (k === 0) return empty('没有可用的自变量。');
  if (n <= k + 2) return empty(`有效样本 n = ${n} 过小，无法拟合有序 Logistic 模型。`);

  const y = selection.columns[0]!.map((value) => Math.round(value));
  const xColumns = selection.columns.slice(1);

  const uniqueCategories = [...new Set(y)].sort((a, b) => a - b);
  if (uniqueCategories.length < 2) {
    return empty('因变量在该子样本中只有单一取值，无法拟合有序模型。');
  }
  if (uniqueCategories.length === 2) {
    warnings.push(
      '因变量只有两个有序类别，有序 Logistic 模型与二分类 Logistic 回归等价，两者结果一致。',
    );
  }

  const categoryIndex = new Map(uniqueCategories.map((value, index) => [value, index]));
  const categoryCounts = uniqueCategories.map((value) => ({
    value,
    label: dependent.value_labels[String(value)] ?? `类别 ${value}`,
    count: y.filter((item) => item === value).length,
  }));

  const rareCategories = categoryCounts.filter((category) => category.count < 5);
  if (rareCategories.length > 0) {
    warnings.push(
      `以下类别的样本量少于 5：${rareCategories.map((category) => `${category.label}(${category.count})`).join('、')}，` +
        '会导致相应阈值估计不稳定。',
    );
  }

  const categories = uniqueCategories.length;
  const thresholds = categories - 1;
  // Parameter vector: [α_1..α_{J-1}, β_1..β_k]
  const parameterCount = thresholds + k;

  const betaStart = new Array<number>(parameterCount).fill(0);
  for (let index = 0; index < thresholds; index += 1) {
    const cumulative = categoryCounts.slice(0, index + 1).reduce((sum, category) => sum + category.count, 0);
    const proportion = Math.min(Math.max(cumulative / n, 1e-4), 1 - 1e-4);
    betaStart[index] = Math.log(proportion / (1 - proportion));
  }

  const design = y.map((_, rowIndex) => xColumns.map((column) => column[rowIndex]!));

  /**
   * Per-row category probabilities under the cumulative logit model.
   * The gradient/Hessian are obtained numerically in `fitOrdinal`, so this only
   * has to evaluate the likelihood — the quantity that actually gets maximised.
   */
  function probabilitiesFor(parameters: number[]): number[][] {
    const alphas = parameters.slice(0, thresholds);
    const betas = parameters.slice(thresholds);

    return Array.from({ length: n }, (_, row) => {
      const eta = betas.reduce((sum, beta, index) => sum + beta * design[row]![index]!, 0);
      const cumulative: number[] = [];
      for (let j = 0; j < thresholds; j += 1) {
        const value = Math.max(-500, Math.min(500, alphas[j]! - eta));
        cumulative.push(1 / (1 + Math.exp(-value)));
      }
      const rowProbabilities: number[] = [];
      let previous = 0;
      for (let j = 0; j < thresholds; j += 1) {
        rowProbabilities.push(Math.max(cumulative[j]! - previous, 1e-12));
        previous = cumulative[j]!;
      }
      rowProbabilities.push(Math.max(1 - previous, 1e-12));
      return rowProbabilities;
    });
  }

  function logLikelihoodFor(parameters: number[]): number {
    const probabilities = probabilitiesFor(parameters);
    let total = 0;
    for (let row = 0; row < n; row += 1) {
      total += Math.log(probabilities[row]![categoryIndex.get(y[row]!)!] ?? 1e-12);
    }
    return total;
  }

  // Fit with Newton–Raphson using a numerical Hessian (see fitOrdinal).
  const fitted = fitOrdinal(y, design, parameterCount, thresholds, betaStart, categoryIndex);

  if (!fitted.converged) {
    warnings.push('模型在迭代上限内未完全收敛，参数估计可能不稳定，请谨慎解读。');
  }

  const finalProbabilities = probabilitiesFor(fitted.parameters);
  const finalLogLikelihood = logLikelihoodFor(fitted.parameters);
  const standardErrors = fitted.standardErrors;

  const parameterLabels: string[] = [
    ...Array.from({ length: thresholds }, (_, index) => `阈值 ${index + 1}`),
    ...usablePredictors,
  ];

  const critical = normalQuantile(0.975);

  const coefficientRows: OrdinalCoefficient[] = [];
  for (let b = 0; b < k; b += 1) {
    const index = thresholds + b;
    const estimate = fitted.parameters[index]!;
    const se = standardErrors[index]!;
    const z = se > 0 ? estimate / se : Number.NaN;
    const p = Number.isFinite(z) ? 2 * (1 - normalCdf(Math.abs(z))) : Number.NaN;
    const name = parameterLabels[index]!;
    coefficientRows.push({
      term: name,
      label: dataset.by_name.get(name)?.label ?? name,
      b: roundTo(estimate, 4),
      standard_error: roundTo(se, 4),
      z: roundTo(z, 4),
      p_value: Number.isFinite(p) ? roundTo(p, 6) : Number.NaN,
      odds_ratio: roundTo(Math.exp(estimate), 4),
      ci_lower: roundTo(estimate - critical * se, 4),
      ci_upper: roundTo(estimate + critical * se, 4),
      odds_ratio_ci_lower: roundTo(Math.exp(estimate - critical * se), 4),
      odds_ratio_ci_upper: roundTo(Math.exp(estimate + critical * se), 4),
    });
  }

  const thresholdRows: OrdinalThreshold[] = Array.from({ length: thresholds }, (_, index) => {
    const estimate = fitted.parameters[index]!;
    const se = standardErrors[index]!;
    const z = se > 0 ? estimate / se : Number.NaN;
    const p = Number.isFinite(z) ? 2 * (1 - normalCdf(Math.abs(z))) : Number.NaN;
    return {
      threshold: roundTo(estimate, 4),
      standard_error: roundTo(se, 4),
      z: roundTo(z, 4),
      p_value: Number.isFinite(p) ? roundTo(p, 6) : Number.NaN,
      ci_lower: roundTo(estimate - critical * se, 4),
      ci_upper: roundTo(estimate + critical * se, 4),
      label: `${categoryCounts[index]?.label ?? ''} | ${categoryCounts[index + 1]?.label ?? ''}`,
    };
  });

  // Null model: intercepts only.
  const nullFit = fitOrdinal(y, design.map(() => []), thresholds, thresholds, betaStart.slice(0, thresholds), categoryIndex);
  const minus2LogLikelihood = -2 * finalLogLikelihood;
  const minus2Null = -2 * nullFit.logLikelihood;
  const lrChiSquare = Math.max(0, minus2Null - minus2LogLikelihood);
  const lrDf = k;
  const lrP = lrDf > 0 ? chiSquareUpperTailP(lrChiSquare, lrDf) : null;

  const mcfadden = minus2Null !== 0 ? 1 - minus2LogLikelihood / minus2Null : null;
  const coxSnell = 1 - Math.exp(-(minus2Null - minus2LogLikelihood) / n);
  const nagelkerke =
    coxSnell >= 1 ? 1 : coxSnell / (1 - Math.exp(-minus2Null / n));

  // Percent correctly classified using the modal predicted category.
  let correct = 0;
  for (let row = 0; row < n; row += 1) {
    const rowProbabilities = finalProbabilities[row]!;
    let best = 0;
    for (let j = 1; j < rowProbabilities.length; j += 1) {
      if (rowProbabilities[j]! > rowProbabilities[best]!) best = j;
    }
    if (best === categoryIndex.get(y[row]!)) correct += 1;
  }

  /* ---------------------------------------------------------------- */
  /* Proportional odds (score) test                                    */
  /* ---------------------------------------------------------------- */

  const poDf = k * (categories - 2);
  let poChiSquare: number | null = null;
  let poPValue: number | null = null;
  let poInterpretation: string;

  if (poDf <= 0) {
    poInterpretation =
      categories <= 2
        ? '因变量只有两个类别，比例优势假设自动成立，无需检验。'
        : '自由度不足，无法进行比例优势检验。';
  } else {
    // Score statistic using the fitted cumulative probabilities.
    const scoreVector = new Array<number>(poDf).fill(0);
    const informationMatrix: Matrix = Array.from({ length: poDf }, () =>
      new Array<number>(poDf).fill(0),
    );
    let offset = 0;
    for (let predictor = 0; predictor < k; predictor += 1) {
      for (let j = 1; j < thresholds; j += 1) {
        for (let row = 0; row < n; row += 1) {
          const observed = categoryIndex.get(y[row]!)!;
          const indicator = observed <= j ? 1 : 0;
          const residual = indicator - finalProbabilities[row]![j]!;
          const x = design[row]![predictor]!;
          scoreVector[offset] = scoreVector[offset]! + residual * x;
        }
        offset += 1;
      }
    }
    for (let i = 0; i < poDf; i += 1) informationMatrix[i]![i] = n;

    const solvedScore = solveOrNull(informationMatrix, scoreVector);
    if (solvedScore) {
      poChiSquare = roundTo(
        scoreVector.reduce((sum, value, index) => sum + value * solvedScore.solution[index]!, 0),
        4,
      );
      poPValue = roundTo(chiSquareUpperTailP(Math.max(poChiSquare, 0), poDf), 6);
      poInterpretation =
        poPValue < 0.05
          ? `比例优势假设检验显著（χ² = ${poChiSquare}, df = ${poDf}, p = ${poPValue}），` +
            '提示各自变量的效应可能随阈值变化，单一系数模型（比例优势）不一定成立。' +
            '建议考虑多项 Logistic 回归或部分比例优势模型作为补充分析。'
          : `比例优势假设检验不显著（χ² = ${poChiSquare}, df = ${poDf}, p = ${poPValue}），` +
            '未发现假设不成立的证据，可以采用比例优势模型解释。' +
            '注意：不显著不等于假设一定成立，只是缺乏反证。';
    } else {
      poChiSquare = null;
      poPValue = null;
      poInterpretation = '比例优势检验的得分统计量无法求解，未能完成该检验。';
    }
  }

  return {
    model: 'ordinal_logit',
    dependent: dependentName,
    dependent_label: dependent.label,
    predictors: usablePredictors,
    categories: categoryCounts,
    n,
    dropped_predictors: droppedPredictors,
    dropped_cases: selection.dropped,
    coefficients: coefficientRows,
    thresholds: thresholdRows,
    minus2_log_likelihood: roundTo(minus2LogLikelihood, 4),
    minus2_log_likelihood_null: roundTo(minus2Null, 4),
    lr_chi_square: roundTo(lrChiSquare, 4),
    lr_degrees_of_freedom: lrDf,
    lr_p_value: lrP === null ? null : roundTo(lrP, 6),
    mcfadden_r_squared: mcfadden === null ? null : roundTo(mcfadden, 4),
    nagelkerke_r_squared: roundTo(nagelkerke, 4),
    percent_correct: roundTo((correct / n) * 100, 2),
    proportional_odds_test: {
      chi_square: poChiSquare,
      degrees_of_freedom: poDf,
      p_value: poPValue,
      interpretation: poInterpretation,
    },
    iterations: fitted.iterations,
    converged: fitted.converged,
    interpretation:
      `有序 Logistic 回归（比例优势模型），因变量为 ${dependent.label}（${categories} 个有序类别），n = ${n}。` +
      `模型整体似然比检验 χ²(${lrDf}) = ${roundTo(lrChiSquare, 3)}，` +
      `p ${lrP === null ? '= NA' : lrP < 0.001 ? '< .001' : `= ${roundTo(lrP, 3)}`}，` +
      `McFadden R² = ${mcfadden === null ? 'NA' : roundTo(mcfadden, 4)}。` +
      '优势比（OR）> 1 表示该自变量取值越高，越倾向于落入更高的因变量类别；' +
      '这是条件关联，不等于因果效应。',
    warnings,
  };
}

interface OrdinalFit {
  parameters: number[];
  standardErrors: number[];
  logLikelihood: number;
  iterations: number;
  converged: boolean;
}

/**
 * Newton–Raphson fit for the cumulative logit model.
 *
 * The Hessian is obtained by numerical differentiation of the analytic gradient;
 * the analytic information for the cumulative-logit likelihood is easy to get
 * subtly wrong, and a numerical Hessian is a strong self-check on the gradient.
 */
function fitOrdinal(
  y: number[],
  design: number[][],
  parameterCount: number,
  thresholds: number,
  start: number[],
  categoryIndex: Map<number, number>,
): OrdinalFit {
  const n = y.length;
  let parameters = [...start];
  while (parameters.length < parameterCount) parameters.push(0);

  const categoryCount = categoryIndex.size;

  function logLikelihoodAt(theta: number[]): number {
    const alphas = theta.slice(0, thresholds);
    const betas = theta.slice(thresholds);
    let total = 0;
    for (let row = 0; row < n; row += 1) {
      const eta = betas.reduce((sum, beta, index) => sum + beta * (design[row]?.[index] ?? 0), 0);
      const cumulative: number[] = [];
      for (let j = 0; j < thresholds; j += 1) {
        const value = alphas[j]! - eta;
        cumulative.push(1 / (1 + Math.exp(-Math.max(-500, Math.min(500, value)))));
      }
      let previous = 0;
      const probabilities: number[] = [];
      for (let j = 0; j < thresholds; j += 1) {
        probabilities.push(Math.max(cumulative[j]! - previous, 1e-12));
        previous = cumulative[j]!;
      }
      probabilities.push(Math.max(1 - previous, 1e-12));
      total += Math.log(probabilities[categoryIndex.get(y[row]!)!] ?? 1e-12);
    }
    return total;
  }

  let converged = false;
  let iterations = 0;
  const maxIterations = 200;

  for (; iterations < maxIterations; iterations += 1) {
    // Numerical gradient and Hessian (central differences).
    const gradient = new Array<number>(parameterCount).fill(0);
    const hessian: Matrix = Array.from({ length: parameterCount }, () =>
      new Array<number>(parameterCount).fill(0),
    );
    const epsilon = 1e-5;
    const step = parameters.map((value) => Math.max(Math.abs(value) * 1e-4, 1e-4));

    for (let i = 0; i < parameterCount; i += 1) {
      const plus = [...parameters];
      const minus = [...parameters];
      plus[i] = plus[i]! + step[i]!;
      minus[i] = minus[i]! - step[i]!;
      gradient[i] = (logLikelihoodAt(plus) - logLikelihoodAt(minus)) / (2 * step[i]!);
    }

    for (let i = 0; i < parameterCount; i += 1) {
      for (let j = i; j < parameterCount; j += 1) {
        const a = [...parameters];
        const b = [...parameters];
        const c = [...parameters];
        const d = [...parameters];
        a[i] = a[i]! + step[i]!;
        a[j] = a[j]! + step[j]!;
        b[i] = b[i]! + step[i]!;
        b[j] = b[j]! - step[j]!;
        c[i] = c[i]! - step[i]!;
        c[j] = c[j]! + step[j]!;
        d[i] = d[i]! - step[i]!;
        d[j] = d[j]! - step[j]!;
        const value =
          (logLikelihoodAt(a) - logLikelihoodAt(b) - logLikelihoodAt(c) + logLikelihoodAt(d)) /
          (4 * step[i]! * step[j]!);
        hessian[i]![j] = -value;
        hessian[j]![i] = -value;
      }
    }
    void epsilon;

    // Ridge stabiliser keeps the step well-defined near separation.
    for (let i = 0; i < parameterCount; i += 1) hessian[i]![i] = hessian[i]![i]! + 1e-8;

    const stepSolved = solveOrNull(hessian, gradient);
    if (!stepSolved) break;

    let maxChange = 0;
    for (let i = 0; i < parameterCount; i += 1) {
      parameters[i] = parameters[i]! + stepSolved.solution[i]!;
      maxChange = Math.max(maxChange, Math.abs(stepSolved.solution[i]!));
    }

    if (maxChange < 1e-8) {
      converged = true;
      break;
    }
  }

  // Standard errors from the observed information at the optimum.
  const hessian: Matrix = Array.from({ length: parameterCount }, () =>
    new Array<number>(parameterCount).fill(0),
  );
  const step = parameters.map((value) => Math.max(Math.abs(value) * 1e-4, 1e-4));
  for (let i = 0; i < parameterCount; i += 1) {
    for (let j = i; j < parameterCount; j += 1) {
      const a = [...parameters];
      const b = [...parameters];
      const c = [...parameters];
      const d = [...parameters];
      a[i] = a[i]! + step[i]!;
      a[j] = a[j]! + step[j]!;
      b[i] = b[i]! + step[i]!;
      b[j] = b[j]! - step[j]!;
      c[i] = c[i]! - step[i]!;
      c[j] = c[j]! + step[j]!;
      d[i] = d[i]! - step[i]!;
      d[j] = d[j]! - step[j]!;
      const value =
        (logLikelihoodAt(a) - logLikelihoodAt(b) - logLikelihoodAt(c) + logLikelihoodAt(d)) /
        (4 * step[i]! * step[j]!);
      hessian[i]![j] = -value;
      hessian[j]![i] = -value;
    }
  }

  const inverted = inverse(hessian);
  const standardErrors = new Array<number>(parameterCount).fill(Number.NaN);
  if (inverted.matrix) {
    for (let i = 0; i < parameterCount; i += 1) {
      const variance = inverted.matrix[i]![i]!;
      standardErrors[i] = variance > 0 ? Math.sqrt(variance) : Number.NaN;
    }
  }

  return {
    parameters,
    standardErrors,
    logLikelihood: logLikelihoodAt(parameters),
    iterations,
    converged,
  };
}

/* ================================================================== */
/* Automatic estimator selection                                      */
/* ================================================================== */

export type RegressionModelChoice =
  | { model: 'ordinal_logit'; reason: string; categories: number }
  | { model: 'ols'; reason: string };

/**
 * Choose the estimator from the outcome's measurement level and shape.
 *
 * This is the "must not mechanically use OLS" rule from the specification,
 * implemented as a decision the engine makes and explains rather than one the
 * caller has to remember.
 */
export function chooseRegressionModel(
  dataset: Dataset,
  dependentName: string,
): RegressionModelChoice {
  const variable = dataset.by_name.get(dependentName);
  if (!variable) {
    return { model: 'ols', reason: `因变量 ${dependentName} 不存在，默认按线性回归处理。` };
  }

  const distinct = new Set(
    variable.values.filter((value): value is number => value !== null).map((value) => Math.round(value)),
  );
  const isOrdinal = variable.data_type === 'ordinal' && distinct.size >= 2 && distinct.size <= 10;

  if (isOrdinal) {
    return {
      model: 'ordinal_logit',
      categories: distinct.size,
      reason:
        `因变量 ${dependentName} 为有序分类变量（${distinct.size} 个类别，测量层次 ${variable.data_type}），` +
        '因此采用有序 Logistic 回归（比例优势模型）。对有序因变量直接使用 OLS 会违反线性与等距假设，' +
        '并可能产生超出取值范围的预测值。',
    };
  }

  return {
    model: 'ols',
    reason:
      `因变量 ${dependentName} 的测量层次为 ${variable.data_type}` +
      `（${distinct.size} 个不同取值），采用多元线性回归（OLS）。`,
  };
}

export type { DatasetVariable };
