/**
 * jsdom environment for UI tests.
 *
 * The sandbox cannot launch a real browser (Chromium needs named-pipe IPC),
 * so the React components are rendered in-process against a genuine DOM
 * implementation. This exercises the actual component code — hooks, event
 * handlers, conditional rendering — rather than merely type-checking it.
 */

import { JSDOM } from 'jsdom';

// NOTE: this module must not import React or react-dom. It is loaded first
// (see setup.ts) precisely so the DOM exists before React performs its
// module-load-time feature detection.

export interface DomEnvironment {
  dom: JSDOM;
  container: HTMLElement;
}

let environment: DomEnvironment | null = null;

/**
 * Install a jsdom value as a global.
 *
 * Node 22+ defines some of these (notably `navigator`) as getter-only
 * properties, so plain assignment throws; `defineProperty` works uniformly.
 */
function defineGlobal(name: string, value: unknown): void {
  Object.defineProperty(globalThis, name, {
    value,
    writable: true,
    configurable: true,
    enumerable: true,
  });
}

export function setupDom(url = 'http://localhost/login'): DomEnvironment {
  if (environment) return environment;

  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    url,
    pretendToBeVisual: true,
  });

  defineGlobal('window', dom.window);
  defineGlobal('document', dom.window.document);
  defineGlobal('navigator', dom.window.navigator);
  defineGlobal('HTMLElement', dom.window.HTMLElement);
  defineGlobal('HTMLInputElement', dom.window.HTMLInputElement);
  defineGlobal('HTMLTextAreaElement', dom.window.HTMLTextAreaElement);
  defineGlobal('HTMLSelectElement', dom.window.HTMLSelectElement);
  defineGlobal('Node', dom.window.Node);
  defineGlobal('Event', dom.window.Event);
  defineGlobal('MouseEvent', dom.window.MouseEvent);
  defineGlobal('getComputedStyle', dom.window.getComputedStyle.bind(dom.window));
  // React 19 requires this flag to use `act`.
  defineGlobal('IS_REACT_ACT_ENVIRONMENT', true);

  const container = dom.window.document.getElementById('root');
  if (!container) throw new Error('#root container missing from the jsdom document');

  environment = { dom, container };
  return environment;
}

export function clearContainer(): void {
  if (environment) environment.container.innerHTML = '';
}

/**
 * Tear the jsdom window down.
 *
 * jsdom keeps timers and animation frames alive, which prevents Node's test
 * runner from exiting on its own; closing the window releases them.
 */
export function closeDom(): void {
  if (!environment) return;
  environment.dom.window.close();
  environment = null;
}

/** Seed the API base + token so the client does not hit the default origin. */
export function configureApi(baseUrl = 'http://127.0.0.1:4000'): void {
  window.localStorage.setItem('ferp.apiBase', baseUrl);
}

export function setToken(token: string | null): void {
  if (token) window.localStorage.setItem('ferp.token', token);
  else window.localStorage.removeItem('ferp.token');
}

/** Minimal Response-like object for stubbing global fetch. */
export function jsonResponse(body: unknown, status = 200): Response {
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: new Headers({ 'content-type': 'application/json' }),
    text: async () => JSON.stringify(body),
    arrayBuffer: async () => new TextEncoder().encode(JSON.stringify(body)).buffer,
  } as unknown as Response;
}

export interface FetchCall {
  url: string;
  method: string;
  headers: Record<string, string>;
  body: unknown;
}

/** Install a fetch stub that records calls and replies with a routing table. */
export function stubFetch(
  handler: (call: FetchCall) => Response | Promise<Response>,
): { calls: FetchCall[]; restore: () => void } {
  const calls: FetchCall[] = [];
  const original = globalThis.fetch;

  globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;
    const headers: Record<string, string> = {};
    if (init?.headers) {
      for (const [key, value] of Object.entries(init.headers as Record<string, string>)) {
        headers[key.toLowerCase()] = value;
      }
    }
    let body: unknown = null;
    if (typeof init?.body === 'string') {
      try {
        body = JSON.parse(init.body);
      } catch {
        body = init.body;
      }
    }
    const call: FetchCall = { url, method: init?.method ?? 'GET', headers, body };
    calls.push(call);
    return handler(call);
  }) as typeof fetch;

  return {
    calls,
    restore: () => {
      globalThis.fetch = original;
    },
  };
}
