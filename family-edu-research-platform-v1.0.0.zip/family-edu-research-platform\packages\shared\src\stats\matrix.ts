/**
 * Small dense linear algebra (PHASE 5).
 *
 * Sized for questionnaire work — tens of variables, hundreds of cases — where a
 * straightforward, numerically careful implementation is both fast enough and
 * far easier to audit than a general-purpose library.
 *
 * Key routines: Gaussian elimination with partial pivoting (solve/inverse/
 * determinant) and the cyclic Jacobi method for symmetric eigen decomposition
 * (used by EFA and by PCA-based extraction).
 */

export type Matrix = number[][];

/* ------------------------------------------------------------------ */
/* Construction and helpers                                           */
/* ------------------------------------------------------------------ */

export function zeros(rows: number, columns: number): Matrix {
  return Array.from({ length: rows }, () => new Array<number>(columns).fill(0));
}

export function identity(size: number): Matrix {
  const result = zeros(size, size);
  for (let index = 0; index < size; index += 1) result[index]![index] = 1;
  return result;
}

export function clone(matrix: Matrix): Matrix {
  return matrix.map((row) => [...row]);
}

export function dimensions(matrix: Matrix): { rows: number; columns: number } {
  return { rows: matrix.length, columns: matrix[0]?.length ?? 0 };
}

export function transpose(matrix: Matrix): Matrix {
  const { rows, columns } = dimensions(matrix);
  const result = zeros(columns, rows);
  for (let i = 0; i < rows; i += 1) {
    for (let j = 0; j < columns; j += 1) result[j]![i] = matrix[i]![j]!;
  }
  return result;
}

export function multiply(a: Matrix, b: Matrix): Matrix {
  const { rows: aRows, columns: aColumns } = dimensions(a);
  const { rows: bRows, columns: bColumns } = dimensions(b);
  if (aColumns !== bRows) {
    throw new Error(`矩阵维度不匹配：(${aRows}×${aColumns}) × (${bRows}×${bColumns})`);
  }
  const result = zeros(aRows, bColumns);
  for (let i = 0; i < aRows; i += 1) {
    for (let k = 0; k < aColumns; k += 1) {
      const factor = a[i]![k]!;
      if (factor === 0) continue;
      for (let j = 0; j < bColumns; j += 1) {
        result[i]![j] = result[i]![j]! + factor * b[k]![j]!;
      }
    }
  }
  return result;
}

export function multiplyVector(matrix: Matrix, vector: number[]): number[] {
  const { rows, columns } = dimensions(matrix);
  if (columns !== vector.length) {
    throw new Error(`矩阵与向量维度不匹配：(${rows}×${columns}) × (${vector.length})`);
  }
  const result = new Array<number>(rows).fill(0);
  for (let i = 0; i < rows; i += 1) {
    let sum = 0;
    for (let j = 0; j < columns; j += 1) sum += matrix[i]![j]! * vector[j]!;
    result[i] = sum;
  }
  return result;
}

/** Sum of squared differences from zero — used for convergence checks. */
export function sumOfSquares(matrix: Matrix): number {
  let total = 0;
  for (const row of matrix) for (const value of row) total += value * value;
  return total;
}

export function isSquare(matrix: Matrix): boolean {
  const { rows, columns } = dimensions(matrix);
  return rows === columns && rows > 0;
}

/* ------------------------------------------------------------------ */
/* Solving and inverting                                              */
/* ------------------------------------------------------------------ */

export interface SolveResult {
  solution: number[] | null;
  /** True when the matrix is numerically singular. */
  singular: boolean;
}

/**
 * Solve A·x = b by Gaussian elimination with partial pivoting.
 *
 * Partial pivoting is not optional here: correlation matrices are frequently
 * near-singular, and without it the inverse silently loses all significant
 * digits (or produces NaNs) rather than reporting the collinearity.
 */
export function solve(a: Matrix, b: number[], tolerance = 1e-12): SolveResult {
  if (!isSquare(a)) throw new Error('solve 需要方阵。');
  const size = a.length;
  if (b.length !== size) throw new Error('solve 需要与矩阵同维的右端向量。');

  const matrix = clone(a);
  const rhs = [...b];

  for (let column = 0; column < size; column += 1) {
    // Pivot on the largest magnitude in this column.
    let pivotRow = column;
    let pivotValue = Math.abs(matrix[column]![column]!);
    for (let row = column + 1; row < size; row += 1) {
      const candidate = Math.abs(matrix[row]![column]!);
      if (candidate > pivotValue) {
        pivotValue = candidate;
        pivotRow = row;
      }
    }

    if (pivotValue < tolerance) return { solution: null, singular: true };

    if (pivotRow !== column) {
      const swapped = matrix[column]!;
      matrix[column] = matrix[pivotRow]!;
      matrix[pivotRow] = swapped;
      const temporary = rhs[column]!;
      rhs[column] = rhs[pivotRow]!;
      rhs[pivotRow] = temporary;
    }

    const pivot = matrix[column]![column]!;
    for (let row = column + 1; row < size; row += 1) {
      const factor = matrix[row]![column]! / pivot;
      if (factor === 0) continue;
      matrix[row]![column] = 0;
      for (let k = column + 1; k < size; k += 1) {
        matrix[row]![k] = matrix[row]![k]! - factor * matrix[column]![k]!;
      }
      rhs[row] = rhs[row]! - factor * rhs[column]!;
    }
  }

  // Back substitution.
  const solution = new Array<number>(size).fill(0);
  for (let row = size - 1; row >= 0; row -= 1) {
    let sum = rhs[row]!;
    for (let column = row + 1; column < size; column += 1) {
      sum -= matrix[row]![column]! * solution[column]!;
    }
    solution[row] = sum / matrix[row]![row]!;
  }

  return { solution, singular: false };
}

export function inverse(a: Matrix, tolerance = 1e-12): { matrix: Matrix | null; singular: boolean } {
  if (!isSquare(a)) throw new Error('inverse 需要方阵。');
  const size = a.length;
  const matrix = clone(a);
  const result = identity(size);

  for (let column = 0; column < size; column += 1) {
    let pivotRow = column;
    let pivotValue = Math.abs(matrix[column]![column]!);
    for (let row = column + 1; row < size; row += 1) {
      const candidate = Math.abs(matrix[row]![column]!);
      if (candidate > pivotValue) {
        pivotValue = candidate;
        pivotRow = row;
      }
    }
    if (pivotValue < tolerance) return { matrix: null, singular: true };

    if (pivotRow !== column) {
      const swapped = matrix[column]!;
      matrix[column] = matrix[pivotRow]!;
      matrix[pivotRow] = swapped;
      const swappedResult = result[column]!;
      result[column] = result[pivotRow]!;
      result[pivotRow] = swappedResult;
    }

    const pivot = matrix[column]![column]!;
    for (let k = 0; k < size; k += 1) {
      matrix[column]![k] = matrix[column]![k]! / pivot;
      result[column]![k] = result[column]![k]! / pivot;
    }

    for (let row = 0; row < size; row += 1) {
      if (row === column) continue;
      const factor = matrix[row]![column]!;
      if (factor === 0) continue;
      for (let k = 0; k < size; k += 1) {
        matrix[row]![k] = matrix[row]![k]! - factor * matrix[column]![k]!;
        result[row]![k] = result[row]![k]! - factor * result[column]![k]!;
      }
    }
  }

  return { matrix: result, singular: false };
}

/* ------------------------------------------------------------------ */
/* Eigen decomposition (symmetric)                                    */
/* ------------------------------------------------------------------ */

export interface EigenDecomposition {
  /** Eigenvalues in descending order. */
  values: number[];
  /** Column k is the eigenvector for values[k]. */
  vectors: Matrix;
  iterations: number;
  /** True when the method failed to converge within the iteration budget. */
  converged: boolean;
}

/**
 * Cyclic Jacobi eigen decomposition for a real symmetric matrix.
 *
 * Chosen over the QR algorithm because it is short, unconditionally stable for
 * symmetric input, and needs no Hessenberg reduction — and because factor
 * analysis only ever decomposes symmetric matrices (correlation/covariance).
 */
export function jacobiEigen(
  input: Matrix,
  options: { maxIterations?: number; tolerance?: number } = {},
): EigenDecomposition {
  if (!isSquare(input)) throw new Error('jacobiEigen 需要对称方阵。');
  const size = input.length;
  const maxIterations = options.maxIterations ?? 100 * size * size;
  const tolerance = options.tolerance ?? 1e-12;

  const a = clone(input);
  const eigenvectors = identity(size);
  let iterations = 0;
  let converged = false;

  for (; iterations < maxIterations; iterations += 1) {
    // Largest off-diagonal magnitude decides whether to stop.
    let offDiagonal = 0;
    for (let i = 0; i < size; i += 1) {
      for (let j = i + 1; j < size; j += 1) offDiagonal += a[i]![j]! * a[i]![j]!;
    }
    if (Math.sqrt(2 * offDiagonal) < tolerance) {
      converged = true;
      break;
    }

    for (let p = 0; p < size - 1; p += 1) {
      for (let q = p + 1; q < size; q += 1) {
        const apq = a[p]![q]!;
        if (Math.abs(apq) < 1e-300) continue;

        const theta = (a[q]![q]! - a[p]![p]!) / (2 * apq);
        const t =
          Math.sign(theta || 1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
        const c = 1 / Math.sqrt(t * t + 1);
        const s = t * c;

        // Apply the rotation to A.
        for (let k = 0; k < size; k += 1) {
          const akp = a[k]![p]!;
          const akq = a[k]![q]!;
          a[k]![p] = c * akp - s * akq;
          a[k]![q] = s * akp + c * akq;
        }
        for (let k = 0; k < size; k += 1) {
          const apk = a[p]![k]!;
          const aqk = a[q]![k]!;
          a[p]![k] = c * apk - s * aqk;
          a[q]![k] = s * apk + c * aqk;
        }
        // Accumulate the rotation into the eigenvector matrix.
        for (let k = 0; k < size; k += 1) {
          const vkp = eigenvectors[k]![p]!;
          const vkq = eigenvectors[k]![q]!;
          eigenvectors[k]![p] = c * vkp - s * vkq;
          eigenvectors[k]![q] = s * vkp + c * vkq;
        }
      }
    }
  }

  const pairs = Array.from({ length: size }, (_, index) => ({
    value: a[index]![index]!,
    vector: eigenvectors.map((row) => row[index]!),
  }));
  pairs.sort((left, right) => right.value - left.value);

  return {
    values: pairs.map((pair) => pair.value),
    vectors: pairs.map((pair) => pair.vector),
    iterations,
    converged,
  };
}

/* ------------------------------------------------------------------ */
/* Correlation and covariance                                         */
/* ------------------------------------------------------------------ */

export function pearsonCorrelation(x: number[], y: number[]): number {
  const n = Math.min(x.length, y.length);
  if (n < 2) return Number.NaN;

  let meanX = 0;
  let meanY = 0;
  for (let index = 0; index < n; index += 1) {
    meanX += x[index]!;
    meanY += y[index]!;
  }
  meanX /= n;
  meanY /= n;

  let covariance = 0;
  let varianceX = 0;
  let varianceY = 0;
  for (let index = 0; index < n; index += 1) {
    const dx = x[index]! - meanX;
    const dy = y[index]! - meanY;
    covariance += dx * dy;
    varianceX += dx * dx;
    varianceY += dy * dy;
  }

  if (varianceX === 0 || varianceY === 0) return Number.NaN;
  return covariance / Math.sqrt(varianceX * varianceY);
}

/** Correlation matrix from a column-major list of variables. */
export function correlationMatrix(columns: number[][]): Matrix {
  const count = columns.length;
  const result = zeros(count, count);
  for (let i = 0; i < count; i += 1) {
    result[i]![i] = 1;
    for (let j = i + 1; j < count; j += 1) {
      const r = pearsonCorrelation(columns[i]!, columns[j]!);
      result[i]![j] = r;
      result[j]![i] = r;
    }
  }
  return result;
}

/** Convert a correlation matrix into a covariance matrix given standard deviations. */
export function correlationToCovariance(correlation: Matrix, standardDeviations: number[]): Matrix {
  const size = correlation.length;
  const result = zeros(size, size);
  for (let i = 0; i < size; i += 1) {
    for (let j = 0; j < size; j += 1) {
      result[i]![j] = correlation[i]![j]! * standardDeviations[i]! * standardDeviations[j]!;
    }
  }
  return result;
}
