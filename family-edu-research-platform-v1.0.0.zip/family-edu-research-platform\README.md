# 家庭教育科研智能研究平台

**AI-Powered Research Operating System** — 面向教育、社会科学与创业研究人员的一体化科研操作系统。

核心闭环：

```
研究设计 → 问卷构建 → 数据收集 → 数据质量检测 → 统计分析
        → AI 解释 → 研究建议 → 创业洞察 → 研究报告 → 数据导出
```

本仓库已完成 **PHASE 1—PHASE 9**（研究设计 → 问卷交互 → 数据收集 → 质量检测 → 统计分析 → AI 解释 → 研究报告 → 数据导出 → 创业洞察的完整闭环），并已通过真实运行验证。

---

## 一、环境约束与技术选型（必读）

开发前对当前环境做了实测，结果直接决定了技术栈：

| 期望技术 | 实测结果 | 实际采用 |
| --- | --- | --- |
| Python + FastAPI | **不可用**。PyPI 及清华/阿里/腾讯镜像均 TLS 连接失败；本机 Python 3.12/3.14 仅装有 pip，无 numpy/pandas/scipy | **Node.js 24 + TypeScript + Express** |
| PostgreSQL | **不可用**。未安装服务端，无 Docker | **SQLite（Node 内置 `node:sqlite`）** |
| Docker | **不可用**。未安装 | 本地脚本（build / serve / dev） |
| pandas · statsmodels · factor_analyzer | **不可用**（无 PyPI） | 已以纯 TypeScript 统计引擎实现（见 PHASE 5），统计量有单元测试逐一手工核对 |
| Vite | **不可用**。Vite 依赖 esbuild 的 JS API，而该 API 以管道 stdio 启动子进程，被沙箱拦截（`spawn EPERM`） | **esbuild CLI 打包**（CLI 直接调用可正常工作） |
| React + TypeScript + Tailwind | 可用 | 已采用（React 19 · TS 5.9 · Tailwind 3.4） |
| ECharts / Recharts | 可用但**刻意未采用** | **手写零依赖 SVG 图表组件**（10 类）。理由：图表所需信息量很小，引入数千 KB 的图表库会显著拖慢首屏，且库的默认行为容易隐藏数字（悬停才显示）；手写组件把每个数值都渲染成真实文本，可读、可断言、可被测试覆盖 |
| shadcn/ui | 可用但**刻意未采用** | 自建 Tailwind 组件（`components/ui.tsx`）。本沙箱的 npm 生命周期脚本被拦截，Radix 系组件需要额外构建步骤；自建组件的样式与可访问性由本项目测试覆盖 |
| Chromium 无头浏览器 | **不可用**。多进程 IPC 依赖命名管道，被沙箱拦截 | jsdom 真实挂载验证（非截图验证），详见第六节 |

> 说明：项目需求允许"如果环境不支持某个技术，请选择稳定的等价技术"，因此以上替换均属预期内的降级方案，而非偏离设计。
>
> SQL 全部写成可移植形式（TEXT/INTEGER/REAL，无引擎专有语法），仓储层与统计层不依赖 SQLite 特性，后续迁移到 PostgreSQL 无需重写调用点。

---

## 二、快速开始

```bash
cd family-edu-research-platform

# 1. 安装依赖（本沙箱需用工作区内的 npm 缓存）
npm install --ignore-scripts

# 2. 初始化数据库并写入演示账号
npm run db:reset
npm run db:seed          # 创建演示账号；密码在本次输出中打印一次

# 3. 构建
npm run build

# 4. 启动（两个终端）
npm run dev:server       # API  → http://127.0.0.1:4000
npm run dev:web          # 控制台 → http://127.0.0.1:5173
```

浏览器打开 <http://127.0.0.1:5173> 登录。

登录使用项目内置的演示账号：账号密码属于本地配置，不在本文档中明文给出。执行 `npm run db:seed` 时会在终端打印该账号与密码（密码仅打印一次，请自行保存）；如需固定密码，可在本地配置文件中通过 `SEED_DEMO_EMAIL` / `SEED_DEMO_PASSWORD` 预设。

受访者填写入口是公开链接 `http://127.0.0.1:5173/research/{share_token}`（发布问卷后自动生成，并附带二维码）。

> `--ignore-scripts` 是沙箱要求：npm 的生命周期脚本以管道 stdio 启动子进程，会被拦截。所依赖的包（express/cors/qrcode/react/tailwind）均无需编译步骤。

### 验证

```bash
npm run typecheck        # 三个包的 TypeScript 检查
npm test                 # 960 项自动化测试
npm run e2e              # 308 项端到端冒烟测试（需先启动 API）
npm run verify           # typecheck + test + build
```

---

## 三、已实现功能（PHASE 1—9）

### PHASE 1 — 项目基础、数据库、认证、研究项目、Dashboard

- **项目初始化**：npm workspaces 三个包（`shared` / `server` / `web`）
- **数据库**：12 张表、迁移运行器（事务内应用、幂等、可回滚）、级联删除
- **研究者注册 / 登录 / 登出**：scrypt 密码哈希（N=2¹⁵）、JWT（HS256，算法固定）、令牌版本号撤销
- **Research Dashboard**：样本量、有效/无效/未评分、有效率、完成率、平均完成时长、今日新增、配额进度与提醒、核心变量分布
- **Research Project CRUD**：列表（搜索/状态/分页）、详情、更新、删除（返回影响范围）、一键模板创建

### PHASE 2 — 问卷构建器、题型、逻辑、预览、发布、版本控制

- **Questionnaire Builder**：三栏界面（题目列表 / 实时预览 / Question Settings）
- **十种题型**：单选、多选、下拉、李克特、矩阵、排序、文本、多行文本、数字、知识测试、分页
- **题目管理**：新增、编辑、删除（报告悬空逻辑引用）、复制（变量名加 `_C` 后缀避免统计合并）、上下移动、整体重排
- **题目属性**：题干、题型、选项（含正确答案 / 互斥 / 敏感拒答标记）、必答、变量名（SPSS 兼容校验）、研究维度、计分方式、辅助说明
- **条件逻辑**：`IF <题目> <运算符> <值> THEN 跳转/显示/隐藏/必答`，13 种运算符，AND/OR 组合，可视化编辑，可读化描述，循环与悬空目标校验
- **Preview**：由**后端逻辑引擎**驱动真实作答流程（`第 X/Y 题`、进度条、上一题/下一题、跳转跳过）
- **Publish**：校验 → 锁定 → 生成分享令牌 → 分享链接 + 渠道追踪参数 + 服务端二维码（SVG/PNG）→ 不可变快照
- **版本控制**：发布即锁定；`建立新版本` 克隆全部题目并递增版本号（V4.0 → V4.1 / V5.0）；旧版本保留数据与快照
- **变量字典**：由问卷定义自动生成，含变量名、题号、题干、维度、数据类型、编码、缺失值、计分规则、分析方法；支持带 BOM 的 CSV 导出

### PHASE 3 — 受访者端填写、数据收集、来源追踪、样本管理

**两种受访者填写版式**（同一份问卷、同一条采集链路、同一个会话）：

| 版式 | 链接 | 说明 |
| --- | --- | --- |
| 逐题模式（默认） | `/research/{share_token}` | 一屏一题、大按钮、移动端优先；适合手机填写与长问卷 |
| 整页模式 | `/research/{share_token}/all` | **全部题目在一页滚动、底部统一提交**；类似纸质问卷，适合桌面端通读通答。带 `已答 X / Y 题` 进度（只统计当前可见题）、必答题拦截（列出题号并滚动定位到第一道未答题）、分组小标题与题号 |

两种版式共用同一套自动保存（500ms 防抖、切页/隐藏/提交前强制刷写）、知情同意门、条件显示逻辑（都由同一个共享逻辑引擎判定，隐藏题不计入必答校验与进度）、以及同一个会话令牌——因此受访者在两个链接之间切换会**续答同一个会话**，不会产生第二份样本。研究者可在「发布」面板同时取到两个链接与各自的复制按钮（二维码指向逐题模式）。

- **受访者端问卷**：`/research/{share_token}` 公开链接，无需注册、无需登录
  - 知情同意页：展示研究说明、伦理要点与平台默认同意文本（研究者未填写时也不会缺失）
  - 逐题作答：`第 X/Y 题` + 进度条 + 上一题/下一题 + 必答提醒
  - **自动保存**：每题作答后自动写入服务端（500ms 防抖，切页/隐藏时强制刷新）
  - **刷新续答**：会话令牌存于本地，刷新、关闭标签页或换设备重开链接都能继续
  - 完成页：展示匿名编号（`A0007` 形式），便于受访者与研究方核对
  - 移动优先布局，矩阵题在自身容器内横向滚动
- **数据收集接口**：开启会话 → 逐题保存 → 提交，全程无需账号
- **来源追踪**：`?source=wechat` 等参数记录渠道；非法值规范化为 `direct`（不接受注入）
- **样本管理**：分页样本列表（按状态/来源/审核状态/匿名编号筛选）、状态汇总、单样本作答明细（选项代码解析为选项文本）、渠道统计
- **研究者审核**：已采用 / 存疑 / 已排除；**排除必须填写原因**；平台不删除样本，结论可随时改回
- **超时样本标记**：由研究者显式触发，将超过阈值的进行中会话标记为「已中断」（不会覆盖已完成样本）

### PHASE 4 — 数据质量检测引擎、配额管理、动态收集建议

- **数据质量检测引擎**（7 条规则，纯函数实现，可复现）
  | 规则 | 检测内容 | 扣分 |
  | --- | --- | --- |
  | `DUPLICATE_SUBMISSION` | 与另一份样本作答向量完全一致 | 40 |
  | `SUSPICIOUS_SPEED` | 总用时低于阈值，或平均每题 < 2 秒 | 30 |
  | `LONG_STRING` | 连续 ≥20 个量表条目选择同一选项 | 25 |
  | `ALTERNATING_PATTERN` | 连续 ≥12 项 A—B—A—B 交替 | 20 |
  | `HIGH_MISSING` | 展示题目中缺失率 > 20% | 20 |
  | `MATRIX_STRAIGHT_LINE` | 矩阵题 ≥5 行全部同一选项 | 15 |
  | `SUBJECTIVE_OBJECTIVE_DISCREPANCY` | 自评"比较/非常了解"但客观知识题 ≤1 分 | 15 |

  - **质量评分 0—100** = 100 − 各命中规则权重之和；每条规则的权重、依据与解读都随标记一并返回
  - **矩阵题按行展开**参与模式检测（把矩阵当成一个条目会正好掩盖最该发现的规律作答）
  - **只统计实际展示给该受访者的题目**，条件跳转导致的未作答不计入缺失率
  - **敏感题拒答不是一条规则** —— 拒答是受访者的权利，把它当作低质量信号会使敏感题的分析偏向愿意披露的人
  - 提交时自动评分；**跨样本规则会回溯更新**（第二份重复样本到达时，第一份也会被重新评分）
  - 无法运行的规则（如该问卷没有知识题）**显式报告为"不适用"**，而不是表现为"通过"
- **样本配额管理**
  - 可配置任意分类变量作为配额维度（默认模板自带 `STAGE`：学前/小学/初中/高中，200/300/300/200）
  - 实时进度、达标/缺口、缺口排序；**"保持目标样本结构"** 开启时平台只提示偏差、不自动调整目标
  - 统计口径明确：**仅计入已完成且未被研究者排除的样本**（排除的重复样本不应掩盖真实缺口）
- **动态数据收集建议**（规格 §35）
  - 逐条建议都附带可核对的证据（各类计数、观测占比、设计占比、判定阈值、各渠道完成情况）
  - 结构失衡时用**占比**而非绝对数量判断，避免早期样本量小时的误判
  - 给出下一阶段优先收集的分类与建议渠道
- **质量与配额界面**：`Quality` 页面（评分分档、规则命中与解读、待复核样本、已排除样本、重算按钮）、样本详情内的质量面板、项目详情内的配额配置与进度

### PHASE 5 — 统计分析引擎（纯 TypeScript，无 Python 依赖）

统计引擎不依赖 Python，全部以 TypeScript 实现于 `packages/shared/src/stats/`，因此可在浏览器与服务器两端运行同一份代码，且每个统计量都可被单元测试逐一手工核对。

- **分布与特殊函数**：对数 Gamma、不完全 Beta/Gamma、正态/t/F/χ² 分布函数与分位数（用于精确 p 值，而非查表近似）。
- **矩阵运算**：求解、求逆（部分主元）、Jacobi 特征分解，用于回归与因素分析。
- **描述统计**：n、缺失、均值、标准差、标准误、中位数、四分位、偏度、峰度、分组频数；**名义变量不给出均值、百分位、极值与偏度**——选项编码求均值会随编码方式变化，因此只报告频数分布。
- **信度**：Cronbach's α（原始与标准化）、条目间平均相关、校正后题总相关、"删除该条目后的 α"，并公开 α 的判定阈值。
- **效度**：KMO（整体与逐条目 MSA）、Bartlett 球形检验、主成分 + varimax 旋转的探索性因素分析（特征值、碎石、载荷、共同度）；相关矩阵接近奇异时如实返回"无法计算"并说明原因，而不是给一个看似可用的数字。
- **相关**：Pearson / Spearman 按测量层次自动选择（仅当两个变量都是等距/比率测量时才用 Pearson），逐配对给出 r、p、n 与方法。
- **回归**：OLS（B、标准误、β、t、p、95% CI、VIF、R²、调整 R²、F、Durbin-Watson、残差偏度/峰度、异常值）与**有序 Logistic（比例优势）回归**（系数、OR、阈值、似然比检验、McFadden/Nagelkerke R²、命中率，并**检验而非假设**比例优势）。因变量的测量层次决定主结论用哪个模型，另一个模型仍会给出以供对照，且平台会说明选择理由。设计矩阵不可逆时明确报错，不输出无意义的系数。
- **组间比较**：方差齐性检验、t 检验（Student/Welch）、单因素方差分析 + Holm 校正事后比较、Mann–Whitney U、Kruskal–Wallis；**参数与非参数结果始终同时给出**，并注明推荐口径及依据。
- **假设检验**：H1—H8 逐条检验，结论为**三态**——支持 / 不支持（方向相反，属"与假设相反的发现"，不改写假设）/ 证据不足（p ≥ α，不等同于证明无关），另有"无法检验"（变量缺失时如实说明）。效应量按 Cohen 惯例给出小/中/大判定并写明出处。
- **分析 API**：`GET /api/projects/:id/analysis/{dataset,descriptive,reliability,validity,correlation,regression,comparisons,hypotheses}`、`POST .../analysis/run`（计算并持久化完整结果包）、`GET .../analysis/{bundle,history}`。
- **可追溯性**：每次分析（含结果包本身）都写入 `analysis_results`，记录引擎版本、参数、样本量与时间戳；同一数据重复运行结果**逐字节一致**（有测试断言）。
- **分析口径**：仅"已完成且未被研究者排除"的样本进入分析，排除数量随结果一并报告；缺失值不插补、一律整例删除，各分析的有效 n 与删除数均随结果给出。

> **测量层次说明（实证发现）**：模板中 `STAGE`（学段）按有序变量处理（学段本身有序，均值可解释）；`UI`（AI 使用意愿）为题级李克特题、按等距测量处理，因此默认回归对 `UI` 采用 OLS，而非有序 Logistic。有序 Logistic 模型已实现并有端到端测试覆盖（当因变量为有序测量时自动启用并作为主结论）。若研究者希望把 `UI` 作为有序因变量，只需在问卷构建器中把该题的计分规则改为有序编码——平台不会替研究者改动测量层次。

### PHASE 6 — 统计可视化与分析控制台

- **零依赖 SVG 图表**（手写，不引入 ECharts/Recharts/D3）：柱状图、饼图、李克特双向堆叠图（以 0 为中线）、相关热力图（颜色 + 数值 + 显著性星号 + 逐格方法标注）、箱线图/均值±1SD 图、散点图、回归系数森林图（B/log-odds 及 95% CI）、收集漏斗图、配额进度条、来源渠道图。固定 viewBox 整体缩放，窄屏不压缩字号而是横向滚动；所有数字都以真实文本渲染，可读、可断言、不依赖鼠标悬停。
- **八个分析页面**：分析总览（样本口径 + 一键"运行全部分析"）、描述统计、信度、效度、相关、回归、组间差异、假设检验。每页都带中文方法学说明，并如实呈现 API 返回的降级原因。
- **如实降级**：`available: false` 时直接渲染 API 给出的中文原因，而不是画一个空图；名义变量显示 `—` 而不是数字；箱线图明确标注其"不是四分位距"（因为组间接口只给均值与标准差）。

### PHASE 7 — DeepSeek AI 研究助手（四层分层 + 证据留痕 + 反幻觉校验）

- **AI 不产生事实**：解释层只读取已持久化的结果包，绝不重算或修改任何统计量；没有结果包时明确拒绝，并提示先运行统计分析。
- **四层分层**：每条陈述被归入且仅归入一层——`FACT`（事实，直接取自结果包）/ `STATISTICAL_FINDING`（统计发现）/ `INTERPRETATION`（解释）/ `RECOMMENDATION`（建议），接口分列为四组返回，绝不合并成一段文字；中文标签为【事实】【统计发现】【解释】【建议】。
- **证据留痕（Evidence Trace）**：每条发现/解释/建议都携带 `evidence[{path, value}]`，写明它依据结果包中的哪个路径与取值（如 `hypotheses.results[H3].r`、`regression.ordinal.coefficients[STI].p_value`），读者可逐条回查。
- **反幻觉数值校验（本功能的核心安全属性）**：解析模型输出后提取其中每一个数字，逐一与结果包比对（绝对容差 0.005 / 相对容差 0.5%，按数值大小匹配，符号由文字承载）。**任何无法在结果包中定位的数字，都会导致该条陈述被整条剔除并记录在 `rejected_claims` 中**（含被引用的数字与原因），而不会被静默放过。声明了不存在的证据路径、或完全没有证据的陈述，同样被剔除。
- **无密钥时的诚实降级**：未配置 `DEEPSEEK_API_KEY` 时不编造输出、也不返回 500，而是返回 `mode: 'degraded'` 并明确说明原因，同时给出**完全由统计引擎推导**的中文摘要（样本构成、描述统计、信度 α 及其判定阈值、显著相关及效应量、组间比较、回归结果、假设结论统计、结果包前提原文），并标注 `derived_by: 'statistical_engine'`、`ai_generated: false`；此时"解释"与"建议"层刻意留空，不伪装成模型输出。
- **Provider 异常处理**：401/500、网络错误、超时、JSON 损坏、SSE 流、无 choices、空内容——每种都有明确定义的结果（降级 + 原因），绝不静默成功；`finish_reason: length` 视为部分成功，已完成部分仍经数值校验后返回并标注 `truncated`。
- **可审计**：每次交互写入 `ai_interactions`（模型、引擎版本、提示词哈希与 token 用量、原始响应、校验结果、被剔除声明、模式、时间戳）。
- **接口**：`POST /api/projects/:id/ai/interpret`、`GET .../ai/{latest,history,status}`；`status` 让界面在用户点击之前就能如实告知 AI 是否可用。

### PHASE 8 — 研究报告生成与数据导出

- **23 章研究报告**（固定顺序）：标题与摘要、研究背景、研究目的与研究问题、研究假设、文献与理论依据、研究方法、数据来源与抽样、样本概况、测量工具与变量说明、信度分析、效度分析、描述性统计、相关分析、回归分析、组间差异分析、假设检验结果、主要发现、讨论、局限性、结论、政策与管理建议、服务优化建议、参考文献与附录。每章都带 `available`、中文 `unavailable_reason` 与 `evidence`。
- **不编造文献**：平台离线运行、没有文献数据源，因此"文献与理论依据""参考文献与附录"两章恒为 `available: false` 并说明原因，正文中**不出现任何形似引用的内容**（测试断言不出现 `doi`、`et al.`、`(20XX)` 等模式）；其余章节若某个统计结果缺失，同样如实标注为不可用而不是用空话填充。
- **导出格式**：`dataset.csv`（UTF-8 **带 BOM**，Excel 打开中文不乱码；缺失值为**空**而非 0）、`dataset.json`（分别报告 `respondents_total` 与 `respondents_exported`，筛选样本不会被读成全样本）、`codebook.csv`（变量字典 + 码本两段；表头用 ASCII，便于 R/SPSS/Python 直接读取）、SPSS 归档（真实 ZIP：`.sps` 语法 + **无 BOM** 的数据 CSV，只声明 `SYSMIS`，不发明 99/-1 之类缺失码）、`results.xlsx`（11 个工作表，含原始数据、变量字典、码本、质量、描述、信度、效度、相关、回归含有序 Logistic 块、假设检验、研究发现）。SPSS 语法与数据也可分别单独下载。
- **中文文件名**：下载响应使用 RFC 5987 `filename*=UTF-8''`，避免乱码文件名。
- **敏感拒答不外泄**：Q32「不愿回答」样本在数据文件中为空，其标签只出现在码本（用于说明编码），测试逐格式断言。
- **接口**：`GET /api/projects/:id/report`、`GET .../report.md`、`GET .../export/{dataset.csv,dataset.json,codebook.csv,spss,spss/syntax,spss/data,results.xlsx}`。刻意不提供 `?review_status=all`：没有任何服务能诚实地把进行中与已排除样本当作数据提供。

### PHASE 9 — Competition Mode 创业竞赛分析

- **九个区块**：目标用户、痛点（按实测严重程度排序）、现有解决方案、服务缺口、产品需求、信任、AI 接受度、付费意愿、市场机会。每区块返回结构化数据 + 中文叙述 + `inputs` 可用性探测 + `evidence[{path, value}]`。
- **有界推断，拒绝编造商业数字**：市场容量估算被**硬性拒绝**（`available: false`、`amount: null`、`currency: null`，并列出还缺哪些数据）；付费意愿区间中点**绝不折算为金额**；某区块的主变量不存在时返回 `available: false` + 中文原因 + `data: null`（测试对窄问卷断言 7 个区块的诚实拒绝），而不是填 0 或行业默认值。
- **如实声明未测量的内容**：学校/老师与内容平台被明确标注为"本问卷未测量"，而不是借用行业假设；平台也主动披露了问卷中一处变量重名问题（详见"数据诚信"一节）。
- **必备前提**：四条前提恒在最前——非概率（便利）抽样不能代表总体、横截面相关不能推断因果、"声称的付费意愿"不等于实际购买行为、当前时点的 AI 接受度不等于未来采用；随后继承结果包自身的全部前提。
- **陈旧性检测**：当结果包的样本量与当前样本不一致时，提示研究者重新运行分析，而不是把两次快照混在一起。
- **接口**：`POST /api/projects/:id/competition/run`、`GET .../competition/{report,history}`；每次运行以 `run_seq` 序号留痕。

### 默认研究模板



「家庭教育认知、实践与社会支持需求调查 **V4.0**」——58 道题、13 个部分、15 个核心变量
（`FEI` `FEK` `LSK` `LKA` `ISC` `FSE` `FPB` `FED` `FIU` `PSA` `STI` `DSD` `WTP` `UI` `QN`）。

---

## 四、数据诚信约束（代码层面强制）

这些不是文档承诺，而是有测试覆盖的实现约束：

| 约束 | 实现位置 | 测试 |
| --- | --- | --- |
| 不生成任何模拟数据；无样本时统计量为真零值、有效率为 `null` 而非 `0` | `dashboard.service.ts` | `dashboard.api.test.ts` |
| 敏感题的"不愿回答"单独编码为缺失，**绝不并入"从未"** | `scoring.ts` · `template/familyEduV4.ts` | `scoring.test.ts` · `template.test.ts` |
| 答错与"不清楚"严格区分（两者都计 0 分，但分开统计） | `computeKnowledgeAccuracy` | `scoring.test.ts` |
| 名义变量不计算均值（避免"父亲=1、母亲=2"的平均值被引用） | `buildCategoricalDistribution` | `dashboard.api.test.ts` |
| 缺失数包含"完全没有作答记录"的样本，不低估缺失率 | `buildDistribution` | `dashboard.api.test.ts` |
| 问卷发布后锁定，修改必须建立新版本 | `assertEditable` | `builder.api.test.ts` |
| 研究者数据隔离；访问他人项目返回 404 而非 403 | `requireProject` 等 | `projects.api.test.ts` · `dashboard.api.test.ts` |
| 研究假设以"未检验"状态创建，不预设结论 | `createProjectFromTemplate` | `projects.api.test.ts` |
| 仪表盘发现仅为 Level 1 `FACT`，可追溯到题号与 n | `getDashboardOverview` | `dashboard.api.test.ts` |
| **被跳过的题目无法通过接口直接作答**（防止绕过逻辑伪造作答） | `saveAnswer` 可见性校验 | `collection.api.test.ts` |
| **修改前置答案后，失效分支的作答被自动清除**（不留结构性矛盾数据） | `saveAnswer` 剪枝 | `collection.api.test.ts` |
| 作答值必须能对应到问卷定义的选项代码，拒绝伪造代码 | `normalizeAnswer` | `collection.test` · `collection.api.test.ts` |
| 研究者无法读取/修改他人项目的样本 | `listRespondents` · `getRespondentDetail` join 校验 | `sample.api.test.ts` |
| 排除样本必须填写原因，且**不删除数据** | `reviewRespondent` | `sample.api.test.ts` |
| 提交后作答不可再修改（409） | `saveAnswer` | `collection.api.test.ts` |
| 研究者未填写同意说明时，平台展示默认伦理声明而非空白 | `PLATFORM_DEFAULT_CONSENT` | `collection.api.test.ts` |
| **质量评分不删除、不修改任何样本**（只写标记与分数） | `persistEvaluation` | `quality.api.test.ts` |
| **敏感题拒答不扣质量分**（与实质作得分相同） | 规则目录中无拒答规则 | `quality.shared` · `quality.api.test.ts` |
| 质量检测**可复现**：同一数据两次运行结果一致 | `recomputeProjectQuality` | `quality.api.test.ts` |
| 无法运行的规则报告为"不适用"，不伪装成"通过" | `inactive_rules` | `quality.api.test.ts` |
| 每条规则都提示可能的误判情形，避免把标记当结论 | `QUALITY_RULES[].interpretation` | `quality.shared` |
| **排除的样本不计入配额**（否则会掩盖真实缺口） | `countByCategor` | `quota.api.test.ts` |
| 配额的每条建议都可追溯到输入数据（测试逐项核对计数） | `buildQuotaRecommendations` | `quota.shared` |
| 配额结构判断用占比而非绝对数量 | `diagnoseBalance` | `quota.shared` |
| 分析只纳入"已完成且未被排除"的样本，且**排除数量随每个结果一并报告** | `loadAnalysableSample` · `buildCaveats` | `analysis.api.test.ts` |
| 缺失值不插补、一律整例删除；每个结果都报告自己的有效 n 与删除数 | 统计引擎全部模块 | `stats-engine.test.ts` |
| **名义变量不给均值、百分位、极值与偏度**（选项编码求均值会随编码方式变化） | `describeVariable` | `stats-engine.test.ts`（PHASE 5 修正） |
| **展开后的变量名必须全局唯一**：矩阵题按行展开后可能与普通题重名，后者会被静默遮蔽并在导出中产生重复列名 | `buildDataset` + 模板约束 | `template.test.ts`（PHASE 5 发现并修正 Q45/Q46 的 `PSU1` 重名） |
| **方差不齐性检验覆盖全部分组**，而不是只检验前两组；任一组不足 3 例时如实说明无法计算，并建议以非参数结论为主 | `leveneTest` · `oneWayAnova` | `stats-engine.test.ts`（PHASE 5 修正） |
| 参数与非参数结果**始终同时给出**，并说明推荐口径与依据 | `runComparisons` · `planComparison` | `stats-engine.test.ts` |
| 设计矩阵不可逆（完全共线）时明确报错，**不输出无意义的回归系数** | `olsRegression` | `stats-engine.test.ts` · 端到端测试（本 README 的 e2e 用例即覆盖该路径） |
| 假设检验结论为**三态**：支持 / 不支持（方向相反）/ 证据不足；"证据不足"绝不被表述为"证明无关" | `testHypothesis` | `stats-engine.test.ts` · `analysis.api.test.ts` |
| AI **不得引入任何引擎未计算的数字**：无法在结果包中定位的数字会导致该条陈述被整条剔除并留痕 | `validateNumbers` · `parseModelOutput` | `ai.api.test.ts` |
| AI 的四层（事实/统计发现/解释/建议）分列返回，**不合并成一段文字** | `AiLayers` | `ai.api.test.ts` |
| 导出中**缺失值一律为空**（绝不写 0）；敏感拒答的标签不出现在数据文件中 | `datasetToRows` · `toCsv` · `toExcelBuffer` | `export.api.test.ts` |
| SPSS 语法只声明 `SYSMIS`，不发明 99/-1 之类缺失码 | `toSpssBundle` | `export.test.ts` |
| 报告的文献与参考文献章节**不编造任何引用**，并以"不可用 + 原因"呈现 | `report.service.ts` | `report.api.test.ts` |
| 创业洞察**拒绝给出市场容量金额**（`amount: null`）并列出所缺数据；付费意愿区间中点不折算为金额 | `insight.service.ts` | `insight.api.test.ts` |
| 公开问卷的每 IP 会话上限刻意放宽，避免共用公网 IP 的真实受访者被拒 | `PUBLIC_SESSION_LIMIT`（默认 600/15 分钟） | `collection.api.test.ts` · 端到端冒烟 |

`n + missing + sensitive_nonresponse === base_n` 这一守恒关系对每个分布变量都有断言。

---

## 五、技术架构

```
packages/
├── shared/   领域模型、问卷逻辑引擎、计分引擎、变量字典、V4.0 模板
├── server/   Express API、SQLite 数据层、服务层、路由
└── web/      React 控制台（esbuild 打包 + Tailwind）
```

**分层原则**

- `shared` 不含任何 IO；逻辑引擎与计分引擎是纯函数，可被 API、构建器预览、受访者端复用 —— 保证"研究者预览到的"就是"受访者经历的"
- `server` 的统计引擎与 AI 模块严格分离（PHASE 7 的 AI 只能读取统计引擎的输出）
- 原始作答永不被 AI 修改；所有派生变量在读取时计算，不落库覆盖

**关键设计**

- **权限隔离集中在一处**：`requireProject` / `requireQuestionnaireForResearcher` 通过 JOIN 校验归属，路由层不重复实现
- **发布即锁定**：锁定后结构性修改返回 `423 LOCKED`，并给出建立新版本的指引
- **迁移以 TypeScript 模块内嵌**，编译产物自包含，无需资源拷贝步骤
- **二维码服务端渲染**：`<img src>` 无法携带 Authorization 头，因此按 `share_token` 走公开路由 —— 该令牌本身就是公开问卷链接
- **受访者端不持有研究者身份**：会话由 `share_token`（公开链接）+ `session_token`（随机 144 位、仅存本机）构成，与 JWT 体系完全分离
- **同一套渲染组件**：构建器预览、流程模拟器与真实问卷都挂载 `components/QuestionPreview.tsx`，不存在"预览一套、实际另一套"的漂移

### API 一览

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| POST | `/api/auth/register` `/login` `/logout` | 注册 / 登录 / 撤销令牌 |
| GET | `/api/auth/me` | 当前研究者 |
| GET | `/api/templates` | 可用研究模板 |
| GET/POST | `/api/projects` | 项目列表 / 创建 |
| POST | `/api/projects/from-template` | 一键默认研究设计 |
| GET/PATCH/DELETE | `/api/projects/:id` | 项目详情 / 更新 / 删除 |
| GET/POST | `/api/projects/:id/questionnaires` | 问卷列表 / 新建 |
| GET | `/api/projects/:id/dashboard` · `/api/dashboard` | 项目 / 全局仪表盘 |
| GET | `/api/questionnaires/:id` · `/builder` · `/logic` · `/dictionary` | 阅读与字典 |
| PATCH | `/api/questionnaires/:id` | 更新标题与说明 |
| POST | `/api/questionnaires/:id/publish` · `/close` · `/versions` · `/snapshots` · `/preview` | 发布 / 关闭 / 版本 / 快照 / 预览 |
| POST | `/api/questionnaires/:id/questions` · `/questions/reorder` | 新增题目 / 重排 |
| PATCH/DELETE/POST | `/api/questions/:id` · `/duplicate` · `/move` | 题目编辑 / 删除 / 复制 / 移动 |
| GET | `/api/projects/:id/respondents` · `/sources` | 样本列表（可筛选分页）/ 渠道统计 |
| POST | `/api/projects/:id/respondents/sweep` | 标记超时未完成样本 |
| GET | `/api/respondents/:id` | 单样本作答明细（选项已解析） |
| POST | `/api/respondents/:id/review` | 审核结论（已采用 / 存疑 / 已排除） |
| GET | `/api/projects/:id/quality` · `/quality/rules` | 项目质量报告 / 规则目录 |
| POST | `/api/projects/:id/quality/recompute` | 重新运行质量检测（幂等，不删改样本） |
| GET | `/api/respondents/:id/quality` · POST `/quality/recompute` | 单样本评分与标记 / 重新评分 |
| GET/PUT | `/api/projects/:id/quota` | 配额进度与建议 / 更新配额配置 |
| GET | `/api/projects/:id/quota/dimensions` | 可作为配额维度的分类变量 |
| GET | `/api/public/survey/:shareToken` · `/instrument` · `/qrcode` | 公开问卷元信息 / 完整题目 / 二维码 |
| POST | `/api/public/survey/:shareToken/sessions` | 开启作答会话（记录来源渠道） |
| GET | `/api/public/sessions/:token` | 续答状态（作答 + 位置） |
| PATCH | `/api/public/sessions/:token/answers` · `/progress` | 自动保存作答 / 上报进度 |
| POST | `/api/public/sessions/:token/complete` | 提交问卷（校验必答题） |
| GET | `/api/projects/:id/analysis/dataset` · `/descriptive` · `/reliability` · `/validity` | 分析数据集 / 描述统计 / 信度 / 效度 |
| GET | `/api/projects/:id/analysis/correlation` · `/regression` · `/comparisons` · `/hypotheses` | 相关 / 回归 / 组间差异 / 假设检验 |
| POST | `/api/projects/:id/analysis/run` | 计算并持久化完整结果包 |
| GET | `/api/projects/:id/analysis/bundle` · `/history` | 最近结果包 / 分析历史（可复现） |
| POST | `/api/projects/:id/ai/interpret` | 四层分层解释（含证据留痕与数值校验） |
| GET | `/api/projects/:id/ai/latest` · `/history` · `/status` | 最近解释 / 交互审计 / 可用性状态 |
| GET | `/api/projects/:id/report` · `/report.md` | 23 章研究报告（结构化 + Markdown） |
| GET | `/api/projects/:id/export/dataset.csv` · `/dataset.json` · `/codebook.csv` | 数据 / JSON / 变量字典与码本 |
| GET | `/api/projects/:id/export/spss` · `/spss/syntax` · `/spss/data` | SPSS 归档（.sps + 数据）或分别下载 |
| GET | `/api/projects/:id/export/results.xlsx` | 多工作表分析结果工作簿 |
| POST | `/api/projects/:id/competition/run` | 生成创业洞察报告并留痕 |
| GET | `/api/projects/:id/competition/report` · `/history` | 最近创业洞察 / 运行历史 |

---

## 六、测试

| 套件 | 数量 | 覆盖内容 |
| --- | --- | --- |
| `@ferp/shared` | 369 | 58 题模板结构、15 个核心变量、知识题、敏感题、跳转逻辑、计分、作答规范化、变量字典、输入校验、质量规则与评分、配额与建议引擎、**完整统计引擎（分布函数、矩阵运算、描述、信度、效度、相关、回归、有序 Logistic、组间比较、假设检验）** |
| `@ferp/server` | 429 | 迁移与约束、scrypt/JWT 安全边界、认证全流程、项目 CRUD、数据隔离、构建器全部题型、发布与版本控制、仪表盘聚合、采集闭环与逻辑完整性、样本管理与渠道统计、质量引擎集成与配额 API、**统计分析 API、AI 助手（含反幻觉校验与降级模式）、研究报告、导出格式、创业洞察** |
| `@ferp/web` | 162 | jsdom 中真实挂载 React 组件：登录/注册表单交互、十种题型渲染、导航与路由、API 客户端错误处理、受访者端完整作答旅程（**逐题模式与整页模式两套版式**）、质量页诚信提示、**十类统计图表与八个分析控制台页面、AI 助手（四层分层 / 证据留痕 / 被拦截声明的展示 / 降级模式标注）、23 章报告页、导出页、创业洞察页**；含附件下载（鉴权后按服务端文件名保存）与剪贴板不可用时的诚实回退 |
| `scripts/e2e-smoke.mjs` | 308 | 对运行中的服务做真实验证（二维码、CSV BOM、令牌撤销、58 题作答闭环、渠道追踪、样本审核、分布守恒、质量检测可复现性与"不删除样本"、配额口径与建议、**统计分析全链路（含"派生构念与原始作答逐项重算一致"的交叉验证）、AI 降级模式与审计留痕、23 章报告与全部导出格式、创业洞察的有界推断**）；自带独立研究者与项目，可重复运行 |

```bash
npm test        # 960 项
npm run e2e     # 308 项（需 API 运行中）
```

> **关于浏览器验证**：本沙箱无法启动 Chromium（其多进程 IPC 依赖命名管道，被沙箱拦截），因此 UI 采用 jsdom 真实挂载验证，而非截图验证。前端产物本身已通过 `http://127.0.0.1:5173` 实际提供并校验（含 SPA 深链接回退）。

---

## 七、路线图

| 阶段 | 内容 | 状态 |
| --- | --- | --- |
| PHASE 1 | 项目初始化、数据库、登录、JWT、研究项目、Dashboard | ✅ 完成 |
| PHASE 2 | 问卷构建器、题型、逻辑、预览、发布、版本控制 | ✅ 完成 |
| PHASE 3 | 受访者端填写 UI、数据收集、来源追踪、样本管理 | ✅ 完成 |
| PHASE 4 | 数据质量检测引擎、配额管理、动态收集建议 | ✅ 完成 |
| PHASE 5 | 统计引擎：描述、信度（α）、效度（KMO/Bartlett/EFA）、相关、回归（含有序 Logistic）、组间比较、假设检验、效应量 | ✅ 完成 |
| PHASE 6 | 可视化（柱状、饼图、李克特分布、热力图、箱线图、散点、回归图、漏斗、配额进度、来源渠道） | ✅ 完成 |
| PHASE 7 | DeepSeek AI 研究助手、Evidence Trace、四层解释分层、反幻觉数值校验 | ✅ 完成（无密钥时为引擎推导的诚实降级模式） |
| PHASE 8 | 研究报告生成器（23 章）、Excel/CSV/JSON/SPSS 导出 | ✅ 完成 |
| PHASE 9 | Competition Mode 创业洞察（九区块，有界推断） | ✅ 完成 |

左侧菜单中未实现的条目会以 `PHASE n` 标签显示为禁用状态，不会伪装成可用功能。PHASE 1—9 的功能在界面上均可实际点击使用。

### 已知限制（如实记录，未隐藏）

- **两份文献类章节无法生成**：平台离线运行、没有文献数据库，因此研究报告的第 5 章（文献与理论依据）与第 23 章（参考文献与附录）恒为"不可用 + 原因"，不会编造引用。研究者需自行补充。
- **`UI`（AI 使用意愿）按等距测量处理**：题级定义为李克特题，因此默认回归用 OLS。有序 Logistic 模型已实现并有端到端测试覆盖；若研究者希望把 `UI` 作为有序因变量，把该题计分规则改为有序编码即可，平台不会替研究者改动测量层次。
- **箱线图用"均值 ± 1 SD"呈现**：组间比较接口只返回各组的 n/均值/标准差/极值，没有中位数与四分位，因此图表如实标注"不是四分位距"，而不是画出看起来像箱线图的假四分位。
- **无头浏览器不可用**：UI 以 jsdom 真实挂载 + DOM 文本断言验证，没有像素级截图验证。
- **Docker 未提供**：本环境无法运行 Docker，因此仓库不包含未经实测的 `docker-compose.yml`；本地脚本（build / serve / dev）即为实际部署方式。
- **整页模式对"纯跳转"规则的处理**：条件分支若用 `show`/`hide` 显示规则表达（构建器默认生成的方式，也是本平台 V4 模板的方式——例如 Q39「从未使用」同时带跳转规则与 Q40 的显示条件，双重保障），两种版式表现完全一致。但若某份问卷**只用** `jump_to` 跳过题目、没有配套的显示规则，整页模式仍会渲染该题（跳转在逐题模式下是光标导航语义，整页模式没有光标）。逐题模式与整页模式对这类问卷的取数会不同，因此：用跳转规则设计分支时，请同时为被跳过的题设置显示条件。

---

## 八、配置

通过环境变量配置（`packages/server/src/config.ts`）：

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `PORT` / `HOST` | `4000` / `127.0.0.1` | API 监听地址 |
| `DATABASE_PATH` | `packages/server/data/ferp.db` | SQLite 文件；`:memory:` 为内存库 |
| `JWT_SECRET` | 开发环境随机生成 | **生产环境必须显式设置 ≥32 字符，否则拒绝启动** |
| `JWT_EXPIRES_IN` | `43200` | 令牌有效期（秒） |
| `CORS_ORIGINS` | `http://localhost:5173,...` | 允许的前端来源 |
| `PUBLIC_BASE_URL` | `http://localhost:5173` | 生成分享链接所用前缀 |
| `PUBLIC_SESSION_LIMIT` | `600` | 公开问卷每 IP 每 15 分钟可开启的作答会话数上限。默认值刻意放宽：真实受访者常常共用同一公网 IP（学校机房、办公楼、运营商 NAT），过紧的上限会直接拒掉真实参与者 |
| `SEED_DEMO_EMAIL` | `demo@ferp.local` | 演示账号邮箱（可由本地配置文件覆盖）。邮箱不是机密，写在此处便于说明；密码不在文档中给出 |
| `SEED_DEMO_PASSWORD` | 未设置 | 演示账号密码。**未设置时由 `npm run db:seed` 随机生成并只打印一次**；设置在本地配置文件中可固定下来。密码不写入源码、不写入文档 |
| `DEEPSEEK_API_KEY` | 未设置 | 未设置时 AI 助手进入**诚实降级模式**（由统计引擎推导摘要，不调用模型、不编造输出），界面会明确告知 |
| `DEEPSEEK_BASE_URL` / `DEEPSEEK_MODEL` | `https://api.deepseek.com` / 内置默认模型 | AI 服务地址与模型名 |
| `DEEPSEEK_TIMEOUT_MS` / `DEEPSEEK_MAX_TOKENS` | 内置默认 | 请求超时与最大输出长度 |

前端 API 地址可在登录页通过 `?api=http://host:port` 覆盖。
