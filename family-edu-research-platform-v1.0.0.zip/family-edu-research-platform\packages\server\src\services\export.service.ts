/**
 * Export service (PHASE 8).
 *
 * Turns a built `Dataset` — optionally accompanied by real analysis results —
 * into the artefacts a researcher actually downloads: wide-format CSV, JSON,
 * an SPSS-ready bundle and a multi-sheet Excel workbook.
 *
 * Two rules shape everything below.
 *
 *  - **Missing stays missing.** A `null` value is never coerced to `0`, never
 *    turned into an empty-string category and never replaced by a default: it
 *    becomes an empty CSV field, an empty cell, JSON `null`, and in SPSS it is
 *    declared under `MISSING VALUES`. Unanswered items and sensitive refusals
 *    ("不愿回答") are both missing, so a refusal can never enter a frequency
 *    table as if it were a substantive answer.
 *
 *  - **No statistic is invented here.** This module has no statistical engine;
 *    it formats results it is handed. When a caller supplies no results for an
 *    analysis sheet, that sheet is created empty with an explicit "not run yet"
 *    note. An honest empty sheet is correct; a plausible-looking number is not.
 */

import ExcelJS, { type Workbook, type Worksheet } from 'exceljs';

import {
  buildVariableDictionary,
  type Dataset,
  type DatasetVariable,
  type Question,
  type VariableDefinition,
} from '@ferp/shared';

/* ------------------------------------------------------------------ */
/* Public types                                                       */
/* ------------------------------------------------------------------ */

export interface ExportContext {
  projectTitle: string;
  questionnaireTitle: string;
  questionnaireVersion: string;
  /** ISO timestamp of the export; also drives the file names. */
  exportedAt: string;
  /** Total collected, may exceed the dataset's rows after exclusions. */
  respondentsTotal: number;
  /** e.g. "已排除 3 份样本"; printed wherever metadata is reported. */
  excludedNote?: string | null;
  /**
   * The stored questionnaire, when the caller can supply it.
   *
   * With the questions, the dictionary and codebook describe coding, missing
   * handling and the analysis method implied by each measurement level. Without
   * them only the fields carried by `DatasetVariable` are known, so the columns
   * that would require guessing are marked as coming from the dictionary
   * interface instead of being invented.
   */
  questions?: Question[];
}

/** A sheet a caller contributes, typically from a real analysis run. */
export interface ExportSheet {
  name: string;
  headers: string[];
  rows: (string | number | null)[][];
}

export interface ExportFilenames {
  csv: string;
  json: string;
  spssData: string;
  spssSyntax: string;
  excel: string;
}

export interface SpssBundle {
  /** The CSV the generated syntax reads: same columns, no BOM (see below). */
  data: string;
  /** The `.sps` syntax file pairing with `data`. */
  syntax: string;
}

export interface ExportCodebookEntry extends VariableDefinition {
  /** Option code → option label, for decoding the numeric columns. */
  value_labels: Record<string, string>;
  /** Non-missing values actually exported. */
  n_valid: number;
  /** Missing values actually exported (never counted as 0). */
  n_missing: number;
}

export interface ExportMetadata {
  project_title: string;
  questionnaire_title: string;
  questionnaire_version: string;
  exported_at: string;
  /** Collected total, before any exclusion. */
  respondents_total: number;
  /** Rows present in this file. */
  respondents_exported: number;
  excluded_note: string | null;
  variable_count: number;
  /** Variables the questionnaire defines but for which nothing was collected. */
  empty_variables: string[];
  missing_value_note: string;
  generator: string;
}

export interface JsonExportPayload {
  metadata: ExportMetadata;
  /** Column order of `data`, identical to the CSV header row. */
  columns: string[];
  codebook: ExportCodebookEntry[];
  data: Record<string, string | number | null>[];
}

/* ------------------------------------------------------------------ */
/* Constants                                                          */
/* ------------------------------------------------------------------ */

/** Column A of every wide-format artefact. */
const RESPONDENT_ID_COLUMN = 'respondent_id';

/** The id column is a string in SPSS; this is its fallback width. */
const ID_STRING_FORMAT_FALLBACK = 64;

/** SPSS's classic A-format ceiling. */
const SPSS_MAX_STRING_WIDTH = 255;

/** Classic SPSS variable-name length limit; longer names are rejected. */
const SPSS_MAX_NAME_LENGTH = 32;

export const DICTIONARY_HEADERS: string[] = [
  'Variable Name',
  'Question Code',
  'Question Text',
  'Dimension',
  'Data Type',
  'Coding',
  'Missing Value',
  'Scoring Rule',
  'Analysis Method',
  'Derived',
];

export const CODEBOOK_HEADERS: string[] = [
  'Variable Name',
  'Variable Label',
  'Dimension',
  'Value',
  'Label',
];

/**
 * Stands in for analysis output that has not been produced yet. Exported so the
 * API, the console and the tests can compare against one shared string instead
 * of three copies drifting apart.
 */
export const ANALYSIS_NOT_RUN_NOTE =
  '该项分析尚未运行。请先在该研究的「Analysis」页面执行后再导出。';

/** Columns that cannot be derived from a `DatasetVariable` on its own. */
const DICTIONARY_DETAILS_PLACEHOLDER = '见变量字典接口';

const MISSING_VALUE_NOTE =
  '缺失值统一导出为空（CSV 空字段 / Excel 空单元格 / JSON null）；' +
  '未作答与敏感拒答（如「不愿回答」）同为缺失，不插补、不记为 0，也绝不作为实质性类别参与统计。';

const GENERATOR = 'family-edu-research-platform';

/** Sheet names, in the order the workbook must present them. */
const RAW_DATA_SHEET = 'Raw Data';
const DICTIONARY_SHEET = 'Variable Dictionary';
const CODEBOOK_SHEET = 'Codebook';

/**
 * Analysis sheets with the columns their real output will use. Only the header
 * row is written here; the numbers come from the caller (see `toExcelBuffer`).
 */
const ANALYSIS_SHEETS: { name: string; headers: string[] }[] = [
  { name: 'Data Quality', headers: ['Metric', 'Value', 'Note'] },
  {
    name: 'Descriptive Statistics',
    headers: ['Variable Name', 'Variable Label', 'Dimension', 'N', 'Missing', 'Mean', 'SD', 'Min', 'Max', 'Median'],
  },
  { name: 'Reliability', headers: ['Scale', 'Items', 'Cronbach α', 'N of Cases', 'Note'] },
  { name: 'Validity', headers: ['Test', 'Statistic', 'df', 'p', 'Note'] },
  { name: 'Correlation', headers: ['Variable 1', 'Variable 2', 'Method', 'N', 'r', 'p'] },
  {
    name: 'Regression',
    headers: ['Model', 'Dependent Variable', 'Predictor', 'B', 'SE', 'Beta', 't', 'p', 'R²', 'Adjusted R²', 'N'],
  },
  { name: 'Hypothesis Testing', headers: ['Hypothesis', 'Statement', 'Test', 'Statistic', 'p', 'Decision'] },
  { name: 'Research Findings', headers: ['序号', '发现', '支撑分析', '局限性'] },
];

/** Excel's own limits: 31 characters, no []:*?/\ and no surrounding apostrophe. */
const EXCEL_MAX_SHEET_NAME = 31;
const EXCEL_ILLEGAL_SHEET_CHARS = /[[\]:*?/\\]/g;

/** Width sampling bound: formatting must not become the slowest part of an export. */
const WIDTH_SAMPLE_ROWS = 200;
const MAX_COLUMN_WIDTH = 60;

/* ------------------------------------------------------------------ */
/* Wide-format data                                                   */
/* ------------------------------------------------------------------ */

/**
 * Wide-format raw data: one row per respondent, one column per variable.
 *
 * The shape is deliberately primitive (no objects, no `undefined`) because it
 * feeds three very different writers — CSV, Excel and SPSS — and every one of
 * them must be able to tell "no answer" apart from "answered zero".
 */
export function datasetToRows(dataset: Dataset): {
  headers: string[];
  rows: (string | number | null)[][];
} {
  const headers = [RESPONDENT_ID_COLUMN, ...dataset.variables.map((variable) => variable.name)];
  const rows = dataset.respondent_ids.map((respondentId, index) => [
    respondentId,
    ...dataset.variables.map((variable) => cellValue(variable, index)),
  ]);
  return { headers, rows };
}

/**
 * One cell of the matrix.
 *
 * Text questions are the one deliberate exception to reading `values` alone:
 * the dataset builder gives them an all-`null` numeric column because text is
 * not numerically coded, so the stored answer is the only record of what was
 * said. The exception cannot leak a refusal into a numeric column, because
 * refusals and non-responses on *scored* questions are already mapped to `null`
 * by the dataset builder and those variables never read `raw` here.
 */
function cellValue(variable: DatasetVariable, index: number): string | number | null {
  const value = variable.values[index];
  if (value !== null && value !== undefined && Number.isFinite(value)) return value;
  if (variable.data_type !== 'text') return null;
  return rawText(variable.raw[index]);
}

function rawText(answer: unknown): string | number | null {
  if (typeof answer === 'string') return answer.trim() === '' ? null : answer;
  if (typeof answer === 'number') return Number.isFinite(answer) ? answer : null;
  // Arrays (multi-select, ranking) and matrix maps have no single cell; the
  // numeric column already carries their coded value.
  return null;
}

/* ------------------------------------------------------------------ */
/* Codebook                                                           */
/* ------------------------------------------------------------------ */

/**
 * Option code → label tables, one row per (variable, option), so a reader can
 * decode the numeric columns of the raw data without reopening the builder.
 *
 * Codes are emitted as numbers when they look numeric, matching the values in
 * the data sheet; a variable without options gets an explanatory row rather
 * than being silently absent, which would read as "no coding exists".
 */
export function codebookRows(dataset: Dataset): (string | number)[][] {
  const rows: (string | number)[][] = [CODEBOOK_HEADERS.slice()];

  for (const variable of dataset.variables) {
    const codes = Object.keys(variable.value_labels);
    if (codes.length === 0) {
      rows.push([
        variable.name,
        variable.label,
        variable.dimension,
        '（无选项编码）',
        noLabelsNote(variable),
      ]);
      continue;
    }
    for (const code of codes) {
      rows.push([
        variable.name,
        variable.label,
        variable.dimension,
        numericLooking(code) ? Number(code) : code,
        variable.value_labels[code] ?? '',
      ]);
    }
  }

  return rows;
}

function noLabelsNote(variable: DatasetVariable): string {
  if (variable.data_type === 'text') {
    return '文本变量：不进行数值编码，原始文本见「Raw Data」表。';
  }
  if (variable.is_derived) {
    return '派生变量：由题项计算得出，取值为连续量，没有选项编码。';
  }
  return `该变量未声明选项标签，编码方式请见「${DICTIONARY_SHEET}」表的 Coding 列。`;
}

function numericLooking(code: string): boolean {
  const trimmed = code.trim();
  return trimmed !== '' && /^-?\d+(\.\d+)?$/.test(trimmed);
}

/* ------------------------------------------------------------------ */
/* CSV                                                                */
/* ------------------------------------------------------------------ */

/**
 * CSV of the raw data (UTF-8, with a leading BOM).
 *
 * The BOM is what makes Excel open a Chinese export as UTF-8 instead of
 * mangling it into the local ANSI code page.
 *
 * No metadata block precedes the header row: every line after the first is
 * exactly one respondent, which is what downstream tools (and researchers
 * counting rows) assume.
 */
export function toCsv(dataset: Dataset, context: ExportContext): string {
  const { headers, rows } = datasetToRows(dataset);
  // `context` intentionally contributes nothing here: the file name carries the
  // project and date, and the JSON/Excel exports carry the full metadata.
  void context;
  return `${BOM}${serializeCsv([headers, ...rows])}`;
}

const BOM = '\uFEFF';

/**
 * RFC 4180 field quoting.
 *
 * Line endings are LF, matching the shared `dictionaryToCsv`, so two modules of
 * the same platform never hand the researcher two different newline
 * conventions. Excel and SPSS both accept LF; only fields that genuinely
 * contain a break get quoted.
 */
function csvField(value: string | number | null | undefined): string {
  if (value === null || value === undefined) return '';
  const text = String(value);
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function serializeCsv(rows: (string | number | null)[][]): string {
  return rows.map((row) => row.map(csvField).join(',')).join('\n');
}

/* ------------------------------------------------------------------ */
/* JSON                                                               */
/* ------------------------------------------------------------------ */

/** JSON export with data + metadata + codebook. */
export function toJson(dataset: Dataset, context: ExportContext): string {
  return JSON.stringify(buildJsonPayload(dataset, context), null, 2);
}

function buildJsonPayload(dataset: Dataset, context: ExportContext): JsonExportPayload {
  const { headers, rows } = datasetToRows(dataset);

  return {
    metadata: metadataOf(dataset, context),
    columns: headers,
    codebook: dictionaryFor(dataset, context).map((definition) => {
      const variable = dataset.by_name.get(definition.variable_name);
      const values = variable?.values ?? [];
      return {
        ...definition,
        value_labels: variable?.value_labels ?? {},
        // Counts are computed from the exported column itself, so they describe
        // this file rather than an assumed analysis sample.
        n_valid: values.filter((value) => value !== null && value !== undefined).length,
        n_missing: values.filter((value) => value === null || value === undefined).length,
      };
    }),
    data: rows.map((row) => {
      const record: Record<string, string | number | null> = {};
      headers.forEach((header, index) => {
        // `null` rather than a dropped key: a consumer that ignores missing
        // values should have to do so explicitly.
        record[header] = row[index] ?? null;
      });
      return record;
    }),
  };
}

/**
 * Metadata reported with every export.
 *
 * `respondents_total` and `respondents_exported` are both stated because they
 * legitimately differ once samples are excluded; reporting only one of them is
 * how a filtered sample silently becomes "the sample".
 */
function metadataOf(dataset: Dataset, context: ExportContext): ExportMetadata {
  return {
    project_title: context.projectTitle,
    questionnaire_title: context.questionnaireTitle,
    questionnaire_version: context.questionnaireVersion,
    exported_at: context.exportedAt,
    respondents_total: context.respondentsTotal,
    respondents_exported: dataset.n_respondents,
    excluded_note: context.excludedNote ?? null,
    variable_count: dataset.variables.length,
    empty_variables: dataset.empty_variables.slice(),
    missing_value_note: MISSING_VALUE_NOTE,
    generator: GENERATOR,
  };
}

/* ------------------------------------------------------------------ */
/* Variable dictionary                                                */
/* ------------------------------------------------------------------ */

/**
 * Dictionary rows for the exported variables.
 *
 * With the stored questionnaire the rows come from `buildVariableDictionary`,
 * which documents coding, missing handling and the analysis method each
 * measurement level implies. Without it, only the fields a `DatasetVariable`
 * carries are known, and the rest are marked as belonging to the dictionary
 * interface rather than guessed.
 */
function dictionaryFor(dataset: Dataset, context: ExportContext): VariableDefinition[] {
  const questions = context.questions ?? [];
  const definitions: VariableDefinition[] = [];
  const covered = new Set<string>();

  if (questions.length > 0) {
    for (const definition of buildVariableDictionary(questions)) {
      definitions.push(definition);
      covered.add(definition.variable_name);
    }
  }

  // A column that is exported but undocumented would make the codebook quietly
  // incomplete, so every remaining dataset variable is added explicitly.
  for (const variable of dataset.variables) {
    if (covered.has(variable.name)) continue;
    definitions.push(variableDefinition(variable));
  }

  return definitions;
}

function variableDefinition(variable: DatasetVariable): VariableDefinition {
  return {
    variable_name: variable.name,
    question_code: variable.question_code,
    question_text: variable.label,
    dimension: variable.dimension,
    data_type: variable.data_type,
    coding: DICTIONARY_DETAILS_PLACEHOLDER,
    missing_value: DICTIONARY_DETAILS_PLACEHOLDER,
    scoring_rule: DICTIONARY_DETAILS_PLACEHOLDER,
    analysis_method: DICTIONARY_DETAILS_PLACEHOLDER,
    is_derived: variable.is_derived,
    note: variable.sources.length > 0 ? `来源题项：${variable.sources.join('、')}` : '',
  };
}

function dictionarySheetRows(dataset: Dataset, context: ExportContext): (string | number)[][] {
  return [
    DICTIONARY_HEADERS.slice(),
    ...dictionaryFor(dataset, context).map((definition) => [
      definition.variable_name,
      definition.question_code,
      definition.question_text,
      definition.dimension,
      definition.data_type,
      definition.coding,
      definition.missing_value,
      definition.scoring_rule,
      definition.analysis_method,
      definition.is_derived ? '是' : '否',
    ]),
  ];
}

/* ------------------------------------------------------------------ */
/* SPSS                                                               */
/* ------------------------------------------------------------------ */

/**
 * SPSS-compatible export: a CSV data file plus a `.sps` syntax file that
 * declares variable labels, value labels and missing values.
 *
 * The data file is written **without** a BOM. `/TYPE=TXT` reads the first field
 * literally, so a BOM would silently become part of the first variable name and
 * the import would fail in a way that looks like a data problem; the encoding
 * is declared in the syntax (`/ENCODING='UTF8'`) instead.
 */
export function toSpssBundle(dataset: Dataset, context: ExportContext): SpssBundle {
  const filenames = exportFilenames(context);
  const { headers, rows } = datasetToRows(dataset);

  return {
    data: serializeCsv([headers, ...rows]),
    syntax: buildSpssSyntax(dataset, context, headers, rows, filenames),
  };
}

interface SpssColumn {
  /** Variable name safe for SPSS. */
  name: string;
  /** Column header as it appears in the platform's own exports. */
  source: string;
  variable: DatasetVariable | undefined;
  isText: boolean;
  format: string;
}

function spssColumns(
  dataset: Dataset,
  headers: string[],
  rows: (string | number | null)[][],
): SpssColumn[] {
  const names = spssVariableNames(headers);

  return headers.map((source, index) => {
    const variable = index === 0 ? undefined : dataset.variables[index - 1];
    const isText = index === 0 || variable?.data_type === 'text';
    const format = isText
      ? stringFormat(columnTextWidth(rows, index), index === 0 ? ID_STRING_FORMAT_FALLBACK : 8)
      : numericFormat(variable);
    return { name: names[index] ?? `V${index + 1}`, source, variable, isText, format };
  });
}

function buildSpssSyntax(
  dataset: Dataset,
  context: ExportContext,
  headers: string[],
  rows: (string | number | null)[][],
  filenames: ExportFilenames,
): string {
  const columns = spssColumns(dataset, headers, rows);
  const excluded = context.excludedNote ? `；${context.excludedNote}` : '';

  const lines: string[] = [
    ...spssComments([
      '=====================================================================',
      `${context.projectTitle} —— SPSS 语法文件`,
      '=====================================================================',
      `配对数据文件：${filenames.spssData}`,
      `语法文件：${filenames.spssSyntax}`,
      `问卷：${context.questionnaireTitle}（${context.questionnaireVersion}）`,
      `导出时间：${context.exportedAt}`,
      `样本：收集 ${context.respondentsTotal} 份，本次导出 ${dataset.n_respondents} 份${excluded}`,
      '使用方法：请把本语法文件与配对数据文件放在同一目录并保持文件名不变；',
      '若数据文件在其他目录，请先修改下方 /FILE 中的路径',
      '缺失值：数据文件中未作答与敏感拒答均写为空字段，SPSS 读入后为系统缺失，',
      '并已在 MISSING VALUES 段显式声明；缺失不会被当作 0 或某个实质性类别',
      'VALUE LABELS 依据问卷选项代码生成；若某题使用分类/有序计分规则',
      '（选项代码 ≠ 分析取值），请以「Variable Dictionary」表的 Coding 列为准',
      '=====================================================================',
    ]),
    '',
    'GET DATA',
    '  /TYPE=TXT',
    `  /FILE=${spssLiteral(filenames.spssData)}`,
    "  /ENCODING='UTF8'",
    "  /DELIMITERS=','",
    '  /QUALIFIER=\'"\'',
    '  /ARRANGEMENT=DELIMITED',
    '  /FIRSTCASE=2',
    '  /VARIABLES=',
    ...columns.map((column) => `    ${column.name} ${column.format}`),
    '  /MAP.',
    'EXECUTE.',
    '',
  ];

  lines.push('VARIABLE LABELS');
  for (const column of columns) {
    lines.push(`  ${column.name} ${spssLiteral(variableLabelOf(column))}`);
  }
  lines.push('  .', '');

  const labelled = columns.filter(
    (column) => Object.keys(column.variable?.value_labels ?? {}).length > 0,
  );
  if (labelled.length > 0) {
    lines.push('VALUE LABELS');
    labelled.forEach((column, position) => {
      lines.push(`  ${position === 0 ? '' : '/ '}${column.name}`.trimEnd());
      for (const [code, label] of Object.entries(column.variable?.value_labels ?? {})) {
        lines.push(`    ${spssValueToken(code)} ${spssLiteral(label)}`);
      }
    });
    lines.push('  .', '');
  } else {
    lines.push(...spssComments(['本次导出的变量未声明选项标签，因此没有 VALUE LABELS 段']), '');
  }

  const numeric = columns.filter((column) => !column.isText).map((column) => column.name);
  if (numeric.length > 0) {
    lines.push('MISSING VALUES');
    const chunks = wrapTokens(numeric, 68);
    chunks.forEach((chunk, position) => {
      const terminator = position === chunks.length - 1 ? ' (SYSMIS).' : '';
      lines.push(`  ${chunk.join(' ')}${terminator}`);
    });
    lines.push('');
  } else {
    lines.push(...spssComments(['本次导出不含数值变量，因此没有 MISSING VALUES 段']), '');
  }

  const textColumns = columns.filter((column) => column.isText);
  if (textColumns.length > 0) {
    lines.push(
      ...spssComments([
        '字符串变量（respondent_id 与文本题）无法声明 SYSMIS，空字段即视为无作答',
      ]),
      '',
    );
  }

  lines.push('EXECUTE.');
  return lines.join('\n');
}

function variableLabelOf(column: SpssColumn): string {
  // The id column has no dataset variable behind it, but a bare
  // "respondent_id" as its label would tell a reader nothing.
  if (!column.variable) return '受访者匿名编号（respondent_id）';

  const label = column.variable.label;
  // When SPSS forced a different name, the original one is kept in the label so
  // the syntax can still be matched against the platform's own exports.
  if (column.name !== column.source && label !== column.source) {
    return `${label} [${column.source}]`;
  }
  return label;
}

/**
 * SPSS variable names: letters, digits and underscores, starting with a letter,
 * at most 32 characters. Longer names are rejected outright, so truncating is
 * strictly better than a syntax file SPSS refuses to run. Collisions created by
 * truncation get a numeric suffix, since SPSS requires unique names.
 */
function spssVariableNames(headers: string[]): string[] {
  const used = new Set<string>();

  return headers.map((header, index) => {
    const cleaned = header.replace(/[^A-Za-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
    // A name made only of characters SPSS cannot use (e.g. a fully Chinese
    // variable name) falls back to its position, which is stable for a given
    // questionnaire and never collides.
    const fallback = `V${index + 1}`;
    let base = cleaned === '' ? fallback : cleaned;
    if (!/^[A-Za-z]/.test(base)) base = `V_${base}`;
    base = base.slice(0, SPSS_MAX_NAME_LENGTH);

    let name = base;
    let suffix = 1;
    while (used.has(name.toLowerCase())) {
      suffix += 1;
      const tag = `_${suffix}`;
      name = `${base.slice(0, SPSS_MAX_NAME_LENGTH - tag.length)}${tag}`;
    }
    used.add(name.toLowerCase());
    return name;
  });
}

function stringFormat(maxLength: number, minimum: number): string {
  const width = Math.min(Math.max(maxLength, minimum), SPSS_MAX_STRING_WIDTH);
  return `A${width}`;
}

function numericFormat(variable: DatasetVariable | undefined): string {
  if (!variable) return 'F8.2';
  return variable.data_type === 'interval' || variable.data_type === 'ratio' ? 'F12.2' : 'F8.0';
}

function columnTextWidth(rows: (string | number | null)[][], index: number): number {
  let width = 0;
  for (const row of rows) {
    const value = row[index];
    if (typeof value === 'string') width = Math.max(width, value.length);
  }
  return width;
}

/**
 * SPSS string literal.
 *
 * SPSS accepts either quote style but has no escape sequence supported by every
 * version, so a label containing the delimiting quote is a syntax hazard. ASCII
 * apostrophes are therefore swapped for the fullwidth character when single
 * quotes are used — visually identical in the Chinese labels this platform
 * produces, and never breaks the file.
 */
function spssLiteral(text: string): string {
  const flat = text.replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (flat.includes("'") && !flat.includes('"')) return `"${flat}"`;
  return `'${flat.replace(/'/g, '\u2019')}'`;
}

/** Numeric codes stay unquoted so SPSS matches them as numbers. */
function spssValueToken(code: string): string {
  const trimmed = code.trim();
  return /^-?\d+(\.\d+)?$/.test(trimmed) ? trimmed : spssLiteral(trimmed);
}

/**
 * SPSS comments end at the first period, so a period inside the body (a version
 * number such as "V4.0", or an ellipsis) would end the comment early and leave
 * the remainder to be parsed as a command. Periods are replaced in comments
 * only — labels and data are never altered.
 */
function spssComments(texts: string[]): string[] {
  return texts.map((text) => `* ${text.replace(/\./g, '·').replace(/\s+/g, ' ').trim()}.`);
}

function wrapTokens(tokens: string[], budget: number): string[][] {
  const lines: string[][] = [];
  let current: string[] = [];
  let length = 0;

  for (const token of tokens) {
    if (current.length > 0 && length + token.length + 1 > budget) {
      lines.push(current);
      current = [];
      length = 0;
    }
    current.push(token);
    length += token.length + 1;
  }
  if (current.length > 0) lines.push(current);
  return lines;
}

/* ------------------------------------------------------------------ */
/* File names                                                         */
/* ------------------------------------------------------------------ */

/** Characters Windows forbids in a file name; the path separators are included. */
const ILLEGAL_FILENAME_CHARS = /[\\/:*?"<>|]/g;

const WINDOWS_RESERVED_NAMES = new Set([
  'CON', 'PRN', 'AUX', 'NUL',
  'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
  'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9',
]);

/**
 * Download file names: a slug of the project title plus the export date.
 *
 * Path separators are stripped above all else, so a project title such as
 * `..\..\evil` can never influence where a download lands. CJK characters are
 * kept — they are legal in file names, and removing them would leave the
 * researcher with unrecognisable files. Reserved device names are prefixed
 * because on Windows `CON.csv` is still the console device.
 */
export function exportFilenames(context: ExportContext): ExportFilenames {
  const base = `${slugify(context.projectTitle)}-${exportDate(context.exportedAt)}`;
  return {
    csv: `${base}.csv`,
    json: `${base}.json`,
    spssData: `${base}-spss.csv`,
    spssSyntax: `${base}-spss.sps`,
    excel: `${base}.xlsx`,
  };
}

function slugify(title: string, maxLength = 80): string {
  const slug = title
    .replace(ILLEGAL_FILENAME_CHARS, '-')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    // A run of dots can spell ".." (directory traversal) or a Windows hidden
    // file, so runs are folded away; a single dot (as in "V4.0") is kept.
    .replace(/\.{2,}/g, '-')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^[-.]+/, '')
    .replace(/[-.\s]+$/, '')
    .slice(0, maxLength)
    // Truncation can reintroduce a trailing dot, which Windows silently drops.
    .replace(/[-.\s]+$/, '');

  if (slug === '') return 'export';
  return WINDOWS_RESERVED_NAMES.has(slug.toUpperCase()) ? `_${slug}` : slug;
}

function exportDate(exportedAt: string): string {
  const parsed = new Date(exportedAt);
  // An unparseable timestamp must not abort a download that is otherwise fine,
  // so today's date is used and the true value is still reported in metadata.
  const iso = Number.isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString();
  return iso.slice(0, 10);
}

/* ------------------------------------------------------------------ */
/* Excel workbook                                                     */
/* ------------------------------------------------------------------ */

interface SheetContent {
  name: string;
  headers: string[];
  rows: (string | number | null)[][];
}

/**
 * Multi-sheet Excel workbook.
 *
 * Analysis sheets carry only what the caller supplied. A sheet with no results
 * is created anyway, with its header row and one honest note, so that a
 * downloaded workbook is never mistaken for a complete analysis and no number
 * in it is ever generated here.
 */
export async function toExcelBuffer(
  dataset: Dataset,
  context: ExportContext,
  extraSheets: ExportSheet[] = [],
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();

  const { headers, rows } = datasetToRows(dataset);
  const contents: SheetContent[] = [
    { name: RAW_DATA_SHEET, headers, rows },
    { name: DICTIONARY_SHEET, headers: DICTIONARY_HEADERS.slice(), rows: dictionarySheetRows(dataset, context).slice(1) },
    { name: CODEBOOK_SHEET, headers: CODEBOOK_HEADERS.slice(), rows: codebookRows(dataset).slice(1) },
    ...ANALYSIS_SHEETS.map((sheet) => ({
      name: sheet.name,
      headers: sheet.headers.slice(),
      rows: [[ANALYSIS_NOT_RUN_NOTE]],
    })),
  ];

  const extras = new Map<string, ExportSheet[]>();
  for (const sheet of extraSheets) {
    const key = sheetKey(sheet.name);
    const bucket = extras.get(key);
    if (bucket) bucket.push(sheet);
    else extras.set(key, [sheet]);
  }

  const usedNames = new Set<string>();
  for (const content of contents) {
    const supplied = extras.get(sheetKey(content.name));
    // Merge, never duplicate: a caller's real results replace the placeholder
    // in the sheet that already exists under that name.
    const merged = supplied ? mergeSections(content, supplied) : content;
    extras.delete(sheetKey(content.name));
    addSheet(workbook, merged, usedNames, {
      freeze: content.name === RAW_DATA_SHEET,
    });
  }

  // Unrecognised names were contributed on purpose, so they are appended rather
  // than dropped — but only after the required sheets, whose order callers rely
  // on.
  for (const bucket of extras.values()) {
    const merged = mergeSections(bucket[0]!, bucket.slice(1));
    addSheet(workbook, merged, usedNames, { freeze: false });
  }

  applyWorkbookProperties(workbook, context, dataset.n_respondents);

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer as ArrayBuffer);
}

/**
 * Combine several contributions for one sheet.
 *
 * Real results replace the placeholder content (the "not run yet" note, or the
 * built-in rows of a structural sheet): the caller's headers define the table,
 * because only the caller knows the shape of its own output. When a later
 * contribution uses a different header row, that header is written before its
 * data, so two different table shapes stay readable in one sheet instead of
 * being positionally misinterpreted.
 */
function mergeSections(primary: SheetContent, others: ExportSheet[]): SheetContent {
  const first = others[0];
  if (!first) return primary;

  const headers = first.headers.length > 0 ? first.headers.slice() : primary.headers.slice();
  const rows: (string | number | null)[][] = first.rows.slice();

  for (const section of others.slice(1)) {
    if (section.headers.length > 0 && section.headers.join('\u0000') !== headers.join('\u0000')) {
      rows.push(section.headers.slice());
    }
    rows.push(...section.rows);
  }

  return { name: primary.name, headers, rows };
}

function addSheet(
  workbook: Workbook,
  content: SheetContent,
  usedNames: Set<string>,
  options: { freeze: boolean },
): Worksheet {
  const worksheet = workbook.addWorksheet(uniqueSheetName(content.name, usedNames));

  if (content.headers.length > 0) {
    worksheet.addRow(content.headers).font = { bold: true };
  }
  for (const row of content.rows) worksheet.addRow(row);

  if (options.freeze) {
    // Header row and column A stay visible: the id column is how a reader keeps
    // track of which case a row belongs to once horizontal scrolling starts.
    worksheet.views = [{ state: 'frozen', xSplit: 1, ySplit: 1 }];
  }

  const widths = columnWidths(content);
  worksheet.columns = widths.map((width) => ({ width }));
  return worksheet;
}

/** Excel sheet names are capped at 31 characters and forbid `[]:*?/\`. */
function uniqueSheetName(name: string, usedNames: Set<string>): string {
  const cleaned = name
    .replace(EXCEL_ILLEGAL_SHEET_CHARS, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^'+|'+$/g, '')
    .trim()
    .slice(0, EXCEL_MAX_SHEET_NAME)
    .trim();
  const base = cleaned === '' ? 'Sheet' : cleaned;

  let candidate = base;
  let suffix = 1;
  while (usedNames.has(candidate.toLowerCase())) {
    suffix += 1;
    const tag = ` (${suffix})`;
    candidate = `${base.slice(0, EXCEL_MAX_SHEET_NAME - tag.length)}${tag}`;
  }
  usedNames.add(candidate.toLowerCase());
  return candidate;
}

function columnWidths(content: SheetContent): number[] {
  return content.headers.map((header, index) => {
    let width = textWidth(header) + 2;
    // Sampling keeps a large export fast; the first rows are representative
    // enough for a readable default width.
    for (const row of content.rows.slice(0, WIDTH_SAMPLE_ROWS)) {
      const value = row[index];
      if (value === null || value === undefined) continue;
      width = Math.max(width, textWidth(String(value)) + 2);
    }
    return Math.min(width, MAX_COLUMN_WIDTH);
  });
}

/** CJK glyphs occupy roughly two Latin cells, so they count twice. */
function textWidth(text: string): number {
  let width = 0;
  for (const character of text) {
    width += (character.codePointAt(0) ?? 0) > 0x2e80 ? 2 : 1;
  }
  return width;
}

function sheetKey(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/**
 * Workbook properties carry the export's context.
 *
 * No metadata sheet is added: callers and downstream readers assume the fixed
 * sheet order above, and file properties surface the same information in
 * Excel's own UI without disturbing it.
 */
function applyWorkbookProperties(
  workbook: Workbook,
  context: ExportContext,
  exportedRespondents: number,
): void {
  const created = new Date(context.exportedAt);
  const timestamp = Number.isNaN(created.getTime()) ? new Date() : created;
  const excluded = context.excludedNote ? `；${context.excludedNote}` : '';

  workbook.creator = GENERATOR;
  workbook.lastModifiedBy = GENERATOR;
  workbook.created = timestamp;
  workbook.modified = timestamp;
  workbook.title = context.projectTitle;
  workbook.subject = `${context.questionnaireTitle}（${context.questionnaireVersion}）`;
  workbook.category = 'Research data export';
  workbook.keywords = 'family education research;survey;codebook;raw data';
  workbook.description =
    `导出时间：${context.exportedAt}；收集样本 ${context.respondentsTotal} 份，` +
    `本次导出 ${exportedRespondents} 份${excluded}。${MISSING_VALUE_NOTE}`;
}
