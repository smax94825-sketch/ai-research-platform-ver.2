/**
 * Publish panel: validation, share link, QR code and version control.
 *
 * Publishing locks the instrument. The UI states that consequence before the
 * action, because it is the one irreversible step in the workflow — the survey
 * link and its QR code become the identity of a data-collection wave.
 */

import { useEffect, useState, type ReactNode } from 'react';
import type { Questionnaire } from '@ferp/shared';
import { Alert, Badge, Button, Card, CardHeader, Input } from '../ui';
import {
  api,
  ApiClientError,
  type LogicIssue,
  type PublishResult,
} from '../../lib/api';
import { formatDateTime, questionnaireStatusMeta } from '../../lib/format';

interface PublishPanelProps {
  questionnaire: Questionnaire;
  editable: boolean;
  lockReason: string | null;
  logicIssues: LogicIssue[];
  questionCount: number;
  onChanged: () => Promise<void>;
}

export function PublishPanel({
  questionnaire,
  editable,
  lockReason,
  logicIssues,
  questionCount,
  onChanged,
}: PublishPanelProps): ReactNode {
  const [result, setResult] = useState<PublishResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState<'stepper' | 'flat' | null>(null);

  const shareToken = result?.share_token ?? questionnaire.share_token;
  const shareUrl = result?.share_url ?? (shareToken ? `${window.location.origin}/research/${shareToken}` : null);
  /**
   * Second public layout: the whole instrument on one page. It is not a second
   * questionnaire — both URLs resolve the same share token, and a respondent who
   * switches between them continues the same session.
   */
  const singlePageUrl = shareUrl ? `${shareUrl}/all` : null;
  const meta = questionnaireStatusMeta(questionnaire.status);
  const errors = logicIssues.filter((issue) => issue.severity === 'error');

  useEffect(() => {
    setCopied(null);
  }, [shareToken]);

  async function publish(): Promise<void> {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const published = await api.questionnaires.publish(questionnaire.id);
      setResult(published);
      setNotice(
        published.questionnaire.status === 'published' && !published.warnings.length
          ? '问卷已发布。'
          : '问卷已发布，请查看下方的提示信息。',
      );
      await onChanged();
    } catch (err) {
      if (err instanceof ApiClientError) {
        const details = err.fieldErrors;
        setError(
          details.length > 0
            ? `${err.message} ${details.map((item) => item.message).join(' ')}`
            : err.message,
        );
      } else {
        setError('发布失败，请稍后重试。');
      }
    } finally {
      setBusy(false);
    }
  }

  async function newVersion(kind: 'minor' | 'major'): Promise<void> {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const created = await api.questionnaires.newVersion(questionnaire.id, kind);
      setNotice(`已创建新版本 ${created.version}，旧版本数据保持不变。`);
      setResult(null);
      await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '建立新版本失败。');
    } finally {
      setBusy(false);
    }
  }

  async function closeCollection(): Promise<void> {
    setBusy(true);
    setError(null);
    try {
      await api.questionnaires.close(questionnaire.id);
      setNotice('已关闭数据收集。题目与数据均保留，可随时查看或导出。');
      await onChanged();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '关闭收集失败。');
    } finally {
      setBusy(false);
    }
  }

  async function copyText(text: string | null, which: 'stepper' | 'flat'): Promise<void> {
    if (!text) return;
    setError(null);
    try {
      await navigator.clipboard.writeText(text);
      setCopied(which);
      window.setTimeout(() => setCopied(null), 2000);
    } catch {
      setError('无法访问剪贴板，请手动复制链接。');
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="space-y-4">
        <Card>
          <CardHeader
            title="发布状态"
            actions={<Badge tone={meta.tone}>{meta.label}</Badge>}
            description={`版本 ${questionnaire.version} · ${questionCount} 道题`}
          />
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-ink-500">发布状态</dt>
              <dd className="text-ink-900">{questionnaire.status === 'published' ? '已发布' : '未发布'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-500">编辑权限</dt>
              <dd className={editable ? 'text-emerald-700' : 'text-amber-700'}>
                {editable ? '可编辑' : '已锁定'}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-500">发布时间</dt>
              <dd className="text-ink-900">{formatDateTime(questionnaire.published_at)}</dd>
            </div>
          </dl>

          {lockReason && (
            <div className="mt-3">
              <Alert tone="warning" title="问卷已锁定">
                {lockReason}
              </Alert>
            </div>
          )}

          {questionCount === 0 && (
            <div className="mt-3">
              <Alert tone="danger" title="无法发布">
                问卷没有任何题目，请先添加题目或使用研究模板。
              </Alert>
            </div>
          )}

          {errors.length > 0 && (
            <div className="mt-3">
              <Alert tone="danger" title={`存在 ${errors.length} 处逻辑错误`}>
                <ul className="list-disc space-y-1 pl-4">
                  {errors.map((issue, index) => (
                    <li key={index}>
                      <span className="font-mono text-xs">{issue.questionCode}</span> {issue.message}
                    </li>
                  ))}
                </ul>
              </Alert>
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="操作" />
          <div className="space-y-3">
            {error && <Alert tone="danger">{error}</Alert>}
            {notice && <Alert tone="success">{notice}</Alert>}

            <Button
              variant="primary"
              className="w-full"
              disabled={questionCount === 0 || errors.length > 0}
              loading={busy && questionnaire.status !== 'published'}
              onClick={() => void publish()}
            >
              {questionnaire.status === 'published' ? '重新获取分享链接' : '发布问卷并生成分享链接'}
            </Button>

            <div className="flex gap-2">
              <Button className="flex-1" disabled={busy} onClick={() => void newVersion('minor')}>
                建立新版本（V1.1）
              </Button>
              <Button className="flex-1" disabled={busy} onClick={() => void newVersion('major')}>
                建立主版本（V2.0）
              </Button>
            </div>

            <Button
              variant="danger"
              className="w-full"
              disabled={busy || questionnaire.status !== 'published'}
              onClick={() => void closeCollection()}
            >
              关闭数据收集
            </Button>

            <p className="text-xs text-ink-500">
              发布后问卷将被锁定。修改题目必须建立新版本，以保证已收集数据与题目版本严格对应；
              建立新版本时系统会自动为旧版本生成不可变快照。
            </p>
          </div>
        </Card>
      </div>

      {/* Share ---------------------------------------------------------- */}
      <div className="space-y-4">
        <Card>
          <CardHeader
            title="分享与二维码"
            description="受访者无需注册即可填写。分享链接可用于微信、学校、社区等渠道。"
          />

          {!shareToken ? (
            <Alert tone="info" title="尚未生成分享链接">
              发布问卷后，系统会生成唯一的分享令牌与二维码。
            </Alert>
          ) : (
            <div className="space-y-4">
              <div>
                <span className="ferp-label">问卷链接（逐题模式）</span>
                <div className="flex gap-2">
                  <Input readOnly value={shareUrl ?? ''} />
                  <Button onClick={() => void copyText(shareUrl, 'stepper')}>
                    {copied === 'stepper' ? '已复制' : '复制'}
                  </Button>
                </div>
                <p className="mt-1 text-xs text-ink-500">每题一屏，适合手机端逐题作答。</p>
              </div>

              <div>
                <span className="ferp-label">问卷链接（整页模式）</span>
                <div className="flex gap-2">
                  <Input readOnly value={singlePageUrl ?? ''} />
                  <Button onClick={() => void copyText(singlePageUrl, 'flat')}>
                    {copied === 'flat' ? '已复制' : '复制'}
                  </Button>
                </div>
                <p className="mt-1 text-xs text-ink-500">
                  全部题目显示在一页，像纸质问卷一样一次答完，适合电脑端填写。
                </p>
              </div>

              <Alert tone="info" title="两种链接共用同一份作答">
                它们指向同一份问卷与同一个分享令牌；受访者在任一链接开始作答后，改换另一个链接会继续
                同一份作答，不会重复计入样本。
              </Alert>

              <div>
                <span className="ferp-label">渠道来源追踪</span>
                <p className="text-xs text-ink-500">
                  在任一链接后追加 <code className="rounded bg-ink-100 px-1">?source=</code> 即可区分样本来源：
                </p>
                <ul className="mt-2 flex flex-wrap gap-1">
                  {['xiaohongshu', 'wechat', 'school', 'community', 'offline'].map((source) => (
                    <li key={source}>
                      <button
                        type="button"
                        className="rounded border border-ink-200 px-2 py-0.5 text-xs text-ink-700 hover:border-brand-500 hover:text-brand-700"
                        onClick={() => {
                          void copyText(`${shareUrl}?source=${source}`, 'stepper');
                        }}
                      >
                        {source}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="ferp-label">二维码</span>
                <div className="inline-block rounded-md border border-ink-200 bg-white p-3">
                  <img
                    src={api.questionnaires.qrCodeUrl(shareToken, 'svg')}
                    alt="问卷二维码"
                    width={200}
                    height={200}
                    className="block"
                  />
                </div>
                <p className="mt-2 text-xs text-ink-500">
                  二维码由服务端生成，编码的即为上方「逐题模式」问卷链接，可直接用于印刷或屏幕展示；
                  如需发放整页模式，请复制上方整页模式链接。
                </p>
              </div>

              <Alert tone="info" title="数据与版本对应">
                <span className="font-mono text-xs">share_token: {shareToken}</span>
                <br />
                该令牌在本版本生命周期内保持不变；重新发布会返回同一个令牌，已印出的二维码不会失效。
              </Alert>
            </div>
          )}
        </Card>

        <Card>
          <CardHeader title="发布前检查清单" />
          <ul className="space-y-2 text-sm">
            <CheckItem ok={questionCount > 0} label={`问卷包含题目（${questionCount} 题）`} />
            <CheckItem ok={errors.length === 0} label={`逻辑校验通过（${errors.length} 处错误）`} />
            <CheckItem ok label="匿名调查，不收集姓名 / 手机号 / 身份证 / 住址" />
            <CheckItem ok label="敏感题允许拒答，且拒答单独编码为缺失" />
            <CheckItem ok label="发布后自动生成不可变快照，保证版本可追溯" />
          </ul>
        </Card>
      </div>
    </div>
  );
}

function CheckItem({ ok, label }: { ok: boolean; label: string }): ReactNode {
  return (
    <li className="flex items-start gap-2">
      <span className={ok ? 'text-emerald-600' : 'text-red-600'}>{ok ? '✓' : '✕'}</span>
      <span className="text-ink-700">{label}</span>
    </li>
  );
}
