/**
 * Runtime configuration.
 *
 * Configuration is read from the environment once and passed around
 * explicitly (rather than imported as a mutable global) so tests can construct
 * an isolated app with their own database file and JWT secret.
 */

import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';
import { dirname, resolve } from 'node:path';

/**
 * The minimal HTTP-client surface the AI service needs.
 *
 * Declared as an injectable seam rather than imported directly: the test suite
 * passes a deterministic fake so AI behaviour (including every failure mode) is
 * exercised offline, and `loadConfig` supplies the platform's real `fetch`.
 */
export type FetchLike = (url: string, init: RequestInit) => Promise<Response>;

/**
 * Configuration of the DeepSeek-backed interpretation layer.
 *
 * `apiKey` is nullable on purpose: the platform must run — and remain honest —
 * without a key, so the absence of a key is a first-class state rather than a
 * boot failure. Defaults target the official API and its current chat model.
 */
export interface AiConfig {
  /** `null` when DEEPSEEK_API_KEY is unset; the AI layer then runs degraded. */
  apiKey: string | null;
  baseUrl: string;
  model: string;
  /** Request timeout; a hung provider must never hang a researcher's request. */
  timeoutMs: number;
  /** Upper bound on generated tokens; a truncated reply is reported, not hidden. */
  maxOutputTokens: number;
  temperature: number;
  /** Prompt template version, stored with every interaction for auditability. */
  promptVersion: string;
  /** The real HTTP client in production; a fake in tests. */
  fetchImpl: FetchLike;
}

export interface Config {
  env: 'development' | 'test' | 'production';
  host: string;
  port: number;
  /** Absolute path to the SQLite file, or ':memory:' for ephemeral runs. */
  databasePath: string;
  jwtSecret: string;
  /** Access-token lifetime in seconds. */
  jwtExpiresIn: number;
  corsOrigins: string[];
  /** Public base URL used when building share links and QR payloads. */
  publicBaseUrl: string;
  /** Warn (dev) or refuse to boot (production) when the secret is ephemeral. */
  usingEphemeralSecret: boolean;
  /** AI interpretation settings, including the injectable HTTP client. */
  ai: AiConfig;
}

/** Repo-relative default: <packages/server>/data/ferp.db */
function defaultDatabasePath(): string {
  const here = dirname(fileURLToPath(import.meta.url));
  // Compiled layout is dist/src/config.js, so the package root is two levels up.
  return resolve(here, '..', '..', 'data', 'ferp.db');
}

function parsePort(value: string | undefined, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 && parsed < 65536 ? parsed : fallback;
}

/** Default model for the interpretation layer (DeepSeek's current chat model). */
export const DEFAULT_AI_MODEL = 'deepseek-chat';
export const DEFAULT_AI_BASE_URL = 'https://api.deepseek.com';

/** Parse an arbitrary positive integer setting, falling back on garbage input. */
function parsePositiveInt(value: string | undefined, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function parseAiConfig(env: NodeJS.ProcessEnv, fetchImpl: FetchLike): AiConfig {
  const apiKey = env.DEEPSEEK_API_KEY?.trim();
  const baseUrl = (env.DEEPSEEK_BASE_URL?.trim() || DEFAULT_AI_BASE_URL).replace(/\/+$/, '');
  const model = env.DEEPSEEK_MODEL?.trim() || DEFAULT_AI_MODEL;
  return {
    // An empty string is treated as "not configured" rather than as a key that
    // will fail later with a confusing 401 from the provider.
    apiKey: apiKey && apiKey.length > 0 ? apiKey : null,
    baseUrl,
    model,
    timeoutMs: parsePositiveInt(env.DEEPSEEK_TIMEOUT_MS, 60_000),
    maxOutputTokens: parsePositiveInt(env.DEEPSEEK_MAX_TOKENS, 2048),
    temperature: 0.2,
    promptVersion: '1.0.0',
    fetchImpl,
  };
}

export function loadConfig(
  env: NodeJS.ProcessEnv = process.env,
  overrides: { fetchImpl?: FetchLike } = {},
): Config {
  const nodeEnv = env.NODE_ENV;
  const mode: Config['env'] =
    nodeEnv === 'production' ? 'production' : nodeEnv === 'test' ? 'test' : 'development';

  const providedSecret = env.JWT_SECRET?.trim();
  if (mode === 'production' && (!providedSecret || providedSecret.length < 32)) {
    throw new Error(
      'JWT_SECRET must be set to at least 32 characters in production. ' +
        'Refusing to start with an ephemeral or weak signing key.',
    );
  }

  const usingEphemeralSecret = !providedSecret;
  const jwtSecret = providedSecret ?? randomBytes(32).toString('hex');

  const corsOrigins = (env.CORS_ORIGINS ?? 'http://localhost:5173,http://127.0.0.1:5173')
    .split(',')
    .map((origin) => origin.trim())
    .filter((origin) => origin.length > 0);

  return {
    env: mode,
    host: env.HOST ?? '127.0.0.1',
    port: parsePort(env.PORT, 4000),
    databasePath: env.DATABASE_PATH ?? (mode === 'test' ? ':memory:' : defaultDatabasePath()),
    jwtSecret,
    jwtExpiresIn: parsePort(env.JWT_EXPIRES_IN, 60 * 60 * 12),
    corsOrigins,
    publicBaseUrl: env.PUBLIC_BASE_URL ?? 'http://localhost:5173',
    usingEphemeralSecret,
    // Wrapped rather than referenced so the global is resolved at call time and
    // never invoked as a detached method.
    ai: parseAiConfig(env, overrides.fetchImpl ?? ((url, init) => globalThis.fetch(url, init))),
  };
}
