﻿/**
 * Correlation matrix heatmap.
 *
 * Three encodings carry the same information so that no reader depends on any
 * single one:
 *   1. cell colour — diverging blue (negative) → white (0) → red (positive),
 *   2. the r value printed in every cell,
 *   3. the conventional significance marker (`*` `**` `***`) derived from the
 *      p values the engine computed for that same cell.
 *
 * The method actually used for each pair (Pearson vs Spearman) is printed in the
 * cell as well, because the engine mixes methods across pairs whenever an
 * ordered variable is involved.
 */

import type { ReactNode } from 'react';
import { formatStat, significanceMark } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg, divergingFill } from './primitives';

export interface HeatmapProps {
  /** Axis codes, in row/column order; also used as the row labels. */
  variables: string[];
  /** r values; `matrix[i][j]` belongs to `variables[i]` × `variables[j]`. */
  matrix: (number | null)[][];
  /** Two-tailed p values, same layout; drives the significance markers. */
  pValues?: (number | null)[][];
  /** Method per cell ('pearson' | 'spearman'), rendered as a P/S marker. */
  methods?: (string | null)[][];
  /** Verbose labels, listed under the chart so the codes on the axes are decodable. */
  labels?: string[];
  emptyText?: string;
  caption?: ReactNode;
}

const CELL_WIDTH = 52;
const CELL_HEIGHT = 34;
const ROW_LABEL_WIDTH = 108;
const COL_LABEL_HEIGHT = 22;
const FOOTER_HEIGHT = 14;

function methodMark(method: string | null | undefined): string {
  if (!method) return '';
  return method === 'spearman' ? 'S' : method === 'pearson' ? 'P' : method.slice(0, 1).toUpperCase();
}

export function Heatmap({
  variables,
  matrix,
  pValues,
  methods,
  labels,
  emptyText = '暂无可展示的相关矩阵。',
  caption,
}: HeatmapProps): ReactNode {
  if (variables.length === 0 || matrix.length === 0) return <ChartEmpty text={emptyText} />;

  const size = variables.length;
  const width = ROW_LABEL_WIDTH + size * CELL_WIDTH;
  const height = COL_LABEL_HEIGHT + size * CELL_HEIGHT + FOOTER_HEIGHT;
  const hasMethods = methods !== undefined;

  return (
    <div>
      <ResponsiveSvg width={width} height={height} label="相关系数矩阵热力图">
        {variables.map((code, column) => (
          <text
            key={`col-${code}`}
            x={ROW_LABEL_WIDTH + column * CELL_WIDTH + CELL_WIDTH / 2}
            y={COL_LABEL_HEIGHT - 7}
            fontSize={FONT}
            fill="#444d5e"
            textAnchor="middle"
          >
            {code}
          </text>
        ))}

        {variables.map((code, row) => (
          <text
            key={`row-${code}`}
            x={ROW_LABEL_WIDTH - 8}
            y={COL_LABEL_HEIGHT + row * CELL_HEIGHT + CELL_HEIGHT / 2 + 4}
            fontSize={FONT}
            fill="#444d5e"
            textAnchor="end"
          >
            {code}
          </text>
        ))}

        {variables.map((code, row) =>
          variables.map((_, column) => {
            const value = matrix[row]?.[column] ?? null;
            const p = pValues?.[row]?.[column] ?? null;
            const isDiagonal = row === column;
            const x = ROW_LABEL_WIDTH + column * CELL_WIDTH;
            const y = COL_LABEL_HEIGHT + row * CELL_HEIGHT;
            const { fill, text } = isDiagonal
              ? { fill: '#eceef2', text: '#535f74' }
              : value === null
                ? { fill: '#f6f7f9', text: '#68778e' }
                : divergingFill(value, 1);
            const marker = isDiagonal ? '' : significanceMark(p);
            return (
              <g key={`${code}-${variables[column] ?? column}`}>
                <rect x={x} y={y} width={CELL_WIDTH} height={CELL_HEIGHT} fill={fill} stroke="#ffffff" strokeWidth={1} />
                <text
                  x={x + CELL_WIDTH / 2}
                  y={y + CELL_HEIGHT / 2 + (hasMethods ? 0 : 4)}
                  fontSize={FONT}
                  fill={text}
                  textAnchor="middle"
                >
                  {value === null ? '—' : `${formatStat(value, 2)}${marker}`}
                </text>
                {hasMethods && (
                  <text
                    x={x + CELL_WIDTH / 2}
                    y={y + CELL_HEIGHT - 5}
                    fontSize={FONT_SMALL}
                    fill={text}
                    textAnchor="middle"
                  >
                    {methodMark(methods?.[row]?.[column])}
                  </text>
                )}
              </g>
            );
          }),
        )}
      </ResponsiveSvg>

      {labels && labels.length > 0 && (
        <ul className="mt-3 grid grid-cols-1 gap-x-4 gap-y-1 text-xs text-ink-600 sm:grid-cols-2">
          {variables.map((code, index) => (
            <li key={code} className="flex gap-1.5">
              <span className="font-medium text-ink-800">{code}</span>
              <span className="min-w-0 truncate" title={labels[index] ?? code}>
                {labels[index] ?? ''}
              </span>
            </li>
          ))}
        </ul>
      )}

      <ChartCaption>
        {caption ?? (
          <>
            显著性标记：<span className="font-medium">* p &lt; 0.05</span> ·
            <span className="font-medium"> ** p &lt; 0.01</span> ·
            <span className="font-medium"> *** p &lt; 0.001</span>
            （双侧检验，未做多重比较校正；对角线为变量与自身的相关，不标注显著性）。
            {hasMethods && ' 单元格下方字母为所用方法：P = Pearson 积矩相关，S = Spearman 等级相关。'}
          </>
        )}
      </ChartCaption>
    </div>
  );
}
