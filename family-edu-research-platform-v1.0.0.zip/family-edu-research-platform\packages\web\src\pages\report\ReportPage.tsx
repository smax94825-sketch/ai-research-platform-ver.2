/**
 * Research report (PHASE 8).
 *
 * The report is the artefact a researcher submits, so the page's single most
 * important job is to keep a gap visible: a section the platform could not fill
 * is rendered as an explicit Chinese notice carrying the API's own
 * `unavailable_reason`, never as an empty section and never with plausible
 * prose. Two of the 23 sections (文献与理论依据, 参考文献与附录) are structurally
 * unavailable because the platform runs offline with no bibliographic source,
 * and a report that invented references would be worse than one that says so.
 *
 * The Markdown body is rendered by a small local renderer (`components/Markdown`)
 * so no dependency is added, and the same bytes are available for download and
 * for copying in full.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Markdown } from '../../components/Markdown';
import { Alert, Badge, Button, Card, CardHeader, LoadingBlock, StatCard } from '../../components/ui';
import { formatDateTime, formatNumber } from '../../lib/format';
import { api, ApiClientError, type ReportSection, type ResearchReport } from '../../lib/api';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from '../analysis/shared';

function SectionBlock({ section }: { section: ReportSection }): ReactNode {
  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="flex items-baseline gap-2 text-base font-semibold text-ink-900">
          <span className="tabular-nums text-ink-500">{`${section.index}.`}</span>
          {section.title}
        </h2>
        <Badge tone={section.available ? 'success' : 'warning'}>
          {section.available ? '由数据生成' : '本平台无法生成，需研究者补充'}
        </Badge>
      </div>

      {!section.available && (
        <div className="mb-3">
          <Alert tone="warning" title="本节未生成内容">
            <p>{section.unavailable_reason ?? '本节当前不可用。'}</p>
            <p className="mt-1">
              平台不会用示例文字或估计值填充本节：缺少的内容必须由研究者依据自己核验过的材料补充，
              在此之前本节保持为空并说明原因。
            </p>
          </Alert>
        </div>
      )}

      <div className={section.available ? '' : 'rounded-md border border-ink-200 bg-ink-50 px-3.5 py-3'}>
        {!section.available && (
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-ink-500">
            平台对缺失内容的说明（原文）
          </p>
        )}
        <Markdown text={section.body} />
      </div>

      {section.evidence.length > 0 && (
        <details className="mt-3 rounded-md border border-ink-200 px-3.5 py-2.5">
          <summary className="cursor-pointer text-xs font-medium text-ink-700">
            {`本节引用的结果包位置（${section.evidence.length} 条，可在分析页核对）`}
          </summary>
          <ul className="mt-2 space-y-1">
            {section.evidence.map((item, index) => (
              <li
                key={`${item.path}-${index}`}
                className="flex flex-wrap items-baseline gap-2 text-xs text-ink-600"
              >
                <code className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[11px] text-ink-700">
                  {item.path}
                </code>
                <span className="text-ink-400">=</span>
                <span className="break-all font-mono text-[11px] text-ink-900">{item.value}</span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </Card>
  );
}

export function ReportPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [report, setReport] = useState<ResearchReport | null>(null);
  /** The API's own Chinese message for the "no analysis bundle yet" 400. */
  const [noBundleMessage, setNoBundleMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [downloadedAs, setDownloadedAs] = useState<string | null>(null);
  const [copyState, setCopyState] = useState<'idle' | 'copied' | 'manual'>('idle');
  const [showFullText, setShowFullText] = useState(false);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    setNoBundleMessage(null);
    try {
      setReport(await api.report.get(projectId));
    } catch (err) {
      setReport(null);
      // A 400 is the documented "no analysis bundle yet" refusal; its message
      // says which button to press, so it is shown instead of a generic error.
      if (err instanceof ApiClientError && err.status === 400) setNoBundleMessage(err.message);
      else setError(err instanceof ApiClientError ? err.message : '无法生成研究报告。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleDownload(): Promise<void> {
    if (!projectId) return;
    setDownloadError(null);
    try {
      const file = await api.report.download(projectId);
      setDownloadedAs(file.filename);
      if (!file.started && file.note) setDownloadError(file.note);
    } catch (err) {
      setDownloadError(err instanceof ApiClientError ? err.message : '下载 Markdown 失败。');
    }
  }

  async function handleCopy(): Promise<void> {
    if (!report) return;
    const clipboard = typeof navigator === 'undefined' ? undefined : navigator.clipboard;
    if (!clipboard || typeof clipboard.writeText !== 'function') {
      // No clipboard API (or a denied one): the full text is shown for manual
      // copying rather than silently claiming the copy succeeded.
      setCopyState('manual');
      setShowFullText(true);
      return;
    }
    try {
      await clipboard.writeText(report.markdown);
      setCopyState('copied');
    } catch {
      setCopyState('manual');
      setShowFullText(true);
    }
  }

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-4">
        <AnalysisPageHeader
          title="Research Reports"
          subtitle="研究报告：23 节固定顺序，逐节给出内容与所引用的结果包位置；无法生成的小节明确说明原因。"
          state={state}
          actions={
            report ? (
              <>
                <Button variant="secondary" onClick={() => void handleCopy()}>
                  复制全文
                </Button>
                <Button variant="primary" onClick={() => void handleDownload()}>
                  下载 Markdown
                </Button>
              </>
            ) : undefined
          }
        />

        {error && <ErrorNotice message={error} />}

        {noBundleMessage && (
          <Alert tone="warning" title="尚未运行完整统计分析，无法生成研究报告">
            <p>{noBundleMessage}</p>
            <p className="mt-3">
              <Link to={`/analysis?project=${projectId}`}>
                <Button variant="primary">前往统计分析并运行全部分析</Button>
              </Link>
            </p>
          </Alert>
        )}

        {loading && !report && !noBundleMessage ? (
          <LoadingBlock label="正在生成研究报告…" />
        ) : !report ? null : (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard
                label="章节总数"
                value={formatNumber(report.section_count)}
                hint="固定顺序，不因数据缺失而删节"
              />
              <StatCard
                label="由数据生成"
                value={formatNumber(report.available_sections)}
                tone="success"
                hint="正文数字全部取自结果包"
              />
              <StatCard
                label="需研究者补充"
                value={formatNumber(report.unavailable_sections)}
                tone="warning"
                hint="平台不生成、不猜测这些内容"
              />
              <StatCard label="正文字数" value={formatNumber(report.word_count)} hint="按中文字符与英文词计" />
            </div>

            <Card>
              <CardHeader
                title={report.project_title}
                description={`问卷：${report.questionnaire_title ?? '（未登记问卷）'} · 统计引擎 ${report.engine_version}`}
              />
              <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">报告生成时间</dt>
                  <dd className="mt-1 text-sm text-ink-800">{formatDateTime(report.generated_at)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">结果包生成时间</dt>
                  <dd className="mt-1 text-sm text-ink-800">{formatDateTime(report.analyser_generated_at)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">下载文件名</dt>
                  <dd className="mt-1 break-all font-mono text-xs text-ink-700">
                    {downloadedAs ?? '点击「下载 Markdown」后显示服务端返回的文件名'}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">复制状态</dt>
                  <dd className="mt-1 text-sm text-ink-800">
                    {copyState === 'copied'
                      ? '已复制全文到剪贴板'
                      : copyState === 'manual'
                        ? '浏览器不允许脚本写剪贴板，已展开全文供手动复制'
                        : '尚未复制'}
                  </dd>
                </div>
              </dl>

              {downloadError && (
                <div className="mt-3">
                  <ErrorNotice message={downloadError} />
                </div>
              )}

              {showFullText && (
                <textarea
                  readOnly
                  aria-label="报告 Markdown 全文"
                  className="ferp-input mt-3 h-64 w-full font-mono text-xs"
                  value={report.markdown}
                />
              )}
            </Card>

            {report.caveats.length > 0 && (
              <MethodNote title="结果包解读前提（原文，引用本报告结论时必须同时引用）">
                <ol className="list-decimal space-y-1 pl-5">
                  {report.caveats.map((caveat, index) => (
                    <li key={`${index}-${caveat.slice(0, 24)}`}>{caveat}</li>
                  ))}
                </ol>
              </MethodNote>
            )}

            {report.sections
              .slice()
              .sort((left, right) => left.index - right.index)
              .map((section) => (
                <SectionBlock key={section.key} section={section} />
              ))}
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
