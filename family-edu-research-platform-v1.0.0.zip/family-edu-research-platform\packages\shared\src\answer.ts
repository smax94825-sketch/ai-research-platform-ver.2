/**
 * Answer normalisation and validation.
 *
 * Shared by the respondent client (instant feedback) and the server
 * (authoritative check), so a stored answer can never disagree with what the
 * questionnaire declares. Anything that cannot be normalised is rejected rather
 * than coerced: silently turning "7" into a valid option code would corrupt the
 * dataset in a way no later analysis could detect.
 */

import type { Question, QuestionOption } from './types.js';
import { findOption } from './scoring.js';
import type { AnswerValue } from './values.js';

export interface AnswerAccepted {
  ok: true;
  /** Canonical stored form, or null when the answer was cleared. */
  value: AnswerValue;
  /** True when the respondent explicitly declined a sensitive item. */
  sensitiveRefusal: boolean;
}

export interface AnswerRejected {
  ok: false;
  errors: string[];
}

export type AnswerValidation = AnswerAccepted | AnswerRejected;

/** True when the value carries no information (treated as "not answered"). */
export function isEmptyAnswer(value: unknown): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string') return value.trim() === '';
  if (Array.isArray(value)) return value.length === 0;
  if (typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).every(
      (item) => item === null || item === undefined || String(item).trim() === '',
    );
  }
  return false;
}

function optionCodes(choices: QuestionOption[] | undefined): Set<string> {
  return new Set((choices ?? []).map((choice) => String(choice.value)));
}

/**
 * Validate and canonicalise one answer.
 *
 * `question.options` is the authority: option codes, matrix rows/columns, number
 * bounds and text limits all come from the instrument that was published.
 */
export function normalizeAnswer(question: Question, raw: unknown): AnswerValidation {
  if (question.question_type === 'page_break') {
    return { ok: false, errors: ['分页题为结构性题目，不接受作答。'] };
  }

  if (isEmptyAnswer(raw)) {
    return { ok: true, value: null, sensitiveRefusal: false };
  }

  const choices = question.options.choices ?? [];

  switch (question.question_type) {
    case 'single':
    case 'dropdown':
    case 'likert':
    case 'knowledge_test': {
      const code = typeof raw === 'string' || typeof raw === 'number' ? String(raw) : null;
      if (code === null) {
        return { ok: false, errors: [`题型 ${question.question_type} 需要单个选项代码。`] };
      }
      const option = findOption(choices, code);
      if (!option) {
        return { ok: false, errors: [`选项代码 ${code} 不属于该题。`] };
      }
      return { ok: true, value: code, sensitiveRefusal: option.sensitiveNonResponse === true };
    }

    case 'multiple': {
      if (!Array.isArray(raw)) {
        return { ok: false, errors: ['多选题的作答必须是选项代码数组。'] };
      }
      const valid = optionCodes(choices);
      const unique: string[] = [];
      for (const item of raw) {
        const code = String(item);
        if (!valid.has(code)) {
          return { ok: false, errors: [`选项代码 ${code} 不属于该题。`] };
        }
        if (!unique.includes(code)) unique.push(code);
      }
      if (unique.length === 0) return { ok: true, value: null, sensitiveRefusal: false };

      const exclusiveSelected = unique.filter(
        (code) => findOption(choices, code)?.exclusive === true,
      );
      if (exclusiveSelected.length > 0 && unique.length > 1) {
        return {
          ok: false,
          errors: ['「以上都不知道」等互斥选项不能与其他选项同时选择。'],
        };
      }
      const sensitiveRefusal = unique.some(
        (code) => findOption(choices, code)?.sensitiveNonResponse === true,
      );
      return { ok: true, value: unique, sensitiveRefusal };
    }

    case 'ranking': {
      if (!Array.isArray(raw)) {
        return { ok: false, errors: ['排序题的作答必须是按次序排列的选项代码数组。'] };
      }
      const valid = optionCodes(choices);
      const unique: string[] = [];
      for (const item of raw) {
        const code = String(item);
        if (!valid.has(code)) {
          return { ok: false, errors: [`选项代码 ${code} 不属于该题。`] };
        }
        if (unique.includes(code)) {
          return { ok: false, errors: [`排序题中选项 ${code} 重复出现。`] };
        }
        unique.push(code);
      }
      if (unique.length === 0) return { ok: true, value: null, sensitiveRefusal: false };
      if (unique.length > choices.length) {
        return { ok: false, errors: ['排序项数超过该题可排序的选项数量。'] };
      }
      return { ok: true, value: unique, sensitiveRefusal: false };
    }

    case 'matrix': {
      const matrix = question.options.matrix;
      if (!matrix) return { ok: false, errors: ['该矩阵题缺少行列定义。'] };
      if (typeof raw !== 'object' || Array.isArray(raw)) {
        return { ok: false, errors: ['矩阵题的作答必须是行代码到列代码的映射。'] };
      }
      const rowCodes = new Set(matrix.rows.map((row) => String(row.value)));
      const columnCodes = optionCodes(matrix.columns);
      const normalized: Record<string, string> = {};
      let sensitiveRefusal = false;

      for (const [rowCode, columnValue] of Object.entries(raw as Record<string, unknown>)) {
        if (!rowCodes.has(String(rowCode))) {
          return { ok: false, errors: [`行代码 ${rowCode} 不属于该矩阵题。`] };
        }
        if (columnValue === null || columnValue === undefined || String(columnValue).trim() === '') {
          continue;
        }
        const code = String(columnValue);
        if (!columnCodes.has(code)) {
          return { ok: false, errors: [`列代码 ${code} 不属于该矩阵题。`] };
        }
        if (findOption(matrix.columns, code)?.sensitiveNonResponse === true) {
          sensitiveRefusal = true;
          continue;
        }
        normalized[String(rowCode)] = code;
      }

      if (Object.keys(normalized).length === 0) {
        return { ok: true, value: null, sensitiveRefusal };
      }
      const minimumRows = matrix.rows.length;
      if (question.required && Object.keys(normalized).length < minimumRows) {
        return {
          ok: false,
          errors: [`本题为必答矩阵题，需要完成全部 ${minimumRows} 行。`],
        };
      }
      return { ok: true, value: normalized, sensitiveRefusal };
    }

    case 'text':
    case 'textarea': {
      if (typeof raw !== 'string') {
        return { ok: false, errors: ['文本题需要字符串作答。'] };
      }
      const maxLength = question.options.maxLength;
      if (maxLength !== undefined && raw.length > maxLength) {
        return { ok: false, errors: [`文本长度超过上限 ${maxLength} 个字符。`] };
      }
      return { ok: true, value: raw, sensitiveRefusal: false };
    }

    case 'number': {
      const value = typeof raw === 'number' ? raw : Number(String(raw));
      if (!Number.isFinite(value)) {
        return { ok: false, errors: ['数字题需要数值作答。'] };
      }
      const { min, max } = question.options;
      if (min !== undefined && value < min) {
        return { ok: false, errors: [`数值小于允许的最小值 ${min}。`] };
      }
      if (max !== undefined && value > max) {
        return { ok: false, errors: [`数值大于允许的最大值 ${max}。`] };
      }
      return { ok: true, value, sensitiveRefusal: false };
    }

    case 'date': {
      if (typeof raw !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
        return { ok: false, errors: ['日期题需要 YYYY-MM-DD 格式。'] };
      }
      const parsed = new Date(`${raw}T00:00:00Z`);
      if (Number.isNaN(parsed.getTime())) {
        return { ok: false, errors: [`日期 ${raw} 无效。`] };
      }
      return { ok: true, value: raw, sensitiveRefusal: false };
    }

    default:
      return { ok: false, errors: [`未知题型：${String(question.question_type)}`] };
  }
}

/* ------------------------------------------------------------------ */
/* Display                                                            */
/* ------------------------------------------------------------------ */

function labelOf(choices: QuestionOption[] | undefined, code: string): string {
  return findOption(choices, code)?.label ?? code;
}

/**
 * Render a stored answer for the sample-detail view.
 * Sensitive refusals are labelled explicitly so a reader never mistakes them
 * for a substantive category.
 */
export function describeAnswer(question: Question, answer: unknown): string {
  if (isEmptyAnswer(answer)) return '（未作答）';

  switch (question.question_type) {
    case 'single':
    case 'dropdown':
    case 'likert':
    case 'knowledge_test': {
      const code = String(answer);
      const option = findOption(question.options.choices, code);
      if (!option) return code;
      return option.sensitiveNonResponse ? `${option.label}（敏感拒答，计为缺失）` : option.label;
    }

    case 'multiple': {
      const codes = Array.isArray(answer) ? answer.map(String) : [String(answer)];
      return codes.map((code) => labelOf(question.options.choices, code)).join('、');
    }

    case 'ranking': {
      const codes = Array.isArray(answer) ? answer.map(String) : [String(answer)];
      return codes
        .map((code, index) => `${index + 1}. ${labelOf(question.options.choices, code)}`)
        .join(' → ');
    }

    case 'matrix': {
      const matrix = question.options.matrix;
      const map = (answer ?? {}) as Record<string, string>;
      return Object.entries(map)
        .map(([rowCode, columnCode]) => {
          const row = matrix?.rows.find((item) => String(item.value) === rowCode);
          return `${row?.label ?? rowCode}：${labelOf(matrix?.columns, String(columnCode))}`;
        })
        .join('；');
    }

    case 'number':
      return String(answer);

    case 'text':
    case 'textarea':
    case 'date':
      return String(answer);

    default:
      return String(answer);
  }
}

/** True when the question currently holds an explicit sensitive refusal. */
export function isSensitiveRefusalAnswer(question: Question, answer: unknown): boolean {
  const result = normalizeAnswer(question, answer);
  return result.ok && result.sensitiveRefusal;
}
