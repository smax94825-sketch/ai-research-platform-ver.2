/**
 * Shared primitives for the hand-written SVG charts.
 *
 * Every chart draws into a FIXED viewBox coordinate system and is then scaled
 * as one unit by the browser. That is what keeps labels from colliding at
 * narrow widths: the drawing is never re-laid-out at a smaller size, it is only
 * scaled down proportionally, so relative positions (and therefore the gaps
 * between labels) are preserved exactly. A minimum width keeps the type
 * legible; below it the container scrolls horizontally instead of shrinking the
 * chart into an unreadable smear.
 *
 * The charts are also deliberately mouse-optional: every number that matters is
 * rendered as real `<text>` inside the SVG, so it is readable without hovering
 * and assertable in a DOM test.
 */

import type { ReactNode } from 'react';

/** Font sizes in viewBox units. */
export const FONT = 11;
export const FONT_SMALL = 9.5;
export const FONT_TITLE = 12;

export interface ResponsiveSvgProps {
  /** viewBox width in chart units. */
  width: number;
  /** viewBox height in chart units. */
  height: number;
  /** Accessible description; the chart's subject, not a repeat of every number. */
  label: string;
  children: ReactNode;
}

/**
 * Scrollable, proportionally-scaled SVG frame.
 *
 * `height: auto` plus the viewBox makes the browser derive the aspect ratio, so
 * the chart never distorts.
 */
export function ResponsiveSvg({ width, height, label, children }: ResponsiveSvgProps): ReactNode {
  return (
    <div className="w-full overflow-x-auto">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label={label}
        preserveAspectRatio="xMinYMin meet"
        style={{
          width: '100%',
          maxWidth: width,
          minWidth: Math.min(width, 320),
          height: 'auto',
          display: 'block',
        }}
      >
        {children}
      </svg>
    </div>
  );
}

/** The one shared "there is nothing to draw" state. */
export function ChartEmpty({ text }: { text: string }): ReactNode {
  return <p className="py-6 text-center text-sm text-ink-400">{text}</p>;
}

/** A short caption under a chart, used for units, criteria and caveats. */
export function ChartCaption({ children }: { children: ReactNode }): ReactNode {
  return <p className="mt-2 text-xs leading-relaxed text-ink-500">{children}</p>;
}

const NEGATIVE_POLE: [number, number, number] = [29, 66, 178];
const POSITIVE_POLE: [number, number, number] = [190, 34, 44];
const NEUTRAL: [number, number, number] = [246, 247, 249];

/**
 * Diverging fill for a signed statistic (a correlation, a standardised β).
 *
 * Colour is never the only cue: the numeric value is printed in the same cell,
 * which is what makes the matrix readable in greyscale and to a colour-blind
 * reader.
 */
export function divergingFill(value: number, maxAbs = 1): { fill: string; text: string } {
  const ceiling = Math.abs(maxAbs) > 0 ? Math.abs(maxAbs) : 1;
  const strength = Math.min(1, Math.abs(value) / ceiling);
  const pole = value < 0 ? NEGATIVE_POLE : POSITIVE_POLE;
  const channels = NEUTRAL.map((channel, index) =>
    Math.round(channel + (pole[index]! - channel) * strength),
  );
  return {
    fill: `rgb(${channels[0]}, ${channels[1]}, ${channels[2]})`,
    text: strength > 0.55 ? '#ffffff' : '#333945',
  };
}

/** Axis ticks on "nice" round numbers within [min, max]. */
export function axisTicks(min: number, max: number, count = 4): number[] {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return [];
  if (min === max) return [min];
  const rawStep = (max - min) / Math.max(1, count);
  const magnitude = 10 ** Math.floor(Math.log10(rawStep));
  const normalized = rawStep / magnitude;
  const step = (normalized >= 5 ? 5 : normalized >= 2 ? 2 : normalized >= 1 ? 1 : 0.5) * magnitude;
  const ticks: number[] = [];
  for (let value = Math.ceil(min / step) * step; value <= max + step * 1e-6; value += step) {
    ticks.push(Number(value.toFixed(10)));
    if (ticks.length >= 24) break;
  }
  return ticks;
}
