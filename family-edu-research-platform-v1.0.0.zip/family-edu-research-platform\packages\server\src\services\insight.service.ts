/**
 * Competition (entrepreneurship) insight service — PHASE 9.
 *
 * Turns a finished statistical analysis into a business-facing view of the same
 * data without letting the business framing outrun the evidence. Three rules are
 * enforced here rather than left to whoever writes the pitch deck:
 *
 *  - **The bundle is the only source of numbers.** Every figure a block quotes is
 *    read from the analysis bundle, and the block records it in `evidence` as an
 *    exact path plus the value found there. The statistical engine computed it;
 *    this layer never recomputes it, never rounds it differently and never
 *    invents one. When a number does not exist in the bundle it is absent from the
 *    report, and the block that needed it says so in Chinese.
 *  - **Missing input is a first-class outcome, not a zero.** Every block carries
 *    `available`, `reason` and `inputs`, so a competition report built on an
 *    instrument that never asked about willingness to pay reads 「本区块不可用」
 *    instead of showing a plausible-looking number.
 *  - **Bounded synthesis.** The market-opportunity block is labelled an inference
 *    from this sample. It reports the drivers that were actually significant,
 *    lists what was not, and refuses outright to produce a market size in
 *    currency, because nothing in the data supports one.
 *
 * `dataset` (the numeric dataset behind the bundle) and `summary` (the live sample
 * summary) are inputs too, but they are used only to answer two questions the
 * bundle alone cannot: what did the instrument actually ask, and is the bundle
 * still current? They never produce a statistic.
 *
 * ## Evidence path grammar
 *
 * A path is relative to the analysis bundle. Two extra roots are recognised:
 * `quality.` (the project quality report) and `current_sample.` (the live sample
 * summary). Each step is `name` plus optional selectors:
 *
 *   `descriptive.variables[DSD].mean`         identity match on a string field
 *   `comparisons[UI].anova.p_value`           identity match (`dependent`)
 *   `regression.ols.coefficients[STI].b`      identity match (`term`)
 *   `correlation.pairs[left=STI,right=FED].r` explicit field=value match
 *   `sample.sources[0].total`                 numeric index
 *   `quality.flagged_samples.length`          array length
 *
 * Identity fields are tried in a fixed order and, when several elements match, the
 * LAST one wins — which mirrors how `Dataset.by_name` resolves a variable name the
 * instrument defines twice (the V4.0 template does: Q45 and the first row of Q46
 * are both `PSU1`). `resolveInsightEvidencePath` implements exactly this grammar,
 * so any consumer — including the test suite — can check every quoted number
 * against the artefact it came from.
 */

import type {
  CorrelationPair,
  Dataset,
  DatasetVariable,
  DescriptiveStats,
  EffectMagnitude,
  HypothesisTestResult,
} from '@ferp/shared';
import type { AnalysisBundle, SampleSummary } from './analysis.service.js';
import {
  ANALYSIS_ENGINE_VERSION,
  getLatestBundle,
  loadAnalysableSample,
} from './analysis.service.js';
import type { ProjectQualityReport } from './quality.service.js';
import { getProjectQualityReport } from './quality.service.js';
import { requireProject } from './project.service.js';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import { parseJson } from './mappers.js';

export const INSIGHT_ENGINE_VERSION = '1.0.0';

/* ------------------------------------------------------------------ */
/* Block identity                                                     */
/* ------------------------------------------------------------------ */

export const INSIGHT_BLOCK_KEYS = [
  'target_user',
  'pain_points',
  'current_solutions',
  'service_gap',
  'product_demand',
  'trust',
  'ai_acceptance',
  'willingness_to_pay',
  'market_opportunity',
] as const;

export type InsightBlockKey = (typeof INSIGHT_BLOCK_KEYS)[number];

/** Chinese titles, keyed by block, so the console never invents its own labels. */
export const INSIGHT_BLOCK_TITLES: Record<InsightBlockKey, string> = {
  target_user: '目标用户',
  pain_points: '痛点',
  current_solutions: '现有解决方案',
  service_gap: '服务缺口',
  product_demand: '产品需求',
  trust: '信任',
  ai_acceptance: 'AI 接受度',
  willingness_to_pay: '付费意愿',
  market_opportunity: '市场机会',
};

/**
 * Statements that MUST accompany a competition report.
 *
 * They are part of the artefact rather than advice in a README, because a
 * business-facing summary is exactly where these four get dropped: the sample is
 * treated as a market, a correlation as a cause, a stated intention as demand, and
 * a current attitude as a forecast.
 */
export const REQUIRED_CAVEATS: readonly string[] = [
  '本报告基于非概率（便利）抽样得到的家长样本，样本构成受投放渠道影响，不能代表任何总体，也不构成市场规模估计。',
  '所有变量间关系均为横截面共变关系，不能据此推断因果；「驱动因素」在此仅指统计上显著的关联，不是因果机制。',
  '问卷测量的是「声称的付费意愿」，不等于实际购买行为；未发生支付，也未测量价格弹性与竞争替代。',
  'AI 接受度是当前时点的态度测量，态度会随产品、政策与使用经验变化，不能据此预测未来的实际采用率。',
];

/* ------------------------------------------------------------------ */
/* Block shapes                                                       */
/* ------------------------------------------------------------------ */

/** One traceable fact: the path where the value was found and the value itself. */
export interface EvidenceRef {
  path: string;
  value: unknown;
}

/** One input a block depends on, and whether the finished questionnaire carries it. */
export interface BlockInputProbe {
  name: string;
  role: 'primary' | 'supporting';
  available: boolean;
  note: string | null;
}

export interface InsightBlock<K extends InsightBlockKey = InsightBlockKey, D = unknown> {
  key: K;
  order: number;
  title: string;
  available: boolean;
  /** Chinese explanation of what is missing; null when the block is available. */
  reason: string | null;
  /** Chinese prose restating the block in business language. */
  narrative: string;
  /** Structured payload; null when unavailable, so nothing can be mistaken for a number. */
  data: D | null;
  inputs: BlockInputProbe[];
  evidence: EvidenceRef[];
}

export interface CategoryShare {
  value: string;
  label: string;
  count: number;
  percent: number;
}

export interface VariableReading {
  variable: string;
  label: string;
  data_type: string;
  n: number;
  mean: number | null;
}

/* ---- 1. target user ---------------------------------------------- */

export interface TargetUserData {
  sample_size: {
    respondents_total: number;
    completed: number;
    analysable: number;
    excluded: number;
    in_progress: number;
    abandoned: number;
  };
  channels: { source: string; total: number; percent_of_sample: number }[];
  demographics: {
    variable: string;
    label: string;
    data_type: string;
    n: number;
    /** Always null: demographic variables are reported as distributions, never as means. */
    mean: null;
    mean_note: string;
    categories: CategoryShare[];
  }[];
  primary_segment: {
    variable: string;
    label: string;
    category: string;
    count: number;
    percent: number;
  } | null;
  sampling_limitation: string;
  quality_context: {
    available: boolean;
    note: string;
    scored_respondents: number | null;
    mean_score: number | null;
    flagged_samples: number | null;
  };
}

/* ---- 2. pain points ---------------------------------------------- */

export interface SeverityEntry {
  rank: number;
  variable: string;
  label: string;
  /** Raw measured mean, exactly as the bundle reports it. */
  mean: number;
  /** Comparable severity reading (see `direction`); this is what the ranking uses. */
  severity: number;
  direction: 'direct' | 'reversed';
  n: number;
  source: 'FED_item' | 'ISC' | 'FEK';
  note: string | null;
}

export interface PainPointsData {
  metric: string;
  ranking: SeverityEntry[];
  fed_overall: VariableReading | null;
  information_environment: {
    overall: VariableReading;
    items: VariableReading[];
  } | null;
  knowledge: {
    subjective: VariableReading | null;
    objective: VariableReading | null;
    /** Percentage-point difference between self-rated and objective accuracy. */
    indicative_gap_percentage_points: number | null;
    note: string;
  } | null;
  excluded_from_ranking: { variable: string; reason: string }[];
}

/* ---- 3. current solutions ---------------------------------------- */

export interface ProviderReading extends VariableReading {
  /** Which link of the awareness → access → use → evaluation chain this measures. */
  chain_stage: string;
}

export interface ProviderChannel {
  id: string;
  label: string;
  measured: boolean;
  reason: string | null;
  readings: ProviderReading[];
  /** A categorical measure worth reporting for this provider, with its own n. */
  distribution: { variable: string; label: string; n: number; categories: CategoryShare[] } | null;
  notes: string[];
}

export interface CurrentSolutionsData {
  channels: ProviderChannel[];
  unmeasured: { id: string; label: string; reason: string }[];
  chain_note: string;
}

/* ---- 4. service gap ---------------------------------------------- */

export interface ServiceGapData {
  metric: string;
  demand: {
    overall: VariableReading;
    items: VariableReading[];
  };
  provision: {
    awareness_access: VariableReading | null;
    use_evaluation: VariableReading | null;
  };
  gaps: { id: string; label: string; formula: string; value: number; note: string }[];
  largest_item_contrast: {
    variable: string;
    label: string;
    demand_mean: number;
    provision_mean: number;
    gap: number;
  } | null;
  caveat: string;
}

/* ---- 5. product demand ------------------------------------------- */

export interface ProductDemandData {
  metric: string;
  overall: VariableReading;
  items: {
    rank: number;
    variable: string;
    label: string;
    mean: number;
    n: number;
    above_scale_midpoint: boolean;
  }[];
  scale_midpoint: number;
  breadth_only: { variable: string; label: string; note: string } | null;
  qualitative_material: { available: boolean; note: string };
  note: string;
}

/* ---- 6. trust ----------------------------------------------------- */

export interface TrustData {
  overall: VariableReading;
  providers: { rank: number; variable: string; label: string; mean: number; n: number }[];
  ai_assistant: {
    variable: string;
    label: string;
    mean: number;
    n: number;
    rank: number;
    of: number;
  } | null;
  adoption_link: {
    available: boolean;
    reason: string | null;
    pairs: { left: string; right: string; r: number; p_value: number; method: string; n: number }[];
    regression: { term: string; model: string; b: number; p_value: number | null }[];
    hypothesis: {
      code: string;
      statement: string;
      verdict: string;
      r: number | null;
      p_value: number | null;
      n: number;
      conclusion: string;
    } | null;
  };
  prerequisite_statement: string;
}

/* ---- 7. AI acceptance -------------------------------------------- */

export interface AiAcceptanceData {
  intention: {
    outcome: VariableReading;
    data_type: string;
    distribution: CategoryShare[];
    /** Reported only as a summary reference; the ordinal model is primary. */
    mean_reference: number | null;
    scale_note: string;
  } | null;
  perceived_value: (VariableReading & { distribution: CategoryShare[] | null }) | null;
  risk: { overall: VariableReading; items: VariableReading[] } | null;
  modelling: {
    auto_selected_model: string | null;
    ordinal_available: boolean;
    ols_available: boolean;
    drivers: {
      model: string;
      term: string;
      b: number;
      p_value: number | null;
      significant: boolean;
    }[];
    note: string;
  };
  risk_link: {
    hypothesis_code: string;
    verdict: string;
    r: number | null;
    p_value: number | null;
    n: number;
    note: string;
  } | null;
}

/* ---- 8. willingness to pay --------------------------------------- */

export interface WtpData {
  willingness: {
    outcome: VariableReading;
    data_type: string;
    distribution: CategoryShare[];
    mean_reference: number | null;
    scale_note: string;
  } | null;
  amount_band: {
    variable: string;
    label: string;
    distribution: CategoryShare[];
    note: string;
  } | null;
  demand_link: {
    available: boolean;
    reason: string | null;
    pair: { left: string; right: string; r: number; p_value: number; method: string; n: number } | null;
    hypothesis: {
      code: string;
      statement: string;
      verdict: string;
      r: number | null;
      p_value: number | null;
      n: number;
      conclusion: string;
    } | null;
  };
  purchase_behaviour_caveat: string;
}

/* ---- 9. market opportunity --------------------------------------- */

export interface MarketDriver {
  source: 'ols' | 'ordinal_logit' | 'correlation' | 'hypothesis';
  name: string;
  statistic: string;
  value: number;
  p_value: number | null;
  effect: string | null;
  note: string;
}

export interface MarketOpportunityData {
  inference_label: string;
  sample_scope: { analysable: number; note: string };
  drivers: MarketDriver[];
  not_confirmed: { name: string; statistic: string; value: number | null; p_value: number | null; verdict: string | null; note: string }[];
  demand_ranking: { rank: number; variable: string; label: string; mean: number; n: number }[];
  segment_findings: {
    dependent: string;
    factor: string;
    p_value: number | null;
    statistic: string;
    effect: string | null;
    recommended: string;
  }[];
  market_size_estimate: {
    available: false;
    amount: null;
    currency: null;
    reason: string;
  };
  what_would_be_needed: string[];
  bounded_conclusion: string;
}

export interface BlockDataMap {
  target_user: TargetUserData;
  pain_points: PainPointsData;
  current_solutions: CurrentSolutionsData;
  service_gap: ServiceGapData;
  product_demand: ProductDemandData;
  trust: TrustData;
  ai_acceptance: AiAcceptanceData;
  willingness_to_pay: WtpData;
  market_opportunity: MarketOpportunityData;
}

export type CompetitionBlock = {
  [K in InsightBlockKey]: InsightBlock<K, BlockDataMap[K]>;
}[InsightBlockKey];

/* ---- report ------------------------------------------------------ */

export interface InsightInputs {
  bundle: AnalysisBundle;
  dataset: Dataset;
  summary: SampleSummary;
  quality: ProjectQualityReport | null;
}

export interface InsightReport {
  engine_version: string;
  generated_at: string;
  source: {
    analysis_engine_version: string;
    analysis_generated_at: string;
    project_id: string;
    project_title: string;
    questionnaire: AnalysisBundle['questionnaire'];
    bundle_engine_matches: boolean;
  };
  sample: SampleSummary;
  staleness: {
    bundle_sample_n: number;
    current_sample_n: number;
    stale: boolean;
    note: string;
  };
  blocks: CompetitionBlock[];
  caveats: string[];
  notes: string[];
}

/* ------------------------------------------------------------------ */
/* Small helpers                                                      */
/* ------------------------------------------------------------------ */

/** 4 decimal places: the engine's own reporting precision. */
function round4(value: number): number {
  return Math.round(value * 10000) / 10000;
}

/**
 * 2 decimal places, used for values THIS layer derives (differences, shares).
 * Values taken from the bundle are never re-rounded.
 */
function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

/** How a number is written into Chinese prose. */
export function displayNumber(value: number): string {
  if (!Number.isFinite(value)) return String(value);
  return Number.isInteger(value) ? String(value) : value.toFixed(2);
}

function displayP(value: number | null): string {
  if (value === null) return '未报告';
  return value < 0.001 ? '< 0.001' : value.toFixed(3);
}

function percent(part: number, whole: number): number {
  return whole > 0 ? round2((part / whole) * 100) : 0;
}

/** Collects the facts a block rests on, de-duplicated by path and value. */
class EvidenceBag {
  private readonly entries: EvidenceRef[] = [];

  add(path: string, value: unknown): void {
    const serialised = JSON.stringify(value) ?? 'undefined';
    const duplicate = this.entries.some(
      (entry) => entry.path === path && (JSON.stringify(entry.value) ?? 'undefined') === serialised,
    );
    if (!duplicate) this.entries.push({ path, value });
  }

  addReading(store: Map<string, DescriptiveStats>, variable: string): void {
    const stats = store.get(variable);
    if (!stats) return;
    this.add(`descriptive.variables[${variable}].mean`, stats.mean);
    this.add(`descriptive.variables[${variable}].n`, stats.n);
  }

  list(): EvidenceRef[] {
    return this.entries;
  }
}

/** Descriptive statistics indexed by variable name (last write wins, see header). */
function descriptiveIndex(bundle: AnalysisBundle): Map<string, DescriptiveStats> {
  const index = new Map<string, DescriptiveStats>();
  for (const stats of bundle.descriptive.variables) index.set(stats.variable, stats);
  return index;
}

/** Variable names the instrument defines more than once — reported, never fixed here. */
function duplicatedVariableNames(bundle: AnalysisBundle): string[] {
  const counts = new Map<string, number>();
  for (const stats of bundle.descriptive.variables) {
    counts.set(stats.variable, (counts.get(stats.variable) ?? 0) + 1);
  }
  return [...counts.entries()].filter(([, count]) => count > 1).map(([name]) => name);
}

/**
 * Item variables belonging to a construct.
 *
 * A multi-question construct records its item names in `sources`; a matrix
 * question records its own question code instead (its rows are separate
 * variables), so the question code is the fallback. Resolved through the dataset
 * because the bundle's variable inventory does not carry `sources` for matrix
 * constructs.
 */
function itemsOf(dataset: Dataset, name: string): DatasetVariable[] {
  const composite = dataset.by_name.get(name);
  if (!composite) return [];
  const names: string[] = [];
  for (const source of composite.sources) {
    const variable = dataset.by_name.get(source);
    if (variable && !variable.is_derived && variable.name !== name) names.push(variable.name);
  }
  if (names.length > 0) return unique(names).map((item) => dataset.by_name.get(item)!);

  return dataset.variables.filter(
    (variable) =>
      !variable.is_derived && variable.question_code === composite.question_code && variable.name !== name,
  );
}

function unique(values: string[]): string[] {
  return [...new Set(values)];
}

/** Read one variable as a business-facing reading; null when unusable. */
function readVariable(
  store: Map<string, DescriptiveStats>,
  variable: string,
  options: { requireMean?: boolean } = {},
): VariableReading | null {
  const stats = store.get(variable);
  if (!stats || stats.n === 0) return null;
  if (options.requireMean !== false && stats.mean === null) return null;
  return {
    variable: stats.variable,
    label: stats.label,
    data_type: stats.data_type,
    n: stats.n,
    mean: stats.mean,
  };
}

/**
 * A usable mean is the precondition for every "how much" claim in this report.
 * The reading carries the descriptive statistics plus the fields callers quote,
 * so prose can never drift from the number it is describing.
 */
function readMean(
  store: Map<string, DescriptiveStats>,
  variable: string,
): { stats: DescriptiveStats; mean: number; n: number; label: string; data_type: string } | null {
  const stats = store.get(variable);
  if (!stats || stats.n === 0 || stats.mean === null) return null;
  return { stats, mean: stats.mean, n: stats.n, label: stats.label, data_type: stats.data_type };
}

function readCategories(
  store: Map<string, DescriptiveStats>,
  variable: string,
): CategoryShare[] | null {
  const stats = store.get(variable);
  if (!stats || !stats.frequencies || stats.frequencies.length === 0) return null;
  return stats.frequencies.map((row) => ({
    value: row.value,
    label: row.label,
    count: row.count,
    percent: row.percent,
  }));
}

/** The label the bundle carries for a variable, or the name when it has none. */
function labelOf(store: Map<string, DescriptiveStats>, variable: string): string {
  return store.get(variable)?.label ?? variable;
}

function probe(
  name: string,
  role: BlockInputProbe['role'],
  available: boolean,
  note: string | null = null,
): BlockInputProbe {
  return { name, role, available, note };
}

function findPair(bundle: AnalysisBundle, left: string, right: string): CorrelationPair | null {
  const pairs = bundle.correlation?.pairs ?? [];
  return (
    pairs.find(
      (pair) =>
        (pair.left === left && pair.right === right) || (pair.left === right && pair.right === left),
    ) ?? null
  );
}

function pairEvidence(bundle: AnalysisBundle, pair: CorrelationPair): {
  r: EvidenceRef;
  p: EvidenceRef;
} | null {
  if (pair.r === null || pair.p_value === null) return null;
  const base = `correlation.pairs[left=${pair.left},right=${pair.right}]`;
  return {
    r: { path: `${base}.r`, value: pair.r },
    p: { path: `${base}.p_value`, value: pair.p_value },
  };
}

function findHypothesis(bundle: AnalysisBundle, code: string): HypothesisTestResult | null {
  return bundle.hypotheses.results.find((result) => result.code === code) ?? null;
}

/** A hypothesis reading is only usable when the engine could actually test it. */
function hypothesisView(result: HypothesisTestResult | null): {
  code: string;
  statement: string;
  verdict: string;
  r: number | null;
  p_value: number | null;
  n: number;
  conclusion: string;
} | null {
  if (!result) return null;
  return {
    code: result.code,
    statement: result.statement,
    verdict: result.verdict,
    r: result.r,
    p_value: result.p_value,
    n: result.n,
    conclusion: result.conclusion,
  };
}

function describeEffect(effect: EffectMagnitude | null | undefined): string | null {
  return effect ? `${effect.text}；判定依据：${effect.convention}` : null;
}

/* ------------------------------------------------------------------ */
/* Evidence path resolver                                             */
/* ------------------------------------------------------------------ */

/** Fields an identity selector `[NAME]` is matched against, in priority order. */
const IDENTITY_FIELDS = [
  'variable',
  'item',
  'scale',
  'dependent',
  'term',
  'code',
  'key',
  'name',
  'group',
  'label',
] as const;

/** Split on dots that are not inside a selector bracket. */
function splitTopLevel(path: string): string[] {
  const parts: string[] = [];
  let current = '';
  let depth = 0;
  for (const char of path) {
    if (char === '[') depth += 1;
    if (char === ']') depth -= 1;
    if (char === '.' && depth === 0) {
      parts.push(current);
      current = '';
      continue;
    }
    current += char;
  }
  if (current !== '') parts.push(current);
  return parts;
}

function parseSegment(segment: string): { name: string; selectors: string[] } {
  const open = segment.indexOf('[');
  if (open === -1) return { name: segment, selectors: [] };
  const name = segment.slice(0, open);
  const selectors: string[] = [];
  let cursor = open;
  while (cursor < segment.length && segment[cursor] === '[') {
    const close = segment.indexOf(']', cursor);
    if (close === -1) break;
    selectors.push(segment.slice(cursor + 1, close));
    cursor = close + 1;
  }
  return { name, selectors };
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === 'object' ? (value as Record<string, unknown>) : null;
}

function selectFromArray(array: unknown[], selector: string): unknown {
  if (/^\d+$/.test(selector)) return array[Number(selector)];
  if (selector === 'length') return array.length;

  if (selector.includes('=')) {
    const conditions = selector.split(',').map((condition) => {
      const [field, expected] = condition.split('=');
      return { field: (field ?? '').trim(), expected: (expected ?? '').trim() };
    });
    let found: unknown;
    for (const item of array) {
      const record = asRecord(item);
      if (!record) continue;
      if (conditions.every((condition) => String(record[condition.field]) === condition.expected)) {
        found = item;
      }
    }
    return found;
  }

  // Identity match. The last matching element wins, mirroring Dataset.by_name.
  let found: unknown;
  for (const item of array) {
    const record = asRecord(item);
    if (!record) continue;
    if (IDENTITY_FIELDS.some((field) => record[field] === selector)) found = item;
  }
  return found;
}

/**
 * Resolve an evidence path against the insight inputs.
 * Returns `undefined` when the path does not exist, so a fabricated path is
 * detectable rather than silently resolving to something plausible.
 */
export function resolveInsightEvidencePath(inputs: InsightInputs, path: string): unknown {
  const segments = splitTopLevel(path);
  if (segments.length === 0) return undefined;

  const head = segments[0]!;
  let current: unknown;
  let rest: string[];
  if (head === 'quality') {
    current = inputs.quality;
    rest = segments.slice(1);
  } else if (head === 'current_sample') {
    current = inputs.summary;
    rest = segments.slice(1);
  } else if (head === 'bundle') {
    current = inputs.bundle;
    rest = segments.slice(1);
  } else {
    current = inputs.bundle;
    rest = segments;
  }

  for (const segment of rest) {
    const { name, selectors } = parseSegment(segment);
    if (current === undefined || current === null) return undefined;

    if (name !== 'length' && Array.isArray(current)) {
      current = selectFromArray(current, name);
    } else {
      current = asRecord(current)?.[name];
    }

    for (const selector of selectors) {
      if (current === undefined || current === null) return undefined;
      if (!Array.isArray(current)) return undefined;
      current = selectFromArray(current, selector);
    }
  }

  return current;
}

/* ------------------------------------------------------------------ */
/* Block 1 — 目标用户                                                  */
/* ------------------------------------------------------------------ */

const DEMOGRAPHIC_DIMENSION = '基本信息';
const PRIMARY_DEMOGRAPHIC_VARIABLE = 'STAGE';

function buildTargetUser(inputs: InsightInputs): InsightBlock<'target_user', TargetUserData> {
  const { bundle, quality } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();
  const sample = bundle.sample;

  evidence.add('sample.respondents_total', sample.respondents_total);
  evidence.add('sample.completed', sample.completed);
  evidence.add('sample.analysable', sample.analysable);
  evidence.add('sample.excluded', sample.excluded);
  evidence.add('sample.sources', sample.sources);

  const channels = sample.sources.map((entry) => ({
    source: entry.source,
    total: entry.total,
    percent_of_sample: percent(entry.total, sample.respondents_total),
  }));

  // Demographic variables: everything the instrument filed under 基本信息 that has
  // option labels, so the shares below are the instrument's own category labels.
  const demographicNames = bundle.descriptive.variables
    .filter((stats) => stats.dimension === DEMOGRAPHIC_DIMENSION)
    .map((stats) => stats.variable)
    .filter((name, index, all) => all.indexOf(name) === index);

  const demographics: TargetUserData['demographics'] = [];
  const withoutCategories: string[] = [];

  for (const name of demographicNames) {
    const stats = store.get(name);
    if (!stats || stats.n === 0) continue;
    const categories = readCategories(store, name);
    if (!categories) {
      withoutCategories.push(name);
      continue;
    }
    evidence.add(`descriptive.variables[${name}].n`, stats.n);
    categories.forEach((category, index) => {
      evidence.add(`descriptive.variables[${name}].frequencies[${index}].count`, category.count);
      evidence.add(`descriptive.variables[${name}].frequencies[${index}].percent`, category.percent);
    });
    demographics.push({
      variable: name,
      label: stats.label,
      data_type: stats.data_type,
      n: stats.n,
      mean: null,
      mean_note:
        '人口学变量以分布呈现：名义变量的编码只是标签，有序变量的类别间隔也不可假定等距，因此本区块不报告均值。',
      categories,
    });
  }

  const primary = demographics.find((entry) => entry.variable === PRIMARY_DEMOGRAPHIC_VARIABLE) ?? demographics[0];
  let primarySegment: TargetUserData['primary_segment'] = null;
  if (primary) {
    const top = primary.categories.reduce(
      (best, category) => (category.count > best.count ? category : best),
      primary.categories[0]!,
    );
    primarySegment = {
      variable: primary.variable,
      label: primary.label,
      category: top.label,
      count: top.count,
      percent: top.percent,
    };
  }

  const available = demographics.length > 0;
  const inputsProbe = [
    probe(PRIMARY_DEMOGRAPHIC_VARIABLE, 'primary', Boolean(primary), primary ? null : '问卷未采集学段信息。'),
    probe(
      'demographic_variables',
      'supporting',
      demographics.length > 0,
      demographics.length > 0 ? null : `问卷未采集任何带选项标签的${DEMOGRAPHIC_DIMENSION}变量。`,
    ),
    probe('sample', 'supporting', sample.analysable > 0, sample.analysable > 0 ? null : '尚无有效样本。'),
    probe('quality', 'supporting', quality !== null, quality ? null : '质量报告不可用，未引用质量数据。'),
  ];

  const qualityContext: TargetUserData['quality_context'] = quality
    ? {
        available: true,
        note:
          `质量引擎已对 ${displayNumber(quality.scored_respondents)} 份样本评分，平均分 ${displayNumber(quality.mean_score ?? 0)}；` +
          `其中 ${displayNumber(quality.flagged_samples.length)} 份存在可疑标记，另有 ${displayNumber(quality.excluded_samples.length)} 份被研究者排除。` +
          '商业结论建立在人工审核后的样本上，质量提示不等于对受访者的评价。',
        scored_respondents: quality.scored_respondents,
        mean_score: quality.mean_score,
        flagged_samples: quality.flagged_samples.length,
      }
    : {
        available: false,
        note: '尚未运行数据质量引擎，本区块无法说明样本的数据质量，也未引用任何质量数值。',
        scored_respondents: null,
        mean_score: null,
        flagged_samples: null,
      };

  if (quality) {
    evidence.add('quality.scored_respondents', quality.scored_respondents);
    evidence.add('quality.mean_score', quality.mean_score);
    evidence.add('quality.flagged_samples.length', quality.flagged_samples.length);
    evidence.add('quality.excluded_samples.length', quality.excluded_samples.length);
  }

  const samplingLimitation =
    `本样本为通过分享链接获得的便利样本（共 ${displayNumber(sample.respondents_total)} 人启动作答，` +
    `${displayNumber(sample.analysable)} 份进入分析），不是随机抽样，样本构成受投放渠道影响；` +
    `它描述的是「回答过本问卷的家长」，不是任何地区的家长总体，因此不能据此推算用户规模或市场容量。`;

  const data: TargetUserData = {
    sample_size: {
      respondents_total: sample.respondents_total,
      completed: sample.completed,
      analysable: sample.analysable,
      excluded: sample.excluded,
      in_progress: sample.in_progress,
      abandoned: sample.abandoned,
    },
    channels,
    demographics,
    primary_segment: primarySegment,
    sampling_limitation: samplingLimitation,
    quality_context: qualityContext,
  };

  const demographicProse = demographics
    .map((entry) => {
      const listing = entry.categories
        .map((category) => `${category.label} ${displayNumber(category.count)} 人（${displayNumber(category.percent)}%）`)
        .join('、');
      return `${entry.label}（n = ${displayNumber(entry.n)}）：${listing}`;
    })
    .join('；');

  const channelProse =
    channels.length > 0
      ? `样本来源渠道：${channels
          .map((entry) => `${entry.source} ${displayNumber(entry.total)} 人（占启动作答的 ${displayNumber(entry.percent_of_sample)}%）`)
          .join('、')}。`
      : '样本未记录来源渠道。';

  const narrative = available
    ? `目标用户为完成本问卷的家长：共 ${displayNumber(sample.respondents_total)} 人启动作答，` +
      `已完成 ${displayNumber(sample.completed)} 份，其中研究者排除 ${displayNumber(sample.excluded)} 份，` +
      `进入分析的有效样本 n = ${displayNumber(sample.analysable)}。` +
      `${channelProse}样本构成：${demographicProse}。` +
      (primarySegment
        ? `构成上占比最高的分组是「${primarySegment.category}」${displayNumber(primarySegment.count)} 人` +
          `（${displayNumber(primarySegment.percent)}%），可作为第一版服务的切入人群。`
        : '') +
      `${samplingLimitation}${qualityContext.note}`
    : `本区块不可用：${demographicNames.length > 0 ? `已采集${DEMOGRAPHIC_DIMENSION}变量（${demographicNames.join('、')}）` : '问卷未采集'}，` +
      `但其中没有任何变量带有选项标签，无法计算构成比例；` +
      (withoutCategories.length > 0 ? `无选项标签的变量：${withoutCategories.join('、')}。` : '') +
      '未给出任何比例数字，以免与真实分布混淆。';

  return {
    key: 'target_user',
    order: 1,
    title: INSIGHT_BLOCK_TITLES.target_user,
    available,
    reason: available
      ? null
      : '问卷未采集任何带选项标签的目标用户分组信息（如学段、身份、学历），无法描述样本构成，本区块不给出任何比例。',
    narrative,
    data: available ? data : null,
    inputs: inputsProbe,
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 2 — 痛点                                                      */
/* ------------------------------------------------------------------ */

/** The midpoint of a 1—5 Likert scale; used only to describe direction. */
const SCALE_MIDPOINT = 3;

function buildPainPoints(inputs: InsightInputs): InsightBlock<'pain_points', PainPointsData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const fedItems = itemsOf(dataset, 'FED')
    .map((variable) => variable.name)
    .filter((name) => readMean(store, name) !== null);
  const iscItems = itemsOf(dataset, 'ISC').map((variable) => variable.name);

  const ranking: SeverityEntry[] = [];

  for (const name of fedItems) {
    const reading = readMean(store, name);
    if (!reading) continue;
    evidence.addReading(store, name);
    ranking.push({
      rank: 0,
      variable: name,
      label: reading.stats.label,
      mean: reading.mean,
      severity: reading.mean,
      direction: 'direct',
      n: reading.stats.n,
      source: 'FED_item',
      note: null,
    });
  }

  const iscOverall = readMean(store, 'ISC');
  const iscReadings: VariableReading[] = [];
  if (iscOverall) {
    evidence.addReading(store, 'ISC');
    for (const name of iscItems) {
      const reading = readMean(store, name);
      if (!reading) continue;
      evidence.addReading(store, name);
      iscReadings.push({
        variable: name,
        label: reading.stats.label,
        data_type: reading.stats.data_type,
        n: reading.stats.n,
        mean: reading.mean,
      });
    }
    ranking.push({
      rank: 0,
      variable: 'ISC',
      label: iscOverall.stats.label,
      mean: iscOverall.mean,
      severity: iscOverall.mean,
      direction: 'direct',
      n: iscOverall.stats.n,
      source: 'ISC',
      note: '信息环境困扰指数（碎片化与判断困难两项均值）。',
    });
  }

  // Knowledge is a pain point in the opposite direction: on the 1—5 了解程度 item
  // a LOW value is the gap, so the severity reading is inverted. Both the raw mean
  // and the transformation are reported, never just the transformed number.
  const fek = readMean(store, 'FEK');
  if (fek) {
    evidence.addReading(store, 'FEK');
    ranking.push({
      rank: 0,
      variable: 'FEK',
      label: fek.stats.label,
      mean: fek.mean,
      severity: round2(6 - fek.mean),
      direction: 'reversed',
      n: fek.stats.n,
      source: 'FEK',
      note: '知识自评为「越高越好」，故以 6 − 均值换算为严重程度，原始均值同时报告。',
    });
  }

  ranking.sort((left, right) => right.severity - left.severity || left.variable.localeCompare(right.variable));
  ranking.forEach((entry, index) => {
    entry.rank = index + 1;
  });

  const fedOverallRaw = readMean(store, 'FED');
  let fedOverall: VariableReading | null = null;
  if (fedOverallRaw) {
    evidence.addReading(store, 'FED');
    fedOverall = {
      variable: 'FED',
      label: fedOverallRaw.stats.label,
      data_type: fedOverallRaw.stats.data_type,
      n: fedOverallRaw.stats.n,
      mean: fedOverallRaw.mean,
    };
  }

  const lka = readMean(store, 'LKA');
  let knowledge: PainPointsData['knowledge'] = null;
  if (fek) {
    if (lka) {
      evidence.addReading(store, 'LKA');
      knowledge = {
        subjective: {
          variable: 'FEK',
          label: fek.stats.label,
          data_type: fek.stats.data_type,
          n: fek.stats.n,
          mean: fek.mean,
        },
        objective: {
          variable: 'LKA',
          label: lka.stats.label,
          data_type: lka.stats.data_type,
          n: lka.stats.n,
          mean: lka.mean,
        },
        // Both are expressed as a share of their own maximum before differencing,
        // because 自评 is a 1—5 rating and LKA is a 0—5 count of correct answers.
        indicative_gap_percentage_points: round2(
          (lka.mean / 5) * 100 - (fek.mean / 5) * 100,
        ),
        note:
          'FEK 为 1—5 的主观自评，LKA 为 0—5 的客观正确题数，两者量表不同，' +
          '故差值按各自满分折算为百分点后相减，仅作方向性对照，不得当作同一量表上的差距。',
      };
    } else {
      knowledge = {
        subjective: {
          variable: 'FEK',
          label: fek.stats.label,
          data_type: fek.stats.data_type,
          n: fek.stats.n,
          mean: fek.mean,
        },
        objective: null,
        indicative_gap_percentage_points: null,
        note:
          '问卷未包含客观知识题（LKA），无法对照主观自评与客观准确度，' +
          '因此本区块不给出「知识缺口」数值，仅报告自评水平。',
      };
    }
  }

  const excludedFromRanking: { variable: string; reason: string }[] = [];
  excludedFromRanking.push({
    variable: 'FED',
    reason: 'FED 是其七个条目（FED1—FED7）的均值，列入排序会与其自身条目重复计数，故只作总体水平报告。',
  });
  if (lka) {
    excludedFromRanking.push({
      variable: 'LKA',
      reason: 'LKA 为 0—5 的答对题数，与 1—5 的严重程度量表不同，不可直接排序比较。',
    });
  }

  const available = ranking.length > 0;
  const inputsProbe = [
    probe('FED', 'primary', fedItems.length > 0, fedItems.length > 0 ? null : '问卷未包含家庭教育困难矩阵题（Q35）。'),
    probe('ISC', 'supporting', iscOverall !== null, iscOverall ? null : '问卷未包含信息环境困扰题（Q19、Q20）。'),
    probe('FEK', 'supporting', fek !== null, fek ? null : '问卷未包含家庭教育知识自评题（Q9）。'),
    probe('LKA', 'supporting', lka !== null, lka ? null : '问卷未包含客观法律知识题（Q12—Q16）。'),
  ];

  const rankingProse = ranking
    .map(
      (entry) =>
        `${entry.rank}. ${entry.label}（${entry.variable}）：均值 ${displayNumber(entry.mean)}，` +
        `严重程度 ${displayNumber(entry.severity)}，n = ${displayNumber(entry.n)}`,
    )
    .join('；');

  const narrative = available
    ? `痛点按测量到的严重程度排序（${displayNumber(ranking.length)} 项，数值越高越严重）：${rankingProse}。` +
      (fedOverall
        ? `家庭教育困难总体均值为 ${displayNumber(fedOverall.mean ?? 0)}（n = ${displayNumber(fedOverall.n)}）。`
        : '') +
      (iscReadings.length > 0
        ? `信息环境困扰分项：${iscReadings
            .map((item) => `${item.label} ${displayNumber(item.mean ?? 0)}（n = ${displayNumber(item.n)}）`)
            .join('、')}。`
        : '') +
      (knowledge
        ? `知识方面：主观自评均值 ${displayNumber(knowledge.subjective?.mean ?? 0)}；` +
          (knowledge.objective
            ? `客观正确题数均值 ${displayNumber(knowledge.objective.mean ?? 0)}；` +
              `折算后自评高于客观正确率的幅度为 ${displayNumber(knowledge.indicative_gap_percentage_points ?? 0)} 个百分点（口径见说明）。`
            : knowledge.note)
        : '') +
      '排序完全来自本次测量的条目均值，未使用任何人工设定的优先级。'
    : '本区块不可用：问卷未包含任何可用于衡量困难或困扰程度的题目（Q35 困难矩阵、Q19/Q20 信息困扰、Q9 知识自评），' +
      '因此不给出痛点排序，也不以「0」或空值填充。';

  const data: PainPointsData = {
    metric:
      '1—5 严重程度均值（数值越高越严重）。反向计分条目（知识自评 FEK）以 6 − 均值换算，原始均值同时报告；' +
      '不同量表的指标不参与同一排序。',
    ranking,
    fed_overall: fedOverall,
    information_environment: iscOverall
      ? {
          overall: {
            variable: 'ISC',
            label: iscOverall.stats.label,
            data_type: iscOverall.stats.data_type,
            n: iscOverall.stats.n,
            mean: iscOverall.mean,
          },
          items: iscReadings,
        }
      : null,
    knowledge,
    excluded_from_ranking: excludedFromRanking,
  };

  return {
    key: 'pain_points',
    order: 2,
    title: INSIGHT_BLOCK_TITLES.pain_points,
    available,
    reason: available
      ? null
      : '问卷未测量家庭教育困难（FED）、信息环境困扰（ISC）或知识自评（FEK），无法给出基于测量值的痛点排序。',
    narrative,
    data: available ? data : null,
    inputs: inputsProbe,
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 3 — 现有解决方案                                              */
/* ------------------------------------------------------------------ */

function buildCurrentSolutions(
  inputs: InsightInputs,
): InsightBlock<'current_solutions', CurrentSolutionsData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();
  const duplicated = duplicatedVariableNames(bundle);

  /** Build one chain reading, or null when the instrument does not carry it. */
  const reading = (variable: string, chainStage: string): ProviderReading | null => {
    const value = readVariable(store, variable);
    if (!value) {
      // Presence without a usable mean is still worth recording honestly.
      const stats = store.get(variable);
      if (stats && stats.n > 0 && stats.mean === null) {
        evidence.add(`descriptive.variables[${variable}].mean`, stats.mean);
        evidence.add(`descriptive.variables[${variable}].n`, stats.n);
      }
      return null;
    }
    evidence.add(`descriptive.variables[${variable}].mean`, value.mean);
    evidence.add(`descriptive.variables[${variable}].n`, value.n);
    return { ...value, chain_stage: chainStage };
  };

  const distributionOf = (
    variable: string,
  ): { variable: string; label: string; n: number; categories: CategoryShare[] } | null => {
    const categories = readCategories(store, variable);
    const stats = store.get(variable);
    if (!categories || !stats || stats.n === 0) return null;
    evidence.add(`descriptive.variables[${variable}].n`, stats.n);
    categories.forEach((category, index) => {
      evidence.add(`descriptive.variables[${variable}].frequencies[${index}].count`, category.count);
      evidence.add(`descriptive.variables[${variable}].frequencies[${index}].percent`, category.percent);
    });
    return { variable, label: stats.label, n: stats.n, categories };
  };

  const channels: ProviderChannel[] = [];

  /* --- 政府家庭教育公共服务 --- */
  const governmentReadings = [
    reading('PSA', '知晓与可及'),
    reading('PSU', '使用与评价'),
    reading('PSAK', '知晓广度'),
    reading('PSUI', '未来使用意愿'),
    reading('PSA1', '知晓清晰度'),
    reading('PSA2', '获取便利性'),
  ].filter((entry): entry is ProviderReading => entry !== null);
  const governmentNotes: string[] = [
    'PSU 为该问卷的使用频次题（Q45）与服务评价矩阵（Q46）的综合均值，' +
      '它把「是否使用过」与「评价高低」混在一个指标里，因此不能读作使用率。',
  ];
  for (const name of duplicated) {
    if (name.startsWith('PSU') || name.startsWith('PSA')) {
      governmentNotes.push(
        `问卷中变量名 ${name} 被定义了多次（Q45 与 Q46 第 1 行），统计引擎按后出现者解析该变量名，` +
          '本报告照实呈现，未重新编码或改名。',
      );
    }
  }
  channels.push({
    id: 'government_public_service',
    label: '政府家庭教育公共服务',
    measured: governmentReadings.length > 0,
    reason:
      governmentReadings.length > 0
        ? null
        : '问卷未包含政府家庭教育公共服务题目（PSA/PSU/PSAK/PSUI），无法评估该供给方。',
    readings: governmentReadings,
    distribution: null,
    notes: governmentNotes,
  });

  /* --- 家庭教育机构 --- */
  const institutionReadings = [
    reading('FIUA', '知晓'),
    reading('FIUU', '使用频次'),
    reading('FIUS', '满意度'),
    reading('FIU', '使用意愿'),
  ].filter((entry): entry is ProviderReading => entry !== null);
  channels.push({
    id: 'family_edu_institution',
    label: '家庭教育机构（付费课程、咨询、指导）',
    measured: institutionReadings.length > 0,
    reason:
      institutionReadings.length > 0
        ? null
        : '问卷未包含家庭教育机构题目（FIUA/FIUU/FIUS/FIU）。机构侧的知晓率、使用率与满意度均未被测量，' +
          '因此本报告不对该供给方作任何推断，也不假设其存在或不存在市场。',
    readings: institutionReadings,
    distribution: distributionOf('FIUU'),
    notes: ['机构使用的测量含跳转逻辑（未使用者不回答满意度题），因此满意度的 n 通常小于使用频次的 n。'],
  });

  /* --- 学校与老师 --- */
  const schoolReadings = [
    reading('ISCB', '渠道广度（多选题计数）'),
    reading('ISCTM', '每周获取知识时间'),
  ].filter((entry): entry is ProviderReading => entry !== null);
  const schoolDistribution = distributionOf('ISCT');
  channels.push({
    id: 'school_and_teacher',
    label: '学校与老师',
    measured: false,
    reason:
      '问卷只把「学校或幼儿园老师」作为信息来源渠道（Q17 多选）与「最信任来源」（Q18 单选）测量，' +
      '并未测量学校/老师提供家庭教育指导的知晓、使用与评价。因此本报告不把它当作一个已测量的供给方，' +
      '也不对其服务质量或覆盖率作任何结论。',
    readings: schoolReadings,
    distribution: schoolDistribution,
    notes: [
      schoolDistribution
        ? '上方分布为 Q18「最信任的信息来源」的选择结果，属于信任测量的口径，不是学校指导的使用率。'
        : '问卷未包含 Q18，因此连「最信任的信息来源」也无法报告。',
    ],
  });

  /* --- 内容平台 --- */
  const platformReadings = [reading('ISCB', '渠道广度（多选题计数）')].filter(
    (entry): entry is ProviderReading => entry !== null,
  );
  channels.push({
    id: 'content_platforms',
    label: '内容平台与自媒体（公众号、短视频、社区）',
    measured: false,
    reason:
      '问卷以多选题统计「渠道广度」（ISCB 为选中渠道的数量），并未逐平台测量使用率；' +
      '多选题的原始作答在统计引擎中被聚合为计数，各平台的单独占比不在结果包中。' +
      '因此本报告只报告渠道广度，不对任何单一平台的份额作推断。',
    readings: platformReadings,
    distribution: null,
    notes: ['渠道广度均值为选中渠道数量（0—9），数值越高表示信息来源越分散。'],
  });

  const unmeasured = channels
    .filter((channel) => !channel.measured)
    .map((channel) => ({ id: channel.id, label: channel.label, reason: channel.reason ?? '' }));

  const available = channels.some((channel) => channel.measured);
  const inputsProbe = channels.map((channel) =>
    probe(channel.id, channel.id === 'government_public_service' ? 'primary' : 'supporting', channel.measured, channel.reason),
  );

  const channelProse = channels
    .map((channel) => {
      const readings =
        channel.readings.length > 0
          ? channel.readings
              .map(
                (entry) =>
                  `${entry.chain_stage} ${entry.variable} = ${displayNumber(entry.mean ?? 0)}（n = ${displayNumber(entry.n)}）`,
              )
              .join('、')
          : '无可用测量值';
      const distribution = channel.distribution
        ? `；${channel.distribution.label}（变量 ${channel.distribution.variable}，n = ${displayNumber(channel.distribution.n)}）分布：` +
          channel.distribution.categories
            .map((category) => `${category.label} ${displayNumber(category.count)} 人（${displayNumber(category.percent)}%）`)
            .join('、')
        : '';
      // Unmeasured providers still list whatever the instrument did measure about
      // them (e.g. the channel-breadth count), clearly separated from the verdict.
      const verdict = channel.measured ? '' : `（该供给方未被问卷直接测量：${channel.reason ?? ''}）`;
      return `${channel.label}${verdict}：${readings}${distribution}`;
    })
    .join('；');

  const narrative = available
    ? `现有解决方案按问卷实际测量的供给方逐一陈述：${channelProse}。` +
      '未被测量的供给方一律标注为「未测量」，不以行业常识代替本次数据。'
    : `本区块不可用：问卷未测量任何家庭教育服务供给方的知晓或使用情况（${unmeasured
        .map((entry) => entry.label)
        .join('、')}）。` + '因此不给出「现有解决方案」的判断，也不引用任何外部行业数据。';

  const data: CurrentSolutionsData = {
    channels,
    unmeasured,
    chain_note:
      '政府公共服务的链条按问卷结构拆为：知晓与可及（PSA）、使用与评价（PSU）、知晓广度（PSAK）、未来使用意愿（PSUI）。' +
      '链条中的每一环都可能缺失，本报告只报告实际测到的那几环。',
  };

  return {
    key: 'current_solutions',
    order: 3,
    title: INSIGHT_BLOCK_TITLES.current_solutions,
    available,
    reason: available
      ? null
      : '问卷未测量任何现有服务供给方的知晓、可及或使用情况，无法描述现有解决方案。',
    narrative,
    data: available ? data : null,
    inputs: inputsProbe,
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 4 — 服务缺口                                                  */
/* ------------------------------------------------------------------ */

function buildServiceGap(inputs: InsightInputs): InsightBlock<'service_gap', ServiceGapData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const demandOverall = readMean(store, 'DSD');
  const awareness = readMean(store, 'PSA');
  const use = readMean(store, 'PSU');

  const demandItems: VariableReading[] = [];
  if (demandOverall) {
    evidence.addReading(store, 'DSD');
    for (const variable of itemsOf(dataset, 'DSD')) {
      const reading = readMean(store, variable.name);
      if (!reading) continue;
      evidence.addReading(store, variable.name);
      demandItems.push({
        variable: variable.name,
        label: reading.stats.label,
        data_type: reading.stats.data_type,
        n: reading.stats.n,
        mean: reading.mean,
      });
    }
  }
  for (const [name, reading] of [
    ['PSA', awareness],
    ['PSU', use],
  ] as const) {
    if (!reading) continue;
    evidence.addReading(store, name);
  }

  const available = demandOverall !== null && (awareness !== null || use !== null);
  const missing: string[] = [];
  if (!demandOverall) missing.push('需求侧 DSD（Q49）');
  if (!awareness && !use) missing.push('供给侧 PSA（Q43、Q44）或 PSU（Q45、Q46）');

  if (!available) {
    return {
      key: 'service_gap',
      order: 4,
      title: INSIGHT_BLOCK_TITLES.service_gap,
      available: false,
      reason: `无法量化服务缺口：缺少${missing.join('、')}，缺口需要需求与供给两侧同时存在。`,
      narrative:
        `本区块不可用：缺少${missing.join('、')}。` +
        '缺口必须是「需求」与「实际供给」两侧的差，只有一侧时任何差值都会是凭空造出的，故本区块不给出任何缺口数值。',
      data: null,
      inputs: [
        probe('DSD', 'primary', demandOverall !== null, demandOverall ? null : '问卷未包含数字化服务需求矩阵题（Q49）。'),
        probe('PSA', 'primary', awareness !== null, awareness ? null : '问卷未包含公共服务知晓与可及题（Q43、Q44）。'),
        probe('PSU', 'primary', use !== null, use ? null : '问卷未包含公共服务使用与评价题（Q45、Q46）。'),
      ],
      evidence: evidence.list(),
    };
  }

  const gaps: ServiceGapData['gaps'] = [];
  if (awareness) {
    const value = round2(demandOverall.mean - awareness.mean);
    gaps.push({
      id: 'demand_minus_awareness',
      label: '需求高于「知晓与可及」的幅度',
      formula: `DSD（${displayNumber(demandOverall.mean)}）− PSA（${displayNumber(awareness.mean)}）= ${displayNumber(value)}`,
      value,
      note: '两侧均为 1—5 均值，但锚点不同（需求程度 vs 同意/便利程度），故该差值只用于方向判断与内部排序。',
    });
  }
  if (use) {
    const value = round2(demandOverall.mean - use.mean);
    gaps.push({
      id: 'demand_minus_use',
      label: '需求高于「使用与评价」的幅度',
      formula: `DSD（${displayNumber(demandOverall.mean)}）− PSU（${displayNumber(use.mean)}）= ${displayNumber(value)}`,
      value,
      note: 'PSU 混合了使用频次与满意度，读数偏低既可能来自「没使用过」，也可能来自「用过但不满意」。',
    });
  }
  if (awareness && use) {
    const value = round2(awareness.mean - use.mean);
    gaps.push({
      id: 'awareness_to_use_break',
      label: '知晓—使用链条的落差（知晓高于使用）',
      formula: `PSA（${displayNumber(awareness.mean)}）− PSU（${displayNumber(use.mean)}）= ${displayNumber(value)}`,
      value,
      note: '这是「知道但没用」的量化迹象，但 PSA 与 PSU 的锚点不同，且 PSU 含评价成分，需结合定性材料判断断点位置。',
    });
  }

  let largestContrast: ServiceGapData['largest_item_contrast'] = null;
  const provisionBaseline = use?.mean ?? awareness?.mean ?? null;
  const strongestDemand = demandItems.reduce<VariableReading | null>(
    (best, item) => (best === null || (item.mean ?? 0) > (best.mean ?? 0) ? item : best),
    null,
  );
  if (strongestDemand && strongestDemand.mean !== null && provisionBaseline !== null) {
    largestContrast = {
      variable: strongestDemand.variable,
      label: strongestDemand.label,
      demand_mean: strongestDemand.mean,
      provision_mean: provisionBaseline,
      gap: round2(strongestDemand.mean - provisionBaseline),
    };
  }

  const metric =
    '缺口指标 = 需求均值 − 供给链条均值（同一 1—5 量表内的均值差，取两位小数）。' +
    '由于需求、知晓、使用三类题目的作答锚点不同，所有缺口值只用于方向判断与内部排序，不代表可比的数量差距。';

  const data: ServiceGapData = {
    metric,
    demand: {
      overall: {
        variable: 'DSD',
        label: demandOverall.stats.label,
        data_type: demandOverall.stats.data_type,
        n: demandOverall.stats.n,
        mean: demandOverall.mean,
      },
      items: demandItems,
    },
    provision: {
      awareness_access: awareness
        ? {
            variable: 'PSA',
            label: awareness.stats.label,
            data_type: awareness.stats.data_type,
            n: awareness.stats.n,
            mean: awareness.mean,
          }
        : null,
      use_evaluation: use
        ? {
            variable: 'PSU',
            label: use.stats.label,
            data_type: use.stats.data_type,
            n: use.stats.n,
            mean: use.mean,
          }
        : null,
    },
    gaps,
    largest_item_contrast: largestContrast,
    caveat:
      '「缺口」在本报告里是一个测量口径内的均值差，不是供给不足的因果证明：' +
      '需求高也可能因为家长对新服务天然更期待，使用低也可能因为样本中本就没有符合条件的使用场景。',
  };

  const gapProse = gaps.map((gap) => `${gap.label}：${gap.formula}`).join('；');
  const demandItemProse = demandItems
    .map((item) => `${item.label} ${displayNumber(item.mean ?? 0)}（n = ${displayNumber(item.n)}）`)
    .join('、');

  return {
    key: 'service_gap',
    order: 4,
    title: INSIGHT_BLOCK_TITLES.service_gap,
    available: true,
    reason: null,
    narrative:
      `缺口指标为同一 1—5 量表上的均值差。需求侧 DSD 均值 ${displayNumber(demandOverall.mean)}` +
      `（n = ${displayNumber(demandOverall.n)}）` +
      (strongestDemand && strongestDemand.mean !== null
        ? `，其中需求最高的一项是「${strongestDemand.label}」${displayNumber(strongestDemand.mean)}（n = ${displayNumber(strongestDemand.n)}）`
        : '') +
      (demandItemProse ? `；需求分项：${demandItemProse}` : '') +
      '；供给侧 ' +      (awareness ? `PSA 均值 ${displayNumber(awareness.mean)}（n = ${displayNumber(awareness.n)}）` : 'PSA 未被测量') +
      '，' +
      (use ? `PSU 均值 ${displayNumber(use.mean)}（n = ${displayNumber(use.n)}）` : 'PSU 未被测量') +
      `。缺口测算：${gapProse}。` +
      (largestContrast
        ? `最突出的单项对比：「${largestContrast.label}」的需求（${displayNumber(largestContrast.demand_mean)}）` +
          `高出供给侧基准（${displayNumber(largestContrast.provision_mean)}）${displayNumber(largestContrast.gap)}。`
        : '') +
      metric +
      data.caveat,
    data,
    inputs: [
      probe('DSD', 'primary', true, null),
      probe('PSA', 'primary', awareness !== null, awareness ? null : '问卷未包含公共服务知晓与可及题（Q43、Q44）。'),
      probe('PSU', 'primary', use !== null, use ? null : '问卷未包含公共服务使用与评价题（Q45、Q46）。'),
    ],
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 5 — 产品需求                                                  */
/* ------------------------------------------------------------------ */

function buildProductDemand(inputs: InsightInputs): InsightBlock<'product_demand', ProductDemandData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const overall = readMean(store, 'DSD');
  const items: ProductDemandData['items'] = [];

  if (overall) {
    evidence.addReading(store, 'DSD');
    for (const variable of itemsOf(dataset, 'DSD')) {
      const reading = readMean(store, variable.name);
      if (!reading) continue;
      evidence.addReading(store, variable.name);
      items.push({
        rank: 0,
        variable: variable.name,
        label: reading.stats.label,
        mean: reading.mean,
        n: reading.stats.n,
        above_scale_midpoint: reading.mean > SCALE_MIDPOINT,
      });
    }
  }

  items.sort((left, right) => right.mean - left.mean || left.variable.localeCompare(right.variable));
  items.forEach((item, index) => {
    item.rank = index + 1;
  });

  const available = overall !== null && items.length > 0;

  const wtpfStats = store.get('WTPF');
  const breadthOnly = wtpfStats
    ? {
        variable: 'WTPF',
        label: wtpfStats.label,
        note:
          'WTPF 为「愿意为哪类服务付费」的多选题，统计引擎按选项数量聚合，' +
          '因此只能报告付费服务广度，不能报告各服务类型的付费占比。',
      }
    : null;
  // No numeric claim is made from WTPF, so no evidence entry is recorded for it:
  // a count-rule mean of a multi-select question is not a share of anything.

  const textVariables = dataset.variables.filter((variable) => variable.data_type === 'text');
  const qualitative = {
    available: textVariables.length > 0,
    note:
      textVariables.length > 0
        ? `问卷包含 ${displayNumber(textVariables.length)} 道开放式文字题（${textVariables
            .map((variable) => variable.name)
            .join('、')}），其内容未纳入本次统计，产品需求排序仅基于量表题。`
        : '问卷不含开放式文字题，因此没有可用于补充产品需求的定性材料。',
  };

  const rankingProse = items
    .map(
      (item) =>
        `${item.rank}. ${item.label}（${item.variable}）需求均值 ${displayNumber(item.mean)}，n = ${displayNumber(item.n)}`,
    )
    .join('；');

  const narrative = available
    ? `数字化服务需求按条目均值从高到低排序（1—5 需求程度，中位点 ${displayNumber(SCALE_MIDPOINT)}）：${rankingProse}。` +
      `总体需求均值 ${displayNumber(overall.mean)}（n = ${displayNumber(overall.n)}）。` +
      `排序全部来自本次测量的条目均值。${breadthOnly ? breadthOnly.note : '问卷未测量「愿意为哪类服务付费」的多选题。'}` +
      qualitative.note
    : '本区块不可用：问卷未测量数字化家庭教育服务需求（Q49，变量 DSD），无法排序产品需求，' +
      '也不以行业报告或其他项目的需求排序代替。';

  const data: ProductDemandData | null = available
    ? {
        metric: '1—5 需求程度条目均值（数值越高需求越强）；中位点 3 为「一般」。',
        overall: {
          variable: 'DSD',
          label: overall.stats.label,
          data_type: overall.stats.data_type,
          n: overall.stats.n,
          mean: overall.mean,
        },
        items,
        scale_midpoint: SCALE_MIDPOINT,
        breadth_only: breadthOnly,
        qualitative_material: qualitative,
        note:
          '条目均值来自矩阵题 Q49 的每一行；矩阵题的维度均值（DSD）同时报告，但不与其条目一起排序，以免重复计数。',
      }
    : null;

  return {
    key: 'product_demand',
    order: 5,
    title: INSIGHT_BLOCK_TITLES.product_demand,
    available,
    reason: available ? null : '问卷未包含数字化家庭教育服务需求矩阵题（Q49，变量 DSD），无法给出产品需求排序。',
    narrative,
    data,
    inputs: [
      probe('DSD', 'primary', available, available ? null : '问卷未包含数字化服务需求矩阵题（Q49）。'),
      probe('WTPF', 'supporting', breadthOnly !== null, breadthOnly ? null : '问卷未包含付费服务类型的多选题（Q55）。'),
    ],
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 6 — 信任                                                      */
/* ------------------------------------------------------------------ */

function buildTrust(inputs: InsightInputs): InsightBlock<'trust', TrustData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const overall = readMean(store, 'STI');
  const providers: TrustData['providers'] = [];

  if (overall) {
    evidence.addReading(store, 'STI');
    for (const variable of itemsOf(dataset, 'STI')) {
      const reading = readMean(store, variable.name);
      if (!reading) continue;
      evidence.addReading(store, variable.name);
      providers.push({
        rank: 0,
        variable: variable.name,
        label: reading.stats.label,
        mean: reading.mean,
        n: reading.stats.n,
      });
    }
  }

  providers.sort((left, right) => right.mean - left.mean || left.variable.localeCompare(right.variable));
  providers.forEach((provider, index) => {
    provider.rank = index + 1;
  });

  const available = overall !== null && providers.length > 0;

  const aiEntry = providers.find((provider) => provider.variable === 'STI6') ?? null;
  const aiAssistant = aiEntry
    ? {
        variable: aiEntry.variable,
        label: aiEntry.label,
        mean: aiEntry.mean,
        n: aiEntry.n,
        rank: aiEntry.rank,
        of: providers.length,
      }
    : null;

  /* Adoption link: trust only matters commercially if it moves demand or intention. */
  const pair = findPair(bundle, 'STI', 'DSD');
  const pairRefs = pair ? pairEvidence(bundle, pair) : null;
  const regressionCoefficients = bundle.regression?.ols?.coefficients ?? [];
  const stiCoefficient = regressionCoefficients.find((coefficient) => coefficient.term === 'STI') ?? null;
  const hypothesis = findHypothesis(bundle, 'H5');
  const hypothesisUsable = hypothesis !== null && hypothesis.verdict !== 'untestable';

  const pairsOut: TrustData['adoption_link']['pairs'] = [];
  if (pair && pairRefs && pair.r !== null && pair.p_value !== null) {
    evidence.add(pairRefs.r.path, pairRefs.r.value);
    evidence.add(pairRefs.p.path, pairRefs.p.value);
    pairsOut.push({
      left: pair.left,
      right: pair.right,
      r: pair.r,
      p_value: pair.p_value,
      method: pair.method,
      n: pair.n,
    });
  }

  const regressionOut: TrustData['adoption_link']['regression'] = [];
  if (stiCoefficient && bundle.regression?.ols) {
    evidence.add('regression.ols.coefficients[STI].b', stiCoefficient.b);
    evidence.add('regression.ols.coefficients[STI].p_value', stiCoefficient.p_value);
    regressionOut.push({
      term: stiCoefficient.term,
      model: 'ols',
      b: stiCoefficient.b,
      p_value: stiCoefficient.p_value,
    });
  }

  if (hypothesisUsable && hypothesis) {
    evidence.add(`hypotheses.results[H5].r`, hypothesis.r);
    evidence.add(`hypotheses.results[H5].p_value`, hypothesis.p_value);
    evidence.add(`hypotheses.results[H5].verdict`, hypothesis.verdict);
  }

  const adoptionAvailable = pairsOut.length > 0 || regressionOut.length > 0 || hypothesisUsable;
  const adoptionReason = adoptionAvailable
    ? null
    : '结果包中没有信任与需求/使用意愿的相关或回归结果（变量不足、样本不足或未运行相应分析），' +
      '因此本区块只呈现信任排序，不声称信任会影响采用。';

  const data: TrustData = {
    overall: {
      variable: 'STI',
      label: overall?.stats.label ?? '服务主体信任度',
      data_type: overall?.stats.data_type ?? 'interval',
      n: overall?.stats.n ?? 0,
      mean: overall?.mean ?? null,
    },
    providers,
    ai_assistant: aiAssistant,
    adoption_link: {
      available: adoptionAvailable,
      reason: adoptionReason,
      pairs: pairsOut,
      regression: regressionOut,
      hypothesis: hypothesisView(hypothesis),
    },
    prerequisite_statement:
      '信任在本报告的框架中是采用的前置条件：家长对服务主体的信任水平决定了他们是否愿意把孩子的教育问题交给该主体，' +
      '因此信任排序用于判断「谁能先把服务交付出去」，而需求排序用于判断「交付什么」。' +
      '前置条件关系是否成立，取决于上方引用的统计结果，而不是本段文字。',
  };

  const rankingProse = providers
    .map(
      (provider) =>
        `${provider.rank}. ${provider.label}（${provider.variable}）${displayNumber(provider.mean)}，n = ${displayNumber(provider.n)}`,
    )
    .join('；');

  const adoptionProse = adoptionAvailable
    ? `信任与需求/采用的关系：` +
      (pairsOut.length > 0
        ? `STI × ${pairsOut[0]!.right} 相关 r = ${displayNumber(pairsOut[0]!.r)}（p = ${displayP(pairsOut[0]!.p_value)}，n = ${displayNumber(pairsOut[0]!.n)}，方法 ${pairsOut[0]!.method}）；`
        : '未报告相关结果；') +
      (regressionOut.length > 0
        ? `OLS 模型中 STI 的系数 B = ${displayNumber(regressionOut[0]!.b)}（p = ${displayP(regressionOut[0]!.p_value)}）；`
        : '') +
      (hypothesisUsable && hypothesis
        ? `假设 H5 的结论为「${hypothesis.verdict}」，r = ${hypothesis.r === null ? '未报告' : displayNumber(hypothesis.r)}，p = ${displayP(hypothesis.p_value)}。` +
          `引擎原文：${hypothesis.conclusion}`
        : '')
    : adoptionReason ?? '';

  const narrative = available
    ? `信任度按六类服务主体的测量值排序（1—5，数值越高越信任）：${rankingProse}。` +
      `总体信任均值 ${overall ? displayNumber(overall.mean) : '未报告'}（n = ${overall ? displayNumber(overall.n) : '0'}）。` +
      (aiAssistant
        ? `其中 AI 智能助手（${aiAssistant.variable}）为 ${aiAssistant.label}，均值 ${displayNumber(aiAssistant.mean)}（n = ${displayNumber(aiAssistant.n)}），` +
          `在 ${displayNumber(aiAssistant.of)} 类主体中排第 ${displayNumber(aiAssistant.rank)} 位；` +
          '它是「AI 服务能否被接受」的直接前置指标，单独列出而不并入总体均值解读。'
        : '问卷未单独测量对 AI 智能助手的信任（STI6）。') +
      adoptionProse +
      data.prerequisite_statement
    : '本区块不可用：问卷未测量服务主体信任度（Q48，变量 STI），无法给出信任排序，' +
      '也不以其他研究的信任数据替代。';

  return {
    key: 'trust',
    order: 6,
    title: INSIGHT_BLOCK_TITLES.trust,
    available,
    reason: available ? null : '问卷未包含服务主体信任矩阵题（Q48，变量 STI），无法给出信任排序。',
    narrative,
    data: available ? data : null,
    inputs: [
      probe('STI', 'primary', available, available ? null : '问卷未包含服务主体信任矩阵题（Q48）。'),
      probe('STI6', 'supporting', aiAssistant !== null, aiAssistant ? null : '问卷未包含对 AI 智能助手的信任条目（第 6 行）。'),
      probe('DSD', 'supporting', pair !== null, pair ? null : '结果包中没有 STI × DSD 相关结果。'),
      probe('regression.ols', 'supporting', regressionOut.length > 0, regressionOut.length > 0 ? null : '结果包中没有 OLS 回归结果。'),
    ],
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 7 — AI 接受度                                                 */
/* ------------------------------------------------------------------ */

function buildAiAcceptance(inputs: InsightInputs): InsightBlock<'ai_acceptance', AiAcceptanceData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const uiStats = store.get('UI');
  const uiCategories = uiStats ? readCategories(store, 'UI') : null;
  let intention: AiAcceptanceData['intention'] = null;
  if (uiStats && uiStats.n > 0) {
    evidence.add(`descriptive.variables[UI].mean`, uiStats.mean);
    evidence.add(`descriptive.variables[UI].n`, uiStats.n);
    if (uiCategories) {
      uiCategories.forEach((category, index) => {
        evidence.add(`descriptive.variables[UI].frequencies[${index}].count`, category.count);
        evidence.add(`descriptive.variables[UI].frequencies[${index}].percent`, category.percent);
      });
    }
    intention = {
      outcome: {
        variable: 'UI',
        label: uiStats.label,
        data_type: uiStats.data_type,
        n: uiStats.n,
        mean: uiStats.mean,
      },
      data_type: uiStats.data_type,
      distribution: uiCategories ?? [],
      mean_reference: uiStats.mean,
      scale_note:
        'UI 为有序分类变量（1—5）。统计引擎将其作为有序结果建模，本报告以类别分布为主要呈现，' +
        '均值仅作汇总参考；1—5 只是等级编码，不能当作等距刻度来解读差距。',
    };
  }

  const aipvStats = store.get('AIPV');
  let perceivedValue: AiAcceptanceData['perceived_value'] = null;
  if (aipvStats && aipvStats.n > 0) {
    evidence.add(`descriptive.variables[AIPV].mean`, aipvStats.mean);
    evidence.add(`descriptive.variables[AIPV].n`, aipvStats.n);
    const categories = readCategories(store, 'AIPV');
    if (categories) {
      categories.forEach((category, index) => {
        evidence.add(`descriptive.variables[AIPV].frequencies[${index}].count`, category.count);
        evidence.add(`descriptive.variables[AIPV].frequencies[${index}].percent`, category.percent);
      });
    }
    perceivedValue = {
      variable: 'AIPV',
      label: aipvStats.label,
      data_type: aipvStats.data_type,
      n: aipvStats.n,
      mean: aipvStats.mean,
      distribution: categories,
    };
  }

  const prcOverall = readMean(store, 'PRC');
  const riskItems: VariableReading[] = [];
  let risk: AiAcceptanceData['risk'] = null;
  if (prcOverall) {
    evidence.addReading(store, 'PRC');
    for (const variable of itemsOf(dataset, 'PRC')) {
      const reading = readMean(store, variable.name);
      if (!reading) continue;
      evidence.addReading(store, variable.name);
      riskItems.push({
        variable: variable.name,
        label: reading.stats.label,
        data_type: reading.stats.data_type,
        n: reading.stats.n,
        mean: reading.mean,
      });
    }
    risk = {
      overall: {
        variable: 'PRC',
        label: prcOverall.stats.label,
        data_type: prcOverall.stats.data_type,
        n: prcOverall.stats.n,
        mean: prcOverall.mean,
      },
      items: riskItems,
    };
  }

  /* Modelling framing comes from the bundle, never from an assumption here. */
  const autoSelection = bundle.regression?.auto_selection ?? null;
  const ordinalCoefficients = bundle.regression?.ordinal?.coefficients ?? [];
  const olsCoefficients = (bundle.regression?.ols?.coefficients ?? []).filter(
    (coefficient) => coefficient.term !== '(常量)',
  );
  const primaryModel = autoSelection?.model === 'ordinal_logit' ? 'ordinal_logit' : 'ols';
  const drivers: AiAcceptanceData['modelling']['drivers'] = [];

  if (ordinalCoefficients.length > 0) {
    for (const coefficient of ordinalCoefficients) {
      evidence.add(`regression.ordinal.coefficients[${coefficient.term}].b`, coefficient.b);
      evidence.add(`regression.ordinal.coefficients[${coefficient.term}].p_value`, coefficient.p_value);
      drivers.push({
        model: 'ordinal_logit',
        term: coefficient.term,
        b: coefficient.b,
        p_value: coefficient.p_value,
        significant: coefficient.p_value < 0.05,
      });
    }
  } else {
    for (const coefficient of olsCoefficients) {
      evidence.add(`regression.ols.coefficients[${coefficient.term}].b`, coefficient.b);
      evidence.add(`regression.ols.coefficients[${coefficient.term}].p_value`, coefficient.p_value);
      drivers.push({
        model: 'ols',
        term: coefficient.term,
        b: coefficient.b,
        p_value: coefficient.p_value,
        significant: coefficient.p_value < 0.05,
      });
    }
  }

  if (autoSelection) evidence.add('regression.auto_selection.model', autoSelection.model);

  const riskHypothesis = findHypothesis(bundle, 'H7');
  let riskLink: AiAcceptanceData['risk_link'] = null;
  if (riskHypothesis && riskHypothesis.verdict !== 'untestable') {
    evidence.add('hypotheses.results[H7].r', riskHypothesis.r);
    evidence.add('hypotheses.results[H7].p_value', riskHypothesis.p_value);
    evidence.add('hypotheses.results[H7].verdict', riskHypothesis.verdict);
    riskLink = {
      hypothesis_code: riskHypothesis.code,
      verdict: riskHypothesis.verdict,
      r: riskHypothesis.r,
      p_value: riskHypothesis.p_value,
      n: riskHypothesis.n,
      note: riskHypothesis.conclusion,
    };
  }

  const available = intention !== null || perceivedValue !== null || risk !== null;
  const missingParts: string[] = [];
  if (!intention) missingParts.push('使用意愿 UI（Q50）');
  if (!perceivedValue) missingParts.push('感知价值 AIPV（Q52）');
  if (!risk) missingParts.push('风险认知 PRC（Q51）');

  const distributionProse = intention
    ? intention.distribution
        .map((category) => `${category.label} ${displayNumber(category.count)} 人（${displayNumber(category.percent)}%）`)
        .join('、')
    : '';
  const prcProse = risk
    ? risk.items
        .map((item) => `${item.label} ${displayNumber(item.mean ?? 0)}（n = ${displayNumber(item.n)}）`)
        .join('、')
    : '';
  const driverProse = drivers.length
    ? drivers
        .map(
          (driver) =>
            `${driver.term} B = ${displayNumber(driver.b)}（p = ${displayP(driver.p_value)}${driver.significant ? '，显著' : '，不显著'}）`,
        )
        .join('、')
    : '结果包中没有可用的回归系数。';

  const narrative = available
    ? (intention
        ? `AI 使用意愿（UI）分布（n = ${displayNumber(intention.outcome.n)}）：${distributionProse}；` +
          `汇总均值参考值 ${intention.mean_reference === null ? '未报告' : displayNumber(intention.mean_reference)}。`
        : '问卷未测量 AI 使用意愿（UI）。') +
      (perceivedValue
        ? `感知价值 AIPV 均值 ${displayNumber(perceivedValue.mean ?? 0)}（n = ${displayNumber(perceivedValue.n)}）。`
        : '问卷未测量感知价值（AIPV）。') +
      (risk
        ? `风险认知 PRC 总体均值 ${displayNumber(risk.overall.mean ?? 0)}（n = ${displayNumber(risk.overall.n)}），分项：${prcProse}。`
        : '问卷未测量风险认知（PRC）。') +
      `建模口径：${autoSelection ? `引擎自动选择 ${autoSelection.model}` : '结果包中没有回归结果'}；` +
      `对使用意愿的系数为 ${driverProse}` +
      (riskLink
        ? `风险认知与使用意愿的关系（假设 ${riskLink.hypothesis_code}）：${riskLink.verdict}，r = ${riskLink.r === null ? '未报告' : displayNumber(riskLink.r)}，p = ${displayP(riskLink.p_value)}。` +
          '若结论为「证据不足」，这只表示本次样本未能提供证据，不等于证明风险认知与使用意愿无关。'
        : '') +
      (intention ? intention.scale_note : '')
    : `本区块不可用：问卷未测量${missingParts.join('、')}，因此不给出 AI 接受度结论，也不以「0」或行业默认值填充。`;

  const data: AiAcceptanceData | null = available
    ? {
        intention,
        perceived_value: perceivedValue,
        risk,
        modelling: {
          auto_selected_model: autoSelection?.model ?? null,
          ordinal_available: Boolean(bundle.regression?.ordinal),
          ols_available: Boolean(bundle.regression?.ols),
          drivers,
          note:
            '系数与 p 值全部来自结果包；当引擎判定因变量为有序变量时，本报告以有序 Logistic 结果为准，' +
            '线性回归结果保留为对照，不作为主要依据。',
        },
        risk_link: riskLink,
      }
    : null;

  return {
    key: 'ai_acceptance',
    order: 7,
    title: INSIGHT_BLOCK_TITLES.ai_acceptance,
    available,
    reason: available ? null : `问卷未测量${missingParts.join('、')}，无法评估 AI 接受度。`,
    narrative,
    data,
    inputs: [
      probe('UI', 'primary', intention !== null, intention ? null : '问卷未包含 AI 使用意愿题（Q50）。'),
      probe('AIPV', 'primary', perceivedValue !== null, perceivedValue ? null : '问卷未包含 AI 感知价值题（Q52）。'),
      probe('PRC', 'primary', risk !== null, risk ? null : '问卷未包含 AI 风险认知矩阵题（Q51）。'),
      probe('regression', 'supporting', drivers.length > 0, drivers.length > 0 ? null : '结果包中没有以 UI 为因变量的回归结果。'),
    ],
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 8 — 付费意愿                                                  */
/* ------------------------------------------------------------------ */

function buildWillingnessToPay(
  inputs: InsightInputs,
): InsightBlock<'willingness_to_pay', WtpData> {
  const { bundle } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const wtpStats = store.get('WTP');
  const wtpCategories = wtpStats ? readCategories(store, 'WTP') : null;
  let willingness: WtpData['willingness'] = null;
  if (wtpStats && wtpStats.n > 0) {
    evidence.add('descriptive.variables[WTP].mean', wtpStats.mean);
    evidence.add('descriptive.variables[WTP].n', wtpStats.n);
    if (wtpCategories) {
      wtpCategories.forEach((category, index) => {
        evidence.add(`descriptive.variables[WTP].frequencies[${index}].count`, category.count);
        evidence.add(`descriptive.variables[WTP].frequencies[${index}].percent`, category.percent);
      });
    }
    willingness = {
      outcome: {
        variable: 'WTP',
        label: wtpStats.label,
        data_type: wtpStats.data_type,
        n: wtpStats.n,
        mean: wtpStats.mean,
      },
      data_type: wtpStats.data_type,
      distribution: wtpCategories ?? [],
      mean_reference: wtpStats.mean,
      scale_note:
        'WTP 为有序分类变量（1—5 的愿意程度）。1—5 只是等级编码，不能按等距刻度解读；' +
        '本报告以类别分布为主要呈现。',
    };
  }

  const wtpaStats = store.get('WTPA');
  const wtpaCategories = wtpaStats ? readCategories(store, 'WTPA') : null;
  let amountBand: WtpData['amount_band'] = null;
  if (wtpaStats && wtpaStats.n > 0 && wtpaCategories) {
    evidence.add('descriptive.variables[WTPA].n', wtpaStats.n);
    wtpaCategories.forEach((category, index) => {
      evidence.add(`descriptive.variables[WTPA].frequencies[${index}].count`, category.count);
      evidence.add(`descriptive.variables[WTPA].frequencies[${index}].percent`, category.percent);
    });
    amountBand = {
      variable: 'WTPA',
      label: wtpaStats.label,
      distribution: wtpaCategories,
      note:
        '这是分档的「最多愿意支付」选项分布，属于声称偏好。' +
        '本报告不使用区间中值换算金额、不乘以任何人数推算收入：区间中值不是测量值，' +
        '这样的乘法会把一个意愿分布变成一个看似精确的营收数字。',
    };
  }

  const pair = findPair(bundle, 'DSD', 'WTP');
  const pairRefs = pair ? pairEvidence(bundle, pair) : null;
  let pairOut: WtpData['demand_link']['pair'] = null;
  if (pair && pairRefs && pair.r !== null && pair.p_value !== null) {
    evidence.add(pairRefs.r.path, pairRefs.r.value);
    evidence.add(pairRefs.p.path, pairRefs.p.value);
    pairOut = {
      left: pair.left,
      right: pair.right,
      r: pair.r,
      p_value: pair.p_value,
      method: pair.method,
      n: pair.n,
    };
  }

  const hypothesis = findHypothesis(bundle, 'H8');
  const hypothesisUsable = hypothesis !== null && hypothesis.verdict !== 'untestable';
  if (hypothesisUsable && hypothesis) {
    evidence.add('hypotheses.results[H8].r', hypothesis.r);
    evidence.add('hypotheses.results[H8].p_value', hypothesis.p_value);
    evidence.add('hypotheses.results[H8].verdict', hypothesis.verdict);
  }

  const demandLinkAvailable = pairOut !== null || hypothesisUsable;
  const demandLinkReason = demandLinkAvailable
    ? null
    : '结果包中没有需求（DSD）与付费意愿（WTP）的相关或假设检验结果，因此本区块只呈现付费意愿分布，不声称需求会转化为付费。';

  const purchaseCaveat =
    '付费意愿是问卷中的声称（stated preference），不是观察到的购买行为：回答者没有实际支付，' +
    '也没有面对价格、替代方案与支付摩擦。因此本区块的分布不能读作付费转化率或收入，' +
    '任何据此推算的市场规模都会把意愿当成成交。';

  const available = willingness !== null || amountBand !== null;
  const missingParts: string[] = [];
  if (!willingness) missingParts.push('付费意愿 WTP（Q53）');
  if (!amountBand) missingParts.push('支付区间 WTPA（Q54）');

  const distributionProse = willingness
    ? willingness.distribution
        .map((category) => `${category.label} ${displayNumber(category.count)} 人（${displayNumber(category.percent)}%）`)
        .join('、')
    : '';
  const amountProse = amountBand
    ? amountBand.distribution
        .map((category) => `${category.label} ${displayNumber(category.count)} 人（${displayNumber(category.percent)}%）`)
        .join('、')
    : '';

  const data: WtpData | null = available
    ? {
        willingness,
        amount_band: amountBand,
        demand_link: {
          available: demandLinkAvailable,
          reason: demandLinkReason,
          pair: pairOut,
          hypothesis: hypothesisView(hypothesis),
        },
        purchase_behaviour_caveat: purchaseCaveat,
      }
    : null;

  const narrative = available
    ? (willingness
        ? `付费意愿（WTP）分布（n = ${displayNumber(willingness.outcome.n)}）：${distributionProse}；` +
          `汇总均值参考值 ${willingness.mean_reference === null ? '未报告' : displayNumber(willingness.mean_reference)}。`
        : '问卷未测量付费意愿（WTP）。') +
      (amountBand
        ? `最多愿意支付的区间（WTPA，n = ${displayNumber(wtpaStats?.n ?? 0)}）：${amountProse}。${amountBand.note}`
        : '问卷未测量最多愿意支付的金额区间（WTPA）。') +
      (demandLinkAvailable
        ? `需求与付费意愿的关系：` +
          (pairOut
            ? `DSD × WTP 相关 r = ${displayNumber(pairOut.r)}（p = ${displayP(pairOut.p_value)}，n = ${displayNumber(pairOut.n)}，方法 ${pairOut.method}）；`
            : '未报告相关结果；') +
          (hypothesisUsable && hypothesis
            ? `假设 H8 的结论为「${hypothesis.verdict}」，r = ${hypothesis.r === null ? '未报告' : displayNumber(hypothesis.r)}，p = ${displayP(hypothesis.p_value)}。引擎原文：${hypothesis.conclusion}`
            : '')
        : demandLinkReason ?? '') +
      purchaseCaveat
    : `本区块不可用：问卷未测量${missingParts.join('、')}，因此不给出付费意愿结论，也不以行业客单价或默认付费率代替。`;

  return {
    key: 'willingness_to_pay',
    order: 8,
    title: INSIGHT_BLOCK_TITLES.willingness_to_pay,
    available,
    reason: available ? null : `问卷未测量${missingParts.join('、')}，无法评估付费意愿。`,
    narrative,
    data,
    inputs: [
      probe('WTP', 'primary', willingness !== null, willingness ? null : '问卷未包含付费意愿题（Q53）。'),
      probe('WTPA', 'supporting', amountBand !== null, amountBand ? null : '问卷未包含支付区间题（Q54）。'),
      probe('DSD', 'supporting', pairOut !== null, pairOut ? null : '结果包中没有 DSD × WTP 相关结果。'),
    ],
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Block 9 — 市场机会                                                  */
/* ------------------------------------------------------------------ */

function buildMarketOpportunity(
  inputs: InsightInputs,
): InsightBlock<'market_opportunity', MarketOpportunityData> {
  const { bundle, dataset } = inputs;
  const store = descriptiveIndex(bundle);
  const evidence = new EvidenceBag();

  const drivers: MarketDriver[] = [];
  const notConfirmed: MarketOpportunityData['not_confirmed'] = [];

  /* Regression: the engine's own model choice decides which coefficients count. */
  const autoSelection = bundle.regression?.auto_selection ?? null;
  const ordinalCoefficients = bundle.regression?.ordinal?.coefficients ?? [];
  const olsCoefficients = (bundle.regression?.ols?.coefficients ?? []).filter(
    (coefficient) => coefficient.term !== '(常量)',
  );

  if (autoSelection) evidence.add('regression.auto_selection.model', autoSelection.model);

  if (ordinalCoefficients.length > 0) {
    for (const coefficient of ordinalCoefficients) {
      evidence.add(`regression.ordinal.coefficients[${coefficient.term}].b`, coefficient.b);
      evidence.add(`regression.ordinal.coefficients[${coefficient.term}].p_value`, coefficient.p_value);
      const significant = coefficient.p_value < 0.05;
      const entry = {
        source: 'ordinal_logit' as const,
        name: coefficient.term,
        statistic: `有序 Logistic 系数 B = ${displayNumber(coefficient.b)}（OR = ${displayNumber(
          Math.round(coefficient.odds_ratio * 10000) / 10000,
        )}）`,
        value: coefficient.b,
        p_value: coefficient.p_value,
        effect: null,
        note: significant
          ? `在有序模型中与使用意愿显著相关（p = ${displayP(coefficient.p_value)}），方向为${coefficient.b > 0 ? '正向' : '负向'}。`
          : `在有序模型中未达显著（p = ${displayP(coefficient.p_value)}），不作为机会假设的证据。`,
      };
      if (significant) drivers.push(entry);
      else
        notConfirmed.push({
          name: coefficient.term,
          statistic: entry.statistic,
          value: coefficient.b,
          p_value: coefficient.p_value,
          verdict: null,
          note: entry.note,
        });
    }
  }

  if (olsCoefficients.length > 0 && ordinalCoefficients.length === 0) {
    for (const coefficient of olsCoefficients) {
      evidence.add(`regression.ols.coefficients[${coefficient.term}].b`, coefficient.b);
      evidence.add(`regression.ols.coefficients[${coefficient.term}].p_value`, coefficient.p_value);
      const significant = coefficient.p_value < 0.05;
      const note = significant
        ? `在线性模型中显著（p = ${displayP(coefficient.p_value)}），标准化系数 β = ${coefficient.beta === null ? '未报告' : displayNumber(coefficient.beta)}。`
        : `在线性模型中未达显著（p = ${displayP(coefficient.p_value)}），不作为机会假设的证据。`;
      if (significant) {
        drivers.push({
          source: 'ols',
          name: coefficient.term,
          statistic: `OLS 系数 B = ${displayNumber(coefficient.b)}${coefficient.beta === null ? '' : `（β = ${displayNumber(coefficient.beta)}）`}`,
          value: coefficient.b,
          p_value: coefficient.p_value,
          effect: coefficient.beta === null ? null : `标准化系数 β = ${displayNumber(coefficient.beta)}`,
          note,
        });
      } else {
        notConfirmed.push({
          name: coefficient.term,
          statistic: `OLS 系数 B = ${displayNumber(coefficient.b)}`,
          value: coefficient.b,
          p_value: coefficient.p_value,
          verdict: null,
          note,
        });
      }
    }
  }

  /* Correlations: reported with the engine's own effect-size judgement. */
  const pairNames: [string, string][] = [
    ['DSD', 'UI'],
    ['STI', 'DSD'],
    ['PSA', 'UI'],
    ['DSD', 'WTP'],
    ['FED', 'DSD'],
  ];
  for (const [left, right] of pairNames) {
    const pair = findPair(bundle, left, right);
    if (!pair || pair.r === null || pair.p_value === null) continue;
    const base = `correlation.pairs[left=${pair.left},right=${pair.right}]`;
    evidence.add(`${base}.r`, pair.r);
    evidence.add(`${base}.p_value`, pair.p_value);
    const significant = pair.p_value < 0.05;
    const effect = describeEffect(pair.effective_size);
    const record = {
      name: `${pair.left} × ${pair.right}`,
      statistic: `${pair.method === 'pearson' ? 'Pearson' : 'Spearman'} r = ${displayNumber(pair.r)}（n = ${displayNumber(pair.n)}）`,
      value: pair.r,
      p_value: pair.p_value,
      verdict: null,
      note: significant
        ? `相关显著（p = ${displayP(pair.p_value)}）${effect ? `；${effect}` : ''}。相关不等于因果。`
        : `相关未达显著（p = ${displayP(pair.p_value)}），证据不足，不能据此认为两者无关。`,
    };
    if (significant) {
      drivers.push({
        source: 'correlation',
        name: record.name,
        statistic: record.statistic,
        value: pair.r,
        p_value: pair.p_value,
        effect,
        note: record.note,
      });
    } else {
      notConfirmed.push(record);
    }
  }

  /* Hypotheses carry a three-state verdict; only "supported" counts as a driver. */
  for (const result of bundle.hypotheses.results) {
    if (result.verdict === 'untestable') continue;
    if (result.r === null || result.p_value === null) continue;
    evidence.add(`hypotheses.results[${result.code}].r`, result.r);
    evidence.add(`hypotheses.results[${result.code}].p_value`, result.p_value);
    evidence.add(`hypotheses.results[${result.code}].verdict`, result.verdict);
    if (result.verdict === 'supported') {
      drivers.push({
        source: 'hypothesis',
        name: `${result.code}（${result.independent} → ${result.dependent}）`,
        statistic: `r = ${displayNumber(result.r)}（n = ${displayNumber(result.n)}）`,
        value: result.r,
        p_value: result.p_value,
        effect: describeEffect(result.effect_size),
        note: result.statement,
      });
    } else {
      notConfirmed.push({
        name: `${result.code}（${result.independent} → ${result.dependent}）`,
        statistic: `r = ${displayNumber(result.r)}（n = ${displayNumber(result.n)}）`,
        value: result.r,
        p_value: result.p_value,
        verdict: result.verdict,
        note:
          result.verdict === 'inconclusive'
            ? '本次样本证据不足，不能表述为「已证明无关」。'
            : '方向与假设相反且显著，属于反方向发现，不应改写假设或忽略。',
      });
    }
  }

  /* Segmentation: which groups differ, on the comparisons the engine actually ran. */
  const segmentFindings: MarketOpportunityData['segment_findings'] = [];
  for (const comparison of bundle.comparisons) {
    const anova = comparison.anova;
    if (!anova) continue;
    const kruskal = comparison.kruskal_wallis;
    const pValue = comparison.recommended === 'nonparametric' ? kruskal?.p_value ?? null : anova.p_value;
    const statistic =
      comparison.recommended === 'nonparametric'
        ? `Kruskal–Wallis H = ${kruskal ? displayNumber(kruskal.h) : '未报告'}（ε² = ${kruskal?.epsilon_squared === null || kruskal?.epsilon_squared === undefined ? '未报告' : displayNumber(kruskal.epsilon_squared)}）`
        : `ANOVA F = ${displayNumber(anova.f)}（η² = ${anova.eta_squared === null ? '未报告' : displayNumber(anova.eta_squared)}）`;
    if (comparison.recommended === 'nonparametric') {
      evidence.add(`comparisons[${comparison.dependent}].kruskal_wallis.p_value`, kruskal?.p_value ?? null);
    } else {
      evidence.add(`comparisons[${comparison.dependent}].anova.p_value`, anova.p_value);
      evidence.add(`comparisons[${comparison.dependent}].anova.eta_squared`, anova.eta_squared);
    }
    segmentFindings.push({
      dependent: comparison.dependent,
      factor: comparison.factor,
      p_value: pValue,
      statistic,
      effect: describeEffect(anova.effect_size),
      recommended: comparison.recommended,
    });
  }

  const demandOverall = readMean(store, 'DSD');
  const demandRanking: MarketOpportunityData['demand_ranking'] = [];
  if (demandOverall) {
    const itemEntries = itemsOf(dataset, 'DSD')
      .map((variable) => store.get(variable.name))
      .filter((stats): stats is NonNullable<typeof stats> => stats !== undefined && stats.mean !== null && stats.n > 0)
      .sort((left, right) => (right.mean ?? 0) - (left.mean ?? 0));
    // Only the strongest demand item is quoted here; the full ranking lives in the
    // product-demand block, so this synthesis stays bounded and does not duplicate it.
    const top = itemEntries[0];
    if (top) {
      evidence.add(`descriptive.variables[${top.variable}].mean`, top.mean);
      evidence.add(`descriptive.variables[${top.variable}].n`, top.n);
      demandRanking.push({
        rank: 1,
        variable: top.variable,
        label: top.label,
        mean: top.mean ?? 0,
        n: top.n,
      });
    }
  }

  const available =
    drivers.length > 0 ||
    notConfirmed.length > 0 ||
    segmentFindings.length > 0 ||
    demandRanking.length > 0;

  const marketSizeReason =
    '本报告不给出任何货币规模：数据集里没有价格、成本、付费转化、市场容量或购买行为，' +
    '声称的付费意愿分档也不足以推算收入（区间中值不是测量值）。' +
    '给出一个金额，无论区间多宽，都是在数据之外添加假设。';

  const data: MarketOpportunityData | null = available
    ? {
        inference_label:
          '以下内容是基于本样本统计结果的推断，属于机会假设，不是市场规模估算，也不是对总体市场的描述。',
        sample_scope: {
          analysable: bundle.sample.analysable,
          note:
            `推断的样本范围仅为本次分析的有效样本 ${displayNumber(bundle.sample.analysable)} 份；` +
            '便利样本不能按人口结构加权，因此任何「放大到某地区」的推算都缺乏依据。',
        },
        drivers,
        not_confirmed: notConfirmed,
        demand_ranking: demandRanking,
        segment_findings: segmentFindings,
        market_size_estimate: {
          available: false,
          amount: null,
          currency: null,
          reason: marketSizeReason,
        },
        what_would_be_needed: [
          '目标人群的总体规模与家庭结构分布（本问卷未采集，且便利样本无法外推）。',
          '真实的价格与支付行为数据（订单、续费、退款），而不是声称的付费意愿。',
          '各供给方的份额与替代关系（本问卷未测量机构与内容平台的逐项使用率）。',
          '竞争产品的定价与获客成本（本平台不收集，也不应从问卷推断）。',
        ],
        bounded_conclusion:
          '可以支持的结论是：在本样本中，上述显著相关变量共同指向「需求强度、服务信任与使用意愿之间存在可测量的关联」，' +
          '这为产品方向提供了有待验证的假设。不能支持的结论包括：市场规模、收入预测、用户增长曲线，' +
          '以及任何以「本样本 X% 」乘以外部分母得到的数字。',
      }
    : null;

  const driverProse = drivers
    .map((driver) => `${driver.name}：${driver.statistic}，p = ${displayP(driver.p_value)}${driver.effect ? `，${driver.effect}` : ''}`)
    .join('；');
  const notConfirmedProse = notConfirmed
    .map((entry) => `${entry.name}：${entry.statistic}，p = ${displayP(entry.p_value)}${entry.verdict ? `，结论 ${entry.verdict}` : ''}`)
    .join('；');
  const segmentProse = segmentFindings
    .map((entry) => `${entry.factor} 对 ${entry.dependent}：${entry.statistic}，p = ${displayP(entry.p_value)}`)
    .join('；');

  const narrative = available
    ? '以下为基于本样本的推断（不是市场规模估算）。' +
      (drivers.length > 0
        ? `本样本中统计显著、可作为机会假设依据的关系：${driverProse}。`
        : '本样本中没有达到显著水平的关系可作为机会依据。') +
      (notConfirmed.length > 0
        ? `未获支持或证据不足的关系（不得当作已证明无关）：${notConfirmedProse}。`
        : '') +
      (segmentFindings.length > 0 ? `分群差异：${segmentProse}。` : '') +
      (demandRanking.length > 0 && demandRanking[0]
        ? `需求最强的一项是「${demandRanking[0].label}」${displayNumber(demandRanking[0].mean)}（n = ${displayNumber(demandRanking[0].n)}）。`
        : '') +
      `市场规模：不给出。${marketSizeReason}` +
      `要做市场规模估算，至少还需要：${data?.what_would_be_needed.join('') ?? ''}` +
      (data?.bounded_conclusion ?? '')
    : '本区块不可用：结果包中既没有可用的回归与相关结果，也没有需求测量，因此没有可依据的显著关系，' +
      '本报告不给出任何市场机会判断，也不以外部行业数据填充。';

  return {
    key: 'market_opportunity',
    order: 9,
    title: INSIGHT_BLOCK_TITLES.market_opportunity,
    available,
    reason: available
      ? null
      : '结果包中没有回归/相关结果，也没有需求测量，无法给出任何有依据的市场机会推断。',
    narrative,
    data,
    inputs: [
      probe('regression', 'primary', bundle.regression !== null, bundle.regression ? null : '结果包中没有回归结果。'),
      probe('correlation', 'primary', bundle.correlation !== null, bundle.correlation ? null : '结果包中没有相关矩阵。'),
      probe('comparisons', 'supporting', bundle.comparisons.length > 0, bundle.comparisons.length > 0 ? null : '结果包中没有组间比较结果。'),
      probe('DSD', 'supporting', demandOverall !== null, demandOverall ? null : '问卷未测量数字化服务需求（DSD）。'),
    ],
    evidence: evidence.list(),
  };
}

/* ------------------------------------------------------------------ */
/* Report assembly                                                    */
/* ------------------------------------------------------------------ */

/**
 * Build the competition report from a finished analysis bundle.
 *
 * Pure: same inputs, same report. `summary` is compared with the bundle's own
 * sample summary so a stale bundle (built before more responses arrived) is
 * disclosed rather than silently presented as current.
 */
export function buildInsightReport(inputs: InsightInputs): InsightReport {
  const { bundle, summary, quality } = inputs;

  const blocks: CompetitionBlock[] = [
    buildTargetUser(inputs),
    buildPainPoints(inputs),
    buildCurrentSolutions(inputs),
    buildServiceGap(inputs),
    buildProductDemand(inputs),
    buildTrust(inputs),
    buildAiAcceptance(inputs),
    buildWillingnessToPay(inputs),
    buildMarketOpportunity(inputs),
  ];

  const stale = summary.analysable !== bundle.sample.analysable;
  const notes: string[] = [
    '本报告的所有统计数字均来自分析结果包（analysis bundle），由平台统计引擎计算，' +
      '本层不重新计算、不四舍五入到不同精度，也不引入外部数据。每个区块的 evidence 逐条给出数字在结果包中的位置。',
    '判定规则：某一区块所需的变量在问卷中不存在、或有效样本为 0 时，区块标记为不可用并说明缺少什么，不会以 0 或行业均值填充。',
    '推断与测量的边界：区块内的测量值是真实现样本的结果；「市场机会」区块是推断，已在区块内明确标注，且不包含任何货币规模。',
  ];
  if (stale) {
    notes.push(
      `结果包与分析时的样本不一致（结果包 n = ${displayNumber(bundle.sample.analysable)}，` +
        `当前可分析样本 n = ${displayNumber(summary.analysable)}）：说明在新的作答进入之后尚未重新运行统计分析，` +
        '本报告描述的是结果包生成时点的样本，请重新运行分析后再对外使用。',
    );
  }
  const duplicated = duplicatedVariableNames(bundle);
  if (duplicated.length > 0) {
    notes.push(
      `以下变量名在问卷中被定义了多次：${duplicated.join('、')}。统计引擎按后出现者解析，` +
        '本报告照实呈现并在相关区块中标注，不重新编码变量。',
    );
  }

  const caveats: string[] = [
    ...REQUIRED_CAVEATS,
    `本报告基于 ${displayNumber(bundle.sample.analysable)} 份有效样本；各统计量另有其自身的有效 n，` +
      '解读时应以各区块与结果包中报告的 n 为准。',
    ...bundle.caveats.filter((caveat) => !REQUIRED_CAVEATS.includes(caveat)),
  ];

  return {
    engine_version: INSIGHT_ENGINE_VERSION,
    generated_at: nowIso(),
    source: {
      analysis_engine_version: bundle.engine_version,
      analysis_generated_at: bundle.generated_at,
      project_id: bundle.project.id,
      project_title: bundle.project.title,
      questionnaire: bundle.questionnaire,
      bundle_engine_matches: bundle.engine_version === ANALYSIS_ENGINE_VERSION,
    },
    sample: bundle.sample,
    staleness: {
      bundle_sample_n: bundle.sample.analysable,
      current_sample_n: summary.analysable,
      stale,
      note: stale
        ? '结果包早于当前样本，请重新运行统计分析后再据此作商业判断。'
        : '结果包与当前样本一致。',
    },
    blocks,
    caveats,
    notes,
  };
}

/** Type-safe accessor for one block's structured payload. */
export function blockData<K extends InsightBlockKey>(
  report: InsightReport,
  key: K,
): BlockDataMap[K] | null {
  const block = report.blocks.find((item) => item.key === key);
  return (block?.data ?? null) as BlockDataMap[K] | null;
}

/* ------------------------------------------------------------------ */
/* Persistence and orchestration                                      */
/* ------------------------------------------------------------------ */

export interface StoredInsightReport {
  id: string;
  project_id: string;
  questionnaire_id: string | null;
  analysis_engine_version: string | null;
  analysis_generated_at: string | null;
  engine_version: string;
  sample_n: number | null;
  blocks_total: number;
  blocks_available: number;
  run_seq: number;
  created_at: string;
  created_by: string | null;
  report: InsightReport | null;
}

interface InsightReportRow {
  id: string;
  project_id: string;
  questionnaire_id: string | null;
  analysis_engine_version: string | null;
  analysis_generated_at: string | null;
  engine_version: string;
  sample_n: number | null;
  blocks_total: number;
  blocks_available: number;
  run_seq: number;
  created_at: string;
  created_by: string | null;
  report_json: string;
}

/**
 * Persist a report.
 *
 * `run_seq` is computed inside the same transaction as the insert, so two runs in
 * the same millisecond still have a defined order — which is what makes the
 * history endpoint an audit trail rather than a list.
 */
export function persistInsightReport(
  db: Db,
  projectId: string,
  researcherId: string,
  report: InsightReport,
): StoredInsightReport {
  const id = newId();
  const createdAt = nowIso();
  const available = report.blocks.filter((block) => block.available).length;
  let runSeq = 1;

  db.transaction(() => {
    runSeq =
      Number(
        db.scalar<number>('SELECT COALESCE(MAX(run_seq), 0) AS n FROM insight_reports WHERE project_id = ?', [
          projectId,
        ]) ?? 0,
      ) + 1;

    db.run(
      `INSERT INTO insight_reports
         (id, project_id, questionnaire_id, analysis_engine_version, analysis_generated_at,
          engine_version, sample_n, blocks_total, blocks_available, run_seq, report_json, created_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        projectId,
        report.source.questionnaire?.id ?? null,
        report.source.analysis_engine_version,
        report.source.analysis_generated_at,
        report.engine_version,
        report.sample.analysable,
        report.blocks.length,
        available,
        runSeq,
        JSON.stringify(report),
        researcherId,
        createdAt,
      ],
    );
  });

  return {
    id,
    project_id: projectId,
    questionnaire_id: report.source.questionnaire?.id ?? null,
    analysis_engine_version: report.source.analysis_engine_version,
    analysis_generated_at: report.source.analysis_generated_at,
    engine_version: report.engine_version,
    sample_n: report.sample.analysable,
    blocks_total: report.blocks.length,
    blocks_available: available,
    run_seq: runSeq,
    created_at: createdAt,
    created_by: researcherId,
    report,
  };
}

function toStoredReport(row: InsightReportRow, includeReport: boolean): StoredInsightReport {
  return {
    id: row.id,
    project_id: row.project_id,
    questionnaire_id: row.questionnaire_id,
    analysis_engine_version: row.analysis_engine_version,
    analysis_generated_at: row.analysis_generated_at,
    engine_version: row.engine_version,
    sample_n: row.sample_n,
    blocks_total: Number(row.blocks_total),
    blocks_available: Number(row.blocks_available),
    run_seq: Number(row.run_seq),
    created_at: row.created_at,
    created_by: row.created_by,
    report: includeReport ? parseJson<InsightReport | null>(row.report_json, null) : null,
  };
}

/** The most recently persisted report, newest first by run sequence. */
export function getLatestInsightReport(
  db: Db,
  projectId: string,
  researcherId: string,
): StoredInsightReport | null {
  requireProject(db, projectId, researcherId);
  const row = db.get<InsightReportRow>(
    'SELECT * FROM insight_reports WHERE project_id = ? ORDER BY run_seq DESC LIMIT 1',
    [projectId],
  );
  return row ? toStoredReport(row, true) : null;
}

/** The audit trail: every report run, newest first, without the payload. */
export function listInsightReports(
  db: Db,
  projectId: string,
  researcherId: string,
): StoredInsightReport[] {
  requireProject(db, projectId, researcherId);
  const rows = db.all<InsightReportRow>(
    'SELECT * FROM insight_reports WHERE project_id = ? ORDER BY run_seq DESC',
    [projectId],
  );
  return rows.map((row) => toStoredReport(row, false));
}

/**
 * Run the competition analysis for the latest persisted bundle and store it.
 *
 * The bundle is required rather than rebuilt here: the competition view must not
 * be able to produce a number the researcher never saw in the analysis console.
 */
export function runCompetitionAnalysis(
  db: Db,
  projectId: string,
  researcherId: string,
): StoredInsightReport {
  requireProject(db, projectId, researcherId);

  const bundle = getLatestBundle(db, projectId, researcherId);
  if (!bundle) {
    throw ApiError.validation(
      '尚未运行过完整统计分析，无法生成创业洞察。请先在「统计分析」中执行「运行全部分析」，' +
        '创业洞察的所有数字都来自该结果包。',
    );
  }

  const { dataset, summary } = loadAnalysableSample(db, projectId);

  // Quality data is supporting context, not a prerequisite: a failure here must
  // not block the report, so it degrades to null and the report says so.
  let quality: ProjectQualityReport | null = null;
  try {
    quality = getProjectQualityReport(db, projectId);
  } catch {
    quality = null;
  }

  const report = buildInsightReport({ bundle, dataset, summary, quality });
  return persistInsightReport(db, projectId, researcherId, report);
}
