/**
 * Password hashing.
 *
 * Uses scrypt from Node's built-in crypto rather than a native bcrypt/argon2
 * dependency: scrypt is memory-hard, is a standard KDF, and needs no build
 * toolchain. Parameters are stored inside the hash string so they can be
 * raised later without invalidating existing accounts.
 *
 * Storage format:  scrypt$N$r$p$<saltBase64>$<hashBase64>
 */

import { randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

/** OWASP-aligned baseline: N=2^15, r=8, p=1 (~32 MB, ~100 ms on desktop). */
const DEFAULT_PARAMS = { N: 32768, r: 8, p: 1 } as const;
const KEY_LENGTH = 64;
const SALT_LENGTH = 16;

export interface ScryptParams {
  N: number;
  r: number;
  p: number;
}

/**
 * scrypt memory use is roughly 128 * N * r bytes; Node enforces a `maxmem`
 * ceiling so it must be raised above that or hashing throws.
 */
function maxmemFor(params: ScryptParams): number {
  return 256 * params.N * params.r;
}

function derive(password: string, salt: Buffer, params: ScryptParams, keyLength: number): Buffer {
  return scryptSync(password.normalize('NFKC'), salt, keyLength, {
    ...params,
    maxmem: maxmemFor(params),
  });
}

export function hashPassword(password: string, params: ScryptParams = DEFAULT_PARAMS): string {
  const salt = randomBytes(SALT_LENGTH);
  const hash = derive(password, salt, params, KEY_LENGTH);
  return [
    'scrypt',
    params.N,
    params.r,
    params.p,
    salt.toString('base64'),
    hash.toString('base64'),
  ].join('$');
}

export interface VerifyResult {
  ok: boolean;
  /** True when the stored hash uses weaker parameters than the current policy. */
  needsRehash: boolean;
}

/**
 * Constant-time password verification.
 * Returns a result object rather than a bare boolean so callers can transparently
 * upgrade the hash on a successful login.
 */
export function verifyPassword(password: string, stored: string): VerifyResult {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') {
    return { ok: false, needsRehash: false };
  }
  const N = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p) || N <= 0 || r <= 0 || p <= 0) {
    return { ok: false, needsRehash: false };
  }

  let salt: Buffer;
  let expected: Buffer;
  try {
    salt = Buffer.from(parts[4] ?? '', 'base64');
    expected = Buffer.from(parts[5] ?? '', 'base64');
  } catch {
    return { ok: false, needsRehash: false };
  }
  if (salt.length === 0 || expected.length === 0) {
    return { ok: false, needsRehash: false };
  }

  let actual: Buffer;
  try {
    actual = derive(password, salt, { N, r, p }, expected.length);
  } catch {
    // Malformed parameters (e.g. absurd N) must fail closed, not crash.
    return { ok: false, needsRehash: false };
  }

  const ok = actual.length === expected.length && timingSafeEqual(actual, expected);
  const needsRehash =
    ok && (N < DEFAULT_PARAMS.N || r < DEFAULT_PARAMS.r || p < DEFAULT_PARAMS.p);
  return { ok, needsRehash };
}

/* ------------------------------------------------------------------ */
/* Password policy                                                    */
/* ------------------------------------------------------------------ */

export interface PasswordPolicyResult {
  valid: boolean;
  errors: string[];
}

/** Minimum-strength policy for researcher accounts. */
export function validatePasswordStrength(password: unknown): PasswordPolicyResult {
  const errors: string[] = [];
  if (typeof password !== 'string' || password.length === 0) {
    return { valid: false, errors: ['密码不能为空。'] };
  }
  if (password.length < 8) errors.push('密码长度至少为 8 个字符。');
  if (password.length > 200) errors.push('密码长度不能超过 200 个字符。');
  if (!/[A-Za-z]/.test(password)) errors.push('密码需包含至少一个字母。');
  if (!/[0-9]/.test(password)) errors.push('密码需包含至少一个数字。');
  return { valid: errors.length === 0, errors };
}
