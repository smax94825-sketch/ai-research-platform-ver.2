/**
 * Static server for the built research console.
 *
 * Serves `dist/` with an SPA fallback so client-side routes such as
 * `/projects/:id/questionnaires/:qid/builder` survive a page refresh. The API
 * is a separate origin (default :4000) and is reached directly by the browser.
 */

import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const distDir = resolve(here, '..', 'dist');
const port = Number(process.env.WEB_PORT ?? 5173);
const host = process.env.WEB_HOST ?? '127.0.0.1';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.map': 'application/json; charset=utf-8',
};

async function tryFile(path) {
  try {
    const info = await stat(path);
    return info.isFile() ? path : null;
  } catch {
    return null;
  }
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  const requested = decodeURIComponent(url.pathname);

  // Block path traversal before touching the filesystem.
  const safePath = normalize(requested).replace(/^(\.\.[\\/])+/, '');
  const candidate = join(distDir, safePath);

  if (!candidate.startsWith(distDir)) {
    res.writeHead(403).end('Forbidden');
    return;
  }

  const direct = requested !== '/' ? await tryFile(candidate) : null;
  const file = direct ?? (await tryFile(join(distDir, 'index.html')));

  if (!file) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
    res.end('未找到前端构建产物。请先运行 npm run build -w @ferp/web');
    return;
  }

  const body = await readFile(file);
  res.writeHead(200, {
    'content-type': MIME[extname(file)] ?? 'application/octet-stream',
    'cache-control': direct ? 'public, max-age=300' : 'no-cache',
  });
  res.end(body);
});

server.listen(port, host, () => {
  console.log('[ferp-web] 研究者控制台已启动');
  console.log(`[ferp-web] 地址: http://${host}:${port}`);
  console.log(`[ferp-web] 静态目录: ${distDir}`);
  console.log('[ferp-web] 请确保后端 API 已启动（默认 http://127.0.0.1:4000）');
});
