/**
 * Test harness.
 *
 * Boots a real HTTP server on an ephemeral port against a fresh in-memory
 * database, so every test exercises the full stack — routing, middleware, JWT
 * verification, SQL and serialisation — rather than a mocked subset.
 */

import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';

import { createApp } from '../src/app.js';
import { loadConfig, type Config } from '../src/config.js';
import { Db } from '../src/db/index.js';
import { migrate } from '../src/db/migrate.js';
import type { Hypothesis } from '@ferp/shared';

export interface TestContext {
  db: Db;
  config: Config;
  server: Server;
  baseUrl: string;
  close(): Promise<void>;
}

export interface ApiResponse<T = unknown> {
  status: number;
  ok: boolean;
  data: T;
  error: { code: string; message: string; details: unknown } | null;
  headers: Headers;
}

export interface RequestOptions {
  token?: string | null;
  body?: unknown;
  headers?: Record<string, string>;
}

/** Start an isolated app + server for one test file. */
export async function createTestContext(): Promise<TestContext> {
  const config = loadConfig({
    NODE_ENV: 'test',
    DATABASE_PATH: ':memory:',
    JWT_SECRET: 'test-secret-that-is-long-enough-for-hs256-signing',
    JWT_EXPIRES_IN: '3600',
  });

  const db = new Db(config.databasePath);
  migrate(db);

  const app = createApp({ db, config });
  const server = await new Promise<Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const address = server.address() as AddressInfo;
  const baseUrl = `http://127.0.0.1:${address.port}`;

  return {
    db,
    config,
    server,
    baseUrl,
    close: () =>
      new Promise<void>((resolve, reject) => {
        server.close((err) => {
          db.close();
          if (err) reject(err);
          else resolve();
        });
      }),
  };
}

/** Minimal typed fetch wrapper for the API under test. */
export async function api<T = unknown>(
  ctx: TestContext,
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  path: string,
  options: RequestOptions = {},
): Promise<ApiResponse<T>> {
  const headers: Record<string, string> = { ...options.headers };
  if (options.body !== undefined) headers['content-type'] = 'application/json';
  if (options.token) headers['authorization'] = `Bearer ${options.token}`;

  const response = await fetch(`${ctx.baseUrl}${path}`, {
    method,
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });

  const text = await response.text();
  let parsed: unknown = null;
  if (text.length > 0) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = text;
    }
  }

  const envelope = parsed as { data?: T; error?: ApiResponse['error'] } | null;
  return {
    status: response.status,
    ok: response.ok,
    data: (envelope?.data ?? null) as T,
    error: envelope?.error ?? null,
    headers: response.headers,
  };
}

/* ------------------------------------------------------------------ */
/* Domain helpers                                                     */
/* ------------------------------------------------------------------ */

export interface TestResearcher {
  id: string;
  email: string;
  password: string;
  token: string;
}

let counter = 0;

/** Register a fresh researcher and return a ready-to-use token. */
export async function registerResearcher(
  ctx: TestContext,
  overrides: { name?: string; email?: string; password?: string } = {},
): Promise<TestResearcher> {
  counter += 1;
  const email = overrides.email ?? `researcher${counter}@test.local`;
  const password = overrides.password ?? 'Password123';

  const response = await api<{ researcher: { id: string; email: string }; token: string }>(
    ctx,
    'POST',
    '/api/auth/register',
    { body: { name: overrides.name ?? `研究者${counter}`, email, password } },
  );

  if (!response.ok || !response.data) {
    throw new Error(`注册测试账号失败: ${response.status} ${JSON.stringify(response.error)}`);
  }

  return { id: response.data.researcher.id, email, password, token: response.data.token };
}

export interface TestProject {
  id: string;
  questionnaireId: string | null;
  questionCount: number;
}

/** Create a project, optionally seeded from the V4.0 template. */
export async function createProject(
  ctx: TestContext,
  token: string,
  options: { title?: string; template?: string | null; hypothesisCount?: number } = {},
): Promise<TestProject> {
  const hypotheses: Hypothesis[] =
    options.hypothesisCount === undefined
      ? []
      : Array.from({ length: options.hypothesisCount }, (_, i) => ({
          code: `H${i + 1}`,
          statement: `假设 ${i + 1}`,
          status: 'untested' as const,
        }));

  const response = await api<{
    project: { id: string };
    questionnaire_id: string | null;
    seeded_questions: number;
  }>(ctx, 'POST', '/api/projects', {
    token,
    body: {
      title: options.title ?? '测试研究项目',
      target_sample_size: 500,
      research_questions: ['家长的家庭教育需求结构如何？'],
      hypotheses,
      template: options.template ?? null,
    },
  });

  if (!response.ok || !response.data) {
    throw new Error(`创建测试项目失败: ${response.status} ${JSON.stringify(response.error)}`);
  }

  return {
    id: response.data.project.id,
    questionnaireId: response.data.questionnaire_id,
    questionCount: response.data.seeded_questions,
  };
}

/** Convenience: project seeded from the default V4.0 template. */
export async function createTemplatedProject(
  ctx: TestContext,
  token: string,
  title = '家庭教育测试研究',
): Promise<TestProject> {
  const project = await createProject(ctx, token, { title, template: 'family-edu-v4' });
  if (!project.questionnaireId) throw new Error('模板项目未创建问卷');
  return project;
}

/* ------------------------------------------------------------------ */
/* PHASE 3 — collection helpers                                       */
/* ------------------------------------------------------------------ */

export interface CollectionFixture {
  projectId: string;
  questionnaireId: string;
  shareToken: string;
}

/** Publish a questionnaire and return its public share token. */
export async function publishQuestionnaire(
  ctx: TestContext,
  token: string,
  questionnaireId: string,
): Promise<string> {
  const response = await api<{ share_token: string }>(
    ctx,
    'POST',
    `/api/questionnaires/${questionnaireId}/publish`,
    { token },
  );
  if (!response.ok || !response.data) {
    throw new Error(`发布问卷失败: ${response.status} ${JSON.stringify(response.error)}`);
  }
  return response.data.share_token;
}

/**
 * Build a small published questionnaire from explicit question definitions.
 * Used where a test needs a deterministic, short instrument rather than the
 * 58-item template.
 */
export async function createPublishedQuestionnaire(
  ctx: TestContext,
  token: string,
  questions: Record<string, unknown>[],
  title = '采集测试问卷',
): Promise<CollectionFixture> {
  const project = await createProject(ctx, token, { title });
  const created = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
    token,
    body: { title },
  });
  if (!created.ok) throw new Error(`创建问卷失败: ${JSON.stringify(created.error)}`);

  for (const question of questions) {
    const added = await api(ctx, 'POST', `/api/questionnaires/${created.data.id}/questions`, {
      token,
      body: question,
    });
    if (!added.ok) throw new Error(`添加题目失败: ${JSON.stringify(added.error)}`);
  }

  const shareToken = await publishQuestionnaire(ctx, token, created.data.id);
  return { projectId: project.id, questionnaireId: created.data.id, shareToken };
}

/** Publish the V4.0 template questionnaire of a project. */
export async function publishTemplatedProject(
  ctx: TestContext,
  token: string,
  title = '采集测试研究',
): Promise<CollectionFixture> {
  const project = await createTemplatedProject(ctx, token, title);
  const shareToken = await publishQuestionnaire(ctx, token, project.questionnaireId!);
  return { projectId: project.id, questionnaireId: project.questionnaireId!, shareToken };
}

export interface PublicSession {
  token: string;
  respondentId: string;
  anonymousId: string;
  source: string;
}

/** Open a respondent session through the public API. */
export async function startSession(
  ctx: TestContext,
  shareToken: string,
  source?: string,
): Promise<PublicSession> {
  const response = await api<{
    session_token: string;
    respondent: { id: string; anonymous_id: string; source: string };
  }>(ctx, 'POST', `/api/public/survey/${shareToken}/sessions`, {
    body: source === undefined ? {} : { source },
  });
  if (!response.ok || !response.data) {
    throw new Error(`开启作答会话失败: ${response.status} ${JSON.stringify(response.error)}`);
  }
  return {
    token: response.data.session_token,
    respondentId: response.data.respondent.id,
    anonymousId: response.data.respondent.anonymous_id,
    source: response.data.respondent.source,
  };
}

/** Autosave one answer through the public API. */
export async function saveAnswer(
  ctx: TestContext,
  sessionToken: string,
  questionCode: string,
  value: unknown,
): Promise<ApiResponse<{ stored: unknown; pruned_question_codes: string[]; answered_count: number }>> {
  return api(ctx, 'PATCH', `/api/public/sessions/${sessionToken}/answers`, {
    body: { question_code: questionCode, value },
  });
}

/** Submit the questionnaire. */
export async function submitSession(
  ctx: TestContext,
  sessionToken: string,
): Promise<ApiResponse<{ respondent: { status: string; duration_seconds: number | null }; completed: boolean }>> {
  return api(ctx, 'POST', `/api/public/sessions/${sessionToken}/complete`, { body: {} });
}
