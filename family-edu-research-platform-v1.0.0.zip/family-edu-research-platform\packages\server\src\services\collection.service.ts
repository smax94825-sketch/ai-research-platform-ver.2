/**
 * Response collection service (PHASE 3).
 *
 * Responsibilities:
 *  - open an anonymous respondent session against a published questionnaire
 *  - autosave single answers, validating every value against the instrument
 *  - refuse answers to questions the current answer path does not administer
 *  - prune answers that a revised earlier answer made unreachable, so the
 *    stored data never contains structurally impossible combinations
 *  - complete a session, enforcing the required-question contract
 *
 * Privacy: a respondent is never identified. The session credential is a random
 * bearer token; the client IP is stored only as a salted hash, and only so that
 * obvious duplicate submissions can be detected later.
 */

import { createHash, randomBytes } from 'node:crypto';
import {
  describeAnswer,
  isQuestionRequired,
  isQuestionVisible,
  normalizeAnswer,
  sortQuestions,
} from '@ferp/shared';
import type {
  AnswerMap,
  AnswerValue,
  Question,
  Respondent,
  RespondentStatus,
  ResponseRecord,
  ReviewStatus,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { formatAnonymousId, newId, nowIso } from '../util/ids.js';
import { parseJson } from './mappers.js';
import { listQuestions, requireQuestionnaire } from './questionnaire.service.js';
import { findResearcherById } from './researcher.service.js';
import type { RespondentRow } from './mappers.js';

/* ------------------------------------------------------------------ */
/* Mappers                                                            */
/* ------------------------------------------------------------------ */

export function toRespondent(row: RespondentRow): Respondent {
  return {
    id: row.id,
    questionnaire_id: row.questionnaire_id,
    project_id: row.project_id,
    anonymous_id: row.anonymous_id,
    source: row.source,
    started_at: row.started_at,
    completed_at: row.completed_at,
    duration_seconds: row.duration_seconds,
    status: row.status as RespondentStatus,
    quality_score: row.quality_score,
    current_question_code: row.current_question_code ?? null,
    answered_count: row.answered_count ?? 0,
    last_activity_at: row.last_activity_at ?? null,
    consent_given_at: row.consent_given_at ?? null,
    review_status: (row.review_status ?? 'unreviewed') as ReviewStatus,
    review_note: row.review_note ?? null,
    created_at: row.created_at,
  };
}

/* ------------------------------------------------------------------ */
/* Source tracking                                                    */
/* ------------------------------------------------------------------ */

const SOURCE_PATTERN = /^[a-zA-Z0-9_-]{1,32}$/;

/**
 * Sanitise a `?source=` value.
 *
 * Unknown channels are preserved (a researcher may add one without a deploy)
 * but the value is constrained to a safe identifier and never echoed into SQL,
 * HTML or a filename. Anything malformed falls back to `direct`.
 */
export function sanitizeSource(raw: unknown): string {
  if (typeof raw !== 'string') return 'direct';
  const trimmed = raw.trim().toLowerCase();
  if (trimmed === '' || !SOURCE_PATTERN.test(trimmed)) return 'direct';
  return trimmed;
}

/** Salted, truncated hash of the client address — never the address itself. */
export function hashClientAddress(address: string | null, salt: string): string | null {
  if (!address) return null;
  return createHash('sha256').update(`${salt}:${address}`).digest('hex').slice(0, 32);
}

/* ------------------------------------------------------------------ */
/* Session lifecycle                                                  */
/* ------------------------------------------------------------------ */

export interface StartSessionInput {
  questionnaireId: string;
  projectId: string;
  source: unknown;
  userAgent: string | null;
  clientAddress: string | null;
  salt: string;
}

export interface RespondentSession {
  session_token: string;
  respondent: Respondent;
  answers: AnswerMap;
}

/** Generate a session bearer token (144 bits of entropy). */
function generateSessionToken(): string {
  return randomBytes(18).toString('base64url');
}

function findRespondentRowByToken(db: Db, token: string): RespondentRow | undefined {
  if (typeof token !== 'string' || token.length < 16) return undefined;
  return db.get<RespondentRow>('SELECT * FROM respondents WHERE session_token = ?', [token]);
}

export function findRespondentByToken(db: Db, token: string): Respondent | undefined {
  const row = findRespondentRowByToken(db, token);
  return row ? toRespondent(row) : undefined;
}

export function requireRespondentByToken(db: Db, token: string): RespondentRow {
  const row = findRespondentRowByToken(db, token);
  if (!row) throw ApiError.notFound('作答会话不存在或已失效，请重新打开问卷链接。');
  return row;
}

/** Next free `A####` code for a questionnaire. */
function nextAnonymousSequence(db: Db, questionnaireId: string): number {
  const max = db.scalar<number>(
    `SELECT COALESCE(MAX(CAST(SUBSTR(anonymous_id, 2) AS INTEGER)), 0) AS m
       FROM respondents WHERE questionnaire_id = ? AND anonymous_id LIKE 'A%'`,
    [questionnaireId],
  );
  return Number(max ?? 0) + 1;
}

/**
 * Open a new respondent session.
 *
 * Anonymous ids are allocated inside the transaction and retried on the unique
 * constraint, so two simultaneous starts cannot collide.
 */
export function startSession(db: Db, input: StartSessionInput): RespondentSession {
  const questionnaire = requireQuestionnaire(db, input.questionnaireId);
  if (questionnaire.status !== 'published') {
    throw ApiError.validation(
      questionnaire.status === 'closed'
        ? '本次调查已结束，暂时无法提交新的作答。'
        : '该问卷尚未发布，无法开始作答。',
    );
  }

  const token = generateSessionToken();
  const timestamp = nowIso();
  const source = sanitizeSource(input.source);
  const ipHash = hashClientAddress(input.clientAddress, input.salt);

  let respondentId = '';

  for (let attempt = 0; attempt < 8; attempt += 1) {
    respondentId = newId();
    const anonymousId = formatAnonymousId(nextAnonymousSequence(db, questionnaire.id));
    try {
      db.transaction(() => {
        db.run(
          `INSERT INTO respondents
             (id, questionnaire_id, project_id, anonymous_id, source, started_at, completed_at,
              duration_seconds, status, quality_score, ip_hash, user_agent, created_at,
              session_token, consent_given_at, current_question_code, answered_count, last_activity_at,
              review_status)
           VALUES (?, ?, ?, ?, ?, ?, NULL, NULL, 'in_progress', NULL, ?, ?, ?, ?, ?, NULL, 0, ?, 'unreviewed')`,
          [
            respondentId,
            questionnaire.id,
            questionnaire.project_id,
            anonymousId,
            source,
            timestamp,
            ipHash,
            input.userAgent,
            timestamp,
            token,
            timestamp,
            timestamp,
          ],
        );
      });
      break;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      // Retry only on the anonymous-id uniqueness race; anything else is real.
      if (!/UNIQUE|constraint/i.test(message) || attempt === 7) throw error;
    }
  }

  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw new ApiError('INTERNAL_ERROR', '创建作答会话后无法读取会话记录。');

  return { session_token: token, respondent: toRespondent(row), answers: {} };
}

/** All stored answers for a respondent, keyed by question code. */
export function loadAnswers(db: Db, respondentId: string): AnswerMap {
  const rows = db.all<{ question_code: string; answer: string | null }>(
    'SELECT question_code, answer FROM responses WHERE respondent_id = ?',
    [respondentId],
  );
  // Values were canonicalised by `normalizeAnswer` before storage, so the
  // parsed shape is guaranteed to be an AnswerValue.
  const answers: AnswerMap = {};
  for (const row of rows) {
    answers[row.question_code] = parseJson<AnswerValue>(row.answer, null);
  }
  return answers;
}

export interface SessionState {
  respondent: Respondent;
  answers: AnswerMap;
  /** Questions the current answer path does not administer. */
  hidden_question_codes: string[];
  /** Required questions still unanswered (only meaningful at completion). */
  missing_required: string[];
}

export function getSessionState(db: Db, respondentId: string): SessionState {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw ApiError.notFound('作答会话不存在。');
  const questions = listQuestions(db, row.questionnaire_id);
  const answers = loadAnswers(db, respondentId);

  const visible = questions.filter(
    (question) => question.question_type !== 'page_break' && isQuestionVisible(question, answers),
  );
  const visibleCodes = new Set(visible.map((question) => question.question_code));

  return {
    respondent: toRespondent(row),
    answers,
    hidden_question_codes: questions
      .filter((question) => question.question_type !== 'page_break')
      .filter((question) => !visibleCodes.has(question.question_code))
      .map((question) => question.question_code),
    missing_required: visible
      .filter((question) => isQuestionRequired(question, answers))
      .filter((question) => answers[question.question_code] === undefined || answers[question.question_code] === null)
      .map((question) => question.question_code),
  };
}

/* ------------------------------------------------------------------ */
/* Save one answer                                                    */
/* ------------------------------------------------------------------ */

export interface SaveAnswerInput {
  respondentId: string;
  questionCode: string;
  value: unknown;
}

export interface SaveAnswerResult {
  respondent: Respondent;
  question_code: string;
  stored: unknown;
  /** Answers removed because a revised earlier answer hid their questions. */
  pruned_question_codes: string[];
  answered_count: number;
}

/**
 * Persist one answer.
 *
 * Integrity rules enforced here:
 *  1. the question must belong to this questionnaire, and be answerable
 *  2. the value must normalise against the instrument (no invented option codes)
 *  3. the question must be visible given the answers already on file — this is
 *     the check that stops a crafted request from answering a skipped question
 *  4. answers that a *changed* earlier answer makes unreachable are deleted, so
 *     the dataset never contains answers to questions never administered
 */
export function saveAnswer(db: Db, input: SaveAnswerInput): SaveAnswerResult {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [input.respondentId]);
  if (!row) throw ApiError.notFound('作答会话不存在。');

  if (row.status === 'completed') {
    throw ApiError.conflict('该作答已提交，无法再修改。');
  }

  const questions = sortQuestions(listQuestions(db, row.questionnaire_id));
  const byCode = new Map(questions.map((question) => [question.question_code, question]));
  const question = byCode.get(input.questionCode);
  if (!question) {
    throw ApiError.validation(`题号 ${input.questionCode} 不属于该问卷。`);
  }

  const before = loadAnswers(db, input.respondentId);

  // Rule 3: the question must be on the current answer path.
  if (!isQuestionVisible(question, before)) {
    throw ApiError.validation(
      `题目 ${input.questionCode} 在当前作答路径下不展示，无法保存作答。`,
      { question_code: input.questionCode, hidden: true },
    );
  }

  const validation = normalizeAnswer(question, input.value);
  if (!validation.ok) {
    throw ApiError.validation(`题目 ${input.questionCode} 的作答无效。`, validation.errors);
  }

  const timestamp = nowIso();
  const after = { ...before };
  if (validation.value === null) delete after[question.question_code];
  else after[question.question_code] = validation.value;

  // Rule 4: prune answers that the new state makes unreachable.
  const pruned: string[] = [];
  for (const candidate of questions) {
    if (candidate.question_code === question.question_code) continue;
    if (candidate.question_type === 'page_break') continue;
    if (after[candidate.question_code] === undefined) continue;
    if (!isQuestionVisible(candidate, after)) pruned.push(candidate.question_code);
  }

  const respondentId = input.respondentId;

  db.transaction(() => {
    if (validation.value === null) {
      db.run('DELETE FROM responses WHERE respondent_id = ? AND question_id = ?', [
        respondentId,
        question.id,
      ]);
    } else {
      db.run(
        `INSERT INTO responses (id, respondent_id, question_id, question_code, answer, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(respondent_id, question_id)
         DO UPDATE SET answer = excluded.answer, updated_at = excluded.updated_at`,
        [
          newId(),
          respondentId,
          question.id,
          question.question_code,
          JSON.stringify(validation.value),
          timestamp,
          timestamp,
        ],
      );
    }

    for (const code of pruned) {
      const stale = byCode.get(code);
      if (!stale) continue;
      db.run('DELETE FROM responses WHERE respondent_id = ? AND question_id = ?', [
        respondentId,
        stale.id,
      ]);
    }

    const answeredCount = Number(
      db.scalar<number>('SELECT COUNT(*) AS n FROM responses WHERE respondent_id = ?', [
        respondentId,
      ]) ?? 0,
    );

    db.run(
      `UPDATE respondents
          SET current_question_code = ?, answered_count = ?, last_activity_at = ?, status = 'in_progress'
        WHERE id = ?`,
      [question.question_code, answeredCount, timestamp, respondentId],
    );
  });

  const updated = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!updated) throw new ApiError('INTERNAL_ERROR', '保存作答后无法读取会话记录。');

  return {
    respondent: toRespondent(updated),
    question_code: question.question_code,
    stored: validation.value,
    pruned_question_codes: pruned,
    answered_count: updated.answered_count ?? 0,
  };
}

/** Record the respondent's current position without storing an answer. */
export function updateProgress(db: Db, respondentId: string, questionCode: string | null): Respondent {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw ApiError.notFound('作答会话不存在。');
  if (row.status === 'completed') return toRespondent(row);

  const timestamp = nowIso();
  db.run(
    'UPDATE respondents SET current_question_code = ?, last_activity_at = ? WHERE id = ?',
    [questionCode, timestamp, respondentId],
  );
  const updated = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!updated) throw new ApiError('INTERNAL_ERROR', '更新进度后无法读取会话记录。');
  return toRespondent(updated);
}

/* ------------------------------------------------------------------ */
/* Completion                                                         */
/* ------------------------------------------------------------------ */

export interface CompleteInput {
  respondentId: string;
  /** Whether the respondent reached the end screen or left early. */
  via?: string | null;
}

export interface CompleteResult {
  respondent: Respondent;
  completed: boolean;
  missing_required: string[];
}

/**
 * Mark a session complete.
 *
 * A session with unanswered required questions is rejected with the exact
 * question codes, so the client can jump the respondent back to the first gap
 * rather than losing their work.
 */
export function completeSession(db: Db, input: CompleteInput): CompleteResult {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [input.respondentId]);
  if (!row) throw ApiError.notFound('作答会话不存在。');

  if (row.status === 'completed') {
    return { respondent: toRespondent(row), completed: true, missing_required: [] };
  }

  const state = getSessionState(db, input.respondentId);
  if (state.missing_required.length > 0) {
    throw ApiError.validation(
      `还有 ${state.missing_required.length} 道必答题未完成，无法提交。`,
      state.missing_required.map((code) => ({
        field: code,
        message: `必答题 ${code} 尚未作答。`,
      })),
    );
  }

  const completedAt = nowIso();
  const startedMs = new Date(row.started_at).getTime();
  const durationSeconds = Number.isFinite(startedMs)
    ? Math.max(0, Math.round((Date.now() - startedMs) / 1000))
    : null;

  db.run(
    `UPDATE respondents
        SET status = 'completed', completed_at = ?, duration_seconds = ?,
            last_activity_at = ?, completed_via = ?, current_question_code = NULL
      WHERE id = ?`,
    [completedAt, durationSeconds, completedAt, input.via ?? null, input.respondentId],
  );

  const updated = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [input.respondentId]);
  if (!updated) throw new ApiError('INTERNAL_ERROR', '提交作答后无法读取会话记录。');

  return { respondent: toRespondent(updated), completed: true, missing_required: [] };
}

/**
 * Mark sessions that stopped reporting as abandoned.
 *
 * Explicit rather than automatic: the platform only changes a sample's status
 * when a researcher asks it to, and never deletes anything.
 */
export function sweepAbandonedSessions(
  db: Db,
  projectId: string,
  olderThanHours = 24,
): { marked: number } {
  const cutoff = new Date(Date.now() - olderThanHours * 3600 * 1000).toISOString();
  const result = db.run(
    `UPDATE respondents
        SET status = 'abandoned'
      WHERE project_id = ?
        AND status = 'in_progress'
        AND COALESCE(last_activity_at, started_at) < ?`,
    [projectId, cutoff],
  );
  return { marked: result.changes };
}

/* ------------------------------------------------------------------ */
/* Researcher-facing reads                                            */
/* ------------------------------------------------------------------ */

export interface RespondentDetail {
  respondent: Respondent;
  questionnaire: { id: string; title: string; version: string };
  responses: ResponseRecord[];
  answered_count: number;
  hidden_question_codes: string[];
}

/** Full response detail for one sample, with answers resolved for display. */
export function getRespondentDetail(
  db: Db,
  respondentId: string,
  researcherId: string,
): RespondentDetail {
  const row = db.get<RespondentRow>(
    `SELECT r.* FROM respondents r
       JOIN research_projects p ON p.id = r.project_id
      WHERE r.id = ? AND p.researcher_id = ?`,
    [respondentId, researcherId],
  );
  if (!row) throw ApiError.notFound('样本不存在，或您没有访问权限。');

  const questionnaire = requireQuestionnaire(db, row.questionnaire_id);
  const questions = sortQuestions(listQuestions(db, row.questionnaire_id));
  const byId = new Map(questions.map((question) => [question.id, question]));

  const responseRows = db.all<{
    question_id: string;
    question_code: string;
    answer: string | null;
    created_at: string;
    updated_at: string;
  }>(
    'SELECT question_id, question_code, answer, created_at, updated_at FROM responses WHERE respondent_id = ?',
    [respondentId],
  );

  const responses: ResponseRecord[] = [];
  for (const response of responseRows) {
    const question = byId.get(response.question_id);
    if (!question) continue;
    const answer = parseJson<unknown>(response.answer, null);
    responses.push({
      question_id: response.question_id,
      question_code: response.question_code,
      question_text: question.question_text,
      question_type: question.question_type,
      dimension: question.dimension,
      variable_name: question.variable_name,
      answer,
      answer_label: describeAnswer(question, answer),
      created_at: response.created_at,
      updated_at: response.updated_at,
    });
  }

  const order = new Map(questions.map((question, index) => [question.question_code, index]));
  responses.sort(
    (a, b) => (order.get(a.question_code) ?? 0) - (order.get(b.question_code) ?? 0),
  );

  const state = getSessionState(db, respondentId);

  return {
    respondent: toRespondent(row),
    questionnaire: { id: questionnaire.id, title: questionnaire.title, version: questionnaire.version },
    responses,
    answered_count: responses.length,
    hidden_question_codes: state.hidden_question_codes,
  };
}

/* ------------------------------------------------------------------ */
/* Researcher review                                                  */
/* ------------------------------------------------------------------ */

export interface ReviewInput {
  respondentId: string;
  researcherId: string;
  status: ReviewStatus;
  note?: string | null;
}

/**
 * Record a researcher's judgement about a sample.
 *
 * This is the ONLY way a sample stops counting towards analysis, and it is
 * always attributable: the reviewer, the timestamp and a note are stored.
 */
export function reviewRespondent(db: Db, input: ReviewInput): Respondent {
  const row = db.get<RespondentRow>(
    `SELECT r.* FROM respondents r
       JOIN research_projects p ON p.id = r.project_id
      WHERE r.id = ? AND p.researcher_id = ?`,
    [input.respondentId, input.researcherId],
  );
  if (!row) throw ApiError.notFound('样本不存在，或您没有访问权限。');

  const allowed: ReviewStatus[] = ['unreviewed', 'accepted', 'flagged', 'excluded'];
  if (!allowed.includes(input.status)) {
    throw ApiError.validation(`未知的审核状态：${input.status}。`);
  }
  if (input.status === 'excluded' && !(input.note ?? '').trim()) {
    throw ApiError.validation('排除样本时必须填写原因，以便在方法部分如实报告排除标准。');
  }
  if (!findResearcherById(db, input.researcherId)) {
    throw ApiError.unauthorized('研究者账号不存在。');
  }

  db.run(
    `UPDATE respondents
        SET review_status = ?, review_note = ?, reviewed_at = ?, reviewed_by = ?
      WHERE id = ?`,
    [
      input.status,
      input.note ?? null,
      nowIso(),
      input.researcherId,
      input.respondentId,
    ],
  );

  const updated = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [input.respondentId]);
  if (!updated) throw new ApiError('INTERNAL_ERROR', '更新审核状态后无法读取样本记录。');
  return toRespondent(updated);
}
