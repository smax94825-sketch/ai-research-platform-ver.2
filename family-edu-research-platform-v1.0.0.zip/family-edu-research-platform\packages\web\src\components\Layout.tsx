/**
 * Console shell: sidebar navigation + header.
 *
 * Every entry listed here is implemented, so every one is a real link. The
 * `phase` mechanism is kept because it is how a later-phase feature is announced
 * before it exists: an item with `phase` renders as disabled with an explicit
 * phase tag rather than being hidden or faked, so a researcher can see the
 * roadmap without being misled into thinking a feature exists.
 */

import type { ReactNode } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/auth';
import { Button } from './ui';

interface NavItem {
  label: string;
  to?: string;
  /** Set only when the feature ships in a later phase; then the item is disabled. */
  phase?: string;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const NAV: NavSection[] = [
  {
    title: '总览',
    items: [{ label: 'Dashboard', to: '/' }],
  },
  {
    title: '研究项目',
    items: [{ label: 'Research Projects', to: '/projects' }],
  },
  {
    title: '问卷',
    items: [
      { label: 'Builder', to: '/builder' },
      { label: 'Logic', to: '/builder?tab=logic' },
      { label: 'Preview', to: '/builder?tab=preview' },
      { label: 'Publish', to: '/builder?tab=publish' },
    ],
  },
  {
    title: '数据收集',
    items: [
      { label: 'Responses', to: '/collection/responses' },
      { label: 'Samples', to: '/collection/samples' },
      { label: 'Sources', to: '/collection/sources' },
      { label: 'Quality', to: '/collection/quality' },
    ],
  },
  {
    title: '统计分析',
    items: [
      { label: 'Analysis Home', to: '/analysis' },
      { label: 'Descriptive', to: '/analysis/descriptive' },
      { label: 'Reliability', to: '/analysis/reliability' },
      { label: 'Validity', to: '/analysis/validity' },
      { label: 'Correlation', to: '/analysis/correlation' },
      { label: 'Regression', to: '/analysis/regression' },
      { label: 'Group Comparison', to: '/analysis/comparison' },
      { label: 'Hypothesis Testing', to: '/analysis/hypotheses' },
    ],
  },
  {
    title: '智能分析',
    items: [
      { label: 'AI Research Assistant', to: '/ai' },
      { label: 'Insights', to: '/competition' },
      { label: 'Reports', to: '/report' },
      { label: 'Export', to: '/export' },
    ],
  },
  {
    title: '系统',
    items: [{ label: 'Settings', to: '/settings' }],
  },
];

export function Layout(): ReactNode {
  const { researcher, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout(): Promise<void> {
    await logout();
    navigate('/login', { replace: true });
  }

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-64 shrink-0 border-r border-ink-200 bg-white lg:flex lg:flex-col">
        <div className="border-b border-ink-200 px-5 py-4">
          <p className="text-sm font-semibold leading-tight text-ink-900">家庭教育科研</p>
          <p className="text-sm font-semibold leading-tight text-ink-900">智能研究平台</p>
          <p className="mt-1 text-xs text-ink-500">AI-Powered Research OS</p>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4">
          {NAV.map((section) => (
            <div key={section.title} className="mb-4">
              <p className="px-2 pb-1 text-[11px] font-semibold uppercase tracking-wider text-ink-400">
                {section.title}
              </p>
              <ul className="space-y-0.5">
                {section.items.map((item) => (
                  <li key={item.label}>
                    {item.to ? (
                      <NavLink
                        to={item.to}
                        end={item.to === '/'}
                        className={({ isActive }) =>
                          `flex items-center justify-between rounded-md px-2 py-1.5 text-sm transition-colors ${
                            isActive
                              ? 'bg-brand-50 font-medium text-brand-700'
                              : 'text-ink-700 hover:bg-ink-100'
                          }`
                        }
                      >
                        <span>{item.label}</span>
                      </NavLink>
                    ) : (
                      <span
                        className="flex cursor-not-allowed items-center justify-between rounded-md px-2 py-1.5 text-sm text-ink-400"
                        title={`该功能将在 ${item.phase} 实现`}
                      >
                        <span>{item.label}</span>
                        <span className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] font-medium text-ink-500">
                          {item.phase}
                        </span>
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>

        <div className="border-t border-ink-200 px-4 py-3">
          <p className="truncate text-sm font-medium text-ink-800">{researcher?.name ?? '—'}</p>
          <p className="truncate text-xs text-ink-500">{researcher?.email ?? ''}</p>
          <Button variant="secondary" className="mt-2 w-full" onClick={handleLogout}>
            退出登录
          </Button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-ink-200 bg-white px-4 py-3 lg:px-6">
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-ink-900 lg:hidden">家庭教育科研智能研究平台</p>
            <p className="hidden text-xs text-ink-500 lg:block">
              研究设计 → 问卷构建 → 数据收集 → 质量检测 → 统计分析 → AI 解释 → 研究报告
            </p>
          </div>
          <div className="flex items-center gap-2 lg:hidden">
            <Button variant="secondary" onClick={handleLogout}>
              退出
            </Button>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-4 py-6 lg:px-6">
          <Outlet />
        </main>

        <footer className="border-t border-ink-200 px-4 py-3 text-xs text-ink-400 lg:px-6">
          本平台所有统计结果均来自数据库真实数据；AI 仅解释统计引擎的输出，不会生成或修改任何数据。
        </footer>
      </div>
    </div>
  );
}
