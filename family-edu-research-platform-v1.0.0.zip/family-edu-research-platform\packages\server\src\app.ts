/**
 * Express application factory.
 *
 * `createApp` takes its dependencies explicitly so tests can build an isolated
 * instance against an in-memory database without touching the environment.
 */

import express, { type Express } from 'express';
import cors from 'cors';
import type { Db } from './db/index.js';
import type { Config } from './config.js';
import { createErrorHandler, notFoundHandler } from './middleware/error.js';
import { createAuthRouter } from './routes/auth.routes.js';
import { createDashboardRouter } from './routes/dashboard.routes.js';
import { createProjectRouter, createTemplateRouter } from './routes/project.routes.js';
import { createPublicRouter } from './routes/public.routes.js';
import { createRespondentRouter, createSampleRouter } from './routes/collection.routes.js';
import {
  createQualityRouter,
  createRespondentQualityRouter,
} from './routes/quality.routes.js';
import { createQuestionnaireRouter, createQuestionRouter } from './routes/questionnaire.routes.js';
import { createAnalysisRouter } from './routes/analysis.routes.js';
import { createAiRouter } from './routes/ai.routes.js';
import { createExportRouter } from './routes/export.routes.js';
import { createInsightRouter } from './routes/insight.routes.js';
import { createReportRouter } from './routes/report.routes.js';

export interface AppDependencies {
  db: Db;
  config: Config;
}

export function createApp({ db, config }: AppDependencies): Express {
  const app = express();

  app.disable('x-powered-by');
  app.set('trust proxy', true);

  app.use(
    cors({
      origin: (origin, callback) => {
        // Same-origin/native clients send no Origin header — allow them.
        if (!origin) {
          callback(null, true);
          return;
        }
        if (config.corsOrigins.includes(origin) || config.env !== 'production') {
          callback(null, true);
          return;
        }
        callback(new Error(`Origin ${origin} is not allowed by CORS policy.`));
      },
      credentials: true,
    }),
  );

  // Questionnaires with 58 questions plus matrix rows can exceed the 100kb default.
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: false, limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    const researchers = Number(db.scalar<number>('SELECT COUNT(*) AS n FROM researchers') ?? 0);
    res.json({
      data: {
        status: 'ok',
        env: config.env,
        database: config.databasePath === ':memory:' ? 'in-memory' : 'file',
        researchers,
        time: new Date().toISOString(),
      },
    });
  });

  app.use('/api/auth', createAuthRouter({ db, config }));
  app.use('/api/templates', createTemplateRouter({ db, config }));
  app.use('/api/public', createPublicRouter({ db, config }));
  app.use('/api/dashboard', createDashboardRouter({ db, config }));
  app.use('/api/projects', createProjectRouter({ db, config }));
  app.use('/api/projects', createSampleRouter({ db, config }));
  app.use('/api/projects', createQualityRouter({ db, config }));
  app.use('/api/projects', createAnalysisRouter({ db, config }));
  // Downstream consumers of the analysis bundle: each reads the persisted bundle
  // and never recomputes a statistic, which is what keeps every number they
  // report traceable to one engine run.
  app.use('/api/projects', createAiRouter({ db, config }));
  app.use('/api/projects', createInsightRouter({ db, config }));
  app.use('/api/projects', createReportRouter({ db, config }));
  app.use('/api/projects', createExportRouter({ db, config }));
  app.use('/api/respondents', createRespondentRouter({ db, config }));
  app.use('/api/respondents', createRespondentQualityRouter({ db, config }));
  app.use('/api/questionnaires', createQuestionnaireRouter({ db, config }));
  app.use('/api/questions', createQuestionRouter({ db, config }));

  app.use(notFoundHandler);
  app.use(createErrorHandler({ logUnexpected: config.env !== 'test' }));

  return app;
}
