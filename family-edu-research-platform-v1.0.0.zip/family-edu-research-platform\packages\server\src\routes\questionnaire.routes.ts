/**
 * Questionnaire Builder routes.
 *
 * Mounted at two prefixes so that question-scoped and questionnaire-scoped
 * operations never collide in Express's path matching:
 *
 *   /api/questionnaires/...   questionnaire-level (read, publish, version, preview)
 *   /api/questions/...        question-level   (update, delete, duplicate, move)
 */

import { Router } from 'express';
import {
  buildVariableDictionary,
  dictionaryToCsv,
  describeRule,
  resolveFlowPath,
  validateLogic,
  isQuestionRequired,
  isQuestionVisible,
  type QuestionLogic,
  type QuestionOptions,
  type QuestionType,
  type ScoringRule,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import {
  buildInstrumentPayload,
  closeQuestionnaire,
  createNewVersion,
  findQuestionById,
  publishQuestionnaire,
  requireQuestionnaireForResearcher,
  snapshotQuestionnaire,
  updateQuestionnaire,
  listQuestions,
} from '../services/questionnaire.service.js';
import {
  createQuestion,
  deleteQuestion,
  duplicateQuestion,
  getBuilderState,
  moveQuestion,
  reorderQuestions,
  updateQuestion,
} from '../services/question.service.js';
import { requireProject } from '../services/project.service.js';
import { ApiError, asyncHandler } from '../util/errors.js';

export interface QuestionnaireRouterContext {
  db: Db;
  config: Config;
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

/* ================================================================== */
/* Questionnaire-level router                                          */
/* ================================================================== */

export function createQuestionnaireRouter(ctx: QuestionnaireRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  const owned = (req: { params: Record<string, string | undefined> }, researcherId: string) =>
    requireQuestionnaireForResearcher(ctx.db, req.params['questionnaireId']!, researcherId);

  /* ---------------------------------------------------------------- */
  router.get(
    '/:questionnaireId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      // Ownership of the parent project is implied by the join in `owned`.
      res.json({ data: buildInstrumentPayload(ctx.db, questionnaire.id) });
    }),
  );

  router.get(
    '/:questionnaireId/builder',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const state = getBuilderState(ctx.db, questionnaire.id);
      const project = requireProject(ctx.db, questionnaire.project_id, researcher.id);

      res.json({
        data: {
          questionnaire,
          project: { id: project.id, title: project.title },
          questions: state.questions,
          suggested_next_code: state.suggested_next_code,
          editable: state.editable,
          lock_reason: state.lock_reason,
        },
      });
    }),
  );

  router.patch(
    '/:questionnaireId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const body = asRecord(req.body);

      const patch: { title?: string; description?: string | null } = {};
      if (typeof body['title'] === 'string') patch.title = body['title'];
      if ('description' in body) patch.description = (body['description'] as string | null) ?? null;

      res.json({ data: updateQuestionnaire(ctx.db, questionnaire.id, patch) });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.post(
    '/:questionnaireId/publish',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const result = publishQuestionnaire(ctx.db, questionnaire.id);

      const shareUrl = `${ctx.config.publicBaseUrl}/research/${result.share_token}`;
      res.json({
        data: {
          questionnaire: result.questionnaire,
          share_token: result.share_token,
          share_url: shareUrl,
          warnings: result.warnings,
          logic_issues: result.logic_issues,
        },
      });
    }),
  );

  router.post(
    '/:questionnaireId/close',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      res.json({ data: closeQuestionnaire(ctx.db, questionnaire.id) });
    }),
  );

  router.post(
    '/:questionnaireId/versions',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const body = asRecord(req.body);
      const kind = body['kind'] === 'major' ? 'major' : 'minor';
      res.status(201).json({ data: createNewVersion(ctx.db, questionnaire.id, kind) });
    }),
  );

  router.post(
    '/:questionnaireId/snapshots',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const body = asRecord(req.body);
      const id = snapshotQuestionnaire(
        ctx.db,
        questionnaire.id,
        typeof body['label'] === 'string' ? body['label'] : undefined,
      );
      res.status(201).json({ data: { snapshot_id: id } });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.get(
    '/:questionnaireId/logic',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const questions = listQuestions(ctx.db, questionnaire.id);
      const labels: Record<string, string> = {};
      for (const question of questions) {
        for (const choice of question.options.choices ?? []) {
          labels[`${question.question_code}:${choice.value}`] = choice.label;
        }
      }

      const rules = questions.flatMap((question) => {
        const choiceLabels: Record<string, string> = {};
        for (const choice of question.options.choices ?? []) choiceLabels[String(choice.value)] = choice.label;
        return (question.logic?.rules ?? []).map((rule) => ({
          question_code: question.question_code,
          question_text: question.question_text,
          rule_id: rule.id,
          description: describeRule(rule, choiceLabels),
          action: rule.action,
          conditions: rule.conditions ?? (rule.when ? [rule.when] : []),
        }));
      });

      res.json({
        data: {
          rules,
          issues: validateLogic(questions),
          option_labels: labels,
        },
      });
    }),
  );

  /**
   * Preview the respondent flow for a given set of answers.
   * This is the same engine the public survey will run, so what the researcher
   * previews is exactly what a respondent experiences.
   */
  router.post(
    '/:questionnaireId/preview',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const body = asRecord(req.body);
      const answers = asRecord(body['answers']) as Record<string, never>;

      const questions = listQuestions(ctx.db, questionnaire.id);
      const path = resolveFlowPath(questions, answers);

      const visible = questions
        .filter((question) => question.question_type !== 'page_break')
        .filter((question) => isQuestionVisible(question, answers))
        .map((question) => ({
          question_code: question.question_code,
          question_text: question.question_text,
          question_type: question.question_type,
          section: question.section,
          required: isQuestionRequired(question, answers),
        }));

      res.json({
        data: {
          questionnaire_id: questionnaire.id,
          version: questionnaire.version,
          total_questions: questions.length,
          answered_path: path,
          answered_count: path.length,
          visible,
          visible_count: visible.length,
          logic_issues: validateLogic(questions),
        },
      });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.get(
    '/:questionnaireId/dictionary',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const questions = listQuestions(ctx.db, questionnaire.id);
      const dictionary = buildVariableDictionary(questions);

      if (req.query['format'] === 'csv') {
        res.type('text/csv; charset=utf-8');
        // BOM so Excel opens the Chinese headers correctly.
        res.send('\uFEFF' + dictionaryToCsv(dictionary));
        return;
      }

      res.json({ data: { questionnaire_id: questionnaire.id, version: questionnaire.version, dictionary } });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.post(
    '/:questionnaireId/questions',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const body = asRecord(req.body);

      const question = createQuestion(ctx.db, questionnaire.id, {
        question_code: typeof body['question_code'] === 'string' ? body['question_code'] : undefined,
        question_text: typeof body['question_text'] === 'string' ? body['question_text'] : '',
        question_type: (typeof body['question_type'] === 'string'
          ? body['question_type']
          : 'single') as QuestionType,
        options: (body['options'] as QuestionOptions | undefined) ?? {},
        required: typeof body['required'] === 'boolean' ? body['required'] : undefined,
        dimension: (body['dimension'] as string | null | undefined) ?? null,
        variable_name: (body['variable_name'] as string | null | undefined) ?? null,
        section: (body['section'] as string | null | undefined) ?? null,
        help_text: (body['help_text'] as string | null | undefined) ?? null,
        logic: (body['logic'] as QuestionLogic | null | undefined) ?? null,
        scoring_rule: (body['scoring_rule'] as ScoringRule | null | undefined) ?? null,
        position: typeof body['position'] === 'number' ? body['position'] : undefined,
      });

      res.status(201).json({ data: question });
    }),
  );

  router.post(
    '/:questionnaireId/questions/reorder',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const questionnaire = owned(req, researcher.id);
      const body = asRecord(req.body);
      const ordered = body['ordered_ids'];

      if (!Array.isArray(ordered) || !ordered.every((v) => typeof v === 'string')) {
        throw ApiError.validation('ordered_ids 必须是题目 ID 字符串数组。');
      }

      const result = reorderQuestions(ctx.db, questionnaire.id, ordered as string[]);
      res.json({ data: result });
    }),
  );

  return router;
}

/* ================================================================== */
/* Question-level router                                               */
/* ================================================================== */

export function createQuestionRouter(ctx: QuestionnaireRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /** Load a question and confirm the caller owns its parent project. */
  function ownedQuestion(questionId: string, researcherId: string) {
    const question = findQuestionById(ctx.db, questionId);
    if (!question) throw ApiError.notFound('题目不存在。');
    requireQuestionnaireForResearcher(ctx.db, question.questionnaire_id, researcherId);
    return question;
  }

  router.patch(
    '/:questionId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const question = ownedQuestion(req.params['questionId']!, researcher.id);
      const body = asRecord(req.body);

      const patch: Parameters<typeof updateQuestion>[2] = {};
      if (typeof body['question_code'] === 'string') patch.question_code = body['question_code'];
      if (typeof body['question_text'] === 'string') patch.question_text = body['question_text'];
      if (typeof body['question_type'] === 'string') patch.question_type = body['question_type'] as QuestionType;
      if ('options' in body) patch.options = (body['options'] as QuestionOptions) ?? {};
      if (typeof body['required'] === 'boolean') patch.required = body['required'];
      if ('dimension' in body) patch.dimension = (body['dimension'] as string | null) ?? null;
      if ('variable_name' in body) patch.variable_name = (body['variable_name'] as string | null) ?? null;
      if ('section' in body) patch.section = (body['section'] as string | null) ?? null;
      if ('help_text' in body) patch.help_text = (body['help_text'] as string | null) ?? null;
      if ('logic' in body) patch.logic = (body['logic'] as QuestionLogic | null) ?? null;
      if ('scoring_rule' in body) patch.scoring_rule = (body['scoring_rule'] as ScoringRule | null) ?? null;

      res.json({ data: updateQuestion(ctx.db, question.id, patch) });
    }),
  );

  router.delete(
    '/:questionId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const question = ownedQuestion(req.params['questionId']!, researcher.id);
      res.json({ data: deleteQuestion(ctx.db, question.id) });
    }),
  );

  router.post(
    '/:questionId/duplicate',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const question = ownedQuestion(req.params['questionId']!, researcher.id);
      res.status(201).json({ data: duplicateQuestion(ctx.db, question.id) });
    }),
  );

  router.post(
    '/:questionId/move',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const question = ownedQuestion(req.params['questionId']!, researcher.id);
      const body = asRecord(req.body);
      const direction = body['direction'] === 'up' ? 'up' : 'down';
      res.json({ data: moveQuestion(ctx.db, question.id, direction) });
    }),
  );

  return router;
}
