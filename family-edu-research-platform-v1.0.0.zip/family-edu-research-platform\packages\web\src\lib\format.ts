/** Presentation helpers. Kept pure so they can be unit tested. */

import { QUESTION_TYPE_LABELS, type QuestionType } from '@ferp/shared';

/** 460 -> "7分40秒"; null -> "—" (never render a fake zero). */
export function formatDuration(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined || !Number.isFinite(seconds)) return '—';
  const total = Math.max(0, Math.round(seconds));
  const minutes = Math.floor(total / 60);
  const rest = total % 60;
  if (minutes === 0) return `${rest}秒`;
  return `${minutes}分${rest}秒`;
}

/** 91.3 -> "91.3%"; null -> "—" so "no data" never looks like "0%". */
export function formatPercent(value: number | null | undefined, digits = 1): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return `${value.toFixed(digits)}%`;
}

export function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return value.toLocaleString('zh-CN');
}

export function formatStat(value: number | null | undefined, digits = 2): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return value.toFixed(digits);
}

/**
 * 0.0431 -> "p = 0.043"; anything below the three-decimal floor -> "p < 0.001".
 * Never "p = 0.000", which would misreport a small p as an impossible zero.
 */
export function formatPValue(value: number | null | undefined, digits = 3): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  if (value < 0.001) return 'p < 0.001';
  return `p = ${value.toFixed(digits)}`;
}

/** Conventional significance marker: *** p<.001, ** p<.01, * p<.05, none otherwise. */
export function significanceMark(value: number | null | undefined): '' | '*' | '**' | '***' {
  if (value === null || value === undefined || !Number.isFinite(value)) return '';
  if (value < 0.001) return '***';
  if (value < 0.01) return '**';
  if (value < 0.05) return '*';
  return '';
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '—';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function questionTypeLabel(type: QuestionType | string): string {
  return QUESTION_TYPE_LABELS[type as QuestionType] ?? String(type);
}

/* ------------------------------------------------------------------ */
/* Status presentation                                                */
/* ------------------------------------------------------------------ */

export type BadgeTone = 'neutral' | 'info' | 'success' | 'warning' | 'danger';

export const PROJECT_STATUS_META: Record<string, { label: string; tone: BadgeTone }> = {
  draft: { label: '草稿', tone: 'neutral' },
  collecting: { label: '收集中', tone: 'info' },
  paused: { label: '已暂停', tone: 'warning' },
  analyzing: { label: '分析中', tone: 'info' },
  completed: { label: '已完成', tone: 'success' },
  archived: { label: '已归档', tone: 'neutral' },
};

export const QUESTIONNAIRE_STATUS_META: Record<string, { label: string; tone: BadgeTone }> = {
  draft: { label: '草稿', tone: 'neutral' },
  published: { label: '已发布', tone: 'success' },
  closed: { label: '已关闭', tone: 'warning' },
};

export function projectStatusMeta(status: string): { label: string; tone: BadgeTone } {
  return PROJECT_STATUS_META[status] ?? { label: status, tone: 'neutral' };
}

export function questionnaireStatusMeta(status: string): { label: string; tone: BadgeTone } {
  return QUESTIONNAIRE_STATUS_META[status] ?? { label: status, tone: 'neutral' };
}

/** Shorten a long question stem for list views without cutting mid-word badly. */
export function truncate(text: string, max = 40): string {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (clean.length <= max) return clean;
  return `${clean.slice(0, max)}…`;
}
