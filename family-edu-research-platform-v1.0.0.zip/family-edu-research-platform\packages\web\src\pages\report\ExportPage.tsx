/**
 * Data export (PHASE 8).
 *
 * Every export is a pure read of the analysable sample (or of the last persisted
 * analysis), so this page is mostly a set of buttons — but they are buttons with
 * consequences for a published paper, which is why three things are stated
 * rather than assumed:
 *
 *  - **What each file is and what opens it.** A `.sps` file is useless without
 *    the data CSV beside it, and a codebook is useless if nobody knows it is one.
 *  - **The missing-value promise.** Missing answers and sensitive refusals are
 *    written as empty fields, never as 0 and never as a substantive category.
 *    The backend keeps that promise; the page makes it visible so a reader of the
 *    exported file knows what an empty cell means.
 *  - **What cannot be exported yet.** `results.xlsx` needs a persisted analysis
 *    bundle; without one the raw data and the codebook are still downloadable, and
 *    the page says exactly which file is unavailable and why.
 *
 * The downloads cannot be plain `<a href>` links: the endpoints require a bearer
 * token, so they go through `downloadFile`, which fetches with the auth header and
 * saves the bytes under the file name the server sent.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Badge, Button, Card, CardHeader, LoadingBlock } from '../../components/ui';
import {
  api,
  ApiClientError,
  type DownloadedFile,
} from '../../lib/api';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from '../analysis/shared';

interface ExportItem {
  key: string;
  label: string;
  /** Endpoint actually fetched; shown so the file can be audited against the API. */
  path: string;
  contains: string;
  consumer: string;
  run: (projectId: string) => Promise<DownloadedFile>;
  /** True when the file needs a persisted analysis bundle. */
  needsBundle?: boolean;
}

interface ExportGroup {
  title: string;
  description: string;
  items: ExportItem[];
}

const GROUPS: ExportGroup[] = [
  {
    title: '原始数据',
    description: '一行一份有效样本的分析数据集，可直接导入统计软件。',
    items: [
      {
        key: 'dataset_csv',
        label: '下载 dataset.csv',
        path: '/api/projects/:projectId/export/dataset.csv',
        contains:
          '宽表 CSV：每行一份样本、每列一个变量，带 UTF-8 BOM，Excel 直接双击即可正确显示中文；缺失值为空字段。',
        consumer: 'Excel、SPSS、R、Stata、Python（pandas）等所有统计软件。',
        run: (projectId) => api.export.datasetCsv(projectId),
      },
      {
        key: 'dataset_json',
        label: '下载 dataset.json',
        path: '/api/projects/:projectId/export/dataset.json',
        contains:
          '同一批数据的 JSON：数据行之外还包含元数据（样本构成、排除说明、导出时间）与变量字典，缺失值为 null。',
        consumer: '需要自带元数据的程序化分析（Python、R、JavaScript）。',
        run: (projectId) => api.export.datasetJson(projectId),
      },
    ],
  },
  {
    title: '变量字典与编码簿',
    description: '解读数据文件里每一列是什么、每个数字代表什么。',
    items: [
      {
        key: 'codebook_csv',
        label: '下载 codebook.csv',
        path: '/api/projects/:projectId/export/codebook.csv',
        contains:
          '变量字典（变量名、题目、维度、测量层次、编码方式、缺失值定义、计分规则、适用分析方法、是否派生变量）加逐选项的编码簿，两段各带表头。',
        consumer: '论文附录、SPSS 变量视图对照、复核者核对编码。',
        run: (projectId) => api.export.codebookCsv(projectId),
      },
    ],
  },
  {
    title: 'SPSS',
    description: '语法文件与它读取的数据文件；两者需要放在同一目录下使用。',
    items: [
      {
        key: 'spss_zip',
        label: '下载 SPSS 压缩包（.zip）',
        path: '/api/projects/:projectId/export/spss',
        contains:
          '一个 ZIP，内含 .sps 语法文件与配套的无 BOM 数据 CSV，解压后直接运行语法即可完成导入、变量标签、缺失值声明与值标签设置。',
        consumer: 'SPSS Statistics（解压后运行 .sps）。',
        run: (projectId) => api.export.spssArchive(projectId),
      },
      {
        key: 'spss_syntax',
        label: '仅下载 .sps 语法',
        path: '/api/projects/:projectId/export/spss/syntax',
        contains: 'SPSS 语法文件：变量类型、宽度、标签、缺失值（MISSING VALUES）与值标签声明。',
        consumer: 'SPSS；适合已经单独取得数据文件的场景。',
        run: (projectId) => api.export.spssSyntax(projectId),
      },
      {
        key: 'spss_data',
        label: '仅下载 SPSS 数据 CSV',
        path: '/api/projects/:projectId/export/spss/data',
        contains:
          '语法文件读取的数据 CSV，刻意不带 BOM：SPSS 的 /TYPE=TXT 会把 BOM 当作第一个变量名的一部分，编码改由语法中的 /ENCODING 声明。',
        consumer: 'SPSS（配合上面的 .sps 语法使用）。',
        run: (projectId) => api.export.spssData(projectId),
      },
    ],
  },
  {
    title: '分析结果工作簿',
    description: '把已经保存的统计分析结果整理成多工作表 Excel。',
    items: [
      {
        key: 'results_xlsx',
        label: '下载 results.xlsx',
        path: '/api/projects/:projectId/export/results.xlsx',
        contains:
          '多工作表工作簿：原始数据、变量字典、编码簿，以及描述统计、信度、效度、相关、回归、组间比较与假设检验等结果表。',
        consumer: 'Excel / WPS；也是论文附录的常用形式。',
        run: (projectId) => api.export.resultsXlsx(projectId),
        needsBundle: true,
      },
    ],
  },
];

type BundleState =
  | { state: 'checking' }
  | { state: 'ready' }
  | { state: 'missing'; reason: string }
  | { state: 'unknown'; reason: string };

export function ExportPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [bundle, setBundle] = useState<BundleState>({ state: 'checking' });
  const [running, setRunning] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [filenames, setFilenames] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    if (!projectId) return;
    setBundle({ state: 'checking' });
    try {
      const response = await api.analysis.bundle(projectId);
      if (response && response.available === false) {
        setBundle({ state: 'missing', reason: response.reason });
      } else {
        setBundle({ state: 'ready' });
      }
    } catch (err) {
      // Not knowing is its own state: the buttons stay usable and the server's
      // own refusal is what the researcher sees if a file is not available.
      setBundle({
        state: 'unknown',
        reason: err instanceof ApiClientError ? err.message : '无法确认是否已生成统计结果包。',
      });
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleDownload(item: ExportItem): Promise<void> {
    if (!projectId) return;
    setRunning(item.key);
    setErrors((previous) => {
      const next = { ...previous };
      delete next[item.key];
      return next;
    });
    try {
      const file = await item.run(projectId);
      setFilenames((previous) => ({ ...previous, [item.key]: file.filename }));
      if (!file.started && file.note) {
        setErrors((previous) => ({ ...previous, [item.key]: file.note ?? '' }));
      }
    } catch (err) {
      setErrors((previous) => ({
        ...previous,
        [item.key]: err instanceof ApiClientError ? err.message : '导出失败，请稍后重试。',
      }));
    } finally {
      setRunning(null);
    }
  }

  const workbookBlocked = bundle.state === 'missing';

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Export"
          subtitle="数据导出：原始数据、变量字典、SPSS 文件与分析结果工作簿，全部为当前可分析样本的真实数据。"
          state={state}
        />

        {bundle.state === 'checking' && <LoadingBlock label="正在确认统计结果包状态…" />}

        {bundle.state === 'missing' && (
          <Alert tone="warning" title="尚未运行完整统计分析：分析结果工作表无法导出">
            <p>{bundle.reason}</p>
            <p className="mt-1">
              这不影响其余文件：<strong>原始数据（dataset.csv / dataset.json）、变量字典（codebook.csv）与 SPSS 文件
              现在就可以导出</strong>
              ；只有依赖结果包的 <code className="font-mono">results.xlsx</code> 无法生成，因为分析工作表里的每一个数字
              都必须来自已经保存的结果包，平台不会临时重算或留空。
            </p>
            <p className="mt-3">
              <Link to={`/analysis?project=${projectId}`}>
                <Button variant="primary">前往统计分析并运行全部分析</Button>
              </Link>
            </p>
          </Alert>
        )}

        {bundle.state === 'unknown' && (
          <Alert tone="info" title="无法确认统计结果包状态">
            <p>{bundle.reason}</p>
            <p className="mt-1">
              导出的文件仍然可用；如果结果包尚未生成，服务端会在下载 <code className="font-mono">results.xlsx</code>
              时返回明确的拒绝原因。
            </p>
          </Alert>
        )}

        <MethodNote title="导出数据的两个承诺（由后端保证，界面据此说明）">
          <p>
            一、<strong>缺失值一律导出为空</strong>：未作答与敏感拒答在 CSV 中是空字段、在 Excel 中是空单元格、在 JSON 中是
            <code className="mx-1 font-mono">null</code>
            ，绝不写成 0，也绝不记为某一实质类别。空单元格就是「没有这个值」，不是「值为零」。
          </p>
          <p>
            二、<strong>敏感拒答不作为数据导出</strong>：选择「不愿回答」的题目与未作答同样按缺失处理，既不做插补，
            也不会作为一种类别出现在数据文件、编码簿或任何统计量中。
          </p>
          <p>
            另外，导出的样本范围是「可分析样本」：已完成且未被研究者排除的样本才会进入导出文件；
            被排除的样本数量与说明写在 JSON 元数据与结果工作簿中，因此文件行数与收集总数可能不同，这不是丢数据。
          </p>
        </MethodNote>

        {GROUPS.map((group) => (
          <Card key={group.title}>
            <CardHeader title={group.title} description={group.description} />

            <ul className="space-y-3">
              {group.items.map((item) => {
                const blocked = item.needsBundle === true && workbookBlocked;
                return (
                  <li key={item.key} className="rounded-md border border-ink-200 px-3.5 py-3">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-ink-900">{item.label}</p>
                        <p className="mt-1 text-xs leading-relaxed text-ink-600">{item.contains}</p>
                        <p className="mt-1 text-xs text-ink-500">{`适用工具：${item.consumer}`}</p>
                        <p className="mt-1 font-mono text-[11px] text-ink-400">{item.path}</p>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1">
                        <Button
                          variant="secondary"
                          loading={running === item.key}
                          disabled={blocked}
                          onClick={() => void handleDownload(item)}
                        >
                          {item.label}
                        </Button>
                        {blocked && <Badge tone="warning">需要先运行全部分析</Badge>}
                        {filenames[item.key] && (
                          <span className="max-w-64 break-all text-right text-[11px] text-ink-500">
                            {`已下载为：${filenames[item.key]}`}
                          </span>
                        )}
                      </div>
                    </div>

                    {errors[item.key] && (
                      <p className="mt-2 text-xs text-red-700">{errors[item.key]}</p>
                    )}
                  </li>
                );
              })}
            </ul>
          </Card>
        ))}

        <MethodNote title="文件命名与下载方式">
          <p>
            文件名由服务端按项目名称与导出日期生成（中文项目名会同时在响应头中给出 UTF-8 与 ASCII 两种形式）。
            平台不在前端重复实现这套命名规则——两套规则迟早会不一致；因此每个文件的实际名称在点击下载后显示在按钮下方，
            与浏览器保存下来的文件名一致。
          </p>
          <p>
            下载接口需要登录令牌，所以这里不使用普通链接：文件通过带身份校验的请求取回后交给浏览器保存，
            取不到时会明确报错，不会给你一个内容为 401 的「CSV」。
          </p>
          <p>
            研究报告的 Markdown 正文在{' '}
            <Link className="text-brand-700 underline" to={`/report?project=${projectId}`}>
              Reports
            </Link>{' '}
            页下载；报告与数据导出使用同一套命名前缀，便于在下载目录中对应。
          </p>
        </MethodNote>
      </div>
    </AnalysisProjectGate>
  );
}
