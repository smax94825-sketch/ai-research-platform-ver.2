import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Alert,
  Badge,
  Button,
  Card,
  EmptyState,
  Input,
  LoadingBlock,
  Modal,
  Select,
} from '../components/ui';
import { api, ApiClientError, type ProjectListResult, type ResearchProject } from '../lib/api';
import { formatDate, formatNumber, projectStatusMeta } from '../lib/format';

export function ProjectsPage(): ReactNode {
  const navigate = useNavigate();
  const [data, setData] = useState<ProjectListResult | null>(null);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [pendingDelete, setPendingDelete] = useState<ResearchProject | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.projects.list({
        ...(search.trim() ? { search: search.trim() } : {}),
        ...(status ? { status: status as ResearchProject['status'] } : {}),
        limit: 200,
      });
      setData(result);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载研究项目列表。');
    } finally {
      setLoading(false);
    }
  }, [search, status]);

  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 250);
    return () => window.clearTimeout(timer);
  }, [load]);

  async function confirmDelete(): Promise<void> {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      await api.projects.remove(pendingDelete.id);
      setPendingDelete(null);
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '删除失败。');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-ink-900">Research Projects</h1>
          <p className="mt-1 text-sm text-ink-500">
            每个研究项目包含独立的研究设计、问卷版本与样本数据。您只能访问自己创建的项目。
          </p>
        </div>
        <Link to="/projects/new">
          <Button variant="primary">新建研究</Button>
        </Link>
      </div>

      <Card>
        <div className="flex flex-wrap items-end gap-3">
          <label className="flex-1 min-w-56">
            <span className="ferp-label">搜索</span>
            <Input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="按研究名称或研究背景搜索"
            />
          </label>
          <label className="min-w-40">
            <span className="ferp-label">状态</span>
            <Select value={status} onChange={(event) => setStatus(event.target.value)}>
              <option value="">全部状态</option>
              <option value="draft">草稿</option>
              <option value="collecting">收集中</option>
              <option value="paused">已暂停</option>
              <option value="analyzing">分析中</option>
              <option value="completed">已完成</option>
              <option value="archived">已归档</option>
            </Select>
          </label>
          <Button onClick={() => void load()}>刷新</Button>
        </div>
      </Card>

      {error && (
        <Alert tone="danger" title="操作失败">
          {error}
        </Alert>
      )}

      {loading && !data ? (
        <LoadingBlock />
      ) : !data || data.items.length === 0 ? (
        <EmptyState
          title={search || status ? '没有符合条件的项目' : '还没有研究项目'}
          description={
            search || status
              ? '请调整搜索条件或状态筛选。'
              : '使用默认模板可一键载入完整研究设计（研究问题、H1—H8 假设、分阶段配额）与 58 道题目的问卷。'
          }
          action={
            search || status ? (
              <Button
                onClick={() => {
                  setSearch('');
                  setStatus('');
                }}
              >
                清除筛选
              </Button>
            ) : (
              <Link to="/projects/new">
                <Button variant="primary">新建研究项目</Button>
              </Link>
            )
          }
        />
      ) : (
        <>
          <p className="text-sm text-ink-500">
            共 {data.total} 个项目
            {data.items.length < data.total && `（当前显示前 ${data.items.length} 个）`}
          </p>
          <div className="grid gap-4 lg:grid-cols-2">
            {data.items.map((project) => {
              const meta = projectStatusMeta(project.status);
              return (
                <Card key={project.id}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <button
                        type="button"
                        className="text-left text-base font-semibold text-ink-900 hover:text-brand-700"
                        onClick={() => navigate(`/projects/${project.id}`)}
                      >
                        {project.title}
                      </button>
                      <div className="mt-1.5 flex flex-wrap items-center gap-2">
                        <Badge tone={meta.tone}>{meta.label}</Badge>
                        <span className="text-xs text-ink-500">
                          更新于 {formatDate(project.updated_at)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="mt-3 line-clamp-2 text-sm text-ink-600">
                    {project.description ?? project.background ?? '（未填写研究简介）'}
                  </p>

                  <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-ink-100 pt-3 text-xs">
                    <div>
                      <dt className="text-ink-500">目标样本</dt>
                      <dd className="mt-0.5 tabular-nums font-medium text-ink-800">
                        {formatNumber(project.target_sample_size)}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-ink-500">研究问题</dt>
                      <dd className="mt-0.5 tabular-nums font-medium text-ink-800">
                        {project.research_questions.length}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-ink-500">研究假设</dt>
                      <dd className="mt-0.5 tabular-nums font-medium text-ink-800">
                        {project.hypotheses.length}
                      </dd>
                    </div>
                  </dl>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <Link to={`/projects/${project.id}`}>
                      <Button>打开项目</Button>
                    </Link>
                    <Button variant="danger" onClick={() => setPendingDelete(project)}>
                      删除
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}

      <Modal
        open={pendingDelete !== null}
        title="确认删除研究项目"
        onClose={() => setPendingDelete(null)}
        footer={
          <>
            <Button onClick={() => setPendingDelete(null)}>取消</Button>
            <Button variant="danger" loading={deleting} onClick={() => void confirmDelete()}>
              确认删除
            </Button>
          </>
        }
      >
        <p className="text-sm text-ink-700">
          即将删除项目「{pendingDelete?.title}」。该操作会<strong>同时删除</strong>其下所有问卷版本、题目、
          受访者与作答记录，且不可恢复。
        </p>
        <Alert tone="warning" title="请确认">
          如果该项目已开始收集数据，请先导出数据备份。
        </Alert>
      </Modal>
    </div>
  );
}
