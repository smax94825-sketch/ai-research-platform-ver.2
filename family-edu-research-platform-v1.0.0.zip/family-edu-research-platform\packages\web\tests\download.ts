/**
 * Download test helpers.
 *
 * jsdom has no download machinery: `URL.createObjectURL` is absent and clicking
 * a `download` anchor would make jsdom attempt a navigation it does not
 * implement. These helpers install just enough of the browser contract to
 * observe what a page asked for, without pretending to save a file.
 */

/** A Response carrying a file body and the server's own `content-disposition`. */
export function fileResponse(body: string, filename: string, contentType = 'text/markdown; charset=utf-8'): Response {
  const bytes = new TextEncoder().encode(body);
  const encoded = encodeURIComponent(filename).replace(
    /['()*]/g,
    (character) => `%${character.charCodeAt(0).toString(16).toUpperCase()}`,
  );
  return {
    ok: true,
    status: 200,
    headers: new Headers({
      'content-type': contentType,
      'content-disposition': `attachment; filename="export.${filename.split('.').pop() ?? 'bin'}"; filename*=UTF-8''${encoded}`,
    }),
    text: async () => body,
    arrayBuffer: async () => bytes.buffer,
    blob: async () => ({ size: bytes.byteLength, type: contentType }) as unknown as Blob,
  } as unknown as Response;
}

export interface DownloadHost {
  /** Anchors the page clicked, in order. */
  clicks: HTMLAnchorElement[];
  /** Object URLs created, so a caller can check the bytes were wrapped. */
  objectUrls: string[];
  restore: () => void;
}

/** Patch the browser download surface for the duration of a test. */
export function stubDownloadHost(): DownloadHost {
  const clicks: HTMLAnchorElement[] = [];
  const objectUrls: string[] = [];

  const originalCreate = URL.createObjectURL;
  const originalRevoke = URL.revokeObjectURL;
  const originalClick = window.HTMLAnchorElement.prototype.click;

  URL.createObjectURL = (() => {
    const url = `blob:mock-${objectUrls.length + 1}`;
    objectUrls.push(url);
    return url;
  }) as typeof URL.createObjectURL;
  URL.revokeObjectURL = (() => undefined) as typeof URL.revokeObjectURL;
  window.HTMLAnchorElement.prototype.click = function click(this: HTMLAnchorElement): void {
    clicks.push(this);
  };

  return {
    clicks,
    objectUrls,
    restore: () => {
      URL.createObjectURL = originalCreate;
      URL.revokeObjectURL = originalRevoke;
      window.HTMLAnchorElement.prototype.click = originalClick;
    },
  };
}
