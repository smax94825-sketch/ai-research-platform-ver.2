/**
 * Input validation for research projects, questionnaires and questions.
 *
 * Validation lives in the shared package so the API, the builder UI and the
 * tests enforce exactly the same rules — a questionnaire that the builder
 * accepts can never be rejected by the publisher for a different reason.
 */

import {
  CHOICE_BASED_TYPES,
  QUESTION_TYPES,
  type LogicRule,
  type QuestionOption,
  type QuestionOptions,
  type QuestionType,
  type ScoringRule,
} from './types.js';
import { conditionsOf } from './logic.js';

export interface ValidationIssue {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
}

function fail(field: string, message: string): ValidationIssue {
  return { field, message };
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

/* ------------------------------------------------------------------ */
/* Question validation                                                */
/* ------------------------------------------------------------------ */

export interface QuestionInput {
  question_code?: unknown;
  question_text?: unknown;
  question_type?: unknown;
  options?: unknown;
  required?: unknown;
  dimension?: unknown;
  variable_name?: unknown;
  scoring_rule?: unknown;
  logic?: unknown;
}

function validateOptions(
  type: QuestionType,
  options: QuestionOptions | undefined,
  errors: ValidationIssue[],
): void {
  const choices = options?.choices;

  if (CHOICE_BASED_TYPES.includes(type)) {
    if (!Array.isArray(choices) || choices.length === 0) {
      errors.push(fail('options.choices', `题型 ${type} 必须至少包含一个选项。`));
    }
  }

  if (type === 'likert') {
    if (!Array.isArray(choices) || choices.length < 2) {
      errors.push(fail('options.choices', '李克特量表至少需要 2 个刻度。'));
    }
  }

  if (type === 'matrix') {
    const matrix = options?.matrix;
    if (!matrix) {
      errors.push(fail('options.matrix', '矩阵题必须提供 matrix.rows 与 matrix.columns。'));
      return;
    }
    if (!Array.isArray(matrix.rows) || matrix.rows.length === 0) {
      errors.push(fail('options.matrix.rows', '矩阵题至少需要一行。'));
    }
    if (!Array.isArray(matrix.columns) || matrix.columns.length < 2) {
      errors.push(fail('options.matrix.columns', '矩阵题至少需要两个评价刻度。'));
    }
  }

  if (type === 'knowledge_test') {
    if (!Array.isArray(choices) || choices.length === 0) return;
    const correct = choices.filter((c) => c.isCorrect === true);
    if (correct.length === 0) {
      errors.push(fail('options.choices', '知识测试题必须标记一个正确答案。'));
    }
  }

  if (type === 'ranking') {
    if (!Array.isArray(choices) || choices.length < 2) {
      errors.push(fail('options.choices', '排序题至少需要两个待排序选项。'));
    }
  }

  if (type === 'multiple' && Array.isArray(choices)) {
    const meaningful = choices.filter((c) => !c.exclusive);
    if (meaningful.length === 0) {
      errors.push(fail('options.choices', '多选题至少需要一个非互斥选项。'));
    }
  }

  // Duplicate option codes would silently corrupt the stored answer codes.
  if (Array.isArray(choices)) {
    const seen = new Set<string>();
    for (const choice of choices) {
      const code = String((choice as QuestionOption).value ?? '');
      if (code === '') {
        errors.push(fail('options.choices', '选项代码不能为空。'));
        continue;
      }
      if (seen.has(code)) {
        errors.push(fail('options.choices', `选项代码重复：${code}。`));
      }
      seen.add(code);
    }
  }
}

function validateScoringRule(
  type: QuestionType,
  rule: ScoringRule | undefined,
  options: QuestionOptions | undefined,
  errors: ValidationIssue[],
): void {
  if (!rule) return;
  if (rule.type === 'knowledge' && type !== 'knowledge_test') {
    errors.push(fail('scoring_rule', 'knowledge 计分规则只能用于知识测试题。'));
  }
  if (type === 'knowledge_test' && rule.type !== 'knowledge' && rule.type !== 'none') {
    errors.push(fail('scoring_rule', '知识测试题应使用 knowledge 计分规则。'));
  }
  if (rule.type === 'reverse' && rule.min >= rule.max) {
    errors.push(fail('scoring_rule', '反向计分的 min 必须小于 max。'));
  }
  if (rule.type === 'categorical' || rule.type === 'ordinal') {
    const codes = options?.choices ?? [];
    for (const choice of codes) {
      if (!(String(choice.value) in rule.codes)) {
        errors.push(
          fail('scoring_rule', `分类编码缺少选项 ${choice.value} 的映射，会导致该选项被静默丢弃。`),
        );
      }
    }
  }
}

function validateLogicRules(
  type: QuestionType,
  logic: { rules?: LogicRule[] } | undefined,
  errors: ValidationIssue[],
): void {
  if (!logic?.rules) return;
  for (const rule of logic.rules) {
    if (!rule.id) errors.push(fail('logic', '每条逻辑规则必须包含 id。'));
    if (!rule.action || typeof rule.action.type !== 'string') {
      errors.push(fail('logic', '逻辑规则缺少 action。'));
      continue;
    }
    const conditions = conditionsOf(rule);
    if (conditions.length === 0) {
      errors.push(fail('logic', '逻辑规则缺少条件。'));
    }
    for (const condition of conditions) {
      if (!isNonEmptyString(condition.questionCode)) {
        errors.push(fail('logic', '逻辑条件缺少 questionCode。'));
      }
      const needsValue =
        condition.operator !== 'answered' && condition.operator !== 'not_answered';
      if (needsValue && (condition.value === undefined || condition.value === null)) {
        errors.push(fail('logic', `逻辑运算符 ${condition.operator} 需要提供比较值。`));
      }
    }
    if (rule.action.type === 'jump_to' && !isNonEmptyString(rule.action.target)) {
      errors.push(fail('logic', '跳转规则缺少目标题目代码。'));
    }
    if (rule.action.type === 'jump_to' && type === 'page_break') {
      errors.push(fail('logic', '分页题不应设置跳转逻辑。'));
    }
  }
}

/** Validate a single question definition before it is persisted. */
export function validateQuestionInput(input: QuestionInput): ValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  const type = input.question_type as QuestionType;
  if (!isNonEmptyString(input.question_code)) {
    errors.push(fail('question_code', '题号不能为空，例如 Q1。'));
  }
  if (!QUESTION_TYPES.includes(type)) {
    errors.push(fail('question_type', `不支持的题型：${String(input.question_type)}。`));
    return { valid: false, errors, warnings };
  }
  if (type !== 'page_break' && type !== 'matrix') {
    if (!isNonEmptyString(input.question_text)) {
      errors.push(fail('question_text', '题干不能为空。'));
    }
  }
  if (type === 'matrix' && !isNonEmptyString(input.question_text)) {
    warnings.push(fail('question_text', '建议为矩阵题填写引导语（题干）。'));
  }

  const options = (input.options ?? {}) as QuestionOptions;
  validateOptions(type, options, errors);
  validateScoringRule(type, input.scoring_rule as ScoringRule | undefined, options, errors);
  validateLogicRules(type, input.logic as { rules?: LogicRule[] } | undefined, errors);

  const variableName = input.variable_name;
  if (isNonEmptyString(variableName) && !/^[A-Za-z][A-Za-z0-9_]*$/.test(variableName)) {
    errors.push(
      fail('variable_name', '变量名必须以字母开头，且只能包含字母、数字和下划线（SPSS 兼容要求）。'),
    );
  }
  if (isNonEmptyString(variableName) && variableName.length > 32) {
    warnings.push(fail('variable_name', 'SPSS 变量名建议不超过 32 个字符。'));
  }

  return { valid: errors.length === 0, errors, warnings };
}

/* ------------------------------------------------------------------ */
/* Questionnaire-level validation                                     */
/* ------------------------------------------------------------------ */

export interface QuestionnaireQuestionLike {
  question_code: string;
  question_type: QuestionType;
  question_text: string;
  sort_order: number;
  logic?: { rules?: LogicRule[] } | null;
}

/** Validate a whole instrument before publishing. */
export function validateQuestionnaireForPublish(questions: QuestionnaireQuestionLike[]): ValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  const answerable = questions.filter((q) => q.question_type !== 'page_break');
  if (answerable.length === 0) {
    errors.push(fail('questions', '问卷至少需要一道可作答的题目才能发布。'));
  }

  const seen = new Set<string>();
  for (const question of questions) {
    if (seen.has(question.question_code)) {
      errors.push(fail('question_code', `题号重复：${question.question_code}。`));
    }
    seen.add(question.question_code);
    if (!isNonEmptyString(question.question_code)) {
      errors.push(fail('question_code', '存在题号为空的题目。'));
    }
  }

  const orders = [...questions].map((q) => q.sort_order).sort((a, b) => a - b);
  for (let i = 0; i < orders.length; i += 1) {
    if (orders[i] !== i + 1) {
      warnings.push(fail('sort_order', '题目排序序号不连续，发布时将自动重新编号。'));
      break;
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}

/* ------------------------------------------------------------------ */
/* Project validation                                                 */
/* ------------------------------------------------------------------ */

export interface ProjectInput {
  title?: unknown;
  target_sample_size?: unknown;
  target_population?: unknown;
  research_questions?: unknown;
  hypotheses?: unknown;
}

export function validateProjectInput(input: ProjectInput): ValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];

  if (!isNonEmptyString(input.title)) {
    errors.push(fail('title', '研究名称不能为空。'));
  } else if (input.title.trim().length > 200) {
    errors.push(fail('title', '研究名称不能超过 200 个字符。'));
  }

  if (input.target_sample_size !== undefined && input.target_sample_size !== null) {
    const n = Number(input.target_sample_size);
    if (!Number.isFinite(n) || !Number.isInteger(n) || n <= 0) {
      errors.push(fail('target_sample_size', '目标样本量必须是正整数。'));
    } else if (n < 30) {
      warnings.push(fail('target_sample_size', '目标样本量低于 30，统计检验的效力可能不足。'));
    } else if (n > 100000) {
      errors.push(fail('target_sample_size', '目标样本量超出平台单项目上限（100000）。'));
    }
  }

  if (Array.isArray(input.research_questions) && input.research_questions.length === 0) {
    warnings.push(fail('research_questions', '尚未填写研究问题，建议在收集数据前补充。'));
  }
  if (Array.isArray(input.hypotheses) && input.hypotheses.length === 0) {
    warnings.push(fail('hypotheses', '尚未填写研究假设，后续将无法执行假设检验。'));
  }

  return { valid: errors.length === 0, errors, warnings };
}
