/**
 * Chart component tests (PHASE 6).
 *
 * The charts exist to make numbers legible, so the tests assert the NUMBERS:
 * every count, percentage, r value, p value and drop-off rate is rendered as
 * text, and these tests check that the text is present, complete (no row or
 * category silently dropped) and consistent with the data that was passed in.
 *
 * The significance markers are checked against the p values that were fed in,
 * and the box plot is checked for the honesty caveat it must carry when the API
 * gives it no quartiles.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';

import { clearContainer, closeDom } from './dom';
import { flush, queryAll, render, text } from './render';

const {
  BarChart,
  BoxPlot,
  FunnelChart,
  Heatmap,
  PieChart,
  ProgressBar,
  RegressionPlot,
  ScatterPlot,
  SourceChannelChart,
  StackedBarChart,
} = await import('../src/components/charts');

beforeEach(() => {
  clearContainer();
});

after(() => {
  closeDom();
});

/* ================================================================== */
/* BarChart                                                           */
/* ================================================================== */

describe('BarChart 频数条形图', () => {
  test('渲染每个类别的标签、人数与百分比', async () => {
    await render(
      createElement(BarChart, {
        data: [
          { label: '完全不同意', value: 12 },
          { label: '比较不同意', value: 30 },
          { label: '一般', value: 58 },
        ],
        caption: '合计 100 人。',
      }),
    );
    await flush();

    const content = text();
    assert.match(content, /完全不同意/, '应显示第一个类别');
    assert.match(content, /比较不同意/);
    assert.match(content, /一般/);
    // 12/100, 30/100, 58/100
    assert.ok(content.includes('12 人 · 12.0%'), `人数与百分比应同时出现：${content}`);
    assert.ok(content.includes('30 人 · 30.0%'));
    assert.ok(content.includes('58 人 · 58.0%'), '最后一个类别不能丢失');
    assert.match(content, /合计 100 人。/);
  });

  test('使用调用方给出的百分比而不是重新推算', async () => {
    await render(
      createElement(BarChart, {
        data: [{ label: 'A', value: 5, percent: 41.7 }],
        total: 12,
      }),
    );
    await flush();
    assert.ok(text().includes('5 人 · 41.7%'));
  });

  test('空数据渲染说明文字而不是空白图', async () => {
    await render(createElement(BarChart, { data: [], emptyText: '该变量暂无有效作答。' }));
    await flush();
    assert.match(text(), /该变量暂无有效作答。/);
  });
});

/* ================================================================== */
/* StackedBarChart                                                    */
/* ================================================================== */

describe('StackedBarChart 李克特发散堆叠图', () => {
  const OPTIONS = ['完全不同意', '比较不同意', '一般', '比较同意', '完全同意'];

  test('每条目给出 n、负面/中立/正面占比，并按选项列出合计', async () => {
    await render(
      createElement(StackedBarChart, {
        options: OPTIONS,
        rows: [
          { label: '条目一', counts: [2, 8, 10, 60, 20] },
          { label: '条目二', counts: [10, 10, 20, 40, 20] },
        ],
      }),
    );
    await flush();

    const content = text();
    // 条目一：负面 10/100、中立 10/100、正面 80/100
    assert.ok(content.includes('n = 100'), '应显示条目样本量');
    assert.match(content, /越偏否定 10\.0% · 中立 10\.0% · 越偏肯定 80\.0%/);
    // 条目二：负面 20、中立 20、正面 60
    assert.match(content, /越偏否定 20\.0% · 中立 20\.0% · 越偏肯定 60\.0%/);

    // 图例按选项给出合计：完全不同意 12、比较不同意 18、一般 30、比较同意 100、完全同意 40
    assert.ok(content.includes('完全不同意'));
    assert.ok(content.includes('12 人（6.0%）'), `图例应给出选项合计与占比：${content}`);
    assert.ok(content.includes('100 人（50.0%）'));
    assert.ok(content.includes('40 人（20.0%）'), '最后一个选项不能丢失');
    // 中央 0 线必须存在
    assert.ok(queryAll('line').length > 0, '应绘制中央 0 线');
  });

  test('偶数选项且无中立项时只在两侧分组，不虚构中立类别', async () => {
    await render(
      createElement(StackedBarChart, {
        options: ['很不同意', '不同意', '同意', '很同意'],
        rows: [{ label: '条目', counts: [5, 5, 30, 60] }],
      }),
    );
    await flush();

    const content = text();
    assert.match(content, /越偏否定 10\.0% · 越偏肯定 90\.0%/);
    assert.ok(!content.includes('中立 0.0%'), '没有中立选项时不应出现中立占比');
  });
});

/* ================================================================== */
/* PieChart                                                           */
/* ================================================================== */

describe('PieChart 构成占比', () => {
  test('图例列出标签、人数与百分比，并显示合计', async () => {
    await render(
      createElement(PieChart, {
        data: [
          { label: '已完成', value: 60 },
          { label: '作答中', value: 30 },
          { label: '已放弃', value: 10 },
        ],
        unit: '人',
      }),
    );
    await flush();

    const content = text();
    assert.match(content, /已完成/);
    assert.match(content, /作答中/);
    assert.match(content, /已放弃/);
    assert.ok(content.includes('60 人'), '应显示人数');
    assert.ok(content.includes('60.0%'), '应显示百分比');
    assert.ok(content.includes('30.0%'));
    assert.ok(content.includes('10.0%'), '最小的一块也必须列出');
    assert.match(content, /合计 100 人/, '应显示合计');
  });

  test('合计为零时给出空状态说明', async () => {
    await render(
      createElement(PieChart, { data: [{ label: '无', value: 0 }], emptyText: '暂无构成数据。' }),
    );
    await flush();
    assert.match(text(), /暂无构成数据。/);
  });
});

/* ================================================================== */
/* Heatmap                                                            */
/* ================================================================== */

describe('Heatmap 相关矩阵', () => {
  const VARIABLES = ['FSE', 'FED', 'UI'];
  const MATRIX = [
    [1, 0.62, -0.18],
    [0.62, 1, 0.05],
    [-0.18, 0.05, 1],
  ];
  // p values chosen so each marker band is exercised exactly once off-diagonal.
  const P_VALUES = [
    [0, 0.0004, 0.04],
    [0.0004, 0, 0.2],
    [0.04, 0.2, 0],
  ];
  const METHODS = [
    ['pearson', 'pearson', 'spearman'],
    ['pearson', 'pearson', 'spearman'],
    ['spearman', 'spearman', 'spearman'],
  ];

  test('每格显示相关系数，显著性标记与 p 值一致', async () => {
    await render(
      createElement(Heatmap, {
        variables: VARIABLES,
        matrix: MATRIX,
        pValues: P_VALUES,
        methods: METHODS,
      }),
    );
    await flush();

    const content = text();
    // p = 0.0004 -> ***, p = 0.04 -> *, p = 0.2 -> 无标记
    assert.ok(content.includes('0.62***'), `p<0.001 应标记 ***：${content}`);
    assert.ok(content.includes('-0.18*'), `p<0.05 应标记 *：${content}`);
    assert.ok(content.includes('0.05') && !content.includes('0.05*'), 'p≥0.05 不应出现星号');
    // 对角线为自身相关，不得因 p=0 被打上 ***
    assert.ok(content.includes('1.00'), '对角线应显示 1.00');
    assert.ok(!content.includes('1.00***'), '对角线不得标记显著性');
    assert.ok(!/1\.00\*/.test(content), '对角线不得带任何星号');
  });

  test('两轴标签与变量全称都显示出来', async () => {
    await render(
      createElement(Heatmap, {
        variables: VARIABLES,
        matrix: MATRIX,
        pValues: P_VALUES,
        labels: ['家庭教育自我效能', '家庭教育需求', '使用意向'],
      }),
    );
    await flush();

    const content = text();
    for (const code of VARIABLES) {
      assert.ok(content.includes(code), `轴标签缺少 ${code}`);
    }
    assert.match(content, /家庭教育自我效能/);
    assert.match(content, /使用意向/);
    assert.match(content, /p < 0.05/, '应说明显著性标记的含义');
  });

  test('空矩阵给出说明而不是空图', async () => {
    await render(createElement(Heatmap, { variables: [], matrix: [], emptyText: '无法计算相关矩阵。' }));
    await flush();
    assert.match(text(), /无法计算相关矩阵。/);
  });
});

/* ================================================================== */
/* BoxPlot                                                            */
/* ================================================================== */

describe('BoxPlot 组间箱线图', () => {
  test('四分位数可用时按中位数与四分位数绘制，并逐组给出统计量', async () => {
    await render(
      createElement(BoxPlot, {
        groups: [
          { label: '学前', n: 45, median: 3.5, q1: 3, q3: 4, minimum: 1, maximum: 5 },
          { label: '小学', n: 52, median: 3.8, q1: 3.2, q3: 4.2, minimum: 2, maximum: 5 },
        ],
      }),
    );
    await flush();

    const content = text();
    assert.match(content, /学前/);
    assert.match(content, /小学/);
    assert.ok(content.includes('n = 45 · 中位数 3.50 · Q1 3.00 · Q3 4.00'), `应给出四分位数：${content}`);
    assert.ok(content.includes('n = 52'), '第二组不能丢失');
    assert.ok(!content.includes('均值 ± 1 个标准差'), '有四分位数时不应给出均值箱体提示');
  });

  test('接口只给均值与标准差时，明确说明箱体不是四分位距', async () => {
    await render(
      createElement(BoxPlot, {
        groups: [{ label: '学前', n: 45, mean: 3.42, sd: 0.71, minimum: 1, maximum: 5, outliers: [5] }],
        valueLabel: '使用意向',
      }),
    );
    await flush();

    const content = text();
    assert.ok(content.includes('n = 45 · 均值 3.42 · SD 0.71'), `应以均值与标准差为箱体：${content}`);
    assert.match(content, /不是四分位距/, '必须声明箱体含义与四分位距不同');
    assert.match(content, /均值 ± 1 个标准差/);
    assert.match(content, /使用意向/, '应显示数值轴名称');
  });
});

/* ================================================================== */
/* ScatterPlot                                                        */
/* ================================================================== */

describe('ScatterPlot 散点图', () => {
  const POINTS = [
    { x: 3.2, y: 0.62, label: '条目一' },
    { x: 3.8, y: 0.41, label: '条目二' },
    { x: 4.1, y: 0.18, label: '条目三' },
  ];

  test('点数量、坐标与拟合直线都可见', async () => {
    await render(
      createElement(ScatterPlot, {
        points: POINTS,
        xLabel: '条目均值',
        yLabel: '题总相关 r',
        fit: { intercept: 1.2, slope: -0.25 },
      }),
    );
    await flush();

    const content = text();
    assert.match(content, /共 3 个数据点/, '应说明点数');
    assert.match(content, /条目均值/);
    assert.match(content, /题总相关 r/);
    assert.match(content, /y = 1\.200 \+ -0\.250 x/, '应说明拟合直线由引擎给出');

    const titles = queryAll('title').map((element) => element.textContent ?? '');
    assert.equal(titles.length, 3, '每个点都应带可读的说明');
    assert.ok(titles.some((title) => title.includes('条目一（x = 3.20, y = 0.62）')), titles.join(' | '));
  });

  test('聚焦某个点即显示其名称与坐标，无需鼠标', async () => {
    await render(createElement(ScatterPlot, { points: POINTS }));
    await flush();

    const circles = queryAll('circle');
    assert.equal(circles.length, 3);
    const focusable = circles.find((circle) => circle.getAttribute('aria-label')?.includes('条目二'));
    assert.ok(focusable, '每个点都应可通过 aria-label 识别');
    assert.equal(focusable!.getAttribute('tabindex'), '0', '点应可聚焦，便于键盘访问');
    assert.match(focusable!.getAttribute('aria-label') ?? '', /x = 3\.80/);

    (focusable as SVGCircleElement).focus();
    await flush();
    assert.match(text(), /条目二（3\.80, 0\.41）/, '聚焦后应显示标签');
  });
});

/* ================================================================== */
/* RegressionPlot                                                     */
/* ================================================================== */

describe('RegressionPlot 回归系数森林图', () => {
  test('逐项显示 B、95% 置信区间、β、VIF 与 p 值', async () => {
    await render(
      createElement(RegressionPlot, {
        coefficients: [
          {
            label: '数字素养',
            estimate: 0.412,
            ciLower: 0.28,
            ciUpper: 0.544,
            beta: 0.371,
            pValue: 0.0004,
            vif: 1.42,
          },
          { label: '科技压力', estimate: -0.08, ciLower: -0.21, ciUpper: 0.05, pValue: 0.231, vif: 6.8 },
        ],
      }),
    );
    await flush();

    const content = text();
    assert.ok(content.includes('0.412 [0.280, 0.544]'), `应显示系数与区间：${content}`);
    assert.ok(content.includes('β = 0.371'));
    assert.ok(content.includes('VIF = 1.42'));
    assert.ok(content.includes('p < 0.001'));
    assert.ok(content.includes('-0.080 [-0.210, 0.050]'), '第二个系数不能丢失');
    assert.ok(content.includes('VIF = 6.80'));
    assert.ok(content.includes('95% CI 包含 0（与 0 无显著差异）'), '区间跨 0 必须明示');
    assert.ok(!content.includes('0.412 [0.280, 0.544] · 95% CI 包含 0'), '区间不含 0 时不应标注跨 0');
  });
});

/* ================================================================== */
/* FunnelChart                                                        */
/* ================================================================== */

describe('FunnelChart 收集漏斗', () => {
  test('逐阶段显示数量与流失率，并列阶段不计算流失率', async () => {
    await render(
      createElement(FunnelChart, {
        stages: [
          { label: '开始作答', count: 500 },
          { label: '完成问卷', count: 400 },
          { label: '进入分析', count: 350 },
          { label: '被研究者排除', count: 50, detached: true },
        ],
      }),
    );
    await flush();

    const content = text();
    assert.ok(content.includes('500 份'), '应显示第一阶段数量');
    assert.ok(content.includes('350 份'), '应显示分析基数');
    assert.ok(content.includes('较「开始作答」减少 100 份（20.0%）'), `应给出流失率：${content}`);
    assert.ok(content.includes('较「完成问卷」减少 50 份（12.5%）'));
    assert.ok(!content.includes('较「进入分析」减少'), '并列阶段不应计算流失率');
    assert.match(content, /不属于上一阶段的子集/, '应说明并列阶段的计数关系');
  });
});

/* ================================================================== */
/* ProgressBar                                                        */
/* ================================================================== */

describe('ProgressBar 目标进度', () => {
  test('未达 / 已达 / 超出 / 未设目标 四种状态都可区分', async () => {
    await render(
      createElement(ProgressBar, {
        items: [
          { label: '学前', current: 120, target: 200 },
          { label: '小学', current: 150, target: 150 },
          { label: '初中', current: 168, target: 140 },
          { label: '高中', current: 30, target: 0 },
        ],
      }),
    );
    await flush();

    const content = text();
    assert.ok(content.includes('120/200 份 · 60.0% · 未达目标（尚缺 80 份）'), `未达目标：${content}`);
    assert.ok(content.includes('150/150 份 · 100.0% · 已达目标'));
    assert.ok(content.includes('168/140 份 · 120.0% · 超出目标（超出 +28 份）'));
    assert.ok(content.includes('未设定目标'), '未设目标的项目不应被当作 0% 进度');
    assert.ok(content.includes('该项目未设定目标样本量'));
    // 未达目标的斜纹填充与达标后的实心填充是两个不同的视觉对象。
    assert.ok(queryAll('pattern').length > 0, '未达目标应使用斜纹填充图案');
  });
});

/* ================================================================== */
/* SourceChannelChart                                                 */
/* ================================================================== */

describe('SourceChannelChart 样本来源渠道', () => {
  test('渠道显示中文名称、人数与占比，按人数排序', async () => {
    await render(
      createElement(SourceChannelChart, {
        sources: [
          { source: 'xiaohongshu', total: 20 },
          { source: 'wechat', total: 70 },
          { source: 'unknown_channel', total: 10 },
        ],
      }),
    );
    await flush();

    const content = text();
    assert.ok(content.includes('微信'), '应显示渠道中文名');
    assert.ok(content.includes('小红书'));
    assert.ok(content.includes('70 人 · 70.0%'), `应显示人数与占比：${content}`);
    assert.ok(content.includes('20 人 · 20.0%'));
    assert.ok(content.includes('unknown_channel'), '未命名的渠道应原样显示而不是被丢弃');

    const labels = queryAll('text').map((element) => element.textContent ?? '');
    const wechatIndex = labels.findIndex((label) => label === '微信');
    const xiaohongshuIndex = labels.findIndex((label) => label === '小红书');
    assert.ok(wechatIndex >= 0 && xiaohongshuIndex >= 0 && wechatIndex < xiaohongshuIndex, '应按人数降序排列');
  });
});
