/**
 * Data Collection → Sources.
 *
 * Channel reporting for the `?source=` parameter (spec §16): how many samples
 * each channel brought in, how many completed, and how many the researcher has
 * excluded. Completion rate is deliberately relative to each channel's own
 * total, so a high-volume channel with poor completion is visible rather than
 * being hidden by its volume.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { SOURCE_LABELS } from '@ferp/shared';
import { Alert, Button, Card, CardHeader, EmptyState, LoadingBlock, Select, StatCard } from '../components/ui';
import { api, ApiClientError, type ProjectListResult, type SourceBreakdown } from '../lib/api';
import { formatPercent } from '../lib/format';

export function SourcesPage(): ReactNode {
  const [searchParams, setSearchParams] = useSearchParams();
  const [projects, setProjects] = useState<ProjectListResult | null>(null);
  const [projectId, setProjectId] = useState('');
  const [breakdown, setBreakdown] = useState<SourceBreakdown | null>(null);
  const [shareToken, setShareToken] = useState<string | null>(null);
  const [publishedQuestionnaireId, setPublishedQuestionnaireId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const list = await api.projects.list({ limit: 200 });
        if (cancelled) return;
        setProjects(list);
        const requested = searchParams.get('project');
        setProjectId(requested ?? list.items[0]?.id ?? '');
        if (list.items.length === 0) setLoading(false);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiClientError ? err.message : '无法加载研究项目。');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      const [data, questionnaires] = await Promise.all([
        api.samples.sources(projectId),
        api.projects.questionnaires(projectId),
      ]);
      setBreakdown(data);
      const published = questionnaires.find((item) => item.share_token);
      setShareToken(published?.share_token ?? null);
      setPublishedQuestionnaireId(published?.id ?? null);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载渠道统计。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  if (!projects) return <LoadingBlock label="正在加载研究项目…" />;

  if (projects.items.length === 0) {
    return (
      <EmptyState
        title="还没有研究项目"
        description="渠道统计需要先有研究项目与已发布的问卷。"
        action={
          <Link to="/projects/new">
            <Button variant="primary">新建研究项目</Button>
          </Link>
        }
      />
    );
  }

  const baseUrl = `${window.location.origin}/research/${shareToken ?? ''}`;
  const totalSamples = breakdown?.total ?? 0;
  const completed = breakdown?.items.reduce((sum, item) => sum + item.completed, 0) ?? 0;
  const excluded = breakdown?.items.reduce((sum, item) => sum + item.excluded, 0) ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-ink-900">Sources</h1>
          <p className="mt-1 text-sm text-ink-500">
            按分享链接的 <code className="rounded bg-ink-100 px-1">?source=</code> 参数统计样本来源，
            用于分析不同渠道的样本结构与完成质量。
          </p>
        </div>
        <label className="flex items-center gap-2 text-sm text-ink-600">
          当前研究项目
          <Select
            className="min-w-56"
            value={projectId}
            onChange={(event) => {
              setProjectId(event.target.value);
              setSearchParams({ project: event.target.value });
            }}
          >
            {projects.items.map((project) => (
              <option key={project.id} value={project.id}>
                {project.title}
              </option>
            ))}
          </Select>
        </label>
      </div>

      {error && (
        <Alert tone="danger" title="加载失败">
          {error}
        </Alert>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="样本总数" value={totalSamples} />
        <StatCard label="已完成" value={completed} tone="success" />
        <StatCard label="渠道数量" value={breakdown?.items.length ?? 0} />
        <StatCard label="已排除" value={excluded} tone={excluded > 0 ? 'warning' : 'neutral'} hint="由研究者人工判定" />
      </div>

      {loading && !breakdown ? (
        <LoadingBlock />
      ) : !breakdown || breakdown.items.length === 0 ? (
        <EmptyState
          title="还没有样本来源数据"
          description="收到第一份作答后，这里会按渠道展示样本量与完成率。"
        />
      ) : (
        <Card padded={false}>
          <div className="border-b border-ink-200 px-5 py-4">
            <h2 className="text-base font-semibold text-ink-900">各渠道样本量与完成率</h2>
            <p className="mt-1 text-sm text-ink-500">
              完成率 = 该渠道已完成样本 / 该渠道全部样本。样本量小的渠道完成率波动较大，解读时请谨慎。
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-5 py-2 text-left">渠道</th>
                  <th className="px-5 py-2 text-left">source 参数</th>
                  <th className="px-5 py-2 text-right">样本数</th>
                  <th className="px-5 py-2 text-right">已完成</th>
                  <th className="px-5 py-2 text-right">进行中</th>
                  <th className="px-5 py-2 text-right">已中断</th>
                  <th className="px-5 py-2 text-right">完成率</th>
                  <th className="px-5 py-2 text-right">已排除</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {breakdown.items.map((item) => (
                  <tr key={item.source}>
                    <td className="px-5 py-2 text-ink-900">{SOURCE_LABELS[item.source] ?? item.source}</td>
                    <td className="px-5 py-2 font-mono text-xs text-ink-500">{item.source}</td>
                    <td className="px-5 py-2 text-right tabular-nums text-ink-900">
                      {item.total}
                      <span className="ml-1 text-xs text-ink-400">
                        ({totalSamples > 0 ? ((item.total / totalSamples) * 100).toFixed(1) : '0.0'}%)
                      </span>
                    </td>
                    <td className="px-5 py-2 text-right tabular-nums text-emerald-700">{item.completed}</td>
                    <td className="px-5 py-2 text-right tabular-nums text-ink-700">{item.in_progress}</td>
                    <td className="px-5 py-2 text-right tabular-nums text-amber-700">{item.abandoned}</td>
                    <td className="px-5 py-2 text-right tabular-nums font-medium text-ink-900">
                      {formatPercent(item.completion_rate)}
                    </td>
                    <td className="px-5 py-2 text-right tabular-nums text-red-700">
                      {item.excluded > 0 ? item.excluded : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Card>
        <CardHeader
          title="如何生成带来源追踪的链接"
          description="渠道参数附加在问卷分享链接之后，受访者无需任何额外操作。"
        />
        {!shareToken ? (
          <Alert tone="info" title="该项目的问卷尚未发布">
            发布问卷后即可获得分享链接与二维码，并可按渠道生成追踪链接。
          </Alert>
        ) : (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2">
              {['wechat', 'xiaohongshu', 'school', 'community', 'offline'].map((source) => (
                <code
                  key={source}
                  className="rounded border border-ink-200 bg-ink-50 px-2 py-1 text-xs text-ink-700"
                >
                  {baseUrl}?source={source}
                </code>
              ))}
            </div>
            <p className="text-xs text-ink-500">
              未带 <code className="rounded bg-ink-100 px-1">source</code> 参数的访问记为
              「直接访问（direct）」。来源参数只接受字母、数字、下划线与连字符，其他内容会被规范化为
              direct，因此不会被用于注入。
            </p>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => void load()}>刷新统计</Button>
              <Link to={`/collection/samples?project=${projectId}`}>
                <Button>查看样本列表</Button>
              </Link>
              <Link to={`/projects/${projectId}/questionnaires/${publishedQuestionnaireId}/builder?tab=publish`}>
                <Button variant="ghost">打开问卷发布页</Button>
              </Link>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
