/**
 * Respondent source channels.
 *
 * A thin, purpose-built wrapper over {@link BarChart}: channels are a frequency
 * distribution, so they get the same geometry and the same "count + percentage"
 * read-out, but the raw channel keys (`wechat`, `xiaohongshu`, …) are mapped to
 * their Chinese labels here rather than at every call site.
 */

import type { ReactNode } from 'react';
import { SOURCE_LABELS } from '@ferp/shared';
import { BarChart } from './BarChart';

export interface SourceChannelDatum {
  /** Raw channel key as stored on the respondent record. */
  source: string;
  total: number;
}

export interface SourceChannelChartProps {
  sources: SourceChannelDatum[];
  unit?: string;
  emptyText?: string;
  /** Overrides the platform's channel dictionary (for channels not yet named). */
  labels?: Record<string, string>;
  caption?: ReactNode;
}

export function SourceChannelChart({
  sources,
  unit = '人',
  emptyText = '暂无样本来源记录。',
  labels,
  caption,
}: SourceChannelChartProps): ReactNode {
  const data = [...sources]
    .sort((left, right) => right.total - left.total)
    .map((item) => ({
      label: labels?.[item.source] ?? SOURCE_LABELS[item.source] ?? item.source,
      value: item.total,
    }));

  return (
    <BarChart
      data={data}
      unit={unit}
      emptyText={emptyText}
      caption={caption ?? '按受访者进入问卷时携带的渠道参数统计；未携带参数时记为 unknown。'}
    />
  );
}
