/**
 * Scoring engine.
 *
 * Converts raw stored answers into analysis-ready numeric values. Kept strictly
 * separate from any AI layer: every number an AI later explains originates here.
 *
 * Two rules are non-negotiable in this module:
 *  1. A sensitive non-response ("不愿回答") is NEVER recoded into a substantive
 *     category. It becomes SENSITIVE_NONRESPONSE and is excluded from means.
 *  2. Missing answers become MISSING, not zero.
 */

import type {
  MatrixConfig,
  Question,
  QuestionOption,
  ScoringRule,
} from './types.js';
import { asNumber, type AnswerMap, type AnswerValue } from './values.js';

/** Value returned for an unanswered / not-applicable item. */
export const MISSING = Symbol.for('ferp.missing');
/** Value returned for an explicit sensitive refusal such as "不愿回答". */
export const SENSITIVE_NONRESPONSE = Symbol.for('ferp.sensitive_nonresponse');

export type ScoredValue = number | typeof MISSING | typeof SENSITIVE_NONRESPONSE;

export function isNumericScore(value: ScoredValue): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

/* ------------------------------------------------------------------ */
/* Option-level scoring                                               */
/* ------------------------------------------------------------------ */

/** Default Likert coding: 1..k following the declared option order. */
export function defaultOptionScore(option: QuestionOption, index: number): number {
  return option.score ?? index + 1;
}

export function findOption(choices: QuestionOption[] | undefined, value: unknown): QuestionOption | undefined {
  if (!choices) return undefined;
  return choices.find((o) => String(o.value) === String(value));
}

/**
 * Score one answer to one question.
 * Returns MISSING / SENSITIVE_NONRESPONSE where no numeric value is defined.
 */
export function scoreQuestionAnswer(question: Question, answer: AnswerValue): ScoredValue {
  const rule = question.scoring_rule ?? null;

  if (answer === null || answer === undefined) return MISSING;
  if (typeof answer === 'string' && answer.trim() === '') return MISSING;
  if (Array.isArray(answer) && answer.length === 0) return MISSING;

  const choices = question.options?.choices;

  switch (question.question_type) {
    case 'knowledge_test': {
      const value = typeof answer === 'string' ? answer : String(answer);
      const option = findOption(choices, value);
      if (option?.sensitiveNonResponse) return SENSITIVE_NONRESPONSE;
      if (!option) return MISSING;
      const knowledge =
        rule && rule.type === 'knowledge'
          ? rule
          : { type: 'knowledge' as const, correctScore: 1, incorrectScore: 0, unknownScore: 0, maxScore: 1 };
      if (knowledge.unknownValue !== undefined && String(value) === String(knowledge.unknownValue)) {
        return knowledge.unknownScore;
      }
      return option.isCorrect ? knowledge.correctScore : knowledge.incorrectScore;
    }

    case 'single':
    case 'dropdown':
    case 'likert': {
      const value = typeof answer === 'string' ? answer : String(answer);
      const options = choices ?? [];
      const index = options.findIndex((o) => String(o.value) === value);
      if (index === -1) return MISSING;
      const option = options[index]!;
      if (option.sensitiveNonResponse) return SENSITIVE_NONRESPONSE;
      // An explicitly declared code map wins over positional scoring, so a
      // researcher can map "不了解，无法判断" to *missing* rather than to a score.
      if (rule && (rule.type === 'categorical' || rule.type === 'ordinal')) {
        if (!(value in rule.codes)) return MISSING;
        const mapped = rule.codes[value];
        return mapped === null || mapped === undefined ? MISSING : mapped;
      }
      const base = defaultOptionScore(option, index);
      if (rule && rule.type === 'reverse') {
        return rule.min + rule.max - base;
      }
      return base;
    }

    case 'multiple':
    case 'ranking': {
      const selected = Array.isArray(answer) ? answer.map(String) : [String(answer)];
      const options = choices ?? [];
      const sensitive = selected.some((v) => findOption(options, v)?.sensitiveNonResponse);
      if (sensitive && selected.length === 1) return SENSITIVE_NONRESPONSE;
      if (rule && rule.type === 'count') {
        const counted = selected.filter((v) => {
          const opt = findOption(options, v);
          if (!opt) return false;
          if (rule.excludeExclusive !== false && opt.exclusive) return false;
          return true;
        });
        return counted.length;
      }
      return selected.length;
    }

    case 'matrix': {
      const rows = answer && typeof answer === 'object' && !Array.isArray(answer)
        ? (answer as Record<string, string>)
        : {};
      const matrix = question.options?.matrix;
      const values: number[] = [];
      for (const row of matrix?.rows ?? []) {
        const raw = rows[row.value];
        if (raw === undefined || raw === null || String(raw).trim() === '') {
          values.push(Number.NaN);
          continue;
        }
        const option = findOption(matrix?.columns, raw);
        if (!option) {
          values.push(Number.NaN);
          continue;
        }
        if (option.sensitiveNonResponse) {
          values.push(Number.NaN);
          continue;
        }
        const index = (matrix?.columns ?? []).findIndex((o) => String(o.value) === String(raw));
        values.push(defaultOptionScore(option, index));
      }
      const usable = values.filter((v) => Number.isFinite(v));
      if (usable.length === 0) return MISSING;
      return usable.reduce((a, b) => a + b, 0) / usable.length;
    }

    case 'number': {
      const num = asNumber(answer);
      return num === null ? MISSING : num;
    }

    case 'text':
    case 'textarea':
    case 'date':
    case 'page_break':
    default:
      return MISSING;
  }
}

/* ------------------------------------------------------------------ */
/* Rule-level application                                             */
/* ------------------------------------------------------------------ */

/** Apply a rule to an already-scored item vector (one question, many items). */
export function applyAggregateRule(rule: ScoringRule | null, values: ScoredValue[]): ScoredValue {
  const usable = values.filter(isNumericScore);
  if (usable.length === 0) {
    return values.some((v) => v === SENSITIVE_NONRESPONSE) ? SENSITIVE_NONRESPONSE : MISSING;
  }
  const sum = usable.reduce((a, b) => a + b, 0);
  switch (rule?.type) {
    case 'sum':
      return sum;
    case 'mean':
      return sum / usable.length;
    default:
      return sum;
  }
}

/* ------------------------------------------------------------------ */
/* Knowledge accuracy (LKA)                                           */
/* ------------------------------------------------------------------ */

export interface KnowledgeAccuracyResult {
  /** Number of items answered with a substantive (non-missing) response. */
  answered: number;
  /** Sum of item scores, i.e. the LKA index. */
  total: number;
  /** Maximum achievable score across the administered items. */
  maxScore: number;
  /** total / maxScore, or null when nothing was administered. */
  ratio: number | null;
  /** Item code -> 0/1 score, for item-level reporting. */
  items: Record<string, number>;
  /** Items answered "不清楚 / 不知道". */
  unknownCount: number;
  missingCount: number;
}

/**
 * Compute the objective law-knowledge index LKA over the Q12-Q16 block.
 * Correct = configured correctScore, incorrect = 0, "不清楚" = 0 (and counted
 * separately so subjective-objective discrepancy can be reported honestly).
 */
export function computeKnowledgeAccuracy(
  questions: Question[],
  answers: AnswerMap,
): KnowledgeAccuracyResult {
  const knowledgeQuestions = questions
    .filter((q) => q.question_type === 'knowledge_test')
    .sort((a, b) => a.sort_order - b.sort_order);

  const items: Record<string, number> = {};
  let total = 0;
  let maxScore = 0;
  let answered = 0;
  let unknownCount = 0;
  let missingCount = 0;

  for (const question of knowledgeQuestions) {
    const rule = question.scoring_rule;
    const perItemMax = rule && rule.type === 'knowledge' ? rule.maxScore : 1;
    maxScore += perItemMax;

    const raw = answers[question.question_code];
    const value = scoreQuestionAnswer(question, raw);
    if (isNumericScore(value)) {
      items[question.question_code] = value;
      total += value;
      answered += 1;
      // "不清楚" scores 0 exactly like a wrong answer, so it must be detected
      // from the raw response. Counting every 0 as "unknown" would overstate
      // non-response and understate genuine misconceptions.
      const declaredUnknown =
        rule && rule.type === 'knowledge' && rule.unknownValue !== undefined;
      if (declaredUnknown && String(raw ?? '') === String(rule.unknownValue)) {
        unknownCount += 1;
      }
    } else {
      items[question.question_code] = 0;
      missingCount += 1;
    }
  }

  return {
    answered,
    total,
    maxScore,
    ratio: maxScore > 0 ? total / maxScore : null,
    items,
    unknownCount,
    missingCount,
  };
}

/* ------------------------------------------------------------------ */
/* Matrix helpers                                                     */
/* ------------------------------------------------------------------ */

/** Item codes for a matrix question, e.g. Q35 -> FED1..FED7. */
export function matrixItemCodes(question: Question): string[] {
  const matrix: MatrixConfig | undefined = question.options?.matrix;
  return (matrix?.rows ?? []).map((row) =>
    question.variable_name ? `${question.variable_name}${row.value}` : `${question.question_code}_${row.value}`,
  );
}

/**
 * Extract per-row numeric scores from a matrix answer, preserving missing rows
 * as null so downstream statistics can report n per row honestly.
 */
export function matrixRowScores(question: Question, answer: AnswerValue): Record<string, number | null> {
  const matrix = question.options?.matrix;
  const rows = answer && typeof answer === 'object' && !Array.isArray(answer)
    ? (answer as Record<string, string>)
    : {};
  const out: Record<string, number | null> = {};
  for (const row of matrix?.rows ?? []) {
    const raw = rows[row.value];
    if (raw === undefined || raw === null || String(raw).trim() === '') {
      out[row.value] = null;
      continue;
    }
    const columns = matrix?.columns ?? [];
    const index = columns.findIndex((o) => String(o.value) === String(raw));
    if (index === -1 || columns[index]?.sensitiveNonResponse) {
      out[row.value] = null;
      continue;
    }
    out[row.value] = defaultOptionScore(columns[index]!, index);
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Sensitive questions                                                */
/* ------------------------------------------------------------------ */

export function isSensitiveQuestion(question: Question): boolean {
  return (question.options?.choices ?? []).some((o) => o.sensitiveNonResponse === true);
}

/**
 * True when the respondent explicitly declined to answer a sensitive item.
 * Callers must treat this as missing-never-as-substantive.
 */
export function isSensitiveRefusal(question: Question, answer: AnswerValue): boolean {
  const choices = question.options?.choices;
  if (!choices) return false;
  const values = Array.isArray(answer) ? answer.map(String) : [String(answer ?? '')];
  return values.some((v) => findOption(choices, v)?.sensitiveNonResponse === true);
}
