/**
 * Typed API client.
 *
 * The server is served from a different origin during development (API on
 * :4000, console on :5173), so the base URL is resolved at runtime and can be
 * overridden — via `?api=` for a quick check, or by setting
 * `localStorage['ferp.apiBase']` for a persistent custom deployment.
 *
 * When the console is served from a real host the default becomes that same
 * origin, so the host can proxy `/api/*` to the platform server.
 */

import type {
  AnovaResult,
  CorrelationMatrixResult,
  DescriptiveReport,
  DescriptiveStats,
  EfaResult,
  FactorLoading,
  FrequencyRow,
  Hypothesis,
  HypothesisReport,
  HypothesisTestResult,
  KmoResult,
  KruskalWallisResult,
  MannWhitneyResult,
  OlsCoefficient,
  OlsResult,
  OrdinalCoefficient,
  OrdinalLogitResult,
  OrdinalThreshold,
  ProjectSettings,
  ProjectStatus,
  Question,
  QuestionLogic,
  QuestionOptions,
  QuestionType,
  Questionnaire,
  QuotaConfig,
  RegressionModelChoice,
  ReliabilityItemStats,
  ReliabilityReport,
  ReliabilityResult,
  ResearchProject,
  Researcher,
  Respondent,
  ResponseRecord,
  ReviewStatus,
  ScoringRule,
  ValidityReport,
  VariableDefinition,
} from '@ferp/shared';

/* ------------------------------------------------------------------ */
/* Configuration                                                      */
/* ------------------------------------------------------------------ */

const LOCAL_API_BASE = 'http://127.0.0.1:4000';

/** Hosts that mean "this page is being served from the developer machine". */
const LOCAL_HOSTS = new Set(['localhost', '127.0.0.1', '::1', '0.0.0.0']);

/**
 * Default base URL when nothing is overridden.
 *
 * On a developer machine the console and the API live on different ports, so the
 * API keeps its own origin. Once the console is hosted, the API is reachable at
 * the same origin under `/api` — the host proxies those calls to the platform
 * server — which also avoids mixed-content and CORS problems on HTTPS.
 */
function defaultApiBase(): string {
  if (typeof window === 'undefined') return LOCAL_API_BASE;
  return LOCAL_HOSTS.has(window.location.hostname) ? LOCAL_API_BASE : window.location.origin;
}

/** True when the console itself is being served from a developer/loopback host. */
function pageIsLoopback(): boolean {
  if (typeof window === 'undefined') return true;
  return LOCAL_HOSTS.has(window.location.hostname);
}

/**
 * True when a configured base points at the *visitor's own* machine.
 *
 * A loopback API base only makes sense when the console is also opened from a
 * loopback host. On a hosted page every visitor's 127.0.0.1 is their own
 * computer, so such a value can never serve anyone but the developer.
 */
function isLoopbackBase(value: string): boolean {
  try {
    return LOCAL_HOSTS.has(new URL(value).hostname.toLowerCase());
  } catch {
    return false;
  }
}

export function resolveApiBase(): string {
  if (typeof window === 'undefined') return LOCAL_API_BASE;

  const fromQuery = new URLSearchParams(window.location.search).get('api');
  if (fromQuery) {
    const value = fromQuery.replace(/\/$/, '');
    // An explicit ?api= is always honoured, but a loopback target on a hosted
    // page must not be persisted: it would silently outlive the session and
    // break every later visit.
    if (pageIsLoopback() || !isLoopbackBase(value)) {
      window.localStorage.setItem('ferp.apiBase', value);
    } else {
      window.localStorage.removeItem('ferp.apiBase');
      console.warn(
        '[ferp] ?api= points at a loopback address while the console is served from a public ' +
          'host; using it for this page only and not persisting it.',
      );
    }
    return value;
  }

  const stored = window.localStorage.getItem('ferp.apiBase');
  if (stored) {
    const value = stored.replace(/\/$/, '');
    if (pageIsLoopback() || !isLoopbackBase(value)) return value;
    // Stale override left behind by an earlier ?api= visit: drop it and fall
    // back to the same-origin API so the console keeps working.
    window.localStorage.removeItem('ferp.apiBase');
    console.warn('[ferp] Discarded a stale loopback API override (localStorage.ferp.apiBase).');
  }

  return defaultApiBase();
}

/**
 * Active API base.
 *
 * Deliberately mutable: a stale override can be detected and repaired at
 * runtime (see `sendWithFallback`) instead of leaving the console broken until
 * someone clears browser storage by hand.
 */
let activeBase = resolveApiBase();

export function apiBaseUrl(): string {
  return activeBase;
}

/* ------------------------------------------------------------------ */
/* Token storage                                                      */
/* ------------------------------------------------------------------ */

const TOKEN_KEY = 'ferp.token';

export function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null): void {
  if (typeof window === 'undefined') return;
  if (token) window.localStorage.setItem(TOKEN_KEY, token);
  else window.localStorage.removeItem(TOKEN_KEY);
}

/* ------------------------------------------------------------------ */
/* Errors                                                             */
/* ------------------------------------------------------------------ */

export interface ApiErrorDetail {
  field?: string;
  message: string;
}

export class ApiClientError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details: unknown;

  constructor(status: number, code: string, message: string, details: unknown) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.code = code;
    this.details = details;
  }

  /** Field-level messages, when the server returned a validation error list. */
  get fieldErrors(): ApiErrorDetail[] {
    if (!Array.isArray(this.details)) return [];
    return this.details
      .filter((item): item is ApiErrorDetail => Boolean(item) && typeof item === 'object' && 'message' in item)
      .map((item) => ({ field: item.field, message: String(item.message) }));
  }
}

/* ------------------------------------------------------------------ */
/* Request core                                                       */
/* ------------------------------------------------------------------ */

interface RequestOptions {
  body?: unknown;
  query?: Record<string, string | number | boolean | undefined | null>;
  /** Set false for endpoints that must not send the stored token. */
  authenticated?: boolean;
  responseType?: 'json' | 'text';
}

function buildUrl(
  path: string,
  query?: RequestOptions['query'],
  base: string = activeBase,
): string {
  const url = new URL(`${base}${path}`);
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value === undefined || value === null || value === '') continue;
      url.searchParams.set(key, String(value));
    }
  }
  return url.toString();
}

/**
 * Same-origin fallback for a broken API base.
 *
 * A stale override — a loopback address on a hosted page, a leftover Netlify
 * `:splat` placeholder, a tunnel hostname that no longer resolves — makes every
 * request fail while the same-origin API is perfectly healthy. On the first
 * network-level failure the request is retried once against
 * `window.location.origin`; if that succeeds the bad override is dropped, so the
 * repair survives a reload.
 */
function sameOriginBase(): string | null {
  if (typeof window === 'undefined') return null;
  return window.location.origin;
}

function forgetApiBaseOverride(): void {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem('ferp.apiBase');
}

async function sendWithFallback(
  path: string,
  query: RequestOptions['query'],
  init: RequestInit,
): Promise<Response> {
  try {
    return await fetch(buildUrl(path, query), init);
  } catch (error) {
    const failedBase = activeBase;
    const origin = sameOriginBase();
    // `fetch` rejects with a TypeError when the request never reached a server;
    // an HTTP error status does not arrive through this path.
    if (!(error instanceof TypeError) || !origin || origin === failedBase) throw error;

    const response = await fetch(buildUrl(path, query, origin), init);
    activeBase = origin;
    forgetApiBaseOverride();
    console.warn(
      `[ferp] API base ${failedBase} is unreachable; fell back to the same-origin API ` +
        `${origin} and cleared the stored override.`,
    );
    return response;
  }
}

/**
 * `fetch` decodes the body as UTF-8 and strips a leading BOM, which would make
 * the exported codebook differ from the bytes the server sent (and break the
 * Excel-compatibility BOM). Text responses are therefore read as raw bytes.
 */
async function readTextPreservingBom(response: Response): Promise<string> {
  const bytes = new Uint8Array(await response.arrayBuffer());
  return new TextDecoder('utf-8', { ignoreBOM: true }).decode(bytes);
}

/** Turn a failed response body into the typed error the console renders. */
function apiErrorFromPayload(status: number, payload: unknown): ApiClientError {
  const envelope = payload as { error?: { code?: string; message?: string; details?: unknown } } | null;

  // A 401 means the stored token is no longer valid (expired, revoked by
  // logout, or signed by a rotated secret). Clear it before throwing so the app
  // falls back to the login screen instead of retrying with a dead token.
  if (status === 401) setToken(null);

  return new ApiClientError(
    status,
    envelope?.error?.code ?? 'HTTP_ERROR',
    envelope?.error?.message ?? `请求失败（${status}）。`,
    envelope?.error?.details ?? null,
  );
}

/** Same rule for the download path, which reads bytes rather than JSON. */
async function apiErrorFrom(response: Response): Promise<ApiClientError> {
  let payload: unknown = null;
  try {
    payload = JSON.parse(await response.text());
  } catch {
    payload = null;
  }
  return apiErrorFromPayload(response.status, payload);
}

async function request<T>(
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE',
  path: string,
  options: RequestOptions = {},
): Promise<T> {
  const headers: Record<string, string> = {};
  if (options.body !== undefined) headers['content-type'] = 'application/json';

  if (options.authenticated !== false) {
    const token = getToken();
    if (token) headers['authorization'] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await sendWithFallback(path, options.query, {
      method,
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    });
  } catch (error) {
    throw new ApiClientError(
      0,
      'NETWORK_ERROR',
      `无法连接研究平台服务（${activeBase}）。请确认后端服务已启动。`,
      error instanceof Error ? error.message : null,
    );
  }

  if (options.responseType === 'text') {
    if (!response.ok) {
      throw new ApiClientError(response.status, 'HTTP_ERROR', `请求失败（${response.status}）。`, null);
    }
    return (await readTextPreservingBom(response)) as T;
  }

  const raw = await response.text();
  let payload: unknown = null;
  if (raw.length > 0) {
    try {
      payload = JSON.parse(raw);
    } catch {
      payload = null;
    }
  }

  if (!response.ok) {
    throw apiErrorFromPayload(response.status, payload);
  }

  return ((payload as { data?: T } | null)?.data ?? null) as T;
}

const get = <T>(path: string, options?: RequestOptions) => request<T>('GET', path, options);
const post = <T>(path: string, options?: RequestOptions) => request<T>('POST', path, options);
const put = <T>(path: string, options?: RequestOptions) => request<T>('PUT', path, options);
const patch = <T>(path: string, options?: RequestOptions) => request<T>('PATCH', path, options);
const del = <T>(path: string, options?: RequestOptions) => request<T>('DELETE', path, options);

/* ------------------------------------------------------------------ */
/* Response shapes                                                    */
/* ------------------------------------------------------------------ */

export interface AuthPayload {
  researcher: Researcher;
  token: string;
  token_type: string;
  expires_in: number;
}

export interface ProjectListResult {
  items: ResearchProject[];
  total: number;
  limit: number;
  offset: number;
}

export interface ProjectDetail {
  project: ResearchProject;
  questionnaires: Questionnaire[];
}

export interface CreateProjectResult {
  project: ResearchProject;
  questionnaire_id: string | null;
  seeded_questions: number;
}

export interface TemplateSummary {
  key: string;
  version: string;
  title: string;
  description: string;
  question_count: number;
  section_count: number;
  default_project: {
    title: string;
    description: string;
    target_population: string;
    target_sample_size: number;
    research_question_count: number;
    hypothesis_count: number;
  };
}

export interface InstrumentPayload {
  questionnaire: Questionnaire;
  questions: Question[];
  response_count: number;
}

export interface BuilderState {
  questionnaire: Questionnaire;
  project: { id: string; title: string };
  questions: Question[];
  suggested_next_code: string;
  editable: boolean;
  lock_reason: string | null;
}

export interface LogicRuleView {
  question_code: string;
  question_text: string;
  rule_id: string;
  description: string;
  action: { type: string; target?: string };
  conditions: { questionCode: string; operator: string; value?: unknown }[];
}

export interface LogicIssue {
  questionCode: string;
  ruleId: string | null;
  severity: 'error' | 'warning';
  message: string;
}

export interface LogicView {
  rules: LogicRuleView[];
  issues: LogicIssue[];
  option_labels: Record<string, string>;
}

export interface PreviewResult {
  questionnaire_id: string;
  version: string;
  total_questions: number;
  answered_path: string[];
  answered_count: number;
  visible: {
    question_code: string;
    question_text: string;
    question_type: QuestionType;
    section: string | null;
    required: boolean;
  }[];
  visible_count: number;
  logic_issues: LogicIssue[];
}

export interface PublishResult {
  questionnaire: Questionnaire;
  share_token: string;
  share_url: string;
  warnings: string[];
  logic_issues: LogicIssue[];
}

export interface DictionaryResult {
  questionnaire_id: string;
  version: string;
  dictionary: VariableDefinition[];
}

export interface DistributionItem {
  value: string;
  label: string;
  count: number;
  percent: number;
}

export interface Distribution {
  variable_name: string;
  question_code: string;
  label: string;
  question_type: string;
  kind: 'categorical' | 'scale' | 'multi' | 'matrix_row_means';
  base_n: number;
  n: number;
  counts: DistributionItem[];
  mean: number | null;
  sd: number | null;
  median: number | null;
  missing: number;
  sensitive_nonresponse: number;
}

export interface QuotaProgress {
  dimension: string;
  category: string;
  target_n: number;
  current_n: number;
  percent: number;
  met: boolean;
}

export interface DashboardFinding {
  level: 'FACT';
  text: string;
  source: { question_code: string; n: number };
}

export interface DashboardOverview {
  generated_at: string;
  scope: 'all_projects' | 'single_project';
  project: { id: string; title: string; status: string; target_sample_size: number | null } | null;
  projects: { total: number; collecting: number; draft: number; analyzing: number; completed: number };
  collection_started: boolean;
  sample: {
    total: number;
    completed: number;
    in_progress: number;
    abandoned: number;
    valid: number;
    invalid: number;
    unscored: number;
    valid_rate: number | null;
    completion_rate: number | null;
    average_duration_seconds: number | null;
    today_new: number;
  };
  questionnaire: {
    id: string;
    title: string;
    version: string;
    status: string;
    question_count: number;
    share_token: string | null;
  } | null;
  distributions: Distribution[];
  quota_progress: QuotaProgress[];
  quota_alerts: string[];
  findings: DashboardFinding[];
}

export interface DeleteQuestionResult {
  deleted: boolean;
  dangling_logic: { question_code: string; rule_id: string; message: string }[];
}

/* ------------------------------------------------------------------ */
/* PHASE 3 — collection and sample management                         */
/* ------------------------------------------------------------------ */

export interface RespondentPage {
  items: Respondent[];
  total: number;
  limit: number;
  offset: number;
  summary: {
    total: number;
    completed: number;
    in_progress: number;
    abandoned: number;
    by_review_status: Record<ReviewStatus, number>;
  };
}

export interface SourceBreakdownItem {
  source: string;
  total: number;
  completed: number;
  in_progress: number;
  abandoned: number;
  completion_rate: number | null;
  excluded: number;
}

export interface SourceBreakdown {
  items: SourceBreakdownItem[];
  total: number;
}

export interface RespondentDetail {
  respondent: Respondent;
  questionnaire: { id: string; title: string; version: string };
  responses: ResponseRecord[];
  answered_count: number;
  hidden_question_codes: string[];
}

/** Payload the public survey runs on (no authentication involved). */
export interface PublicInstrument {
  questionnaire: {
    id: string;
    title: string;
    description: string | null;
    version: string;
    status: string;
  };
  project: { title: string; target_sample_size: number | null };
  consent_text: string;
  consent_is_platform_default: boolean;
  ethics_points: string[];
  anonymous: boolean;
  allow_partial: boolean;
  min_duration_seconds: number | null;
  accepting_responses: boolean;
  question_count: number;
  questions: Question[];
}

export interface PublicSessionState {
  respondent: Respondent;
  answers: Record<string, unknown>;
  hidden_question_codes: string[];
  missing_required: string[];
}

/* ------------------------------------------------------------------ */
/* PHASE 4 — quality and quota                                        */
/* ------------------------------------------------------------------ */

export type QualityRuleCode =
  | 'SUSPICIOUS_SPEED'
  | 'LONG_STRING'
  | 'HIGH_MISSING'
  | 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'
  | 'DUPLICATE_SUBMISSION'
  | 'MATRIX_STRAIGHT_LINE'
  | 'ALTERNATING_PATTERN';

export type QualitySeverity = 'info' | 'warning' | 'critical';

export interface QualityRuleDefinition {
  code: QualityRuleCode;
  label: string;
  description: string;
  interpretation: string;
  default_severity: QualitySeverity;
  score_impact: number;
}

export interface QualityFlagRecord {
  rule_code: QualityRuleCode;
  label: string;
  severity: QualitySeverity;
  score_impact: number;
  detail: string;
  evidence: Record<string, unknown>;
  created_at: string;
}

export interface RespondentQualityView {
  respondent_id: string;
  anonymous_id: string;
  score: number | null;
  severity: QualitySeverity | 'clean' | 'unscored';
  computed_at: string | null;
  engine_version: string | null;
  review_status: string;
  review_note: string | null;
  flags: QualityFlagRecord[];
}

export interface ProjectQualityReport {
  project_id: string;
  engine_version: string;
  thresholds_note: string;
  scored_respondents: number;
  unscored_respondents: number;
  mean_score: number | null;
  median_score: number | null;
  bands: { label: string; min: number; max: number; count: number }[];
  rule_frequency: { rule_code: QualityRuleCode; label: string; count: number; severity: QualitySeverity }[];
  flagged_samples: {
    respondent_id: string;
    anonymous_id: string;
    score: number;
    severity: string;
    review_status: string;
    rule_codes: QualityRuleCode[];
  }[];
  excluded_samples: { anonymous_id: string; note: string | null; reviewed_at: string | null }[];
  inactive_rules: { rule_code: string; reason: string }[];
}

export interface QualityRecomputeResult {
  project_id: string;
  engine_version: string;
  respondents_scored: number;
  flags_written: number;
  clean_respondents: number;
  flagged_respondents: number;
  rule_counts: Record<string, number>;
  computed_at: string;
}

export interface QuotaProgressItem {
  dimension: string;
  category: string;
  target_n: number;
  current_n: number;
  percent: number;
  remaining: number;
  met: boolean;
  exceeded: boolean;
}

export interface QuotaRecommendation {
  kind: 'quota_shortfall' | 'structure' | 'channel' | 'saturation' | 'none';
  severity: 'info' | 'warning' | 'critical';
  text: string;
  evidence: string[];
}

export interface QuotaStatus {
  project_id: string;
  enabled: boolean;
  preserve_structure: boolean;
  dimension_question_code: string | null;
  dimension_variable: string | null;
  progress: {
    items: QuotaProgressItem[];
    total_target: number;
    total_current: number;
    percent: number | null;
    met_categories: number;
    unmet_categories: number;
    largest_shortfalls: QuotaProgressItem[];
  };
  balance: {
    imbalanced: boolean;
    observed_share: Record<string, number>;
    target_share: Record<string, number>;
    most_over: { category: string; deviation_pp: number } | null;
    most_under: { category: string; deviation_pp: number } | null;
    threshold_pp: number;
  };
  recommendations: QuotaRecommendation[];
  counting_note: string;
  excluded_samples: number;
  counted_samples: number;
}

export interface QuotaDimension {
  variable: string;
  question_code: string;
  label: string;
  categories: string[];
}

/* ------------------------------------------------------------------ */
/* PHASE 6 — statistical analysis                                     */
/* ------------------------------------------------------------------ */

/**
 * Analysis responses.
 *
 * The statistical payloads themselves are the engine's own types from
 * `@ferp/shared`, so the console cannot drift from what the engine computed.
 * Only the response envelope (and the bundle, which the server assembles from
 * those pieces) is declared here.
 */

/** The analysis base actually used, stated in every report. */
export interface AnalysisSampleSummary {
  respondents_total: number;
  completed: number;
  in_progress: number;
  abandoned: number;
  /** Completed but excluded by the researcher's review. */
  excluded: number;
  analysable: number;
  rows_loaded: number;
  sources: { source: string; total: number }[];
}

/** Every analysis that cannot be computed says so instead of returning empty numbers. */
export interface AnalysisUnavailable {
  engine_version: string;
  available: false;
  reason: string;
}

export interface AnalysisDatasetInventory {
  engine_version: string;
  sample: AnalysisSampleSummary;
  n_respondents: number;
  variable_count: number;
  derived_variable_count: number;
  empty_variables: string[];
  variables: {
    name: string;
    label: string;
    dimension: string;
    question_code: string;
    data_type: string;
    n: number;
    missing: number;
    is_derived: boolean;
    sources: string[];
  }[];
  available: {
    correlation_variables: string[];
    regression_dependent: string | null;
    regression_predictors: string[];
    comparison_factor: string | null;
    comparison_dependents: string[];
  };
  note: string;
}

export type AnalysisDescriptiveResponse = {
  engine_version: string;
  sample: AnalysisSampleSummary;
} & DescriptiveReport;

export type AnalysisReliabilityResponse = { engine_version: string } & ReliabilityReport;
export type AnalysisValidityResponse = { engine_version: string } & ValidityReport;

export type AnalysisCorrelationResponse =
  | ({ engine_version: string; available: true } & CorrelationMatrixResult)
  | AnalysisUnavailable;

export interface AnalysisComparison {
  dependent: string;
  dependent_label: string;
  factor: string;
  factor_label: string;
  groups: number;
  anova: AnovaResult | null;
  mann_whitney: MannWhitneyResult | null;
  kruskal_wallis: KruskalWallisResult | null;
  recommended: 'parametric' | 'nonparametric';
  recommendation_reason: string;
  screening: {
    variable: string;
    group: string;
    n: number;
    skewness: number | null;
    acceptable: boolean;
    reason: string;
  }[];
}

export interface AnalysisComparisonResponse {
  engine_version: string;
  factor: string;
  comparisons: AnalysisComparison[];
  available: boolean;
  reason: string | null;
}

export interface AnalysisRegressionBlock {
  /** The engine's own verdict on which estimator the outcome calls for. */
  auto_selection: RegressionModelChoice;
  ols: OlsResult | null;
  /** Present when the outcome is ordinal — then it is the primary result. */
  ordinal: OrdinalLogitResult | null;
  recommendation: string;
}

export type AnalysisRegressionResponse =
  | ({ engine_version: string; available: true } & AnalysisRegressionBlock)
  | AnalysisUnavailable;

export type AnalysisHypothesisResponse = { engine_version: string } & HypothesisReport;

export interface AnalysisBundle {
  engine_version: string;
  generated_at: string;
  project: { id: string; title: string };
  questionnaire: { id: string; title: string; version: string; question_count: number } | null;
  sample: AnalysisSampleSummary;
  dataset_summary: {
    n_respondents: number;
    variable_count: number;
    derived_variable_count: number;
    empty_variables: string[];
    variables: { name: string; label: string; data_type: string; n: number; missing: number }[];
    composites: { name: string; label: string; sources: string[] }[];
  };
  descriptive: DescriptiveReport;
  reliability: ReliabilityReport;
  validity: ValidityReport;
  correlation: CorrelationMatrixResult | null;
  regression: AnalysisRegressionBlock | null;
  comparisons: AnalysisComparison[];
  hypotheses: HypothesisReport;
  caveats: string[];
}

export type AnalysisBundleResponse =
  | ({ available: true } & AnalysisBundle)
  | AnalysisUnavailable;

export interface StoredAnalysisRow {
  id: string;
  analysis_type: string;
  engine_version: string;
  sample_n: number | null;
  created_at: string;
  parameters: unknown;
}

/* ------------------------------------------------------------------ */
/* PHASE 7 — AI interpretation of the analysis bundle                  */
/* ------------------------------------------------------------------ */

/**
 * The four interpretation levels, in the order the API reports them.
 *
 * The order is the contract: a reader walks from what the engine measured to
 * what a model concluded, and the console keeps the four groups apart so a
 * sentence cannot be read as a stronger claim than it is.
 */
export type AiLevel = 'FACT' | 'STATISTICAL_FINDING' | 'INTERPRETATION' | 'RECOMMENDATION';

export type AiMode = 'live' | 'degraded';

/**
 * Chinese label per level.
 *
 * Mirrors `LEVEL_LABELS_ZH` in the server's `ai.service.ts`, which also prefixes
 * the same label into every statement's `labelled_text`. It is declared here as
 * well so a level group with no statements still has a heading; the statements
 * themselves are always rendered from the API's own text.
 */
export const AI_LEVEL_LABELS_ZH: Record<AiLevel, string> = {
  FACT: '事实',
  STATISTICAL_FINDING: '统计发现',
  INTERPRETATION: '解释',
  RECOMMENDATION: '建议',
};

/** The four levels in the order they must be read. */
export const AI_LEVELS: readonly AiLevel[] = [
  'FACT',
  'STATISTICAL_FINDING',
  'INTERPRETATION',
  'RECOMMENDATION',
];

/**
 * Sections the model can be asked to concentrate on.
 *
 * Mirrors `INTERPRETATION_SECTIONS` in the server's `ai.service.ts`; the server
 * rejects any other value, so the selector can only offer these.
 */
export const AI_INTERPRETATION_SECTIONS = [
  'overview',
  'descriptive',
  'reliability',
  'correlation',
  'regression',
  'comparisons',
  'hypotheses',
] as const;

export type AiInterpretationSection = (typeof AI_INTERPRETATION_SECTIONS)[number];

export const AI_SECTION_LABELS_ZH: Record<AiInterpretationSection, string> = {
  overview: '总览',
  descriptive: '描述统计',
  reliability: '信度分析',
  correlation: '相关分析',
  regression: '回归分析',
  comparisons: '组间差异',
  hypotheses: '假设检验',
};

/** One citation of an exact bundle location, as validated by the server. */
export interface AiEvidence {
  /** Bundle path, e.g. `hypotheses.results[H3].r`. */
  path: string;
  /** The value found at that path, quoted from the bundle. */
  value: string | number | boolean | null;
  /** `declared` — the model cited it; `inferred` — derived from a validated number. */
  source: 'declared' | 'inferred';
}

export interface AiStatement {
  id: string;
  level: AiLevel;
  text: string;
  /** The statement with its Chinese level label prefixed (`【统计发现】…`). */
  labelled_text: string;
  evidence: AiEvidence[];
  /** True when the model omitted the label and the level was inferred from wording. */
  label_inferred: boolean;
  hypothesis_code: string | null;
}

export type AiRejectedClaimCode =
  | 'untraceable_number'
  | 'no_evidence'
  | 'evidence_path_not_found'
  | 'evidence_value_mismatch'
  | 'empty_statement';

export interface AiRejectedClaim {
  text: string;
  code: AiRejectedClaimCode;
  reason: string;
  /** The offending number, when the rejection was caused by one. */
  quoted_number: number | null;
  /** The number exactly as the model wrote it. */
  raw_number: string | null;
  level: AiLevel | null;
}

/** The four levels, kept separate all the way to the client. */
export interface AiLayers {
  facts: AiStatement[];
  statistical_findings: AiStatement[];
  interpretations: AiStatement[];
  recommendations: AiStatement[];
}

export interface AiUsage {
  prompt_tokens: number | null;
  completion_tokens: number | null;
  total_tokens: number | null;
}

export interface AiUnavailable {
  code: string;
  message: string;
  provider_status: number | null;
}

/** Deterministic, engine-derived summary returned when no model was used. */
export interface AiEngineSummary {
  derived_by: 'statistical_engine';
  ai_generated: false;
  headline: string;
  text: string;
  statement_count: number;
  sections: { title: string; lines: string[] }[];
}

export interface InterpretationScope {
  section: string | null;
  hypothesis_code: string | null;
  focus: string | null;
}

export interface AiInterpretationResult {
  mode: AiMode;
  interaction_id: string;
  generated_at: string;
  engine_version: string;
  prompt_version: string;
  prompt_hash: string | null;
  model: string;
  base_url: string;
  scope: InterpretationScope;
  bundle_generated_at: string;
  source_of_truth: 'analysis_bundle';
  layers: AiLayers;
  statement_count: number;
  levels_used: AiLevel[];
  rejected_claims: AiRejectedClaim[];
  warnings: string[];
  caveats: string[];
  truncated: boolean;
  ai_unavailable: AiUnavailable | null;
  engine_summary: AiEngineSummary | null;
  usage: AiUsage | null;
  notice: string;
}

export interface AiStatus {
  configured: boolean;
  mode: AiMode;
  /** Chinese explanation shown before the researcher clicks. */
  reason: string;
  model: string;
  base_url: string;
  timeout_ms: number;
  has_bundle: boolean;
  bundle_generated_at: string | null;
  latest_interaction_at: string | null;
  latest_mode: AiMode | null;
}

/** One audit-trail row; failed and degraded attempts are included. */
export interface AiHistoryItem {
  id: string;
  mode: AiMode;
  model: string;
  engine_version: string;
  prompt_hash: string;
  prompt_version: string;
  prompt_tokens: number | null;
  completion_tokens: number | null;
  total_tokens: number | null;
  duration_ms: number | null;
  scope: InterpretationScope;
  statement_count: number;
  rejected_claims: AiRejectedClaim[];
  rejected_claim_count: number;
  error_code: string | null;
  error_message: string | null;
  raw_response: string | null;
  result: AiInterpretationResult | null;
  researcher_id: string | null;
  created_at: string;
}

export type AiLatestResponse =
  | { available: false; reason: string }
  | ({
      available: true;
      id: string;
      mode: AiMode;
      model: string;
      engine_version: string;
      prompt_hash: string;
      prompt_version: string;
      prompt_tokens: number | null;
      completion_tokens: number | null;
      total_tokens: number | null;
      duration_ms: number | null;
      scope: InterpretationScope;
      statement_count: number;
      rejected_claim_count: number;
      error_code: string | null;
      error_message: string | null;
      created_at: string;
      result: AiInterpretationResult | null;
    });

export interface AiInterpretRequest {
  section?: string | null;
  hypothesis_code?: string | null;
  focus?: string | null;
}

/* ------------------------------------------------------------------ */
/* PHASE 8 — research report                                           */
/* ------------------------------------------------------------------ */

/** One number a report section used, with the bundle path it came from. */
export interface ReportEvidence {
  path: string;
  value: string;
}

export interface ReportSection {
  /** 1-based position in the fixed 23-section order. */
  index: number;
  key: string;
  title: string;
  body: string;
  evidence: ReportEvidence[];
  /** False when the section could not be filled from the data. */
  available: boolean;
  /** Chinese explanation of what is missing; `null` when `available` is true. */
  unavailable_reason: string | null;
}

export interface ResearchReport {
  report_type: 'research_report';
  project_id: string;
  project_title: string;
  questionnaire_title: string | null;
  engine_version: string;
  /** Timestamp of the analysis the report was built from. */
  analyser_generated_at: string;
  generated_at: string;
  sections: ReportSection[];
  section_count: number;
  available_sections: number;
  unavailable_sections: number;
  /** Verbatim from the bundle: statements that must accompany any reading. */
  caveats: string[];
  markdown: string;
  word_count: number;
}

/* ------------------------------------------------------------------ */
/* PHASE 9 — competition (entrepreneurship) insight                    */
/* ------------------------------------------------------------------ */

export type InsightBlockKey =
  | 'target_user'
  | 'pain_points'
  | 'current_solutions'
  | 'service_gap'
  | 'product_demand'
  | 'trust'
  | 'ai_acceptance'
  | 'willingness_to_pay'
  | 'market_opportunity';

/** One traceable fact: where the value was found, and the value itself. */
export interface InsightEvidence {
  path: string;
  value: unknown;
}

/** One input a block depends on, and whether the questionnaire carries it. */
export interface InsightBlockInput {
  name: string;
  role: 'primary' | 'supporting';
  available: boolean;
  note: string | null;
}

/**
 * One of the nine blocks.
 *
 * `data` is typed `unknown` on purpose: each block has its own structured
 * payload, and the page renders them through one honest generic renderer rather
 * than nine hand-written shapes that could drift from the service.
 */
export interface InsightBlock {
  key: InsightBlockKey;
  order: number;
  title: string;
  available: boolean;
  /** Chinese explanation of what is missing; null when the block is available. */
  reason: string | null;
  narrative: string;
  /** Null when unavailable, so nothing can be mistaken for a number. */
  data: unknown;
  inputs: InsightBlockInput[];
  evidence: InsightEvidence[];
}

export interface InsightSampleSummary {
  respondents_total: number;
  completed: number;
  in_progress: number;
  abandoned: number;
  excluded: number;
  analysable: number;
  rows_loaded: number;
  sources: { source: string; total: number }[];
}

export interface InsightReport {
  engine_version: string;
  generated_at: string;
  source: {
    analysis_engine_version: string;
    analysis_generated_at: string;
    project_id: string;
    project_title: string;
    questionnaire: { id: string; title: string; version: string; question_count: number } | null;
    bundle_engine_matches: boolean;
  };
  sample: InsightSampleSummary;
  staleness: {
    bundle_sample_n: number;
    current_sample_n: number;
    stale: boolean;
    note: string;
  };
  blocks: InsightBlock[];
  caveats: string[];
  notes: string[];
}

export interface CompetitionReportPayload extends InsightReport {
  report_id: string;
  run_seq: number;
  created_at: string;
  blocks_total?: number;
  blocks_available?: number;
}

export type CompetitionReportResponse =
  | { available: false; reason: string }
  | ({ available: true } & CompetitionReportPayload);

export interface CompetitionHistoryItem {
  id: string;
  run_seq: number;
  engine_version: string;
  analysis_engine_version: string | null;
  analysis_generated_at: string | null;
  sample_n: number | null;
  blocks_total: number;
  blocks_available: number;
  questionnaire_id: string | null;
  created_by: string | null;
  created_at: string;
}

export interface CompetitionHistoryResponse {
  blocks: Record<string, string>;
  items: CompetitionHistoryItem[];
}

/* ------------------------------------------------------------------ */
/* File downloads                                                     */
/* ------------------------------------------------------------------ */

export interface DownloadedFile {
  /** File name taken from the server's `content-disposition`, when it sent one. */
  filename: string;
  bytes: number;
  /** False when the environment cannot save files (no Blob URL support). */
  started: boolean;
  note: string | null;
}

/**
 * Read the file name out of `content-disposition`.
 *
 * RFC 5987 `filename*=UTF-8''…` wins over the ASCII `filename="…"` fallback,
 * because the exports are named after Chinese project titles and only the
 * encoded form survives that round trip.
 */
export function filenameFromDisposition(header: string | null): string | null {
  if (!header) return null;
  const extended = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(header);
  if (extended?.[1]) {
    try {
      return decodeURIComponent(extended[1].trim());
    } catch {
      // A malformed percent-escape falls through to the ASCII form below.
    }
  }
  const plain = /filename\s*=\s*"([^"]*)"/i.exec(header) ?? /filename\s*=\s*([^;]+)/i.exec(header);
  return plain?.[1]?.trim() ?? null;
}

/**
 * Fetch an authenticated file and hand it to the browser as a download.
 *
 * The export and report endpoints require a bearer token, so a plain
 * `<a href="…/export/dataset.csv">` cannot be used: the link would be fetched
 * without the `authorization` header and answered with 401. The bytes are
 * therefore fetched through the same header logic as every other call, wrapped
 * in a Blob, and offered through a download link carrying the server's own
 * file name.
 */
export async function downloadFile(
  path: string,
  options: { query?: Record<string, string | number | boolean | undefined | null> } = {},
): Promise<DownloadedFile> {
  const headers: Record<string, string> = {};
  const token = getToken();
  if (token) headers['authorization'] = `Bearer ${token}`;

  let response: Response;
  try {
    response = await sendWithFallback(path, options.query, { method: 'GET', headers });
  } catch (error) {
    throw new ApiClientError(
      0,
      'NETWORK_ERROR',
      `无法连接研究平台服务（${activeBase}）。请确认后端服务已启动。`,
      error instanceof Error ? error.message : null,
    );
  }

  if (!response.ok) throw await apiErrorFrom(response);

  const filename = filenameFromDisposition(response.headers.get('content-disposition'));
  const blob = await response.blob();
  const resolved = filename ?? path.split('/').pop() ?? 'download';

  // A Blob URL is what makes the browser save the bytes rather than navigate to
  // them; without it (a non-browser test host) the download cannot be started.
  if (typeof document === 'undefined' || typeof URL.createObjectURL !== 'function') {
    return {
      filename: resolved,
      bytes: blob.size,
      started: false,
      note: '当前环境不支持自动保存文件（缺少 Blob 下载支持），文件内容已从服务端取回。',
    };
  }

  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = resolved;
  anchor.rel = 'noopener';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  // Revoking synchronously can cancel the save in some browsers; one turn later
  // the download has already been handed to the browser.
  if (typeof URL.revokeObjectURL === 'function') {
    setTimeout(() => URL.revokeObjectURL(objectUrl), 0);
  }

  return { filename: resolved, bytes: blob.size, started: true, note: null };
}

/* ------------------------------------------------------------------ */
/* Endpoints                                                          */
/* ------------------------------------------------------------------ */

export const api = {
  health: () => get<{ status: string; env: string; database: string }>('/api/health', { authenticated: false }),

  auth: {
    register: (body: { name: string; email: string; password: string; affiliation?: string }) =>
      post<AuthPayload>('/api/auth/register', { body, authenticated: false }),
    login: (body: { email: string; password: string }) =>
      post<AuthPayload>('/api/auth/login', { body, authenticated: false }),
    me: () => get<Researcher>('/api/auth/me'),
    logout: () => post<{ ok: boolean; message: string }>('/api/auth/logout'),
  },

  templates: {
    list: () => get<TemplateSummary[]>('/api/templates'),
  },

  projects: {
    list: (query?: { search?: string; status?: ProjectStatus; limit?: number; offset?: number }) =>
      get<ProjectListResult>('/api/projects', { query }),
    create: (body: Record<string, unknown>) => post<CreateProjectResult>('/api/projects', { body }),
    createFromTemplate: () => post<CreateProjectResult>('/api/projects/from-template'),
    get: (projectId: string) => get<ProjectDetail>(`/api/projects/${projectId}`),
    update: (projectId: string, body: Record<string, unknown>) =>
      patch<{ project: ResearchProject }>(`/api/projects/${projectId}`, { body }),
    remove: (projectId: string) =>
      del<{ deleted: boolean; questionnaires: number; respondents: number }>(`/api/projects/${projectId}`),
    questionnaires: (projectId: string) => get<Questionnaire[]>(`/api/projects/${projectId}/questionnaires`),
    createQuestionnaire: (projectId: string, body: { title?: string; template?: string }) =>
      post<Questionnaire>(`/api/projects/${projectId}/questionnaires`, { body }),
    dashboard: (projectId: string) => get<DashboardOverview>(`/api/projects/${projectId}/dashboard`),
  },

  dashboard: {
    overview: (projectId?: string) => get<DashboardOverview>('/api/dashboard', { query: { project_id: projectId } }),
  },

  questionnaires: {
    get: (id: string) => get<InstrumentPayload>(`/api/questionnaires/${id}`),
    builder: (id: string) => get<BuilderState>(`/api/questionnaires/${id}/builder`),
    update: (id: string, body: { title?: string; description?: string | null }) =>
      patch<Questionnaire>(`/api/questionnaires/${id}`, { body }),
    publish: (id: string) => post<PublishResult>(`/api/questionnaires/${id}/publish`),
    close: (id: string) => post<Questionnaire>(`/api/questionnaires/${id}/close`),
    newVersion: (id: string, kind: 'minor' | 'major' = 'minor') =>
      post<Questionnaire>(`/api/questionnaires/${id}/versions`, { body: { kind } }),
    logic: (id: string) => get<LogicView>(`/api/questionnaires/${id}/logic`),
    preview: (id: string, answers: Record<string, unknown>) =>
      post<PreviewResult>(`/api/questionnaires/${id}/preview`, { body: { answers } }),
    dictionary: (id: string) => get<DictionaryResult>(`/api/questionnaires/${id}/dictionary`),
    /** Codebook as CSV text (UTF-8 with BOM), fetched with the auth header. */
    dictionaryCsv: (id: string) =>
      get<string>(`/api/questionnaires/${id}/dictionary?format=csv`, { responseType: 'text' }),
    addQuestion: (id: string, body: Record<string, unknown>) =>
      post<Question>(`/api/questionnaires/${id}/questions`, { body }),
    reorder: (id: string, orderedIds: string[]) =>
      post<{ questions: Question[]; warnings: string[] }>(`/api/questionnaires/${id}/questions/reorder`, {
        body: { ordered_ids: orderedIds },
      }),
    /** Public QR code for this questionnaire's share link (no auth header needed). */
    qrCodeUrl: (shareToken: string, format: 'svg' | 'png' = 'svg') =>
      `${apiBaseUrl()}/api/public/survey/${shareToken}/qrcode?format=${format}`,
  },

  questions: {
    update: (questionId: string, body: Record<string, unknown>) =>
      patch<Question>(`/api/questions/${questionId}`, { body }),
    remove: (questionId: string) => del<DeleteQuestionResult>(`/api/questions/${questionId}`),
    duplicate: (questionId: string) => post<Question>(`/api/questions/${questionId}/duplicate`),
    move: (questionId: string, direction: 'up' | 'down') =>
      post<Question[]>(`/api/questions/${questionId}/move`, { body: { direction } }),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 3 — sample management (researcher, authenticated)           */
  /* ---------------------------------------------------------------- */

  samples: {
    list: (
      projectId: string,
      query?: {
        status?: string;
        source?: string;
        review_status?: string;
        search?: string;
        limit?: number;
        offset?: number;
      },
    ) => get<RespondentPage>(`/api/projects/${projectId}/respondents`, { query }),
    sources: (projectId: string) => get<SourceBreakdown>(`/api/projects/${projectId}/sources`),
    sweep: (projectId: string, olderThanHours = 24) =>
      post<{ marked: number }>(`/api/projects/${projectId}/respondents/sweep`, {
        body: { older_than_hours: olderThanHours },
      }),
    detail: (respondentId: string) => get<RespondentDetail>(`/api/respondents/${respondentId}`),
    review: (respondentId: string, body: { status: ReviewStatus; note?: string }) =>
      post<Respondent>(`/api/respondents/${respondentId}/review`, { body }),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 4 — data quality engine                                     */
  /* ---------------------------------------------------------------- */

  quality: {
    /** The rule catalogue, so the UI explains rules from one source of truth. */
    rules: (projectId: string) => get<QualityRuleDefinition[]>(`/api/projects/${projectId}/quality/rules`),
    report: (projectId: string) => get<ProjectQualityReport>(`/api/projects/${projectId}/quality`),
    /** Idempotent re-run; clears and rewrites this project's flags. */
    recompute: (projectId: string) =>
      post<QualityRecomputeResult>(`/api/projects/${projectId}/quality/recompute`),
    respondent: (respondentId: string) =>
      get<RespondentQualityView>(`/api/respondents/${respondentId}/quality`),
    recomputeRespondent: (respondentId: string) =>
      post<{ view: RespondentQualityView }>(`/api/respondents/${respondentId}/quality/recompute`),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 4 — quota management                                        */
  /* ---------------------------------------------------------------- */

  quota: {
    status: (projectId: string) => get<QuotaStatus>(`/api/projects/${projectId}/quota`),
    dimensions: (projectId: string) =>
      get<QuotaDimension[]>(`/api/projects/${projectId}/quota/dimensions`),
    update: (projectId: string, config: QuotaConfig | null) =>
      put<QuotaStatus>(`/api/projects/${projectId}/quota`, { body: { quota_config: config } }),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 6 — statistical analysis console                            */
  /* ---------------------------------------------------------------- */

  analysis: {
    /** Sample inventory and which default variables the engine can use. */
    dataset: (projectId: string) =>
      get<AnalysisDatasetInventory>(`/api/projects/${projectId}/analysis/dataset`),
    descriptive: (projectId: string) =>
      get<AnalysisDescriptiveResponse>(`/api/projects/${projectId}/analysis/descriptive`),
    reliability: (projectId: string) =>
      get<AnalysisReliabilityResponse>(`/api/projects/${projectId}/analysis/reliability`),
    validity: (projectId: string) =>
      get<AnalysisValidityResponse>(`/api/projects/${projectId}/analysis/validity`),
    correlation: (projectId: string, variables?: string[]) =>
      get<AnalysisCorrelationResponse>(`/api/projects/${projectId}/analysis/correlation`, {
        query: { variables: variables && variables.length > 0 ? variables.join(',') : undefined },
      }),
    regression: (projectId: string, query?: { dependent?: string; predictors?: string[] }) =>
      get<AnalysisRegressionResponse>(`/api/projects/${projectId}/analysis/regression`, {
        query: {
          dependent: query?.dependent,
          predictors: query?.predictors ? query.predictors.join(',') : undefined,
        },
      }),
    comparisons: (projectId: string, query?: { factor?: string; dependents?: string[] }) =>
      get<AnalysisComparisonResponse>(`/api/projects/${projectId}/analysis/comparisons`, {
        query: {
          factor: query?.factor,
          dependents: query?.dependents ? query.dependents.join(',') : undefined,
        },
      }),
    hypotheses: (projectId: string) =>
      get<AnalysisHypothesisResponse>(`/api/projects/${projectId}/analysis/hypotheses`),
    /** Runs every analysis and persists the bundle the later phases consume. */
    run: (projectId: string) => post<AnalysisBundle>(`/api/projects/${projectId}/analysis/run`, { body: {} }),
    bundle: (projectId: string) =>
      get<AnalysisBundleResponse>(`/api/projects/${projectId}/analysis/bundle`),
    history: (projectId: string, type?: string) =>
      get<StoredAnalysisRow[]>(`/api/projects/${projectId}/analysis/history`, { query: { type } }),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 7 — AI interpretation                                       */
  /* ---------------------------------------------------------------- */

  ai: {
    /** Whether a model is configured, and why not when it is not. */
    status: (projectId: string) => get<AiStatus>(`/api/projects/${projectId}/ai/status`),
    /**
     * Interpret the latest analysis bundle.
     *
     * The body can narrow the *focus*; it cannot supply numbers. A statement the
     * model cannot trace back to the bundle is dropped and reported instead.
     */
    interpret: (projectId: string, body: AiInterpretRequest = {}) =>
      post<AiInterpretationResult>(`/api/projects/${projectId}/ai/interpret`, { body }),
    latest: (projectId: string) => get<AiLatestResponse>(`/api/projects/${projectId}/ai/latest`),
    /** Audit trail: one row per attempt, including failed and degraded ones. */
    history: (projectId: string, limit?: number) =>
      get<AiHistoryItem[]>(`/api/projects/${projectId}/ai/history`, { query: { limit } }),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 8 — research report                                         */
  /* ---------------------------------------------------------------- */

  report: {
    /** The 23 structured sections plus the rendered Markdown. */
    get: (projectId: string) => get<ResearchReport>(`/api/projects/${projectId}/report`),
    /** Markdown download; requires the auth header, so it goes through `downloadFile`. */
    download: (projectId: string) => downloadFile(`/api/projects/${projectId}/report.md`),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 8 — data export                                             */
  /* ---------------------------------------------------------------- */

  export: {
    datasetCsv: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/dataset.csv`),
    datasetJson: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/dataset.json`),
    codebookCsv: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/codebook.csv`),
    /** ZIP holding the `.sps` syntax and the BOM-free data CSV it reads. */
    spssArchive: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/spss`),
    spssSyntax: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/spss/syntax`),
    spssData: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/spss/data`),
    /** Multi-sheet workbook; requires a persisted analysis bundle. */
    resultsXlsx: (projectId: string) => downloadFile(`/api/projects/${projectId}/export/results.xlsx`),
  },

  /* ---------------------------------------------------------------- */
  /* PHASE 9 — competition (entrepreneurship) insight                  */
  /* ---------------------------------------------------------------- */

  competition: {
    /** Build the nine-block report from the latest bundle and persist it. */
    run: (projectId: string) =>
      post<{ available: true } & CompetitionReportPayload>(
        `/api/projects/${projectId}/competition/run`,
        { body: {} },
      ),
    report: (projectId: string) =>
      get<CompetitionReportResponse>(`/api/projects/${projectId}/competition/report`),
    /** Audit trail: which engine produced each run, from which analysis. */
    history: (projectId: string) =>
      get<CompetitionHistoryResponse>(`/api/projects/${projectId}/competition/history`),
  },
};

/* ------------------------------------------------------------------ */
/* Public survey client (respondent-facing, never sends a JWT)        */
/* ------------------------------------------------------------------ */

export const publicApi = {
  /** Landing metadata: title, whether responses are still accepted. */
  survey: (shareToken: string) =>
    get<{
      title: string;
      description: string | null;
      version: string;
      status: string;
      accepting_responses: boolean;
      question_count: number;
      message: string | null;
    }>(`/api/public/survey/${shareToken}`, { authenticated: false }),

  instrument: (shareToken: string) =>
    get<PublicInstrument>(`/api/public/survey/${shareToken}/instrument`, { authenticated: false }),

  startSession: (shareToken: string, source?: string | null) =>
    post<{ session_token: string; respondent: Respondent }>(
      `/api/public/survey/${shareToken}/sessions`,
      { body: { source: source ?? null }, authenticated: false },
    ),

  session: (sessionToken: string) =>
    get<PublicSessionState>(`/api/public/sessions/${sessionToken}`, { authenticated: false }),

  saveAnswer: (sessionToken: string, questionCode: string, value: unknown) =>
    patch<{
      respondent: Respondent;
      question_code: string;
      stored: unknown;
      pruned_question_codes: string[];
      answered_count: number;
    }>(`/api/public/sessions/${sessionToken}/answers`, {
      body: { question_code: questionCode, value },
      authenticated: false,
    }),

  updateProgress: (sessionToken: string, questionCode: string | null) =>
    patch<Respondent>(`/api/public/sessions/${sessionToken}/progress`, {
      body: { question_code: questionCode },
      authenticated: false,
    }),

  complete: (sessionToken: string) =>
    post<{ respondent: Respondent; completed: boolean; missing_required: string[] }>(
      `/api/public/sessions/${sessionToken}/complete`,
      { body: {}, authenticated: false },
    ),
};

export type {
  Hypothesis,
  ProjectSettings,
  ProjectStatus,
  Question,
  QuestionLogic,
  QuestionOptions,
  QuestionType,
  Questionnaire,
  QuotaConfig,
  ResearchProject,
  Researcher,
  Respondent,
  ResponseRecord,
  ReviewStatus,
  ScoringRule,
  VariableDefinition,
};

export type {
  DescriptiveReport,
  DescriptiveStats,
  EfaResult,
  FrequencyRow,
  FactorLoading,
  HypothesisReport,
  HypothesisTestResult,
  KmoResult,
  OlsCoefficient,
  OlsResult,
  OrdinalCoefficient,
  OrdinalLogitResult,
  OrdinalThreshold,
  ReliabilityItemStats,
  ReliabilityResult,
  ValidityReport,
};
