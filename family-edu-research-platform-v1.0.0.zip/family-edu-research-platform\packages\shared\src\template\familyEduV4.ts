/**
 * 「家庭教育认知、实践与社会支持需求调查 V4.0」— 58-item instrument template.
 *
 * This template is the default research instrument of the platform. It encodes
 * the twenty research content areas as thirteen sections and 15 core variables
 * (FEI, FEK, LSK, LKA, ISC, FSE, FPB, FED, FIU, PSA, STI, DSD, WTP, UI, QN).
 *
 * Design invariants:
 *  - Q12-Q16 are objective knowledge items (correct = 1, incorrect / 不清楚 = 0)
 *    and roll up into LKA while Q10 stays the subjective rating LSK, so that
 *    subjective vs objective law knowledge can be compared honestly.
 *  - Q32 is a sensitive item: "不愿回答" is an explicit non-response code and is
 *    never recoded into "从未".
 *  - Q39 -> Q41 carries the canonical skip-logic demonstration.
 *  - No question collects direct identifiers (name, phone, ID, address, school).
 */

import type {
  ProjectSettings,
  QuestionLogic,
  QuestionOption,
  QuestionOptions,
  QuestionType,
  QuotaConfig,
  ResearchProject,
  ScoringRule,
} from '../types.js';

/* ------------------------------------------------------------------ */
/* Seed types                                                         */
/* ------------------------------------------------------------------ */

/** A question definition without database-owned fields. */
export interface QuestionSeed {
  question_code: string;
  question_text: string;
  question_type: QuestionType;
  options: QuestionOptions;
  required: boolean;
  dimension: string;
  variable_name: string | null;
  section: string;
  help_text: string | null;
  logic: QuestionLogic | null;
  scoring_rule: ScoringRule | null;
}

export interface SectionSeed {
  index: number;
  title: string;
  first_code: string;
  last_code: string;
}

export interface TemplateSeed {
  key: string;
  version: string;
  title: string;
  description: string;
  sections: SectionSeed[];
  questions: QuestionSeed[];
  project: Omit<ResearchProject, 'id' | 'researcher_id' | 'created_at' | 'updated_at' | 'status'>;
}

/* ------------------------------------------------------------------ */
/* Choice scale builders                                              */
/* ------------------------------------------------------------------ */

function choicesFromLabels(labels: string[]): QuestionOption[] {
  return labels.map((label, i) => ({ value: String(i + 1), label, score: i + 1 }));
}

/** 同意程度 1..5 */
const SCALE_AGREE = choicesFromLabels(['非常不同意', '比较不同意', '一般', '比较同意', '非常同意']);
/** 了解程度 1..5 (used for the subjective knowledge self-rating) */
const SCALE_KNOW = choicesFromLabels(['非常不了解', '比较不了解', '一般', '比较了解', '非常了解']);
/** 频率 1..5 */
const SCALE_FREQ = choicesFromLabels(['从不', '很少', '有时', '经常', '总是']);
/** 困难程度 1..5 */
const SCALE_DIFFICULTY = choicesFromLabels(['完全没有困难', '困难较小', '一般', '困难较大', '困难非常大']);
/** 信任程度 1..5 */
const SCALE_TRUST = choicesFromLabels(['非常不信任', '比较不信任', '一般', '比较信任', '非常信任']);
/** 需求程度 1..5 */
const SCALE_NEED = choicesFromLabels(['完全不需要', '比较不需要', '一般', '比较需要', '非常需要']);
/** 满意程度 1..5 */
const SCALE_SATISFY = choicesFromLabels(['非常不满意', '比较不满意', '一般', '比较满意', '非常满意']);

/**
 * Knowledge-test choice set. `correctValue` marks which option is the true
 * answer; the "不清楚" option is scored 0 and counted separately.
 */
function knowledgeChoices(correctValue: '1' | '2'): QuestionOption[] {
  return [
    { value: '1', label: '正确', score: correctValue === '1' ? 1 : 0, isCorrect: correctValue === '1' },
    { value: '2', label: '错误', score: correctValue === '2' ? 1 : 0, isCorrect: correctValue === '2' },
    { value: '3', label: '不清楚', score: 0 },
  ];
}

const KNOWLEDGE_RULE: ScoringRule = {
  type: 'knowledge',
  correctScore: 1,
  incorrectScore: 0,
  unknownScore: 0,
  unknownValue: '3',
  maxScore: 1,
};

const SCALE_5_RULE: ScoringRule = { type: 'mean', min: 1, max: 5 };
const COUNT_RULE: ScoringRule = { type: 'count', excludeExclusive: true };
const NO_RULE: ScoringRule = { type: 'none' };

/**
 * Nominal coding — unordered categories (e.g. 父亲／母亲／祖辈).
 * `null` marks an option that must be treated as missing in analysis.
 */
function nominal(codes: Record<string, number | null>): ScoringRule {
  return { type: 'categorical', codes };
}

/**
 * Ordinal coding — ordered categories (e.g. 学历、年龄段、支付区间).
 * Declared explicitly because a 1..k code sequence alone cannot prove order.
 */
function ordinal(codes: Record<string, number | null>): ScoringRule {
  return { type: 'ordinal', codes };
}

function matrix(rows: string[], columns: QuestionOption[]): QuestionOptions {
  return {
    matrix: {
      rows: rows.map((label, i) => ({ value: String(i + 1), label })),
      columns,
    },
    scaleMin: 1,
    scaleMax: columns.length,
  };
}

/* ------------------------------------------------------------------ */
/* Sections                                                           */
/* ------------------------------------------------------------------ */

export const FAMILY_EDU_V4_SECTIONS: SectionSeed[] = [
  { index: 1, title: '第一部分　基本信息', first_code: 'Q1', last_code: 'Q5' },
  { index: 2, title: '第二部分　家庭教育认知', first_code: 'Q6', last_code: 'Q9' },
  { index: 3, title: '第三部分　《家庭教育促进法》认知', first_code: 'Q10', last_code: 'Q16' },
  { index: 4, title: '第四部分　信息获取渠道', first_code: 'Q17', last_code: 'Q21' },
  { index: 5, title: '第五部分　家庭教育自我效能', first_code: 'Q22', last_code: 'Q30' },
  { index: 6, title: '第六部分　家庭教育实际行为', first_code: 'Q31', last_code: 'Q34' },
  { index: 7, title: '第七部分　家庭教育困难', first_code: 'Q35', last_code: 'Q37' },
  { index: 8, title: '第八部分　家庭教育机构', first_code: 'Q38', last_code: 'Q41' },
  { index: 9, title: '第九部分　政府家庭教育公共服务', first_code: 'Q42', last_code: 'Q47' },
  { index: 10, title: '第十部分　服务主体信任', first_code: 'Q48', last_code: 'Q48' },
  { index: 11, title: '第十一部分　数字化家庭教育服务', first_code: 'Q49', last_code: 'Q52' },
  { index: 12, title: '第十二部分　付费意愿', first_code: 'Q53', last_code: 'Q55' },
  { index: 13, title: '第十三部分　综合评价', first_code: 'Q56', last_code: 'Q58' },
];

/* ------------------------------------------------------------------ */
/* Canonical logic rules                                              */
/* ------------------------------------------------------------------ */

/** Q39 "从未使用" -> skip Q40 -> continue at Q41. */
export const Q39_SKIP_LOGIC: QuestionLogic = {
  rules: [
    {
      id: 'rule-q39-skip-q40',
      match: 'all',
      conditions: [{ questionCode: 'Q39', operator: 'eq', value: '1' }],
      action: { type: 'jump_to', target: 'Q41' },
      note: '从未使用过家庭教育机构者跳过满意度题，直接进入使用意愿题。',
    },
  ],
};

/** Q40 is shown only to respondents who have used an institution. */
export const Q40_CONDITIONAL_SHOW: QuestionLogic = {
  rules: [
    {
      id: 'rule-q40-show',
      match: 'all',
      conditions: [{ questionCode: 'Q39', operator: 'neq', value: '1' }],
      action: { type: 'show' },
      note: '仅在受访者使用过家庭教育机构时展示。',
    },
  ],
};

/** Q11 is shown only to respondents who have heard of the law. */
export const Q11_CONDITIONAL_SHOW: QuestionLogic = {
  rules: [
    {
      id: 'rule-q11-show',
      match: 'all',
      conditions: [{ questionCode: 'Q10', operator: 'neq', value: '1' }],
      action: { type: 'show' },
      note: '从未听说该法的受访者无需回答了解渠道。',
    },
  ],
};

/* ------------------------------------------------------------------ */
/* The 58 questions                                                   */
/* ------------------------------------------------------------------ */

type Draft = {
  code: string;
  text: string;
  type: QuestionType;
  section: string;
  dimension: string;
  variable: string | null;
  required?: boolean;
  options?: QuestionOptions;
  help?: string | null;
  logic?: QuestionLogic | null;
  scoring?: ScoringRule | null;
};

const DRAFTS: Draft[] = [
  /* ---------------- 第一部分 基本信息 ---------------- */
  {
    code: 'Q1',
    text: '您是孩子的：',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[0]!.title,
    dimension: '基本信息',
    variable: 'ROLE',
    options: { choices: choicesFromLabels(['父亲', '母亲', '祖辈（爷爷奶奶／外公外婆）', '其他监护人']) },
    scoring: nominal({ '1': 1, '2': 2, '3': 3, '4': 4 }),
    help: '本题仅用于分组统计，不会用于识别您的个人身份。',
  },
  {
    code: 'Q2',
    text: '您的年龄：',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[0]!.title,
    dimension: '基本信息',
    variable: 'AGE',
    options: {
      choices: choicesFromLabels([
        '25岁及以下',
        '26—30岁',
        '31—35岁',
        '36—40岁',
        '41—45岁',
        '46岁及以上',
      ]),
    },
    scoring: ordinal({ '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6 }),
  },
  {
    code: 'Q3',
    text: '您的最高学历：',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[0]!.title,
    dimension: '基本信息',
    variable: 'EDU',
    options: {
      choices: choicesFromLabels(['初中及以下', '高中或中专', '大专', '本科', '硕士及以上']),
    },
    scoring: ordinal({ '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 }),
  },
  {
    code: 'Q4',
    text: '您目前主要承担教育责任的孩子所处的教育阶段：',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[0]!.title,
    dimension: '基本信息',
    variable: 'STAGE',
    options: { choices: choicesFromLabels(['学前（0—6岁）', '小学', '初中', '高中']) },
    scoring: ordinal({ '1': 1, '2': 2, '3': 3, '4': 4 }),
    help: '如有多名子女，请选择您投入家庭教育精力最多的那一个孩子。',
  },
  {
    code: 'Q5',
    text: '您家庭的常住地区属于：',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[0]!.title,
    dimension: '基本信息',
    variable: 'AREA',
    options: { choices: choicesFromLabels(['省会城市', '地级市', '县城', '乡镇', '农村']) },
    scoring: ordinal({ '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 }),
    help: '仅需选择地区类型，不需要填写具体地址。',
  },

  /* ---------------- 第二部分 家庭教育认知 ---------------- */
  {
    code: 'Q6',
    text: '家庭教育对孩子的成长具有不可替代的重要作用。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[1]!.title,
    dimension: '家庭教育认知',
    variable: 'FEI1',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q7',
    text: '家长是家庭教育的第一责任人。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[1]!.title,
    dimension: '家庭教育认知',
    variable: 'FEI2',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q8',
    text: '家庭教育需要科学的方法，而不能仅依赖个人经验。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[1]!.title,
    dimension: '家庭教育认知',
    variable: 'FEI3',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q9',
    text: '总体而言，您认为自己目前对家庭教育知识的了解程度如何？',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[1]!.title,
    dimension: '家庭教育认知',
    variable: 'FEK',
    options: { choices: SCALE_KNOW, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
    help: '这是您的主观自评，研究将与客观知识题（Q12—Q16）的结果进行对照分析。',
  },

  /* ---------------- 第三部分 《家庭教育促进法》认知 ---------------- */
  {
    code: 'Q10',
    text: '您是否听说过《中华人民共和国家庭教育促进法》？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LSK',
    options: {
      choices: choicesFromLabels([
        '从未听说',
        '听说过但不了解内容',
        '大致了解',
        '比较了解',
        '非常了解',
      ]),
    },
    scoring: SCALE_5_RULE,
    help: 'LSK 为主观法律认知水平，可与客观知识得分 LKA 对照。',
  },
  {
    code: 'Q11',
    text: '您主要通过哪些途径了解到《中华人民共和国家庭教育促进法》？（可多选）',
    type: 'multiple',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LSKCH',
    options: {
      choices: choicesFromLabels([
        '电视、广播、报纸等传统媒体',
        '微信公众号、朋友圈等社交平台',
        '抖音、快手等短视频平台',
        '小红书、知乎等社区平台',
        '学校或幼儿园的宣传',
        '社区（村）组织的宣传活动',
        '亲友、同事交流',
        '政府官方网站或政务平台',
        '其他',
      ]),
    },
    logic: Q11_CONDITIONAL_SHOW,
    scoring: COUNT_RULE,
  },
  {
    code: 'Q12',
    text: '判断：《中华人民共和国家庭教育促进法》自2022年1月1日起施行。',
    type: 'knowledge_test',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LKA1',
    options: { choices: knowledgeChoices('1') },
    scoring: KNOWLEDGE_RULE,
    help: '客观知识题，答对计1分，答错或选择"不清楚"计0分。',
  },
  {
    code: 'Q13',
    text: '判断：《家庭教育促进法》规定家庭教育以立德树人为根本任务。',
    type: 'knowledge_test',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LKA2',
    options: { choices: knowledgeChoices('1') },
    scoring: KNOWLEDGE_RULE,
  },
  {
    code: 'Q14',
    text: '判断：未成年人的父母或者其他监护人负责实施家庭教育。',
    type: 'knowledge_test',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LKA3',
    options: { choices: knowledgeChoices('1') },
    scoring: KNOWLEDGE_RULE,
  },
  {
    code: 'Q15',
    text: '判断：家庭教育只是家庭的私事，国家和社会不需要为家庭教育提供指导、支持和服务。',
    type: 'knowledge_test',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LKA4',
    options: { choices: knowledgeChoices('2') },
    scoring: KNOWLEDGE_RULE,
  },
  {
    code: 'Q16',
    text: '判断：家庭教育指导机构可以以营利为目的开展家庭教育指导服务活动。',
    type: 'knowledge_test',
    section: FAMILY_EDU_V4_SECTIONS[2]!.title,
    dimension: '《家庭教育促进法》认知',
    variable: 'LKA5',
    options: { choices: knowledgeChoices('2') },
    scoring: KNOWLEDGE_RULE,
    help: '《家庭教育促进法》规定，家庭教育指导机构开展指导服务活动不得组织或变相组织营利性教育培训。',
  },

  /* ---------------- 第四部分 信息获取渠道 ---------------- */
  {
    code: 'Q17',
    text: '您通常通过哪些渠道获取家庭教育知识或方法？（可多选）',
    type: 'multiple',
    section: FAMILY_EDU_V4_SECTIONS[3]!.title,
    dimension: '信息获取渠道',
    variable: 'ISCB',
    options: {
      choices: choicesFromLabels([
        '微信公众号、家长群等社交平台',
        '抖音、快手等短视频平台',
        '小红书、知乎等社区平台',
        '学校或幼儿园老师',
        '亲友、同事交流',
        '家庭教育类书籍或课程',
        '线下讲座、家长学校或社区活动',
        '专业机构或咨询师',
        '其他',
      ]),
    },
    scoring: COUNT_RULE,
    help: 'ISCB 为渠道广度（选中渠道数量），用于分析信息来源的碎片化程度。',
  },
  {
    code: 'Q18',
    text: '在上述渠道中，您最信任的是哪一类信息来源？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[3]!.title,
    dimension: '信息获取渠道',
    variable: 'ISCT',
    options: {
      choices: choicesFromLabels([
        '学校或幼儿园老师',
        '专业家庭教育机构或咨询师',
        '政府或官方平台',
        '亲友、同事',
        '网络自媒体',
        '书籍、课程等出版物',
        '没有特别信任的来源',
      ]),
    },
    scoring: NO_RULE,
  },
  {
    code: 'Q19',
    text: '我觉得目前的家庭教育信息比较碎片化，难以系统掌握。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[3]!.title,
    dimension: '信息获取渠道',
    variable: 'ISC1',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q20',
    text: '我很难判断网络上的家庭教育信息是否科学可靠。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[3]!.title,
    dimension: '信息获取渠道',
    variable: 'ISC2',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q21',
    text: '您平均每周用于获取家庭教育知识的时间大约是：',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[3]!.title,
    dimension: '信息获取渠道',
    variable: 'ISCTM',
    options: {
      choices: choicesFromLabels(['几乎没有', '1小时以内', '1—3小时', '3—5小时', '5小时以上']),
    },
    scoring: SCALE_5_RULE,
  },

  /* ---------------- 第五部分 家庭教育自我效能 (FSE, 9 items) ---------------- */
  ...[
    '我有信心帮助孩子养成良好的学习习惯。',
    '我有信心与孩子进行有效的沟通。',
    '我有信心处理孩子的情绪问题。',
    '我有信心在孩子遇到困难时给予恰当的支持。',
    '我有信心为孩子营造良好的家庭学习氛围。',
    '我有信心在孩子行为不当时进行恰当的引导。',
    '我有信心平衡工作与陪伴孩子的时间。',
    '我有信心与学校老师有效配合教育孩子。',
    '我有信心为孩子选择合适的教育资源。',
  ].map((text, i): Draft => ({
    code: `Q${22 + i}`,
    text,
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[4]!.title,
    dimension: '家庭教育自我效能',
    variable: `FSE${i + 1}`,
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  })),

  /* ---------------- 第六部分 家庭教育实际行为 ---------------- */
  {
    code: 'Q31',
    text: '我会主动学习家庭教育的知识和方法。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[5]!.title,
    dimension: '家庭教育实际行为',
    variable: 'FPB1',
    options: { choices: SCALE_FREQ, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q32',
    text: '过去12个月内，您是否曾因为孩子的行为问题而采取过身体上的惩罚？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[5]!.title,
    dimension: '家庭教育实际行为',
    variable: 'FPB_PUNISH',
    required: false,
    options: {
      choices: [
        { value: '1', label: '从未', score: 0 },
        { value: '2', label: '偶尔', score: 1 },
        { value: '3', label: '有时', score: 2 },
        { value: '4', label: '经常', score: 3 },
        {
          value: '5',
          label: '不愿回答',
          sensitiveNonResponse: true,
        },
      ],
    },
    scoring: ordinal({ '1': 0, '2': 1, '3': 2, '4': 3, '5': null }),
    help:
      '本题为匿名调查，您可以拒绝回答，选择"不愿回答"不会影响您的参与。' +
      '您的回答仅用于研究统计，不会被单独识别，也不代表任何评价。',
  },
  {
    code: 'Q33',
    text: '我会和孩子一起制定并遵守家庭规则。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[5]!.title,
    dimension: '家庭教育实际行为',
    variable: 'FPB2',
    options: { choices: SCALE_FREQ, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q34',
    text: '我会定期与孩子进行深入的沟通交流。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[5]!.title,
    dimension: '家庭教育实际行为',
    variable: 'FPB3',
    options: { choices: SCALE_FREQ, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },

  /* ---------------- 第七部分 家庭教育困难 ---------------- */
  {
    code: 'Q35',
    text: '请评价您在以下方面遇到的家庭教育困难程度：',
    type: 'matrix',
    section: FAMILY_EDU_V4_SECTIONS[6]!.title,
    dimension: '家庭教育困难',
    variable: 'FED',
    options: matrix(
      [
        '缺乏科学的家庭教育方法',
        '没有足够的时间陪伴和教育孩子',
        '与孩子沟通困难',
        '孩子学习习惯差、缺乏自觉性',
        '孩子的情绪或行为问题',
        '家庭成员之间教育观念不一致',
        '难以获得专业、可靠的家庭教育指导',
      ],
      SCALE_DIFFICULTY,
    ),
    scoring: SCALE_5_RULE,
    help: 'FED 为七个方面的平均困难程度（1—5分）。',
  },
  {
    code: 'Q36',
    text: '上述困难中，您认为对您影响最大的是哪一项？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[6]!.title,
    dimension: '家庭教育困难',
    variable: 'FEDM',
    options: {
      choices: choicesFromLabels([
        '缺乏科学的家庭教育方法',
        '没有足够的时间陪伴和教育孩子',
        '与孩子沟通困难',
        '孩子学习习惯差、缺乏自觉性',
        '孩子的情绪或行为问题',
        '家庭成员之间教育观念不一致',
        '难以获得专业、可靠的家庭教育指导',
        '没有明显困难',
      ]),
    },
    scoring: NO_RULE,
  },
  {
    code: 'Q37',
    text: '总体而言，我在家庭教育中感到比较吃力。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[6]!.title,
    dimension: '家庭教育困难',
    variable: 'FEDO',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },

  /* ---------------- 第八部分 家庭教育机构 ---------------- */
  {
    code: 'Q38',
    text: '我了解社会上存在哪些家庭教育指导或服务机构。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[7]!.title,
    dimension: '家庭教育机构',
    variable: 'FIUA',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q39',
    text: '您是否使用过家庭教育机构（包括付费课程、咨询、指导服务等）？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[7]!.title,
    dimension: '家庭教育机构',
    variable: 'FIUU',
    options: { choices: choicesFromLabels(['从未使用', '使用过1—2次', '偶尔使用', '经常使用']) },
    scoring: SCALE_5_RULE,
    logic: Q39_SKIP_LOGIC,
    help: '选择"从未使用"将自动跳过下一题。',
  },
  {
    code: 'Q40',
    text: '您对所使用过的家庭教育机构服务的总体满意程度：',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[7]!.title,
    dimension: '家庭教育机构',
    variable: 'FIUS',
    options: { choices: SCALE_SATISFY, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
    logic: Q40_CONDITIONAL_SHOW,
  },
  {
    code: 'Q41',
    text: '未来我愿意使用专业的家庭教育机构提供的服务。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[7]!.title,
    dimension: '家庭教育机构',
    variable: 'FIU',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },

  /* ---------------- 第九部分 政府家庭教育公共服务 ---------------- */
  {
    code: 'Q42',
    text: '您知道政府提供以下哪些家庭教育公共服务？（可多选）',
    type: 'multiple',
    section: FAMILY_EDU_V4_SECTIONS[8]!.title,
    dimension: '政府家庭教育公共服务',
    variable: 'PSAK',
    options: {
      choices: [
        { value: '1', label: '社区（村）家长学校', score: 1 },
        { value: '2', label: '学校、幼儿园开展的家庭教育指导', score: 1 },
        { value: '3', label: '家庭教育公益讲座或宣传活动', score: 1 },
        { value: '4', label: '家庭教育指导服务热线或咨询', score: 1 },
        { value: '5', label: '政府建设的家庭教育公共服务平台或网站', score: 1 },
        { value: '6', label: '免费的家庭教育宣传资料', score: 1 },
        { value: '7', label: '以上都不知道', exclusive: true },
      ],
    },
    scoring: COUNT_RULE,
    help: 'PSAK 为公共服务知晓广度，用于构建"知晓→使用"漏斗的第一层。',
  },
  {
    code: 'Q43',
    text: '我清楚知道可以从哪些渠道获得政府的家庭教育公共服务。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[8]!.title,
    dimension: '政府家庭教育公共服务',
    variable: 'PSA1',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q44',
    text: '您认为获取政府家庭教育公共服务的方便程度如何？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[8]!.title,
    dimension: '政府家庭教育公共服务',
    variable: 'PSA2',
    options: {
      choices: choicesFromLabels([
        '非常不方便',
        '比较不方便',
        '一般',
        '比较方便',
        '非常方便',
        '不了解，无法判断',
      ]),
    },
    scoring: ordinal({ '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': null }),
    help: '选项"不了解，无法判断"在统计中作为缺失值处理，不计入均值。',
  },
  {
    code: 'Q45',
    text: '您是否使用过政府提供的家庭教育公共服务？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[8]!.title,
    dimension: '政府家庭教育公共服务',
    // Deliberately NOT `PSU1`: Q46 is a matrix whose first row expands to
    // `PSU1` as well, and two questions producing one variable name means the
    // later one silently shadows the earlier in every analysis (and duplicates
    // a column in every export). The variable is named for what it measures.
    variable: 'PSUF',
    options: { choices: choicesFromLabels(['从未使用', '使用过1—2次', '偶尔使用', '经常使用']) },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q46',
    text: '请对政府家庭教育公共服务以下方面进行评价：',
    type: 'matrix',
    section: FAMILY_EDU_V4_SECTIONS[8]!.title,
    dimension: '政府家庭教育公共服务',
    variable: 'PSU',
    options: matrix(
      ['服务内容具有实用性', '获取方式便利', '宣传告知充分', '服务人员专业', '服务的覆盖公平'],
      SCALE_SATISFY,
    ),
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q47',
    text: '未来我愿意使用政府提供的家庭教育公共服务。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[8]!.title,
    dimension: '政府家庭教育公共服务',
    variable: 'PSUI',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },

  /* ---------------- 第十部分 服务主体信任 ---------------- */
  {
    code: 'Q48',
    text: '请评价您对以下家庭教育服务主体的信任程度：',
    type: 'matrix',
    section: FAMILY_EDU_V4_SECTIONS[9]!.title,
    dimension: '服务主体信任',
    variable: 'STI',
    options: matrix(
      [
        '政府部门',
        '学校及教师',
        '专业家庭教育机构',
        '心理咨询师等专业人士',
        '亲友及其他家长',
        'AI智能助手',
      ],
      SCALE_TRUST,
    ),
    scoring: SCALE_5_RULE,
    help: '第6行为对AI智能助手的信任度（STI6），单独用于AI接受度分析。',
  },

  /* ---------------- 第十一部分 数字化家庭教育服务 ---------------- */
  {
    code: 'Q49',
    text: '请评价您对以下数字化家庭教育服务的需求程度：',
    type: 'matrix',
    section: FAMILY_EDU_V4_SECTIONS[10]!.title,
    dimension: '数字化家庭教育服务需求',
    variable: 'DSD',
    options: matrix(
      [
        '个性化育儿方案推荐',
        '在线专家咨询',
        '系统化的家庭教育课程',
        '亲子沟通技巧指导',
        '儿童行为问题应对指导',
        '家庭教育政策与公共服务导航',
      ],
      SCALE_NEED,
    ),
    scoring: SCALE_5_RULE,
    help: 'DSD 为六类数字化服务的平均需求程度（1—5分）。',
  },
  {
    code: 'Q50',
    text: '我愿意使用AI辅助的家庭教育服务。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[10]!.title,
    dimension: 'AI家庭教育服务接受度',
    variable: 'UI',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
    help: 'UI 为AI家庭教育服务使用意愿，是回归分析的主要因变量。',
  },
  {
    code: 'Q51',
    text: '对于AI家庭教育服务，您是否有以下担忧？',
    type: 'matrix',
    section: FAMILY_EDU_V4_SECTIONS[10]!.title,
    dimension: 'AI服务风险认知',
    variable: 'PRC',
    options: matrix(
      [
        '担心AI提供的信息不够专业',
        '担心个人隐私泄露',
        '担心AI给出的建议不够准确',
        '担心AI缺乏情感温度',
        '担心过度依赖AI',
      ],
      SCALE_AGREE,
    ),
    scoring: SCALE_5_RULE,
    help: 'PRC 为风险认知均值，分数越高表示担忧越强。',
  },
  {
    code: 'Q52',
    text: '我认为AI能够有效帮助我解决家庭教育中的问题。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[10]!.title,
    dimension: 'AI家庭教育服务接受度',
    variable: 'AIPV',
    options: { choices: SCALE_AGREE, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
    help: 'AIPV 为AI服务感知价值。',
  },

  /* ---------------- 第十二部分 付费意愿 ---------------- */
  {
    code: 'Q53',
    text: '您是否愿意为优质的家庭教育服务付费？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[11]!.title,
    dimension: '家庭教育服务付费意愿',
    variable: 'WTP',
    options: {
      choices: choicesFromLabels(['非常不愿意', '比较不愿意', '一般', '比较愿意', '非常愿意']),
    },
    scoring: SCALE_5_RULE,
    help: 'WTP 为有序分类变量（1—5），统计时优先采用有序Logistic回归。',
  },
  {
    code: 'Q54',
    text: '在愿意付费的前提下，您每年最多愿意为家庭教育服务支付多少？',
    type: 'single',
    section: FAMILY_EDU_V4_SECTIONS[11]!.title,
    dimension: '家庭教育服务付费意愿',
    variable: 'WTPA',
    options: {
      choices: choicesFromLabels([
        '0元',
        '1—500元',
        '501—2000元',
        '2001—5000元',
        '5001—10000元',
        '10000元以上',
      ]),
    },
    scoring: ordinal({ '1': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 5 }),
  },
  {
    code: 'Q55',
    text: '您更愿意为以下哪些家庭教育服务付费？（可多选）',
    type: 'multiple',
    section: FAMILY_EDU_V4_SECTIONS[11]!.title,
    dimension: '家庭教育服务付费意愿',
    variable: 'WTPF',
    options: {
      choices: [
        { value: '1', label: '一对一家庭教育咨询', score: 1 },
        { value: '2', label: '系统化的家长课程', score: 1 },
        { value: '3', label: '儿童行为问题干预指导', score: 1 },
        { value: '4', label: '亲子沟通训练', score: 1 },
        { value: '5', label: '学习习惯培养方案', score: 1 },
        { value: '6', label: '家庭教育政策与资源导航', score: 1 },
        { value: '7', label: '都不愿意付费', exclusive: true },
      ],
    },
    scoring: COUNT_RULE,
  },

  /* ---------------- 第十三部分 综合评价 ---------------- */
  {
    code: 'Q56',
    text: '总体而言，我对目前能够获得的社会家庭教育支持感到满意。',
    type: 'likert',
    section: FAMILY_EDU_V4_SECTIONS[12]!.title,
    dimension: '综合评价',
    variable: 'SAT',
    options: { choices: SCALE_SATISFY, scaleMin: 1, scaleMax: 5 },
    scoring: SCALE_5_RULE,
  },
  {
    code: 'Q57',
    text: '在家庭教育方面，您目前最希望获得什么样的支持？（选填）',
    type: 'textarea',
    section: FAMILY_EDU_V4_SECTIONS[12]!.title,
    dimension: '综合评价',
    variable: 'OPN',
    required: false,
    options: { placeholder: '请简要描述，例如希望获得什么样的帮助、通过什么方式获得。', maxLength: 500 },
    scoring: NO_RULE,
    help: '本题为开放性选答题，您可以跳过。请不要填写姓名、电话等个人信息。',
  },
  {
    code: 'Q58',
    text: '请按您需要的程度，对以下家庭教育支持方式进行排序（1＝最需要）。',
    type: 'ranking',
    section: FAMILY_EDU_V4_SECTIONS[12]!.title,
    dimension: '综合评价',
    variable: 'RANK',
    required: false,
    options: {
      choices: choicesFromLabels([
        '专业的家庭教育知识课程',
        '一对一的专家咨询指导',
        '学校或社区组织的家长活动',
        '便捷的线上服务平台',
        '政府提供的免费公共服务',
        '家长之间的互助交流',
      ]),
      rankCount: 6,
    },
    scoring: NO_RULE,
    help: '本题为选答题，可拖动排序。',
  },
];

/* ------------------------------------------------------------------ */
/* Derived (composite) variables                                      */
/* ------------------------------------------------------------------ */

export interface CompositeSpec {
  variable_name: string;
  label: string;
  dimension: string;
  /** Source question codes contributing items. */
  sources: string[];
  aggregation: 'mean' | 'sum' | 'count' | 'index';
  data_type: 'interval' | 'count' | 'ordinal';
  note: string;
}

/**
 * Composite variables the statistical engine materialises before analysis.
 * Derived values never overwrite raw answers — they are computed on read.
 */
export const FAMILY_EDU_V4_COMPOSITES: CompositeSpec[] = [
  {
    variable_name: 'FEI',
    label: '家庭教育认知',
    dimension: '家庭教育认知',
    sources: ['Q6', 'Q7', 'Q8'],
    aggregation: 'mean',
    data_type: 'interval',
    note: 'Q6—Q8 均值，反映对家庭教育重要性与科学性的认知水平。',
  },
  {
    variable_name: 'FEK',
    label: '家庭教育知识主观自评',
    dimension: '家庭教育认知',
    sources: ['Q9'],
    aggregation: 'mean',
    data_type: 'ordinal',
    note: '单题主观自评，需与 LKA 对照解读。',
  },
  {
    variable_name: 'LSK',
    label: '法律认知主观水平',
    dimension: '《家庭教育促进法》认知',
    sources: ['Q10'],
    aggregation: 'mean',
    data_type: 'ordinal',
    note: '主观法律认知，与客观知识 LKA 构成对照。',
  },
  {
    variable_name: 'LKA',
    label: '法律知识客观准确度',
    dimension: '《家庭教育促进法》认知',
    sources: ['Q12', 'Q13', 'Q14', 'Q15', 'Q16'],
    aggregation: 'sum',
    data_type: 'interval',
    note: 'Q12—Q16 得分之和，取值 0—5。答错或"不清楚"均计 0 分。',
  },
  {
    variable_name: 'ISC',
    label: '信息环境困扰指数',
    dimension: '信息获取渠道',
    sources: ['Q19', 'Q20'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '碎片化与判断困难两项均值，分数越高表示信息环境困扰越强。',
  },
  {
    variable_name: 'FSE',
    label: '家庭教育自我效能',
    dimension: '家庭教育自我效能',
    sources: ['Q22', 'Q23', 'Q24', 'Q25', 'Q26', 'Q27', 'Q28', 'Q29', 'Q30'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '九题均值，需报告 Cronbach\'s α。',
  },
  {
    variable_name: 'FPB',
    label: '科学家庭教育实践',
    dimension: '家庭教育实际行为',
    sources: ['Q31', 'Q33', 'Q34'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '不含 Q32（敏感题），Q32 单独作为体罚行为指标分析。',
  },
  {
    variable_name: 'FED',
    label: '家庭教育困难程度',
    dimension: '家庭教育困难',
    sources: ['Q35'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '七个方面困难程度均值。',
  },
  {
    variable_name: 'FIU',
    label: '家庭教育机构使用意愿',
    dimension: '家庭教育机构',
    sources: ['Q41'],
    aggregation: 'mean',
    data_type: 'ordinal',
    note: '单题，配合 Q38—Q40 描述机构使用现状。',
  },
  {
    variable_name: 'PSA',
    label: '政府公共服务知晓与可及性',
    dimension: '政府家庭教育公共服务',
    sources: ['Q43', 'Q44'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '知晓清晰度与获取便利性均值；Q42 的知晓广度另行报告。',
  },
  {
    variable_name: 'PSU',
    label: '政府公共服务使用与评价',
    dimension: '政府家庭教育公共服务',
    sources: ['Q45', 'Q46'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '使用频次与服务评价的综合指标。',
  },
  {
    variable_name: 'STI',
    label: '服务主体信任度',
    dimension: '服务主体信任',
    sources: ['Q48'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '六类主体信任度均值；STI6 为对AI智能助手的信任度。',
  },
  {
    variable_name: 'DSD',
    label: '数字化家庭教育服务需求',
    dimension: '数字化家庭教育服务需求',
    sources: ['Q49'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '六类数字化服务需求均值。',
  },
  {
    variable_name: 'UI',
    label: 'AI家庭教育服务使用意愿',
    dimension: 'AI家庭教育服务接受度',
    sources: ['Q50'],
    aggregation: 'mean',
    data_type: 'ordinal',
    note: '核心因变量。',
  },
  {
    variable_name: 'PRC',
    label: 'AI服务风险认知',
    dimension: 'AI服务风险认知',
    sources: ['Q51'],
    aggregation: 'mean',
    data_type: 'interval',
    note: '五类担忧均值，分数越高担忧越强。',
  },
  {
    variable_name: 'AIPV',
    label: 'AI服务感知价值',
    dimension: 'AI家庭教育服务接受度',
    sources: ['Q52'],
    aggregation: 'mean',
    data_type: 'ordinal',
    note: '单题感知价值指标。',
  },
  {
    variable_name: 'WTP',
    label: '家庭教育服务付费意愿',
    dimension: '家庭教育服务付费意愿',
    sources: ['Q53'],
    aggregation: 'mean',
    data_type: 'ordinal',
    note: '有序分类变量（1—5）。',
  },
  {
    variable_name: 'QN',
    label: '家庭教育支持需求综合指数',
    dimension: '综合评价',
    sources: ['Q35', 'Q49'],
    aggregation: 'index',
    data_type: 'interval',
    note:
      '派生指标：将困难程度（FED）与数字化服务需求（DSD）分别标准化后取均值。' +
      '仅在两项均有作答时计算，用于"需求—付费意愿"矩阵分析，不参与信度分析。',
  },
];

/* ------------------------------------------------------------------ */
/* Scale definitions for reliability / validity analysis              */
/* ------------------------------------------------------------------ */

export interface ScaleDefinition {
  variable_name: string;
  label: string;
  dimension: string;
  question_codes: string[];
  /** Reverse-coded item codes, if any. */
  reverse_codes: string[];
  min: number;
  max: number;
}

export const FAMILY_EDU_V4_SCALES: ScaleDefinition[] = [
  {
    variable_name: 'FEI',
    label: '家庭教育认知',
    dimension: '家庭教育认知',
    question_codes: ['Q6', 'Q7', 'Q8'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'FSE',
    label: '家庭教育自我效能',
    dimension: '家庭教育自我效能',
    question_codes: ['Q22', 'Q23', 'Q24', 'Q25', 'Q26', 'Q27', 'Q28', 'Q29', 'Q30'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'FPB',
    label: '科学家庭教育实践',
    dimension: '家庭教育实际行为',
    question_codes: ['Q31', 'Q33', 'Q34'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'ISC',
    label: '信息环境困扰',
    dimension: '信息获取渠道',
    question_codes: ['Q19', 'Q20'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'FED',
    label: '家庭教育困难',
    dimension: '家庭教育困难',
    question_codes: ['Q35'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'DSD',
    label: '数字化家庭教育服务需求',
    dimension: '数字化家庭教育服务需求',
    question_codes: ['Q49'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'PRC',
    label: 'AI服务风险认知',
    dimension: 'AI服务风险认知',
    question_codes: ['Q51'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'STI',
    label: '服务主体信任',
    dimension: '服务主体信任',
    question_codes: ['Q48'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
  {
    variable_name: 'PSU',
    label: '政府公共服务评价',
    dimension: '政府家庭教育公共服务',
    question_codes: ['Q46'],
    reverse_codes: [],
    min: 1,
    max: 5,
  },
];

/* ------------------------------------------------------------------ */
/* Research design (default template project)                         */
/* ------------------------------------------------------------------ */

export const FAMILY_EDU_V4_HYPOTHESES = [
  { code: 'H1', statement: '家庭教育知识水平与家庭教育自我效能呈正向关系。', status: 'untested' as const },
  { code: 'H2', statement: '家庭教育自我效能与科学家庭教育实践呈正向关系。', status: 'untested' as const },
  { code: 'H3', statement: '家庭教育困难程度越高，专业家庭教育服务需求越强。', status: 'untested' as const },
  { code: 'H4', statement: '政府家庭教育公共服务可及性越高，公共服务使用意愿越高。', status: 'untested' as const },
  { code: 'H5', statement: '专业服务信任度越高，数字化家庭教育服务使用意愿越强。', status: 'untested' as const },
  { code: 'H6', statement: 'AI服务感知价值越高，AI使用意愿越强。', status: 'untested' as const },
  { code: 'H7', statement: '隐私和专业性担忧越高，AI使用意愿越低。', status: 'untested' as const },
  { code: 'H8', statement: '家庭教育服务需求越高，付费意愿越高。', status: 'untested' as const },
];

export const FAMILY_EDU_V4_RESEARCH_QUESTIONS = [
  '家长对家庭教育的整体认知水平如何，是否存在"重视但缺乏方法"的落差？',
  '家长对《家庭教育促进法》的主观了解程度与客观知识准确度之间存在多大差距？',
  '家长获取家庭教育信息的渠道结构如何，信息环境是否存在碎片化与可靠性困扰？',
  '家长在家庭教育中遇到的主要困难有哪些，其严重程度与分布如何？',
  '家庭教育机构的知晓率、使用率与满意度现状如何？',
  '政府家庭教育公共服务的知晓—可及—使用—评价链条存在哪些断点？',
  '家长对不同服务主体（政府、学校、机构、专业人士、AI）的信任度差异如何？',
  '家长对数字化与AI家庭教育服务的需求强度、接受度与风险认知如何？',
  '影响家长AI家庭教育服务使用意愿的关键因素有哪些？',
  '家长的付费意愿水平如何，需求强度与付费意愿之间是否匹配？',
];

export const FAMILY_EDU_V4_QUOTA_CONFIG: QuotaConfig = {
  enabled: true,
  preserve_structure: true,
  categories: [
    { dimension: 'STAGE', category: '学前（0—6岁）', target_n: 200 },
    { dimension: 'STAGE', category: '小学', target_n: 300 },
    { dimension: 'STAGE', category: '初中', target_n: 300 },
    { dimension: 'STAGE', category: '高中', target_n: 200 },
  ],
};

export const FAMILY_EDU_V4_SETTINGS: ProjectSettings = {
  anonymous: true,
  allow_partial: false,
  consent_text:
    '本研究为匿名调查。参与完全自愿，您可以拒绝回答任何问题，也可以随时退出。' +
    '调查数据仅用于学术研究与项目分析，不会收集姓名、身份证号、精确住址、学校名称、手机号等' +
    '可识别个人身份的信息。继续填写即表示您已了解并同意上述说明。',
  min_duration_seconds: 90,
};

/* ------------------------------------------------------------------ */
/* Template assembly                                                  */
/* ------------------------------------------------------------------ */

export const FAMILY_EDU_V4_TEMPLATE_KEY = 'family-edu-v4';

export function buildFamilyEduV4Template(): TemplateSeed {
  const questions: QuestionSeed[] = DRAFTS.map((draft) => ({
    question_code: draft.code,
    question_text: draft.text,
    question_type: draft.type,
    options: draft.options ?? {},
    required: draft.required ?? true,
    dimension: draft.dimension,
    variable_name: draft.variable,
    section: draft.section,
    help_text: draft.help ?? null,
    logic: draft.logic ?? null,
    scoring_rule: draft.scoring ?? NO_RULE,
  }));

  return {
    key: FAMILY_EDU_V4_TEMPLATE_KEY,
    version: 'V4.0',
    title: '家庭教育认知、实践与社会支持需求调查',
    description:
      '本问卷旨在了解家长在家庭教育方面的认知、实践、困难与社会支持需求，' +
      '为家庭教育公共服务优化与数字化服务设计提供实证依据。问卷共58题，预计用时8—12分钟。',
    sections: FAMILY_EDU_V4_SECTIONS,
    questions,
    project: {
      title: '家庭教育认知、实践与社会支持需求研究',
      description:
        '家庭教育公共服务与数字化服务需求分析——基于家长问卷调查的实证研究。',
      background:
        '《中华人民共和国家庭教育促进法》自2022年1月1日施行，明确家庭教育以立德树人为根本任务，' +
        '并要求国家和社会为家庭教育提供指导、支持和服务。与此同时，数字化与人工智能技术快速发展，' +
        '为家庭教育支持体系的供给方式带来新的可能。然而，家长的实际需求结构、对现有公共服务的知晓与' +
        '使用状况、以及对新技术的接受度与风险认知，仍缺乏系统的实证证据。',
      objectives:
        '（1）描述家长家庭教育认知、知识、自我效能与实际行为的现状；' +
        '（2）识别家长在家庭教育中的主要困难及其严重程度；' +
        '（3）评估政府家庭教育公共服务的知晓度、可及性与使用情况；' +
        '（4）测量家长对不同服务主体的信任水平；' +
        '（5）分析数字化与AI家庭教育服务的需求强度、接受度、风险认知与付费意愿；' +
        '（6）检验影响服务使用意愿与付费意愿的关键因素，为公共服务优化与产品设计提供依据。',
      research_questions: FAMILY_EDU_V4_RESEARCH_QUESTIONS,
      hypotheses: FAMILY_EDU_V4_HYPOTHESES,
      target_population: '育有学前至高中阶段子女、且主要承担家庭教育责任的家长或监护人。',
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      quota_config: FAMILY_EDU_V4_QUOTA_CONFIG,
      settings: FAMILY_EDU_V4_SETTINGS,
    },
  };
}

/** Convenience accessor used by tests and the API layer. */
export const FAMILY_EDU_V4_TEMPLATE = buildFamilyEduV4Template();
