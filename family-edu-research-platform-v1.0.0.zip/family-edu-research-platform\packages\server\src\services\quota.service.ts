/**
 * Quota service (PHASE 4).
 *
 * Turns the stored quota configuration plus the collected sample into progress,
 * a balance diagnostic and deterministic collection recommendations.
 *
 * Counting rule, and it matters: a category is counted from responses to the
 * question that *defines* the quota dimension (e.g. `STAGE` ← Q4), considering
 * only samples the researcher has not excluded. Excluded samples still exist
 * (the platform never deletes), but they should not count towards a quota,
 * otherwise an excluded duplicate would mask a real shortfall.
 */

import {
  buildQuotaRecommendations,
  computeQuotaProgress,
  diagnoseBalance,
  validateQuotaConfig,
  type QuotaConfig,
  type QuotaRecommendation,
  type QuotaProgressSummary,
  type QuotaValidationIssue,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { parseJson } from './mappers.js';
import { listQuestions } from './questionnaire.service.js';
import { getSourceBreakdown } from './sample.service.js';
import { requireProject } from './project.service.js';

export interface QuotaStatus {
  project_id: string;
  enabled: boolean;
  preserve_structure: boolean;
  /** Question code the quota dimension is measured from, when it is resolvable. */
  dimension_question_code: string | null;
  dimension_variable: string | null;
  progress: QuotaProgressSummary;
  balance: ReturnType<typeof diagnoseBalance>;
  recommendations: QuotaRecommendation[];
  /** Human-readable counting rule, so a number is never unexplained. */
  counting_note: string;
  excluded_samples: number;
  counted_samples: number;
}

/** Count samples per quota category from the dimension question's answers. */
function countByCategor(
  db: Db,
  projectId: string,
  dimension: string,
  categories: readonly { category: string }[],
): { counts: Record<string, number>; questionCode: string | null; variable: string | null } {
  const questionnaire = db.get<{ id: string }>(
    'SELECT id FROM questionnaires WHERE project_id = ? ORDER BY is_current DESC, created_at DESC LIMIT 1',
    [projectId],
  );
  if (!questionnaire) return { counts: {}, questionCode: null, variable: null };

  const questions = listQuestions(db, questionnaire.id);
  // The quota dimension is declared as a variable name (e.g. "STAGE").
  const question = questions.find((item) => item.variable_name === dimension);
  if (!question) return { counts: {}, questionCode: null, variable: dimension };

  const labelToCode = new Map<string, string>();
  const codeToLabel = new Map<string, string>();
  for (const choice of question.options.choices ?? []) {
    labelToCode.set(choice.label, String(choice.value));
    codeToLabel.set(String(choice.value), choice.label);
  }

  const wanted = new Set(categories.map((item) => item.category));
  const codes = [...wanted]
    .map((label) => labelToCode.get(label) ?? (codeToLabel.has(label) ? label : null))
    .filter((code): code is string => code !== null);

  const counts: Record<string, number> = {};
  for (const category of categories) counts[category.category] = 0;
  if (codes.length === 0) {
    return { counts, questionCode: question.question_code, variable: dimension };
  }

  const placeholders = codes.map(() => '?').join(', ');
  const rows = db.all<{ answer: string | null; n: number }>(
    `SELECT r.answer AS answer, COUNT(*) AS n
       FROM responses r
       JOIN respondents d ON d.id = r.respondent_id
      WHERE d.project_id = ?
        AND d.status = 'completed'
        AND COALESCE(d.review_status, 'unreviewed') <> 'excluded'
        AND r.question_code = ?
        AND r.answer IN (${placeholders})
      GROUP BY r.answer`,
    [projectId, question.question_code, ...codes.map((code) => JSON.stringify(code))],
  );

  for (const row of rows) {
    const code = parseJson<string | null>(row.answer, null);
    if (code === null) continue;
    const label = codeToLabel.get(String(code));
    if (label && label in counts) counts[label] = Number(row.n);
  }

  return { counts, questionCode: question.question_code, variable: dimension };
}

export function getQuotaStatus(
  db: Db,
  projectId: string,
  researcherId: string,
): QuotaStatus {
  const project = requireProject(db, projectId, researcherId);
  const config = project.quota_config;

  const excluded = Number(
    db.scalar<number>(
      "SELECT COUNT(*) AS n FROM respondents WHERE project_id = ? AND COALESCE(review_status,'unreviewed') = 'excluded'",
      [projectId],
    ) ?? 0,
  );
  const counted = Number(
    db.scalar<number>(
      "SELECT COUNT(*) AS n FROM respondents WHERE project_id = ? AND status = 'completed' AND COALESCE(review_status,'unreviewed') <> 'excluded'",
      [projectId],
    ) ?? 0,
  );

  if (!config || !config.enabled || config.categories.length === 0) {
    const empty: QuotaProgressSummary = {
      items: [],
      total_target: 0,
      total_current: 0,
      percent: null,
      met_categories: 0,
      unmet_categories: 0,
      largest_shortfalls: [],
    };
    return {
      project_id: projectId,
      enabled: Boolean(config?.enabled),
      preserve_structure: config?.preserve_structure ?? true,
      dimension_question_code: null,
      dimension_variable: null,
      progress: empty,
      balance: diagnoseBalance(empty),
      recommendations: buildQuotaRecommendations({
        config: config ?? null,
        summary: empty,
        balance: diagnoseBalance(empty),
      }),
      counting_note:
        '未配置配额。启用配额后，系统会按配额维度对应的题目统计可用样本，并在结构失衡时给出收集建议。',
      excluded_samples: excluded,
      counted_samples: counted,
    };
  }

  const dimension = config.categories[0]!.dimension;
  const { counts, questionCode, variable } = countByCategor(db, projectId, dimension, config.categories);
  const progress = computeQuotaProgress(config.categories, counts);
  const balance = diagnoseBalance(progress);

  const sources = getSourceBreakdown(db, projectId, researcherId);

  const recommendations = buildQuotaRecommendations({
    config,
    summary: progress,
    balance,
    sourceCounts: sources.items.map((item) => ({
      source: item.source,
      total: item.total,
      completed: item.completed,
    })),
  });

  return {
    project_id: projectId,
    enabled: config.enabled,
    preserve_structure: config.preserve_structure,
    dimension_question_code: questionCode,
    dimension_variable: variable,
    progress,
    balance,
    recommendations,
    counting_note:
      `按题目 ${questionCode ?? '（未找到）'}（变量 ${variable ?? dimension}）统计；` +
      '仅计入已完成且未被研究者排除的样本，进行中与已排除的样本不计入配额。',
    excluded_samples: excluded,
    counted_samples: counted,
  };
}

/* ------------------------------------------------------------------ */
/* Configuration                                                      */
/* ------------------------------------------------------------------ */

export interface QuotaConfigUpdate {
  config: QuotaConfig | null;
}

export function updateQuotaConfig(
  db: Db,
  projectId: string,
  researcherId: string,
  config: unknown,
): QuotaConfig | null {
  requireProject(db, projectId, researcherId);

  const validation = validateQuotaConfig(config);
  if (!validation.valid) {
    throw ApiError.validation(
      `配额配置校验失败，共 ${validation.errors.length} 处问题。`,
      validation.errors,
    );
  }

  db.run('UPDATE research_projects SET quota_config = ?, updated_at = ? WHERE id = ?', [
    config === null || config === undefined ? null : JSON.stringify(config),
    new Date().toISOString(),
    projectId,
  ]);

  return config === null || config === undefined ? null : (config as QuotaConfig);
}

/** Dimensions a questionnaire can build a quota from (categorical variables). */
export function availableQuotaDimensions(
  db: Db,
  projectId: string,
): { variable: string; question_code: string; label: string; categories: string[] }[] {
  const questionnaire = db.get<{ id: string }>(
    'SELECT id FROM questionnaires WHERE project_id = ? ORDER BY is_current DESC, created_at DESC LIMIT 1',
    [projectId],
  );
  if (!questionnaire) return [];

  return listQuestions(db, questionnaire.id)
    .filter((question) => {
      const rule = question.scoring_rule;
      const choices = question.options.choices ?? [];
      return (
        question.variable_name !== null &&
        (question.question_type === 'single' || question.question_type === 'dropdown') &&
        choices.length >= 2 &&
        choices.length <= 12 &&
        (rule?.type === 'categorical' || rule?.type === 'ordinal')
      );
    })
    .map((question) => ({
      variable: question.variable_name!,
      question_code: question.question_code,
      label: question.question_text,
      categories: (question.options.choices ?? []).map((choice) => choice.label),
    }));
}

export type { QuotaValidationIssue };
