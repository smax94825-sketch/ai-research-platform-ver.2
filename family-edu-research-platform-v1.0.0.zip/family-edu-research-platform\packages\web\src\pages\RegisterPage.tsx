import { useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Alert, Button, Card, Field, Input } from '../components/ui';
import { useAuth } from '../lib/auth';

/** Client-side mirror of the server password policy. */
function passwordIssues(password: string): string[] {
  const issues: string[] = [];
  if (password.length < 8) issues.push('密码长度至少为 8 个字符。');
  if (!/[A-Za-z]/.test(password)) issues.push('密码需包含至少一个字母。');
  if (!/[0-9]/.test(password)) issues.push('密码需包含至少一个数字。');
  return issues;
}

export function RegisterPage(): ReactNode {
  const { register, error, clearError } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [affiliation, setAffiliation] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const issues = password.length > 0 ? passwordIssues(password) : [];
  const mismatch = confirm.length > 0 && confirm !== password;

  async function handleSubmit(event: FormEvent): Promise<void> {
    event.preventDefault();
    if (issues.length > 0 || mismatch) return;
    setSubmitting(true);
    try {
      await register({
        name: name.trim(),
        email: email.trim(),
        password,
        ...(affiliation.trim() ? { affiliation: affiliation.trim() } : {}),
      });
      navigate('/', { replace: true });
    } catch {
      // Error message comes from the auth context.
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <h1 className="text-xl font-semibold text-ink-900">家庭教育科研智能研究平台</h1>
          <p className="mt-1 text-sm text-ink-500">注册研究者账号</p>
        </div>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert tone="danger" title="注册失败">
                {error}
              </Alert>
            )}

            <Field label="姓名" required>
              <Input
                required
                value={name}
                onChange={(event) => {
                  clearError();
                  setName(event.target.value);
                }}
                placeholder="您的姓名"
              />
            </Field>

            <Field label="邮箱" required hint="用于登录，平台不会对外公开。">
              <Input
                type="email"
                autoComplete="username"
                required
                value={email}
                onChange={(event) => {
                  clearError();
                  setEmail(event.target.value);
                }}
                placeholder="researcher@example.com"
              />
            </Field>

            <Field label="所属机构" hint="选填，例如某大学教育学院。">
              <Input
                value={affiliation}
                onChange={(event) => setAffiliation(event.target.value)}
                placeholder="选填"
              />
            </Field>

            <Field
              label="密码"
              required
              error={issues.length > 0 ? issues.join(' ') : undefined}
              hint="至少 8 位，且同时包含字母与数字。"
            >
              <Input
                type="password"
                autoComplete="new-password"
                required
                value={password}
                onChange={(event) => {
                  clearError();
                  setPassword(event.target.value);
                }}
              />
            </Field>

            <Field label="确认密码" required error={mismatch ? '两次输入的密码不一致。' : undefined}>
              <Input
                type="password"
                autoComplete="new-password"
                required
                value={confirm}
                onChange={(event) => setConfirm(event.target.value)}
              />
            </Field>

            <Button
              type="submit"
              variant="primary"
              className="w-full"
              loading={submitting}
              disabled={issues.length > 0 || mismatch}
            >
              注册
            </Button>
          </form>

          <p className="mt-4 text-center text-sm text-ink-500">
            已有账号？
            <Link to="/login" className="ml-1 font-medium text-brand-600 hover:underline">
              返回登录
            </Link>
          </p>
        </Card>
      </div>
    </div>
  );
}
