/**
 * Instrument template tests.
 *
 * These assertions protect the scientific integrity of the default V4.0
 * questionnaire: a wrong item count, a missing variable, a knowledge item with
 * no correct answer or a sensitive item that lost its refusal code would all
 * silently corrupt every downstream analysis, so they are pinned here.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  FAMILY_EDU_V4_TEMPLATE,
  FAMILY_EDU_V4_SECTIONS,
  FAMILY_EDU_V4_COMPOSITES,
  FAMILY_EDU_V4_SCALES,
  FAMILY_EDU_V4_HYPOTHESES,
  FAMILY_EDU_V4_QUOTA_CONFIG,
  QUESTION_TYPE_LABELS,
  isSensitiveQuestion,
  validateQuestionInput,
  type Question,
  type QuestionSeed,
} from '../src/index.js';

const seeds: QuestionSeed[] = FAMILY_EDU_V4_TEMPLATE.questions;

/** Adapt a seed to the Question shape consumed by the scoring/dictionary code. */
function toQuestion(seed: QuestionSeed, index: number): Question {
  return {
    id: `q-${seed.question_code}`,
    questionnaire_id: 'qn-1',
    question_code: seed.question_code,
    question_text: seed.question_text,
    question_type: seed.question_type,
    options: seed.options,
    required: seed.required,
    dimension: seed.dimension,
    variable_name: seed.variable_name,
    sort_order: index + 1,
    section: seed.section,
    help_text: seed.help_text,
    logic: seed.logic,
    scoring_rule: seed.scoring_rule,
    created_at: '2025-01-01T00:00:00.000Z',
    updated_at: '2025-01-01T00:00:00.000Z',
  };
}

const questions: Question[] = seeds.map(toQuestion);

describe('V4.0 问卷结构', () => {
  test('包含恰好 58 道题', () => {
    assert.equal(seeds.length, 58);
  });

  test('题号从 Q1 连续到 Q58，无重复无缺失', () => {
    const codes = seeds.map((s) => s.question_code);
    const expected = Array.from({ length: 58 }, (_, i) => `Q${i + 1}`);
    assert.deepEqual(codes, expected);
    assert.equal(new Set(codes).size, 58);
  });

  test('十三个部分覆盖 Q1—Q58 且区间连续无缝', () => {
    assert.equal(FAMILY_EDU_V4_SECTIONS.length, 13);
    let expectedStart = 1;
    for (const section of FAMILY_EDU_V4_SECTIONS) {
      assert.equal(
        section.first_code,
        `Q${expectedStart}`,
        `部分「${section.title}」起始题号应为 Q${expectedStart}`,
      );
      const endNumber = Number(section.last_code.slice(1));
      assert.ok(endNumber >= expectedStart, `部分「${section.title}」结束题号异常`);
      expectedStart = endNumber + 1;
    }
    assert.equal(expectedStart, 59, '最后一个部分应结束于 Q58');
  });

  test('每道题的 section 都能在部分定义中找到', () => {
    const titles = new Set(FAMILY_EDU_V4_SECTIONS.map((s) => s.title));
    for (const seed of seeds) {
      assert.ok(titles.has(seed.section), `题目 ${seed.question_code} 的部分「${seed.section}」未定义`);
    }
  });

  test('题型声明均为平台支持的题型', () => {
    for (const seed of seeds) {
      assert.ok(
        seed.question_type in QUESTION_TYPE_LABELS,
        `题目 ${seed.question_code} 使用了未知题型 ${seed.question_type}`,
      );
    }
  });

  test('所有题目定义均通过输入校验', () => {
    const failures: string[] = [];
    for (const seed of seeds) {
      const result = validateQuestionInput(seed);
      if (!result.valid) {
        failures.push(`${seed.question_code}: ${result.errors.map((e) => e.message).join('; ')}`);
      }
    }
    assert.deepEqual(failures, []);
  });
});

describe('核心研究变量', () => {
  const requiredComposites = [
    'FEI', 'FEK', 'LSK', 'LKA', 'ISC', 'FSE',
    'FPB', 'FED', 'FIU', 'PSA', 'STI', 'DSD', 'WTP', 'UI', 'QN',
  ];

  test('15 个核心变量全部有定义', () => {
    const defined = new Set(FAMILY_EDU_V4_COMPOSITES.map((c) => c.variable_name));
    for (const name of requiredComposites) {
      assert.ok(defined.has(name), `缺少核心变量 ${name}`);
    }
  });

  test('每个派生变量的来源题号都真实存在', () => {
    const codes = new Set(seeds.map((s) => s.question_code));
    for (const spec of FAMILY_EDU_V4_COMPOSITES) {
      assert.ok(spec.sources.length > 0, `${spec.variable_name} 没有来源题项`);
      for (const source of spec.sources) {
        assert.ok(codes.has(source), `${spec.variable_name} 引用了不存在的题目 ${source}`);
      }
    }
  });

  test('展开后的变量名全局唯一（矩阵行展开后也不得重名）', () => {
    // Two questions producing the same variable name is silent data loss: the
    // dataset indexes variables by name, so the later one shadows the earlier in
    // every analysis, and an export writes two columns with one header. Matrix
    // questions are the trap, because their rows expand to `<prefix><rowValue>`,
    // which can collide with an ordinary question's variable name.
    const owners = new Map<string, string[]>();
    for (const question of seeds) {
      const names: string[] = [];
      if (question.question_type === 'matrix') {
        for (const row of question.options.matrix?.rows ?? []) {
          names.push(`${question.variable_name ?? question.question_code}${row.value}`);
        }
        names.push(question.variable_name ?? question.question_code);
      } else {
        names.push(question.variable_name ?? question.question_code);
      }
      for (const name of names) {
        owners.set(name, [...(owners.get(name) ?? []), question.question_code]);
      }
    }

    const duplicates = [...owners.entries()].filter(([, codes]) => codes.length > 1);
    assert.deepEqual(
      duplicates.map(([name, codes]) => `${name} ← ${codes.join('/')}`),
      [],
      '存在重名变量：后者会在分析中被静默遮蔽，并在导出中产生重复列名',
    );
  });

  test('LKA 由 Q12—Q16 五道知识题构成，理论总分 0—5', () => {
    const lka = FAMILY_EDU_V4_COMPOSITES.find((c) => c.variable_name === 'LKA');
    assert.ok(lka);
    assert.deepEqual(lka.sources, ['Q12', 'Q13', 'Q14', 'Q15', 'Q16']);
    assert.equal(lka.aggregation, 'sum');

    const knowledgeItems = seeds.filter((s) => s.question_type === 'knowledge_test');
    assert.equal(knowledgeItems.length, 5);
    const maxTotal = knowledgeItems.reduce((sum, item) => {
      const rule = item.scoring_rule;
      return sum + (rule && rule.type === 'knowledge' ? rule.maxScore : 0);
    }, 0);
    assert.equal(maxTotal, 5);
  });

  test('FEK(主观) 与 LKA(客观) 是彼此独立的两个变量', () => {
    const fek = FAMILY_EDU_V4_COMPOSITES.find((c) => c.variable_name === 'FEK');
    const lka = FAMILY_EDU_V4_COMPOSITES.find((c) => c.variable_name === 'LKA');
    assert.ok(fek && lka);
    assert.notDeepEqual(fek.sources, lka.sources);
    assert.ok(!lka.sources.includes('Q9'), '客观知识得分不得混入主观自评题 Q9');
  });

  test('FPB 不含敏感题 Q32', () => {
    const fpb = FAMILY_EDU_V4_COMPOSITES.find((c) => c.variable_name === 'FPB');
    assert.ok(fpb);
    assert.ok(!fpb.sources.includes('Q32'), 'Q32 为敏感题，不得并入科学实践均值');
  });
});

describe('《家庭教育促进法》知识题 Q12—Q16', () => {
  const knowledge = seeds.filter((s) => s.question_type === 'knowledge_test');

  test('每题都恰好标记一个正确答案', () => {
    for (const item of knowledge) {
      const correct = (item.options.choices ?? []).filter((c) => c.isCorrect);
      assert.equal(correct.length, 1, `${item.question_code} 的正确答案数量应为 1`);
    }
  });

  test('每题都包含"不清楚"选项且计 0 分', () => {
    for (const item of knowledge) {
      const unknown = (item.options.choices ?? []).find((c) => c.value === '3');
      assert.ok(unknown, `${item.question_code} 缺少"不清楚"选项`);
      assert.equal(unknown.label, '不清楚');
      const rule = item.scoring_rule;
      assert.ok(rule && rule.type === 'knowledge');
      assert.equal(rule.unknownScore, 0);
      assert.equal(rule.correctScore, 1);
      assert.equal(rule.incorrectScore, 0);
    }
  });

  test('正确答案分布不是全部相同，避免默许反应偏差', () => {
    const answers = knowledge.map(
      (item) => (item.options.choices ?? []).find((c) => c.isCorrect)?.value,
    );
    assert.ok(new Set(answers).size > 1, '所有知识题的正确答案都是同一选项，会引入默许偏差');
    assert.ok(answers.includes('2'), '应至少有一道题的正确答案是"错误"，以检验真实理解');
  });

  test('Q15 与 Q16 的正确答案是"错误"（陈述本身不成立）', () => {
    for (const code of ['Q15', 'Q16']) {
      const item = seeds.find((s) => s.question_code === code);
      assert.ok(item);
      const correct = (item.options.choices ?? []).find((c) => c.isCorrect);
      assert.equal(correct?.value, '2', `${code} 的正确答案应为"错误"`);
    }
  });

  test('Q12 关于施行日期的陈述为真，因此正确答案是"正确"', () => {
    const item = seeds.find((s) => s.question_code === 'Q12');
    assert.ok(item);
    assert.match(item.question_text, /2022年1月1日/);
    assert.equal((item.options.choices ?? []).find((c) => c.isCorrect)?.value, '1');
  });
});

describe('敏感题 Q32', () => {
  const q32 = seeds.find((s) => s.question_code === 'Q32');

  test('Q32 存在且被识别为敏感题', () => {
    assert.ok(q32);
    assert.ok(isSensitiveQuestion(toQuestion(q32, 31)));
  });

  test('"不愿回答"是显式的敏感未作答代码', () => {
    const refusal = (q32!.options.choices ?? []).find((c) => c.label === '不愿回答');
    assert.ok(refusal, 'Q32 必须提供"不愿回答"选项');
    assert.equal(refusal.sensitiveNonResponse, true);
  });

  test('Q32 不是必答题，受访者可以拒答', () => {
    assert.equal(q32!.required, false);
  });

  test('"不愿回答"在分类编码中映射为缺失（null），而非 0', () => {
    const rule = q32!.scoring_rule;
    assert.ok(rule && (rule.type === 'categorical' || rule.type === 'ordinal'));
    assert.equal(rule.codes['5'], null, '"不愿回答"必须编码为缺失');
    assert.equal(rule.codes['1'], 0, '"从未"编码为 0');
  });

  test('Q32 按有序分类编码（0—3 的严重程度序列）', () => {
    const rule = q32!.scoring_rule;
    assert.ok(rule && rule.type === 'ordinal', '体罚频次是有序分类变量，应声明为 ordinal');
  });
});

describe('跳转逻辑 Q39 → Q41', () => {
  const q39 = seeds.find((s) => s.question_code === 'Q39');
  const q40 = seeds.find((s) => s.question_code === 'Q40');

  test('Q39 声明了跳过 Q40 的跳转规则', () => {
    assert.ok(q39?.logic);
    const jump = q39.logic.rules.find((r) => r.action.type === 'jump_to');
    assert.ok(jump, 'Q39 缺少跳转规则');
    assert.equal(jump.action.type === 'jump_to' ? jump.action.target : null, 'Q41');
    assert.deepEqual(jump.conditions, [{ questionCode: 'Q39', operator: 'eq', value: '1' }]);
  });

  test('Q40 声明了条件显示规则，双重保障不会误问', () => {
    assert.ok(q40?.logic);
    const show = q40.logic.rules.find((r) => r.action.type === 'show');
    assert.ok(show);
    assert.equal(show.conditions?.[0]?.questionCode, 'Q39');
    assert.equal(show.conditions?.[0]?.operator, 'neq');
  });

  test('"从未使用"是选项代码 1', () => {
    const never = (q39!.options.choices ?? []).find((c) => c.value === '1');
    assert.equal(never?.label, '从未使用');
  });
});

describe('研究设计元数据', () => {
  test('包含 8 条待检验假设 H1—H8，且状态均为未检验', () => {
    assert.equal(FAMILY_EDU_V4_HYPOTHESES.length, 8);
    assert.deepEqual(
      FAMILY_EDU_V4_HYPOTHESES.map((h) => h.code),
      ['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'H7', 'H8'],
    );
    for (const hypothesis of FAMILY_EDU_V4_HYPOTHESES) {
      assert.equal(hypothesis.status, 'untested', '模板中的假设不得预设为已支持');
    }
  });

  test('目标样本量与分阶段配额自洽（200+300+300+200＝1000）', () => {
    const total = FAMILY_EDU_V4_QUOTA_CONFIG.categories.reduce((s, c) => s + c.target_n, 0);
    assert.equal(total, 1000);
    assert.equal(FAMILY_EDU_V4_TEMPLATE.project.target_sample_size, 1000);
  });

  test('配额维度为 Q4 的教育阶段变量 STAGE', () => {
    for (const category of FAMILY_EDU_V4_QUOTA_CONFIG.categories) {
      assert.equal(category.dimension, 'STAGE');
    }
  });

  test('伦理声明包含匿名与自愿要点，且默认不收集身份信息', () => {
    const consent = FAMILY_EDU_V4_TEMPLATE.project.settings?.consent_text ?? '';
    assert.match(consent, /匿名/);
    assert.match(consent, /自愿/);
    assert.match(consent, /拒绝回答/);
    assert.equal(FAMILY_EDU_V4_TEMPLATE.project.settings?.anonymous, true);
  });

  test('问卷中不存在采集直接身份标识的题目', () => {
    const forbidden = ['身份证', '手机号', '电话号码', '家庭住址', '姓名', '学校名称'];
    for (const seed of seeds) {
      for (const word of forbidden) {
        const inQuestion = seed.question_text.includes(word);
        const inHelp = (seed.help_text ?? '').includes(word);
        // Wording such as "不会收集姓名" is a privacy assurance, not collection.
        const isAssurance = (seed.help_text ?? '').includes(`不`) && inHelp;
        assert.ok(
          !inQuestion && (!inHelp || isAssurance),
          `题目 ${seed.question_code} 可能采集了身份信息关键词「${word}」`,
        );
      }
    }
  });

  test('信度分析量表定义引用的题目均存在', () => {
    const codes = new Set(seeds.map((s) => s.question_code));
    for (const scale of FAMILY_EDU_V4_SCALES) {
      for (const code of scale.question_codes) {
        assert.ok(codes.has(code), `量表 ${scale.variable_name} 引用了不存在的题目 ${code}`);
      }
    }
  });
});

describe('题型覆盖', () => {
  test('模板覆盖平台要求的全部核心题型', () => {
    const used = new Set(seeds.map((s) => s.question_type));
    const requiredTypes = [
      'single',
      'multiple',
      'likert',
      'matrix',
      'text',
      'number',
      'dropdown',
      'ranking',
      'knowledge_test',
      'page_break',
    ] as const;
    // The V4.0 instrument itself uses most types; text/number/dropdown/page_break
    // are builder capabilities validated separately in the builder tests.
    const inTemplate = ['single', 'multiple', 'likert', 'matrix', 'textarea', 'ranking', 'knowledge_test'] as const;
    for (const type of inTemplate) {
      assert.ok(used.has(type), `模板未使用题型 ${type}`);
    }
    for (const type of requiredTypes) {
      assert.ok(type in QUESTION_TYPE_LABELS, `平台未声明题型 ${type}`);
    }
  });

  test('至少一道矩阵题带有多个行项目', () => {
    const matrices = seeds.filter((s) => s.question_type === 'matrix');
    assert.ok(matrices.length >= 4, '模板应包含至少 4 道矩阵题');
    for (const matrix of matrices) {
      assert.ok((matrix.options.matrix?.rows.length ?? 0) >= 5, `${matrix.question_code} 行项目过少`);
      assert.ok((matrix.options.matrix?.columns.length ?? 0) >= 5, `${matrix.question_code} 评价刻度不足`);
    }
  });

  test('Q22—Q30 构成 9 题 FSE 量表', () => {
    const fseItems = seeds.filter((s) => /^FSE[1-9]$/.test(s.variable_name ?? ''));
    assert.equal(fseItems.length, 9);
    assert.deepEqual(
      fseItems.map((s) => s.question_code),
      Array.from({ length: 9 }, (_, i) => `Q${22 + i}`),
    );
  });
});

describe('数据质量检测所需的变量可用性', () => {
  test('存在主观知识自评题（Q9）用于主客观差异检测', () => {
    const q9 = seeds.find((s) => s.question_code === 'Q9');
    assert.equal(q9?.variable_name, 'FEK');
    assert.equal(q9?.question_type, 'likert');
  });

  test('存在地区与教育阶段变量用于配额与代表性分析', () => {
    assert.equal(seeds.find((s) => s.question_code === 'Q5')?.variable_name, 'AREA');
    assert.equal(seeds.find((s) => s.question_code === 'Q4')?.variable_name, 'STAGE');
  });

  test('存在服务渠道与信任变量用于创业洞察分析', () => {
    const variables = new Set(seeds.map((s) => s.variable_name));
    for (const name of ['ISCB', 'ISCT', 'STI', 'DSD', 'WTP', 'UI', 'PRC', 'AIPV']) {
      assert.ok(variables.has(name), `缺少创业分析所需变量 ${name}`);
    }
  });
});
