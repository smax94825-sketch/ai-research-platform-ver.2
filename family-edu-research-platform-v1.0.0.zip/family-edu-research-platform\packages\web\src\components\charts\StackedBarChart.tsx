/**
 * Likert / matrix item distributions as a diverging stacked bar chart.
 *
 * The layout is the standard "Likert diverging" one: options run from negative
 * on the left to positive on the right, the neutral option straddles a centred
 * zero line, and both sides share ONE scale — 100% of a row's answers span the
 * full plotting width. That single scale is what makes the left and right halves
 * directly comparable; scaling each half independently would make a 50/50 item
 * look identical to a 90/10 one.
 *
 * Each row states its own n and its negative / neutral / positive shares as
 * text, so the chart is readable without hovering and without colour vision.
 */

import type { ReactNode } from 'react';
import { truncate } from '../../lib/format';
import {
  ChartCaption,
  ChartEmpty,
  FONT,
  FONT_SMALL,
  ResponsiveSvg,
  divergingFill,
} from './primitives';

export interface LikertRow {
  label: string;
  /** Counts aligned with `options`; shorter arrays are treated as zero. */
  counts: number[];
}

export interface StackedBarChartProps {
  /** Option labels ordered from the most negative to the most positive. */
  options: string[];
  rows: LikertRow[];
  /**
   * Index of the neutral option. Options before it count as negative, options
   * after it as positive. Use -1 when the scale has no neutral point.
   * Defaults to the middle option of an odd-length scale.
   */
  neutralIndex?: number;
  categoryLabels?: { negative: string; neutral: string; positive: string };
  unit?: string;
  emptyText?: string;
  caption?: ReactNode;
}

const WIDTH = 680;
const ROW_HEIGHT = 48;
const BAR_HEIGHT = 14;

/** Fill for option `index` of `total`, following the negative→positive order. */
export function optionFill(index: number, total: number): string {
  const position = total <= 1 ? 0.5 : index / (total - 1);
  return divergingFill(position * 2 - 1).fill;
}

export function StackedBarChart({
  options,
  rows,
  neutralIndex,
  categoryLabels = { negative: '越偏否定', neutral: '中立', positive: '越偏肯定' },
  unit = '人',
  emptyText = '暂无可展示的分布数据。',
  caption,
}: StackedBarChartProps): ReactNode {
  if (rows.length === 0 || options.length === 0) return <ChartEmpty text={emptyText} />;

  const neutral =
    neutralIndex === undefined ? (options.length % 2 === 1 ? (options.length - 1) / 2 : -1) : neutralIndex;

  // Index of the first option that counts as positive; an even-length scale with
  // no neutral point is split down the middle.
  const firstPositive = neutral >= 0 ? neutral + 1 : Math.ceil(options.length / 2);
  const optionIndices = options.map((_, index) => index);

  const halfWidth = WIDTH / 2;
  const topPadding = 4;
  const axisHeight = 20;
  const height = topPadding + rows.length * ROW_HEIGHT + axisHeight;

  // Option totals across every row, for the legend.
  const totals = options.map((_, index) =>
    rows.reduce((sum, row) => sum + (row.counts[index] ?? 0), 0),
  );
  const grandTotal = totals.reduce((sum, value) => sum + value, 0);

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={height} label="李克特量表条目分布（发散堆叠条形图）">
        {rows.map((row, rowIndex) => {
          const rowTop = topPadding + rowIndex * ROW_HEIGHT;
          const counts = options.map((_, index) => row.counts[index] ?? 0);
          const n = counts.reduce((sum, value) => sum + value, 0);

          const negativeIndices = optionIndices.filter((index) => index < firstPositive && index !== neutral);
          const positiveIndices = optionIndices.filter((index) => index >= firstPositive);

          const negativeShare = negativeIndices.reduce((sum, index) => sum + (counts[index] ?? 0), 0);
          const neutralCount = neutral >= 0 ? counts[neutral] ?? 0 : 0;
          const positiveShare = positiveIndices.reduce((sum, index) => sum + (counts[index] ?? 0), 0);

          const share = (value: number) => (n > 0 ? value / n : 0);

          // Draw each side outward from the centre so the ordering of the
          // options is preserved (most extreme option at the outer end).
          let cursor = halfWidth;
          const segments: { x: number; width: number; index: number }[] = [];
          for (const index of [...negativeIndices].reverse()) {
            const width = share(counts[index] ?? 0) * WIDTH;
            cursor -= width;
            segments.push({ x: cursor, width, index });
          }
          if (neutral >= 0 && neutralCount > 0) {
            // The neutral option is split across the centre line, half on each
            // side, which is what "centred neutral" means visually.
            const width = share(neutralCount) * WIDTH;
            segments.push({ x: halfWidth - width / 2, width, index: neutral });
          }
          let rightCursor = halfWidth;
          for (const index of positiveIndices) {
            const width = share(counts[index] ?? 0) * WIDTH;
            segments.push({ x: rightCursor, width, index });
            rightCursor += width;
          }

          return (
            <g key={`${row.label}-${rowIndex}`}>
              <text x={0} y={rowTop + 11} fontSize={FONT} fill="#3a4150">
                {truncate(row.label, 30)}
              </text>
              <text x={WIDTH} y={rowTop + 11} fontSize={FONT} fill="#68778e" textAnchor="end">
                {`n = ${n}`}
              </text>
              {segments.map((segment) => (
                <rect
                  key={`${segment.index}-${segment.x.toFixed(2)}`}
                  x={segment.x}
                  y={rowTop + 16}
                  width={Math.max(segment.width, 0)}
                  height={BAR_HEIGHT}
                  fill={optionFill(segment.index, options.length)}
                  stroke="#ffffff"
                  strokeWidth={0.75}
                />
              ))}
              <text x={0} y={rowTop + 44} fontSize={FONT_SMALL} fill="#535f74">
                {neutral >= 0
                  ? `${categoryLabels.negative} ${(share(negativeShare) * 100).toFixed(1)}% · ` +
                    `${categoryLabels.neutral} ${(share(neutralCount) * 100).toFixed(1)}% · ` +
                    `${categoryLabels.positive} ${(share(positiveShare) * 100).toFixed(1)}%`
                  : `${categoryLabels.negative} ${(share(negativeShare) * 100).toFixed(1)}% · ` +
                    `${categoryLabels.positive} ${(share(positiveShare) * 100).toFixed(1)}%`}
              </text>
            </g>
          );
        })}

        {/* Centre zero line, spanning every row. */}
        <line
          x1={halfWidth}
          y1={topPadding}
          x2={halfWidth}
          y2={topPadding + rows.length * ROW_HEIGHT}
          stroke="#333945"
          strokeWidth={1}
        />
        <text
          x={halfWidth}
          y={topPadding + rows.length * ROW_HEIGHT + 13}
          fontSize={FONT_SMALL}
          fill="#535f74"
          textAnchor="middle"
        >
          0
        </text>
        <text
          x={0}
          y={topPadding + rows.length * ROW_HEIGHT + 13}
          fontSize={FONT_SMALL}
          fill="#68778e"
        >
          {`← ${categoryLabels.negative}`}
        </text>
        <text
          x={WIDTH}
          y={topPadding + rows.length * ROW_HEIGHT + 13}
          fontSize={FONT_SMALL}
          fill="#68778e"
          textAnchor="end"
        >
          {`${categoryLabels.positive} →`}
        </text>
      </ResponsiveSvg>

      <ul className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-600">
        {options.map((label, index) => {
          const count = totals[index] ?? 0;
          const percent = grandTotal > 0 ? (count / grandTotal) * 100 : 0;
          return (
            <li key={label} className="flex items-center gap-1.5">
              <span
                className="inline-block h-2.5 w-2.5 rounded-sm"
                style={{ backgroundColor: optionFill(index, options.length) }}
              />
              <span>{label}</span>
              <span className="tabular-nums text-ink-500">
                {`${count} ${unit}（${percent.toFixed(1)}%）`}
              </span>
            </li>
          );
        })}
      </ul>

      <ChartCaption>
        {caption ??
          '左右两侧使用同一比例尺：某条目全部作答合计占满整行宽度；中立选项跨越中央 0 线，两侧各占一半。'}
      </ChartCaption>
    </div>
  );
}
