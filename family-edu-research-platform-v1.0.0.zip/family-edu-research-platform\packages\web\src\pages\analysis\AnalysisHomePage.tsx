/**
 * Analysis console home (PHASE 6).
 *
 * The hub answers three questions before anything else: what sample the engine
 * would analyse, what the persisted bundle's status is, and which analyses are
 * available for this instrument. It also owns the one action that writes
 * anything — running the full analysis and persisting the bundle that the AI
 * assistant, the report generator and the competition analysis all read from.
 */

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import {
  FunnelChart,
  PieChart,
  ProgressBar,
  SourceChannelChart,
} from '../../components/charts';
import { Alert, Badge, Button, Card, CardHeader, LoadingBlock, StatCard } from '../../components/ui';
import {
  api,
  ApiClientError,
  type AnalysisBundleResponse,
  type AnalysisDatasetInventory,
} from '../../lib/api';
import { formatDateTime, formatNumber, formatStat } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  UnavailableNotice,
  unavailableReason,
  useAnalysisProject,
} from './shared';

const ANALYSIS_LINKS: { to: string; title: string; description: string }[] = [
  {
    to: '/analysis/descriptive',
    title: 'Descriptive · 描述统计',
    description: '各变量的有效 n、缺失、均值、标准差、中位数、四分位数与偏度，并附分类变量频数图。',
  },
  {
    to: '/analysis/reliability',
    title: 'Reliability · 信度分析',
    description: '各量表的 Cronbach α、标准化 α，以及条目层面的校正题总相关与「删除该条目后的 α」。',
  },
  {
    to: '/analysis/validity',
    title: 'Validity · 效度分析',
    description: '整体 KMO 与逐项 MSA、Bartlett 球形检验，以及各量表探索性因素分析的特征值、碎石图、负荷与共同度。',
  },
  {
    to: '/analysis/correlation',
    title: 'Correlation · 相关分析',
    description: '相关矩阵热力图与变量对明细，逐格标注所用方法（Pearson / Spearman）与显著性。',
  },
  {
    to: '/analysis/regression',
    title: 'Regression · 回归分析',
    description: '引擎的模型选择结论、OLS 系数表（B、SE、β、t、p、VIF、95% CI）、拟合指标与残差诊断，以及有序 Logistic 结果。',
  },
  {
    to: '/analysis/comparison',
    title: 'Group Comparison · 组间比较',
    description: '各因变量的分布筛查、单因素 ANOVA（含事后比较）与非参数 Kruskal–Wallis 对照，并给出引擎建议。',
  },
  {
    to: '/analysis/hypotheses',
    title: 'Hypothesis Testing · 假设检验',
    description: '八条研究假设的三态判定（支持 / 不支持 / 证据不足）、方法、效应量、证据与注意事项。',
  },
];

export function AnalysisHomePage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId, projects } = state;

  const [dataset, setDataset] = useState<AnalysisDatasetInventory | null>(null);
  const [bundle, setBundle] = useState<AnalysisBundleResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      const [inventory, latest] = await Promise.all([
        api.analysis.dataset(projectId),
        api.analysis.bundle(projectId),
      ]);
      setDataset(inventory);
      setBundle(latest);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载分析数据。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const project = useMemo(
    () => projects?.items.find((item) => item.id === projectId) ?? null,
    [projects, projectId],
  );

  async function runAll(): Promise<void> {
    setRunning(true);
    setError(null);
    setNotice(null);
    try {
      const result = await api.analysis.run(projectId);
      setNotice(
        `全部分析已运行并保存：引擎版本 ${result.engine_version}，分析基础 ${result.sample.analysable} 份，` +
          `生成时间 ${formatDateTime(result.generated_at)}。` +
          `共计算描述统计、信度、效度、相关、回归、组间比较与 ${result.hypotheses.summary.total} 条假设检验。` +
          '（本操作只读取已收集数据，不会修改任何作答）',
      );
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '运行全部分析失败。');
    } finally {
      setRunning(false);
    }
  }

  const bundleReason = unavailableReason(bundle);

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Analysis"
          subtitle="统计分析控制台：先确认分析样本，再运行并保存全套统计结果。"
          state={state}
          actions={
            <Button variant="primary" loading={running} onClick={() => void runAll()}>
              运行全部分析
            </Button>
          }
        />

        {error && <ErrorNotice message={error} />}
        {notice && <Alert tone="success">{notice}</Alert>}

        {loading && !dataset ? (
          <LoadingBlock label="正在读取分析样本…" />
        ) : !dataset ? null : (
          <>
            {/* Sample ------------------------------------------------------ */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
              <StatCard label="累计样本" value={formatNumber(dataset.sample.respondents_total)} />
              <StatCard label="已完成" value={formatNumber(dataset.sample.completed)} />
              <StatCard
                label="可分析样本"
                value={formatNumber(dataset.sample.analysable)}
                tone="info"
                hint="已完成且未被研究者排除"
              />
              <StatCard
                label="已排除"
                value={formatNumber(dataset.sample.excluded)}
                tone={dataset.sample.excluded > 0 ? 'warning' : 'neutral'}
                hint="由研究者人工判定，非系统剔除"
              />
              <StatCard label="分析变量" value={formatNumber(dataset.variable_count)} hint={`其中派生变量 ${dataset.derived_variable_count} 个`} />
            </div>

            <MethodNote>
              <p>{dataset.note}</p>
              <p>
                引擎版本 {dataset.engine_version}；本次载入的整例样本行数为 {dataset.sample.rows_loaded}，
                与可分析样本数一致，说明分析只使用已完成且未被排除的样本。
              </p>
              {dataset.empty_variables.length > 0 && (
                <p className="text-amber-700">
                  以下变量没有任何有效作答，未参与分析：{dataset.empty_variables.join('、')}。
                </p>
              )}
            </MethodNote>

            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader title="样本收集漏斗" description="从开始作答到进入分析的每一步留存，并标明排除样本的去向。" />
                <FunnelChart
                  stages={[
                    { label: '开始作答', count: dataset.sample.respondents_total },
                    { label: '完成问卷', count: dataset.sample.completed },
                    { label: '进入分析（可分析样本）', count: dataset.sample.analysable },
                    {
                      label: '被研究者排除',
                      count: dataset.sample.excluded,
                      note: '已完成但审核为排除',
                      detached: true,
                    },
                  ]}
                />
              </Card>

              <Card>
                <CardHeader title="样本状态构成" description="按问卷状态统计的受访者构成（审核排除为并列计数，不计入本图）。" />
                <PieChart
                  data={[
                    { label: '已完成', value: dataset.sample.completed },
                    { label: '作答中', value: dataset.sample.in_progress },
                    { label: '已放弃', value: dataset.sample.abandoned },
                  ]}
                  unit="人"
                  caption="三类状态互斥，合计等于累计样本数；研究者审核排除的样本可能来自其中任一状态，故单列于漏斗图。"
                />
              </Card>

              <Card>
                <CardHeader title="样本来源渠道" description="受访者进入问卷时携带的渠道参数统计。" />
                <SourceChannelChart sources={dataset.sample.sources} />
              </Card>

              <Card>
                <CardHeader
                  title="目标样本量进度"
                  description="以研究项目设定的目标样本量为分母，衡量当前可分析样本的收集进度。"
                />
                <ProgressBar
                  items={[
                    {
                      label: project?.title ?? '当前研究项目',
                      current: dataset.sample.analysable,
                      target: project?.target_sample_size ?? 0,
                    },
                  ]}
                  caption={
                    project?.target_sample_size
                      ? '进度按「可分析样本 / 目标样本量」计算；分类配额（各维度分别达标）的进度见数据收集模块的配额页。'
                      : '该项目尚未设定目标样本量，因此只能显示当前可分析样本数。'
                  }
                />
              </Card>
            </div>

            {/* Engine specification --------------------------------------- */}
            <Card>
              <CardHeader
                title="引擎默认分析规格"
                description="本问卷中实际存在的变量。分析页面默认使用这套规格，因此结果可直接对照。"
              />
              <dl className="grid gap-3 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">相关分析变量</dt>
                  <dd className="mt-1 text-ink-800">
                    {dataset.available.correlation_variables.length > 0
                      ? dataset.available.correlation_variables.join('、')
                      : '—（可用变量不足）'}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">回归因变量</dt>
                  <dd className="mt-1 text-ink-800">{dataset.available.regression_dependent ?? '—（变量缺失）'}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">回归自变量</dt>
                  <dd className="mt-1 text-ink-800">
                    {dataset.available.regression_predictors.length > 0
                      ? dataset.available.regression_predictors.join('、')
                      : '—（变量缺失）'}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">组间比较分组变量</dt>
                  <dd className="mt-1 text-ink-800">
                    {dataset.available.comparison_factor ?? '—（变量缺失）'}
                    {dataset.available.comparison_dependents.length > 0 &&
                      ` × ${dataset.available.comparison_dependents.join('、')}`}
                  </dd>
                </div>
              </dl>
            </Card>

            {/* Persisted bundle ------------------------------------------ */}
            <Card>
              <CardHeader
                title="已保存的分析结果"
                description="AI 解释、研究报告与洞察分析都读取这份已保存的结果，不会重新计算统计量。"
                actions={
                  <Button variant="secondary" loading={running} onClick={() => void runAll()}>
                    运行全部分析
                  </Button>
                }
              />
              {bundleReason ? (
                <UnavailableNotice reason={bundleReason} title="尚未保存分析结果" />
              ) : bundle && bundle.available ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-3 text-sm text-ink-700">
                    <Badge tone="success">已保存</Badge>
                    <span>生成时间 {formatDateTime(bundle.generated_at)}</span>
                    <span>引擎版本 {bundle.engine_version}</span>
                    <span>分析基础 {bundle.sample.analysable} 份</span>
                    <span>变量 {bundle.dataset_summary.variable_count} 个</span>
                  </div>
                  <dl className="grid gap-3 text-sm sm:grid-cols-3">
                    <div>
                      <dt className="text-xs uppercase tracking-wide text-ink-500">相关矩阵</dt>
                      <dd className="mt-1 text-ink-800">
                        {bundle.correlation ? `${bundle.correlation.variables.length} 个变量` : '未生成'}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs uppercase tracking-wide text-ink-500">回归模型</dt>
                      <dd className="mt-1 text-ink-800">
                        {bundle.regression
                          ? bundle.regression.auto_selection.model === 'ordinal_logit'
                            ? '有序 Logistic（含 OLS 对照）'
                            : 'OLS 线性回归'
                          : '未生成'}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs uppercase tracking-wide text-ink-500">组间比较</dt>
                      <dd className="mt-1 text-ink-800">{bundle.comparisons.length} 个因变量</dd>
                    </div>
                    <div>
                      <dt className="text-xs uppercase tracking-wide text-ink-500">假设检验</dt>
                      <dd className="mt-1 text-ink-800">
                        支持 {bundle.hypotheses.summary.supported} / 不支持 {bundle.hypotheses.summary.not_supported} /
                        证据不足 {bundle.hypotheses.summary.inconclusive} / 无法检验{' '}
                        {bundle.hypotheses.summary.untestable}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs uppercase tracking-wide text-ink-500">整体 KMO</dt>
                      <dd className="mt-1 text-ink-800">{formatStat(bundle.validity.overall_kmo.overall, 3)}</dd>
                    </div>
                    <div>
                      <dt className="text-xs uppercase tracking-wide text-ink-500">信度</dt>
                      <dd className="mt-1 text-ink-800">{bundle.reliability.scales.length} 个量表</dd>
                    </div>
                  </dl>

                  {bundle.caveats.length > 0 && (
                    <div className="rounded-md border border-amber-200 bg-amber-50 px-3.5 py-3">
                      <p className="text-xs font-semibold text-amber-900">结果解读必须同时说明的限制</p>
                      <ul className="mt-1 list-disc space-y-1 pl-4 text-xs leading-relaxed text-amber-900">
                        {bundle.caveats.map((caveat) => (
                          <li key={caveat}>{caveat}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ) : null}
            </Card>

            {/* Navigation ------------------------------------------------- */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {ANALYSIS_LINKS.map((item) => (
                <Link
                  key={item.to}
                  to={`${item.to}?project=${projectId}`}
                  className="ferp-card block p-4 transition-colors hover:border-brand-300 hover:bg-brand-50/40"
                >
                  <p className="text-sm font-semibold text-ink-900">{item.title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-ink-500">{item.description}</p>
                </Link>
              ))}
            </div>
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
