/**
 * Public (unauthenticated) routes — the respondent-facing API.
 *
 * Everything here is keyed by the questionnaire's `share_token`, which is
 * itself the public survey link, plus (once started) a per-respondent session
 * token. No endpoint exposes another respondent's data, and the researcher API
 * is never reachable from here.
 */

import { Router } from 'express';
import QRCode from 'qrcode';
import { PLATFORM_DEFAULT_CONSENT, PLATFORM_ETHICS_POINTS } from '@ferp/shared';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import {
  findQuestionnaireByShareToken,
  listQuestions,
} from '../services/questionnaire.service.js';
import { findProjectById } from '../services/project.service.js';
import {
  completeSession,
  getSessionState,
  saveAnswer,
  startSession,
  updateProgress,
  requireRespondentByToken,
} from '../services/collection.service.js';
import { scoreCompletedSubmission } from '../services/quality.service.js';
import { ApiError, asyncHandler } from '../util/errors.js';
import { clientKey, createRateLimiter } from '../util/rateLimit.js';

export interface PublicRouterContext {
  db: Db;
  config: Config;
}

export function createPublicRouter(ctx: PublicRouterContext): Router {
  const router = Router();

  /** Resolve a share token to its questionnaire, or throw 404. */
  function requireShared(shareToken: string) {
    const questionnaire = findQuestionnaireByShareToken(ctx.db, shareToken);
    if (!questionnaire) throw ApiError.notFound('问卷链接无效或已被撤销。');
    return questionnaire;
  }

  // A real respondent opens the survey once; this only blunts scripted floods.
  // The ceiling has to be generous, because legitimate respondents routinely
  // share one public IP — a school computer room, an office, a mobile carrier's
  // NAT — so a tight per-IP cap would reject real participants and look like a
  // broken survey. The limit only exists to stop scripted abuse, so it is set
  // where a whole class can still answer at once, and it is configurable for
  // deployments that want it tighter.
  const configuredLimit = Number(process.env.PUBLIC_SESSION_LIMIT ?? 600);
  const sessionLimit =
    Number.isInteger(configuredLimit) && configuredLimit > 0 ? configuredLimit : 600;

  const sessionLimiter = createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: sessionLimit,
    keyFn: (req) => `${clientKey(req)}::start-session`,
    message:
      '短时间内发起的作答会话过多，请稍后重试。若您与其他受访者共用同一网络（例如同一学校或办公楼），' +
      '可能是整体访问量较大，请稍后再试。',
  });

  /* ---------------------------------------------------------------- */
  /* QR code                                                           */
  /* ---------------------------------------------------------------- */

  router.get(
    '/survey/:shareToken/qrcode',
    asyncHandler(async (req, res) => {
      const shareToken = req.params['shareToken']!;
      const questionnaire = requireShared(shareToken);
      const surveyUrl = `${ctx.config.publicBaseUrl}/research/${questionnaire.share_token}`;
      const format = req.query['format'] === 'png' ? 'png' : 'svg';
      const size = Math.min(Math.max(Number(req.query['size']) || 320, 120), 1024);

      if (format === 'png') {
        const buffer = await QRCode.toBuffer(surveyUrl, {
          type: 'png',
          width: size,
          margin: 2,
          errorCorrectionLevel: 'M',
        });
        res.type('image/png');
        res.setHeader('cache-control', 'public, max-age=3600');
        res.send(buffer);
        return;
      }

      const svg = await QRCode.toString(surveyUrl, {
        type: 'svg',
        width: size,
        margin: 2,
        errorCorrectionLevel: 'M',
      });
      res.type('image/svg+xml');
      res.setHeader('cache-control', 'public, max-age=3600');
      res.send(svg);
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Survey landing metadata                                            */
  /* ---------------------------------------------------------------- */

  router.get(
    '/survey/:shareToken',
    asyncHandler((req, res) => {
      const questionnaire = requireShared(req.params['shareToken']!);

      if (questionnaire.status === 'closed') {
        res.json({
          data: {
            title: questionnaire.title,
            version: questionnaire.version,
            status: 'closed',
            accepting_responses: false,
            message: '本次调查已结束，感谢您的关注。',
          },
        });
        return;
      }

      const questionCount = Number(
        ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM questions WHERE questionnaire_id = ?', [
          questionnaire.id,
        ]) ?? 0,
      );

      res.json({
        data: {
          title: questionnaire.title,
          description: questionnaire.description,
          version: questionnaire.version,
          status: questionnaire.status,
          accepting_responses: questionnaire.status === 'published',
          question_count: questionCount,
          message: questionnaire.status === 'published' ? null : '该问卷尚未发布，暂时无法填写。',
        },
      });
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Instrument (consent screen + question definitions)                 */
  /* ---------------------------------------------------------------- */

  /**
   * The full instrument. The consent wording comes from the project settings,
   * and the questions are sent in one payload so the respondent client can run
   * the shared logic engine locally; the server re-validates every save.
   */
  router.get(
    '/survey/:shareToken/instrument',
    asyncHandler((req, res) => {
      const questionnaire = requireShared(req.params['shareToken']!);
      const project = findProjectById(ctx.db, questionnaire.project_id);
      const questions = listQuestions(ctx.db, questionnaire.id);
      const settings = project.settings;

      res.json({
        data: {
          questionnaire: {
            id: questionnaire.id,
            title: questionnaire.title,
            description: questionnaire.description,
            version: questionnaire.version,
            status: questionnaire.status,
          },
          project: {
            title: project.title,
            target_sample_size: project.target_sample_size,
          },
          // Consent is an ethics requirement: if the project never recorded a
          // statement, the platform default is shown rather than nothing.
          consent_text: settings?.consent_text?.trim() || PLATFORM_DEFAULT_CONSENT,
          consent_is_platform_default: !settings?.consent_text?.trim(),
          ethics_points: PLATFORM_ETHICS_POINTS,
          anonymous: settings?.anonymous ?? true,
          allow_partial: settings?.allow_partial ?? false,
          min_duration_seconds: settings?.min_duration_seconds ?? null,
          accepting_responses: questionnaire.status === 'published',
          question_count: questions.filter((q) => q.question_type !== 'page_break').length,
          questions,
        },
      });
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Session lifecycle                                                  */
  /* ---------------------------------------------------------------- */

  router.post(
    '/survey/:shareToken/sessions',
    sessionLimiter.middleware,
    asyncHandler((req, res) => {
      const questionnaire = requireShared(req.params['shareToken']!);
      const body = (req.body ?? {}) as Record<string, unknown>;

      // The channel can arrive either in the body (from the client) or in the
      // query string (?source=wechat on the shared link).
      const source =
        typeof body['source'] === 'string'
          ? body['source']
          : typeof req.query['source'] === 'string'
            ? req.query['source']
            : null;

      const session = startSession(ctx.db, {
        questionnaireId: questionnaire.id,
        projectId: questionnaire.project_id,
        source,
        userAgent: typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : null,
        clientAddress: req.ip ?? req.socket.remoteAddress ?? null,
        salt: ctx.config.jwtSecret,
      });

      res.status(201).json({
        data: {
          session_token: session.session_token,
          respondent: session.respondent,
        },
      });
    }),
  );

  /** Resume state: stored answers plus the current position. */
  router.get(
    '/sessions/:token',
    asyncHandler((req, res) => {
      const row = requireRespondentByToken(ctx.db, req.params['token']!);
      const state = getSessionState(ctx.db, row.id);
      res.json({
        data: {
          respondent: state.respondent,
          answers: state.answers,
          hidden_question_codes: state.hidden_question_codes,
          missing_required: state.missing_required,
        },
      });
    }),
  );

  /** Autosave one answer. */
  router.patch(
    '/sessions/:token/answers',
    asyncHandler((req, res) => {
      const row = requireRespondentByToken(ctx.db, req.params['token']!);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const questionCode = body['question_code'];

      if (typeof questionCode !== 'string' || questionCode.trim() === '') {
        throw ApiError.validation('缺少 question_code。');
      }
      if (!('value' in body)) {
        throw ApiError.validation('缺少 value。');
      }

      const result = saveAnswer(ctx.db, {
        respondentId: row.id,
        questionCode: questionCode.trim(),
        value: body['value'],
      });

      res.json({ data: result });
    }),
  );

  /** Record the current question without storing an answer. */
  router.patch(
    '/sessions/:token/progress',
    asyncHandler((req, res) => {
      const row = requireRespondentByToken(ctx.db, req.params['token']!);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const code = typeof body['question_code'] === 'string' ? body['question_code'] : null;
      res.json({ data: updateProgress(ctx.db, row.id, code) });
    }),
  );

  /** Submit the completed questionnaire. */
  router.post(
    '/sessions/:token/complete',
    asyncHandler((req, res) => {
      const row = requireRespondentByToken(ctx.db, req.params['token']!);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const result = completeSession(ctx.db, {
        respondentId: row.id,
        via: typeof body['via'] === 'string' ? body['via'] : 'survey',
      });

      // Score the submission. Deliberately best-effort: a bug in the quality
      // engine must never cost a respondent their submission, so a failure here
      // is logged and the submission still succeeds. The researcher can always
      // re-run the engine from the console.
      if (result.respondent.status === 'completed') {
        try {
          scoreCompletedSubmission(ctx.db, row.id);
        } catch (error) {
          console.error('[ferp] 质量评分失败（不影响提交）:', error);
        }
      }

      res.json({ data: result });
    }),
  );

  return router;
}
