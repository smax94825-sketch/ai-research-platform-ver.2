import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Badge, Button, Card, CardHeader, Field, Input } from '../components/ui';
import { api, apiBaseUrl, ApiClientError } from '../lib/api';
import { useAuth } from '../lib/auth';
import { formatDateTime } from '../lib/format';

export function SettingsPage(): ReactNode {
  const { researcher, logout } = useAuth();
  const [health, setHealth] = useState<{ status: string; env: string; database: string } | null>(null);
  const [healthError, setHealthError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const result = await api.health();
        if (!cancelled) setHealth(result);
      } catch (err) {
        if (!cancelled) {
          setHealthError(err instanceof ApiClientError ? err.message : '无法连接服务端。');
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-ink-900">Settings</h1>
        <p className="mt-1 text-sm text-ink-500">账号、服务连接与平台数据诚信原则。</p>
      </div>

      <Card>
        <CardHeader title="研究者账号" />
        <dl className="grid gap-3 sm:grid-cols-2">
          <div>
            <dt className="text-xs text-ink-500">姓名</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{researcher?.name ?? '—'}</dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">邮箱</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{researcher?.email ?? '—'}</dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">所属机构</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{researcher?.affiliation ?? '未填写'}</dd>
          </div>
          <div>
            <dt className="text-xs text-ink-500">注册时间</dt>
            <dd className="mt-0.5 text-sm text-ink-900">{formatDateTime(researcher?.created_at)}</dd>
          </div>
        </dl>
        <div className="mt-4 border-t border-ink-100 pt-4">
          <Button variant="danger" onClick={() => void logout()}>
            退出登录（令牌立即失效）
          </Button>
          <p className="mt-2 text-xs text-ink-500">
            退出会递增账号的令牌版本号，此前签发的所有 JWT 会立刻失效，而不必等待到期。
          </p>
        </div>
      </Card>

      <Card>
        <CardHeader title="服务连接" description="研究平台后端 API 地址，可在登录页通过 ?api= 参数覆盖。" />
        <Field label="API Base URL">
          <Input readOnly value={apiBaseUrl()} />
        </Field>
        <div className="mt-3 text-sm">
          {healthError ? (
            <Alert tone="danger" title="无法连接后端服务">
              {healthError}
            </Alert>
          ) : health ? (
            <div className="flex flex-wrap items-center gap-3">
              <Badge tone="success">服务正常</Badge>
              <span className="text-ink-600">环境：{health.env}</span>
              <span className="text-ink-600">数据库：{health.database}</span>
            </div>
          ) : (
            <p className="text-ink-500">正在检查服务状态…</p>
          )}
        </div>
      </Card>

      <Card>
        <CardHeader
          title="平台数据诚信原则"
          description="这些约束在代码层面强制执行，不是说明性条款。"
        />
        <ul className="space-y-2 text-sm text-ink-700">
          <li>· 所有统计数字都来自数据库中的真实作答；平台不生成、不预置任何模拟数据。</li>
          <li>· AI 模块只能解释统计引擎的输出，不能读取原始数据后自行"推测"结果。</li>
          <li>· 敏感题的"不愿回答"单独编码为缺失，绝不并入"从未"等实质性类别。</li>
          <li>· 系统不会自动删除样本，只会标记可疑数据，由研究者人工判断。</li>
          <li>· 问卷发布后即锁定；修改必须建立新版本，保证数据与题目版本严格对应。</li>
          <li>· 研究数据按研究者账号隔离，访问他人项目返回 404 而非 403，避免泄露存在性。</li>
          <li>· 数据质量评分只是提示复核的线索，不构成剔除依据；平台从不自动删除样本。</li>
          <li>· 敏感题拒答不属于低质量信号 —— 拒答是受访者的权利。</li>
        </ul>
      </Card>

      <Card>
        <CardHeader title="后续阶段" description="路线图中尚未实现的功能。" />
        <ul className="grid gap-2 text-sm text-ink-600 sm:grid-cols-2">
          <li>· PHASE 5：统计分析引擎（描述、信度、效度、相关、回归、组间比较、假设检验）</li>
          <li>· PHASE 6：可视化与图表</li>
          <li>· PHASE 7：DeepSeek AI 研究助手与证据追溯</li>
          <li>· PHASE 8：研究报告生成与 Excel / CSV / JSON / SPSS 导出</li>
          <li>· PHASE 9：Competition Mode 创业洞察</li>
        </ul>
        <p className="mt-3 text-xs text-ink-500">
          已完成：PHASE 1（项目初始化、数据库、登录、研究项目、Dashboard）、
          PHASE 2（问卷构建器、题型、逻辑、预览、发布、版本控制）、
          PHASE 3（受访者端填写、数据收集、来源追踪、样本管理）与
          PHASE 4（数据质量检测引擎、配额管理、动态收集建议）。
        </p>
      </Card>
    </div>
  );
}
