/**
 * Data quality and quota API tests (PHASE 4).
 *
 * The quality engine's guarantees are behavioural, so they are asserted
 * behaviourally: the same input must produce the same score, a flagged sample
 * must still exist with all of its answers, and legitimate refusal must not be
 * treated as a defect.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import {
  api,
  createPublishedQuestionnaire,
  createTemplatedProject,
  createTestContext,
  publishQuestionnaire,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

/** 22 Likert items — enough to trigger the 20-item long-string rule. */
function likertQuestions(count: number): Record<string, unknown>[] {
  const agree = [
    { value: '1', label: '非常不同意', score: 1 },
    { value: '2', label: '比较不同意', score: 2 },
    { value: '3', label: '一般', score: 3 },
    { value: '4', label: '比较同意', score: 4 },
    { value: '5', label: '非常同意', score: 5 },
  ];
  return Array.from({ length: count }, (_, index) => ({
    question_code: `L${index + 1}`,
    question_text: `量表题 ${index + 1}`,
    question_type: 'likert',
    required: true,
    variable_name: `LS${index + 1}`,
    options: { choices: agree, scaleMin: 1, scaleMax: 5 },
    scoring_rule: { type: 'mean', min: 1, max: 5 },
  }));
}

const SENSITIVE_QUESTIONS: Record<string, unknown>[] = [
  {
    question_code: 'S1',
    question_text: '过去12个月内，您是否曾采取过身体上的惩罚？',
    question_type: 'single',
    required: false,
    variable_name: 'PUNISH',
    options: {
      choices: [
        { value: '1', label: '从未' },
        { value: '2', label: '偶尔' },
        { value: '5', label: '不愿回答', sensitiveNonResponse: true },
      ],
    },
    scoring_rule: { type: 'ordinal', codes: { '1': 0, '2': 1, '5': null } },
  },
  {
    question_code: 'S2',
    question_text: '请评价您的整体感受。',
    question_type: 'likert',
    required: true,
    options: {
      choices: [
        { value: '1', label: '很差', score: 1 },
        { value: '3', label: '一般', score: 3 },
        { value: '5', label: '很好', score: 5 },
      ],
    },
    scoring_rule: { type: 'mean', min: 1, max: 5 },
  },
];

interface CollectedSample {
  respondentId: string;
  sessionToken: string;
  anonymousId: string;
}

/**
 * Collect one complete sample with a controlled duration.
 *
 * Duration is derived from `started_at`, so the test backdates that column to
 * simulate a fast or a normal completion without waiting.
 */
async function collectSample(
  fixture: { shareToken: string },
  answers: Record<string, unknown>,
  options: { source?: string; durationSeconds?: number } = {},
): Promise<CollectedSample> {
  const session = await startSession(ctx, fixture.shareToken, options.source ?? 'wechat');

  if (options.durationSeconds !== undefined) {
    const startedAt = new Date(Date.now() - options.durationSeconds * 1000).toISOString();
    ctx.db.run('UPDATE respondents SET started_at = ? WHERE id = ?', [startedAt, session.respondentId]);
  }

  for (const [code, value] of Object.entries(answers)) {
    const saved = await saveAnswer(ctx, session.token, code, value);
    assert.equal(saved.status, 200, `${code} 保存失败：${JSON.stringify(saved.error)}`);
  }

  const submitted = await submitSession(ctx, session.token);
  assert.equal(submitted.status, 200, `提交失败：${JSON.stringify(submitted.error)}`);

  return { respondentId: session.respondentId, sessionToken: session.token, anonymousId: session.anonymousId };
}

/* ================================================================== */
/* Rule catalogue                                                     */
/* ================================================================== */

describe('质量规则目录接口', () => {
  test('返回规则说明与扣分权重', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '规则目录');

    const response = await api<
      {
        code: string;
        label: string;
        description: string;
        interpretation: string;
        default_severity: string;
        score_impact: number;
      }[]
    >(ctx, 'GET', `/api/projects/${project.id}/quality/rules`, { token: researcher.token });

    assert.equal(response.status, 200);
    assert.ok(response.data.length >= 7);
    const speed = response.data.find((rule) => rule.code === 'SUSPICIOUS_SPEED');
    assert.ok(speed);
    assert.ok(speed.description.length > 10);
    assert.ok(speed.interpretation.length > 10, '规则必须附带解读说明');
    assert.ok(speed.score_impact > 0);
    assert.ok(speed.default_severity.length > 0);

    // The payload must use snake_case like every other endpoint, so a client
    // never has to know which route was written in which style.
    for (const rule of response.data) {
      assert.ok(!('scoreImpact' in rule), `规则 ${rule.code} 泄露了内部驼峰字段名`);
      assert.ok(!('defaultSeverity' in rule), `规则 ${rule.code} 泄露了内部驼峰字段名`);
    }
  });

  test('未登录无法读取规则目录', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '规则目录权限');
    const response = await api(ctx, 'GET', `/api/projects/${project.id}/quality/rules`);
    assert.equal(response.status, 401);
  });
});

/* ================================================================== */
/* Clean samples                                                      */
/* ================================================================== */

describe('正常样本不被误判', () => {
  test('作答变化、用时正常的样本得满分', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '正常样本',
    );

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) {
      answers[`L${index + 1}`] = String((index % 5) + 1);
    }

    const sample = await collectSample(fixture, answers, { durationSeconds: 900 });
    const quality = await api<{ score: number; severity: string; flags: unknown[] }>(
      ctx,
      'GET',
      `/api/respondents/${sample.respondentId}/quality`,
      { token: researcher.token },
    );

    assert.equal(quality.status, 200);
    assert.equal(quality.data.score, 100, `正常样本应得满分，实际 ${quality.data.score}`);
    assert.equal(quality.data.severity, 'clean');
    assert.deepEqual(quality.data.flags, []);
  });

  test('敏感题选择「不愿回答」不会降低质量评分', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      SENSITIVE_QUESTIONS,
      '敏感拒答不扣分',
    );

    const refused = await collectSample(
      fixture,
      { S1: '5', S2: '3' }, // 明确拒答
      { durationSeconds: 300 },
    );
    const answered = await collectSample(
      fixture,
      { S1: '1', S2: '3' }, // 实质作答
      { durationSeconds: 300 },
    );

    const refusedQuality = await api<{ score: number; flags: { rule_code: string }[] }>(
      ctx,
      'GET',
      `/api/respondents/${refused.respondentId}/quality`,
      { token: researcher.token },
    );
    const answeredQuality = await api<{ score: number }>(
      ctx,
      'GET',
      `/api/respondents/${answered.respondentId}/quality`,
      { token: researcher.token },
    );

    assert.equal(
      refusedQuality.data.score,
      answeredQuality.data.score,
      '拒答敏感题与实质作答应得到相同的质量评分',
    );
    assert.equal(refusedQuality.data.score, 100);
    assert.ok(
      !refusedQuality.data.flags.some((flag) => /SENSITIVE|REFUS/i.test(flag.rule_code)),
      '不得存在以拒答为依据的规则',
    );
  });
});

/* ================================================================== */
/* Speed                                                              */
/* ================================================================== */

describe('完成时间过短', () => {
  test('快速提交被标记并扣分', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '速度检测',
    );

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) {
      answers[`L${index + 1}`] = String((index % 5) + 1);
    }

    const sample = await collectSample(fixture, answers, { durationSeconds: 35 });
    const quality = await api<{
      score: number;
      severity: string;
      flags: { rule_code: string; detail: string; score_impact: number }[];
    }>(ctx, 'GET', `/api/respondents/${sample.respondentId}/quality`, { token: researcher.token });

    const speed = quality.data.flags.find((flag) => flag.rule_code === 'SUSPICIOUS_SPEED');
    assert.ok(speed, '应检出完成时间过短');
    assert.match(speed.detail, /低于最短时长/);
    assert.equal(speed.score_impact, 30);
    assert.ok(quality.data.score < 100);
    assert.equal(quality.data.severity, 'critical');
  });

  test('提交时会自动完成评分（无需手动触发）', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '自动评分',
    );

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) {
      answers[`L${index + 1}`] = String((index % 5) + 1);
    }
    const sample = await collectSample(fixture, answers, { durationSeconds: 30 });

    const row = ctx.db.get<{
      quality_score: number | null;
      quality_severity: string | null;
      quality_computed_at: string | null;
      quality_engine_version: string | null;
    }>(
      'SELECT quality_score, quality_severity, quality_computed_at, quality_engine_version FROM respondents WHERE id = ?',
      [sample.respondentId],
    );
    assert.ok(row?.quality_score !== null, '提交后应立即写入质量评分');
    assert.ok(row?.quality_computed_at, '应记录评分时间');
    assert.equal(row?.quality_engine_version, '1.0.0');
  });
});

/* ================================================================== */
/* Long string / straight line                                        */
/* ================================================================== */

describe('连续同选项与矩阵整列', () => {
  test('22 项全部相同触发长串标记', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '长串检测',
    );

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) answers[`L${index + 1}`] = '4';

    const sample = await collectSample(fixture, answers, { durationSeconds: 600 });
    const quality = await api<{ score: number; flags: { rule_code: string; evidence: Record<string, unknown> }[] }>(
      ctx,
      'GET',
      `/api/respondents/${sample.respondentId}/quality`,
      { token: researcher.token },
    );

    const longString = quality.data.flags.find((flag) => flag.rule_code === 'LONG_STRING');
    assert.ok(longString, '应检出连续同选项');
    assert.equal(longString.evidence['run_length'], 22);
    assert.equal(quality.data.score, 75, '长串规则扣 25 分');
  });

  test('矩阵题整列同一选项被单独标记', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      [
        {
          question_code: 'M1',
          question_text: '请评价以下各方面：',
          question_type: 'matrix',
          required: true,
          options: {
            matrix: {
              rows: Array.from({ length: 6 }, (_, i) => ({ value: String(i + 1), label: `方面${i + 1}` })),
              columns: [
                { value: '1', label: '很不满意', score: 1 },
                { value: '2', label: '一般', score: 2 },
                { value: '3', label: '很满意', score: 3 },
              ],
            },
          },
          scoring_rule: { type: 'mean', min: 1, max: 3 },
        },
      ],
      '矩阵整列检测',
    );

    const sample = await collectSample(
      fixture,
      { M1: { '1': '2', '2': '2', '3': '2', '4': '2', '5': '2', '6': '2' } },
      { durationSeconds: 300 },
    );

    const quality = await api<{ flags: { rule_code: string; detail: string }[] }>(
      ctx,
      'GET',
      `/api/respondents/${sample.respondentId}/quality`,
      { token: researcher.token },
    );
    const matrix = quality.data.flags.find((flag) => flag.rule_code === 'MATRIX_STRAIGHT_LINE');
    assert.ok(matrix, '应检出矩阵整列同一选项');
    assert.match(matrix.detail, /M1/);
  });
});

/* ================================================================== */
/* Duplicate detection                                                */
/* ================================================================== */

describe('疑似重复提交', () => {
  test('两份完全一致的作答都被标记', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '重复检测',
    );

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) answers[`L${index + 1}`] = String((index % 5) + 1);

    const first = await collectSample(fixture, answers, { durationSeconds: 600 });
    const second = await collectSample(fixture, { ...answers }, { durationSeconds: 620 });

    for (const sample of [first, second]) {
      const quality = await api<{ flags: { rule_code: string; detail: string }[] }>(
        ctx,
        'GET',
        `/api/respondents/${sample.respondentId}/quality`,
        { token: researcher.token },
      );
      const duplicate = quality.data.flags.find((flag) => flag.rule_code === 'DUPLICATE_SUBMISSION');
      assert.ok(duplicate, `样本 ${sample.anonymousId} 应被标记为疑似重复`);
      assert.match(duplicate.detail, /共 2 份样本/);
    }
  });

  test('作答不同的样本不会互相触发重复标记', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '非重复检测',
    );

    const base: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) base[`L${index + 1}`] = String((index % 5) + 1);

    const first = await collectSample(fixture, base, { durationSeconds: 600 });
    // L5 happens to be "5" in the base pattern, so flip it to a different code.
    const different = await collectSample(
      fixture,
      { ...base, L5: '1' },
      { durationSeconds: 620 },
    );

    for (const sample of [first, different]) {
      const quality = await api<{ flags: { rule_code: string }[] }>(
        ctx,
        'GET',
        `/api/respondents/${sample.respondentId}/quality`,
        { token: researcher.token },
      );
      assert.ok(
        !quality.data.flags.some((flag) => flag.rule_code === 'DUPLICATE_SUBMISSION'),
        `样本 ${sample.anonymousId} 不应被判为重复`,
      );
    }
  });

  test('重复标记不会删除或改动任何样本', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '重复不删除',
    );

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) answers[`L${index + 1}`] = String((index % 5) + 1);

    const first = await collectSample(fixture, answers, { durationSeconds: 600 });
    const second = await collectSample(fixture, { ...answers }, { durationSeconds: 600 });

    const before = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM respondents WHERE project_id = ?', [fixture.projectId]) ?? 0,
    );
    const answersBefore = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM responses WHERE respondent_id = ?', [first.respondentId]) ?? 0,
    );

    await api(ctx, 'POST', `/api/projects/${fixture.projectId}/quality/recompute`, {
      token: researcher.token,
    });

    const after = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM respondents WHERE project_id = ?', [fixture.projectId]) ?? 0,
    );
    const answersAfter = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM responses WHERE respondent_id = ?', [first.respondentId]) ?? 0,
    );

    assert.equal(after, before, '重算质量不得删除样本');
    assert.equal(answersAfter, answersBefore, '重算质量不得改动作答');
    assert.equal(before, 2);
    assert.ok(second.respondentId);
  });
});

/* ================================================================== */
/* Subjective vs objective                                            */
/* ================================================================== */

describe('主客观知识矛盾', () => {
  test('模板问卷中自评高但客观全错的样本被标记', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '主客观矛盾');
    const shareToken = await publishQuestionnaire(ctx, researcher.token, project.questionnaireId!);

    const instrument = await api<{
      questions: { question_code: string; question_type: string; required: boolean; options: { choices?: { value: string }[]; matrix?: { rows: { value: string }[]; columns: { value: string }[] } } }[];
    }>(ctx, 'GET', `/api/public/survey/${shareToken}/instrument`);

    const byCode = new Map(instrument.data.questions.map((q) => [q.question_code, q]));

    // Q9 = 5（非常了解），Q12–Q16 全部选「不清楚」→ 客观得分 0。
    // 用「不清楚」而不是随便挑一个非正确项，因为知识题的正确答案各不相同
    // （Q12/Q13/Q14/Q16 正确＝1，Q15 正确＝2），"非 1" 并不等于答错。
    const overrides: Record<string, unknown> = { Q9: '5' };
    for (const code of ['Q12', 'Q13', 'Q14', 'Q15', 'Q16']) {
      overrides[code] = '3';
    }

    const session = await startSession(ctx, shareToken);
    const startedAt = new Date(Date.now() - 600 * 1000).toISOString();
    ctx.db.run('UPDATE respondents SET started_at = ? WHERE id = ?', [startedAt, session.respondentId]);

    // 按真实路径作答，全部必答题先给"第一个选项"，再覆盖目标题。
    for (let guard = 0; guard < 200; guard += 1) {
      const state = await api<{ answers: Record<string, unknown>; hidden_question_codes: string[] }>(
        ctx,
        'GET',
        `/api/public/sessions/${session.token}`,
      );
      const hidden = new Set(state.data.hidden_question_codes);
      const next = instrument.data.questions.find(
        (question) =>
          question.question_type !== 'page_break' &&
          question.required &&
          !hidden.has(question.question_code) &&
          state.data.answers[question.question_code] === undefined,
      );
      if (!next) break;
      const target = byCode.get(next.question_code)!;
      let value: unknown;
      if (overrides[next.question_code] !== undefined) value = overrides[next.question_code];
      else if (next.question_type === 'matrix') {
        value = Object.fromEntries(
          target.options.matrix!.rows.map((row) => [row.value, target.options.matrix!.columns[0]!.value]),
        );
      } else if (next.question_type === 'textarea' || next.question_type === 'text') value = '测试';
      else if (next.question_type === 'number') value = 1;
      else if (next.question_type === 'multiple') value = [target.options.choices![0]!.value];
      else value = target.options.choices![0]!.value;

      const saved = await saveAnswer(ctx, session.token, next.question_code, value);
      assert.equal(saved.status, 200, `${next.question_code}: ${JSON.stringify(saved.error)}`);
    }

    const submitted = await submitSession(ctx, session.token);
    assert.equal(submitted.status, 200, JSON.stringify(submitted.error));

    const quality = await api<{ flags: { rule_code: string; severity: string; detail: string }[] }>(
      ctx,
      'GET',
      `/api/respondents/${session.respondentId}/quality`,
      { token: researcher.token },
    );

    const discrepancy = quality.data.flags.find(
      (flag) => flag.rule_code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
    );
    assert.ok(discrepancy, `应检出主客观矛盾，实际标记：${JSON.stringify(quality.data.flags.map((f) => f.rule_code))}`);
    assert.match(discrepancy.detail, /自评了解程度 5\/5/);
    assert.equal(discrepancy.severity, 'info', '该模式属于信息性提示，不应视为严重问题');
  });

  test('不含知识题的问卷如实报告该规则未启用', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '规则未启用');
    const shareToken = await publishQuestionnaire(ctx, researcher.token, project.questionnaireId!);
    const session = await startSession(ctx, shareToken);
    await saveAnswer(ctx, session.token, 'Q1', '2');
    await submitSession(ctx, session.token);

    const report = await api<{ inactive_rules: { rule_code: string; reason: string }[] }>(
      ctx,
      'GET',
      `/api/projects/${project.id}/quality`,
      { token: researcher.token },
    );
    // 模板问卷包含矩阵题与知识题，因此不应报告未启用；这里验证字段存在且为数组。
    assert.ok(Array.isArray(report.data.inactive_rules));
  });
});

/* ================================================================== */
/* Recompute and reporting                                            */
/* ================================================================== */

describe('项目质量报告与重算', () => {
  test('重算是幂等的：两次运行得到相同评分与相同标记数', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '重算幂等',
    );

    const good: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) good[`L${index + 1}`] = String((index % 5) + 1);
    const flat: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) flat[`L${index + 1}`] = '3';

    await collectSample(fixture, good, { durationSeconds: 900 });
    await collectSample(fixture, flat, { durationSeconds: 50 });

    const first = await api<{
      flags_written: number;
      respondents_scored: number;
      rule_counts: Record<string, number>;
      clean_respondents: number;
      flagged_respondents: number;
      computed_at: string;
    }>(ctx, 'POST', `/api/projects/${fixture.projectId}/quality/recompute`, {
      token: researcher.token,
    });
    const second = await api<typeof first.data>(
      ctx,
      'POST',
      `/api/projects/${fixture.projectId}/quality/recompute`,
      { token: researcher.token },
    );

    // `computed_at` is expected to advance; everything derived from the data
    // must be identical, otherwise the engine is not reproducible.
    const stable = (result: typeof first.data): Omit<typeof first.data, 'computed_at'> => {
      const { computed_at: _ignored, ...rest } = result;
      return rest;
    };
    assert.deepEqual(stable(second.data), stable(first.data), '重算结果必须可复现');
    assert.equal(first.data.respondents_scored, 2);
    assert.ok(first.data.flags_written > 0);

    const flagRows = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM quality_flags WHERE project_id = ?', [fixture.projectId]) ?? 0,
    );
    assert.equal(flagRows, first.data.flags_written, '重算不应累积历史标记');
  });

  test('项目报告给出分档、规则频次与待复核样本', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '质量报告',
    );

    const good: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) good[`L${index + 1}`] = String((index % 5) + 1);
    const flat: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) flat[`L${index + 1}`] = '4';

    const clean = await collectSample(fixture, good, { durationSeconds: 900 });
    const flagged = await collectSample(fixture, flat, { durationSeconds: 45 });

    const report = await api<{
      engine_version: string;
      thresholds_note: string;
      scored_respondents: number;
      mean_score: number | null;
      median_score: number | null;
      bands: { label: string; count: number }[];
      rule_frequency: { rule_code: string; count: number; label: string }[];
      flagged_samples: { anonymous_id: string; rule_codes: string[]; score: number }[];
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/quality`, { token: researcher.token });

    assert.equal(report.status, 200);
    assert.equal(report.data.scored_respondents, 2);
    assert.equal(report.data.engine_version, '1.0.0');
    assert.match(report.data.thresholds_note, /启发式指标/);
    assert.match(report.data.thresholds_note, /不构成剔除依据/);
    assert.equal(report.data.bands.reduce((sum, band) => sum + band.count, 0), 2);
    assert.ok(report.data.median_score !== null);

    const longString = report.data.rule_frequency.find((item) => item.rule_code === 'LONG_STRING');
    assert.ok(longString, '应统计长串规则命中次数');
    assert.ok(longString.label.length > 0, '规则频次应带中文名称');

    const flaggedIds = report.data.flagged_samples.map((item) => item.anonymous_id);
    assert.ok(flaggedIds.includes(flagged.anonymousId), '被标记样本应出现在待复核列表');
    assert.ok(!flaggedIds.includes(clean.anonymousId), '干净样本不应出现在待复核列表');
  });

  test('空项目的报告返回零值与 null，而不是报错', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '空质量报告');

    const report = await api<{
      scored_respondents: number;
      unscored_respondents: number;
      mean_score: number | null;
      median_score: number | null;
      flagged_samples: unknown[];
      rule_frequency: unknown[];
    }>(ctx, 'GET', `/api/projects/${project.id}/quality`, { token: researcher.token });

    assert.equal(report.status, 200);
    assert.equal(report.data.scored_respondents, 0);
    assert.equal(report.data.unscored_respondents, 0);
    assert.equal(report.data.mean_score, null);
    assert.equal(report.data.median_score, null);
    assert.deepEqual(report.data.flagged_samples, []);
    assert.deepEqual(report.data.rule_frequency, []);
  });

  test('研究者排除样本不会导致样本被删除，且排除记录出现在报告中', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '排除记录',
    );

    const flat: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) flat[`L${index + 1}`] = '4';
    const sample = await collectSample(fixture, flat, { durationSeconds: 45 });

    await api(ctx, 'POST', `/api/respondents/${sample.respondentId}/review`, {
      token: researcher.token,
      body: { status: 'excluded', note: '疑似机械作答，已核对' },
    });

    const report = await api<{ excluded_samples: { anonymous_id: string; note: string | null }[] }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/quality`,
      { token: researcher.token },
    );
    assert.equal(report.data.excluded_samples.length, 1);
    assert.equal(report.data.excluded_samples[0]?.anonymous_id, sample.anonymousId);
    assert.equal(report.data.excluded_samples[0]?.note, '疑似机械作答，已核对');

    const stillExists = ctx.db.get<{ id: string }>('SELECT id FROM respondents WHERE id = ?', [
      sample.respondentId,
    ]);
    assert.ok(stillExists, '平台不会因质量原因删除样本');
  });

  test('可按质量等级筛选样本', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(
      ctx,
      researcher.token,
      likertQuestions(22),
      '质量筛选',
    );

    const good: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) good[`L${index + 1}`] = String((index % 5) + 1);
    const bad: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) bad[`L${index + 1}`] = '4';

    await collectSample(fixture, good, { durationSeconds: 900 });
    const flagged = await collectSample(fixture, bad, { durationSeconds: 45 });

    const cleanOnly = await api<{ total: number; items: { anonymous_id: string }[] }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?quality_severity=clean`,
      { token: researcher.token },
    );
    assert.equal(cleanOnly.data.total, 1);

    const criticalOnly = await api<{ total: number; items: { anonymous_id: string; quality_score: number }[] }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?quality_severity=critical`,
      { token: researcher.token },
    );
    assert.equal(criticalOnly.data.total, 1);
    assert.equal(criticalOnly.data.items[0]?.anonymous_id, flagged.anonymousId);

    const flaggedOnly = await api<{ total: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?flagged_only=true`,
      { token: researcher.token },
    );
    assert.equal(flaggedOnly.data.total, 1);
  });

  test('拒绝非法的质量等级筛选值', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '非法筛选');
    const response = await api(
      ctx,
      'GET',
      `/api/projects/${project.id}/respondents?quality_severity=bogus`,
      { token: researcher.token },
    );
    assert.equal(response.status, 400);
  });
});

/* ================================================================== */
/* Isolation                                                          */
/* ================================================================== */

describe('质量数据隔离', () => {
  test('他人无法读取我的质量报告', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, owner.token, '隔离质量报告');

    const response = await api(ctx, 'GET', `/api/projects/${project.id}/quality`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });

  test('他人无法读取我的样本质量评分', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, owner.token, likertQuestions(22), '隔离评分');

    const answers: Record<string, unknown> = {};
    for (let index = 0; index < 22; index += 1) answers[`L${index + 1}`] = String((index % 5) + 1);
    const sample = await collectSample(fixture, answers, { durationSeconds: 900 });

    const response = await api(ctx, 'GET', `/api/respondents/${sample.respondentId}/quality`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });
});
