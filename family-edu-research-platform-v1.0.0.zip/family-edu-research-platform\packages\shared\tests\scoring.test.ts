/**
 * Scoring engine tests.
 *
 * The sensitive-item and knowledge-item behaviours are the two places where a
 * careless implementation would produce publishable-looking but wrong results,
 * so both are covered exhaustively.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  FAMILY_EDU_V4_TEMPLATE,
  MISSING,
  SENSITIVE_NONRESPONSE,
  applyAggregateRule,
  computeKnowledgeAccuracy,
  isNumericScore,
  isSensitiveRefusal,
  matrixRowScores,
  scoreQuestionAnswer,
  type AnswerMap,
  type Question,
  type QuestionSeed,
} from '../src/index.js';

const seeds: QuestionSeed[] = FAMILY_EDU_V4_TEMPLATE.questions;

function question(code: string): Question {
  const index = seeds.findIndex((s) => s.question_code === code);
  const seed = seeds[index];
  if (!seed) throw new Error(`Template question ${code} not found`);
  return {
    id: `seed-${seed.question_code}`,
    questionnaire_id: 'qn-v4',
    question_code: seed.question_code,
    question_text: seed.question_text,
    question_type: seed.question_type,
    options: seed.options,
    required: seed.required,
    dimension: seed.dimension,
    variable_name: seed.variable_name,
    sort_order: index + 1,
    section: seed.section,
    help_text: seed.help_text,
    logic: seed.logic,
    scoring_rule: seed.scoring_rule,
    created_at: '2025-01-01T00:00:00.000Z',
    updated_at: '2025-01-01T00:00:00.000Z',
  };
}

/** Numeric score or a descriptive sentinel string, for readable assertions. */
function scored(code: string, answer: unknown): number | 'MISSING' | 'SENSITIVE' {
  const value = scoreQuestionAnswer(question(code), answer as never);
  if (value === MISSING) return 'MISSING';
  if (value === SENSITIVE_NONRESPONSE) return 'SENSITIVE';
  return value;
}

/* ------------------------------------------------------------------ */

describe('李克特与单选题计分', () => {
  test('按选项顺序赋 1—5 分', () => {
    assert.equal(scored('Q6', '1'), 1);
    assert.equal(scored('Q6', '3'), 3);
    assert.equal(scored('Q6', '5'), 5);
  });

  test('Q9 主观自评使用同一 1—5 编码', () => {
    assert.equal(scored('Q9', '1'), 1);
    assert.equal(scored('Q9', '5'), 5);
  });

  test('未作答、空字符串与 null 均为缺失，绝不记为 0', () => {
    assert.equal(scored('Q6', undefined), 'MISSING');
    assert.equal(scored('Q6', null), 'MISSING');
    assert.equal(scored('Q6', ''), 'MISSING');
    assert.equal(scored('Q6', []), 'MISSING');
  });

  test('不存在的选项代码按缺失处理', () => {
    assert.equal(scored('Q6', '99'), 'MISSING');
  });

  test('Q44 的"不了解，无法判断"按缺失处理而非计分', () => {
    assert.equal(scored('Q44', '6'), 'MISSING');
    assert.equal(scored('Q44', '4'), 4);
  });

  test('反向计分按 min+max−原始分 反转', () => {
    const instrument: Question = {
      ...question('Q6'),
      scoring_rule: { type: 'reverse', min: 1, max: 5 },
    };
    assert.equal(scoreQuestionAnswer(instrument, '1'), 5);
    assert.equal(scoreQuestionAnswer(instrument, '5'), 1);
    assert.equal(scoreQuestionAnswer(instrument, '3'), 3);
  });
});

describe('多选题计数计分', () => {
  test('取选中选项数量', () => {
    assert.equal(scored('Q17', ['1', '4', '6']), 3);
    assert.equal(scored('Q17', ['2']), 1);
  });

  test('互斥选项不计入广度（Q42"以上都不知道"）', () => {
    assert.equal(scored('Q42', ['7']), 0);
    assert.equal(scored('Q42', ['1', '2']), 2);
    assert.equal(scored('Q42', ['1', '7']), 1);
  });

  test('空选择为缺失', () => {
    assert.equal(scored('Q17', []), 'MISSING');
  });
});

describe('矩阵题计分', () => {
  test('对有效行取均值', () => {
    const answer = { '1': '1', '2': '3', '3': '5' };
    const value = scoreQuestionAnswer(question('Q35'), answer);
    assert.equal(isNumericScore(value) ? value : null, 3);
  });

  test('缺失行被跳过，均值基于有效行', () => {
    const answer = { '1': '5', '2': '4' };
    const value = scoreQuestionAnswer(question('Q35'), answer);
    assert.equal(isNumericScore(value) ? value : null, 4.5);
  });

  test('全部缺失时为缺失', () => {
    assert.equal(scored('Q35', {}), 'MISSING');
    assert.equal(scored('Q35', { '1': '', '2': '' }), 'MISSING');
  });

  test('matrixRowScores 保留每行结果并标记缺失行', () => {
    const rows = matrixRowScores(question('Q35'), { '1': '4', '3': '2' });
    const values = Object.values(rows);
    assert.equal(values.filter((v) => v === null).length, 5);
    assert.equal(rows['1'], 4);
    assert.equal(rows['3'], 2);
  });

  test('行数与原问卷定义一致（Q35 有 7 行）', () => {
    const rows = matrixRowScores(question('Q35'), {});
    assert.equal(Object.keys(rows).length, 7);
  });
});

describe('敏感题 Q32 的拒答处理', () => {
  test('"不愿回答"返回敏感未作答，而不是 0', () => {
    assert.equal(scored('Q32', '5'), 'SENSITIVE');
  });

  test('"从未"确实计为 0，与拒答严格区分', () => {
    assert.equal(scored('Q32', '1'), 0);
  });

  test('"偶尔/有时/经常"分别计 1/2/3，保留严重程度序列', () => {
    assert.equal(scored('Q32', '2'), 1);
    assert.equal(scored('Q32', '3'), 2);
    assert.equal(scored('Q32', '4'), 3);
  });

  test('未作答与拒答是两种不同的状态', () => {
    assert.equal(scored('Q32', undefined), 'MISSING');
    assert.equal(scored('Q32', '5'), 'SENSITIVE');
  });

  test('isSensitiveRefusal 能识别拒答且不误判实质作答', () => {
    const q32 = question('Q32');
    assert.equal(isSensitiveRefusal(q32, '5'), true);
    assert.equal(isSensitiveRefusal(q32, '1'), false);
    assert.equal(isSensitiveRefusal(q32, undefined), false);
  });

  test('敏感拒答不会被聚合规则悄悄变成 0', () => {
    const result = applyAggregateRule({ type: 'mean', min: 0, max: 3 }, [SENSITIVE_NONRESPONSE]);
    assert.equal(result, SENSITIVE_NONRESPONSE);
  });
});

describe('知识测试题计分', () => {
  test('答对计 1 分', () => {
    assert.equal(scored('Q13', '1'), 1);
  });

  test('答错计 0 分', () => {
    assert.equal(scored('Q13', '2'), 0);
  });

  test('"不清楚"计 0 分', () => {
    assert.equal(scored('Q13', '3'), 0);
  });

  test('Q12 陈述为真，答"正确"得 1 分、答"错误"得 0 分', () => {
    assert.equal(scored('Q12', '1'), 1);
    assert.equal(scored('Q12', '2'), 0);
  });

  test('Q15 与 Q16 的正确答案为"错误"', () => {
    for (const code of ['Q15', 'Q16']) {
      assert.equal(scored(code, '2'), 1, `${code} 答"错误"应得 1 分`);
      assert.equal(scored(code, '1'), 0, `${code} 答"正确"应得 0 分`);
    }
  });
});

describe('LKA 客观法律知识指数', () => {
  const instrument = ['Q12', 'Q13', 'Q14', 'Q15', 'Q16'].map(question);

  test('全对得 5 分，理论满分 5', () => {
    const answers: AnswerMap = { Q12: '1', Q13: '1', Q14: '1', Q15: '2', Q16: '2' };
    const result = computeKnowledgeAccuracy(instrument, answers);
    assert.equal(result.total, 5);
    assert.equal(result.maxScore, 5);
    assert.equal(result.ratio, 1);
    assert.equal(result.answered, 5);
    assert.equal(result.missingCount, 0);
  });

  test('全部"不清楚"得 0 分，且被单独计数', () => {
    const answers: AnswerMap = { Q12: '3', Q13: '3', Q14: '3', Q15: '3', Q16: '3' };
    const result = computeKnowledgeAccuracy(instrument, answers);
    assert.equal(result.total, 0);
    assert.equal(result.unknownCount, 5);
    assert.equal(result.answered, 5);
  });

  test('部分缺失时按有效题项计分并如实报告缺失数', () => {
    const answers: AnswerMap = { Q12: '1', Q13: '1', Q15: '2' };
    const result = computeKnowledgeAccuracy(instrument, answers);
    assert.equal(result.total, 3);
    assert.equal(result.answered, 3);
    assert.equal(result.missingCount, 2);
    assert.equal(result.maxScore, 5, '满分应保持为完整量表的 5 分，便于跨样本比较');
  });

  test('逐题明细可用于报告题目难度', () => {
    const answers: AnswerMap = { Q12: '1', Q13: '2', Q14: '1', Q15: '2', Q16: '3' };
    const result = computeKnowledgeAccuracy(instrument, answers);
    assert.deepEqual(result.items, { Q12: 1, Q13: 0, Q14: 1, Q15: 1, Q16: 0 });
    assert.equal(result.total, 3);
    assert.equal(result.unknownCount, 1, 'Q16 选择"不清楚"应被单独计数');
  });

  test('ratio 在无题项时为 null，不产生 0 除', () => {
    const result = computeKnowledgeAccuracy([], {});
    assert.equal(result.ratio, null);
    assert.equal(result.maxScore, 0);
  });

  test('只统计知识测试题，不受其他题型干扰', () => {
    const mixed = [...instrument, question('Q10'), question('Q6')];
    const result = computeKnowledgeAccuracy(mixed, { Q10: '5', Q6: '5' });
    assert.equal(result.maxScore, 5);
    assert.equal(result.missingCount, 5);
  });
});

describe('主客观法律认知对照（LSK vs LKA）', () => {
  test('"自认为了解"但客观全错的情形可被如实检出', () => {
    const instrument = ['Q12', 'Q13', 'Q14', 'Q15', 'Q16'].map(question);
    const answers: AnswerMap = {
      Q10: '5', // LSK = 5，非常了解
      Q12: '2', Q13: '2', Q14: '2', Q15: '1', Q16: '1', // LKA = 0，五题全错
    };
    const lsk = scoreQuestionAnswer(question('Q10'), answers.Q10);
    const lka = computeKnowledgeAccuracy(instrument, answers);
    assert.equal(lsk, 5);
    assert.equal(lka.total, 0);
    assert.ok(isNumericScore(lsk) && lsk >= 4 && lka.total <= 1, '应能识别主观高估情形');
  });
});

describe('聚合规则', () => {
  test('mean 对有效项取平均', () => {
    assert.equal(applyAggregateRule({ type: 'mean' }, [1, 2, 3]), 2);
  });

  test('sum 对有效项求和', () => {
    assert.equal(applyAggregateRule({ type: 'sum' }, [1, 2, 3]), 6);
  });

  test('忽略缺失项', () => {
    assert.equal(applyAggregateRule({ type: 'mean' }, [MISSING, 4, MISSING]), 4);
  });

  test('无有效项时返回缺失', () => {
    assert.equal(applyAggregateRule({ type: 'mean' }, [MISSING, MISSING]), MISSING);
  });

  test('无规则时默认求和（与维度总分语义一致）', () => {
    assert.equal(applyAggregateRule(null, [1, 2, 3]), 6);
  });
});
