/**
 * Respondent-flow simulator.
 *
 * The visible question list and the navigation order are computed by the
 * SERVER's logic engine (`POST /preview`), not re-implemented here. That is the
 * point of the preview: a researcher can trust that the branch they see is the
 * branch a real respondent will get.
 */

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Question } from '@ferp/shared';
import { Alert, Badge, Button, Card, CardHeader } from '../ui';
import { api, ApiClientError, type PreviewResult } from '../../lib/api';
import { QuestionPreview, type AnswerValue } from '../QuestionPreview';

interface PreviewPanelProps {
  questionnaireId: string;
  questions: Question[];
  version: string;
}

export function PreviewPanel({ questionnaireId, questions, version }: PreviewPanelProps): ReactNode {
  const [answers, setAnswers] = useState<Record<string, AnswerValue>>({});
  const [preview, setPreview] = useState<PreviewResult | null>(null);
  const [cursor, setCursor] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const byCode = useMemo(() => new Map(questions.map((question) => [question.question_code, question])), [questions]);

  const refresh = useCallback(
    async (nextAnswers: Record<string, AnswerValue>) => {
      setLoading(true);
      setError(null);
      try {
        const result = await api.questionnaires.preview(questionnaireId, nextAnswers);
        setPreview(result);
        setCursor((current) => Math.min(current, Math.max(result.visible.length - 1, 0)));
      } catch (err) {
        setError(err instanceof ApiClientError ? err.message : '无法计算作答流程。');
      } finally {
        setLoading(false);
      }
    },
    [questionnaireId],
  );

  useEffect(() => {
    void refresh({});
  }, [refresh]);

  const visible = preview?.visible ?? [];
  const current = visible[cursor];
  const currentQuestion = current ? byCode.get(current.question_code) ?? null : null;
  const isLast = visible.length > 0 && cursor >= visible.length - 1;

  function setAnswer(code: string, value: AnswerValue): void {
    const next = { ...answers, [code]: value };
    setAnswers(next);
    void refresh(next);
  }

  function reset(): void {
    setAnswers({});
    setCursor(0);
    void refresh({});
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <Card>
        <CardHeader
          title="受访者视角预览"
          description={`问卷版本 ${version} · 作答流程由后端逻辑引擎实时计算。"下一题"按真实跳转逻辑推进。`}
        />

        {error && (
          <Alert tone="danger" title="预览失败">
            {error}
          </Alert>
        )}

        {!error && visible.length === 0 && !loading && (
          <Alert tone="warning" title="无法计算作答路径">
            请检查题目逻辑是否存在循环跳转或悬空目标。
          </Alert>
        )}

        {current && currentQuestion && (
          <div>
            <div className="mb-3">
              <div className="flex items-center justify-between text-xs text-ink-500">
                <span>
                  第 {cursor + 1}/{visible.length} 题
                </span>
                <span className="font-mono">{current.question_code}</span>
              </div>
              <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-ink-100">
                <div
                  className="h-full rounded-full bg-brand-500 transition-all"
                  style={{ width: `${((cursor + 1) / visible.length) * 100}%` }}
                />
              </div>
              {current.section && (
                <p className="mt-2 text-xs text-ink-500">{current.section}</p>
              )}
            </div>

            <QuestionPreview
              question={currentQuestion}
              value={answers[currentQuestion.question_code] ?? null}
              onChange={(value) => setAnswer(currentQuestion.question_code, value)}
            />

            <div className="mt-4 flex items-center justify-between">
              <Button disabled={cursor === 0} onClick={() => setCursor((value) => Math.max(0, value - 1))}>
                上一题
              </Button>
              <div className="flex gap-2">
                <Button onClick={reset}>重置作答</Button>
                {isLast ? (
                  <Button variant="primary" disabled>
                    已是最后一题
                  </Button>
                ) : (
                  <Button
                    variant="primary"
                    onClick={() => setCursor((value) => Math.min(visible.length - 1, value + 1))}
                  >
                    下一题
                  </Button>
                )}
              </div>
            </div>

            {current.required && (
              <p className="mt-3 text-xs text-ink-500">本题为必答题（由题目设置或逻辑规则动态决定）。</p>
            )}
          </div>
        )}
      </Card>

      <div className="space-y-4">
        <Card>
          <CardHeader title="流程摘要" />
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-ink-500">问卷总题数</dt>
              <dd className="tabular-nums text-ink-900">{preview?.total_questions ?? '—'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-500">当前可见题数</dt>
              <dd className="tabular-nums text-ink-900">{preview?.visible_count ?? '—'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-500">默认路径长度</dt>
              <dd className="tabular-nums text-ink-900">{preview?.answered_count ?? '—'}</dd>
            </div>
            {preview && preview.total_questions !== preview.visible_count && (
              <div className="flex justify-between">
                <dt className="text-ink-500">因逻辑跳过的题数</dt>
                <dd className="tabular-nums text-amber-700">
                  {preview.total_questions - preview.visible_count}
                </dd>
              </div>
            )}
          </dl>
          <p className="mt-3 text-xs text-ink-500">
            尝试回答 Q39「从未使用」可以看到 Q40 被自动跳过；回答 Q10「从未听说」可以看到 Q11 被隐藏。
          </p>
        </Card>

        <Card>
          <CardHeader title="当前作答路径" description="按后端逻辑引擎解析出的题号顺序。" />
          {!preview || preview.answered_path.length === 0 ? (
            <p className="text-sm text-ink-400">暂无路径。</p>
          ) : (
            <div className="flex flex-wrap gap-1">
              {preview.answered_path.map((code, index) => {
                const isCurrent = visible[cursor]?.question_code === code;
                const answered = answers[code] !== undefined && answers[code] !== null;
                return (
                  <span
                    key={`${code}-${index}`}
                    className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${
                      isCurrent
                        ? 'bg-brand-600 text-white'
                        : answered
                          ? 'bg-emerald-50 text-emerald-700'
                          : 'bg-ink-100 text-ink-600'
                    }`}
                  >
                    {code}
                  </span>
                );
              })}
            </div>
          )}
        </Card>

        {preview && preview.logic_issues.length > 0 && (
          <Card>
            <CardHeader title="逻辑提示" />
            <ul className="space-y-2 text-xs">
              {preview.logic_issues.map((issue, index) => (
                <li key={index} className="flex gap-2">
                  <Badge tone={issue.severity === 'error' ? 'danger' : 'warning'}>
                    {issue.severity === 'error' ? '错误' : '提示'}
                  </Badge>
                  <span className="text-ink-700">
                    <span className="font-mono">{issue.questionCode}</span> {issue.message}
                  </span>
                </li>
              ))}
            </ul>
          </Card>
        )}
      </div>
    </div>
  );
}
