/**
 * Research dashboard aggregation.
 *
 * Everything returned here is computed from stored responses. There is no
 * placeholder or synthesised figure anywhere in this module: when a project has
 * collected nothing, the metrics are genuinely zero and `collection_started` is
 * false so the console can say so instead of rendering meaningless charts.
 *
 * Missing answers and sensitive refusals are reported as their own counts and
 * are excluded from percentages, means and standard deviations.
 */

import {
  SCALE_BASED_TYPES,
  findOption,
  isSensitiveRefusal,
  scoreQuestionAnswer,
  type Question,
  type QuestionOption,
  type ResearchProject,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { parseJson } from './mappers.js';
import { getCurrentQuestionnaire, listQuestions } from './questionnaire.service.js';
import { listProjects } from './project.service.js';

/**
 * Quality score at or above which a completed response counts as "valid".
 * PHASE 4's quality engine produces the score; this threshold only classifies
 * it for reporting, and it never deletes anything.
 */
export const VALID_QUALITY_THRESHOLD = 60;

/* ------------------------------------------------------------------ */
/* Types                                                              */
/* ------------------------------------------------------------------ */

export interface DistributionItem {
  value: string;
  label: string;
  count: number;
  /** Percentage of respondents who answered the item (excludes missing). */
  percent: number;
}

export interface Distribution {
  variable_name: string;
  question_code: string;
  label: string;
  question_type: string;
  kind: 'categorical' | 'scale' | 'multi' | 'matrix_row_means';
  /**
   * Respondents in the analysis base for this item — i.e. completed
   * respondents. `n + missing + sensitive_nonresponse === base_n` always holds.
   */
  base_n: number;
  /** Respondents contributing a usable answer. */
  n: number;
  counts: DistributionItem[];
  mean: number | null;
  sd: number | null;
  median: number | null;
  /** Answered nothing (including respondents with no row for this question). */
  missing: number;
  /** Explicit sensitive refusal (e.g. "不愿回答") — never folded into a category. */
  sensitive_nonresponse: number;
}

export interface QuotaProgress {
  dimension: string;
  category: string;
  target_n: number;
  current_n: number;
  percent: number;
  met: boolean;
}

export interface DashboardFinding {
  /** Level 1 (FACT) only — descriptive statements traceable to a question. */
  level: 'FACT';
  text: string;
  source: { question_code: string; n: number };
}

export interface DashboardOverview {
  generated_at: string;
  scope: 'all_projects' | 'single_project';
  project: {
    id: string;
    title: string;
    status: string;
    target_sample_size: number | null;
  } | null;
  projects: {
    total: number;
    collecting: number;
    draft: number;
    analyzing: number;
    completed: number;
  };
  collection_started: boolean;
  sample: {
    total: number;
    completed: number;
    in_progress: number;
    abandoned: number;
    valid: number;
    invalid: number;
    unscored: number;
    valid_rate: number | null;
    completion_rate: number | null;
    average_duration_seconds: number | null;
    today_new: number;
  };
  questionnaire: {
    id: string;
    title: string;
    version: string;
    status: string;
    question_count: number;
    share_token: string | null;
  } | null;
  distributions: Distribution[];
  quota_progress: QuotaProgress[];
  quota_alerts: string[];
  findings: DashboardFinding[];
}

/* ------------------------------------------------------------------ */
/* Statistics helpers                                                 */
/* ------------------------------------------------------------------ */

function mean(values: number[]): number | null {
  if (values.length === 0) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function standardDeviation(values: number[]): number | null {
  if (values.length < 2) return null;
  const m = mean(values);
  if (m === null) return null;
  const variance = values.reduce((acc, v) => acc + (v - m) ** 2, 0) / (values.length - 1);
  return Math.sqrt(variance);
}

function median(values: number[]): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[mid]!;
  return ((sorted[mid - 1]! + sorted[mid]!) / 2);
}

function round(value: number | null, digits = 4): number | null {
  if (value === null || !Number.isFinite(value)) return null;
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

/* ------------------------------------------------------------------ */
/* Response loading                                                   */
/* ------------------------------------------------------------------ */

interface ResponseRow {
  respondent_id: string;
  question_code: string;
  answer: string | null;
}

interface RespondentRow {
  id: string;
  status: string;
  duration_seconds: number | null;
  completed_at: string | null;
  quality_score: number | null;
  created_at: string;
}

/** Safety valve so an enormous project cannot exhaust memory in one request. */
const MAX_RESPONSES_SCANNED = 50_000;

function loadRespondents(db: Db, questionnaireId: string): RespondentRow[] {
  return db.all<RespondentRow>(
    `SELECT id, status, duration_seconds, completed_at, quality_score, created_at
       FROM respondents WHERE questionnaire_id = ? ORDER BY created_at DESC LIMIT ?`,
    [questionnaireId, MAX_RESPONSES_SCANNED],
  );
}

function loadResponses(db: Db, questionnaireId: string): ResponseRow[] {
  return db.all<ResponseRow>(
    `SELECT r.respondent_id, r.question_code, r.answer
       FROM responses r
       JOIN respondents d ON d.id = r.respondent_id
      WHERE d.questionnaire_id = ?
      LIMIT ?`,
    [questionnaireId, MAX_RESPONSES_SCANNED * 60],
  );
}

/* ------------------------------------------------------------------ */
/* Distribution builders                                              */
/* ------------------------------------------------------------------ */

function labelFor(choices: QuestionOption[] | undefined, value: string): string {
  return findOption(choices, value)?.label ?? value;
}

function buildCategoricalDistribution(
  question: Question,
  perRespondent: Map<string, unknown>,
  baseN: number,
): Distribution {
  const choices = question.options.choices ?? [];
  const counts = new Map<string, number>();
  let sensitive = 0;
  let missing = 0;
  let answered = 0;

  for (const answer of perRespondent.values()) {
    if (answer === undefined || answer === null || String(answer).trim() === '') {
      missing += 1;
      continue;
    }
    if (isSensitiveRefusal(question, answer as never)) {
      sensitive += 1;
      continue;
    }
    const value = String(answer);
    counts.set(value, (counts.get(value) ?? 0) + 1);
    answered += 1;
  }

  const items: DistributionItem[] = choices.map((choice) => {
    const count = counts.get(String(choice.value)) ?? 0;
    return {
      value: String(choice.value),
      label: choice.label,
      count,
      percent: answered > 0 ? round((count / answered) * 100, 2)! : 0,
    };
  });

  return {
    variable_name: question.variable_name ?? question.question_code,
    question_code: question.question_code,
    label: question.question_text,
    question_type: question.question_type,
    kind: 'categorical',
    base_n: baseN,
    n: answered,
    counts: items,
    // A nominal variable has no meaningful central tendency: the mean of
    // arbitrary category codes (父亲=1, 母亲=2, …) would be nonsense, so it is
    // deliberately reported as null rather than as a number someone might quote.
    mean: null,
    sd: null,
    median: null,
    missing,
    sensitive_nonresponse: sensitive,
  };
}

function buildMultiDistribution(
  question: Question,
  perRespondent: Map<string, unknown>,
  baseN: number,
): Distribution {
  const choices = question.options.choices ?? [];
  const counts = new Map<string, number>();
  let sensitive = 0;
  let missing = 0;
  let answered = 0;

  for (const answer of perRespondent.values()) {
    const selected = Array.isArray(answer)
      ? answer.map(String)
      : answer === undefined || answer === null || String(answer).trim() === ''
        ? []
        : [String(answer)];
    if (selected.length === 0) {
      missing += 1;
      continue;
    }
    if (isSensitiveRefusal(question, selected as never)) {
      sensitive += 1;
      continue;
    }
    answered += 1;
    for (const value of selected) counts.set(value, (counts.get(value) ?? 0) + 1);
  }

  const items: DistributionItem[] = choices.map((choice) => {
    const count = counts.get(String(choice.value)) ?? 0;
    return {
      value: String(choice.value),
      label: choice.label,
      count,
      // Share of respondents who selected this option (multi-select convention).
      percent: answered > 0 ? round((count / answered) * 100, 2)! : 0,
    };
  });

  return {
    variable_name: question.variable_name ?? question.question_code,
    question_code: question.question_code,
    label: question.question_text,
    question_type: question.question_type,
    kind: 'multi',
    base_n: baseN,
    n: answered,
    counts: items,
    mean: null,
    sd: null,
    median: null,
    missing,
    sensitive_nonresponse: sensitive,
  };
}

function buildLikertDistribution(
  question: Question,
  perRespondent: Map<string, unknown>,
  baseN: number,
): Distribution {
  const choices = question.options.choices ?? [];
  const counts = new Map<string, number>();
  const scores: number[] = [];
  let sensitive = 0;
  let missing = 0;

  for (const answer of perRespondent.values()) {
    if (answer === undefined || answer === null || String(answer).trim() === '') {
      missing += 1;
      continue;
    }
    if (isSensitiveRefusal(question, answer as never)) {
      sensitive += 1;
      continue;
    }
    const value = String(answer);
    counts.set(value, (counts.get(value) ?? 0) + 1);
    const score = scoreQuestionAnswer(question, value);
    if (typeof score === 'number' && Number.isFinite(score)) scores.push(score);
  }

  const answered = scores.length;
  const items: DistributionItem[] = choices.map((choice) => {
    const count = counts.get(String(choice.value)) ?? 0;
    return {
      value: String(choice.value),
      label: choice.label,
      count,
      percent: answered > 0 ? round((count / answered) * 100, 2)! : 0,
    };
  });

  return {
    variable_name: question.variable_name ?? question.question_code,
    question_code: question.question_code,
    label: question.question_text,
    question_type: question.question_type,
    kind: 'scale',
    base_n: baseN,
    n: answered,
    counts: items,
    mean: round(mean(scores)),
    sd: round(standardDeviation(scores)),
    median: median(scores),
    missing,
    sensitive_nonresponse: sensitive,
  };
}

/** Per-row means for a matrix question (e.g. which family-education difficulty is worst). */
function buildMatrixDistribution(
  question: Question,
  perRespondent: Map<string, unknown>,
  baseN: number,
): Distribution {
  const rows = question.options.matrix?.rows ?? [];
  const columns = question.options.matrix?.columns ?? [];
  const perRow = new Map<string, number[]>();
  const perRowMissing = new Map<string, number>();
  let sensitive = 0;
  let missing = 0;
  let answered = 0;

  for (const answer of perRespondent.values()) {
    if (!answer || typeof answer !== 'object' || Array.isArray(answer)) {
      missing += 1;
      continue;
    }
    const map = answer as Record<string, string>;
    const keys = Object.keys(map).filter((k) => String(map[k] ?? '').trim() !== '');
    if (keys.length === 0) {
      missing += 1;
      continue;
    }
    answered += 1;
    for (const row of rows) {
      const raw = map[row.value];
      if (raw === undefined || raw === null || String(raw).trim() === '') {
        perRowMissing.set(row.value, (perRowMissing.get(row.value) ?? 0) + 1);
        continue;
      }
      const option = findOption(columns, raw);
      if (option?.sensitiveNonResponse) {
        sensitive += 1;
        continue;
      }
      const index = columns.findIndex((c) => String(c.value) === String(raw));
      if (index === -1) continue;
      const score = option?.score ?? index + 1;
      const list = perRow.get(row.value) ?? [];
      list.push(score);
      perRow.set(row.value, list);
    }
  }

  const items: DistributionItem[] = rows.map((row) => {
    const values = perRow.get(row.value) ?? [];
    const m = mean(values);
    return {
      value: row.value,
      label: row.label,
      count: values.length,
      percent: round(m, 2) ?? 0,
    };
  });

  return {
    variable_name: question.variable_name ?? question.question_code,
    question_code: question.question_code,
    label: question.question_text,
    question_type: question.question_type,
    kind: 'matrix_row_means',
    base_n: baseN,
    n: answered,
    counts: items,
    mean: null,
    sd: null,
    median: null,
    missing,
    sensitive_nonresponse: sensitive,
  };
}

/**
 * Build a distribution for one question.
 *
 * `baseRespondentIds` is the analysis base (completed respondents). It is used
 * to pre-seed the answer map so that a respondent with *no row at all* for this
 * question is counted as missing — otherwise item non-response would be
 * systematically understated, which is exactly the kind of quiet distortion a
 * research platform must not introduce.
 */
function buildDistribution(
  question: Question,
  responses: ResponseRow[],
  baseRespondentIds: ReadonlySet<string>,
): Distribution {
  const perRespondent = new Map<string, unknown>();
  for (const id of baseRespondentIds) perRespondent.set(id, undefined);
  for (const row of responses) {
    if (row.question_code !== question.question_code) continue;
    if (!baseRespondentIds.has(row.respondent_id)) continue;
    perRespondent.set(row.respondent_id, parseJson<unknown>(row.answer, null));
  }

  const baseN = baseRespondentIds.size;

  if (question.question_type === 'matrix') {
    return buildMatrixDistribution(question, perRespondent, baseN);
  }
  if (question.question_type === 'multiple') {
    return buildMultiDistribution(question, perRespondent, baseN);
  }

  const rule = question.scoring_rule;
  // Honour the declared measurement level: a nominal item gets frequencies
  // only, an ordinal/scale item additionally gets central tendency.
  if (rule && rule.type === 'categorical') {
    return buildCategoricalDistribution(question, perRespondent, baseN);
  }
  if (rule && rule.type === 'ordinal') {
    return buildLikertDistribution(question, perRespondent, baseN);
  }
  if (SCALE_BASED_TYPES.includes(question.question_type)) {
    return buildLikertDistribution(question, perRespondent, baseN);
  }
  return buildCategoricalDistribution(question, perRespondent, baseN);
}

/* ------------------------------------------------------------------ */
/* Overview                                                           */
/* ------------------------------------------------------------------ */

/**
 * Variables the dashboard always tries to surface (spec §6).
 *
 * FPB_PUNISH is the sensitive item: it is shown on purpose so the refusal rate
 * is visible to the researcher rather than hidden inside a missing count.
 */
const DASHBOARD_VARIABLES = ['AREA', 'STAGE', 'ISCB', 'FED', 'UI', 'WTP', 'FPB_PUNISH'];

export interface DashboardOptions {
  /** Restrict to one project (ownership already checked by the caller). */
  project?: ResearchProject;
}

export function getDashboardOverview(
  db: Db,
  researcherId: string,
  options: DashboardOptions = {},
): DashboardOverview {
  const generatedAt = new Date().toISOString();
  const { items: projects } = listProjects(db, researcherId, { limit: 200 });

  const projectCounts = {
    total: projects.length,
    collecting: projects.filter((p) => p.status === 'collecting').length,
    draft: projects.filter((p) => p.status === 'draft').length,
    analyzing: projects.filter((p) => p.status === 'analyzing').length,
    completed: projects.filter((p) => p.status === 'completed').length,
  };

  const emptyOverview: DashboardOverview = {
    generated_at: generatedAt,
    scope: options.project ? 'single_project' : 'all_projects',
    project: options.project
      ? {
          id: options.project.id,
          title: options.project.title,
          status: options.project.status,
          target_sample_size: options.project.target_sample_size,
        }
      : null,
    projects: projectCounts,
    collection_started: false,
    sample: {
      total: 0,
      completed: 0,
      in_progress: 0,
      abandoned: 0,
      valid: 0,
      invalid: 0,
      unscored: 0,
      valid_rate: null,
      completion_rate: null,
      average_duration_seconds: null,
      today_new: 0,
    },
    questionnaire: null,
    distributions: [],
    quota_progress: [],
    quota_alerts: [],
    findings: [],
  };

  if (!options.project) return emptyOverview;

  const questionnaire = getCurrentQuestionnaire(db, options.project.id);
  if (!questionnaire) return emptyOverview;

  const questions = listQuestions(db, questionnaire.id);
  const respondents = loadRespondents(db, questionnaire.id);
  const responses = loadResponses(db, questionnaire.id);

  const completed = respondents.filter((r) => r.status === 'completed');
  const scored = completed.filter((r) => r.quality_score !== null);
  const valid = scored.filter((r) => (r.quality_score ?? 0) >= VALID_QUALITY_THRESHOLD);
  const invalid = scored.filter((r) => (r.quality_score ?? 0) < VALID_QUALITY_THRESHOLD);
  const unscored = completed.length - scored.length;

  const durations = completed
    .map((r) => r.duration_seconds)
    .filter((d): d is number => typeof d === 'number' && Number.isFinite(d) && d > 0);

  const todayPrefix = generatedAt.slice(0, 10);
  const todayNew = respondents.filter((r) => (r.completed_at ?? r.created_at).startsWith(todayPrefix)).length;

  const sample: DashboardOverview['sample'] = {
    total: respondents.length,
    completed: completed.length,
    in_progress: respondents.filter((r) => r.status === 'in_progress').length,
    abandoned: respondents.filter((r) => r.status === 'abandoned').length,
    valid: valid.length,
    invalid: invalid.length,
    unscored,
    valid_rate: scored.length > 0 ? round((valid.length / scored.length) * 100, 2) : null,
    completion_rate:
      respondents.length > 0 ? round((completed.length / respondents.length) * 100, 2) : null,
    average_duration_seconds: durations.length > 0 ? Math.round(mean(durations)!) : null,
    today_new: todayNew,
  };

  const distributions: Distribution[] = [];
  // The analysis base is completed respondents: partial sessions would inflate
  // item non-response with incompleteness rather than real non-response.
  const baseRespondentIds = new Set(completed.map((r) => r.id));
  for (const variable of DASHBOARD_VARIABLES) {
    const question = questions.find((q) => q.variable_name === variable);
    if (!question) continue;
    distributions.push(buildDistribution(question, responses, baseRespondentIds));
  }

  /* Quota progress -------------------------------------------------- */
  const quotaConfig = options.project.quota_config;
  const quotaProgress: QuotaProgress[] = [];
  const quotaAlerts: string[] = [];

  if (quotaConfig?.enabled) {
    const stageQuestion = questions.find((q) => q.variable_name === 'STAGE');
    const stageDistribution = stageQuestion
      ? distributions.find((d) => d.question_code === stageQuestion.question_code)
      : undefined;

    for (const category of quotaConfig.categories) {
      const entry = stageDistribution?.counts.find((c) => c.label === category.category);
      const current = entry?.count ?? 0;
      const percent = category.target_n > 0 ? round((current / category.target_n) * 100, 2)! : 0;
      quotaProgress.push({
        dimension: category.dimension,
        category: category.category,
        target_n: category.target_n,
        current_n: current,
        percent,
        met: current >= category.target_n,
      });
    }

    const shortfalls = quotaProgress.filter((q) => !q.met);
    if (shortfalls.length > 0 && shortfalls.length < quotaProgress.length) {
      quotaAlerts.push(
        `${shortfalls.map((q) => q.category).join('、')}样本不足，建议继续收集。` +
          (quotaConfig.preserve_structure ? '（已开启"保持目标样本结构"）' : ''),
      );
    } else if (shortfalls.length === quotaProgress.length && quotaProgress.length > 0) {
      quotaAlerts.push('各类样本均未达到目标配额，建议按计划继续收集。');
    }
  }

  /* Level-1 findings ------------------------------------------------- */
  const findings: DashboardFinding[] = [];
  if (sample.total === 0) {
    findings.push({
      level: 'FACT',
      text: '该项目尚未收集到任何样本，以下指标将在收到第一份问卷后自动更新。',
      source: { question_code: questionnaire.title, n: 0 },
    });
  } else {
    if (sample.valid_rate !== null) {
      findings.push({
        level: 'FACT',
        text: `已完成且通过质量评分阈值的样本占已完成样本的 ${sample.valid_rate}%（有效 ${sample.valid} / 已完成 ${sample.completed}）。`,
        source: { question_code: 'data_quality', n: sample.completed },
      });
    }
    if (sample.average_duration_seconds !== null) {
      const minutes = Math.floor(sample.average_duration_seconds / 60);
      const seconds = sample.average_duration_seconds % 60;
      findings.push({
        level: 'FACT',
        text: `已完成样本的平均作答时长为 ${minutes} 分 ${seconds} 秒。`,
        source: { question_code: 'respondent_duration', n: durations.length },
      });
    }
    for (const distribution of distributions) {
      if (distribution.n === 0) continue;
      if (distribution.kind === 'scale' && distribution.mean !== null) {
        findings.push({
          level: 'FACT',
          text: `${distribution.variable_name} 的均值为 ${distribution.mean}（SD=${distribution.sd ?? 'NA'}，n=${distribution.n}）。`,
          source: { question_code: distribution.question_code, n: distribution.n },
        });
      } else if (distribution.kind === 'categorical') {
        const top = [...distribution.counts].sort((a, b) => b.count - a.count)[0];
        if (top && top.count > 0) {
          findings.push({
            level: 'FACT',
            text: `${distribution.variable_name} 中占比最高的是「${top.label}」，占 ${top.percent}%（n=${distribution.n}）。`,
            source: { question_code: distribution.question_code, n: distribution.n },
          });
        }
      }
    }
  }

  return {
    generated_at: generatedAt,
    scope: 'single_project',
    project: {
      id: options.project.id,
      title: options.project.title,
      status: options.project.status,
      target_sample_size: options.project.target_sample_size,
    },
    projects: projectCounts,
    collection_started: sample.total > 0,
    sample,
    questionnaire: {
      id: questionnaire.id,
      title: questionnaire.title,
      version: questionnaire.version,
      status: questionnaire.status,
      question_count: questions.length,
      share_token: questionnaire.share_token,
    },
    distributions,
    quota_progress: quotaProgress,
    quota_alerts: quotaAlerts,
    findings,
  };
}
