/**
 * Download headers for generated files.
 *
 * Exports are named after the research project, and those names are Chinese.
 * A bare `filename="研究报告.md"` in `content-disposition` is not valid HTTP and
 * is mangled by some clients, so the RFC 5987 `filename*` form is emitted
 * alongside an ASCII-only `filename` fallback: modern browsers use the UTF-8
 * name, older ones still get a usable, if transliterated, file name.
 */

/** Printable ASCII only; everything else becomes `_` for the legacy fallback. */
function asciiFallback(filename: string): string {
  const ascii = filename.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');
  // A name made entirely of non-ASCII characters collapses to underscores,
  // which is useless; the extension is worth keeping at least.
  const extension = /\.([A-Za-z0-9]{1,8})$/.exec(filename)?.[1];
  if (!/[A-Za-z0-9]/.test(ascii)) return extension ? `export.${extension}` : 'export';
  return ascii;
}

/** `content-disposition` value for an attachment download. */
export function attachmentDisposition(filename: string): string {
  const encoded = encodeURIComponent(filename).replace(
    /['()*]/g,
    (character) => `%${character.charCodeAt(0).toString(16).toUpperCase()}`,
  );
  return `attachment; filename="${asciiFallback(filename)}"; filename*=UTF-8''${encoded}`;
}
