# 生产部署指南（阿里云 Ubuntu ECS）

> 只讲部署操作，不改动任何模型/业务代码。
> 本项目的实际形态见 §0；GPU 与 CPU 的差异见 §2（**本项目只需 CPU**，GPU 一节是给"另有本地模型推理工程"的情况）。

---

## 0. 部署前必须知道的四件事

1. **本项目是两个进程 + 一个 SQLite 文件**，不是一个端口就能跑完的服务：
   - API 进程：`node dist/src/index.js`，默认 `127.0.0.1:4000`
   - 前端静态进程：`node packages/web/scripts/serve.mjs`，默认 `127.0.0.1:5173`
   - 数据库：单个 SQLite 文件（WAL 模式，同目录还有 `-wal` / `-shm`）
2. **不需要 GPU**。本项目的 AI 能力是**出站 HTTPS 调用 DeepSeek API**，本地不做任何模型推理，没有 CUDA / PyTorch / vLLM 依赖。
3. **Node.js 必须 ≥ 22.5**（代码用了 Node 内置的 `node:sqlite`）。Ubuntu 仓库自带的 nodejs 版本不够，必须单独装。推荐 Node 24：`node:sqlite` 无需任何启动参数；若装 Node 22.x，启动时要加 `--experimental-sqlite`。
4. **前端不需要配置 API 地址**：前端在非 localhost 域名下会自动使用 `window.location.origin`。因此**单域名反向代理**（Nginx 把 `/api/` 转给 4000、其余转给 5173）即可，前后端同源，CORS 与跨域 cookie 问题都不存在。

规划建议：

| 项 | 建议值 |
| --- | --- |
| 运行用户 | `ferp`（非 root、不可登录） |
| 代码目录 | `/opt/ferp` |
| 数据目录 | `/var/lib/ferp`（放 SQLite 文件） |
| 配置目录 | `/etc/ferp`（放 env 文件，权限 600） |
| 公网入口 | 只开 `22` / `80` / `443` |

---

## 1. 项目上传到服务器

### 1.1 本地打包（排除不该上传的内容）

在**本地项目根目录**执行，排除依赖、构建产物、数据库与本地配置：

```bash
tar --exclude=./node_modules \
    --exclude=./.npm-cache \
    --exclude=./packages/*/dist \
    --exclude=./packages/*/dist-tests \
    --exclude=./packages/server/data \
    --exclude=./.env \
    --exclude=./.env.local \
    -czf ferp-src.tar.gz .
```

要点：
- `node_modules` 不要上传（里面有 Windows 平台的二进制，Linux 上不能用）。
- `packages/server/data/` 是本地开发库，**默认不上传**。若要把已有数据迁到线上，见 §1.4。
- `.env` / `.env.local` 不上传；线上配置单独写（§4）。

### 1.2 上传

```bash
scp ferp-src.tar.gz root@<ECS公网IP>:/tmp/
```

数据量大或要断点续传时改用 rsync：

```bash
rsync -avz --progress ferp-src.tar.gz root@<ECS公网IP>:/tmp/
```

### 1.3 服务器上解包

```bash
# 建运行用户（不允许登录）
sudo adduser --system --group --home /opt/ferp --shell /usr/sbin/nologin ferp

sudo mkdir -p /opt/ferp /var/lib/ferp /etc/ferp
sudo tar -xzf /tmp/ferp-src.tar.gz -C /opt/ferp
sudo rm /tmp/ferp-src.tar.gz

sudo chown -R ferp:ferp /opt/ferp /var/lib/ferp
sudo chmod 700 /var/lib/ferp
sudo chmod 600 /etc/ferp/*.env 2>/dev/null || true
```

### 1.4 迁移已有数据（可选，但必须小心）

SQLite 是文件库，最可靠的迁移方式是**先停写、再拷文件**：

```bash
# 本地：把 WAL 合并进主库，避免拷到半截事务
sqlite3 packages/server/data/ferp.db "PRAGMA wal_checkpoint(TRUNCATE);"
scp packages/server/data/ferp.db root@<ECS公网IP>:/tmp/ferp.db

# 服务器：放到数据目录并改属主
sudo mv /tmp/ferp.db /var/lib/ferp/ferp.db
sudo chown ferp:ferp /var/lib/ferp/ferp.db
```

> 若线上还没建库，也可以选择不迁数据，直接用 §3 的迁移+种子重建空库。

---

## 2. 环境安装（CPU / GPU 分列）

### 2.1 CPU 环境 —— **本项目用这一节**

```bash
sudo apt update
sudo apt install -y curl ca-certificates gnupg git sqlite3 nginx

# Node.js 24（NodeSource 源）
curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
sudo apt install -y nodejs

node -v      # 必须是 v22.5 以上，建议 v24.x
npm -v
```

可选：把 npm 全局目录放到用户目录，避免 sudo 装全局包（本项目不需要全局包，可跳过）。

> 项目自带的 `.npmrc` 里有一行 `cache=./.npm-cache`，那是本地沙箱环境为了把缓存放在工作区内加的。服务器上保留它也能用（缓存会落在项目目录里），但会占空间、也会被一起备份；建议在服务器上删掉这一行：
> ```bash
> sudo sed -i '/^cache=/d' /opt/ferp/.npmrc
> ```

### 2.2 GPU 环境 —— **本项目不需要，以下是给"另有本地模型推理工程"的差异说明**

只有在你要在 ECS 上**自己跑模型推理**（PyTorch / vLLM / Ollama 等）时才需要。差异只有四点，其余步骤与 CPU 相同：

1. **实例规格**：必须选 GPU 计算型实例（如 `gn7i` / `gn6i` 系列），并在购买时选好 GPU 驱动或后续自装；CPU 型实例无法挂载 GPU。
2. **驱动与 CUDA**：
   ```bash
   nvidia-smi                     # 有输出即驱动就绪，记下 CUDA Version
   ```
   若命令不存在：安装 NVIDIA 官方驱动（阿里云 GPU 镜像通常已预装，建议优先用官方镜像，省掉驱动与内核头文件的匹配问题）。
3. **容器化推理**（若用容器）：
   ```bash
   nvidia-ctk --version           # 来自 nvidia-container-toolkit
   docker run --rm --gpus all nvidia/cuda:12.4.0-base-ubuntu22.04 nvidia-smi
   ```
   需要装 NVIDIA Container Toolkit 并 `nvidia-ctk runtime configure --runtime=docker` 后重启 docker。
4. **显存与并发**：显存决定最大并发与上下文长度；`nvidia-smi -l 5` 观察显存是否打满。CPU 环境不存在这些约束，也不存在"驱动版本与框架版本不匹配"这类故障。

> 说明：我不知道你那个推理工程的框架与显存需求，所以这里只给通用可验证的检查点，没有编造具体版本号。本项目（family-edu-research-platform）请直接用 §2.1。

---

## 3. 依赖安装与构建

```bash
sudo -iu ferp
cd /opt/ferp

# 依赖（有 package-lock.json，用 ci 保证可复现）
npm ci

# 构建：shared → server → web
npm run build
```

**关键提醒：不要加 `--ignore-scripts`**。
本地沙箱是因为禁止子进程管道才加了这个参数；在 Ubuntu 上必须正常安装，因为 esbuild / tailwind 需要执行安装脚本放置平台二进制，跳过脚本会导致构建失败。

初始化数据库（**生产环境务必带 `NODE_ENV=production`**，见 §4）：

```bash
set -a; . /etc/ferp/api.env; set +a
npm run db:migrate -w @ferp/server
npm run db:seed    -w @ferp/server     # 建演示账号；密码只在本次输出中打印一次，请立刻保存
```

> 小内存实例（1 核 1G）若在 `npm ci` 或构建时被 OOM 杀掉，先加 2G swap：
> ```bash
> sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile
> sudo mkswap /swapfile && sudo swapon /swapfile
> echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
> ```

---

## 4. 环境变量（`/etc/ferp/api.env`）

```bash
sudo tee /etc/ferp/api.env >/dev/null <<'EOF'
NODE_ENV=production

# 数据库：放到独立数据目录（SQLite 需要对该目录有写权限，WAL 文件也在同一目录）
DATABASE_PATH=/var/lib/ferp/ferp.db

# 监听：只监听回环，公网流量一律经 Nginx 转发
HOST=127.0.0.1
PORT=4000

# 必填：生产环境下少于 32 字符会拒绝启动
JWT_SECRET=请替换为随机值
JWT_EXPIRES_IN=43200

# 公网地址：用于生成受访者问卷链接与二维码，必须是外部可访问的地址
PUBLIC_BASE_URL=https://你的域名

# 同源反向代理下 CORS 基本不触发，仍建议显式填上
CORS_ORIGINS=https://你的域名

# 公开问卷每 IP 会话上限（默认 600/15 分钟；学校机房等共用出口 IP 的场景可适当调高）
PUBLIC_SESSION_LIMIT=600

# AI 解释：不填则自动进入"诚实降级模式"（由统计引擎生成摘要，不调用模型、不编造）
DEEPSEEK_API_KEY=
DEEPSEEK_BASE_URL=https://api.deepseek.com
# DEEPSEEK_MODEL=
# DEEPSEEK_TIMEOUT_MS=

# 演示账号（可选）：不填则由 db:seed 随机生成并只打印一次
# SEED_DEMO_EMAIL=
# SEED_DEMO_PASSWORD=
EOF

# 生成 JWT_SECRET 并写入
sudo sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$(openssl rand -base64 48 | tr -d '\n')|" /etc/ferp/api.env

sudo chown root:ferp /etc/ferp/api.env
sudo chmod 640 /etc/ferp/api.env      # 只有 root 与 ferp 组可读
```

前端静态进程只需要监听地址，单独一个文件：

```bash
sudo tee /etc/ferp/web.env >/dev/null <<'EOF'
WEB_HOST=127.0.0.1
WEB_PORT=5173
EOF
sudo chown root:ferp /etc/ferp/web.env
sudo chmod 640 /etc/ferp/web.env
```

自查：`sudo -iu ferp bash -c 'set -a; . /etc/ferp/api.env; set +a; echo $NODE_ENV $DATABASE_PATH'`

---

## 5. 后台启动（systemd）

### 5.1 API 服务

```bash
sudo tee /etc/systemd/system/ferp-api.service >/dev/null <<'EOF'
[Unit]
Description=FERP research platform API
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ferp
Group=ferp
WorkingDirectory=/opt/ferp/packages/server
EnvironmentFile=/etc/ferp/api.env
ExecStart=/usr/bin/node dist/src/index.js
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ferp-api

# 基本加固
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=/var/lib/ferp

[Install]
WantedBy=multi-user.target
EOF
```

> 若服务器上是 Node 22.x 而不是 24.x，把 ExecStart 改成：
> `ExecStart=/usr/bin/node --experimental-sqlite dist/src/index.js`

### 5.2 前端静态服务

```bash
sudo tee /etc/systemd/system/ferp-web.service >/dev/null <<'EOF'
[Unit]
Description=FERP research console (static + SPA fallback)
After=network-online.target ferp-api.service
Wants=network-online.target

[Service]
Type=simple
User=ferp
Group=ferp
WorkingDirectory=/opt/ferp/packages/web
EnvironmentFile=/etc/ferp/web.env
ExecStart=/usr/bin/node scripts/serve.mjs
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ferp-web

NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
EOF
```

### 5.3 启动并验证

```bash
sudo systemctl daemon-reload
sudo systemctl start ferp-api ferp-web

sudo systemctl status ferp-api --no-pager
sudo systemctl status ferp-web --no-pager

# 本机自测（不经过 Nginx）
curl -s http://127.0.0.1:4000/api/health
curl -sI http://127.0.0.1:5173/ | head -n 1
```

`/api/health` 应返回 `{"data":{"status":"ok",...,"database":"file",...}}`。

---

## 6. 开通开机自启

```bash
sudo systemctl enable ferp-api ferp-web

# 验证是否已设为开机自启
systemctl is-enabled ferp-api ferp-web      # 期望两个都是 enabled

# 最可靠的验证：重启一次，再确认服务与健康检查
# sudo reboot
# （重连后）
systemctl is-active ferp-api ferp-web
curl -s http://127.0.0.1:4000/api/health
```

---

## 7. 反向代理与 HTTPS（Nginx，单域名）

`/etc/nginx/sites-available/ferp`：

```nginx
server {
    listen 80;
    server_name 你的域名;

    # 问卷提交是 JSON，服务端限制 2MB；这里留出余量
    client_max_body_size 8m;

    # API：必须转发真实客户端 IP
    location /api/ {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # AI 解释与导出可能较慢，避免 60s 超时
        proxy_read_timeout 180s;
        proxy_send_timeout 180s;
    }

    # 问卷二维码等静态图片也走 API 进程
    location = /favicon.ico { access_log off; log_not_found off; }

    # 其余交给前端静态进程（含 SPA 深链接回退）
    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Host      $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo ln -sf /etc/nginx/sites-available/ferp /etc/nginx/sites-enabled/ferp
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

**必须转发真实 IP 的原因**（不是可选项）：API 的公开问卷限流是按客户端 IP 分桶的。若 Nginx 不转发 `X-Forwarded-For`，所有受访者会被算成同一个 `127.0.0.1`，共用同一份额度——真实用户会被误拒。

### 7.1 HTTPS

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d 你的域名
sudo systemctl status certbot.timer      # 自动续期
sudo certbot renew --dry-run
```

装好证书后，确认 §4 里的 `PUBLIC_BASE_URL` 已是 `https://你的域名`，否则问卷二维码会指向 http 地址。

### 7.2 中国大陆地域的备案提醒

若 ECS 在中国大陆地域且使用域名对外提供 80/443 服务，域名需完成 **ICP 备案**，否则会被拦截。可选做法：换香港/海外地域、或暂时用非 80/443 端口（并接受 URL 带端口）。这是合规要求，不是技术故障。

---

## 8. 安全组（阿里云控制台）

入方向规则（**只放这三条**）：

| 协议 | 端口 | 授权对象 | 说明 |
| --- | --- | --- | --- |
| TCP | 22 | 你的固定 IP/32 | SSH。不要对 0.0.0.0/0 开放 |
| TCP | 80 | 0.0.0.0/0 | HTTP（跳转 HTTPS / 证书签发） |
| TCP | 443 | 0.0.0.0/0 | HTTPS |

出方向：保持默认（全部允许）。**不要**限制出方向，否则 API 无法访问 DeepSeek。

**绝对不要**在安全组里开放 `4000` 与 `5173`：两个进程都只监听 `127.0.0.1`，只应经 Nginx 访问。旁证检查：

```bash
sudo ss -lntp | grep -E '4000|5173'     # 期望看到 127.0.0.1:4000 与 127.0.0.1:5173，而不是 0.0.0.0
```

如果服务器上启用了 ufw，安全组与 ufw 是两道独立的门，都要放行：

```bash
sudo ufw status
sudo ufw allow 22/tcp && sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
sudo ufw enable
```

---

## 9. 日志查看

```bash
# 实时跟随
sudo journalctl -u ferp-api -f
sudo journalctl -u ferp-web -f

# 最近 200 行 / 指定时间范围
sudo journalctl -u ferp-api -n 200 --no-pager
sudo journalctl -u ferp-api --since "10 min ago" --no-pager
sudo journalctl -u ferp-api --since today --no-pager

# 只看错误级别
sudo journalctl -u ferp-api -p err --no-pager

# 按标识过滤（两个服务都写 journal，用 SyslogIdentifier 区分）
sudo journalctl -t ferp-api -n 100 --no-pager

# Nginx 日志
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# journal 占用与清理（默认可能吃掉不少磁盘）
journalctl --disk-usage
sudo journalctl --vacuum-time=14d
```

限制 journal 大小（`/etc/systemd/journald.conf`）：`SystemMaxUse=500M` 后 `sudo systemctl restart systemd-journald`。

---

## 10. 数据备份（SQLite 必须这样做）

**不要**直接 `cp ferp.db`——WAL 模式下正在写入时会拷到不一致的快照。用 SQLite 自己的备份命令：

```bash
sudo -u ferp sqlite3 /var/lib/ferp/ferp.db ".backup '/var/lib/ferp/backup/ferp-$(date +%F-%H%M).db'"
# 或
sudo -u ferp sqlite3 /var/lib/ferp/ferp.db "VACUUM INTO '/var/lib/ferp/backup/ferp-$(date +%F-%H%M).db'"
```

定时任务（`crontab -u ferp -e`，保留 14 天）：

```bash
15 3 * * * mkdir -p /var/lib/ferp/backup && sqlite3 /var/lib/ferp/ferp.db ".backup '/var/lib/ferp/backup/ferp-$(date +\%F).db'" && find /var/lib/ferp/backup -name 'ferp-*.db' -mtime +14 -delete
```

---

## 11. 排错命令速查

| 症状 | 命令 / 判断 |
| --- | --- |
| 服务没起来 | `systemctl status ferp-api --no-pager -l` → 看 `Active:` 与最后几行报错 |
| 服务反复重启 | `journalctl -u ferp-api -n 100 --no-pager`；常见原因见下三行 |
| 启动即退出、日志提到 JWT | 生产环境下 `JWT_SECRET` 少于 32 字符会**拒绝启动**。检查 `sudo grep -c . /etc/ferp/api.env` 与变量是否真的加载 |
| 启动报 `Cannot find module 'node:sqlite'` | Node 版本低于 22.5。`node -v`；或 Node 22.x 忘了加 `--experimental-sqlite` |
| 报数据库只读 / `SQLITE_CANTOPEN` | 目录权限：`ls -ld /var/lib/ferp`，属主必须是 `ferp`；WAL 需要**目录**写权限 |
| 端口没监听 | `sudo ss -lntp \| grep -E '4000\|5173'`；没有输出说明进程没起来 |
| 本机健康检查失败 | `curl -v http://127.0.0.1:4000/api/health`；再看 `journalctl -u ferp-api -n 50` |
| 域名 502 / 504 | `sudo nginx -t`；`sudo tail -50 /var/log/nginx/error.log`；后端是否在监听；AI/导出类请求 504 多为 `proxy_read_timeout` 太短 |
| 页面能开但接口 404 | Nginx 是否把 `/api/` 转发到了 4000；`curl -s https://域名/api/health` |
| 页面能开但接口跨域报错 | 用了双域名/双端口直连。改成 §7 的单域名反代即可 |
| 问卷限流误伤真实用户 | 检查 Nginx 是否转发 `X-Forwarded-For`（否则所有人共用一个桶） |
| 磁盘满 | `df -h`；`du -sh /var/lib/ferp/* /var/log/journal`；清理 journal 与旧备份 |
| 内存不足被 OOM | `dmesg \| tail -50 \| grep -i oom`；加 swap（§3） |
| 时间不对导致时间戳错乱 | `timedatectl`；`sudo timedatectl set-timezone Asia/Shanghai` |
| 想确认现状 | `curl -s http://127.0.0.1:4000/api/health`、`systemctl is-active ferp-api ferp-web`、`node -v` |
| 查看 SQLite 状态 | `sudo -u ferp sqlite3 /var/lib/ferp/ferp.db "PRAGMA journal_mode; PRAGMA integrity_check;"` |

---

## 12. 更新与回滚

```bash
# 更新
sudo -iu ferp
cd /opt/ferp
# 上传/拉取新代码后：
npm ci
npm run build
npm run db:migrate -w @ferp/server     # 迁移是幂等的，可重复执行
exit

sudo systemctl restart ferp-api ferp-web
sudo systemctl status ferp-api ferp-web --no-pager
curl -s http://127.0.0.1:4000/api/health
```

回滚要点：**先备份数据库再迁移**（§10）。迁移只前进不回退，若新版本引入了表结构变更，仅回退代码可能与新库结构不匹配——因此回滚前务必保留迁移前的数据库副本。

---

## 13. 上线前检查清单

- [ ] `node -v` ≥ 22.5（建议 24.x）
- [ ] `NODE_ENV=production` 且 `JWT_SECRET` ≥ 32 字符
- [ ] `PUBLIC_BASE_URL` 与 `CORS_ORIGINS` 均为最终 https 域名
- [ ] `/etc/ferp/*.env` 权限为 `640`、属主 `root:ferp`
- [ ] `ss -lntp` 显示 4000/5173 **只**监听 `127.0.0.1`
- [ ] 安全组只开 22 / 80 / 443，4000 与 5173 未暴露
- [ ] Nginx 转发了 `X-Real-IP` 与 `X-Forwarded-For`
- [ ] `systemctl is-enabled ferp-api ferp-web` 均为 `enabled`
- [ ] `curl -s https://域名/api/health` 返回 `status: ok`
- [ ] 浏览器访问域名可登录，`https://域名/research/<share_token>` 与 `/all` 两种问卷链接均可打开
- [ ] 已配置数据库定时备份并实测恢复过一次
- [ ] 演示账号密码已离线保存（不是写在服务器明文文件里）
