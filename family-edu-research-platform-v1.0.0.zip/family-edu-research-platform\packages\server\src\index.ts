/**
 * Server entry point.
 *
 * Opens the database, applies pending migrations, and starts listening. The
 * process refuses to start if migrations fail — serving requests against a
 * half-migrated schema would silently corrupt data.
 */

import { loadConfig } from './config.js';
import { Db } from './db/index.js';
import { migrate } from './db/migrate.js';
import { createApp } from './app.js';

const config = loadConfig();
const db = new Db(config.databasePath);

const migration = migrate(db);
if (migration.applied.length > 0) {
  console.log(`[ferp] 已应用数据库迁移：${migration.applied.join(', ')}`);
}

const app = createApp({ db, config });

const server = app.listen(config.port, config.host, () => {
  console.log('[ferp] 家庭教育科研智能研究平台 — API 服务已启动');
  console.log(`[ferp] 环境: ${config.env}`);
  console.log(`[ferp] 地址: http://${config.host}:${config.port}`);
  console.log(`[ferp] 数据库: ${config.databasePath}`);
  if (config.usingEphemeralSecret) {
    console.warn(
      '[ferp] 警告: 未设置 JWT_SECRET，正在使用临时密钥。' +
        '重启后所有登录状态将失效；生产环境必须显式设置 JWT_SECRET。',
    );
  }
});

function shutdown(signal: string): void {
  console.log(`[ferp] 收到 ${signal}，正在关闭服务…`);
  server.close(() => {
    db.close();
    process.exit(0);
  });
  // Do not hang forever on a stuck connection.
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
