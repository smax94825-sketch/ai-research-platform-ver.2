/**
 * Competition insight API tests (PHASE 9).
 *
 * The sample is collected through the real public survey API and the analysis
 * bundle is produced by the real statistical engine, so the whole chain is
 * covered: instrument → answers → dataset → engine → bundle → competition view.
 *
 * Two fixtures are built deliberately:
 *
 *  - **Fixture A** is a V4.0-derived instrument carrying every construct the
 *    competition view can talk about (difficulty, digital-service demand, trust,
 *    AI acceptance, willingness to pay, the public-service chain). It exercises
 *    the available path.
 *  - **Fixture B** is a short, non-template instrument that asks about nothing but
 *    demographics, family-education cognition and self-efficacy. Every block that
 *    needs demand / trust / AI / payment data must therefore come back
 *    `available: false` with a Chinese reason and `data: null` — the honest-refusal
 *    path, asserted rather than assumed.
 *
 * The central anti-fabrication assertion is that every `evidence` entry a block
 * reports resolves, through an INDEPENDENTLY IMPLEMENTED resolver (below), to the
 * value recorded next to it. A block cannot quote a number that is not in the
 * bundle, and cannot cite a path that does not exist.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';

import express from 'express';

import { createApp } from '../src/app.js';
import { loadConfig } from '../src/config.js';
import { Db } from '../src/db/index.js';
import { migrate } from '../src/db/migrate.js';
import { createErrorHandler } from '../src/middleware/error.js';
import { createInsightRouter } from '../src/routes/insight.routes.js';
import { REQUIRED_CAVEATS } from '../src/services/insight.service.js';
import {
  api,
  createPublishedQuestionnaire,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

/* ================================================================== */
/* Test context                                                       */
/* ================================================================== */

/**
 * Boot the real app with the competition router in front of it.
 *
 * `createApp` registers its 404 handler as plain middleware that answers the
 * request directly, so a router appended after the fact would never be reached;
 * the router has to sit before that handler. Mounting it on a thin wrapper that
 * delegates everything else to the real app keeps the test exercising the whole
 * stack — auth, the public survey API and the analysis router — rather than a
 * hand-built subset.
 */
async function createInsightTestContext(): Promise<TestContext> {
  const config = loadConfig({
    NODE_ENV: 'test',
    DATABASE_PATH: ':memory:',
    JWT_SECRET: 'test-secret-that-is-long-enough-for-hs256-signing',
    JWT_EXPIRES_IN: '3600',
  });

  const db = new Db(config.databasePath);
  migrate(db);

  const inner = createApp({ db, config });
  const app = express();
  app.use(express.json({ limit: '2mb' }));
  app.use('/api/projects', createInsightRouter({ db, config }));
  // The error handler belongs to the same layer as the router: without it, a
  // rejected handler would fall through to Express's default HTML error page and
  // the documented `{ error: { code, message } }` envelope would be lost.
  app.use(createErrorHandler({ logUnexpected: false }));
  app.use(inner);

  const server = await new Promise<Server>((resolve) => {
    const created = app.listen(0, '127.0.0.1', () => resolve(created));
  });
  const address = server.address() as AddressInfo;

  return {
    db,
    config,
    server,
    baseUrl: `http://127.0.0.1:${address.port}`,
    close: () =>
      new Promise<void>((resolve, reject) => {
        server.close((error) => {
          db.close();
          if (error) reject(error);
          else resolve();
        });
      }),
  };
}

/* ================================================================== */
/* Instrument builders                                                */
/* ================================================================== */

const AGREE = [
  { value: '1', label: '非常不同意', score: 1 },
  { value: '2', label: '比较不同意', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较同意', score: 4 },
  { value: '5', label: '非常同意', score: 5 },
];

const KNOW = [
  { value: '1', label: '非常不了解', score: 1 },
  { value: '2', label: '比较不了解', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较了解', score: 4 },
  { value: '5', label: '非常了解', score: 5 },
];

const FREQ = [
  { value: '1', label: '从不', score: 1 },
  { value: '2', label: '很少', score: 2 },
  { value: '3', label: '有时', score: 3 },
  { value: '4', label: '经常', score: 4 },
  { value: '5', label: '总是', score: 5 },
];

const DIFFICULTY = [
  { value: '1', label: '完全没有困难', score: 1 },
  { value: '2', label: '困难较小', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '困难较大', score: 4 },
  { value: '5', label: '困难非常大', score: 5 },
];

const TRUST = [
  { value: '1', label: '非常不信任', score: 1 },
  { value: '2', label: '比较不信任', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较信任', score: 4 },
  { value: '5', label: '非常信任', score: 5 },
];

const NEED = [
  { value: '1', label: '完全不需要', score: 1 },
  { value: '2', label: '比较不需要', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较需要', score: 4 },
  { value: '5', label: '非常需要', score: 5 },
];

const SATISFY = [
  { value: '1', label: '非常不满意', score: 1 },
  { value: '2', label: '比较不满意', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较满意', score: 4 },
  { value: '5', label: '非常满意', score: 5 },
];

const MEAN_5 = { type: 'mean', min: 1, max: 5 };
/** UI/WTP are documented as ordinal (1—5) by the template's own help text. */
const ORDINAL_5 = { type: 'ordinal', codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 } };
const COUNT_RULE = { type: 'count', excludeExclusive: true };
const KNOWLEDGE_RULE = {
  type: 'knowledge',
  correctScore: 1,
  incorrectScore: 0,
  unknownScore: 0,
  unknownValue: '3',
  maxScore: 1,
};

function likert(
  code: string,
  variable: string,
  dimension: string,
  choices: { value: string; label: string; score: number }[] = AGREE,
  rule: Record<string, unknown> = MEAN_5,
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'likert',
    required: true,
    dimension,
    variable_name: variable,
    options: { choices, scaleMin: 1, scaleMax: choices.length },
    scoring_rule: rule,
  };
}

function single(
  code: string,
  variable: string,
  dimension: string,
  labels: string[],
  rule: Record<string, unknown>,
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'single',
    required: true,
    dimension,
    variable_name: variable,
    options: { choices: labels.map((label, index) => ({ value: String(index + 1), label, score: index + 1 })) },
    scoring_rule: rule,
  };
}

function matrix(
  code: string,
  variable: string,
  dimension: string,
  rows: string[],
  columns: { value: string; label: string; score: number }[],
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'matrix',
    required: true,
    dimension,
    variable_name: variable,
    options: {
      matrix: {
        rows: rows.map((label, index) => ({ value: String(index + 1), label })),
        columns,
      },
      scaleMin: 1,
      scaleMax: columns.length,
    },
    scoring_rule: MEAN_5,
  };
}

function knowledge(
  code: string,
  variable: string,
  correctValue: '1' | '2',
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `客观知识题（${code}）`,
    question_type: 'knowledge_test',
    required: true,
    dimension: '《家庭教育促进法》认知',
    variable_name: variable,
    options: {
      choices: [
        { value: '1', label: '正确', score: correctValue === '1' ? 1 : 0, isCorrect: correctValue === '1' },
        { value: '2', label: '错误', score: correctValue === '2' ? 1 : 0, isCorrect: correctValue === '2' },
        { value: '3', label: '不清楚', score: 0 },
      ],
    },
    scoring_rule: KNOWLEDGE_RULE,
  };
}

function multiple(
  code: string,
  variable: string,
  dimension: string,
  labels: string[],
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'multiple',
    required: true,
    dimension,
    variable_name: variable,
    options: {
      choices: labels.map((label, index) => ({
        value: String(index + 1),
        label,
        score: 1,
        exclusive: index === labels.length - 1,
      })),
    },
    scoring_rule: COUNT_RULE,
  };
}

const STAGES = ['学前（0—6岁）', '小学', '初中', '高中'];
const FED_ROWS = [
  '缺乏科学的家庭教育方法',
  '没有足够的时间陪伴和教育孩子',
  '与孩子沟通困难',
  '孩子学习习惯差、缺乏自觉性',
  '孩子的情绪或行为问题',
  '家庭成员之间教育观念不一致',
  '难以获得专业、可靠的家庭教育指导',
];
const STI_ROWS = [
  '政府部门',
  '学校及教师',
  '专业家庭教育机构',
  '心理咨询师等专业人士',
  '亲友及其他家长',
  'AI智能助手',
];
const DSD_ROWS = [
  '个性化育儿方案推荐',
  '在线专家咨询',
  '系统化的家庭教育课程',
  '亲子沟通技巧指导',
  '儿童行为问题应对指导',
  '家庭教育政策与公共服务导航',
];
const PRC_ROWS = [
  '担心AI提供的信息不够专业',
  '担心个人隐私泄露',
  '担心AI给出的建议不够准确',
  '担心AI缺乏情感温度',
  '担心过度依赖AI',
];

const FSE_CODES = ['Q22', 'Q23', 'Q24', 'Q25', 'Q26', 'Q27', 'Q28', 'Q29', 'Q30'];

/** Fixture A: the full V4.0-derived instrument (45 questions, real template codes). */
const INSTRUMENT: Record<string, unknown>[] = [
  single('Q1', 'ROLE', '基本信息', ['父亲', '母亲', '祖辈（爷爷奶奶／外公外婆）', '其他监护人'], {
    type: 'categorical',
    codes: { '1': 1, '2': 2, '3': 3, '4': 4 },
  }),
  single('Q2', 'AGE', '基本信息', ['25岁及以下', '26—30岁', '31—35岁', '36—40岁', '41—45岁', '46岁及以上'], {
    type: 'ordinal',
    codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6 },
  }),
  single('Q3', 'EDU', '基本信息', ['初中及以下', '高中或中专', '大专', '本科', '硕士及以上'], {
    type: 'ordinal',
    codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 },
  }),
  single('Q4', 'STAGE', '基本信息', STAGES, { type: 'categorical', codes: { '1': 1, '2': 2, '3': 3, '4': 4 } }),
  single('Q5', 'AREA', '基本信息', ['省会城市', '地级市', '县城', '乡镇', '农村'], {
    type: 'ordinal',
    codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 },
  }),
  likert('Q6', 'FEI1', '家庭教育认知'),
  likert('Q7', 'FEI2', '家庭教育认知'),
  likert('Q8', 'FEI3', '家庭教育认知'),
  likert('Q9', 'FEK', '家庭教育认知', KNOW),
  knowledge('Q12', 'LKA1', '1'),
  knowledge('Q13', 'LKA2', '1'),
  knowledge('Q14', 'LKA3', '1'),
  knowledge('Q15', 'LKA4', '2'),
  knowledge('Q16', 'LKA5', '2'),
  likert('Q19', 'ISC1', '信息获取渠道'),
  likert('Q20', 'ISC2', '信息获取渠道'),
  ...FSE_CODES.map((code, index) => likert(code, `FSE${index + 1}`, '家庭教育自我效能')),
  likert('Q31', 'FPB1', '家庭教育实际行为', FREQ),
  likert('Q33', 'FPB2', '家庭教育实际行为', FREQ),
  likert('Q34', 'FPB3', '家庭教育实际行为', FREQ),
  matrix('Q35', 'FED', '家庭教育困难', FED_ROWS, DIFFICULTY),
  likert('Q38', 'FIUA', '家庭教育机构'),
  single('Q39', 'FIUU', '家庭教育机构', ['从未使用', '使用过1—2次', '偶尔使用', '经常使用'], MEAN_5),
  likert('Q41', 'FIU', '家庭教育机构'),
  multiple('Q42', 'PSAK', '政府家庭教育公共服务', [
    '社区（村）家长学校',
    '学校、幼儿园开展的家庭教育指导',
    '家庭教育公益讲座或宣传活动',
    '家庭教育指导服务热线或咨询',
    '政府建设的家庭教育公共服务平台或网站',
    '免费的家庭教育宣传资料',
    '以上都不知道',
  ]),
  likert('Q43', 'PSA1', '政府家庭教育公共服务'),
  likert('Q44', 'PSA2', '政府家庭教育公共服务'),
  single('Q45', 'PSU1', '政府家庭教育公共服务', ['从未使用', '使用过1—2次', '偶尔使用', '经常使用'], MEAN_5),
  matrix('Q46', 'PSU', '政府家庭教育公共服务', ['服务内容具有实用性', '获取方式便利', '宣传告知充分', '服务人员专业', '服务的覆盖公平'], SATISFY),
  likert('Q47', 'PSUI', '政府家庭教育公共服务'),
  matrix('Q48', 'STI', '服务主体信任', STI_ROWS, TRUST),
  matrix('Q49', 'DSD', '数字化家庭教育服务需求', DSD_ROWS, NEED),
  likert('Q50', 'UI', 'AI家庭教育服务接受度', AGREE, ORDINAL_5),
  matrix('Q51', 'PRC', 'AI服务风险认知', PRC_ROWS, AGREE),
  likert('Q52', 'AIPV', 'AI家庭教育服务接受度'),
  likert('Q53', 'WTP', '家庭教育服务付费意愿', AGREE, ORDINAL_5),
  single('Q54', 'WTPA', '家庭教育服务付费意愿', ['0元', '1—500元', '501—2000元', '2001—5000元', '5001—10000元', '10000元以上'], {
    type: 'ordinal',
    codes: { '1': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 5 },
  }),
  multiple('Q55', 'WTPF', '家庭教育服务付费意愿', [
    '一对一家庭教育咨询',
    '系统化的家长课程',
    '儿童行为问题干预指导',
    '亲子沟通训练',
    '学习习惯培养方案',
    '家庭教育政策与资源导航',
    '都不愿意付费',
  ]),
];

/**
 * Fixture B: a deliberately narrow, non-template instrument.
 *
 * It shares only 14 of the template's 58 question codes, which is far below the
 * threshold at which the engine recognises a questionnaire as template-derived,
 * so no composite construct (FSE, ISC, LKA, QN …) is materialised. Everything the
 * competition view says about demand, trust, AI or payment must therefore be
 * refused rather than guessed.
 */
const NARROW_INSTRUMENT: Record<string, unknown>[] = [
  single('Q4', 'STAGE', '基本信息', STAGES, { type: 'categorical', codes: { '1': 1, '2': 2, '3': 3, '4': 4 } }),
  likert('Q6', 'FEI1', '家庭教育认知'),
  likert('Q7', 'FEI2', '家庭教育认知'),
  likert('Q8', 'FEI3', '家庭教育认知'),
  likert('Q9', 'FEK', '家庭教育认知', KNOW),
  ...FSE_CODES.map((code, index) => likert(code, `FSE${index + 1}`, '家庭教育自我效能')),
];

/* ================================================================== */
/* Data-generating process                                            */
/* ================================================================== */

/** Fixed-seed LCG: the same sample on every run, so failures point at code. */
function lcg(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function gaussian(rand: () => number): number {
  let sum = 0;
  for (let i = 0; i < 12; i += 1) sum += rand();
  return sum - 6;
}

function lk(value: number): number {
  return Math.min(5, Math.max(1, Math.round(value)));
}

function mean(values: number[]): number {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function matrixAnswer(values: number[]): Record<string, string> {
  const answer: Record<string, string> = {};
  values.forEach((value, index) => {
    answer[String(index + 1)] = String(value);
  });
  return answer;
}

/**
 * Per-item offsets.
 *
 * The ranking assertions below are only meaningful if the items differ by a
 * knowable amount: with identical distributions the order would be pure noise and
 * "assert the order matches the values" would prove nothing.
 */
const FED_OFFSETS = [0.9, 0.6, 0.3, 0, -0.3, -0.6, -0.9];
const STI_OFFSETS = [0.6, 0.35, -0.2, 0.1, -0.5, -0.9];
const DSD_OFFSETS = [0.3, 0.8, -0.1, 0.2, -0.4, -0.8];
const PRC_OFFSETS = [0, 0.6, 0.2, -0.2, -0.5];

interface GeneratedSample {
  answers: Record<string, unknown>;
}

function generateFullSample(rand: () => number, index: number): GeneratedSample {
  const stage = (index % STAGES.length) + 1;
  const g = (): number => gaussian(rand);

  const ability = g();
  const difficulty = g();
  const trust = g();
  const risk = g();
  const value = g();
  const access = g();
  const digital = g();

  const role = String((index % 4) + 1);
  const age = String(((index * 2) % 6) + 1);
  const edu = String(((index * 3) % 5) + 1);
  const area = String(((index * 4) % 5) + 1);

  const fei = [0, 1, 2].map(() => lk(3.2 + 0.3 * ability + 0.5 * g()));
  const fek = lk(3.0 + 0.75 * ability + 0.3 * g());
  const lka = (['1', '1', '1', '2', '2'] as const).map((correct) =>
    knowledgeAnswer(rand, correct, 0.45 + 0.12 * ability),
  );
  const isc = [0, 1].map(() => lk(3.0 + 0.4 * g()));

  const fse = Array.from({ length: 9 }, () => lk(3.0 + 0.8 * ability + 0.3 * g()));
  const fseMean = mean(fse);
  const fpb = [0, 1, 2].map(() => lk(0.9 + 0.6 * fseMean + 0.35 * g()));
  const fed = FED_OFFSETS.map((offset) => lk(2.2 + 0.35 * stage + 0.6 * difficulty + 0.4 * g() + offset));
  const fedMean = mean(fed);

  const fiua = lk(2.4 + 0.5 * g());
  const fiuu = String(Math.min(4, Math.max(1, Math.round(1.4 + 0.6 * g()))));
  const fiu = lk(2.6 + 0.5 * trust + 0.4 * g());

  const psa = [0, 1].map(() => lk(2.6 - 0.1 * stage + 0.7 * access + 0.4 * g()));
  const psak = [rand() < 0.5 ? '1' : '2', rand() < 0.4 ? '3' : '6'];
  const psuUsage = String(Math.min(4, Math.max(1, Math.round(1.1 + 0.5 * g()))));
  const psuEval = Array.from({ length: 5 }, () => lk(2.1 + 0.5 * access + 0.4 * g()));
  const psui = lk(3.4 + 0.4 * access + 0.4 * g());

  const sti = STI_OFFSETS.map((offset) => lk(2.9 + 0.75 * trust + 0.45 * g() + offset));
  const stiMean = mean(sti);
  const prc = PRC_OFFSETS.map((offset) => lk(3.0 + 0.7 * risk + 0.4 * g() + offset));
  const prcMean = mean(prc);
  const aipv = lk(3.0 + 0.7 * value + 0.4 * g());
  const dsd = DSD_OFFSETS.map((offset) =>
    lk(1.6 + 0.28 * fedMean + 0.3 * stiMean + 0.5 * digital + 0.4 * g() + offset),
  );
  const dsdMean = mean(dsd);

  const ui = lk(3.0 + 0.4 * (stiMean - 3) - 0.4 * (prcMean - 3) + 0.5 * (dsdMean - 3) + 0.7 * g());
  const wtp = lk(0.8 + 0.5 * dsdMean + 0.3 * aipv + 0.4 * g());
  const wtpa = String(Math.min(6, Math.max(1, Math.round(0.5 + 0.7 * wtp + 0.4 * g()))));
  const wtpf = wtp >= 3 ? ['2', '4'] : ['1'];

  const answers: Record<string, unknown> = {
    Q1: role,
    Q2: age,
    Q3: edu,
    Q4: String(stage),
    Q5: area,
    Q6: String(fei[0]!),
    Q7: String(fei[1]!),
    Q8: String(fei[2]!),
    Q9: String(fek),
    Q12: lka[0]!,
    Q13: lka[1]!,
    Q14: lka[2]!,
    Q15: lka[3]!,
    Q16: lka[4]!,
    Q19: String(isc[0]!),
    Q20: String(isc[1]!),
    Q31: String(fpb[0]!),
    Q33: String(fpb[1]!),
    Q34: String(fpb[2]!),
    Q35: matrixAnswer(fed),
    Q38: String(fiua),
    Q39: fiuu,
    Q41: String(fiu),
    Q42: psak,
    Q43: String(psa[0]!),
    Q44: String(psa[1]!),
    Q45: psuUsage,
    Q46: matrixAnswer(psuEval),
    Q47: String(psui),
    Q48: matrixAnswer(sti),
    Q49: matrixAnswer(dsd),
    Q50: String(ui),
    Q51: matrixAnswer(prc),
    Q52: String(aipv),
    Q53: String(wtp),
    Q54: wtpa,
    Q55: wtpf,
  };

  FSE_CODES.forEach((code, position) => {
    answers[code] = String(fse[position]!);
  });

  return { answers };
}

/** One objective knowledge answer: correct, wrong, or "不清楚" (also 0 points). */
function knowledgeAnswer(rand: () => number, correctValue: '1' | '2', probability: number): string {
  const clamped = Math.min(0.9, Math.max(0.05, probability));
  if (rand() < clamped) return correctValue;
  const wrong = correctValue === '1' ? '2' : '1';
  return rand() < 0.6 ? wrong : '3';
}

function generateNarrowSample(rand: () => number, index: number): GeneratedSample {
  const stage = (index % STAGES.length) + 1;
  const ability = gaussian(rand);
  const fei = [0, 1, 2].map(() => lk(3.2 + 0.3 * ability + 0.5 * gaussian(rand)));
  const fek = lk(3.0 + 0.75 * ability + 0.3 * gaussian(rand));
  const fse = Array.from({ length: 9 }, () => lk(3.0 + 0.8 * ability + 0.3 * gaussian(rand)));

  const answers: Record<string, unknown> = {
    Q4: String(stage),
    Q6: String(fei[0]!),
    Q7: String(fei[1]!),
    Q8: String(fei[2]!),
    Q9: String(fek),
  };
  FSE_CODES.forEach((code, position) => {
    answers[code] = String(fse[position]!);
  });
  return { answers };
}

/* ================================================================== */
/* Independent evidence-path resolver                                 */
/* ================================================================== */

/**
 * The same documented grammar the service uses, implemented here from scratch so
 * the check is independent of the code it verifies: `name[selector]` steps, an
 * identity selector matched on a fixed field list, `[field=value]` conditions,
 * numeric indexes, `length`, and the `quality.` root.
 */
const RESOLVER_IDENTITY_FIELDS = [
  'variable',
  'item',
  'scale',
  'dependent',
  'term',
  'code',
  'key',
  'name',
  'group',
  'label',
];

function splitEvidencePath(path: string): string[] {
  const parts: string[] = [];
  let current = '';
  let depth = 0;
  for (const char of path) {
    if (char === '[') depth += 1;
    if (char === ']') depth -= 1;
    if (char === '.' && depth === 0) {
      parts.push(current);
      current = '';
      continue;
    }
    current += char;
  }
  if (current !== '') parts.push(current);
  return parts;
}

function selectFromArray(array: unknown[], selector: string): unknown {
  if (/^\d+$/.test(selector)) return array[Number(selector)];
  if (selector === 'length') return array.length;

  if (selector.includes('=')) {
    const conditions = selector.split(',').map((condition) => {
      const parts = condition.split('=');
      return { field: (parts[0] ?? '').trim(), expected: (parts[1] ?? '').trim() };
    });
    let found: unknown;
    for (const item of array) {
      if (item === null || typeof item !== 'object') continue;
      const record = item as Record<string, unknown>;
      if (conditions.every((condition) => String(record[condition.field]) === condition.expected)) {
        found = item;
      }
    }
    return found;
  }

  let found: unknown;
  for (const item of array) {
    if (item === null || typeof item !== 'object') continue;
    const record = item as Record<string, unknown>;
    if (RESOLVER_IDENTITY_FIELDS.some((field) => record[field] === selector)) found = item;
  }
  return found;
}

function resolveEvidencePath(
  roots: { bundle: unknown; quality: unknown },
  path: string,
): unknown {
  const segments = splitEvidencePath(path);
  let current: unknown;
  let rest: string[];

  if (segments[0] === 'quality') {
    current = roots.quality;
    rest = segments.slice(1);
  } else if (segments[0] === 'bundle') {
    current = roots.bundle;
    rest = segments.slice(1);
  } else {
    current = roots.bundle;
    rest = segments;
  }

  for (const segment of rest) {
    const open = segment.indexOf('[');
    const name = open === -1 ? segment : segment.slice(0, open);
    const selectors: string[] = [];
    let cursor = open;
    while (open !== -1 && cursor !== -1 && cursor < segment.length && segment[cursor] === '[') {
      const close = segment.indexOf(']', cursor);
      if (close === -1) break;
      selectors.push(segment.slice(cursor + 1, close));
      cursor = close + 1;
    }

    if (current === undefined || current === null) return undefined;
    if (name !== 'length' && Array.isArray(current)) {
      current = selectFromArray(current, name);
    } else if (typeof current === 'object') {
      current = (current as Record<string, unknown>)[name];
    } else {
      return undefined;
    }

    for (const selector of selectors) {
      if (!Array.isArray(current)) return undefined;
      current = selectFromArray(current, selector);
    }
  }

  return current;
}

/* ================================================================== */
/* Response shapes used by the assertions                             */
/* ================================================================== */

interface EvidenceEntry {
  path: string;
  value: unknown;
}

interface BlockLike {
  key: string;
  order: number;
  title: string;
  available: boolean;
  reason: string | null;
  narrative: string;
  data: Record<string, unknown> | null;
  inputs: { name: string; role: string; available: boolean; note: string | null }[];
  evidence: EvidenceEntry[];
}

interface ReportLike {
  available: boolean;
  report_id: string;
  run_seq: number;
  created_at: string;
  engine_version: string;
  generated_at: string;
  source: {
    analysis_engine_version: string;
    analysis_generated_at: string;
    project_id: string;
    bundle_engine_matches: boolean;
  };
  sample: { analysable: number; respondents_total: number; completed: number; excluded: number };
  staleness: { stale: boolean; bundle_sample_n: number; current_sample_n: number; note: string };
  blocks: BlockLike[];
  caveats: string[];
  notes: string[];
}

interface DescriptiveVariableLike {
  variable: string;
  label: string;
  dimension: string;
  data_type: string;
  n: number;
  mean: number | null;
  frequencies: { value: string; label: string; count: number; percent: number }[] | null;
}

interface BundleLike {
  engine_version: string;
  generated_at: string;
  sample: { analysable: number; excluded: number };
  dataset_summary: { variables: { name: string }[] };
  descriptive: { variables: DescriptiveVariableLike[] };
  correlation: { pairs: { left: string; right: string; r: number | null; p_value: number | null }[] } | null;
  regression: { auto_selection: { model: string }; ordinal: unknown; ols: unknown } | null;
  comparisons: { dependent: string }[];
  hypotheses: { results: { code: string }[] };
  caveats: string[];
}

interface QualityLike {
  scored_respondents: number;
  mean_score: number | null;
  flagged_samples: unknown[];
  excluded_samples: unknown[];
}

interface TargetUserLike {
  sample_size: { analysable: number; excluded: number };
  channels: { source: string; total: number; percent_of_sample: number }[];
  demographics: {
    variable: string;
    label: string;
    data_type: string;
    n: number;
    mean: null;
    mean_note: string;
    categories: { value: string; label: string; count: number; percent: number }[];
  }[];
  primary_segment: { variable: string; category: string; count: number; percent: number } | null;
  sampling_limitation: string;
  quality_context: { available: boolean; note: string; flagged_samples: number | null };
}

interface PainPointsLike {
  metric: string;
  ranking: {
    rank: number;
    variable: string;
    label: string;
    mean: number;
    severity: number;
    direction: string;
    n: number;
    source: string;
  }[];
  fed_overall: { variable: string; mean: number | null; n: number } | null;
  information_environment: {
    overall: { mean: number | null; n: number };
    items: { variable: string; mean: number | null; n: number }[];
  } | null;
  knowledge: {
    subjective: { mean: number | null } | null;
    objective: { mean: number | null } | null;
    indicative_gap_percentage_points: number | null;
    note: string;
  } | null;
  excluded_from_ranking: { variable: string; reason: string }[];
}

interface ServiceGapLike {
  metric: string;
  demand: { overall: { mean: number | null; n: number }; items: { variable: string; mean: number | null; n: number }[] };
  provision: {
    awareness_access: { mean: number | null; n: number } | null;
    use_evaluation: { mean: number | null; n: number } | null;
  };
  gaps: { id: string; label: string; formula: string; value: number; note: string }[];
  largest_item_contrast: {
    variable: string;
    demand_mean: number;
    provision_mean: number;
    gap: number;
  } | null;
  caveat: string;
}

interface ProductDemandLike {
  metric: string;
  overall: { mean: number | null; n: number };
  items: { rank: number; variable: string; label: string; mean: number; n: number }[];
  scale_midpoint: number;
  breadth_only: { variable: string; note: string } | null;
  qualitative_material: { available: boolean; note: string };
}

interface TrustLike {
  overall: { mean: number | null; n: number };
  providers: { rank: number; variable: string; label: string; mean: number; n: number }[];
  ai_assistant: { variable: string; mean: number; rank: number; of: number } | null;
  adoption_link: { available: boolean; reason: string | null; pairs: unknown[]; hypothesis: unknown };
  prerequisite_statement: string;
}

interface AiAcceptanceLike {
  intention: {
    outcome: { variable: string; n: number; data_type: string };
    distribution: { value: string; label: string; count: number; percent: number }[];
    mean_reference: number | null;
    scale_note: string;
  } | null;
  perceived_value: { mean: number | null; n: number } | null;
  risk: { overall: { mean: number | null; n: number }; items: { variable: string; mean: number | null }[] } | null;
  modelling: { auto_selected_model: string | null; drivers: { term: string; b: number }[]; note: string };
  risk_link: { hypothesis_code: string; verdict: string; note: string } | null;
}

interface WtpLike {
  willingness: {
    outcome: { n: number; data_type: string };
    distribution: { value: string; label: string; count: number; percent: number }[];
    mean_reference: number | null;
    scale_note: string;
  } | null;
  amount_band: { variable: string; distribution: unknown[]; note: string } | null;
  demand_link: { available: boolean; reason: string | null };
  purchase_behaviour_caveat: string;
}

interface MarketOpportunityLike {
  inference_label: string;
  sample_scope: { analysable: number; note: string };
  drivers: { source: string; name: string; statistic: string; value: number; p_value: number | null }[];
  not_confirmed: { name: string; statistic: string; p_value: number | null; verdict: string | null; note: string }[];
  demand_ranking: { rank: number; variable: string; label: string; mean: number; n: number }[];
  segment_findings: { dependent: string; factor: string; p_value: number | null }[];
  market_size_estimate: { available: false; amount: null; currency: null; reason: string };
  what_would_be_needed: string[];
  bounded_conclusion: string;
}

/* ================================================================== */
/* Fixture                                                            */
/* ================================================================== */

const SAMPLE_SIZE = 32;
const NARROW_SAMPLE_SIZE = 6;

interface InsightFixture {
  token: string;
  projectId: string;
  respondents: string[];
}

let ctx: TestContext;
let full: InsightFixture;
let narrow: InsightFixture;
let emptyProjectId: string;

before(async () => {
  ctx = await createInsightTestContext();
  const researcher = await registerResearcher(ctx, { name: '创业洞察研究者' });

  const collect = async (
    questions: Record<string, unknown>[],
    title: string,
    size: number,
    generate: (rand: () => number, index: number) => GeneratedSample,
    seed: number,
  ): Promise<InsightFixture> => {
    const created = await createPublishedQuestionnaire(ctx, researcher.token, questions, title);
    const rand = lcg(seed);
    const respondents: string[] = [];
    for (let index = 0; index < size; index += 1) {
      const { answers } = generate(rand, index);
      const session = await startSession(ctx, created.shareToken, index % 3 === 0 ? 'wechat' : 'school');
      for (const [code, value] of Object.entries(answers)) {
        const saved = await saveAnswer(ctx, session.token, code, value);
        assert.equal(saved.status, 200, `${code} 保存失败：${JSON.stringify(saved.error)}`);
      }
      const submitted = await submitSession(ctx, session.token);
      assert.equal(submitted.status, 200, `提交失败：${JSON.stringify(submitted.error)}`);
      respondents.push(session.respondentId);
    }
    return { token: researcher.token, projectId: created.projectId, respondents };
  };

  full = await collect(INSTRUMENT, '创业洞察完整问卷研究', SAMPLE_SIZE, generateFullSample, 20260901);
  narrow = await collect(NARROW_INSTRUMENT, '创业洞察窄口径问卷研究', NARROW_SAMPLE_SIZE, generateNarrowSample, 20260902);

  // A third project with a questionnaire but no analysis run at all: the
  // competition view must refuse with a business error rather than an empty report.
  const third = await createPublishedQuestionnaire(
    ctx,
    researcher.token,
    [
      single('Q4', 'STAGE', '基本信息', STAGES, { type: 'categorical', codes: { '1': 1, '2': 2, '3': 3, '4': 4 } }),
      likert('Q6', 'FEI1', '家庭教育认知'),
    ],
    '创业洞察未分析项目',
  );
  emptyProjectId = third.projectId;

  // Real analysis runs: the competition view is derived from these bundles.
  for (const fixture of [full, narrow]) {
    const ran = await api(ctx, 'POST', `/api/projects/${fixture.projectId}/analysis/run`, {
      token: fixture.token,
    });
    assert.equal(ran.status, 200, `运行全部分析失败：${JSON.stringify(ran.error)}`);
  }
});

after(async () => {
  await ctx.close();
});

/* ================================================================== */
/* Helpers for assertions                                             */
/* ================================================================== */

function findBlock(report: ReportLike, key: string): BlockLike {
  const block = report.blocks.find((item) => item.key === key);
  assert.ok(block, `报告缺少区块 ${key}`);
  return block;
}

function blockPayload<T>(report: ReportLike, key: string): T {
  const block = findBlock(report, key);
  assert.equal(block.available, true, `区块 ${key} 应可用：${block.reason ?? ''}`);
  assert.ok(block.data, `区块 ${key} 可用时必须给出结构化数据`);
  return block.data as T;
}

/** Same display rule the service documents: integers verbatim, else two decimals. */
function formatNumber(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(2);
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

function variableOf(bundle: BundleLike, name: string): DescriptiveVariableLike {
  const found = [...bundle.descriptive.variables].reverse().find((item) => item.variable === name);
  assert.ok(found, `结果包缺少变量 ${name}`);
  return found;
}

function meanOf(bundle: BundleLike, name: string): number {
  const value = variableOf(bundle, name).mean;
  assert.ok(value !== null, `变量 ${name} 应有均值`);
  return value;
}

const BLOCK_KEYS = [
  'target_user',
  'pain_points',
  'current_solutions',
  'service_gap',
  'product_demand',
  'trust',
  'ai_acceptance',
  'willingness_to_pay',
  'market_opportunity',
];

/* ================================================================== */
/* Access control and preconditions                                   */
/* ================================================================== */

describe('创业洞察接口 · 权限与前置条件', () => {
  test('未登录无法访问创业洞察', async () => {
    const run = await api(ctx, 'POST', `/api/projects/${full.projectId}/competition/run`);
    assert.equal(run.status, 401);
    const report = await api(ctx, 'GET', `/api/projects/${full.projectId}/competition/report`);
    assert.equal(report.status, 401);
    const history = await api(ctx, 'GET', `/api/projects/${full.projectId}/competition/history`);
    assert.equal(history.status, 401);
  });

  test('他人项目不可见', async () => {
    const outsider = await registerResearcher(ctx, { name: '无关研究者' });
    const run = await api(ctx, 'POST', `/api/projects/${full.projectId}/competition/run`, {
      token: outsider.token,
    });
    assert.ok(run.status === 403 || run.status === 404, `意外的状态码 ${run.status}`);
    const report = await api(ctx, 'GET', `/api/projects/${full.projectId}/competition/report`, {
      token: outsider.token,
    });
    assert.ok(report.status === 403 || report.status === 404, `意外的状态码 ${report.status}`);
    const history = await api(ctx, 'GET', `/api/projects/${full.projectId}/competition/history`, {
      token: outsider.token,
    });
    assert.ok(history.status === 403 || history.status === 404, `意外的状态码 ${history.status}`);
  });

  test('尚未运行统计分析时给出 400 与中文提示', async () => {
    const response = await api<{ code: string; message: string }>(
      ctx,
      'POST',
      `/api/projects/${emptyProjectId}/competition/run`,
      { token: full.token },
    );
    assert.equal(response.status, 400, JSON.stringify(response.error));
    assert.ok(response.error, '必须返回错误对象');
    assert.ok(
      response.error.message.includes('统计分析'),
      `错误信息应说明需要先运行统计分析，实际：${response.error.message}`,
    );
    assert.ok(response.error.message.includes('创业洞察'));
  });

  test('尚未生成报告时如实返回不可用而非空报告', async () => {
    const response = await api<{ available: boolean; reason: string; blocks?: unknown }>(
      ctx,
      'GET',
      `/api/projects/${full.projectId}/competition/report`,
      { token: full.token },
    );
    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.available, false);
    assert.ok(response.data.reason.includes('创业洞察'), `原因应为中文说明：${response.data.reason}`);
    assert.equal(response.data.blocks, undefined, '不可用时不得给出任何区块数据');
  });
});

/* ================================================================== */
/* Persistence and audit trail                                        */
/* ================================================================== */

let report: ReportLike;
let bundle: BundleLike;
let quality: QualityLike;
let firstReportId = '';
let secondReportId = '';

describe('创业洞察报告 · 持久化与留痕', () => {
  test('运行两次各存一行，报告接口返回最新一份', async () => {
    const first = await api<ReportLike>(ctx, 'POST', `/api/projects/${full.projectId}/competition/run`, {
      token: full.token,
    });
    assert.equal(first.status, 200, JSON.stringify(first.error));
    assert.equal(first.data.available, true);
    assert.equal(first.data.run_seq, 1, '首次运行应为第 1 次');
    assert.ok(first.data.report_id.length > 0);
    assert.equal(first.data.blocks.length, 9);
    firstReportId = first.data.report_id;

    const second = await api<ReportLike>(ctx, 'POST', `/api/projects/${full.projectId}/competition/run`, {
      token: full.token,
    });
    assert.equal(second.status, 200, JSON.stringify(second.error));
    assert.equal(second.data.run_seq, 2, '第二次运行应递增序号');
    assert.notEqual(second.data.report_id, firstReportId, '两次运行必须各自留痕');
    secondReportId = second.data.report_id;

    const history = await api<{ blocks: Record<string, string>; items: { id: string; run_seq: number }[] }>(
      ctx,
      'GET',
      `/api/projects/${full.projectId}/competition/history`,
      { token: full.token },
    );
    assert.equal(history.status, 200, JSON.stringify(history.error));
    assert.equal(history.data.items.length, 2, '运行两次必须留下两行记录');
    assert.deepEqual(
      history.data.items.map((item) => item.run_seq),
      [2, 1],
      '历史应按运行顺序倒序返回',
    );
    assert.equal(history.data.items[0]!.id, secondReportId);

    // The report endpoint returns the latest persisted copy, not a rerun.
    const latest = await api<ReportLike>(ctx, 'GET', `/api/projects/${full.projectId}/competition/report`, {
      token: full.token,
    });
    assert.equal(latest.status, 200, JSON.stringify(latest.error));
    assert.equal(latest.data.available, true);
    assert.equal(latest.data.report_id, secondReportId);
    assert.equal(latest.data.run_seq, 2);
    report = latest.data;
  });

  test('历史留痕记录引擎版本与来源分析结果包', async () => {
    const history = await api<{
      items: {
        id: string;
        run_seq: number;
        engine_version: string;
        analysis_engine_version: string | null;
        analysis_generated_at: string | null;
        sample_n: number | null;
        blocks_total: number;
        blocks_available: number;
        created_at: string;
      }[];
    }>(ctx, 'GET', `/api/projects/${full.projectId}/competition/history`, { token: full.token });

    assert.equal(history.status, 200, JSON.stringify(history.error));
    assert.equal(history.data.items.length, 2);
    for (const row of history.data.items) {
      assert.equal(row.engine_version, '1.0.0');
      assert.equal(row.analysis_engine_version, '1.0.0', '必须记录所依据结果包的引擎版本');
      assert.ok(row.analysis_generated_at, '必须记录所依据结果包的生成时间');
      assert.equal(row.sample_n, SAMPLE_SIZE);
      assert.equal(row.blocks_total, 9);
      assert.ok(row.blocks_available > 0 && row.blocks_available <= 9);
      assert.ok(row.created_at.length > 0);
    }
  });
});

/* ================================================================== */
/* The nine blocks                                                    */
/* ================================================================== */

describe('创业洞察报告 · 九个区块', () => {
  before(async () => {
    const stored = await api<{ available: boolean } & BundleLike>(
      ctx,
      'GET',
      `/api/projects/${full.projectId}/analysis/bundle`,
      { token: full.token },
    );
    assert.equal(stored.status, 200, JSON.stringify(stored.error));
    assert.equal(stored.data.available, true, '分析结果包应已存在');
    bundle = stored.data;

    const qualityResponse = await api<QualityLike>(ctx, 'GET', `/api/projects/${full.projectId}/quality`, {
      token: full.token,
    });
    assert.equal(qualityResponse.status, 200, JSON.stringify(qualityResponse.error));
    quality = qualityResponse.data;
  });

  test('九个区块齐备，顺序固定，各自声明输入与可用性', () => {
    assert.deepEqual(
      report.blocks.map((block) => block.key),
      BLOCK_KEYS,
      '九个区块必须齐备且顺序固定',
    );
    assert.deepEqual(
      report.blocks.map((block) => block.order),
      [1, 2, 3, 4, 5, 6, 7, 8, 9],
    );

    for (const block of report.blocks) {
      assert.equal(typeof block.available, 'boolean', `${block.key} 必须明确声明 available`);
      assert.ok(block.title.length > 0, `${block.key} 必须有中文标题`);
      assert.ok(block.narrative.length > 0, `${block.key} 必须有中文叙述`);
      assert.ok(block.inputs.length > 0, `${block.key} 必须列出其依赖的输入`);
      assert.ok(Array.isArray(block.evidence), `${block.key} 必须带 evidence 数组`);
      if (block.available) {
        assert.equal(block.reason, null, `${block.key} 可用时不应给出不可用原因`);
        assert.ok(block.data, `${block.key} 可用时必须给出结构化数据`);
        assert.ok(block.evidence.length > 0, `${block.key} 可用时必须给出证据路径`);
      } else {
        assert.ok(block.reason && block.reason.length > 0, `${block.key} 不可用时必须说明原因`);
        assert.equal(block.data, null, `${block.key} 不可用时不得给出任何数据`);
        assert.equal(block.evidence.length, 0, `${block.key} 不可用时不得编造证据`);
      }
    }
  });

  test('每个区块的证据路径都能解析到它所引用的值（反造假检查）', () => {
    const roots = { bundle: bundle as unknown, quality: quality as unknown };
    let checked = 0;

    for (const block of report.blocks) {
      for (const entry of block.evidence) {
        const resolved = resolveEvidencePath(roots, entry.path);
        assert.notEqual(
          resolved,
          undefined,
          `区块 ${block.key} 引用了结果包中不存在的路径：${entry.path}`,
        );
        if (typeof entry.value === 'number') {
          assert.equal(typeof resolved, 'number', `${entry.path} 应为数值`);
          assert.ok(
            Math.abs((resolved as number) - entry.value) < 1e-9,
            `区块 ${block.key} 的证据值与该路径不一致：${entry.path} 报告 ${entry.value}，实际 ${String(resolved)}`,
          );
        } else {
          assert.deepEqual(
            resolved,
            entry.value,
            `区块 ${block.key} 的证据值与该路径不一致：${entry.path}`,
          );
        }
        checked += 1;
      }
    }

    assert.ok(checked > 60, `证据条目过少（${checked}），反造假检查意义不足`);
  });

  test('可用区块引用的均值与样本量都出现在中文叙述中', () => {
    for (const block of report.blocks) {
      if (!block.available) continue;
      for (const entry of block.evidence) {
        if (typeof entry.value !== 'number') continue;
        if (!entry.path.endsWith('.mean') && !entry.path.endsWith('.n')) continue;
        assert.ok(
          block.narrative.includes(formatNumber(entry.value)),
          `区块 ${block.key} 的叙述未包含 ${entry.path} 的值 ${formatNumber(entry.value)}`,
        );
      }
    }
  });

  test('中文叙述中不出现 undefined / NaN / null 等占位文本', () => {
    // Assembled prose is where a missing value silently becomes the string
    // "undefined"; the report must never reach a reader in that state.
    for (const block of report.blocks) {
      for (const text of [block.narrative, block.reason ?? '']) {
        assert.ok(
          !/undefined|NaN|\[object Object\]|null/.test(text),
          `区块 ${block.key} 的中文叙述含占位文本：${text.slice(0, 160)}`,
        );
      }
    }
  });

  test('目标用户区块按份额呈现学段构成，且名义变量不给均值', () => {
    const target = blockPayload<TargetUserLike>(report, 'target_user');

    assert.equal(target.sample_size.analysable, SAMPLE_SIZE);
    assert.equal(target.sample_size.excluded, 0);

    const stage = target.demographics.find((entry) => entry.variable === 'STAGE');
    assert.ok(stage, '目标用户区块必须包含学段构成');
    assert.equal(stage.n, SAMPLE_SIZE);
    assert.equal(stage.categories.length, STAGES.length);
    assert.equal(
      stage.categories.reduce((sum, category) => sum + category.count, 0),
      SAMPLE_SIZE,
      '分组频数应覆盖全部样本',
    );

    const totalPercent = stage.categories.reduce((sum, category) => sum + category.percent, 0);
    assert.ok(Math.abs(totalPercent - 100) < 0.5, `份额合计应接近 100，实际 ${totalPercent}`);

    // The engine refuses a mean for a nominal variable, and the block must not
    // invent one either: the field is present and explicitly null, with a note.
    assert.equal(stage.mean, null, '名义变量不得给出均值');
    assert.ok(stage.mean_note.includes('均值'), '必须说明为何不给均值');
    assert.equal(variableOf(bundle, 'STAGE').data_type, 'nominal');
    assert.equal(variableOf(bundle, 'STAGE').mean, null, '结果包本身也不应为名义变量计算均值');
    for (const entry of target.demographics) {
      assert.equal(entry.mean, null, `${entry.variable} 为人口学变量，不应报告均值`);
    }

    assert.ok(target.primary_segment, '必须给出占比最高的分组');
    assert.ok(target.sampling_limitation.includes('便利样本'));
    assert.ok(target.sampling_limitation.includes('不能'), '必须说明不可外推');
  });

  test('痛点排序与结果包中的条目均值一致', () => {
    const pain = blockPayload<PainPointsLike>(report, 'pain_points');

    const fedMeans = FED_ROWS.map((_, index) => meanOf(bundle, `FED${index + 1}`));
    const fedEntries = pain.ranking.filter((entry) => entry.source === 'FED_item');
    assert.equal(fedEntries.length, FED_ROWS.length, '七个困难条目都要进入排序');

    // Every entry quotes the bundle value, not a value of its own.
    for (const entry of fedEntries) {
      assert.equal(entry.mean, meanOf(bundle, entry.variable), `${entry.variable} 均值与结果包不一致`);
      assert.equal(entry.severity, entry.mean, '直接计分条目的严重程度就是其均值');
      assert.equal(entry.n, variableOf(bundle, entry.variable).n);
    }

    // The ranking is the descending sort of the measured values.
    const descending = [...fedEntries].sort((left, right) => right.mean - left.mean);
    assert.deepEqual(
      fedEntries.map((entry) => entry.variable),
      descending.map((entry) => entry.variable),
      '困难条目必须按均值从高到低排列',
    );

    // The generator makes the first difficulty row the hardest by a known margin.
    assert.equal(fedEntries[0]!.variable, 'FED1', '最突出的困难应为生成时设定最高的 FED1');
    assert.equal(pain.ranking[0]!.variable, 'FED1', '总体排序的第一名应为 FED1');

    // Knowledge is reverse-worded: severity must be the inverted reading, and the
    // raw mean must still be reported alongside it.
    const knowledgeEntry = pain.ranking.find((entry) => entry.source === 'FEK');
    assert.ok(knowledgeEntry, '知识缺口应进入排序');
    assert.equal(knowledgeEntry!.direction, 'reversed');
    const fekMean = meanOf(bundle, 'FEK');
    assert.equal(knowledgeEntry!.mean, fekMean, '原始均值必须如实报告');
    assert.equal(knowledgeEntry!.severity, round2(6 - fekMean));

    // Ranking order must match the reported severity everywhere.
    const severities = pain.ranking.map((entry) => entry.severity);
    for (let index = 1; index < severities.length; index += 1) {
      assert.ok(severities[index - 1]! >= severities[index]!, '排序必须与严重程度一致');
    }
    assert.ok(pain.metric.includes('严重程度'));

    assert.ok(pain.fed_overall, '应报告困难总体水平');
    assert.equal(pain.fed_overall!.mean, meanOf(bundle, 'FED'));
    assert.ok(pain.excluded_from_ranking.some((entry) => entry.variable === 'FED'), '必须说明为何 FED 不参与排序');

    // ISC item means must also be the bundle's values.
    assert.ok(pain.information_environment, '应报告信息环境困扰');
    assert.equal(pain.information_environment!.overall.mean, meanOf(bundle, 'ISC'));
    for (const item of pain.information_environment!.items) {
      assert.equal(item.mean, meanOf(bundle, item.variable));
    }
  });

  test('服务缺口的数值可由需求与供给均值复算', () => {
    const gap = blockPayload<ServiceGapLike>(report, 'service_gap');

    const demand = meanOf(bundle, 'DSD');
    const awareness = meanOf(bundle, 'PSA');
    const use = meanOf(bundle, 'PSU');

    assert.equal(gap.demand.overall.mean, demand);
    assert.equal(gap.demand.overall.n, variableOf(bundle, 'DSD').n);
    assert.equal(gap.provision.awareness_access?.mean, awareness);
    assert.equal(gap.provision.use_evaluation?.mean, use);

    const byId = new Map(gap.gaps.map((entry) => [entry.id, entry]));
    assert.equal(
      byId.get('demand_minus_awareness')!.value,
      round2(demand - awareness),
      '需求与知晓的差值必须可由两侧均值复算',
    );
    assert.equal(byId.get('demand_minus_use')!.value, round2(demand - use));
    assert.equal(byId.get('awareness_to_use_break')!.value, round2(awareness - use));

    // The stated formula must actually contain the numbers it is based on.
    for (const entry of gap.gaps) {
      assert.ok(entry.formula.includes(formatNumber(round2(entry.value))), `缺口公式应含其数值：${entry.formula}`);
      assert.ok(entry.note.length > 0, '每个缺口都必须说明口径限制');
    }

    assert.ok(gap.largest_item_contrast, '应给出最突出的单项对比');
    const contrast = gap.largest_item_contrast!;
    assert.equal(contrast.demand_mean, meanOf(bundle, contrast.variable));
    assert.equal(contrast.gap, round2(contrast.demand_mean - contrast.provision_mean));
    // Demand must be the strongest demand item in the bundle, not a hand-picked one.
    const demandItems = DSD_ROWS.map((_, index) => `DSD${index + 1}`);
    const strongest = demandItems.reduce((best, name) =>
      meanOf(bundle, name) > meanOf(bundle, best) ? name : best,
    );
    assert.equal(contrast.variable, strongest, '单项对比必须取需求最高的条目');
    assert.equal(strongest, 'DSD2', '生成数据中需求最高的是「在线专家咨询」');
    assert.ok(gap.metric.includes('均值差'), '必须写明所用指标');
    assert.ok(gap.caveat.includes('不是'), '必须声明缺口不等于供给不足的因果证明');
  });

  test('产品需求按条目均值排序，并引用结果包中的条目文本与样本量', () => {
    const demand = blockPayload<ProductDemandLike>(report, 'product_demand');

    assert.equal(demand.overall.mean, meanOf(bundle, 'DSD'));
    assert.equal(demand.items.length, DSD_ROWS.length);
    for (const item of demand.items) {
      assert.equal(item.mean, meanOf(bundle, item.variable), `${item.variable} 需求均值与结果包不一致`);
      assert.equal(item.n, variableOf(bundle, item.variable).n);
      assert.equal(item.label, variableOf(bundle, item.variable).label, '条目文本必须取自结果包');
    }
    const means = demand.items.map((item) => item.mean);
    for (let index = 1; index < means.length; index += 1) {
      assert.ok(means[index - 1]! >= means[index]!, '产品需求必须按均值从高到低排序');
    }
    assert.equal(demand.items[0]!.variable, 'DSD2', '生成数据中需求最高的服务类型应为 DSD2');
    assert.ok(demand.breadth_only, '多选题只能报告广度，必须说明');
    assert.ok(demand.breadth_only!.note.includes('不能'), '不得把广度当作各服务类型占比');
    assert.equal(demand.qualitative_material.available, false, '本问卷无开放式文字题');
  });

  test('信任排序引用测量值，并把 AI 助手信任单独列出', () => {
    const trust = blockPayload<TrustLike>(report, 'trust');

    assert.equal(trust.providers.length, STI_ROWS.length);
    for (const provider of trust.providers) {
      assert.equal(provider.mean, meanOf(bundle, provider.variable));
      assert.equal(provider.label, variableOf(bundle, provider.variable).label);
    }
    const means = trust.providers.map((provider) => provider.mean);
    for (let index = 1; index < means.length; index += 1) {
      assert.ok(means[index - 1]! >= means[index]!, '信任度必须按测量值排序');
    }
    assert.equal(trust.providers[0]!.variable, 'STI1', '生成数据中政府部门信任度最高');

    assert.ok(trust.ai_assistant, 'AI 智能助手信任必须单独列出');
    assert.equal(trust.ai_assistant!.variable, 'STI6');
    assert.equal(trust.ai_assistant!.mean, meanOf(bundle, 'STI6'));
    assert.equal(trust.ai_assistant!.of, STI_ROWS.length);
    assert.equal(trust.ai_assistant!.rank, STI_ROWS.length, '生成数据中 AI 助手信任度最低');

    // Trust is framed as a prerequisite, and whether it moves demand must be
    // claimed only when the bundle actually measured it.
    assert.ok(trust.prerequisite_statement.includes('前置条件'));
    if (trust.adoption_link.available) {
      assert.ok(trust.adoption_link.pairs.length > 0 || trust.adoption_link.hypothesis !== null);
    } else {
      assert.ok(trust.adoption_link.reason && trust.adoption_link.reason.length > 0);
    }
  });

  test('AI 接受度以有序结果为框架，分布与系数均来自结果包', () => {
    const ai = blockPayload<AiAcceptanceLike>(report, 'ai_acceptance');

    assert.ok(ai.intention, '必须给出使用意愿');
    assert.equal(ai.intention!.outcome.variable, 'UI');
    assert.equal(ai.intention!.outcome.data_type, 'ordinal', 'UI 在引擎中是测量层次为有序的变量');
    assert.equal(ai.intention!.outcome.n, variableOf(bundle, 'UI').n);
    assert.equal(ai.intention!.mean_reference, variableOf(bundle, 'UI').mean);
    assert.equal(
      ai.intention!.distribution.reduce((sum, category) => sum + category.count, 0),
      variableOf(bundle, 'UI').n,
      '类别分布应覆盖全部有效样本',
    );

    // The framing must keep the ordinal reading and refuse interval language.
    assert.ok(ai.intention!.scale_note.includes('有序'), '必须说明 UI 为有序变量');
    assert.ok(ai.intention!.scale_note.includes('等距'), '必须拒绝把类别编码当作等距刻度');

    assert.ok(ai.perceived_value, '必须给出感知价值');
    assert.equal(ai.perceived_value!.mean, meanOf(bundle, 'AIPV'));

    assert.ok(ai.risk, '必须给出风险认知');
    assert.equal(ai.risk!.overall.mean, meanOf(bundle, 'PRC'));
    assert.equal(ai.risk!.items.length, PRC_ROWS.length);
    for (const item of ai.risk!.items) {
      assert.equal(item.mean, meanOf(bundle, item.variable));
    }

    assert.equal(ai.modelling.auto_selected_model, 'ordinal_logit', 'UI 为有序因变量，引擎应选择有序模型');
    assert.ok(ai.modelling.drivers.length > 0, '必须给出有序模型的系数');
    assert.ok(ai.modelling.note.includes('有序'), '必须说明以哪个模型为主要结论');

    if (ai.risk_link) {
      assert.equal(ai.risk_link.hypothesis_code, 'H7');
      assert.ok(
        ['supported', 'not_supported', 'inconclusive'].includes(ai.risk_link.verdict),
        `假设结论必须落在三态之内：${ai.risk_link.verdict}`,
      );
      if (ai.risk_link.verdict === 'inconclusive') {
        assert.ok(ai.risk_link.note.includes('证据不足'), '证据不足不得表述为「已证明无关」');
        assert.ok(ai.risk_link.note.includes('不等于'), '必须写明不等于证明无关');
      }
    }
  });

  test('付费意愿如实呈现分布，并声明意愿不等于购买行为', () => {
    const wtp = blockPayload<WtpLike>(report, 'willingness_to_pay');

    assert.ok(wtp.willingness, '必须给出付费意愿分布');
    assert.equal(wtp.willingness!.outcome.data_type, 'ordinal');
    assert.equal(wtp.willingness!.outcome.n, variableOf(bundle, 'WTP').n);
    assert.equal(
      wtp.willingness!.distribution.reduce((sum, category) => sum + category.count, 0),
      variableOf(bundle, 'WTP').n,
      '意愿分布应覆盖全部有效样本',
    );
    assert.ok(wtp.willingness!.scale_note.includes('等距'), '必须拒绝把意愿等级当作等距刻度');

    assert.ok(wtp.amount_band, '必须给出支付区间分布');
    assert.ok(wtp.amount_band!.note.includes('中值'), '必须说明不使用区间中值换算金额');
    assert.ok(wtp.purchase_behaviour_caveat.includes('不是观察到的购买行为'));
    assert.ok(wtp.demand_link.available || (wtp.demand_link.reason ?? '').length > 0);
  });

  test('市场机会只给出有依据的推断，并拒绝任何货币规模', () => {
    const market = blockPayload<MarketOpportunityLike>(report, 'market_opportunity');

    assert.ok(market.inference_label.includes('推断'), '必须明确标注为推断');
    assert.ok(market.inference_label.includes('不是市场规模估算'));
    assert.equal(market.sample_scope.analysable, SAMPLE_SIZE);
    assert.ok(market.sample_scope.note.includes('不能'), '必须说明便利样本不可外推');

    // Every driver must be a significant result the bundle actually contains.
    for (const driver of market.drivers) {
      assert.ok(driver.statistic.length > 0, `${driver.name} 必须给出统计量`);
      if (driver.p_value !== null) {
        assert.ok(driver.p_value < 0.05, `${driver.name} 被列为机会依据，但 p 未达显著`);
      }
    }

    // Not-confirmed results must be visible rather than dropped: an inconclusive
    // hypothesis is evidence of absence of evidence, not of absence.
    for (const entry of market.not_confirmed) {
      if (entry.verdict === 'inconclusive') {
        assert.ok(entry.note.includes('证据不足'));
      }
    }

    assert.ok(market.demand_ranking.length > 0, '应引用需求最强的条目');
    assert.equal(market.demand_ranking[0]!.mean, meanOf(bundle, market.demand_ranking[0]!.variable));
    assert.equal(market.demand_ranking[0]!.variable, 'DSD2');

    // The refusal itself is part of the artefact.
    assert.equal(market.market_size_estimate.available, false);
    assert.equal(market.market_size_estimate.amount, null);
    assert.equal(market.market_size_estimate.currency, null);
    assert.ok(market.market_size_estimate.reason.includes('货币规模'));
    assert.ok(market.what_would_be_needed.length >= 3);
    assert.ok(market.bounded_conclusion.includes('不能支持的结论'));
  });

  test('必备声明与继承的方法学限制都在报告里', () => {
    for (const statement of REQUIRED_CAVEATS) {
      assert.ok(
        report.caveats.includes(statement),
        `报告缺少必备声明：${statement.slice(0, 20)}…`,
      );
    }
    assert.ok(report.caveats.some((caveat) => caveat.includes('非概率') || caveat.includes('便利')));
    assert.ok(report.caveats.some((caveat) => caveat.includes('因果')));
    assert.ok(report.caveats.length >= REQUIRED_CAVEATS.length + 1);
    assert.ok(report.staleness.stale === false, '结果包与当前样本应一致');
    assert.equal(report.source.analysis_engine_version, bundle.engine_version);
    assert.equal(report.source.bundle_engine_matches, true);
    assert.ok(report.notes.some((note) => note.includes('结果包')), '必须说明数字来源');
    assert.ok(
      report.notes.some((note) => note.includes('PSU1')),
      '变量名重复必须被如实披露',
    );
  });
});

/* ================================================================== */
/* Honest refusal when the instrument does not measure it              */
/* ================================================================== */

describe('创业洞察报告 · 输入缺失时如实返回不可用', () => {
  test('窄口径问卷下，需求/信任/AI/付费相关区块全部不可用且不给数字', async () => {
    const sealed = await api<ReportLike>(ctx, 'POST', `/api/projects/${narrow.projectId}/competition/run`, {
      token: narrow.token,
    });
    assert.equal(sealed.status, 200, JSON.stringify(sealed.error));
    const narrowReport = sealed.data;

    for (const key of [
      'current_solutions',
      'service_gap',
      'product_demand',
      'trust',
      'ai_acceptance',
      'willingness_to_pay',
      'market_opportunity',
    ]) {
      const block = findBlock(narrowReport, key);
      assert.equal(block.available, false, `区块 ${key} 应标记为不可用`);
      assert.ok(block.reason && block.reason.length > 0, `区块 ${key} 必须给出中文原因`);
      assert.equal(block.data, null, `区块 ${key} 不可用时不得给出任何数据`);
      assert.equal(block.evidence.length, 0, `区块 ${key} 不可用时不得给出任何证据`);
      assert.ok(block.narrative.includes('不可用'), `区块 ${key} 的叙述必须说明不可用`);
      // The reason must name what is missing, not merely say "no data".
      assert.ok(
        /DSD|WTP|STI|UI|PRC|AIPV|PSA|PSU|FIUA|FIUT|供给方|需求/.test(block.reason!),
        `区块 ${key} 的原因应点明缺少哪些变量：${block.reason}`,
      );
    }

    // The blocks that CAN be answered from a narrow instrument still work.
    const target = blockPayload<TargetUserLike>(narrowReport, 'target_user');
    const stage = target.demographics.find((entry) => entry.variable === 'STAGE');
    assert.ok(stage, '窄口径问卷仍应给出学段构成');
    assert.equal(stage!.mean, null);

    const pain = findBlock(narrowReport, 'pain_points');
    assert.equal(pain.available, true, '知识自评仍可构成痛点证据');
    const painData = pain.data as unknown as PainPointsLike;
    assert.deepEqual(
      painData.ranking.map((entry) => entry.variable),
      ['FEK'],
      '仅有知识自评可用时，排序中只应有它',
    );
    assert.ok(painData.knowledge, '应给出知识自评');
    assert.equal(painData.knowledge!.objective, null, '无客观知识题时不得给出客观均值');
    assert.equal(painData.knowledge!.indicative_gap_percentage_points, null, '不得编造知识缺口数值');
    assert.ok(painData.knowledge!.note.includes('无法对照'));

    // The missing variable must be visible in the block's own input probe.
    const fedProbe = pain.inputs.find((entry) => entry.name === 'FED');
    assert.ok(fedProbe, '痛点区块必须声明 FED 输入');
    assert.equal(fedProbe!.available, false);
    assert.ok((fedProbe!.note ?? '').length > 0);
  });

  test('窄口径问卷下产品需求区块的原因点明缺少 DSD 且不引用行业数据', async () => {
    const stored = await api<ReportLike>(ctx, 'GET', `/api/projects/${narrow.projectId}/competition/report`, {
      token: narrow.token,
    });
    assert.equal(stored.status, 200, JSON.stringify(stored.error));
    const block = findBlock(stored.data, 'product_demand');
    assert.equal(block.available, false);
    assert.ok(block.reason!.includes('DSD'));
    assert.ok(block.narrative.includes('不以行业报告'), '必须声明不用外部数据替代');
  });
});
