/**
 * Regression analysis (PHASE 6).
 *
 * The engine decides which estimator the outcome calls for and explains why, so
 * the page's job is to honour that decision: when the outcome is ordinal the
 * proportional-odds model is presented FIRST and labelled 主要结论, and the OLS
 * fit is demoted to a clearly-marked comparison. Forcing an ordinal outcome
 * through OLS violates the equidistance assumption and can predict values
 * outside the scale's range, which is exactly the mistake the layout prevents.
 *
 * Nothing below the coefficient tables is optional: VIF, the residual
 * diagnostics and the proportional-odds test are all shown, because a
 * coefficient without them is not something a reader can evaluate.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { RegressionPlot } from '../../components/charts';
import { Alert, Badge, Card, CardHeader, LoadingBlock } from '../../components/ui';
import {
  api,
  ApiClientError,
  type AnalysisRegressionBlock,
  type AnalysisRegressionResponse,
  type OlsResult,
  type OrdinalLogitResult,
} from '../../lib/api';
import { formatNumber, formatPValue, formatStat, significanceMark } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  UnavailableNotice,
  unavailableReason,
  useAnalysisProject,
} from './shared';

function OlsBlock({ ols, primary }: { ols: OlsResult; primary: boolean }): ReactNode {
  const significant = ols.coefficients.filter((item) => item.p_value < 0.05);

  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={primary ? 'info' : 'neutral'}>{primary ? '主要结论' : '对照结果'}</Badge>
        <span className="text-sm text-ink-600">
          {`因变量 ${ols.dependent_label}（${ols.dependent}）× 自变量 ${ols.predictors.join('、')}`}
        </span>
      </div>

      <p className="mt-3 font-mono text-sm text-ink-800">{ols.equation}</p>
      <p className="mt-2 text-sm leading-relaxed text-ink-700">{ols.interpretation}</p>

      <dl className="mt-4 grid gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">有效样本 n</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatNumber(ols.n)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">R²</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatStat(ols.r_squared, 4)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">调整后 R²</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatStat(ols.adjusted_r_squared, 4)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">估计标准误</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatStat(ols.standard_error_estimate, 4)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">F 检验</dt>
          <dd className="mt-1 tabular-nums text-ink-800">
            {`F(${ols.degrees_of_freedom_model}, ${ols.degrees_of_freedom_residual}) = ${formatStat(ols.f_statistic, 3)}`}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">模型显著性</dt>
          <dd className="mt-1 tabular-nums text-ink-800">{formatPValue(ols.f_p_value)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">多元相关 R</dt>
          <dd className="mt-1 tabular-nums text-ink-800">{formatStat(ols.r, 4)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">显著预测变量</dt>
          <dd className="mt-1 tabular-nums text-ink-800">
            {significant.length}/{ols.coefficients.length}
          </dd>
        </div>
      </dl>

      {ols.dropped_predictors.length > 0 && (
        <p className="mt-3 text-xs text-amber-700">
          以下自变量因方差为零被剔除，未进入模型：{ols.dropped_predictors.join('、')}。
        </p>
      )}
      {ols.dropped_cases > 0 && (
        <p className="mt-1 text-xs text-amber-700">
          有 {ols.dropped_cases} 例样本因在模型变量上存在缺失而被整例删除（未插补）。
        </p>
      )}

      <div className="mt-5 overflow-x-auto">
        <table className="w-full min-w-[860px] text-sm">
          <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-3 py-2 text-left">预测变量</th>
              <th className="px-3 py-2 text-right">B</th>
              <th className="px-3 py-2 text-right">标准误</th>
              <th className="px-3 py-2 text-right">β</th>
              <th className="px-3 py-2 text-right">t</th>
              <th className="px-3 py-2 text-left">p</th>
              <th className="px-3 py-2 text-right">95% CI（B）</th>
              <th className="px-3 py-2 text-right">VIF</th>
              <th className="px-3 py-2 text-right">容差</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {ols.coefficients.map((item) => (
              <tr key={item.term}>
                <td className="px-3 py-2">
                  <span className="text-ink-900">{item.label}</span>
                  <span className="ml-2 font-mono text-[11px] text-ink-500">{item.term}</span>
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-900">{formatStat(item.b, 4)}</td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                  {formatStat(item.standard_error, 4)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-800">{formatStat(item.beta, 4)}</td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">{formatStat(item.t, 3)}</td>
                <td className="px-3 py-2 text-xs text-ink-700">
                  {formatPValue(item.p_value)} {significanceMark(item.p_value)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                  {`[${formatStat(item.ci_lower, 3)}, ${formatStat(item.ci_upper, 3)}]`}
                </td>
                <td
                  className={`px-3 py-2 text-right tabular-nums ${
                    item.vif !== null && item.vif > 5 ? 'text-amber-700' : 'text-ink-700'
                  }`}
                >
                  {formatStat(item.vif, 3)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                  {formatStat(item.tolerance, 3)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-5">
        <h3 className="mb-2 text-sm font-medium text-ink-800">系数森林图（B 与 95% 置信区间）</h3>
        <RegressionPlot
          coefficients={ols.coefficients.map((item) => ({
            label: item.label,
            estimate: item.b,
            ciLower: item.ci_lower,
            ciUpper: item.ci_upper,
            beta: item.beta,
            pValue: item.p_value,
            vif: item.vif,
          }))}
          estimateLabel="非标准化系数 B"
        />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">残差诊断</h3>
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-xs uppercase tracking-wide text-ink-500">Durbin–Watson</dt>
              <dd className="mt-1 tabular-nums text-ink-800">
                {formatStat(ols.diagnostics.durbin_watson, 3)}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-ink-500">残差偏度</dt>
              <dd className="mt-1 tabular-nums text-ink-800">
                {formatStat(ols.diagnostics.residual_skewness, 3)}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-ink-500">残差峰度</dt>
              <dd className="mt-1 tabular-nums text-ink-800">
                {formatStat(ols.diagnostics.residual_kurtosis, 3)}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-ink-500">最大标准化残差</dt>
              <dd className="mt-1 tabular-nums text-ink-800">
                {formatStat(ols.diagnostics.max_abs_standardized_residual, 3)}
              </dd>
            </div>
          </dl>
          <p className="mt-2 text-xs leading-relaxed text-ink-500">
            Durbin–Watson 接近 2 表示残差无自相关（横截面数据一般应接近 2）；残差偏度绝对值大于 1
            提示残差分布偏离正态；标准化残差绝对值大于 3 的样本被视为离群点。
          </p>
          {ols.diagnostics.outliers.length > 0 && (
            <ul className="mt-2 space-y-1 text-xs text-amber-800">
              {ols.diagnostics.outliers.map((outlier) => (
                <li key={outlier.respondent_id}>
                  离群样本 {outlier.respondent_id}：标准化残差 {formatStat(outlier.standardised_residual, 3)}
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">共线性与提示</h3>
          {ols.collinearity_warnings.length === 0 ? (
            <p className="text-sm text-ink-600">
              未发现 VIF 超过警戒阈值的自变量（常用警戒值：VIF &gt; 5 需关注，VIF &gt; 10 视为严重共线性）。
            </p>
          ) : (
            <ul className="list-disc space-y-1 pl-4 text-sm text-amber-800">
              {ols.collinearity_warnings.map((warning) => (
                <li key={warning.term}>
                  {warning.term}：VIF = {formatStat(warning.vif, 3)}，标准误被共线性放大，系数不稳定。
                </li>
              ))}
            </ul>
          )}
          {ols.warnings.length > 0 && (
            <ul className="mt-3 list-disc space-y-1 pl-4 text-xs text-amber-800">
              {ols.warnings.map((warning) => (
                <li key={warning}>{warning}</li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </>
  );
}

function OrdinalBlock({ ordinal, primary }: { ordinal: OrdinalLogitResult; primary: boolean }): ReactNode {
  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={primary ? 'info' : 'neutral'}>{primary ? '主要结论' : '对照结果'}</Badge>
        <span className="text-sm text-ink-600">
          {`有序因变量 ${ordinal.dependent_label}（${ordinal.dependent}），共 ${ordinal.categories.length} 个类别`}
        </span>
      </div>

      <p className="mt-3 text-sm leading-relaxed text-ink-700">{ordinal.interpretation}</p>

      <dl className="mt-4 grid gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">有效样本 n</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatNumber(ordinal.n)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">似然比 χ²</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatStat(ordinal.lr_chi_square, 3)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">LR 检验自由度</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{ordinal.lr_degrees_of_freedom}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">LR 检验显著性</dt>
          <dd className="mt-1 tabular-nums text-lg text-ink-900">{formatPValue(ordinal.lr_p_value)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">McFadden 伪 R²</dt>
          <dd className="mt-1 tabular-nums text-ink-800">{formatStat(ordinal.mcfadden_r_squared, 4)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">Nagelkerke R²</dt>
          <dd className="mt-1 tabular-nums text-ink-800">{formatStat(ordinal.nagelkerke_r_squared, 4)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">分类正确率</dt>
          <dd className="mt-1 tabular-nums text-ink-800">
            {ordinal.percent_correct === null ? '—' : `${formatStat(ordinal.percent_correct, 2)}%`}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">迭代与收敛</dt>
          <dd className="mt-1 text-ink-800">
            {`${ordinal.iterations} 次 · ${ordinal.converged ? '已收敛' : '未收敛（结果不可信，建议检查数据）'}`}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">−2 对数似然（模型 / 空模型）</dt>
          <dd className="mt-1 tabular-nums text-ink-800">
            {`${formatStat(ordinal.minus2_log_likelihood, 3)} / ${formatStat(ordinal.minus2_log_likelihood_null, 3)}`}
          </dd>
        </div>
      </dl>

      {ordinal.dropped_predictors.length > 0 && (
        <p className="mt-3 text-xs text-amber-700">
          以下自变量因方差为零被剔除：{ordinal.dropped_predictors.join('、')}。
        </p>
      )}
      {ordinal.dropped_cases > 0 && (
        <p className="mt-1 text-xs text-amber-700">
          有 {ordinal.dropped_cases} 例样本因在模型变量上存在缺失而被整例删除（未插补）。
        </p>
      )}

      <div className="mt-5 overflow-x-auto">
        <h3 className="mb-2 text-sm font-medium text-ink-800">系数（对数优势 b 与优势比 OR）</h3>
        <table className="w-full min-w-[900px] text-sm">
          <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-3 py-2 text-left">预测变量</th>
              <th className="px-3 py-2 text-right">b（对数优势）</th>
              <th className="px-3 py-2 text-right">标准误</th>
              <th className="px-3 py-2 text-right">Wald z</th>
              <th className="px-3 py-2 text-left">p</th>
              <th className="px-3 py-2 text-right">OR = exp(b)</th>
              <th className="px-3 py-2 text-right">OR 95% CI</th>
              <th className="px-3 py-2 text-right">b 95% CI</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {ordinal.coefficients.map((item) => (
              <tr key={item.term}>
                <td className="px-3 py-2">
                  <span className="text-ink-900">{item.label}</span>
                  <span className="ml-2 font-mono text-[11px] text-ink-500">{item.term}</span>
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-900">{formatStat(item.b, 4)}</td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                  {formatStat(item.standard_error, 4)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">{formatStat(item.z, 3)}</td>
                <td className="px-3 py-2 text-xs text-ink-700">
                  {formatPValue(item.p_value)} {significanceMark(item.p_value)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-900">
                  {formatStat(item.odds_ratio, 4)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                  {`[${formatStat(item.odds_ratio_ci_lower, 3)}, ${formatStat(item.odds_ratio_ci_upper, 3)}]`}
                </td>
                <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                  {`[${formatStat(item.ci_lower, 3)}, ${formatStat(item.ci_upper, 3)}]`}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-2 text-xs leading-relaxed text-ink-500">
          比例优势模型假设各自变量对"跨越任一分界"的作用相同，因此每个自变量只有一个 b 与一个 OR；
          OR &gt; 1 表示该变量取值上升时，因变量落入更高类别的优势上升。OR 的 95% CI 不含 1 等价于 p &lt; 0.05。
        </p>
      </div>

      <div className="mt-5">
        <h3 className="mb-2 text-sm font-medium text-ink-800">系数森林图（b 与 95% 置信区间）</h3>
        <RegressionPlot
          coefficients={ordinal.coefficients.map((item) => ({
            label: item.label,
            estimate: item.b,
            ciLower: item.ci_lower,
            ciUpper: item.ci_upper,
            pValue: item.p_value,
            oddsRatio: item.odds_ratio,
          }))}
          estimateLabel="对数优势系数 b"
        />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div className="overflow-x-auto">
          <h3 className="mb-2 text-sm font-medium text-ink-800">阈值（分界点）</h3>
          <table className="w-full min-w-[420px] text-sm">
            <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-3 py-2 text-left">分界</th>
                <th className="px-3 py-2 text-right">阈值 α</th>
                <th className="px-3 py-2 text-right">标准误</th>
                <th className="px-3 py-2 text-right">z</th>
                <th className="px-3 py-2 text-left">p</th>
                <th className="px-3 py-2 text-right">95% CI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {ordinal.thresholds.map((threshold, index) => (
                <tr key={`threshold-${index}`}>
                  <td className="px-3 py-2 text-ink-800">{threshold.label}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-900">
                    {formatStat(threshold.threshold, 4)}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                    {formatStat(threshold.standard_error, 4)}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-700">{formatStat(threshold.z, 3)}</td>
                  <td className="px-3 py-2 text-xs text-ink-700">{formatPValue(threshold.p_value)}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                    {`[${formatStat(threshold.ci_lower, 3)}, ${formatStat(threshold.ci_upper, 3)}]`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-2 text-xs text-ink-500">
            阈值为累积 logit 的分界常数，通常不作为解释重点，但必须报告以便复核模型。
          </p>
        </div>

        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">因变量类别分布</h3>
          <table className="w-full text-sm">
            <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-3 py-2 text-left">取值</th>
                <th className="px-3 py-2 text-left">标签</th>
                <th className="px-3 py-2 text-right">频数</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {ordinal.categories.map((category) => (
                <tr key={category.value}>
                  <td className="px-3 py-2 tabular-nums text-ink-800">{category.value}</td>
                  <td className="px-3 py-2 text-ink-800">{category.label}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-800">{category.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-2 text-xs text-ink-500">
            类别过少或某一类别样本极少时，阈值估计会不稳定，收敛性与标准误需一并检查。
          </p>
        </div>
      </div>

      <div className="mt-5">
        <h3 className="mb-2 text-sm font-medium text-ink-800">比例优势假设检验</h3>
        <dl className="grid grid-cols-3 gap-3 text-sm">
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">χ²</dt>
            <dd className="mt-1 tabular-nums text-ink-800">
              {formatStat(ordinal.proportional_odds_test.chi_square, 3)}
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">自由度</dt>
            <dd className="mt-1 tabular-nums text-ink-800">{ordinal.proportional_odds_test.degrees_of_freedom}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">显著性</dt>
            <dd className="mt-1 tabular-nums text-ink-800">
              {formatPValue(ordinal.proportional_odds_test.p_value)}
            </dd>
          </div>
        </dl>
        <p className="mt-2 text-sm leading-relaxed text-ink-700">
          {ordinal.proportional_odds_test.interpretation}
        </p>
      </div>

      {ordinal.warnings.length > 0 && (
        <div className="mt-4">
          <Alert tone="warning" title="模型提示">
            <ul className="list-disc space-y-1 pl-4">
              {ordinal.warnings.map((warning) => (
                <li key={warning}>{warning}</li>
              ))}
            </ul>
          </Alert>
        </div>
      )}
    </>
  );
}

export function RegressionPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisRegressionResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setData(await api.analysis.regression(projectId));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载回归分析结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const reason = unavailableReason(data);
  const block: AnalysisRegressionBlock | null = data && data.available ? data : null;
  const ordinalPrimary = block?.auto_selection.model === 'ordinal_logit' && block.ordinal !== null;

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Regression"
          subtitle="回归分析：引擎的模型选择、系数估计、拟合优度与残差诊断。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在拟合回归模型…" />
        ) : !data ? null : reason ? (
          <UnavailableNotice reason={reason} title="无法进行回归分析" />
        ) : !block ? null : (
          <>
            <Card>
              <CardHeader
                title="模型选择结论"
                description="引擎根据因变量的测量层次与取值分布自动选择估计方法，并说明理由。"
                actions={
                  <Badge tone={block.auto_selection.model === 'ordinal_logit' ? 'info' : 'success'}>
                    {block.auto_selection.model === 'ordinal_logit' ? '有序 Logistic 回归' : 'OLS 线性回归'}
                  </Badge>
                }
              />
              <p className="text-sm leading-relaxed text-ink-800">{block.auto_selection.reason}</p>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{block.recommendation}</p>
              <MethodNote title="报告时应写明的模型设定">
                <p>
                  因变量：{block.ols?.dependent_label ?? block.ordinal?.dependent_label ?? '—'}；
                  自变量：{(block.ols?.predictors ?? block.ordinal?.predictors ?? []).join('、') || '—'}。
                </p>
                <p>
                  缺失值采用整例删除，不做插补；因此各模型的有效 n 可能不同，本文所有统计量均以各自报告的 n 为准。
                  回归系数只描述自变量与因变量在数据中的条件关联，横截面数据不支持因果解释。
                </p>
              </MethodNote>
            </Card>

            {ordinalPrimary && block.ordinal && (
              <Card>
                <CardHeader
                  title="有序 Logistic 回归（比例优势模型）"
                  description="因变量为有序分类变量时，本模型是更合适的估计方法，应作为主要结论报告。"
                />
                <OrdinalBlock ordinal={block.ordinal} primary />
              </Card>
            )}

            {block.ols && (
              <Card>
                <CardHeader
                  title="OLS 线性回归"
                  description={
                    ordinalPrimary
                      ? '以下为对照结果。因变量为有序分类变量，线性模型会违反等距假设，请勿以此作为主要结论。'
                      : '因变量测量层次适合线性模型，以下为本次分析的主要结果。'
                  }
                />
                <OlsBlock ols={block.ols} primary={!ordinalPrimary} />
              </Card>
            )}

            {!block.ols && !block.ordinal && (
              <Alert tone="warning" title="没有可用的回归结果">
                引擎未能拟合任何回归模型（可能是自变量全部缺失或有效样本不足），请检查数据收集情况。
              </Alert>
            )}
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
