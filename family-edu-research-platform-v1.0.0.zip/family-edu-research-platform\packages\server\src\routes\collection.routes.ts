/**
 * Sample management routes (PHASE 3, researcher-facing).
 *
 *   GET  /api/projects/:projectId/respondents              — paged sample list
 *   POST /api/projects/:projectId/respondents/sweep        — mark stale sessions abandoned
 *   GET  /api/projects/:projectId/sources                  — channel breakdown
 *   GET  /api/respondents/:respondentId                    — one sample, all answers
 *   POST /api/respondents/:respondentId/review             — researcher decision
 *
 * Mounted at two prefixes so project-scoped and sample-scoped paths cannot
 * shadow one another in Express's matcher.
 */

import { Router } from 'express';
import type { ReviewStatus } from '@ferp/shared';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import {
  getRespondentDetail,
  reviewRespondent,
  sweepAbandonedSessions,
} from '../services/collection.service.js';
import { getSourceBreakdown, listRespondents } from '../services/sample.service.js';
import { requireProject } from '../services/project.service.js';
import { asyncHandler } from '../util/errors.js';

export interface CollectionRouterContext {
  db: Db;
  config: Config;
}

/* ================================================================== */
/* Project-scoped: sample list, sweep, channel breakdown              */
/* ================================================================== */

export function createSampleRouter(ctx: CollectionRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  router.get(
    '/:projectId/respondents',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const query = req.query;
      res.json({
        data: listRespondents(ctx.db, req.params['projectId']!, researcher.id, {
          status: typeof query['status'] === 'string' ? query['status'] : undefined,
          source: typeof query['source'] === 'string' ? query['source'] : undefined,
          reviewStatus: typeof query['review_status'] === 'string' ? query['review_status'] : undefined,
          qualitySeverity:
            typeof query['quality_severity'] === 'string' ? query['quality_severity'] : undefined,
          flaggedOnly: query['flagged_only'] === 'true',
          search: typeof query['search'] === 'string' ? query['search'] : undefined,
          from: typeof query['from'] === 'string' ? query['from'] : undefined,
          to: typeof query['to'] === 'string' ? query['to'] : undefined,
          limit: query['limit'] !== undefined ? Number(query['limit']) : undefined,
          offset: query['offset'] !== undefined ? Number(query['offset']) : undefined,
        }),
      });
    }),
  );

  /**
   * Explicitly mark stale in-progress sessions as abandoned.
   * Deliberately a POST a researcher triggers, not a side effect of reading.
   */
  router.post(
    '/:projectId/respondents/sweep',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const hours = typeof body['older_than_hours'] === 'number' ? body['older_than_hours'] : 24;
      res.json({ data: sweepAbandonedSessions(ctx.db, projectId, Math.max(1, hours)) });
    }),
  );

  router.get(
    '/:projectId/sources',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      res.json({
        data: getSourceBreakdown(ctx.db, req.params['projectId']!, researcher.id),
      });
    }),
  );

  return router;
}

/* ================================================================== */
/* Sample-scoped: detail and review                                   */
/* ================================================================== */

export function createRespondentRouter(ctx: CollectionRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  router.get(
    '/:respondentId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      res.json({
        data: getRespondentDetail(ctx.db, req.params['respondentId']!, researcher.id),
      });
    }),
  );

  router.post(
    '/:respondentId/review',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const status = (typeof body['status'] === 'string' ? body['status'] : 'unreviewed') as ReviewStatus;
      res.json({
        data: reviewRespondent(ctx.db, {
          respondentId: req.params['respondentId']!,
          researcherId: researcher.id,
          status,
          note: typeof body['note'] === 'string' ? body['note'] : null,
        }),
      });
    }),
  );

  return router;
}
