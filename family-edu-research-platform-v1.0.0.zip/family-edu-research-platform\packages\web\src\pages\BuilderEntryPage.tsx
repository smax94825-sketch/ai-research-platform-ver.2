import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Badge, Button, Card, EmptyState, LoadingBlock } from '../components/ui';
import {
  api,
  ApiClientError,
  type ProjectListResult,
  type Questionnaire,
} from '../lib/api';
import { formatDate, questionnaireStatusMeta } from '../lib/format';

interface ProjectWithQuestionnaires {
  projectId: string;
  projectTitle: string;
  questionnaires: Questionnaire[];
}

/** Entry point for the "Builder" nav item: pick which questionnaire to edit. */
export function BuilderEntryPage(): ReactNode {
  const [data, setData] = useState<ProjectWithQuestionnaires[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load(): Promise<void> {
      setLoading(true);
      setError(null);
      try {
        const list: ProjectListResult = await api.projects.list({ limit: 200 });
        const grouped = await Promise.all(
          list.items.map(async (project) => ({
            projectId: project.id,
            projectTitle: project.title,
            questionnaires: await api.projects.questionnaires(project.id),
          })),
        );
        if (!cancelled) setData(grouped);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiClientError ? err.message : '无法加载问卷列表。');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <LoadingBlock label="正在加载问卷…" />;
  if (error) {
    return (
      <Alert tone="danger" title="加载失败">
        {error}
      </Alert>
    );
  }

  const withQuestionnaires = (data ?? []).filter((item) => item.questionnaires.length > 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-ink-900">Questionnaire Builder</h1>
        <p className="mt-1 text-sm text-ink-500">
          选择一个问卷进入构建器。构建器提供题目管理、逻辑编辑、实时预览与发布（分享链接与二维码）。
        </p>
      </div>

      {withQuestionnaires.length === 0 ? (
        <EmptyState
          title="还没有可编辑的问卷"
          description="请先创建研究项目，并按模板载入问卷或新建空白问卷。"
          action={
            <Link to="/projects/new">
              <Button variant="primary">新建研究项目</Button>
            </Link>
          }
        />
      ) : (
        <div className="space-y-4">
          {withQuestionnaires.map((group) => (
            <Card key={group.projectId}>
              <div className="mb-3 flex items-center justify-between gap-3">
                <h2 className="text-sm font-semibold text-ink-900">{group.projectTitle}</h2>
                <Link to={`/projects/${group.projectId}`} className="text-xs text-brand-600 hover:underline">
                  项目详情 →
                </Link>
              </div>
              <ul className="divide-y divide-ink-100">
                {group.questionnaires.map((questionnaire) => {
                  const meta = questionnaireStatusMeta(questionnaire.status);
                  return (
                    <li
                      key={questionnaire.id}
                      className="flex flex-wrap items-center justify-between gap-3 py-3"
                    >
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-xs text-ink-500">{questionnaire.version}</span>
                          <span className="text-sm text-ink-900">{questionnaire.title}</span>
                          <Badge tone={meta.tone}>{meta.label}</Badge>
                          {questionnaire.is_current && <Badge tone="info">当前</Badge>}
                          {questionnaire.locked && <Badge tone="warning">已锁定</Badge>}
                        </div>
                        <p className="mt-1 text-xs text-ink-500">
                          更新于 {formatDate(questionnaire.updated_at)}
                        </p>
                      </div>
                      <Link
                        to={`/projects/${group.projectId}/questionnaires/${questionnaire.id}/builder`}
                      >
                        <Button variant="primary">打开构建器</Button>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
