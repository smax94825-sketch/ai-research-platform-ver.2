/**
 * Platform ethics defaults.
 *
 * The consent statement is a research-ethics requirement, not a nice-to-have.
 * A project created without explicit settings must still present an accurate
 * statement to respondents, so the platform falls back to this text rather than
 * showing nothing. The wording is deliberately conservative: it states what the
 * platform actually does, and nothing more.
 */

export const PLATFORM_DEFAULT_CONSENT =
  '本研究为匿名调查。参与完全自愿，您可以拒绝回答任何问题，也可以随时退出。' +
  '调查数据仅用于学术研究与项目分析，不会收集姓名、身份证号、精确住址、学校名称、手机号等' +
  '可识别个人身份的信息。继续填写即表示您已了解并同意上述说明。';

/** Bullet points rendered on the consent screen. */
export const PLATFORM_ETHICS_POINTS: readonly string[] = [
  '本研究为匿名调查，不会收集您的姓名、手机号、身份证号、精确住址或学校名称。',
  '参与完全自愿，您可以拒绝回答任何问题，也可以中途退出。',
  '敏感题目提供「不愿回答」选项，选择它不会影响您的参与。',
  '数据仅用于研究统计与项目分析，不会用于任何商业推销。',
  '您可以随时关闭页面，已填写的内容会在本机保留，重新打开链接可以继续。',
];

/**
 * Questions the platform must never ask.
 *
 * Enforced by validation and surfaced in the UI, so a researcher cannot
 * accidentally turn an anonymous instrument into an identifying one.
 */
export const FORBIDDEN_IDENTITY_PATTERNS: readonly { pattern: RegExp; label: string }[] = [
  { pattern: /身份证/, label: '身份证号' },
  { pattern: /手机|电话|联系方式/, label: '手机号／联系方式' },
  { pattern: /家庭住址|详细地址|门牌/, label: '精确住址' },
  { pattern: /学生姓名|孩子姓名|儿童姓名/, label: '子女姓名' },
  { pattern: /学校名称|就读学校/, label: '学校名称' },
  { pattern: /银行卡|账号密码/, label: '财务账号' },
];
