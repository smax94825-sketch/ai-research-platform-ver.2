/**
 * Database CLI: migrate / seed / reset / status.
 *
 *   npm run db:migrate -w @ferp/server
 *   npm run db:seed    -w @ferp/server
 *   npm run db:reset   -w @ferp/server   (drops everything, then migrates)
 *
 * The seed creates a demo researcher account and one project with the official
 * V4.0 instrument. It deliberately creates NO responses: fabricated sample data
 * would undermine the platform's guarantee that every reported number comes
 * from real collected data.
 */

import { randomBytes } from 'node:crypto';

import { loadConfig } from '../config.js';
import { Db } from './index.js';
import { appliedMigrations, dropAllTables, listTables, migrate } from './migrate.js';
import { registerResearcher, findResearcherByEmail } from '../services/researcher.service.js';
import { createProjectFromDefaultTemplate } from '../services/project.service.js';

const DEMO_EMAIL_DEFAULT = 'demo@ferp.local';

/**
 * Demo account credentials.
 *
 * The password is deliberately NOT a literal in this file: a password committed
 * to source is a published password, and one written into a README is published
 * twice over. It is local configuration — `SEED_DEMO_PASSWORD` presets it (for
 * example from a local, untracked env file), and otherwise one is generated and
 * printed once, locally, when the account is created.
 */
function resolveDemoEmail(env: NodeJS.ProcessEnv = process.env): string {
  return env['SEED_DEMO_EMAIL']?.trim() || DEMO_EMAIL_DEFAULT;
}

/**
 * Generate a password that satisfies the account policy (≥ 8 characters, and at
 * least one letter and one digit). The `Aa1` prefix guarantees the policy holds
 * whatever the random draw happens to produce.
 */
function generateDemoPassword(): string {
  const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const drawn = Array.from(randomBytes(17), (byte) => alphabet[byte % alphabet.length]!);
  return `Aa1${drawn.join('')}`;
}

function status(db: Db): void {
  const migrations = appliedMigrations(db);
  console.log(`已应用迁移（${migrations.length}）:`);
  for (const row of migrations) {
    console.log(`  - ${row.id}  ${row.name}  @ ${row.applied_at}`);
  }
  const tables = listTables(db);
  console.log(`数据表（${tables.length}）: ${tables.join(', ')}`);
}

function seed(db: Db): void {
  const demoEmail = resolveDemoEmail();

  if (findResearcherByEmail(db, demoEmail)) {
    console.log(`示例研究者账号已存在：${demoEmail}`);
    console.log('  出于安全考虑不在此处显示密码；如需重设，请用 SEED_DEMO_PASSWORD 指定后重建该账号。');
  } else {
    const preset = process.env['SEED_DEMO_PASSWORD']?.trim();
    const password = preset && preset.length > 0 ? preset : generateDemoPassword();
    registerResearcher(db, {
      name: '示例研究者',
      email: demoEmail,
      password,
      affiliation: '家庭教育研究课题组',
    });
    console.log(`已创建示例研究者账号：${demoEmail}`);
    console.log(`  密码：${password}`);
    console.log(
      preset && preset.length > 0
        ? '  （来自 SEED_DEMO_PASSWORD，请自行妥善保存）'
        : '  （本次随机生成，仅打印这一次，请立即保存；也可用 SEED_DEMO_PASSWORD 预设）',
    );
  }

  const owner = findResearcherByEmail(db, demoEmail);
  if (!owner) {
    console.error('无法定位示例研究者账号，跳过示例项目创建。');
    return;
  }

  const projectCount = Number(
    db.scalar<number>('SELECT COUNT(*) AS n FROM research_projects WHERE researcher_id = ?', [owner.id]) ??
      0,
  );
  if (projectCount > 0) {
    console.log(`示例研究者已有 ${projectCount} 个研究项目，跳过项目创建。`);
    return;
  }

  const result = createProjectFromDefaultTemplate(db, owner.id);
  console.log(
    `已创建示例研究项目「${result.project.title}」，包含 ${result.seeded_questions} 道题目的问卷。`,
  );
  console.log('提示：示例项目不会自动生成任何受访者数据，请通过问卷链接真实收集。');
}

function main(): void {
  const command = process.argv[2] ?? 'migrate';
  const config = loadConfig();
  const db = new Db(config.databasePath);

  try {
    switch (command) {
      case 'migrate': {
        const result = migrate(db);
        console.log(`数据库: ${config.databasePath}`);
        console.log(`新应用迁移: ${result.applied.length > 0 ? result.applied.join(', ') : '（无）'}`);
        console.log(`已跳过迁移: ${result.skipped.length > 0 ? result.skipped.join(', ') : '（无）'}`);
        status(db);
        break;
      }
      case 'seed': {
        migrate(db);
        seed(db);
        break;
      }
      case 'reset': {
        dropAllTables(db);
        console.log('已删除全部数据表。');
        const result = migrate(db);
        console.log(`已重新应用迁移: ${result.applied.join(', ')}`);
        status(db);
        break;
      }
      case 'status': {
        status(db);
        break;
      }
      default:
        console.error(`未知命令: ${command}`);
        console.error('可用命令: migrate | seed | reset | status');
        process.exitCode = 1;
    }
  } finally {
    db.close();
  }
}

main();
