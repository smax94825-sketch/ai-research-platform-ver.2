/**
 * Competition Mode / entrepreneurship insight tests (PHASE 9).
 *
 * This page is the easiest place on the platform to overclaim, so the tests
 * check the four guards the page is supposed to hold:
 *   1. all nine blocks render, in the `order` the API reports (not fixture order),
 *   2. a block with `available: false` shows its Chinese reason as a refusal,
 *   3. the market-opportunity block carries the "this sample only, not a market
 *      size" statement, and `market_size_estimate` renders as a refusal with no
 *      amount at all — in particular not 0,
 *   4. the four mandatory caveats lead the caveat list, and a stale bundle is
 *      disclosed rather than hidden.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { click, flush, queryAll, render, text } from './render';

const { CompetitionPage } = await import('../src/pages/competition/CompetitionPage');

/* ================================================================== */
/* Fixtures                                                           */
/* ================================================================== */

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育投入研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'analyzing',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

const SAMPLE = {
  respondents_total: 500,
  completed: 400,
  in_progress: 70,
  abandoned: 30,
  excluded: 50,
  analysable: 350,
  rows_loaded: 350,
  sources: [
    { source: 'wechat', total: 300 },
    { source: 'school', total: 200 },
  ],
};

const REQUIRED_CAVEATS = [
  '本报告基于非概率（便利）抽样得到的家长样本，样本构成受投放渠道影响，不能代表任何总体，也不构成市场规模估计。',
  '所有变量间关系均为横截面共变关系，不能据此推断因果；「驱动因素」在此仅指统计上显著的关联，不是因果机制。',
  '问卷测量的是「声称的付费意愿」，不等于实际购买行为；未发生支付，也未测量价格弹性与竞争替代。',
  'AI 接受度是当前时点的态度测量，态度会随产品、政策与使用经验变化，不能据此预测未来的实际采用率。',
];

const CAVEATS = [
  ...REQUIRED_CAVEATS,
  '本报告基于 350 份有效样本；各统计量另有其自身的有效 n，解读时应以各区块与结果包中报告的 n 为准。',
  '本研究采用横截面问卷调查数据，所有关联结论均为变量间的共变关系，不能据此推断因果关系。',
];

const MARKET_SIZE_REASON =
  '本报告不给出任何货币规模：数据集里没有价格、成本、付费转化、市场容量或购买行为，' +
  '声称的付费意愿分档也不足以推算收入（区间中值不是测量值）。给出一个金额，无论区间多宽，都是在数据之外添加假设。';

const INFERENCE_LABEL =
  '以下内容是基于本样本统计结果的推断，属于机会假设，不是市场规模估算，也不是对总体市场的描述。';

const NO_REPORT_REASON =
  '尚未生成创业洞察报告。请先运行「运行全部分析」得到统计结果包，再执行「生成创业洞察」；' +
  '创业洞察的所有数字都来自该结果包，不会独立计算。';

interface BlockFixture {
  key: string;
  order: number;
  title: string;
  available: boolean;
  reason: string | null;
  narrative: string;
  data: unknown;
  inputs: { name: string; role: 'primary' | 'supporting'; available: boolean; note: string | null }[];
  evidence: { path: string; value: unknown }[];
}

/**
 * The nine blocks, declared out of order on purpose: the page must render them by
 * `order`, and a client that trusted array order would fail the ordering test.
 */
const BLOCKS: BlockFixture[] = [
  {
    key: 'market_opportunity',
    order: 9,
    title: '市场机会',
    available: true,
    reason: null,
    narrative:
      '以下为基于本样本的推断（不是市场规模估算）。本样本中统计显著、可作为机会假设依据的关系：DSD：有序 Logistic 系数 B = 0.74，p = < 0.001。市场规模：不给出。' +
      MARKET_SIZE_REASON,
    data: {
      inference_label: INFERENCE_LABEL,
      sample_scope: {
        analysable: 350,
        note:
          '推断的样本范围仅为本次分析的有效样本 350 份；便利样本不能按人口结构加权，' +
          '因此任何「放大到某地区」的推算都缺乏依据。',
      },
      drivers: [
        {
          source: 'ordinal_logit',
          name: 'DSD',
          statistic: '有序 Logistic 系数 B = 0.74（OR = 2.1）',
          value: 0.742,
          p_value: 0.0001,
          effect: null,
          note: '在有序模型中与使用意愿显著相关（p = < 0.001），方向为正向。',
        },
      ],
      not_confirmed: [
        {
          name: 'STI',
          statistic: '有序 Logistic 系数 B = -0.12（OR = 0.886）',
          value: -0.121,
          p_value: 0.246,
          verdict: null,
          note: '在有序模型中未达显著（p = 0.246），不作为机会假设的证据。',
        },
      ],
      demand_ranking: [
        { rank: 1, variable: 'DSD3', label: '在线课程与学习资源推荐', mean: 4.12, n: 344 },
      ],
      segment_findings: [
        {
          dependent: 'FED',
          factor: 'STAGE',
          p_value: 0.0244,
          statistic: 'Kruskal–Wallis H = 7.42（ε² = 0.0155）',
          effect: '效应量小（ε² = 0.016）',
          recommended: 'nonparametric',
        },
      ],
      market_size_estimate: {
        available: false,
        amount: null,
        currency: null,
        reason: MARKET_SIZE_REASON,
      },
      what_would_be_needed: [
        '目标人群的总体规模与家庭结构分布（本问卷未采集，且便利样本无法外推）。',
        '真实的价格与支付行为数据（订单、续费、退款），而不是声称的付费意愿。',
      ],
      bounded_conclusion:
        '可以支持的结论是：在本样本中，上述显著相关变量共同指向「需求强度、服务信任与使用意愿之间存在可测量的关联」，' +
        '这为产品方向提供了有待验证的假设。不能支持的结论包括：市场规模、收入预测、用户增长曲线，' +
        '以及任何以「本样本 X% 」乘以外部分母得到的数字。',
    },
    inputs: [
      { name: 'regression', role: 'primary', available: true, note: null },
      { name: 'correlation', role: 'primary', available: true, note: null },
      { name: 'comparisons', role: 'supporting', available: true, note: null },
      { name: 'DSD', role: 'supporting', available: true, note: null },
    ],
    evidence: [
      { path: 'regression.ordinal.coefficients[DSD].b', value: 0.742 },
      { path: 'regression.ordinal.coefficients[DSD].p_value', value: 0.0001 },
      { path: 'descriptive.variables[DSD3].mean', value: 4.12 },
    ],
  },
  {
    key: 'willingness_to_pay',
    order: 8,
    title: '付费意愿',
    available: true,
    reason: null,
    narrative: '本样本中 WTP 的均值为 2.86（n = 342），属于「声称的付费意愿」，不是实际购买行为。',
    data: {
      willingness: {
        outcome: { variable: 'WTP', label: '付费意愿', data_type: 'ordinal', n: 342, mean: 2.86 },
        data_type: 'ordinal',
        distribution: [
          { value: '1', label: '完全不愿意', count: 96, percent: 28.07 },
          { value: '3', label: '一般', count: 130, percent: 38.01 },
          { value: '5', label: '非常愿意', count: 42, percent: 12.28 },
        ],
        mean_reference: 2.86,
        scale_note: '五级有序量表，均值仅作参考，结论以有序 Logistic 回归为主。',
      },
      amount_band: {
        variable: 'WTP2',
        label: '可接受的价格区间',
        distribution: [
          { value: '1', label: '0—50 元/月', count: 152, percent: 44.44 },
          { value: '2', label: '51—100 元/月', count: 110, percent: 32.16 },
        ],
        note: '区间中值不是测量值，不能用于收入推算。',
      },
      demand_link: {
        available: true,
        reason: null,
        pair: { left: 'DSD', right: 'WTP', r: 0.31, p_value: 0.0042, method: 'spearman', n: 338 },
        hypothesis: {
          code: 'H4',
          statement: '数字化服务需求越高，付费意愿越强。',
          verdict: 'supported',
          r: 0.31,
          p_value: 0.0042,
          n: 338,
          conclusion: '数据支持该假设：显著的正向相关。',
        },
      },
      purchase_behaviour_caveat: '未发生支付，也未测量价格弹性与竞争替代；付费意愿不能直接用于定价。',
    },
    inputs: [{ name: 'WTP', role: 'primary', available: true, note: null }],
    evidence: [
      { path: 'descriptive.variables[WTP].mean', value: 2.86 },
      { path: 'correlation.pairs[left=DSD,right=WTP].r', value: 0.31 },
    ],
  },
  {
    key: 'target_user',
    order: 1,
    title: '目标用户',
    available: true,
    reason: null,
    narrative: '本样本以「小学」学段家长为主（占 42.86%）。样本来自便利投放，不能代表任何总体。',
    data: {
      sample_size: {
        respondents_total: 500,
        completed: 400,
        analysable: 350,
        excluded: 50,
        in_progress: 70,
        abandoned: 30,
      },
      channels: [
        { source: 'wechat', total: 300, percent_of_sample: 60 },
        { source: 'school', total: 200, percent_of_sample: 40 },
      ],
      demographics: [
        {
          variable: 'STAGE',
          label: '孩子学段',
          data_type: 'nominal',
          n: 350,
          mean: null,
          mean_note: '名义变量不给均值：对类别编码求均值没有意义。',
          categories: [
            { value: '1', label: '学前', count: 120, percent: 34.29 },
            { value: '2', label: '小学', count: 150, percent: 42.86 },
            { value: '3', label: '初中', count: 80, percent: 22.86 },
          ],
        },
      ],
      primary_segment: { variable: 'STAGE', label: '孩子学段', category: '小学', count: 150, percent: 42.86 },
      sampling_limitation: '便利样本不能按人口结构加权，任何「放大到某地区」的推算都缺乏依据。',
      quality_context: {
        available: true,
        note: '质量引擎已评分，可作为样本可信度的参考。',
        scored_respondents: 350,
        mean_score: 92.4,
        flagged_samples: 18,
      },
    },
    inputs: [
      { name: 'STAGE', role: 'primary', available: true, note: null },
      { name: 'quality', role: 'supporting', available: true, note: null },
    ],
    evidence: [
      { path: 'sample.analysable', value: 350 },
      { path: 'descriptive.variables[STAGE].n', value: 350 },
    ],
  },
  {
    key: 'pain_points',
    order: 2,
    title: '痛点',
    available: true,
    reason: null,
    narrative: '困难程度最高的一项是「学业辅导困难」（均值 3.82，n = 348）。',
    data: {
      metric: '严重度（越高表示困难越突出）',
      ranking: [
        {
          rank: 1,
          variable: 'FED1',
          label: '学业辅导困难',
          mean: 3.82,
          severity: 3.82,
          direction: 'direct',
          n: 348,
          source: 'FED_item',
          note: null,
        },
        {
          rank: 2,
          variable: 'FED4',
          label: '亲子沟通困难',
          mean: 3.41,
          severity: 3.41,
          direction: 'direct',
          n: 344,
          source: 'FED_item',
          note: null,
        },
      ],
      fed_overall: { variable: 'FED', label: '家庭教育困难', data_type: 'interval', n: 349, mean: 3.66 },
      information_environment: {
        overall: { variable: 'ISC', label: '信息搜寻', data_type: 'interval', n: 340, mean: 3.12 },
        items: [{ variable: 'ISC1', label: '主动搜寻教育信息', data_type: 'interval', n: 340, mean: 3.45 }],
      },
      knowledge: {
        subjective: { variable: 'FEK', label: '家庭教育知识（自评）', data_type: 'interval', n: 346, mean: 3.71 },
        objective: { variable: 'FEKO', label: '家庭教育知识（客观）', data_type: 'interval', n: 342, mean: 2.98 },
        indicative_gap_percentage_points: 14.6,
        note: '自评高于客观测量，属于指示性差距，不是能力差距的直接证据。',
      },
      excluded_from_ranking: [
        { variable: 'PSU', reason: '该变量测量的是服务使用，不是困难程度。' },
      ],
    },
    inputs: [
      { name: 'FED', role: 'primary', available: true, note: null },
      { name: 'ISC', role: 'supporting', available: false, note: '问卷未测量信息搜寻行为（ISC）。' },
    ],
    evidence: [
      { path: 'descriptive.variables[FED].mean', value: 3.66 },
      { path: 'descriptive.variables[FED1].mean', value: 3.82 },
      { path: 'descriptive.variables[FEK].mean', value: 3.71 },
    ],
  },
  {
    key: 'current_solutions',
    order: 3,
    title: '现有解决方案',
    available: false,
    reason:
      '问卷没有测量任何供给方（学校、社区、机构、内容平台）的知晓、获取或使用情况，' +
      '因此无法描述家长现在用什么；平台不会用行业经验填补。',
    narrative:
      '本区块不可用：结果包中没有供给方的测量，因此没有可依据的数字，本报告不描述现有解决方案。',
    data: null,
    inputs: [
      { name: 'PSA', role: 'primary', available: false, note: '问卷未测量公共服务知晓（PSA）。' },
      { name: 'PSU', role: 'primary', available: false, note: '问卷未测量公共服务使用（PSU）。' },
    ],
    evidence: [],
  },
  {
    key: 'service_gap',
    order: 4,
    title: '服务缺口',
    available: true,
    reason: null,
    narrative: '需求与供给之间的缺口在本样本中为 0.74 分（需求 3.86 − 供给 3.12）。',
    data: {
      metric: '缺口 = 需求均值 − 供给均值',
      demand: {
        overall: { variable: 'DSD', label: '数字化服务需求', data_type: 'interval', n: 344, mean: 3.86 },
        items: [{ variable: 'DSD3', label: '在线课程与学习资源推荐', data_type: 'interval', n: 344, mean: 4.12 }],
      },
      provision: {
        awareness_access: { variable: 'PSA', label: '公共服务知晓与获取', data_type: 'interval', n: 340, mean: 3.12 },
        use_evaluation: null,
      },
      gaps: [
        {
          id: 'demand_vs_access',
          label: '需求高于知晓与获取',
          formula: 'DSD.mean − PSA.mean',
          value: 0.74,
          note: '缺口为正表示需求高于供给，数值仅适用于本样本。',
        },
      ],
      largest_item_contrast: {
        variable: 'DSD3',
        label: '在线课程与学习资源推荐',
        demand_mean: 4.12,
        provision_mean: 3.12,
        gap: 1,
      },
      caveat: '缺口是两组自评均值之差，不是服务供给能力的测量。',
    },
    inputs: [
      { name: 'DSD', role: 'primary', available: true, note: null },
      { name: 'PSA', role: 'primary', available: true, note: null },
    ],
    evidence: [
      { path: 'descriptive.variables[DSD].mean', value: 3.86 },
      { path: 'descriptive.variables[PSA].mean', value: 3.12 },
    ],
  },
  {
    key: 'product_demand',
    order: 5,
    title: '产品需求',
    available: true,
    reason: null,
    narrative: '需求最强的一项为「在线课程与学习资源推荐」（均值 4.12，n = 344）。',
    data: {
      metric: '需求均值（1—5）',
      overall: { variable: 'DSD', label: '数字化服务需求', data_type: 'interval', n: 344, mean: 3.86 },
      items: [
        { rank: 1, variable: 'DSD3', label: '在线课程与学习资源推荐', mean: 4.12, n: 344, above_scale_midpoint: true },
        { rank: 2, variable: 'DSD1', label: '个性化学习方案', mean: 3.94, n: 346, above_scale_midpoint: true },
      ],
      scale_midpoint: 3,
      breadth_only: { variable: 'DSD', label: '数字化服务需求', note: '只有总体广度测量，未展开功能粒度。' },
      qualitative_material: {
        available: false,
        note: '问卷未采集开放题文本，无法补充质性材料。',
      },
      note: '需求均值高于量表中点只表示意愿方向，不代表付费与使用行为。',
    },
    inputs: [{ name: 'DSD', role: 'primary', available: true, note: null }],
    evidence: [{ path: 'descriptive.variables[DSD3].mean', value: 4.12 }],
  },
  {
    key: 'trust',
    order: 6,
    title: '信任',
    available: true,
    reason: null,
    narrative: '服务主体信任度 STI 的均值为 3.52（n = 341），AI 助手在 5 个主体中排第 4。',
    data: {
      overall: { variable: 'STI', label: '服务主体信任度', data_type: 'interval', n: 341, mean: 3.52 },
      providers: [
        { rank: 1, variable: 'STI1', label: '学校', mean: 4.02, n: 342 },
        { rank: 4, variable: 'STI4', label: 'AI 助手', mean: 3.18, n: 338 },
      ],
      ai_assistant: { variable: 'STI4', label: 'AI 助手', mean: 3.18, n: 338, rank: 4, of: 5 },
      adoption_link: {
        available: true,
        reason: null,
        pairs: [{ left: 'STI', right: 'UI', r: 0.44, p_value: 0.0002, method: 'spearman', n: 339 }],
        regression: [{ term: 'STI', model: 'ordinal_logit', b: 0.386, p_value: 0.0004 }],
        hypothesis: {
          code: 'H5',
          statement: '服务主体信任度越高，使用意向越强。',
          verdict: 'supported',
          r: 0.44,
          p_value: 0.0002,
          n: 339,
          conclusion: '数据支持该假设：显著的正向相关。',
        },
      },
      prerequisite_statement: '信任是接受度的前提条件，但信任水平本身不构成使用行为。',
    },
    inputs: [
      { name: 'STI', role: 'primary', available: true, note: null },
      { name: 'UI', role: 'primary', available: true, note: null },
    ],
    evidence: [
      { path: 'descriptive.variables[STI].mean', value: 3.52 },
      { path: 'correlation.pairs[left=STI,right=UI].r', value: 0.44 },
    ],
  },
  {
    key: 'ai_acceptance',
    order: 7,
    title: 'AI 接受度',
    available: true,
    reason: null,
    narrative: '使用意愿 UI 的均值为 3.71（n = 342），结论以有序 Logistic 回归为主。',
    data: {
      intention: {
        outcome: { variable: 'UI', label: 'AI 服务使用意愿', data_type: 'ordinal', n: 342, mean: 3.71 },
        data_type: 'ordinal',
        distribution: [
          { value: '1', label: '完全不同意', count: 20, percent: 5.85 },
          { value: '4', label: '比较同意', count: 118, percent: 34.5 },
          { value: '5', label: '完全同意', count: 60, percent: 17.54 },
        ],
        mean_reference: 3.71,
        scale_note: '五级有序量表；均值仅作参考，不以均值代替有序模型结论。',
      },
      perceived_value: {
        variable: 'AIPV',
        label: 'AI 感知价值',
        data_type: 'interval',
        n: 340,
        mean: 3.64,
        distribution: null,
      },
      risk: {
        overall: { variable: 'PRC', label: '风险认知', data_type: 'interval', n: 339, mean: 3.42 },
        items: [{ variable: 'PRC1', label: '担心隐私泄露', data_type: 'interval', n: 339, mean: 3.78 }],
      },
      modelling: {
        auto_selected_model: 'ordinal_logit',
        ordinal_available: true,
        ols_available: true,
        drivers: [
          { model: 'ordinal_logit', term: 'DSD', b: 0.742, p_value: 0.0001, significant: true },
          { model: 'ordinal_logit', term: 'STI', b: -0.121, p_value: 0.246, significant: false },
        ],
        note: '因变量为有序分类，有序 Logistic 回归为主要结论，线性回归仅作对照。',
      },
      risk_link: {
        hypothesis_code: 'H6',
        verdict: 'inconclusive',
        r: -0.08,
        p_value: 0.14,
        n: 337,
        note: '本次样本证据不足，不能表述为「已证明无关」。',
      },
    },
    inputs: [
      { name: 'UI', role: 'primary', available: true, note: null },
      { name: 'PRC', role: 'supporting', available: true, note: null },
    ],
    evidence: [
      { path: 'descriptive.variables[UI].mean', value: 3.71 },
      { path: 'regression.ordinal.coefficients[DSD].b', value: 0.742 },
    ],
  },
];

const REPORT = {
  engine_version: '1.0.0',
  generated_at: '2026-03-05T09:00:00.000Z',
  source: {
    analysis_engine_version: '1.0.0',
    analysis_generated_at: '2026-02-01T09:30:00.000Z',
    project_id: 'p-1',
    project_title: '家庭教育投入研究',
    questionnaire: { id: 'q-1', title: '家庭教育投入问卷', version: '4.0.0', question_count: 58 },
    bundle_engine_matches: true,
  },
  sample: SAMPLE,
  staleness: {
    bundle_sample_n: 350,
    current_sample_n: 372,
    stale: true,
    note: '结果包早于当前样本，请重新运行统计分析后再据此作商业判断。',
  },
  blocks: BLOCKS,
  caveats: CAVEATS,
  notes: [
    '本报告的所有统计数字均来自分析结果包（analysis bundle），由平台统计引擎计算，本层不重新计算、不四舍五入到不同精度，也不引入外部数据。',
    '结果包与分析时的样本不一致（结果包 n = 350，当前可分析样本 n = 372）：说明在新的作答进入之后尚未重新运行统计分析。',
  ],
};

const REPORT_RESPONSE = {
  available: true,
  report_id: 'ir-1',
  run_seq: 1,
  created_at: '2026-03-05T09:00:00.000Z',
  ...REPORT,
};

const RUN_RESPONSE = {
  available: true,
  report_id: 'ir-2',
  run_seq: 2,
  created_at: '2026-03-06T10:30:00.000Z',
  blocks_total: 9,
  blocks_available: 8,
  ...REPORT,
};

const HISTORY = {
  blocks: {
    target_user: '目标用户',
    pain_points: '痛点',
    current_solutions: '现有解决方案',
    service_gap: '服务缺口',
    product_demand: '产品需求',
    trust: '信任',
    ai_acceptance: 'AI 接受度',
    willingness_to_pay: '付费意愿',
    market_opportunity: '市场机会',
  },
  items: [
    {
      id: 'ir-2',
      run_seq: 2,
      engine_version: '1.0.0',
      analysis_engine_version: '1.0.0',
      analysis_generated_at: '2026-02-01T09:30:00.000Z',
      sample_n: 350,
      blocks_total: 9,
      blocks_available: 8,
      questionnaire_id: 'q-1',
      created_by: 'r-1',
      created_at: '2026-03-06T10:30:00.000Z',
    },
    {
      id: 'ir-1',
      run_seq: 1,
      engine_version: '1.0.0',
      analysis_engine_version: '1.0.0',
      analysis_generated_at: '2026-02-01T09:30:00.000Z',
      sample_n: 350,
      blocks_total: 9,
      blocks_available: 7,
      questionnaire_id: 'q-1',
      created_by: 'r-1',
      created_at: '2026-03-05T09:00:00.000Z',
    },
  ],
};

interface StubOptions {
  report?: unknown;
  run?: unknown;
  history?: unknown;
}

function stubCompetitionApi(options: StubOptions = {}) {
  return stubFetch((call: FetchCall) => {
    const url = call.url;
    if (url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
    if (url.includes('/competition/run')) return jsonResponse({ data: options.run ?? RUN_RESPONSE });
    if (url.includes('/competition/report')) {
      return jsonResponse({ data: options.report ?? REPORT_RESPONSE });
    }
    if (url.includes('/competition/history')) return jsonResponse({ data: options.history ?? HISTORY });
    return jsonResponse({ data: null });
  });
}

function blockTitles(): string[] {
  return queryAll('h2')
    .map((element) => element.textContent ?? '')
    .filter((content) => /^\d+\./.test(content))
    // The heading also carries the machine key (`1.目标用户target_user`); the
    // title is what precedes it.
    .map((content) => content.replace(/[a-z_]+$/, ''));
}

function blockCard(title: string): Element {
  const heading = queryAll('h2').find((element) => (element.textContent ?? '').includes(title));
  assert.ok(heading, `未找到「${title}」区块`);
  const card = heading!.closest('div.ferp-card');
  assert.ok(card, `「${title}」应在卡片内`);
  return card!;
}

async function renderPage(): Promise<void> {
  await render(createElement(MemoryRouter, null, createElement(CompetitionPage)));
  await flush();
  await flush();
}

beforeEach(() => {
  clearContainer();
  window.localStorage.clear();
});

after(() => {
  // The suite shares one process and one jsdom: leave no token behind.
  window.localStorage.clear();
  closeDom();
});

/* ================================================================== */
/* Blocks                                                             */
/* ================================================================== */

describe('创业洞察页', () => {
  test('九个区块按 order 渲染，标题齐全并显示结构化数据与证据留痕', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const titles = blockTitles();
      assert.equal(titles.length, 9, '必须渲染全部九个区块');
      assert.deepEqual(titles, [
        '1.目标用户',
        '2.痛点',
        '3.现有解决方案',
        '4.服务缺口',
        '5.产品需求',
        '6.信任',
        '7.AI 接受度',
        '8.付费意愿',
        '9.市场机会',
      ]);

      const content = text();
      // Structured payload values from several blocks reach the screen.
      assert.ok(content.includes('学业辅导困难'), '应渲染痛点排序的条目名');
      assert.ok(content.includes('3.82'), '应渲染痛点严重度数值');
      assert.ok(content.includes('在线课程与学习资源推荐'), '应渲染产品需求条目');
      assert.ok(content.includes('4.12'), '应渲染需求均值');
      assert.ok(content.includes('42.86'), '应渲染样本构成比例');
      assert.ok(content.includes('92.4'), '应渲染质量背景均值');
      assert.ok(content.includes('0.44'), '应渲染信任与使用意愿的相关系数');

      // Evidence traces are given as bundle paths.
      assert.ok(content.includes('descriptive.variables[FED1].mean'));
      assert.ok(content.includes('correlation.pairs[left=STI,right=UI].r'));
      assert.match(content, /证据留痕（3 条，逐条给出结果包中的位置）/);

      // Inputs, including the one the questionnaire does not carry.
      assert.match(content, /问卷未测量信息搜寻行为（ISC）。/);
      assert.match(content, /已测量/);
      assert.match(content, /缺失/);

      // Run metadata and history.
      assert.match(content, /第 1 次/);
      assert.match(content, /创业洞察运行历史/);
      assert.ok(content.includes('9'), '应显示可用区块计数');
    } finally {
      stub.restore();
    }
  });

  test('available: false 的区块显示中文原因，而不是空区块或 0', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const card = blockCard('现有解决方案');
      const cardText = card.textContent ?? '';
      assert.match(cardText, /本区块无法给出结论/);
      assert.match(cardText, /原因：问卷没有测量任何供给方/);
      assert.match(cardText, /因此无法描述家长现在用什么；平台不会用行业经验填补。/);
      assert.match(cardText, /这是平台的有意拒绝：宁可不给结论，也不以 0、行业均值或外部数据填补。/);
      assert.match(cardText, /问卷未测量公共服务知晓（PSA）。/);

      // The refusal must not be dressed up with numbers of its own.
      assert.ok(!cardText.includes('3.86'), '不可用区块不得引用其他区块的需求均值');
      assert.ok(!cardText.includes('需求均值为 0'), '不可用区块不得以 0 代替数值');
      assert.match(cardText, /本区块无法给出结论/);

      const content = text();
      assert.match(content, /可用区块/);
      assert.match(content, /不可用区块会说明原因，不以 0 填充/);
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Market opportunity guards                                        */
  /* ================================================================ */

  test('市场机会区块醒目声明「仅本样本推断、不是市场规模」', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const cardText = blockCard('市场机会').textContent ?? '';
      assert.match(cardText, /以下数字全部是「本样本内部」的统计推断，不是市场规模估算/);
      assert.ok(cardText.includes(INFERENCE_LABEL), '应原文引用接口给出的推断性质说明');
      assert.match(cardText, /推断的样本范围仅为本次分析的有效样本 350 份/);
      assert.match(cardText, /请勿把本区块的任何比例、系数或均值乘以外部人口数/);
      assert.match(cardText, /这为产品方向提供了有待验证的假设/);
      assert.match(cardText, /不能支持的结论包括：市场规模、收入预测、用户增长曲线/);
    } finally {
      stub.restore();
    }
  });

  test('market_size_estimate 以拒绝形式呈现，金额为 null 而不是 0', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const content = text();
      assert.match(content, /市场规模估计：本平台拒绝给出金额/);
      assert.match(content, /数据集里没有价格、成本、付费转化、市场容量或购买行为/);
      assert.match(content, /服务端该字段为 available=false、amount=null、currency=null/);
      assert.match(content, /不是 0/);
      assert.match(content, /0 是一个金额，而这里没有金额/);

      // No currency figure is shown for the estimate — in particular not 0. The
      // price bands measured by the questionnaire belong to another block, so the
      // check is scoped to the market-opportunity card.
      const marketCard = blockCard('市场机会').textContent ?? '';
      assert.ok(!/[¥￥$]\s?\d/.test(marketCard), '不得出现货币金额');
      assert.ok(!/\d+(\.\d+)?\s*(元|万元|亿元)/.test(marketCard), '不得出现金额数字');
      assert.ok(!marketCard.includes('金额：0'), '被拒绝的估计不得显示为 0');
      assert.ok(!content.includes('金额：0'), '被拒绝的估计不得显示为 0');
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Caveats and staleness                                            */
  /* ================================================================ */

  test('四条强制限制排在最前并标为必读，且披露结果包已过期', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const content = text();
      for (const caveat of REQUIRED_CAVEATS) {
        assert.ok(content.includes(caveat), `缺少强制限制：${caveat.slice(0, 20)}…`);
      }
      assert.match(content, /必须与报告同时引用的限制（前四条为平台强制声明）/);

      const items = queryAll('li').filter((element) =>
        (element.textContent ?? '').startsWith('【必读】'),
      );
      assert.equal(items.length, 4, '前四条必须标为必读');
      assert.ok(
        (items[0]!.textContent ?? '').includes('便利）抽样得到的家长样本'),
        '第一条必读限制应是抽样代表性声明',
      );
      assert.ok(
        !(items[3]!.textContent ?? '').includes('有效样本；各统计量另有其自身的有效 n'),
        '第五条（样本量说明）不是强制四条之一',
      );

      assert.match(content, /结果包已经过期：样本在分析之后发生了变化/);
      assert.match(content, /结果包早于当前样本，请重新运行统计分析后再据此作商业判断。/);
      assert.match(content, /结果包记录的样本为 350 份，当前可分析样本为 372 份。/);
      assert.match(content, /不要据此报告作对外判断。/);
    } finally {
      stub.restore();
    }
  });

  test('结果包与样本一致时如实说明一致，不显示过期警告', async () => {
    const stub = stubCompetitionApi({
      report: {
        ...REPORT_RESPONSE,
        staleness: {
          bundle_sample_n: 350,
          current_sample_n: 350,
          stale: false,
          note: '结果包与当前样本一致。',
        },
      },
    });
    try {
      await renderPage();

      const content = text();
      assert.match(content, /结果包与当前可分析样本一致（n = 350）/);
      assert.ok(!content.includes('结果包已经过期'), '一致时不得显示过期警告');
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* Run, empty state and history                                     */
  /* ================================================================ */

  test('「生成创业洞察」提交 POST 请求并渲染返回的区块与运行序号', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const button = queryAll('button').find((element) =>
        (element.textContent ?? '').includes('生成创业洞察'),
      );
      assert.ok(button, '应有生成按钮');
      await click(button!);
      await flush();
      await flush();

      const runCall = stub.calls.find((call) => call.url.includes('/competition/run'));
      assert.ok(runCall, '应调用运行接口');
      assert.equal(runCall!.method, 'POST');

      const content = text();
      assert.match(content, /第 2 次/, '应显示本次运行序号');
      assert.equal(blockTitles().length, 9, '运行后仍应渲染九个区块');

      const historyCall = stub.calls.filter((call) => call.url.includes('/competition/history'));
      assert.equal(historyCall.length, 2, '运行后应刷新历史记录');
    } finally {
      stub.restore();
    }
  });

  test('尚未生成报告时显示接口的中文原因并指向统计分析页', async () => {
    const stub = stubCompetitionApi({ report: { available: false, reason: NO_REPORT_REASON } });
    try {
      await renderPage();

      const content = text();
      assert.match(content, /尚未生成创业洞察报告/);
      assert.match(content, /请先运行「运行全部分析」得到统计结果包，再执行「生成创业洞察」/);
      assert.match(content, /创业洞察不会独立计算任何数字/);
      assert.equal(blockTitles().length, 0, '没有报告时不应渲染任何区块');

      const links = queryAll('a').map((element) => element.getAttribute('href'));
      assert.ok(
        links.some((href) => href?.includes('/analysis')),
        '应提供前往统计分析页的入口',
      );
    } finally {
      stub.restore();
    }
  });

  test('历史列表显示运行序号、引擎版本、样本量与可用区块数', async () => {
    const stub = stubCompetitionApi();
    try {
      await renderPage();

      const rows = queryAll('tr').filter((element) => (element.textContent ?? '').includes('第 '));
      assert.equal(rows.length, 2, '两次运行都应出现在历史中');

      const cells = rows[0]!.querySelectorAll('td');
      assert.equal(cells[0]?.textContent, '第 2 次');
      assert.equal(cells[2]?.textContent, '1.0.0');
      assert.equal(cells[4]?.textContent, '350');
      assert.equal(cells[5]?.textContent, '8/9');

      const older = rows[1]!.querySelectorAll('td');
      assert.equal(older[0]?.textContent, '第 1 次');
      assert.equal(older[5]?.textContent, '7/9');
    } finally {
      stub.restore();
    }
  });
});
