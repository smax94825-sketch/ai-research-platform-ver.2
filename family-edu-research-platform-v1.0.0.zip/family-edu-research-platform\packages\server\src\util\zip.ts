/**
 * Minimal ZIP writer (stored entries only).
 *
 * The SPSS export has to ship two files — the `.sps` syntax and the data CSV it
 * reads — as one download, and Node ships no archive writer. A whole ZIP
 * implementation dependency is not worth carrying for two small text files, so
 * the small, well-specified subset needed here is written out directly.
 *
 * Deliberate restrictions, each of which keeps the output trivially correct:
 *  - **Store only** (compression method 0). Both entries are a few kilobytes of
 *    text, and a stored entry is readable by every unzip tool without a
 *    decompressor ever being involved.
 *  - **UTF-8 names** with general-purpose bit 11 set, so Chinese file names
 *    survive instead of being interpreted in the local code page.
 *  - **No ZIP64.** The EOCD record carries 16/32-bit fields, which is ample for
 *    two files; a caller that somehow exceeds 4 GiB would be truncated rather
 *    than silently mis-described, which is why the sizes are validated.
 */

/** One file inside the archive. */
export interface ZipEntry {
  /** Path inside the archive; forward slashes only. */
  name: string;
  content: string;
}

/** Bytes above this cannot be described by the 32-bit EOCD fields. */
const MAX_ENTRY_BYTES = 0xffffffff;

const CRC_TABLE: Uint32Array = (() => {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      value = (value & 1) !== 0 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    }
    table[index] = value >>> 0;
  }
  return table;
})();

/** Standard CRC-32 (polynomial 0xEDB88320), as ZIP requires. */
function crc32(data: Buffer): number {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ byte) & 0xff]!;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

/**
 * MS-DOS date/time pair.
 *
 * The format cannot represent years before 1980; an earlier timestamp is
 * clamped to the epoch of the format rather than producing a negative field
 * that some tools read as an absurd future date.
 */
function dosDateTime(when: Date): { time: number; date: number } {
  const year = Math.max(when.getFullYear(), 1980);
  const date = (((year - 1980) & 0x7f) << 9) | ((when.getMonth() + 1) << 5) | when.getDate();
  const time =
    (when.getHours() << 11) | (when.getMinutes() << 5) | Math.floor(when.getSeconds() / 2);
  return { time: time & 0xffff, date: date & 0xffff };
}

/** Build a ZIP archive from UTF-8 text entries, in the order given. */
export function createZip(
  entries: ZipEntry[],
  options: { modifiedAt?: Date } = {},
): Buffer {
  const { time, date } = dosDateTime(options.modifiedAt ?? new Date());

  const localParts: Buffer[] = [];
  const centralParts: Buffer[] = [];
  let offset = 0;

  for (const entry of entries) {
    const name = Buffer.from(entry.name.replace(/\\/g, '/'), 'utf8');
    const data = Buffer.from(entry.content, 'utf8');

    if (name.length > 0xffff) throw new Error(`ZIP entry name too long: ${entry.name}`);
    if (data.length > MAX_ENTRY_BYTES) throw new Error(`ZIP entry too large: ${entry.name}`);

    const checksum = crc32(data);

    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0); // local file header signature
    local.writeUInt16LE(20, 4); // version needed to extract (2.0)
    local.writeUInt16LE(0x0800, 6); // bit 11: file name is UTF-8
    local.writeUInt16LE(0, 8); // method: stored
    local.writeUInt16LE(time, 10);
    local.writeUInt16LE(date, 12);
    local.writeUInt32LE(checksum, 14);
    local.writeUInt32LE(data.length, 18); // compressed size == stored size
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28); // no extra field
    localParts.push(local, name, data);

    const central = Buffer.alloc(46);
    central.writeUInt32LE(0x02014b50, 0); // central directory header signature
    central.writeUInt16LE(20, 4); // version made by
    central.writeUInt16LE(20, 6); // version needed
    central.writeUInt16LE(0x0800, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(time, 12);
    central.writeUInt16LE(date, 14);
    central.writeUInt32LE(checksum, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30); // extra field length
    central.writeUInt16LE(0, 32); // comment length
    central.writeUInt16LE(0, 34); // disk number start
    central.writeUInt16LE(0, 36); // internal attributes
    central.writeUInt32LE(0, 38); // external attributes
    central.writeUInt32LE(offset, 42); // relative offset of the local header
    centralParts.push(central, name);

    offset += local.length + name.length + data.length;
  }

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);

  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); // end of central directory signature
  end.writeUInt16LE(0, 4); // this disk
  end.writeUInt16LE(0, 6); // disk with the central directory
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16); // offset of the central directory
  end.writeUInt16LE(0, 20); // no archive comment

  return Buffer.concat([...localParts, ...centralParts, end]);
}
