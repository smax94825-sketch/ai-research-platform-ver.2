/**
 * Descriptive statistics (PHASE 6).
 *
 * The table is deliberately complete rather than pretty: n, missingness, the
 * five-number summary and skewness side by side, so a reader can see the shape
 * of every variable before any inferential result is trusted.
 *
 * Nominal variables MUST show 「—」 where a mean would go. The engine returns
 * `null` for statistics that are not defined at that measurement level, and this
 * page renders that null as 「—」 — never as 0, and never as a silently dropped
 * column.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { BarChart } from '../../components/charts';
import { Alert, Card, CardHeader, LoadingBlock, Select } from '../../components/ui';
import { api, ApiClientError, type AnalysisDescriptiveResponse, type DescriptiveStats } from '../../lib/api';
import { formatNumber, formatPercent, formatStat } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  measurementLabel,
  useAnalysisProject,
} from './shared';

export function DescriptivePage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisDescriptiveResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedVariable, setSelectedVariable] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setData(await api.analysis.descriptive(projectId));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载描述统计结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const variables: DescriptiveStats[] = data?.variables ?? [];
  const withFrequencies = variables.filter(
    (item) => item.frequencies !== null && item.frequencies.length > 0,
  );
  const active =
    withFrequencies.find((item) => item.variable === selectedVariable) ?? withFrequencies[0] ?? null;

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Descriptive"
          subtitle="描述统计：每个变量的有效样本、缺失、集中趋势、离散程度与分布形态。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在计算描述统计…" />
        ) : !data ? null : variables.length === 0 ? (
          <Alert tone="warning" title="暂无可描述的变量">
            该项目的问卷中没有任何可统计的变量，请先完善问卷并收集样本。
          </Alert>
        ) : (
          <>
            <MethodNote>
              <p>{data.note}</p>
              <p>
                分析基数：可分析样本 {formatNumber(data.sample.analysable)} 份（已完成且未被研究者排除），
                整例删除后实际载入 {formatNumber(data.sample.rows_loaded)} 行；引擎版本 {data.engine_version}。
              </p>
              <p>
                名义（分类）变量不存在有意义的均值、标准差与偏度，引擎对这些统计量返回空值，
                下表如实显示为「—」，而不是填 0 或留空。
              </p>
              {data.unusable_variables.length > 0 && (
                <p className="text-amber-700">
                  以下变量没有任何有效作答，未参与分析：
                  {data.unusable_variables.map((item) => item.variable).join('、')}。
                </p>
              )}
            </MethodNote>

            <Card padded={false}>
              <div className="border-b border-ink-200 px-5 py-4">
                <h2 className="text-base font-semibold text-ink-900">
                  描述统计表（{variables.length} 个变量）
                </h2>
                <p className="mt-1 text-sm text-ink-500">
                  缺失率以整例样本为分母；Q1/Q3 为第一、第三四分位数；偏度为标准化偏度（0 表示对称）。
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] text-sm">
                  <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-4 py-2 text-left">变量</th>
                      <th className="px-4 py-2 text-left">测量层次</th>
                      <th className="px-4 py-2 text-right">n</th>
                      <th className="px-4 py-2 text-right">缺失</th>
                      <th className="px-4 py-2 text-right">缺失率</th>
                      <th className="px-4 py-2 text-right">均值</th>
                      <th className="px-4 py-2 text-right">标准差</th>
                      <th className="px-4 py-2 text-right">中位数</th>
                      <th className="px-4 py-2 text-right">Q1</th>
                      <th className="px-4 py-2 text-right">Q3</th>
                      <th className="px-4 py-2 text-right">偏度</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {variables.map((item) => (
                      <tr key={item.variable}>
                        <td className="px-4 py-2">
                          <span className="text-ink-900">{item.label}</span>
                          <span className="ml-2 font-mono text-[11px] text-ink-500">
                            {item.variable} · {item.question_code}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-xs text-ink-600">{measurementLabel(item.data_type)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-800">{item.n}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-800">{item.missing}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-600">
                          {formatPercent(item.missing_percent)}
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-900">{formatStat(item.mean)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-800">
                          {formatStat(item.standard_deviation)}
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-800">{formatStat(item.median)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-600">{formatStat(item.q1)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-600">{formatStat(item.q3)}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-ink-600">{formatStat(item.skewness)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            <Card>
              <CardHeader
                title="分类变量频数图"
                description={
                  withFrequencies.length === 0
                    ? '该问卷没有任何带选项标签的变量，因此没有频数分布可绘制。'
                    : `共 ${withFrequencies.length} 个变量可绘制频数分布；选择变量查看其各类别人数与占比。`
                }
                actions={
                  withFrequencies.length > 0 ? (
                    <Select
                      className="min-w-56"
                      value={active?.variable ?? ''}
                      onChange={(event) => setSelectedVariable(event.target.value)}
                    >
                      {withFrequencies.map((item) => (
                        <option key={item.variable} value={item.variable}>
                          {item.label}
                        </option>
                      ))}
                    </Select>
                  ) : undefined
                }
              />

              {active && (
                <>
                  <p className="mb-3 text-sm text-ink-700">
                    {active.label}
                    <span className="ml-2 font-mono text-[11px] text-ink-500">
                      {active.variable} · {active.question_code}
                    </span>
                  </p>
                  <BarChart
                    data={(active.frequencies ?? []).map((row) => ({
                      label: row.label,
                      value: row.count,
                      percent: row.percent,
                    }))}
                    total={active.n}
                    unit="人"
                    emptyText="该变量暂无有效作答。"
                    caption={
                      `有效作答 n = ${active.n}，缺失 ${active.missing}；百分比以有效作答为分母。` +
                      `各选项占全部样本（含缺失）的比例可直接由频数除以分析基数得到。`
                    }
                  />
                </>
              )}
            </Card>
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
