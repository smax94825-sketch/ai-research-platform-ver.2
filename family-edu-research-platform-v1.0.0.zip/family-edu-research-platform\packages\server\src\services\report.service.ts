/**
 * Research report generation (PHASE 8).
 *
 * Produces the 23-section Chinese research report from a persisted
 * `AnalysisBundle`. The module is a *report writer*, not an analyst: it never
 * computes a statistic, never re-rounds one, and never fills a gap with a
 * plausible-looking value.
 *
 * Three integrity rules shape every section below.
 *
 *  1. **The bundle is the only source of statistical truth.** Every number in a
 *     section body is the engine's own value, printed with `String(value)` so it
 *     is character-for-character the value stored in the result bundle. The
 *     `evidence` list of each section records the bundle path each number came
 *     from, so the report can be audited line by line.
 *
 *  2. **Unfillable means unavailable, not invented.** A section whose content
 *     cannot be derived from the data is emitted with `available: false` and a
 *     Chinese explanation of exactly what is missing. The two clearest cases are
 *     文献与理论依据 and 参考文献与附录: the platform runs offline against no
 *     bibliographic database, so it will not emit an author, a year, a journal, a
 *     DOI or a page number. Those sections are placeholders addressed to the
 *     researcher, and their bodies deliberately contain no citation-shaped text
 *     at all.
 *
 *  3. **Verbal verdicts stay three-valued.** A hypothesis that did not reach
 *     significance is reported as 证据不足 ("this sample provided no evidence"),
 *     never as proof that the variables are unrelated. Absence of evidence is not
 *     restated as evidence of absence anywhere in this file.
 */

import type { Dataset } from '@ferp/shared';

import type { AnalysisBundle, SampleSummary } from './analysis.service.js';
import { exportFilenames } from './export.service.js';
import { nowIso } from '../util/ids.js';

/**
 * Verdict wording, kept in one place because both the report and the results
 * workbook describe the same verdicts and must never describe them differently.
 *
 * The `inconclusive` wording is the one that matters: a null result is reported
 * as "this sample provided no evidence", never as proof that the variables are
 * unrelated.
 */
export const VERDICT_LABELS: Record<string, string> = {
  supported: '支持（p < α 且方向与假设一致）',
  not_supported: '不支持（p < α 但方向与假设相反）',
  inconclusive: '证据不足（p ≥ α，当前样本未提供证据，不能据此判断两者没有关系）',
  untestable: '无法检验（变量缺失，或有效样本量与变异不足）',
};

/* ------------------------------------------------------------------ */
/* Public shapes                                                      */
/* ------------------------------------------------------------------ */

/** One number the section used, with the bundle path it came from. */
export interface ReportEvidence {
  /** Dotted path inside the analysis bundle, e.g. `hypotheses.summary.supported`. */
  path: string;
  /** The exact stored value, stringified without further rounding. */
  value: string;
}

export interface ReportSection {
  /** 1-based position in the fixed section order. */
  index: number;
  /** Stable machine key, safe to use as a UI anchor. */
  key: string;
  title: string;
  /** Chinese body assembled from real bundle values (or from the explanation). */
  body: string;
  evidence: ReportEvidence[];
  /** False when the section could not be filled from the data. */
  available: boolean;
  /** Chinese explanation of what is missing; `null` when `available` is true. */
  unavailable_reason: string | null;
}

export interface ResearchReport {
  report_type: 'research_report';
  project_id: string;
  project_title: string;
  questionnaire_title: string | null;
  engine_version: string;
  /** Timestamp of the analysis the report was built from. */
  analyser_generated_at: string;
  generated_at: string;
  sections: ReportSection[];
  section_count: number;
  available_sections: number;
  unavailable_sections: number;
  /** Verbatim from the bundle: statements that must accompany any reading. */
  caveats: string[];
  markdown: string;
  word_count: number;
}

/* ------------------------------------------------------------------ */
/* Fixed section order                                                */
/* ------------------------------------------------------------------ */

/**
 * The 23 sections, in the order they are written.
 *
 * The order is fixed and documented so that the UI, the Markdown export and the
 * tests all address a section by the same index. Two entries — `literature` and
 * `references_appendix` — are structurally unavailable: no offline bibliographic
 * source exists, and a research report that invents its references is worse than
 * one that states the gap. They are kept in the list (rather than dropped) so a
 * reader sees the omission instead of silently getting a report with no
 * literature section at all.
 */
export const REPORT_SECTION_ORDER: { key: string; title: string }[] = [
  { key: 'title_abstract', title: '标题与摘要' },
  { key: 'background', title: '研究背景' },
  { key: 'objectives', title: '研究目的与研究问题' },
  { key: 'hypotheses', title: '研究假设' },
  { key: 'literature', title: '文献与理论依据' },
  { key: 'method', title: '研究方法' },
  { key: 'sampling', title: '数据来源与抽样' },
  { key: 'sample_profile', title: '样本概况' },
  { key: 'instrument', title: '测量工具与变量说明' },
  { key: 'reliability', title: '信度分析' },
  { key: 'validity', title: '效度分析' },
  { key: 'descriptive', title: '描述性统计' },
  { key: 'correlation', title: '相关分析' },
  { key: 'regression', title: '回归分析' },
  { key: 'group_differences', title: '组间差异分析' },
  { key: 'hypothesis_tests', title: '假设检验结果' },
  { key: 'findings', title: '主要发现' },
  { key: 'discussion', title: '讨论' },
  { key: 'limitations', title: '局限性' },
  { key: 'conclusion', title: '结论' },
  { key: 'policy_recommendations', title: '政策与管理建议' },
  { key: 'service_recommendations', title: '服务优化建议' },
  { key: 'references_appendix', title: '参考文献与附录' },
];

export const REPORT_SECTION_COUNT = REPORT_SECTION_ORDER.length;

/* ------------------------------------------------------------------ */
/* Value formatting                                                   */
/* ------------------------------------------------------------------ */

/**
 * Render a bundle value.
 *
 * Deliberately no re-rounding: the report prints `String(value)`, so a number in
 * the prose can be copied straight into a search of the stored result. Rounding
 * here — even to a "nicer" number of decimals — would break that traceability,
 * which is the whole point of quoting the bundle.
 */
function figure(value: unknown): string {
  if (value === null || value === undefined) return '未计算（null）';
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return '未计算（null）';
    return String(value);
  }
  return String(value);
}

/** Significance, with the exact value kept in the evidence list. */
function significance(p: number | null | undefined): string {
  if (p === null || p === undefined || !Number.isFinite(p)) return '未计算';
  return p < 0.001 ? '< .001' : `= ${String(p)}`;
}

function ev(path: string, value: unknown): ReportEvidence {
  return { path, value: value === undefined ? 'undefined' : figure(value) };
}

function joinFigures(values: (number | null)[], separator = '、'): string {
  return values.map((value) => figure(value)).join(separator);
}

/** Markdown table; `|` inside a cell is replaced so the table cannot break. */
function table(headers: string[], rows: (string | number | null)[][]): string {
  const cell = (value: string | number | null): string =>
    value === null || value === undefined ? '（空）' : String(value).replace(/\|/g, '／');
  return [
    `| ${headers.join(' | ')} |`,
    `| ${headers.map(() => '---').join(' | ')} |`,
    ...rows.map((row) => `| ${row.map(cell).join(' | ')} |`),
  ].join('\n');
}

/* ------------------------------------------------------------------ */
/* Small bundle accessors                                             */
/* ------------------------------------------------------------------ */

function descriptiveOf(
  bundle: AnalysisBundle,
  variable: string,
): AnalysisBundle['descriptive']['variables'][number] | null {
  return bundle.descriptive.variables.find((item) => item.variable === variable) ?? null;
}

function meanOf(bundle: AnalysisBundle, variable: string): string {
  return figure(descriptiveOf(bundle, variable)?.mean ?? null);
}

function hasVariables(dataset: Dataset, names: string[]): boolean {
  return names.some((name) => dataset.by_name.has(name));
}

/** Item counts per questionnaire dimension, derived from the built dataset. */
function dimensionCounts(dataset: Dataset): { dimension: string; count: number }[] {
  const counts = new Map<string, number>();
  for (const variable of dataset.variables) {
    counts.set(variable.dimension, (counts.get(variable.dimension) ?? 0) + 1);
  }
  return [...counts.entries()]
    .map(([dimension, count]) => ({ dimension, count }))
    .sort((left, right) => right.count - left.count || left.dimension.localeCompare(right.dimension));
}

/* ------------------------------------------------------------------ */
/* Section drafts                                                     */
/* ------------------------------------------------------------------ */

interface SectionDraft {
  key: string;
  title: string;
  body: string;
  evidence: ReportEvidence[];
  available: boolean;
  unavailable_reason: string | null;
}

function filled(
  key: string,
  title: string,
  body: string,
  evidence: ReportEvidence[],
): SectionDraft {
  return { key, title, body, evidence, available: true, unavailable_reason: null };
}

/**
 * An unavailable section.
 *
 * Its body *is* the explanation: a reader who prints the report must be able to
 * see, in place of the missing content, why it is missing and what has to be
 * supplied. No sample text, no illustrative reference and no placeholder number
 * is ever generated for it.
 */
function missing(key: string, title: string, reason: string, body?: string): SectionDraft {
  return {
    key,
    title,
    body: body ?? `本节未生成内容。原因：${reason}`,
    evidence: [],
    available: false,
    unavailable_reason: reason,
  };
}

/* ================================================================== */
/* Section builders                                                   */
/* ================================================================== */

function titleAbstract(bundle: AnalysisBundle): SectionDraft {
  const { sample, dataset_summary: dataset, hypotheses, reliability } = bundle;
  const scalesWithAlpha = reliability.scales.filter((scale) => scale.cronbach_alpha !== null);

  const body = [
    `本研究题目为「${bundle.project.title}」。本报告由平台统计引擎 ${bundle.engine_version} 依据结果包（分析生成时间 ${bundle.generated_at}）自动生成，正文中的每一个数字都取自该结果包，未做任何人工调整。`,
    '',
    `数据概况：共收集 ${sample.respondents_total} 份作答，其中已完成 ${sample.completed} 份、作答中 ${sample.in_progress} 份、中途退出 ${sample.abandoned} 份；经研究者排除 ${sample.excluded} 份后，进入分析的样本为 ${sample.analysable} 份。数据集包含 ${dataset.variable_count} 个变量，其中派生变量 ${dataset.derived_variable_count} 个。`,
    '',
    `测量与检验：信度分析计算了 ${reliability.scales.length} 个量表（其中 ${scalesWithAlpha.length} 个给出了 Cronbach α）；效度分析报告整体 KMO 与 Bartlett 球形检验；假设检验共 ${hypotheses.summary.total} 条，数据支持 ${hypotheses.summary.supported} 条、方向与假设相反 ${hypotheses.summary.not_supported} 条、证据不足 ${hypotheses.summary.inconclusive} 条、无法检验 ${hypotheses.summary.untestable} 条。`,
    '',
    '本报告仅陈述数据中观察到的关系。横截面调查数据不能支持因果推断，各条解读限制见「局限性」一节，全部限制同时以结果包原文附于该节。',
  ].join('\n');

  return filled('title_abstract', '标题与摘要', body, [
    ev('project.title', bundle.project.title),
    ev('engine_version', bundle.engine_version),
    ev('generated_at', bundle.generated_at),
    ev('sample.respondents_total', sample.respondents_total),
    ev('sample.completed', sample.completed),
    ev('sample.excluded', sample.excluded),
    ev('sample.analysable', sample.analysable),
    ev('dataset_summary.variable_count', dataset.variable_count),
    ev('dataset_summary.derived_variable_count', dataset.derived_variable_count),
    ev('reliability.scales.length', reliability.scales.length),
    ev('hypotheses.summary.total', hypotheses.summary.total),
    ev('hypotheses.summary.supported', hypotheses.summary.supported),
    ev('hypotheses.summary.inconclusive', hypotheses.summary.inconclusive),
  ]);
}

function background(bundle: AnalysisBundle, dataset: Dataset): SectionDraft {
  const dimensions = dimensionCounts(dataset);
  const top = dimensions[0] ?? null;
  const questionCount = bundle.questionnaire?.question_count ?? 0;

  const body = [
    '本节仅陈述平台内可核验的立项信息与测量范围，不含文献综述，也不引用任何政策文件（平台离线运行，未接入文献库或政策文本库）。',
    '',
    `研究题目：${bundle.project.title}。所用问卷为「${bundle.questionnaire?.title ?? '（未登记问卷）'}（${bundle.questionnaire?.version ?? '无版本'}）」，共 ${questionCount} 道题目，展开为 ${bundle.dataset_summary.variable_count} 个分析变量。`,
    '',
    `问卷覆盖的测量维度共 ${dimensions.length} 个，按变量数由多到少依次为：` +
      (dimensions.length === 0
        ? '（无）'
        : dimensions.map((item) => `${item.dimension}（${item.count} 项）`).join('、')) +
      '。' +
      (top ? `其中题项最多的维度是「${top.dimension}」，包含 ${top.count} 个变量。` : ''),
    '',
    `变量中有 ${bundle.dataset_summary.empty_variables.length} 个在整个样本中没有任何有效作答${bundle.dataset_summary.empty_variables.length > 0 ? `（${bundle.dataset_summary.empty_variables.join('、')}）` : ''}，该事实已在结果包中声明，不影响其余变量的统计。`,
    '',
    '说明：本研究的理论背景与政策背景叙述需要研究者依据其立项材料撰写，平台不生成、也不引用任何文献条目。',
  ].join('\n');

  return filled('background', '研究背景', body, [
    ev('project.title', bundle.project.title),
    ev('questionnaire.title', bundle.questionnaire?.title ?? null),
    ev('questionnaire.question_count', questionCount),
    ev('dataset_summary.variable_count', bundle.dataset_summary.variable_count),
    ev('dataset_summary.empty_variables.length', bundle.dataset_summary.empty_variables.length),
  ]);
}

function objectives(bundle: AnalysisBundle): SectionDraft {
  const { hypotheses, sample } = bundle;
  if (hypotheses.results.length === 0) {
    return missing(
      'objectives',
      '研究目的与研究问题',
      '结果包中没有假设检验结果（hypotheses.results 为空），无法据此归纳研究目的与研究问题。请确认项目已登记假设，并已在「分析」页面运行全部分析。',
    );
  }

  const body = [
    `研究目的：在 ${sample.analysable} 份有效样本上，描述家长在家庭教育认知、实践、困难与服务需求等方面的现状水平，检验 ${hypotheses.summary.total} 条研究假设，并考察组间差异。`,
    '',
    '与本次实际执行的分析相对应的研究问题（由平台依据已检验的假设与已测量的变量归纳）：',
    `1. 各测量变量的现状水平与分布如何？见「描述性统计」（共 ${bundle.descriptive.variables.length} 个变量）。`,
    `2. 变量之间是否存在统计上显著的关系？见「相关分析」（${bundle.correlation ? `${bundle.correlation.variables.length} 个变量的相关矩阵` : '本次结果包未给出相关矩阵'}）与「回归分析」。`,
    `3. 各条假设是否得到数据支持？见「假设检验结果」（共 ${hypotheses.summary.total} 条，支持 ${hypotheses.summary.supported} 条）。`,
    `4. 不同分组之间是否存在差异？见「组间差异分析」（${bundle.comparisons.length} 组比较）。`,
    '',
    '说明：本节的问题表述由平台上已检验的假设与已测量的变量归纳得到。若与项目登记的研究问题表述不一致，请以项目登记内容为准并据此修改本节文字。',
  ].join('\n');

  return filled('objectives', '研究目的与研究问题', body, [
    ev('sample.analysable', sample.analysable),
    ev('hypotheses.summary.total', hypotheses.summary.total),
    ev('descriptive.variables.length', bundle.descriptive.variables.length),
    ev('comparisons.length', bundle.comparisons.length),
  ]);
}

function hypothesesSection(bundle: AnalysisBundle): SectionDraft {
  const { hypotheses } = bundle;
  if (hypotheses.results.length === 0) {
    return missing(
      'hypotheses',
      '研究假设',
      '结果包中没有假设检验结果（hypotheses.results 为空）。研究假设需在项目设置中登记，并重新运行分析后才能生成。',
    );
  }

  const lines = hypotheses.results.map((result) => {
    const directionWord = result.direction === 'positive' ? '正向' : '负向';
    return (
      `${result.code}：${result.statement}` +
      `（预期${directionWord}关系；检验变量 ${result.independent} × ${result.dependent}；` +
      `方法 ${result.method}；结论：${VERDICT_LABELS[result.verdict] ?? result.verdict}）`
    );
  });

  const body = [
    `本研究共登记并检验 ${hypotheses.summary.total} 条假设，逐条如下。`,
    '',
    ...lines,
    '',
    `汇总：支持 ${hypotheses.summary.supported} 条、方向与假设相反 ${hypotheses.summary.not_supported} 条、证据不足 ${hypotheses.summary.inconclusive} 条、无法检验 ${hypotheses.summary.untestable} 条。`,
    hypotheses.unavailable_variables.length > 0
      ? `以下变量在数据中缺失或变异不足，涉及它们的方法未执行：${hypotheses.unavailable_variables.join('；')}。`
      : '',
  ]
    .filter((line) => line !== '')
    .join('\n');

  return filled('hypotheses', '研究假设', body, [
    ev('hypotheses.summary.total', hypotheses.summary.total),
    ev('hypotheses.results[].code', hypotheses.results.map((result) => result.code).join('、')),
    ev('hypotheses.summary.supported', hypotheses.summary.supported),
    ev('hypotheses.summary.not_supported', hypotheses.summary.not_supported),
    ev('hypotheses.summary.inconclusive', hypotheses.summary.inconclusive),
    ev('hypotheses.summary.untestable', hypotheses.summary.untestable),
  ]);
}

function literature(): SectionDraft {
  const reason =
    '平台在离线环境中运行，没有可检索的文献数据库，也未接入任何引文来源，因此无法自动生成文献综述。' +
    '任何自动生成的作者、年份、期刊名、卷期、页码或文献编号都无法被溯源，属于编造，平台不提供该功能。';
  const body = [
    '本节为占位内容，需由研究者本人提供。',
    '',
    `原因：${reason}`,
    '',
    '请研究者在提交前用本人核验过的文献替换本节，内容包括：与家庭教育认知、家庭教育实践、社会支持与服务需求相关的既有研究结论、所使用的理论框架（及其出处），以及本研究相对既有研究的增量。',
    '',
    '平台不会给出文献建议，也不会生成示例条目——一旦生成，它就可能被误当作真实引用写入最终稿。本报告其余各节不含任何文献引用，因此不存在需要核对的条目。',
  ].join('\n');

  return missing('literature', '文献与理论依据', reason, body);
}

function method(bundle: AnalysisBundle): SectionDraft {
  const { sample, descriptive, reliability, validity, correlation, regression, comparisons, hypotheses } = bundle;
  const regressionModel = regression
    ? `${regression.auto_selection.model}（自动选择依据：${regression.auto_selection.reason}）`
    : '未运行';

  const body = [
    `本研究采用横截面问卷调查数据。全部统计量由平台统计引擎 ${bundle.engine_version} 计算，可由原始数据完全复现；统计之外的其他环节均不参与计算。`,
    '',
    `样本与缺失处理：进入分析的样本为 ${sample.analysable} 份（已完成 ${sample.completed} 份，研究者排除 ${sample.excluded} 份）。缺失值不做插补，一律采用整例删除（listwise），因此各统计量各自的有效 n 可能不同，本报告与结果包均以各结果自身报告的 n 为准。`,
    '',
    '检验口径：显著性水平 α = 0.05（见结果包假设检验说明）；相关系数按测量层次自动选择 Pearson 积矩相关或 Spearman 等级相关；组间比较同时给出参数与非参数结果并说明以哪一个为主要结论；因变量为有序分类时以有序 Logistic 回归（比例优势模型）为主要结论，同时给出线性回归作为对照。',
    '',
    `本次实际执行的分析：描述统计 ${descriptive.variables.length} 个变量；信度分析 ${reliability.scales.length} 个量表；效度分析（整体 KMO ${figure(validity.overall_kmo.overall)}，Bartlett χ² ${figure(validity.overall_bartlett.chi_square)}，逐量表因素分析 ${validity.scale_efa.length} 项）；相关矩阵 ${correlation ? `${correlation.variables.length} 个变量、${correlation.pairs.length} 组变量对` : '未运行'}；回归分析 ${regressionModel}；组间比较 ${comparisons.length} 组；假设检验 ${hypotheses.summary.total} 条。`,
    '',
    '本节仅说明实际使用的统计方法。研究设计、抽样方案与数据收集流程属于研究者的方法学陈述，平台不代为撰写。',
  ].join('\n');

  return filled('method', '研究方法', body, [
    ev('engine_version', bundle.engine_version),
    ev('sample.analysable', sample.analysable),
    ev('descriptive.variables.length', descriptive.variables.length),
    ev('reliability.scales.length', reliability.scales.length),
    ev('validity.overall_kmo.overall', validity.overall_kmo.overall),
    ev('validity.overall_bartlett.chi_square', validity.overall_bartlett.chi_square),
    ev('correlation.pairs.length', correlation?.pairs.length ?? null),
    ev('comparisons.length', comparisons.length),
    ev('hypotheses.summary.total', hypotheses.summary.total),
  ]);
}

function sampling(bundle: AnalysisBundle): SectionDraft {
  const { sample } = bundle;
  const sources =
    sample.sources.length === 0
      ? '本次结果包未记录有效的渠道信息（sources 为空）。'
      : sample.sources.map((item) => `${item.source}：${item.total} 份`).join('；');

  const body = [
    `数据由研究者在平台上发布问卷后经公开作答链接收集，本次共产生作答记录 ${sample.respondents_total} 份。`,
    '',
    `按渠道统计：${sources}`,
    '',
    `作答状态：已完成 ${sample.completed} 份、作答中 ${sample.in_progress} 份、中途退出 ${sample.abandoned} 份。只有已完成且未被研究者排除的 ${sample.analysable} 份进入分析；被排除的 ${sample.excluded} 份的排除决定与理由由研究者作出并记录在质量与样本审核模块，平台不会自动删除任何样本。`,
    '',
    '说明：抽样方式（如便利抽样、滚雪球抽样、配额抽样）、样本框与目标总体的界定不记录在统计结果包中，必须由研究者在方法部分如实说明；平台的配额完成情况可在质量与配额模块中查看。缺少该说明时，本节的样本代表性无法评估。',
  ].join('\n');

  return filled('sampling', '数据来源与抽样', body, [
    ev('sample.respondents_total', sample.respondents_total),
    ev('sample.completed', sample.completed),
    ev('sample.in_progress', sample.in_progress),
    ev('sample.abandoned', sample.abandoned),
    ev('sample.excluded', sample.excluded),
    ev('sample.analysable', sample.analysable),
    ev('sample.sources', sample.sources.map((item) => `${item.source}:${item.total}`).join('、')),
  ]);
}

function sampleProfile(bundle: AnalysisBundle): SectionDraft {
  const nominal = bundle.descriptive.variables.filter(
    (item) => item.data_type === 'nominal' && item.frequencies !== null && item.frequencies.length > 0,
  );

  if (nominal.length === 0) {
    return missing(
      'sample_profile',
      '样本概况',
      '数据集中没有任何带选项标签的名义变量（如学段、填答人身份）具有有效作答，无法生成分类样本概况。请在问卷中设置带选项的分类题并收集数据后重新运行分析。',
    );
  }

  const blocks: string[] = [];
  for (const item of nominal) {
    const frequencies = item.frequencies ?? [];
    blocks.push(`变量 ${item.variable}（${item.label}，${item.dimension}），有效作答 n = ${item.n}，缺失 ${item.missing}：`);
    blocks.push(
      table(
        ['类别', '编码', '人数', '占有效作答比例（%）', '占全部样本比例（%）'],
        frequencies.map((row) => [
          row.label,
          row.value,
          row.count,
          row.percent,
          row.percent_of_total,
        ]),
      ),
    );
    blocks.push('');
  }

  const missingHeavy = bundle.descriptive.variables
    .filter((item) => item.missing > 0)
    .sort((left, right) => right.missing - left.missing);
  const missingLine =
    missingHeavy.length === 0
      ? '所有变量都没有缺失值。'
      : `存在缺失的变量共 ${missingHeavy.length} 个，缺失最多的是 ${missingHeavy[0]!.variable}（缺失 ${missingHeavy[0]!.missing} 例）；` +
        '缺失包含「未作答」与敏感题目的「不愿回答」两种情况，两者都按缺失处理，绝不计为某一实质类别。';

  const body = [
    `分析样本共 ${bundle.sample.analysable} 份。本节报告所有带选项标签的名义变量的分类分布；连续变量的集中与离散趋势见「描述性统计」。`,
    '',
    ...blocks,
    missingLine,
  ]
    .filter((line) => line !== '')
    .join('\n');

  return filled('sample_profile', '样本概况', body, [
    ev('sample.analysable', bundle.sample.analysable),
    ev('descriptive.variables[].data_type=nominal', nominal.map((item) => item.variable).join('、')),
    ev('descriptive.variables[].n', nominal.map((item) => `${item.variable}:${item.n}`).join('、')),
    ev('descriptive.variables[].missing', nominal.map((item) => `${item.variable}:${item.missing}`).join('、')),
  ]);
}

function instrument(bundle: AnalysisBundle, dataset: Dataset): SectionDraft {
  const { dataset_summary: summary } = bundle;
  const composites = summary.composites;
  const textVariables = dataset.variables.filter((variable) => variable.data_type === 'text');
  const matrixComposites = dataset.variables.filter(
    (variable) => variable.is_derived && variable.sources.length === 1,
  );
  const scales = dataset.scales;

  const body = [
    `数据集共 ${summary.variable_count} 个变量，来自问卷的 ${bundle.questionnaire?.question_count ?? 0} 道题目，其中派生变量 ${summary.derived_variable_count} 个。`,
    '',
    '多题合成变量（由多个题项取均值或合计得到）：',
    composites.length === 0
      ? '本次问卷未命中任何预先声明的合成构念，因此没有多题合成变量。'
      : composites
          .map(
            (composite) =>
              `- ${composite.name}（${composite.label}）：由 ${composite.sources.length} 个题项合成，来源 ${composite.sources.join('、')}`,
          )
          .join('\n'),
    '',
    `矩阵题的维度均值变量 ${matrixComposites.length} 个：` +
      (matrixComposites.length === 0
        ? '（无）'
        : matrixComposites
            .map((variable) => `${variable.name}（来自 ${variable.sources.join('、')}）`)
            .join('、')) +
      '。矩阵题同时保留每一行的条目变量，条目变量与维度均值都出现在数据文件中。',
    '',
    `已声明的量表 ${scales.length} 个：` +
      (scales.length === 0
        ? '（无）'
        : scales.map((scale) => `${scale.variable_name}（题项代码 ${scale.question_codes.join('、')}）`).join('、')) +
      '。',
    '',
    `文本变量 ${textVariables.length} 个（${textVariables.map((variable) => variable.name).join('、') || '无'}）：文本不进行数值编码，仅保留原始作答，不参与任何统计检验。`,
    '',
    `有 ${summary.empty_variables.length} 个变量在整个样本中没有任何有效作答${summary.empty_variables.length > 0 ? `（${summary.empty_variables.join('、')}）` : ''}；它们已被排除在相关与回归之外，结果包中亦如实列出。`,
    '',
    '每个变量的编码方式、缺失值处理、计分规则与适用的分析方法见随数据导出的变量字典（Variable Dictionary）与编码簿（Codebook）；本报告不重复该表。',
  ].join('\n');

  return filled('instrument', '测量工具与变量说明', body, [
    ev('dataset_summary.variable_count', summary.variable_count),
    ev('dataset_summary.derived_variable_count', summary.derived_variable_count),
    ev('dataset_summary.composites', composites.map((item) => item.name).join('、')),
    ev('dataset_summary.empty_variables', summary.empty_variables.join('、')),
    ev('questionnaire.question_count', bundle.questionnaire?.question_count ?? null),
  ]);
}

function reliabilitySection(bundle: AnalysisBundle): SectionDraft {
  const { reliability } = bundle;
  const scored = reliability.scales.filter((scale) => scale.cronbach_alpha !== null);

  if (scored.length === 0) {
    return missing(
      'reliability',
      '信度分析',
      '本次结果包中没有任何量表能够计算 Cronbach α（量表未声明，或整例删除后有效样本不足 2 例，或量表条目少于 2 个）。信度无法估计，请勿在论文中用其他数字代替。',
    );
  }

  const rows: (string | number | null)[][] = reliability.scales.map((scale) => [
    scale.scale,
    scale.label,
    scale.k,
    scale.n,
    scale.dropped,
    scale.cronbach_alpha,
    scale.standardized_alpha,
    scale.mean_inter_item_correlation,
    scale.scale_mean,
    scale.scale_standard_deviation,
  ]);

  const ranked = [...scored].sort(
    (left, right) => (right.cronbach_alpha ?? 0) - (left.cronbach_alpha ?? 0),
  );
  const highest = ranked[0]!;
  const lowest = ranked[ranked.length - 1]!;
  const belowCut = scored.filter(
    (scale) => (scale.cronbach_alpha ?? 0) < (scale.alpha_reference?.acceptable ?? 0.7),
  );
  const reference = scored[0]!.alpha_reference;

  const body = [
    `共对 ${reliability.scales.length} 个量表做内部一致性分析，其中 ${scored.length} 个给出了 Cronbach α。α 基于整例删除后的完整样本计算，量表内所有条目使用同一批样本，否则系数无法解释。`,
    '',
    table(
      ['量表', '名称', '条目数', 'n', '剔除例数', 'Cronbach α', '标准化 α', '条目间平均相关', '量表均值', '量表标准差'],
      rows,
    ),
    '',
    `α 最高的是 ${highest.scale}（α = ${figure(highest.cronbach_alpha)}，n = ${highest.n}，条目 ${highest.k} 个）；最低的是 ${lowest.scale}（α = ${figure(lowest.cronbach_alpha)}，n = ${lowest.n}，条目 ${lowest.k} 个）。`,
    belowCut.length > 0
      ? `低于可接受水平（α < ${figure(reference.acceptable)}）的量表：${belowCut
          .map((scale) => `${scale.scale}（α = ${figure(scale.cronbach_alpha)}）`)
          .join('、')}。这些量表的合成分数在使用前应检查条目内容是否真的属于同一维度。`
      : `所有可计算量表的 α 均不低于可接受水平（α ≥ ${figure(reference.acceptable)}）。`,
    '',
    `判断标准取自结果包：α ≥ ${figure(reference.excellent)} 为很高、≥ ${figure(reference.good)} 为较好、≥ ${figure(reference.acceptable)} 为可接受、≥ ${figure(reference.questionable)} 为偏低。`,
    '',
    '需要强调：α 只反映内部一致性，既不是效度证据，也不证明量表单维；条目高度重复同样会推高 α。单条目量表不报告 α。',
  ].join('\n');

  return filled('reliability', '信度分析', body, [
    ev('reliability.scales.length', reliability.scales.length),
    ev('reliability.scales[].cronbach_alpha', scored.map((scale) => `${scale.scale}:${scale.cronbach_alpha}`).join('、')),
    ev('reliability.scales[].n', scored.map((scale) => `${scale.scale}:${scale.n}`).join('、')),
    ev('reliability.scales[].k', scored.map((scale) => `${scale.scale}:${scale.k}`).join('、')),
  ]);
}

function validitySection(bundle: AnalysisBundle): SectionDraft {
  const { validity } = bundle;
  const kmoAvailable = validity.overall_kmo.overall !== null;
  const bartlettAvailable = validity.overall_bartlett.chi_square !== null;

  if (!kmoAvailable && !bartlettAvailable && validity.scale_efa.length === 0) {
    return missing(
      'validity',
      '效度分析',
      '本次结果包中 KMO 与 Bartlett 球形检验均无法计算（相关矩阵接近奇异或可用变量少于 2 个），也没有可执行的逐量表因素分析。结构效度在本数据上无法评估，请勿以其他数字替代。',
    );
  }

  const rows: (string | number | null)[][] = [
    ['KMO 取样适切性（整体）', validity.overall_kmo.overall, null, null],
    [
      `Bartlett 球形检验${validity.overall_bartlett.unavailable ? '（不可用）' : ''}`,
      validity.overall_bartlett.chi_square,
      validity.overall_bartlett.degrees_of_freedom,
      validity.overall_bartlett.p_value,
    ],
  ];
  for (const entry of validity.scale_efa) {
    rows.push([
      `EFA：${entry.scale}`,
      entry.result.rotated_cumulative_variance,
      entry.result.factors_retained,
      entry.result.bartlett.p_value,
    ]);
  }

  const body = [
    '结构效度通过取样适切性（KMO）、Bartlett 球形检验与逐量表的探索性因素分析评估。相关矩阵接近奇异时，检验被报告为不可用，而不是给出一个无法复现的数字。',
    '',
    table(['检验', '统计量', 'df / 保留因子数', 'p'], rows),
    '',
    `KMO：${kmoAvailable ? `${figure(validity.overall_kmo.overall)}（${validity.overall_kmo.adequacy}）。${validity.overall_kmo.interpretation}` : `不可用。${validity.overall_kmo.interpretation}`}`,
    '',
    `Bartlett 球形检验：χ² = ${figure(validity.overall_bartlett.chi_square)}，df = ${figure(validity.overall_bartlett.degrees_of_freedom)}，p ${significance(validity.overall_bartlett.p_value)}。${validity.overall_bartlett.interpretation}`,
    '',
    validity.scale_efa.length === 0
      ? '逐量表因素分析：本次没有可执行的量表因素分析。'
      : `逐量表因素分析共 ${validity.scale_efa.length} 项：` +
        validity.scale_efa
          .map(
            (entry) =>
              `${entry.scale}（n = ${entry.result.n}，题项 ${entry.result.p} 个，保留 ${entry.result.factors_retained} 个因子，旋转后累计解释方差 ${figure(entry.result.rotated_cumulative_variance)}，共同度低于 0.40 的变量 ${entry.result.low_communality.length} 个，多重载荷变量 ${entry.result.cross_loading.length} 个）`,
          )
          .join('；') +
        '。',
    '',
    '需要强调：因素分析的结果依赖于样本量与题目内容，本节的判断只针对本次数据；内容效度与效标效度需要研究者依据测量设计判断，平台不做评价。',
  ].join('\n');

  return filled('validity', '效度分析', body, [
    ev('validity.overall_kmo.overall', validity.overall_kmo.overall),
    ev('validity.overall_kmo.adequacy', validity.overall_kmo.adequacy),
    ev('validity.overall_bartlett.chi_square', validity.overall_bartlett.chi_square),
    ev('validity.overall_bartlett.degrees_of_freedom', validity.overall_bartlett.degrees_of_freedom),
    ev('validity.overall_bartlett.p_value', validity.overall_bartlett.p_value),
    ev('validity.scale_efa.length', validity.scale_efa.length),
  ]);
}

function descriptiveSection(bundle: AnalysisBundle): SectionDraft {
  const variables = bundle.descriptive.variables;
  if (variables.length === 0) {
    return missing(
      'descriptive',
      '描述性统计',
      '本次结果包中没有可描述的非文本变量（descriptive.variables 为空），无法给出集中趋势与离散程度。',
    );
  }

  const rows: (string | number | null)[][] = variables.map((stats) => [
    stats.variable,
    stats.dimension,
    stats.data_type,
    stats.n,
    stats.missing,
    stats.mean,
    stats.standard_deviation,
    stats.minimum,
    stats.maximum,
    stats.median,
    stats.skewness,
  ]);

  const withMean = variables.filter((stats) => stats.mean !== null);
  const missingHeavy = [...variables].sort((left, right) => right.missing - left.missing)[0] ?? null;

  const body = [
    `描述统计共覆盖 ${variables.length} 个变量，全部基于有效作答计算，缺失值不参与任何统计量，也不做插补。名义分类变量不给均值与标准差（对类别编码求均值没有意义），其分布见「样本概况」。`,
    '',
    table(
      ['变量', '维度', '测量层次', 'n', '缺失', '均值', '标准差', '最小值', '最大值', '中位数', '偏度'],
      rows,
    ),
    '',
    `本次共有 ${bundle.descriptive.unusable_variables.length} 个变量没有任何有效作答（${bundle.descriptive.unusable_variables.map((item) => item.variable).join('、') || '无'}），未参与任何分析。`,
    missingHeavy && missingHeavy.missing > 0
      ? `缺失最多的是 ${missingHeavy.variable}（缺失 ${missingHeavy.missing} 例，占该变量记录数的 ${figure(missingHeavy.missing_percent)}%）。`
      : '所有变量均无缺失。',
    '',
    `可计算均值的变量 ${withMean.length} 个；名义变量 ${variables.filter((stats) => stats.data_type === 'nominal').length} 个（不给均值）。`,
    '',
    `本节口径说明（结果包原文）：${bundle.descriptive.note}`,
  ].join('\n');

  return filled('descriptive', '描述性统计', body, [
    ev('descriptive.variables.length', variables.length),
    ev('descriptive.n_respondents', bundle.descriptive.n_respondents),
    ev('descriptive.variables[].mean', variables.map((stats) => `${stats.variable}:${stats.mean}`).join('、')),
    ev('descriptive.unusable_variables.length', bundle.descriptive.unusable_variables.length),
    ev('descriptive.note', bundle.descriptive.note),
  ]);
}

function correlationSection(bundle: AnalysisBundle): SectionDraft {
  const correlation = bundle.correlation;
  if (!correlation) {
    return missing(
      'correlation',
      '相关分析',
      '本次结果包没有相关矩阵（correlation 为 null）：可用的连续/有序变量少于 2 个，或有效样本不足 4 例，或所选变量没有变异。请先确认相关变量已在问卷中测量并已收集足够样本。',
    );
  }

  const significant = correlation.pairs.filter(
    (pair) => pair.p_value !== null && pair.p_value < 0.05,
  );
  const ranked = [...correlation.pairs]
    .filter((pair) => pair.r !== null)
    .sort((left, right) => Math.abs(right.r ?? 0) - Math.abs(left.r ?? 0))
    .slice(0, 5);

  const rows: (string | number | null)[][] = correlation.pairs.map((pair) => [
    pair.left,
    pair.right,
    pair.method,
    pair.n,
    pair.r,
    pair.p_value,
    pair.effective_size ? pair.effective_size.text : null,
  ]);

  const body = [
    `相关分析覆盖 ${correlation.variables.length} 个变量，共 ${correlation.pairs.length} 组变量对。系数按测量层次选择方法，并采用成对删除（pairwise），因此各单元格的 n 可能不同。`,
    '',
    `参与变量：${correlation.variables.join('、')}。${correlation.mixed_methods ? '由于存在有序分类变量，部分变量对使用 Spearman 等级相关，矩阵中不同单元格的系数类型并不完全一致，解读时须注意。' : '所有变量对均使用 Pearson 积矩相关。'}`,
    '',
    `在 ${correlation.pairs.length} 组变量对中，达到 α = 0.05 显著水平的有 ${significant.length} 组。`,
    '',
    '按相关系数绝对值排序的前 5 组：',
    table(
      ['变量 1', '变量 2', '方法', 'n', 'r', 'p'],
      ranked.map((pair) => [pair.left, pair.right, pair.method, pair.n, pair.r, pair.p_value]),
    ),
    '',
    '全部变量对：',
    table(['变量 1', '变量 2', '方法', 'n', 'r', 'p', '效应量'], rows),
    '',
    `本节口径说明（结果包原文）：${correlation.note}`,
    '',
    '相关分析只描述变量在同一时点的共变方向与强度，不能推断因果关系，也不能排除第三个变量的影响。',
  ].join('\n');

  return filled('correlation', '相关分析', body, [
    ev('correlation.variables', correlation.variables.join('、')),
    ev('correlation.pairs.length', correlation.pairs.length),
    ev('correlation.mixed_methods', correlation.mixed_methods),
    ev('correlation.pairs[].r', ranked.map((pair) => `${pair.left}×${pair.right}:${pair.r}`).join('、')),
    ev('correlation.pairs[].p_value', ranked.map((pair) => `${pair.left}×${pair.right}:${pair.p_value}`).join('、')),
  ]);
}

function regressionSection(bundle: AnalysisBundle): SectionDraft {
  const block = bundle.regression;
  if (!block || (!block.ols && !block.ordinal)) {
    return missing(
      'regression',
      '回归分析',
      '本次结果包没有回归结果（regression 为 null 或其中各模型均为空）：因变量或自变量不存在于数据集中。请确认回归所用的变量已在问卷中测量。',
    );
  }

  const parts: string[] = [
    `平台按自变量与因变量的测量层次自动选择模型：${block.auto_selection.model}。选择依据（结果包原文）：${block.auto_selection.reason}`,
    '',
    `模型建议（结果包原文）：${block.recommendation}`,
    '',
  ];

  if (block.ols) {
    const ols = block.ols;
    parts.push(
      `线性回归（OLS）：因变量 ${ols.dependent}（${ols.dependent_label}），n = ${ols.n}，自变量 ${ols.predictors.length} 个，整例删除剔除 ${ols.dropped_cases} 例${ols.dropped_predictors.length > 0 ? `，因无变异被剔除的自变量：${ols.dropped_predictors.join('、')}` : ''}。`,
      `R² = ${figure(ols.r_squared)}，调整后 R² = ${figure(ols.adjusted_r_squared)}，F = ${figure(ols.f_statistic)}（df = ${ols.degrees_of_freedom_model}, ${ols.degrees_of_freedom_residual}），p ${significance(ols.f_p_value)}。`,
      `回归方程：${ols.equation === '' ? '（未给出）' : ols.equation}`,
      '',
      table(
        ['项', 'B', 'SE', 'Beta', 't', 'p', 'VIF'],
        ols.coefficients.map((coefficient) => [
          coefficient.term,
          coefficient.b,
          coefficient.standard_error,
          coefficient.beta,
          coefficient.t,
          coefficient.p_value,
          coefficient.vif,
        ]),
      ),
      '',
      `残差诊断：Durbin–Watson = ${figure(ols.diagnostics.durbin_watson)}，残差偏度 = ${figure(ols.diagnostics.residual_skewness)}，残差峰度 = ${figure(ols.diagnostics.residual_kurtosis)}，标准化残差绝对值最大 = ${figure(ols.diagnostics.max_abs_standardized_residual)}，|标准化残差| > 3 的个案 ${ols.diagnostics.outliers.length} 例。`,
      ols.collinearity_warnings.length > 0
        ? `共线性提示：${ols.collinearity_warnings.map((warning) => `${warning.term}（VIF = ${figure(warning.vif)}）`).join('、')}。VIF 越高，该系数的估计越不稳定。`
        : '共线性提示：所有自变量的 VIF 均未超过警戒阈值。',
      ols.warnings.length > 0 ? `模型警告（结果包原文）：${ols.warnings.join(' ')}` : '',
      '',
    );
  } else {
    parts.push('本次结果包未包含线性回归结果。', '');
  }

  if (block.ordinal) {
    const ordinal = block.ordinal;
    parts.push(
      `有序 Logistic 回归（比例优势模型）：因变量 ${ordinal.dependent}（${ordinal.dependent_label}），n = ${ordinal.n}，${ordinal.converged ? `迭代 ${ordinal.iterations} 次后收敛` : '模型未收敛，以下系数不可用于解读'}。`,
      `似然比检验：χ² = ${figure(ordinal.lr_chi_square)}，df = ${figure(ordinal.lr_degrees_of_freedom)}，p ${significance(ordinal.lr_p_value)}；McFadden R² = ${figure(ordinal.mcfadden_r_squared)}，Nagelkerke R² = ${figure(ordinal.nagelkerke_r_squared)}，分类正确率 = ${figure(ordinal.percent_correct)}%。`,
      '',
      table(
        ['项', 'Log-odds B', 'SE', 'OR', 'Wald z', 'p'],
        ordinal.coefficients.map((coefficient) => [
          coefficient.term,
          coefficient.b,
          coefficient.standard_error,
          coefficient.odds_ratio,
          coefficient.z,
          coefficient.p_value,
        ]),
      ),
      '',
      `比例优势假设检验：χ² = ${figure(ordinal.proportional_odds_test.chi_square)}，df = ${figure(ordinal.proportional_odds_test.degrees_of_freedom)}，p ${significance(ordinal.proportional_odds_test.p_value)}。${ordinal.proportional_odds_test.interpretation}`,
      `结果类别分布：${ordinal.categories.map((category) => `${category.label}（${category.count} 例）`).join('、')}。`,
      ordinal.warnings.length > 0 ? `模型警告（结果包原文）：${ordinal.warnings.join(' ')}` : '',
      '',
    );
  }

  parts.push(
    '回归系数反映在控制其余自变量后，某一自变量每变化一个单位时因变量的期望变化；本节结果是观测数据的条件关联，不是因果效应，未被纳入模型的变量仍可能造成混淆。',
  );

  const body = parts.filter((line) => line !== '').join('\n');

  return filled('regression', '回归分析', body, [
    ev('regression.auto_selection.model', block.auto_selection.model),
    ev('regression.recommendation', block.recommendation),
    ev('regression.ols.n', block.ols?.n ?? null),
    ev('regression.ols.r_squared', block.ols?.r_squared ?? null),
    ev('regression.ols.adjusted_r_squared', block.ols?.adjusted_r_squared ?? null),
    ev('regression.ols.f_statistic', block.ols?.f_statistic ?? null),
    ev('regression.ols.f_p_value', block.ols?.f_p_value ?? null),
    ev('regression.ordinal.converged', block.ordinal?.converged ?? null),
    ev('regression.ordinal.n', block.ordinal?.n ?? null),
    ev('regression.ordinal.mcfadden_r_squared', block.ordinal?.mcfadden_r_squared ?? null),
  ]);
}

function groupDifferencesSection(bundle: AnalysisBundle): SectionDraft {
  const { comparisons } = bundle;
  if (comparisons.length === 0) {
    return missing(
      'group_differences',
      '组间差异分析',
      '本次结果包没有组间比较结果（comparisons 为空）：分组变量不存在，或所选因变量在该分组下有效样本不足。请确认问卷中测量了用于分组的变量（如学段）并在样本中覆盖了各个类别。',
    );
  }

  const parts: string[] = [
    `组间比较共 ${comparisons.length} 组，分组变量为 ${comparisons[0]!.factor}（${comparisons[0]!.factor_label}），分组数 ${comparisons[0]!.groups}。每组同时给出参数与非参数结果，并说明以哪一个作为主要结论。`,
    '',
  ];

  for (const comparison of comparisons) {
    const anova = comparison.anova;
    const kruskal = comparison.kruskal_wallis;
    parts.push(
      `【${comparison.dependent}（${comparison.dependent_label}）】`,
      `单因素方差分析：F = ${figure(anova?.f ?? null)}，df = ${figure(anova?.df_between ?? null)}, ${figure(anova?.df_within ?? null)}，p ${significance(anova?.p_value ?? null)}，η² = ${figure(anova?.eta_squared ?? null)}，ω² = ${figure(anova?.omega_squared ?? null)}；方差齐性检验统计量 = ${figure(anova?.homogeneity?.statistic ?? null)}（p ${significance(anova?.homogeneity?.p_value ?? null)}）。`,
      `Kruskal–Wallis 检验：H = ${figure(kruskal?.h ?? null)}，df = ${figure(kruskal?.degrees_of_freedom ?? null)}，p ${significance(kruskal?.p_value ?? null)}，ε² = ${figure(kruskal?.epsilon_squared ?? null)}。`,
      comparison.mann_whitney
        ? `Mann–Whitney U（${comparison.mann_whitney.group_a} × ${comparison.mann_whitney.group_b}）：U = ${figure(comparison.mann_whitney.u)}，z = ${figure(comparison.mann_whitney.z)}，p ${significance(comparison.mann_whitney.p_value)}，等级双列相关 r = ${figure(comparison.mann_whitney.rank_biserial_r)}。`
        : '',
      `主要结论取值器：${comparison.recommended === 'parametric' ? '参数检验（方差分析）' : '非参数检验（Kruskal–Wallis）'}。依据（结果包原文）：${comparison.recommendation_reason}`,
      anova
        ? `各组描述（组名、n、均值、标准差）：${anova.groups.map((group) => `${group.group}（n = ${group.n}，M = ${figure(group.mean)}，SD = ${figure(group.sd)}）`).join('；')}。`
        : '',
      anova && anova.post_hoc.length > 0
        ? `事后两两比较共 ${anova.post_hoc.length} 对，校正后 p < 0.05 的有 ${anova.post_hoc.filter((pair) => pair.significant).length} 对。`
        : '',
      anova && anova.warnings.length > 0 ? `模型警告（结果包原文）：${anova.warnings.join(' ')}` : '',
      '',
    );
  }

  parts.push('组间差异反映的是样本中分组与因变量的关联。分组变量本身可能与其他未测量变量相关，不能据此把差异归因于分组因素本身。');

  return filled('group_differences', '组间差异分析', parts.filter((line) => line !== '').join('\n'), [
    ev('comparisons.length', comparisons.length),
    ev('comparisons[].factor', comparisons.map((item) => item.factor).join('、')),
    ev('comparisons[].dependent', comparisons.map((item) => item.dependent).join('、')),
    ev('comparisons[].recommended', comparisons.map((item) => `${item.dependent}:${item.recommended}`).join('、')),
    ev('comparisons[].anova.f', comparisons.map((item) => `${item.dependent}:${item.anova?.f ?? null}`).join('、')),
    ev('comparisons[].anova.p_value', comparisons.map((item) => `${item.dependent}:${item.anova?.p_value ?? null}`).join('、')),
  ]);
}

function hypothesisTestsSection(bundle: AnalysisBundle): SectionDraft {
  const { hypotheses } = bundle;
  if (hypotheses.results.length === 0) {
    return missing(
      'hypothesis_tests',
      '假设检验结果',
      '本次结果包没有假设检验结果（hypotheses.results 为空），无法报告检验结论。请在项目设置中登记假设并重新运行分析。',
    );
  }

  const lines = hypotheses.results.map((result) => {
    const verdict = VERDICT_LABELS[result.verdict] ?? result.verdict;
    return (
      `${result.code}　${result.statement}\n` +
      `　　方法：${result.method}；变量：${result.independent} × ${result.dependent}（n = ${result.n}）；` +
      `r = ${figure(result.r)}，p ${significance(result.p_value)}；` +
      `95% 置信区间 = ${result.ci_lower === null || result.ci_upper === null ? '未报告（有序变量不给出区间估计）' : `[${figure(result.ci_lower)}, ${figure(result.ci_upper)}]`}；` +
      `效应量：${result.effect_size ? `${result.effect_size.text}，判定标准 ${result.effect_size.convention}` : '未报告'}。\n` +
      `　　结论：${verdict}`
    );
  });

  const body = [
    `本节逐条报告 ${hypotheses.summary.total} 条假设的检验结果。三态判定规则为：p < α 且方向与假设一致记为「支持」；p < α 但方向与假设相反记为「不支持」（这是与假设相反的发现，不应改写假设）；p ≥ α 记为「证据不足」。`,
    '',
    `汇总：支持 ${hypotheses.summary.supported} 条、方向与假设相反 ${hypotheses.summary.not_supported} 条、证据不足 ${hypotheses.summary.inconclusive} 条、无法检验 ${hypotheses.summary.untestable} 条。`,
    '',
    ...lines,
    '',
    '关于「证据不足」的表述：本报告中它一律表示当前样本未提供足以支持该假设的统计证据，绝不表示已经证明两个变量没有关系——样本量不足、测量误差或取值范围受限都会产生同样的结果。',
    '',
    `本节口径说明（结果包原文）：${hypotheses.note}`,
  ].join('\n');

  return filled('hypothesis_tests', '假设检验结果', body, [
    ev('hypotheses.summary.total', hypotheses.summary.total),
    ev('hypotheses.summary.supported', hypotheses.summary.supported),
    ev('hypotheses.summary.not_supported', hypotheses.summary.not_supported),
    ev('hypotheses.summary.inconclusive', hypotheses.summary.inconclusive),
    ev('hypotheses.summary.untestable', hypotheses.summary.untestable),
    ev('hypotheses.results[].verdict', hypotheses.results.map((result) => `${result.code}:${result.verdict}`).join('、')),
    ev('hypotheses.results[].r', hypotheses.results.map((result) => `${result.code}:${result.r}`).join('、')),
    ev('hypotheses.results[].p_value', hypotheses.results.map((result) => `${result.code}:${result.p_value}`).join('、')),
    ev('hypotheses.note', hypotheses.note),
  ]);
}

function findingsSection(bundle: AnalysisBundle): SectionDraft {
  const { hypotheses, reliability } = bundle;
  const pairs = bundle.correlation?.pairs ?? [];
  if (hypotheses.results.length === 0 && pairs.length === 0) {
    return missing(
      'findings',
      '主要发现',
      '本次结果包既没有假设检验结果也没有相关分析结果，无法归纳主要发现。请先运行全部分析。',
    );
  }

  const supported = hypotheses.results.filter((result) => result.verdict === 'supported');
  const inconclusive = hypotheses.results.filter((result) => result.verdict === 'inconclusive');
  const opposite = hypotheses.results.filter((result) => result.verdict === 'not_supported');
  const untestable = hypotheses.results.filter((result) => result.verdict === 'untestable');
  const ranked = [...pairs]
    .filter((pair) => pair.r !== null)
    .sort((left, right) => Math.abs(right.r ?? 0) - Math.abs(left.r ?? 0));
  const strongest = ranked[0] ?? null;
  const best = [...reliability.scales]
    .filter((scale) => scale.cronbach_alpha !== null)
    .sort((left, right) => (right.cronbach_alpha ?? 0) - (left.cronbach_alpha ?? 0))[0];

  const items: string[] = [
    `本次分析的样本为 ${bundle.sample.analysable} 份（收集 ${bundle.sample.respondents_total} 份，排除 ${bundle.sample.excluded} 份），变量 ${bundle.dataset_summary.variable_count} 个，缺失值整例删除且不插补。`,
  ];

  if (best) {
    items.push(
      `内部一致性方面，${best.scale} 量表的 Cronbach α 为 ${figure(best.cronbach_alpha)}（${best.k} 个条目，n = ${best.n}），在可计算的信度系数中最高。`,
    );
  }

  if (strongest) {
    items.push(
      `变量间关系方面，绝对值最大的相关系数为 ${strongest.left} × ${strongest.right}：r = ${figure(strongest.r)}（${strongest.method}，n = ${strongest.n}，p ${significance(strongest.p_value)}）。`,
    );
  }

  if (supported.length > 0) {
    items.push(
      `在 ${hypotheses.summary.total} 条假设中，有 ${supported.length} 条获得数据支持：` +
        supported
          .map(
            (result) =>
              `${result.code}（${result.independent} × ${result.dependent}，r = ${figure(result.r)}，p ${significance(result.p_value)}）`,
          )
          .join('、') +
        '。',
    );
  } else {
    items.push(`在 ${hypotheses.summary.total} 条假设中，没有任何一条在本次数据上获得支持。`);
  }

  if (inconclusive.length > 0) {
    items.push(
      `有 ${inconclusive.length} 条假设的结果为「证据不足」：` +
        inconclusive.map((result) => result.code).join('、') +
        '。这表示当前样本未能提供支持这些假设的证据，不能解读为这些关系不存在。',
    );
  }

  if (opposite.length > 0) {
    items.push(
      `有 ${opposite.length} 条假设出现了与预期方向相反的显著结果：` +
        opposite
          .map(
            (result) =>
              `${result.code}（预期${result.direction === 'positive' ? '正向' : '负向'}，实际观察方向为${result.observed_direction === 'positive' ? '正向' : '负向'}，r = ${figure(result.r)}）`,
          )
          .join('、') +
        '。这是需要如实报告的发现，不应通过改写假设来规避。',
    );
  }

  if (untestable.length > 0) {
    items.push(
      `有 ${untestable.length} 条假设无法检验（${untestable.map((result) => result.code).join('、')}），原因是所需变量缺失或有效样本/变异不足。`,
    );
  }

  const body = [
    ...items.map((item, index) => `${index + 1}. ${item}`),
    '',
    '以上发现全部来自本次分析的结果包，逐项可在对应章节中核对。所有关联结论均为共变关系，不能推断因果。',
  ].join('\n');

  return filled('findings', '主要发现', body, [
    ev('sample.analysable', bundle.sample.analysable),
    ev('hypotheses.summary.supported', hypotheses.summary.supported),
    ev('hypotheses.summary.inconclusive', hypotheses.summary.inconclusive),
    ev('correlation.pairs[].r', strongest ? `${strongest.left}×${strongest.right}:${strongest.r}` : '无'),
    ev('reliability.scales[].cronbach_alpha', best ? `${best.scale}:${best.cronbach_alpha}` : '无'),
  ]);
}

function discussionSection(bundle: AnalysisBundle): SectionDraft {
  const { hypotheses } = bundle;
  if (hypotheses.results.length === 0) {
    return missing(
      'discussion',
      '讨论',
      '本次结果包没有假设检验结果，讨论缺乏可依据的统计事实。请先运行全部分析。',
    );
  }

  const supported = hypotheses.results.filter((result) => result.verdict === 'supported');
  const inconclusive = hypotheses.results.filter((result) => result.verdict === 'inconclusive');
  const strongest = [...supported].sort(
    (left, right) => Math.abs(right.r ?? 0) - Math.abs(left.r ?? 0),
  )[0];

  const parts: string[] = [
    '本节仅对本次分析的结果包做数据层面的解释，不引用任何文献，也不与既有研究结论作比较——与文献的对话需要研究者自行补充文献后完成（见「文献与理论依据」）。',
    '',
    `得到支持的关系共 ${supported.length} 条（共检验 ${hypotheses.summary.total} 条）。` +
      (strongest
        ? `其中关联最强的是 ${strongest.code}（${strongest.independent} × ${strongest.dependent}，r = ${figure(strongest.r)}，p ${significance(strongest.p_value)}，n = ${strongest.n}），${strongest.effect_size ? `${strongest.effect_size.text}，判定标准为 ${strongest.effect_size.convention}` : '结果包未报告效应量'}。`
        : ''),
    '',
    '这些关系是横截面数据中的共变关系，方向性解释必须谨慎：既可能是前者促进后者，也可能是后者反过来强化前者，还可能同时受第三个变量影响。结果包对此的声明为：' +
      (bundle.caveats.find((caveat) => caveat.includes('因果')) ?? '（结果包未单列因果声明）'),
    '',
    inconclusive.length > 0
      ? `未达显著的假设共 ${inconclusive.length} 条（${inconclusive.map((result) => result.code).join('、')}）。这些结果的可能来源包括样本量不足、测量误差、取值范围受限或效应本身较小；` +
        `本次有效样本为 ${bundle.sample.analysable} 份，在检验效力有限的情况下，不显著结果无法区分「关系不存在」与「证据不足」。`
      : '全部可检验的假设都得到了统计显著的结果，因此本次数据没有出现「证据不足」的判定。',
    '',
    bundle.regression
      ? `回归分析层面，${bundle.regression.auto_selection.model} 的 R²/pseudo-R² 与各系数见「回归分析」；当多个自变量同时进入模型时，某一条假设的单变量相关方向可能在控制其他变量后减弱或消失，这两类结果必须同时报告，不能只择其一。`
      : '回归分析在本次结果包中不可用，因此无法报告控制其他变量后的系数，讨论仅基于相关与组间比较结果。',
    '',
    bundle.comparisons.length > 0
      ? `组间比较层面，共报告 ${bundle.comparisons.length} 组比较，其中建议以非参数检验为主要结论的 ${bundle.comparisons.filter((item) => item.recommended === 'nonparametric').length} 组。分组差异同样属于关联证据。`
      : '本次结果包没有组间比较结果，因此不讨论分组差异。',
  ];

  const body = parts.filter((line) => line !== '').join('\n');

  return filled('discussion', '讨论', body, [
    ev('hypotheses.summary.total', hypotheses.summary.total),
    ev('hypotheses.summary.supported', hypotheses.summary.supported),
    ev('hypotheses.summary.inconclusive', hypotheses.summary.inconclusive),
    ev('sample.analysable', bundle.sample.analysable),
    ev('caveats[因果声明]', bundle.caveats.find((caveat) => caveat.includes('因果')) ?? null),
  ]);
}

function limitationsSection(bundle: AnalysisBundle): SectionDraft {
  const { caveats } = bundle;
  if (caveats.length === 0) {
    return missing(
      'limitations',
      '局限性',
      '结果包未携带任何解读前提（caveats 为空），平台不会自行编造研究局限，因此本节不生成内容。请检查分析是否完整运行。',
    );
  }

  const body = [
    `以下 ${caveats.length} 条限制为结果包（analysis bundle）原文，由统计引擎在生成结果时一并写入，任何引用本报告结论的下游材料都应同时引用这些限制：`,
    '',
    ...caveats.map((caveat, index) => `${index + 1}. ${caveat}`),
    '',
    `此外，本报告在方法层面还有两点必须声明：其一，平台不提供文献依据，报告中不存在与既有研究对照的讨论（见「文献与理论依据」）；其二，抽样方式与目标总体未记录在统计结果包中，样本代表性需由研究者依据其抽样方案判断。`,
    '',
    '本报告不包含对样本代表性的评价，也不包含对研究设计的评价。',
  ].join('\n');

  return filled('limitations', '局限性', body, [
    ev('caveats.length', caveats.length),
    ev('caveats[]', caveats.join(' ')),
    ev('sample.analysable', bundle.sample.analysable),
  ]);
}

function conclusionSection(bundle: AnalysisBundle): SectionDraft {
  const { hypotheses } = bundle;
  if (hypotheses.results.length === 0) {
    return missing(
      'conclusion',
      '结论',
      '本次结果包没有假设检验结果，无法形成结论。请先运行全部分析。',
    );
  }

  const supported = hypotheses.results.filter((result) => result.verdict === 'supported');
  const inconclusive = hypotheses.results.filter((result) => result.verdict === 'inconclusive');

  const body = [
    `第一，本研究在 ${bundle.sample.analysable} 份有效样本上完成了 ${hypotheses.summary.total} 条假设的检验，其中 ${supported.length} 条获得数据支持、${hypotheses.summary.not_supported} 条出现与预期方向相反的显著结果、${inconclusive.length} 条证据不足、${hypotheses.summary.untestable} 条无法检验。`,
    '',
    supported.length > 0
      ? `第二，获得支持的关系为：${supported
          .map(
            (result) =>
              `${result.code}（${result.independent} × ${result.dependent}，r = ${figure(result.r)}，p ${significance(result.p_value)}，n = ${result.n}）`,
          )
          .join('；')}。`
      : '第二，本次数据没有支持任何一条假设，全部结论为「证据不足」或「方向相反」。',
    '',
    inconclusive.length > 0
      ? `第三，${inconclusive.map((result) => result.code).join('、')} 在当前样本上未达到统计显著，只能得出「当前样本未提供支持证据」的结论，不能得出这些关系不存在的结论；若需就此作出判断，应先扩大样本量或改进测量。`
      : '第三，本次数据中所有可检验的假设都达到了统计显著，因此不存在「证据不足」的假设。',
    '',
    `第四，上述结论全部基于横截面数据，变量间的关系是共变关系而非因果关系；在 ${bundle.caveats.length} 条结果包限制得到满足之前，不应把本文结论用于因果性表述。`,
    '',
    '本节不含文献层面的理论结论，也不对既有研究作出评价。',
  ]
    .filter((line) => line !== '')
    .join('\n');

  return filled('conclusion', '结论', body, [
    ev('sample.analysable', bundle.sample.analysable),
    ev('hypotheses.summary.total', hypotheses.summary.total),
    ev('hypotheses.summary.supported', hypotheses.summary.supported),
    ev('hypotheses.summary.inconclusive', hypotheses.summary.inconclusive),
    ev('hypotheses.summary.untestable', hypotheses.summary.untestable),
    ev('caveats.length', bundle.caveats.length),
  ]);
}

function policyRecommendations(bundle: AnalysisBundle): SectionDraft {
  const wanted = ['PSA', 'PSU', 'FED', 'DSD', 'STI'];
  const present = wanted.filter((name) => descriptiveOf(bundle, name)?.mean !== null);
  if (present.length === 0) {
    return missing(
      'policy_recommendations',
      '政策与管理建议',
      `数据集中没有可用于公共服务的测量变量（${wanted.join('、')} 均无有效均值），平台不会在没有任何数据依据的情况下给出政策建议。请先在问卷中测量公共服务知晓、获取与使用等变量并收集数据。`,
    );
  }

  const items: string[] = [];
  const psa = descriptiveOf(bundle, 'PSA');
  const psu = descriptiveOf(bundle, 'PSU');
  const fed = descriptiveOf(bundle, 'FED');
  const sti = descriptiveOf(bundle, 'STI');

  if (psa && psa.mean !== null) {
    items.push(
      `公共服务知晓与获取方面：PSA 的均值为 ${figure(psa.mean)}（n = ${psa.n}，标准差 ${figure(psa.standard_deviation)}）。` +
        `该均值反映的是家长对公共服务「知晓清晰度与获取便利性」的自评水平（理论取值 1—5）；若该均值低于量表中点，说明知晓与获取环节仍有提升空间，否则应以维持现有信息渠道为主。是否低于中点需按研究设计中的量表定义判断，本节不代为判定。`,
    );
  }
  if (psu && psu.mean !== null) {
    items.push(
      `服务使用环节：PSU 的均值为 ${figure(psu.mean)}（n = ${psu.n}）。建议结合「组间差异分析」中按学段的分组结果，判断是否需要针对特定学段加强服务供给。`,
    );
  }
  if (fed && fed.mean !== null) {
    const fedItems = bundle.descriptive.variables.filter(
      (stats) => stats.variable.startsWith('FED') && stats.variable !== 'FED' && stats.mean !== null,
    );
    const worst = [...fedItems].sort((left, right) => (right.mean ?? 0) - (left.mean ?? 0))[0];
    items.push(
      `困难优先序方面：家庭教育困难总体均值为 ${figure(fed.mean)}（n = ${fed.n}）。` +
        (worst
          ? `在 ${fedItems.length} 个困难方面中，均值最高的是 ${worst.variable}（${worst.label}，均值 ${figure(worst.mean)}）。困难程度是需求判断的直接依据，建议把资源优先投向均值最高的方面；该排序只适用于本次样本所覆盖的困难清单。`
          : '本次数据未展开逐方面的困难变量，无法给出优先序。'),
    );
  }
  if (sti && sti.mean !== null) {
    items.push(
      `信任基础方面：服务主体信任度 STI 的均值为 ${figure(sti.mean)}（n = ${sti.n}）。信任水平会直接影响家长对服务的接受程度，建议在服务告知环节明确提供主体、资质与隐私处理方式。`,
    );
  }

  const comparisons = bundle.comparisons.filter((item) => item.recommended === 'nonparametric');
  if (comparisons.length > 0) {
    items.push(
      `需要在方法上注明：以下组间比较建议以非参数检验为主要结论，相关结论应按非参数结果报告——${comparisons.map((item) => item.dependent).join('、')}。`,
    );
  }

  const body = [
    `本节建议由平台依据上述统计结果推导得出，共 ${items.length} 条；每一条都附有其依据的统计量。`,
    '',
    ...items.map((item, index) => `${index + 1}. ${item}`),
    '',
    '本节不含政策文件依据，也不含文献依据——平台离线运行，未接入任何政策文本库或文献库。发布前请结合本地政策环境、责任主体与预算条件核实，任何建议在缺少制度依据时都不应直接作为政策表述。',
  ].join('\n');

  return filled('policy_recommendations', '政策与管理建议', body, [
    ev('descriptive.variables[PSA].mean', psa?.mean ?? null),
    ev('descriptive.variables[PSU].mean', psu?.mean ?? null),
    ev('descriptive.variables[FED].mean', fed?.mean ?? null),
    ev('descriptive.variables[STI].mean', sti?.mean ?? null),
    ev('comparisons[].recommended', bundle.comparisons.map((item) => `${item.dependent}:${item.recommended}`).join('、')),
  ]);
}

function serviceRecommendations(bundle: AnalysisBundle): SectionDraft {
  const wanted = ['DSD', 'UI', 'PRC', 'WTP', 'ISC'];
  const present = wanted.filter((name) => descriptiveOf(bundle, name)?.mean !== null);
  if (present.length === 0) {
    return missing(
      'service_recommendations',
      '服务优化建议',
      `数据集中没有可用于服务优化的测量变量（${wanted.join('、')} 均无有效均值），平台不会在没有任何数据依据的情况下给出服务优化建议。`,
    );
  }

  const items: string[] = [];
  const dsd = descriptiveOf(bundle, 'DSD');
  const dsdItems = bundle.descriptive.variables.filter(
    (stats) => stats.variable.startsWith('DSD') && stats.variable !== 'DSD' && stats.mean !== null,
  );
  const top = [...dsdItems].sort((left, right) => (right.mean ?? 0) - (left.mean ?? 0))[0];
  const ui = descriptiveOf(bundle, 'UI');
  const prc = descriptiveOf(bundle, 'PRC');
  const wtp = descriptiveOf(bundle, 'WTP');

  if (dsd && dsd.mean !== null) {
    items.push(
      `数字化服务需求：DSD 均值为 ${figure(dsd.mean)}（n = ${dsd.n}）。` +
        (top
          ? `在 ${dsdItems.length} 类数字化服务中，需求均值最高的是 ${top.variable}（${top.label}，均值 ${figure(top.mean)}），功能排期应优先覆盖该项。`
          : '本次数据未展开逐类服务变量，无法给出功能优先序。'),
    );
  }
  if (ui && ui.mean !== null) {
    items.push(
      `AI 服务接受度：UI 均值为 ${figure(ui.mean)}（n = ${ui.n}，${ui.data_type === 'ordinal' ? '有序分类变量' : ui.data_type}）。` +
        '该指标只反映使用意愿，是否上线 AI 功能还应结合风险认知数据判断。' +
        `回归分析中该因变量的模型选择与系数见「回归分析」${bundle.regression ? `（自动选择模型：${bundle.regression.auto_selection.model}）` : '（本次未运行回归）'}。`,
    );
  }
  if (prc && prc.mean !== null) {
    items.push(
      `风险认知：PRC 均值为 ${figure(prc.mean)}（n = ${prc.n}）。建议在服务设计中对隐私与专业性顾虑给出明确处理说明，并把风险提示放在授权环节之前。`,
    );
  }
  if (wtp && wtp.mean !== null) {
    items.push(
      `付费意愿：WTP 均值为 ${figure(wtp.mean)}（n = ${wtp.n}）。付费意愿属于意愿指标而非实际购买行为，不能直接用于定价测算；如需定价依据，应另行收集支付意愿实验或实际购买数据。`,
    );
  }

  const body = [
    `本节建议由平台依据上述统计结果推导得出，共 ${items.length} 条；每一条都附有其依据的统计量。`,
    '',
    ...items.map((item, index) => `${index + 1}. ${item}`),
    '',
    `说明：本节建议仅基于本次 ${bundle.sample.analysable} 份样本的描述统计与关系分析，不含文献依据，也未做服务成本与可行性的评估。落地前应结合服务承载能力与用户访谈验证。`,
  ].join('\n');

  return filled('service_recommendations', '服务优化建议', body, [
    ev('descriptive.variables[DSD].mean', dsd?.mean ?? null),
    ev('descriptive.variables[UI].mean', ui?.mean ?? null),
    ev('descriptive.variables[PRC].mean', prc?.mean ?? null),
    ev('descriptive.variables[WTP].mean', wtp?.mean ?? null),
    ev('sample.analysable', bundle.sample.analysable),
  ]);
}
function referencesAppendix(): SectionDraft {
  const reason =
    '平台不生成参考文献：离线环境没有文献来源，任何自动生成的条目都无法被溯源。' +
    '参考文献必须由研究者按目标期刊或评审要求自行撰写并逐条核对。';
  const body = [
    '参考文献部分：本报告正文不含任何文献引用，因此没有需要核对的条目。参考文献列表必须由研究者提供；请勿把平台生成的任何文本当作文献来源。',
    '',
    `原因：${reason}`,
    '',
    '附录部分：可由平台已生成的导出文件组成，研究者按目标刊物的要求编号与取舍即可：',
    '- 原始数据：宽表 CSV（含 UTF-8 BOM，便于 Excel 正确打开中文）与 JSON（含元数据与编码簿）；',
    '- 变量字典与编码簿：codebook.csv，以及 SPSS 的语法文件与配套数据文件；',
    '- 分析结果工作簿：results.xlsx，含原始数据、变量字典、编码簿与各分析工作表；',
    '- 研究报告文本：本报告本身。',
    '',
    '请注意：导出文件中的样本数与本报告「数据来源与抽样」一节必须一致；若在两次导出之间又收集或排除了样本，应重新运行分析后再导出，以免正文与附录对不上。',
  ].join('\n');

  return missing('references_appendix', '参考文献与附录', reason, body);
}

/* ================================================================== */
/* Assembly                                                           */
/* ================================================================== */

/**
 * Build the 23 sections, in the documented fixed order.
 *
 * Pure: the result depends only on its three arguments, so a test can assert the
 * wording and the numbers without a server, a database or a clock.
 */
export function buildReportSections(
  bundle: AnalysisBundle,
  dataset: Dataset,
  summary: SampleSummary,
): ReportSection[] {
  // `summary` is the analysis sample summary. The bundle carries the same
  // numbers, but the argument is the one the caller just loaded, so a mismatch
  // is worth surfacing rather than hiding: see `summaryDiscrepancy`.
  const drafts: SectionDraft[] = [
    titleAbstract(bundle),
    background(bundle, dataset),
    objectives(bundle),
    hypothesesSection(bundle),
    literature(),
    method(bundle),
    sampling(bundle),
    sampleProfile(bundle),
    instrument(bundle, dataset),
    reliabilitySection(bundle),
    validitySection(bundle),
    descriptiveSection(bundle),
    correlationSection(bundle),
    regressionSection(bundle),
    groupDifferencesSection(bundle),
    hypothesisTestsSection(bundle),
    findingsSection(bundle),
    discussionSection(bundle),
    limitationsSection(bundle),
    conclusionSection(bundle),
    policyRecommendations(bundle),
    serviceRecommendations(bundle),
    referencesAppendix(),
  ];

  const discrepancy = summaryDiscrepancy(summary, bundle);
  if (discrepancy) drafts[0]!.body += `\n\n${discrepancy}`;

  return drafts.map((draft, position) => ({
    index: position + 1,
    key: draft.key,
    title: draft.title,
    body: draft.body,
    evidence: draft.evidence,
    available: draft.available,
    unavailable_reason: draft.unavailable_reason,
  }));
}

/**
 * The one place the passed-in summary is compared with the bundle's own.
 *
 * The report is built from a freshly loaded sample and a *stored* bundle; if the
 * two disagree, sample numbers in the prose would silently describe a different
 * dataset than the statistics. The mismatch is stated in the report rather than
 * resolved silently by preferring one of them.
 */
function summaryDiscrepancy(summary: SampleSummary, bundle: AnalysisBundle): string | null {
  if (
    summary.analysable === bundle.sample.analysable &&
    summary.respondents_total === bundle.sample.respondents_total
  ) {
    return null;
  }
  return (
    `⚠ 数据一致性提示：本次重新装载的样本（收集 ${summary.respondents_total} 份，进入分析 ${summary.analysable} 份）` +
    `与结果包记录的样本（收集 ${bundle.sample.respondents_total} 份，进入分析 ${bundle.sample.analysable} 份）不一致。` +
    '本报告中的统计量全部取自结果包，上述差异说明在分析运行之后样本发生了变化，请重新运行分析后再使用本报告。'
  );
}

/** Counting rule: CJK characters count as words, Latin runs as single words. */
export function countWords(text: string): number {
  const cjk = text.match(/[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/g) ?? [];
  const latin = text.match(/[A-Za-z][A-Za-z0-9._-]*/g) ?? [];
  return cjk.length + latin.length;
}

/** Render the sections as a Chinese Markdown document. */
export function renderReportMarkdown(
  sections: ReportSection[],
  meta: {
    projectTitle: string;
    questionnaireTitle: string | null;
    engineVersion: string;
    analyserGeneratedAt: string;
    generatedAt: string;
    caveats: string[];
  },
): string {
  const header = [
    `# ${meta.projectTitle} 研究报告`,
    '',
    `- 研究题目：${meta.projectTitle}`,
    `- 问卷：${meta.questionnaireTitle ?? '（未登记问卷）'}`,
    `- 统计引擎版本：${meta.engineVersion}`,
    `- 结果包生成时间：${meta.analyserGeneratedAt}`,
    `- 报告生成时间：${meta.generatedAt}`,
    `- 章节数：${sections.length}（其中 ${sections.filter((section) => section.available).length} 节由数据生成，${sections.filter((section) => !section.available).length} 节需研究者补充）`,
    '',
    '> 本报告的全部统计数字来自上述结果包，未做任何人工修改；缺失值不插补，未作答与敏感拒答均按缺失处理。',
    '> 报告中不含任何文献引用：平台离线运行，不生成也无法核验参考文献。',
    '',
    '---',
  ].join('\n');

  const body = sections
    .map((section) => {
      const status = section.available ? '' : '（本平台无法生成，需研究者补充）';
      // The reason is repeated only when the body does not already state it, so
      // a reader never wades through the same paragraph twice.
      const reason =
        section.unavailable_reason && !section.body.includes(section.unavailable_reason)
          ? `\n\n> 未生成原因：${section.unavailable_reason}`
          : '';
      return `## ${section.index}. ${section.title}${status}\n\n${section.body}${reason}`;
    })
    .join('\n\n---\n\n');

  const caveats = [
    '---',
    '',
    '## 结果包解读前提（原文）',
    '',
    ...meta.caveats.map((caveat, index) => `${index + 1}. ${caveat}`),
  ].join('\n');

  return `${header}\n\n${body}\n\n${caveats}\n`;
}

/** Build the complete report: structured sections plus the rendered Markdown. */
export function buildResearchReport(
  bundle: AnalysisBundle,
  dataset: Dataset,
  summary: SampleSummary,
  options: { generatedAt?: string } = {},
): ResearchReport {
  const generatedAt = options.generatedAt ?? nowIso();
  const sections = buildReportSections(bundle, dataset, summary);
  const questionnaireTitle = bundle.questionnaire?.title ?? null;

  const markdown = renderReportMarkdown(sections, {
    projectTitle: bundle.project.title,
    questionnaireTitle,
    engineVersion: bundle.engine_version,
    analyserGeneratedAt: bundle.generated_at,
    generatedAt,
    caveats: bundle.caveats,
  });

  return {
    report_type: 'research_report',
    project_id: bundle.project.id,
    project_title: bundle.project.title,
    questionnaire_title: questionnaireTitle,
    engine_version: bundle.engine_version,
    analyser_generated_at: bundle.generated_at,
    generated_at: generatedAt,
    sections,
    section_count: sections.length,
    available_sections: sections.filter((section) => section.available).length,
    unavailable_sections: sections.filter((section) => !section.available).length,
    caveats: bundle.caveats.slice(),
    markdown,
    word_count: countWords(markdown),
  };
}

/**
 * File name for the Markdown download.
 *
 * Built from the same project slug and date logic as the data exports (the
 * export service owns that logic), so a report and its dataset end up beside
 * each other in a downloads folder with a recognisable shared prefix.
 */
export function reportMarkdownFilename(
  report: Pick<ResearchReport, 'project_title' | 'questionnaire_title' | 'generated_at'>,
): string {
  const filenames = exportFilenames({
    projectTitle: report.project_title,
    questionnaireTitle: report.questionnaire_title ?? '（未命名问卷）',
    questionnaireVersion: '',
    exportedAt: report.generated_at,
    respondentsTotal: 0,
  });
  return filenames.csv.replace(/\.csv$/, '-report.md');
}
