/**
 * Copy index.html into dist.
 *
 * Kept as a tiny script rather than a bundler plugin because the HTML has no
 * build-time templating: assets are referenced by fixed paths.
 */

import { copyFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const target = resolve(root, 'dist', 'index.html');

mkdirSync(dirname(target), { recursive: true });
copyFileSync(resolve(root, 'index.html'), target);
console.log(`[web] copied index.html -> ${target}`);
