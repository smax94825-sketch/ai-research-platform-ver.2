/**
 * Variable dictionary / codebook generator.
 *
 * Produces the "Variable Dictionary" sheet required by the export module:
 * variable name, question code, question text, dimension, data type, coding,
 * missing value handling, scoring rule and the analysis method that the
 * statistical engine will apply to that variable's measurement level.
 *
 * The dictionary is derived from the *stored questionnaire* rather than from a
 * hard-coded list, so a researcher who edits the instrument gets an accurate
 * codebook for the version they actually fielded.
 */

import type {
  DataType,
  Question,
  QuestionOption,
  ScoringRule,
  VariableDefinition,
} from './types.js';
import { FAMILY_EDU_V4_COMPOSITES, type CompositeSpec } from './template/familyEduV4.js';

/* ------------------------------------------------------------------ */
/* Inference helpers                                                  */
/* ------------------------------------------------------------------ */

/** Human readable description of how an answer is coded numerically. */
export function describeCoding(question: Question): string {
  const rule = question.scoring_rule;
  const choices = question.options?.choices ?? [];
  const matrix = question.options?.matrix;

  switch (question.question_type) {
    case 'matrix': {
      const cols = matrix?.columns ?? [];
      const range = cols.length > 0 ? `1—${cols.length}` : '1—5';
      const prefix = question.variable_name ?? question.question_code;
      const rowVars = (matrix?.rows ?? []).map((r) => `${prefix}${r.value}`);
      return (
        `按行计分，每行取所选列的次序分值（${range}）；` +
        `行变量为 ${rowVars.join('、')}；` +
        '该题为维度均值变量的来源，不单独进入回归。'
      );
    }
    case 'knowledge_test':
      return '答对＝1，答错＝0，"不清楚"＝0；总分为各题之和（LKA）。';
    case 'multiple': {
      const excl = choices.filter((c) => c.exclusive).map((c) => c.value);
      return excl.length > 0
        ? `记录所选项代码集合；计分时排除互斥选项（${excl.join('、')}），取有效选项数量。`
        : '记录所选项代码集合；计分时取选中项数量（广度指标）。';
    }
    case 'ranking':
      return '记录各选项的排序位次（1＝第一顺位），按选项分别生成位次变量。';
    case 'number':
      return '直接记录原始数值。';
    case 'text':
    case 'textarea':
      return '记录原始文本，不进行数值编码；分析时采用主题编码或文本挖掘。';
    case 'date':
      return '记录 ISO 日期（YYYY-MM-DD）。';
    case 'likert':
    case 'single':
    case 'dropdown': {
      if (rule && (rule.type === 'categorical' || rule.type === 'ordinal')) {
        const parts = Object.entries(rule.codes).map(([code, value]) =>
          value === null ? `${code}→缺失` : `${code}→${value}`,
        );
        const level = rule.type === 'ordinal' ? '有序分类' : '名义分类';
        return `${level}编码：${parts.join('，')}。`;
      }
      return choices.length > 0
        ? `按选项顺序赋分 1—${choices.length}（原始选项代码：${choices
            .map((c) => c.value)
            .join('、')}）。`
        : '按选项顺序赋分。';
    }
    default:
      return '按原始作答记录。';
  }
}

/** Describe how missing and sensitive non-response are represented. */
export function describeMissing(question: Question): string {
  const choices = question.options?.choices ?? [];
  const sensitive = choices.filter((c) => c.sensitiveNonResponse);
  const parts: string[] = ['未作答＝系统缺失（不填补、不记为0）'];
  if (sensitive.length > 0) {
    parts.push(
      `敏感拒答（${sensitive.map((c) => `选项${c.value}「${c.label}」`).join('、')}）＝敏感未作答，` +
        '单独编码为缺失，绝不并入实质性类别',
    );
  }
  const rule = question.scoring_rule;
  if (rule && (rule.type === 'categorical' || rule.type === 'ordinal')) {
    const nulls = Object.entries(rule.codes)
      .filter(([, v]) => v === null)
      .map(([k]) => k);
    if (nulls.length > 0) parts.push(`选项${nulls.join('、')}在统计分析中按缺失处理`);
  }
  return parts.join('；') + '。';
}

export function describeScoringRule(rule: ScoringRule | null): string {
  if (!rule) return '无特殊计分规则。';
  switch (rule.type) {
    case 'none':
      return '不参与数值计分。';
    case 'mean':
      return `维度均值：对有效作答项取平均${rule.min !== undefined && rule.max !== undefined ? `（理论取值 ${rule.min}—${rule.max}）` : ''}。至少需1项有效作答。`;
    case 'sum':
      return `维度总分：对有效作答项求和${rule.min !== undefined && rule.max !== undefined ? `（理论取值 ${rule.min}—${rule.max}）` : ''}。`;
    case 'reverse':
      return `反向计分：按 ${rule.min}＋${rule.max}－原始分 进行反转。`;
    case 'knowledge':
      return `知识计分：答对＝${rule.correctScore}，答错＝${rule.incorrectScore}，"不清楚"＝${rule.unknownScore}；理论总分 0—${rule.maxScore}。`;
    case 'categorical':
      return '名义分类编码：按选项中声明的映射关系转换为分析用代码，映射为空的选项视为缺失。';
    case 'ordinal':
      return '有序分类编码：按选项中声明的映射关系转换为有序分析用代码，映射为空的选项视为缺失。';
    case 'count':
      return `计数编码：统计所选选项数量${rule.excludeExclusive !== false ? '（排除互斥选项）' : ''}。`;
    default:
      return '无特殊计分规则。';
  }
}

export function inferDataType(question: Question): DataType {
  const rule = question.scoring_rule;
  const choices = question.options?.choices ?? [];

  switch (question.question_type) {
    case 'matrix':
      return 'interval';
    case 'knowledge_test':
      return 'interval';
    case 'multiple':
      return 'count';
    case 'number':
      return 'ratio';
    case 'text':
    case 'textarea':
      return 'text';
    case 'date':
      return 'text';
    case 'ranking':
      return 'ordinal';
    case 'likert':
      return 'ordinal';
    case 'single':
    case 'dropdown': {
      // The declared scoring rule states the measurement level explicitly.
      // Inferring ordinality from a 1..k code sequence would misclassify
      // nominal variables such as 父亲／母亲／祖辈.
      if (rule && rule.type === 'ordinal') return 'ordinal';
      if (rule && rule.type === 'categorical') return 'nominal';
      return choices.length >= 3 ? 'ordinal' : 'nominal';
    }
    default:
      return 'nominal';
  }
}

export function inferAnalysisMethod(question: Question, dataType: DataType): string {
  switch (dataType) {
    case 'nominal':
      return '频数分布与百分比；组间比较采用卡方检验；作为自变量时进入多元回归需先虚拟编码。';
    case 'ordinal':
      return '频数分布、中位数与四分位距；组间比较采用非参数检验（Mann-Whitney U 或 Kruskal-Wallis H）；因变量为有序分类时采用有序 Logistic 回归；作连续处理时需说明依据。';
    case 'interval':
      return '均值、标准差、最小值、最大值；Pearson 相关；组间比较采用独立样本 t 检验或单因素 ANOVA；进入多元线性回归。';
    case 'ratio':
      return '均值、标准差、中位数；分布偏态时改用中位数与稳健统计量。';
    case 'count':
      return '计数分布与均值；组间比较采用非参数检验（Mann-Whitney U 或 Kruskal-Wallis H）。';
    case 'text':
      return '文本主题编码、词频统计；不参与数值统计检验。';
    default:
      return '描述性统计。';
  }
}

/* ------------------------------------------------------------------ */
/* Item-level dictionary                                              */
/* ------------------------------------------------------------------ */

/**
 * Expand one question into one or more dictionary rows.
 * Matrix questions produce a row per row-item plus a row for the composite.
 */
export function describeQuestion(question: Question): VariableDefinition[] {
  const dimension = question.dimension ?? '未分类';
  const baseVariable = question.variable_name ?? question.question_code;
  const dataType = inferDataType(question);
  const coding = describeCoding(question);
  const missing = describeMissing(question);
  const scoring = describeScoringRule(question.scoring_rule);
  const analysis = inferAnalysisMethod(question, dataType);

  if (question.question_type === 'matrix') {
    const rows = question.options?.matrix?.rows ?? [];
    const rowDefs: VariableDefinition[] = rows.map((row) => ({
      variable_name: `${baseVariable}${row.value}`,
      question_code: question.question_code,
      question_text: `${question.question_text} — ${row.label}`,
      dimension,
      data_type: 'ordinal',
      coding: coding,
      missing_value: missing,
      scoring_rule: scoring,
      analysis_method:
        '频数分布与均值；作为维度条目的信度与因素分析输入；组间比较采用非参数检验。',
      is_derived: false,
      note: `矩阵题 ${question.question_code} 的第 ${row.value} 行。`,
    }));

    rowDefs.push({
      variable_name: baseVariable,
      question_code: question.question_code,
      question_text: question.question_text,
      dimension,
      data_type: 'interval',
      coding: coding,
      missing_value: missing,
      scoring_rule: scoring,
      analysis_method: analysis,
      is_derived: true,
      note: `由 ${question.question_code} 各行得分求均值得出的维度变量。`,
    });

    return rowDefs;
  }

  if (question.question_type === 'page_break') return [];

  return [
    {
      variable_name: baseVariable,
      question_code: question.question_code,
      question_text: question.question_text,
      dimension,
      data_type: dataType,
      coding,
      missing_value: missing,
      scoring_rule: scoring,
      analysis_method: analysis,
      is_derived: false,
      note: question.help_text ?? '',
    },
  ];
}

/* ------------------------------------------------------------------ */
/* Composite variables                                                */
/* ------------------------------------------------------------------ */

function describeComposite(spec: CompositeSpec, availableCodes: Set<string>): VariableDefinition {
  const present = spec.sources.filter((code) => availableCodes.has(code));
  const aggregationText =
    spec.aggregation === 'mean'
      ? '取各来源题项有效得分的算术平均'
      : spec.aggregation === 'sum'
        ? '取各来源题项得分之和'
        : spec.aggregation === 'count'
          ? '取所选选项数量'
          : '先分别标准化再取平均（派生综合指数）';

  const analysisByType: Record<string, string> = {
    interval:
      '均值与标准差；Pearson 相关；独立样本 t 检验 / 单因素 ANOVA；作为自变量或因变量进入多元线性回归；信度分析（Cronbach\'s α）与 EFA。',
    ordinal:
      '频数分布与中位数；Spearman 相关；组间比较采用非参数检验（Mann-Whitney U 或 Kruskal-Wallis H）；作为因变量时采用有序 Logistic 回归。',
    count: '计数分布；组间比较采用非参数检验（Mann-Whitney U 或 Kruskal-Wallis H）。',
  };

  return {
    variable_name: spec.variable_name,
    question_code: present.join('、') || spec.sources.join('、'),
    question_text: spec.label,
    dimension: spec.dimension,
    data_type: spec.data_type,
    coding: `${aggregationText}。来源题项：${present.join('、') || spec.sources.join('、')}。`,
    missing_value:
      '参与计算的题项全部缺失时该变量记为缺失；部分缺失时按有效题项计算并记录 n。不进行插补。',
    scoring_rule: `派生变量（构造方式：${spec.aggregation}）。`,
    analysis_method: analysisByType[spec.data_type] ?? '描述性统计。',
    is_derived: true,
    note: spec.note,
  };
}

/* ------------------------------------------------------------------ */
/* Public API                                                         */
/* ------------------------------------------------------------------ */

export interface DictionaryOptions {
  /** Include the platform's derived composite variables (default true). */
  includeComposites?: boolean;
  /** Extra composite specs; defaults to the V4.0 template set. */
  composites?: CompositeSpec[];
}

/**
 * Build the full variable dictionary for a questionnaire.
 * Sorted by first appearance of the question code in instrument order.
 */
export function buildVariableDictionary(
  questions: Question[],
  options: DictionaryOptions = {},
): VariableDefinition[] {
  const ordered = [...questions].sort((a, b) => a.sort_order - b.sort_order);
  const defs: VariableDefinition[] = [];

  for (const question of ordered) {
    defs.push(...describeQuestion(question));
  }

  if (options.includeComposites !== false) {
    const available = new Set(ordered.map((q) => q.question_code));
    const specs = options.composites ?? FAMILY_EDU_V4_COMPOSITES;
    for (const spec of specs) {
      const hasSource = spec.sources.some((code) => available.has(code));
      if (hasSource) defs.push(describeComposite(spec, available));
    }
  }

  return defs;
}

/** Render the dictionary as CSV text ready for the export module. */
export function dictionaryToCsv(defs: VariableDefinition[]): string {
  const headers = [
    'Variable Name',
    'Question Code',
    'Question Text',
    'Dimension',
    'Data Type',
    'Coding',
    'Missing Value',
    'Scoring Rule',
    'Analysis Method',
    'Derived',
    'Note',
  ];
  const escape = (value: string): string => {
    const needsQuotes = /[",\n\r]/.test(value);
    const escaped = value.replace(/"/g, '""');
    return needsQuotes ? `"${escaped}"` : escaped;
  };
  const rows = defs.map((d) =>
    [
      d.variable_name,
      d.question_code,
      d.question_text,
      d.dimension,
      d.data_type,
      d.coding,
      d.missing_value,
      d.scoring_rule,
      d.analysis_method,
      d.is_derived ? '是' : '否',
      d.note,
    ]
      .map((v) => escape(String(v ?? '')))
      .join(','),
  );
  return [headers.join(','), ...rows].join('\n');
}

/** Options of a question rendered as a compact code list for the codebook. */
export function optionCodeList(choices: QuestionOption[] | undefined): string {
  return (choices ?? []).map((c) => `${c.value}=${c.label}`).join(' | ');
}
