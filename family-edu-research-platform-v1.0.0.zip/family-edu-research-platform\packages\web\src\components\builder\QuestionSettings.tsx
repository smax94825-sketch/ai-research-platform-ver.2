/**
 * Question settings panel (right column of the builder).
 *
 * Edits a local draft and only persists on save, so an accidental keystroke
 * never rewrites a fielded instrument. Option-level flags (correct answer,
 * mutually exclusive, sensitive non-response) are exposed explicitly because
 * they change how the statistical engine treats the data.
 */

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  CHOICE_BASED_TYPES,
  QUESTION_TYPES,
  QUESTION_TYPE_LABELS,
  type Question,
  type QuestionOption,
  type QuestionType,
  type ScoringRule,
} from '@ferp/shared';
import { Alert, Button, Checkbox, Field, Input, Select, Textarea } from '../ui';

export interface QuestionDraft {
  question_text: string;
  question_type: QuestionType;
  options: Question['options'];
  required: boolean;
  dimension: string | null;
  variable_name: string | null;
  section: string | null;
  help_text: string | null;
  scoring_rule: ScoringRule | null;
}

interface QuestionSettingsProps {
  question: Question;
  editable: boolean;
  saving: boolean;
  onSave: (draft: QuestionDraft) => Promise<void>;
  onCancel: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
  fieldError: string | null;
}

function toDraft(question: Question): QuestionDraft {
  return {
    question_text: question.question_text,
    question_type: question.question_type,
    options: structuredClone(question.options ?? {}),
    required: question.required,
    dimension: question.dimension,
    variable_name: question.variable_name,
    section: question.section,
    help_text: question.help_text,
    scoring_rule: question.scoring_rule ? structuredClone(question.scoring_rule) : null,
  };
}

export function QuestionSettings({
  question,
  editable,
  saving,
  onSave,
  onCancel,
  onDelete,
  onDuplicate,
  fieldError,
}: QuestionSettingsProps): ReactNode {
  const [draft, setDraft] = useState<QuestionDraft>(() => toDraft(question));
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    setDraft(toDraft(question));
    setDirty(false);
  }, [question]);

  const update = (patch: Partial<QuestionDraft>): void => {
    setDraft((current) => ({ ...current, ...patch }));
    setDirty(true);
  };

  const choices = draft.options.choices ?? [];
  const setChoices = (next: QuestionOption[]): void => {
    update({ options: { ...draft.options, choices: next } });
  };

  const isChoiceBased = CHOICE_BASED_TYPES.includes(draft.question_type);
  const isMatrix = draft.question_type === 'matrix';
  const isKnowledge = draft.question_type === 'knowledge_test';

  const scoringSummary = useMemo(() => describeScoring(draft.scoring_rule), [draft.scoring_rule]);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-ink-200 px-4 py-3">
        <h2 className="text-sm font-semibold text-ink-900">Question Settings</h2>
        <p className="mt-0.5 font-mono text-xs text-ink-500">
          {question.question_code} · {questionTypeLabelSafe(draft.question_type)}
        </p>
      </div>

      <div className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
        {!editable && (
          <Alert tone="warning" title="问卷已锁定">
            该版本已发布，无法直接修改。请在「发布」标签页建立新版本后再编辑。
          </Alert>
        )}

        {fieldError && <Alert tone="danger">{fieldError}</Alert>}

        <Field label="题干（引导语）" required={draft.question_type !== 'page_break'}>
          <Textarea
            rows={isMatrix ? 2 : 3}
            value={draft.question_text}
            disabled={!editable}
            onChange={(event) => update({ question_text: event.target.value })}
          />
        </Field>

        <Field label="题型" hint="切换题型会保留已有选项，但可能需要重新配置。">
          <Select
            value={draft.question_type}
            disabled={!editable}
            onChange={(event) => update({ question_type: event.target.value as QuestionType })}
          >
            {QUESTION_TYPES.map((type) => (
              <option key={type} value={type}>
                {QUESTION_TYPE_LABELS[type]}
              </option>
            ))}
          </Select>
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="变量名" hint="SPSS 兼容：字母开头，字母数字下划线。">
            <Input
              value={draft.variable_name ?? ''}
              disabled={!editable}
              onChange={(event) => update({ variable_name: event.target.value || null })}
              placeholder="例如 FSE1"
            />
          </Field>
          <Field label="研究维度">
            <Input
              value={draft.dimension ?? ''}
              disabled={!editable}
              onChange={(event) => update({ dimension: event.target.value || null })}
              placeholder="例如 家庭教育自我效能"
            />
          </Field>
        </div>

        <Field label="所属部分">
          <Input
            value={draft.section ?? ''}
            disabled={!editable}
            onChange={(event) => update({ section: event.target.value || null })}
            placeholder="例如 第五部分　家庭教育自我效能"
          />
        </Field>

        <Field label="辅助说明" hint="显示在题干下方，例如敏感题的匿名与自愿说明。">
          <Textarea
            rows={2}
            value={draft.help_text ?? ''}
            disabled={!editable}
            onChange={(event) => update({ help_text: event.target.value || null })}
          />
        </Field>

        <Checkbox
          checked={draft.required}
          disabled={!editable}
          onChange={(next) => update({ required: next })}
          label="必答（敏感题应保持非必答，允许受访者拒答）"
        />

        {/* Options ------------------------------------------------------ */}
        {isChoiceBased && (
          <div className="rounded-md border border-ink-200 p-3">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-ink-500">选项</h3>
              <Button
                variant="ghost"
                disabled={!editable}
                onClick={() =>
                  setChoices([
                    ...choices,
                    { value: String(choices.length + 1), label: `选项 ${choices.length + 1}` },
                  ])
                }
              >
                + 添加选项
              </Button>
            </div>

            {choices.length === 0 && (
              <p className="text-xs text-ink-400">该题型至少需要一个选项，否则无法保存或发布。</p>
            )}

            <ul className="space-y-2">
              {choices.map((choice, index) => (
                <li key={`${choice.value}-${index}`} className="rounded border border-ink-200 p-2">
                  <div className="flex items-center gap-2">
                    <Input
                      className="w-16 shrink-0"
                      value={choice.value}
                      disabled={!editable}
                      onChange={(event) => {
                        const next = [...choices];
                        next[index] = { ...choice, value: event.target.value };
                        setChoices(next);
                      }}
                      aria-label="选项代码"
                    />
                    <Input
                      value={choice.label}
                      disabled={!editable}
                      onChange={(event) => {
                        const next = [...choices];
                        next[index] = { ...choice, label: event.target.value };
                        setChoices(next);
                      }}
                      aria-label="选项文本"
                    />
                    <Input
                      className="w-16 shrink-0"
                      type="number"
                      value={choice.score ?? ''}
                      disabled={!editable}
                      onChange={(event) => {
                        const next = [...choices];
                        next[index] = {
                          ...choice,
                          score: event.target.value === '' ? undefined : Number(event.target.value),
                        };
                        setChoices(next);
                      }}
                      aria-label="计分"
                    />
                    <Button
                      variant="ghost"
                      disabled={!editable}
                      onClick={() => setChoices(choices.filter((_, i) => i !== index))}
                      aria-label="删除选项"
                    >
                      ✕
                    </Button>
                  </div>

                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 pl-1">
                    {isKnowledge && (
                      <Checkbox
                        checked={choice.isCorrect === true}
                        disabled={!editable}
                        label="正确答案"
                        onChange={(next) => {
                          const updated = [...choices];
                          // A knowledge item has exactly one correct answer.
                          updated.forEach((item, i) => {
                            updated[i] = { ...item, isCorrect: next && i === index };
                          });
                          setChoices(updated);
                        }}
                      />
                    )}
                    <Checkbox
                      checked={choice.exclusive === true}
                      disabled={!editable}
                      label="互斥选项"
                      onChange={(next) => {
                        const updated = [...choices];
                        updated[index] = { ...choice, exclusive: next || undefined };
                        setChoices(updated);
                      }}
                    />
                    <Checkbox
                      checked={choice.sensitiveNonResponse === true}
                      disabled={!editable}
                      label="敏感拒答（计为缺失）"
                      onChange={(next) => {
                        const updated = [...choices];
                        updated[index] = { ...choice, sensitiveNonResponse: next || undefined };
                        setChoices(updated);
                      }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Matrix ------------------------------------------------------ */}
        {isMatrix && (
          <div className="space-y-3 rounded-md border border-ink-200 p-3">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wide text-ink-500">行项目</h3>
                <Button
                  variant="ghost"
                  disabled={!editable}
                  onClick={() => {
                    const rows = draft.options.matrix?.rows ?? [];
                    update({
                      options: {
                        ...draft.options,
                        matrix: {
                          rows: [...rows, { value: String(rows.length + 1), label: `行 ${rows.length + 1}` }],
                          columns: draft.options.matrix?.columns ?? [],
                        },
                      },
                    });
                  }}
                >
                  + 添加行
                </Button>
              </div>
              <ul className="space-y-1.5">
                {(draft.options.matrix?.rows ?? []).map((row, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <Input
                      className="w-16 shrink-0"
                      value={row.value}
                      disabled={!editable}
                      onChange={(event) => {
                        const rows = [...(draft.options.matrix?.rows ?? [])];
                        rows[index] = { ...row, value: event.target.value };
                        update({
                          options: {
                            ...draft.options,
                            matrix: { rows, columns: draft.options.matrix?.columns ?? [] },
                          },
                        });
                      }}
                      aria-label="行代码"
                    />
                    <Input
                      value={row.label}
                      disabled={!editable}
                      onChange={(event) => {
                        const rows = [...(draft.options.matrix?.rows ?? [])];
                        rows[index] = { ...row, label: event.target.value };
                        update({
                          options: {
                            ...draft.options,
                            matrix: { rows, columns: draft.options.matrix?.columns ?? [] },
                          },
                        });
                      }}
                      aria-label="行文本"
                    />
                    <Button
                      variant="ghost"
                      disabled={!editable}
                      onClick={() => {
                        const rows = (draft.options.matrix?.rows ?? []).filter((_, i) => i !== index);
                        update({
                          options: {
                            ...draft.options,
                            matrix: { rows, columns: draft.options.matrix?.columns ?? [] },
                          },
                        });
                      }}
                    >
                      ✕
                    </Button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="text-xs font-semibold uppercase tracking-wide text-ink-500">评价刻度</h3>
                <Button
                  variant="ghost"
                  disabled={!editable}
                  onClick={() => {
                    const columns = draft.options.matrix?.columns ?? [];
                    update({
                      options: {
                        ...draft.options,
                        matrix: {
                          rows: draft.options.matrix?.rows ?? [],
                          columns: [
                            ...columns,
                            { value: String(columns.length + 1), label: `刻度 ${columns.length + 1}` },
                          ],
                        },
                      },
                    });
                  }}
                >
                  + 添加刻度
                </Button>
              </div>
              <ul className="space-y-1.5">
                {(draft.options.matrix?.columns ?? []).map((column, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <Input
                      className="w-16 shrink-0"
                      value={column.value}
                      disabled={!editable}
                      onChange={(event) => {
                        const columns = [...(draft.options.matrix?.columns ?? [])];
                        columns[index] = { ...column, value: event.target.value };
                        update({
                          options: {
                            ...draft.options,
                            matrix: { rows: draft.options.matrix?.rows ?? [], columns },
                          },
                        });
                      }}
                      aria-label="刻度代码"
                    />
                    <Input
                      value={column.label}
                      disabled={!editable}
                      onChange={(event) => {
                        const columns = [...(draft.options.matrix?.columns ?? [])];
                        columns[index] = { ...column, label: event.target.value };
                        update({
                          options: {
                            ...draft.options,
                            matrix: { rows: draft.options.matrix?.rows ?? [], columns },
                          },
                        });
                      }}
                      aria-label="刻度文本"
                    />
                    <Button
                      variant="ghost"
                      disabled={!editable}
                      onClick={() => {
                        const columns = (draft.options.matrix?.columns ?? []).filter((_, i) => i !== index);
                        update({
                          options: {
                            ...draft.options,
                            matrix: { rows: draft.options.matrix?.rows ?? [], columns },
                          },
                        });
                      }}
                    >
                      ✕
                    </Button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* Scoring ----------------------------------------------------- */}
        <div className="rounded-md border border-ink-200 p-3">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-500">计分方式</h3>
          <Select
            value={draft.scoring_rule?.type ?? 'none'}
            disabled={!editable}
            onChange={(event) => update({ scoring_rule: buildScoringRule(event.target.value, draft) })}
          >
            <option value="none">不计分（分类描述）</option>
            <option value="categorical">名义分类编码</option>
            <option value="ordinal">有序分类编码</option>
            <option value="mean">维度均值（mean）</option>
            <option value="sum">维度总分（sum）</option>
            <option value="reverse">反向计分</option>
            <option value="count">多选题计数</option>
            <option value="knowledge">知识测试计分</option>
          </Select>
          <p className="mt-2 text-xs text-ink-500">{scoringSummary}</p>

          {draft.scoring_rule?.type === 'knowledge' && (
            <div className="mt-3 grid grid-cols-3 gap-2">
              <Field label="答对">
                <Input
                  type="number"
                  value={draft.scoring_rule.correctScore}
                  disabled={!editable}
                  onChange={(event) =>
                    update({
                      scoring_rule: {
                        type: 'knowledge',
                        correctScore: Number(event.target.value),
                        incorrectScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.incorrectScore : 0,
                        unknownScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.unknownScore : 0,
                        unknownValue:
                          draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.unknownValue : undefined,
                        maxScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.maxScore : 1,
                      },
                    })
                  }
                />
              </Field>
              <Field label="答错">
                <Input
                  type="number"
                  value={draft.scoring_rule.incorrectScore}
                  disabled={!editable}
                  onChange={(event) =>
                    update({
                      scoring_rule: {
                        type: 'knowledge',
                        correctScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.correctScore : 1,
                        incorrectScore: Number(event.target.value),
                        unknownScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.unknownScore : 0,
                        unknownValue:
                          draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.unknownValue : undefined,
                        maxScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.maxScore : 1,
                      },
                    })
                  }
                />
              </Field>
              <Field label="不清楚">
                <Input
                  type="number"
                  value={draft.scoring_rule.unknownScore}
                  disabled={!editable}
                  onChange={(event) =>
                    update({
                      scoring_rule: {
                        type: 'knowledge',
                        correctScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.correctScore : 1,
                        incorrectScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.incorrectScore : 0,
                        unknownScore: Number(event.target.value),
                        unknownValue:
                          draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.unknownValue : undefined,
                        maxScore: draft.scoring_rule?.type === 'knowledge' ? draft.scoring_rule.maxScore : 1,
                      },
                    })
                  }
                />
              </Field>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-2 border-t border-ink-200 px-4 py-3">
        <div className="flex gap-2">
          <Button
            variant="primary"
            className="flex-1"
            disabled={!editable || !dirty}
            loading={saving}
            onClick={() => void onSave(draft)}
          >
            {dirty ? '保存修改' : '无未保存修改'}
          </Button>
          <Button disabled={!dirty} onClick={onCancel}>
            撤销
          </Button>
        </div>
        <div className="flex gap-2">
          <Button className="flex-1" disabled={!editable} onClick={onDuplicate}>
            复制题目
          </Button>
          <Button variant="danger" className="flex-1" disabled={!editable} onClick={onDelete}>
            删除题目
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

function questionTypeLabelSafe(type: QuestionType): string {
  return QUESTION_TYPE_LABELS[type] ?? String(type);
}

function describeScoring(rule: ScoringRule | null): string {
  if (!rule || rule.type === 'none') return '该题不参与数值计分，仅作描述性统计。';
  switch (rule.type) {
    case 'mean':
      return `维度均值：对有效作答项取平均${rule.min !== undefined && rule.max !== undefined ? `（理论取值 ${rule.min}—${rule.max}）` : ''}。`;
    case 'sum':
      return '维度总分：对有效作答项求和。';
    case 'reverse':
      return `反向计分：按 ${rule.min}＋${rule.max}－原始分 反转。`;
    case 'knowledge':
      return `知识计分：答对＝${rule.correctScore}，答错＝${rule.incorrectScore}，"不清楚"＝${rule.unknownScore}；理论总分 0—${rule.maxScore}。`;
    case 'categorical':
      return '名义分类编码：映射为空的选项在统计中按缺失处理。';
    case 'ordinal':
      return '有序分类编码：映射为空的选项在统计中按缺失处理。';
    case 'count':
      return '计数编码：统计所选选项数量（排除互斥选项）。';
    default:
      return '描述性统计。';
  }
}

/** Build a default rule for the chosen type, preserving what makes sense. */
function buildScoringRule(type: string, draft: QuestionDraft): ScoringRule {
  const choices = draft.options.choices ?? [];
  const codes: Record<string, number | null> = {};
  choices.forEach((choice, index) => {
    codes[String(choice.value)] = choice.score ?? index + 1;
  });

  switch (type) {
    case 'mean':
      return { type: 'mean', min: 1, max: Math.max(choices.length, 5) };
    case 'sum':
      return { type: 'sum' };
    case 'reverse':
      return { type: 'reverse', min: 1, max: Math.max(choices.length, 5) };
    case 'count':
      return { type: 'count', excludeExclusive: true };
    case 'categorical':
      return { type: 'categorical', codes };
    case 'ordinal':
      return { type: 'ordinal', codes };
    case 'knowledge':
      return {
        type: 'knowledge',
        correctScore: 1,
        incorrectScore: 0,
        unknownScore: 0,
        unknownValue: choices.length > 0 ? String(choices[choices.length - 1]!.value) : undefined,
        maxScore: 1,
      };
    default:
      return { type: 'none' };
  }
}
