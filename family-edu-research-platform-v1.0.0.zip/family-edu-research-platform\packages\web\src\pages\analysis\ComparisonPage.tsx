/**
 * Group comparison (PHASE 6).
 *
 * The page leads with the engine's recommendation and its reason, because the
 * estimator choice — parametric ANOVA or its non-parametric counterpart — is the
 * decision a reader is least able to make from the numbers alone. Both results
 * are always shown: hiding the estimator the engine did not recommend would make
 * the conclusion impossible to check.
 *
 * The box plot is drawn from the ANOVA group descriptives, which carry n, mean,
 * SD, min and max but not quartiles; the chart says so rather than passing a
 * standard deviation off as an interquartile range.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { BoxPlot } from '../../components/charts';
import { Alert, Badge, Card, CardHeader, LoadingBlock } from '../../components/ui';
import {
  api,
  ApiClientError,
  type AnalysisComparison,
  type AnalysisComparisonResponse,
} from '../../lib/api';
import { formatNumber, formatPValue, formatStat, significanceMark } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  UnavailableNotice,
  unavailableReason,
  useAnalysisProject,
} from './shared';

function RecommendationBanner({ comparison }: { comparison: AnalysisComparison }): ReactNode {
  const parametric = comparison.recommended === 'parametric';
  return (
    <div
      className={`rounded-md border px-3.5 py-3 ${
        parametric ? 'border-emerald-200 bg-emerald-50' : 'border-amber-200 bg-amber-50'
      }`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={parametric ? 'success' : 'warning'}>
          {parametric ? '建议以参数检验（ANOVA）为主要结论' : '建议以非参数检验（Kruskal–Wallis）为主要结论'}
        </Badge>
        <span className="text-xs text-ink-500">
          {`分组变量 ${comparison.factor_label}（${comparison.factor}）· 共 ${comparison.groups} 组`}
        </span>
      </div>
      <p className={`mt-2 text-sm leading-relaxed ${parametric ? 'text-emerald-900' : 'text-amber-900'}`}>
        {comparison.recommendation_reason}
      </p>
    </div>
  );
}

function ComparisonCard({ comparison }: { comparison: AnalysisComparison }): ReactNode {
  const anova = comparison.anova;
  const kruskal = comparison.kruskal_wallis;

  return (
    <Card>
      <CardHeader
        title={`${comparison.dependent_label}（${comparison.dependent}）`}
        description={`因变量 ${comparison.dependent_label} 在分组变量 ${comparison.factor_label} 上的组间差异检验。`}
      />

      <RecommendationBanner comparison={comparison} />

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">分布形态筛查</h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[420px] text-sm">
              <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-3 py-2 text-left">组别</th>
                  <th className="px-3 py-2 text-right">n</th>
                  <th className="px-3 py-2 text-right">偏度</th>
                  <th className="px-3 py-2 text-left">可接受</th>
                  <th className="px-3 py-2 text-left">说明</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {comparison.screening.map((row) => (
                  <tr key={row.group}>
                    <td className="px-3 py-2 text-ink-900">{row.group}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-ink-700">{row.n}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                      {formatStat(row.skewness, 3)}
                    </td>
                    <td className="px-3 py-2 text-xs">
                      {row.acceptable ? (
                        <span className="text-emerald-700">是</span>
                      ) : (
                        <span className="text-amber-700">否</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-xs text-ink-600">{row.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-xs leading-relaxed text-ink-500">
            常用判据：偏度绝对值不超过 1，或该组样本量达到 30 以上（中心极限定理），即认为参数检验的正态性假设可接受。
          </p>
        </div>

        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">各组分布</h3>
          {anova && anova.groups.length > 0 ? (
            <BoxPlot
              groups={anova.groups.map((group) => ({
                label: group.group,
                n: group.n,
                mean: group.mean,
                sd: group.sd,
                minimum: group.minimum,
                maximum: group.maximum,
              }))}
              valueLabel={comparison.dependent_label}
            />
          ) : (
            <p className="py-6 text-center text-sm text-ink-400">该因变量没有可绘制的分组描述统计。</p>
          )}
        </div>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">单因素方差分析（ANOVA）</h3>
          {anova ? (
            <>
              <div className="overflow-x-auto">
                <table className="w-full min-w-[420px] text-sm">
                  <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-3 py-2 text-left">组别</th>
                      <th className="px-3 py-2 text-right">n</th>
                      <th className="px-3 py-2 text-right">均值</th>
                      <th className="px-3 py-2 text-right">标准差</th>
                      <th className="px-3 py-2 text-right">最小值</th>
                      <th className="px-3 py-2 text-right">最大值</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {anova.groups.map((group) => (
                      <tr key={group.group}>
                        <td className="px-3 py-2 text-ink-900">{group.group}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-ink-700">{group.n}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-ink-900">
                          {formatStat(group.mean, 3)}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                          {formatStat(group.sd, 3)}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums text-ink-600">
                          {formatStat(group.minimum, 3)}
                        </td>
                        <td className="px-3 py-2 text-right tabular-nums text-ink-600">
                          {formatStat(group.maximum, 3)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">F 检验</dt>
                  <dd className="mt-1 tabular-nums text-ink-900">
                    {`F(${anova.df_between}, ${anova.df_within}) = ${formatStat(anova.f, 3)}`}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">显著性</dt>
                  <dd className="mt-1 tabular-nums text-ink-900">
                    {formatPValue(anova.p_value)} {significanceMark(anova.p_value)}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">η²</dt>
                  <dd className="mt-1 tabular-nums text-ink-900">{formatStat(anova.eta_squared, 4)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">partial η²</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">{formatStat(anova.partial_eta_squared, 4)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">ω²</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">{formatStat(anova.omega_squared, 4)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">方差齐性</dt>
                  <dd className="mt-1 text-ink-800">
                    {anova.homogeneity
                      ? `${formatStat(anova.homogeneity.statistic, 3)}，${formatPValue(anova.homogeneity.p_value)}（${
                          anova.homogeneity.equal_variances ? '方差齐性成立' : '方差齐性不成立'
                        }）`
                      : '未计算'}
                  </dd>
                </div>
              </dl>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{anova.interpretation}</p>
              {anova.effect_size && (
                <p className="mt-1 text-xs text-ink-500">{anova.effect_size.convention}</p>
              )}
              {anova.warnings.length > 0 && (
                <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-amber-800">
                  {anova.warnings.map((warning) => (
                    <li key={warning}>{warning}</li>
                  ))}
                </ul>
              )}

              <h4 className="mt-4 text-sm font-medium text-ink-800">事后多重比较（Welch t + Holm 校正）</h4>
              {anova.post_hoc.length === 0 ? (
                <p className="mt-1 text-sm text-ink-500">组数少于 3 或有效样本不足，未进行事后比较。</p>
              ) : (
                <div className="mt-2 overflow-x-auto">
                  <table className="w-full min-w-[520px] text-sm">
                    <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                      <tr>
                        <th className="px-3 py-2 text-left">组对</th>
                        <th className="px-3 py-2 text-right">均值差</th>
                        <th className="px-3 py-2 text-right">t</th>
                        <th className="px-3 py-2 text-left">p（原始）</th>
                        <th className="px-3 py-2 text-left">p（Holm）</th>
                        <th className="px-3 py-2 text-left">显著</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-ink-100">
                      {anova.post_hoc.map((row) => (
                        <tr key={`${row.group_a}-${row.group_b}`}>
                          <td className="px-3 py-2 text-ink-800">{`${row.group_a} — ${row.group_b}`}</td>
                          <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                            {formatStat(row.mean_difference, 3)}
                          </td>
                          <td className="px-3 py-2 text-right tabular-nums text-ink-700">{formatStat(row.t, 3)}</td>
                          <td className="px-3 py-2 text-xs text-ink-700">{formatPValue(row.p_raw)}</td>
                          <td className="px-3 py-2 text-xs text-ink-700">{formatPValue(row.p_adjusted)}</td>
                          <td className="px-3 py-2 text-xs">
                            {row.significant ? (
                              <span className="text-emerald-700">是</span>
                            ) : (
                              <span className="text-ink-500">否</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <p className="mt-2 text-xs text-ink-500">
                    多重比较会抬高假阳性率，因此同时给出 Holm 校正后的 p 值；是否显著以校正后的 p 值为准。
                  </p>
                </div>
              )}
            </>
          ) : (
            <p className="text-sm text-ink-500">该因变量无法进行方差分析。</p>
          )}
        </div>

        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">Kruskal–Wallis 检验（非参数对照）</h3>
          {kruskal ? (
            <>
              <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">H 统计量</dt>
                  <dd className="mt-1 tabular-nums text-ink-900">{formatStat(kruskal.h, 3)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">自由度</dt>
                  <dd className="mt-1 tabular-nums text-ink-900">{kruskal.degrees_of_freedom}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">显著性</dt>
                  <dd className="mt-1 tabular-nums text-ink-900">
                    {formatPValue(kruskal.p_value)} {significanceMark(kruskal.p_value)}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">ε² 效应量</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">{formatStat(kruskal.epsilon_squared, 4)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">结点校正</dt>
                  <dd className="mt-1 text-ink-800">{kruskal.tie_corrected ? '已校正' : '未校正'}</dd>
                </div>
              </dl>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">{kruskal.interpretation}</p>
              {kruskal.groups.length > 0 && (
                <div className="mt-3 overflow-x-auto">
                  <table className="w-full min-w-[360px] text-sm">
                    <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                      <tr>
                        <th className="px-3 py-2 text-left">组别</th>
                        <th className="px-3 py-2 text-right">n</th>
                        <th className="px-3 py-2 text-right">中位数</th>
                        <th className="px-3 py-2 text-right">平均秩</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-ink-100">
                      {kruskal.groups.map((group) => (
                        <tr key={group.group}>
                          <td className="px-3 py-2 text-ink-800">{group.group}</td>
                          <td className="px-3 py-2 text-right tabular-nums text-ink-700">{group.n}</td>
                          <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                            {formatStat(group.median, 3)}
                          </td>
                          <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                            {formatStat(group.mean_rank, 2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {kruskal.warnings.length > 0 && (
                <ul className="mt-2 list-disc space-y-1 pl-4 text-xs text-amber-800">
                  {kruskal.warnings.map((warning) => (
                    <li key={warning}>{warning}</li>
                  ))}
                </ul>
              )}
            </>
          ) : (
            <p className="text-sm text-ink-500">该因变量无法进行 Kruskal–Wallis 检验。</p>
          )}

          {comparison.mann_whitney && (
            <div className="mt-5">
              <h4 className="text-sm font-medium text-ink-800">两组时的 Mann–Whitney U 检验</h4>
              <dl className="mt-2 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">组别</dt>
                  <dd className="mt-1 text-ink-800">
                    {`${comparison.mann_whitney.group_a}（n=${comparison.mann_whitney.n_a}） vs ${comparison.mann_whitney.group_b}（n=${comparison.mann_whitney.n_b}）`}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">U（较小值）</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">
                    {`${formatStat(comparison.mann_whitney.u_min, 1)}（z = ${formatStat(comparison.mann_whitney.z, 3)}）`}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">显著性</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">
                    {formatPValue(comparison.mann_whitney.p_value)}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">秩双列相关 r</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">
                    {formatStat(comparison.mann_whitney.rank_biserial_r, 3)}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">中位数</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">
                    {`${formatStat(comparison.mann_whitney.median_a, 3)} vs ${formatStat(comparison.mann_whitney.median_b, 3)}`}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">平均秩</dt>
                  <dd className="mt-1 tabular-nums text-ink-800">
                    {`${formatStat(comparison.mann_whitney.mean_rank_a, 2)} vs ${formatStat(comparison.mann_whitney.mean_rank_b, 2)}`}
                  </dd>
                </div>
              </dl>
              <p className="mt-2 text-sm leading-relaxed text-ink-700">
                {comparison.mann_whitney.interpretation}
              </p>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

export function ComparisonPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisComparisonResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setData(await api.analysis.comparisons(projectId));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载组间比较结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const reason = unavailableReason(data);
  const comparisons = data && data.comparisons.length > 0 ? data.comparisons : [];

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Group Comparison"
          subtitle="组间比较：ANOVA 与非参数检验并行报告，并给出引擎的估计方法建议。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在计算组间差异…" />
        ) : !data ? null : reason ? (
          <UnavailableNotice reason={reason} title="无法进行组间比较" />
        ) : comparisons.length === 0 ? (
          <UnavailableNotice
            reason={
              data.reason ??
              '分组变量不存在，或所选因变量在该分组下的有效样本不足（每组至少需要 6 例且存在变异）。'
            }
            title="无法进行组间比较"
          />
        ) : (
          <>
            <MethodNote>
              <p>
                引擎版本 {data.engine_version}；分组变量 {data.factor}，
                共对 {comparisons.length} 个因变量进行组间比较。
              </p>
              <p>
                每个因变量同时给出参数检验（单因素 ANOVA，含 Welch t + Holm 校正的事后比较）与非参数检验
                （Kruskal–Wallis，两组时为 Mann–Whitney U），并依据各组样本量与分布形态筛查结果给出建议采用哪一种。
                两种结果都完整列出，便于读者自行复核建议。
              </p>
              <p>
                组间差异显著只说明组均值（或秩）在统计上不相等，不说明差异来自分组变量本身：
                横截面数据中的组间差异同样可能由年龄、学历等未纳入分析的变量造成。
              </p>
            </MethodNote>

            {comparisons.map((comparison) => (
              <ComparisonCard key={comparison.dependent} comparison={comparison} />
            ))}

            <Alert tone="info" title="关于效应量">
              显著性回答「有没有差异」，效应量回答「差异有多大」。本页同时报告 η²（ANOVA）与 ε²
              （Kruskal–Wallis）：η² 表示因变量总变异中被分组解释的比例，样本量很大时即使差异很小也可能显著，
              因此判断实际意义应参照效应量而非仅看 p 值。
            </Alert>
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
