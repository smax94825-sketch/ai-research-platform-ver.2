/**
 * Local storage of the respondent's session token.
 *
 * The platform exposes two respondent layouts for the SAME collection session:
 * the step-by-step flow at `/research/:shareToken` and the single-page
 * questionnaire at `/research/:shareToken/all`. A respondent may open either
 * link for the same wave — and may switch between them — so the token must live
 * under one key. If each page owned its own key the switch would silently open a
 * second session, and the same person would be counted twice in `respondents`.
 *
 * The key is therefore defined once, here, and imported by both pages.
 */

const SESSION_KEY_PREFIX = 'ferp.survey.session.';

/** localStorage key holding the session token for one questionnaire share token. */
export function sessionStorageKey(shareToken: string): string {
  return `${SESSION_KEY_PREFIX}${shareToken}`;
}
