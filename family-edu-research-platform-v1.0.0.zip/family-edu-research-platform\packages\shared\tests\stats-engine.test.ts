/**
 * Statistical engine tests (PHASE 5).
 *
 * Every expected value here is either hand-computable from the raw numbers or
 * derived from an independent mathematical identity. This matters more than
 * coverage: a plausible-looking but wrong coefficient would be reported in a
 * paper and never noticed.
 *
 * Hand-computed anchors used below:
 *   - t test: [1..5] vs [6..10] → t = −5, df = 8, p ≈ 0.001052, d = −3.1623
 *   - ANOVA: [1,2,3] / [4,5,6] / [7,8,9] → F(2,6) = 27, η² = 0.90
 *   - χ²: [[10,20],[20,10]] → χ² = 6.6667, df = 1, p ≈ 0.009823
 *   - OLS: y = 1 + 2x₁ + 3x₂ exactly → R² = 1, B = (1, 2, 3)
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  chiSquareTest,
  chooseCorrelationMethod,
  chooseRegressionModel,
  completeCases,
  correlationMatrixWithTests,
  correlatePair,
  cronbachAlpha,
  describeVariable,
  exploratoryFactorAnalysis,
  independentTTest,
  kruskalWallis,
  leveneTest,
  mannWhitneyU,
  olsRegression,
  oneWayAnova,
  ordinalLogistic,
  reliabilityOfScale,
  ranks,
  spearmanCorrelation,
  testAllHypotheses,
  testHypothesis,
  type Dataset,
  type DatasetVariable,
  type HypothesisDefinition,
  DEFAULT_HYPOTHESES,
} from '../src/index.js';

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

function makeDataset(
  columns: Record<string, number[]>,
  options: { dataTypes?: Record<string, DatasetVariable['data_type']>; labels?: Record<string, string> } = {},
): Dataset {
  const names = Object.keys(columns);
  const first = names[0];
  const n = first === undefined ? 0 : columns[first]!.length;
  const variables: DatasetVariable[] = names.map((name) => ({
    name,
    label: options.labels?.[name] ?? name,
    dimension: 'test',
    question_code: name,
    data_type: options.dataTypes?.[name] ?? 'interval',
    values: columns[name]!,
    raw: columns[name]!,
    value_labels: {},
    is_derived: false,
    sources: [name],
  }));
  return {
    respondent_ids: Array.from({ length: n }, (_, index) => `R${index + 1}`),
    variables,
    by_name: new Map(variables.map((variable) => [variable.name, variable])),
    scales: [],
    n_respondents: n,
    empty_variables: [],
  };
}

function closeTo(actual: number | null, expected: number, tolerance: number, label: string): void {
  assert.ok(actual !== null, `${label}: 期望 ${expected}，实际为 null`);
  assert.ok(
    Math.abs(actual! - expected) <= tolerance,
    `${label}: 期望 ${expected}（±${tolerance}），实际 ${actual}`,
  );
}

/* ================================================================== */
/* Dataset construction                                               */
/* ================================================================== */

describe('数据集构建与缺失处理', () => {
  test('缺失值保持为 null，不会被当作 0', () => {
    const dataset = makeDataset({ A: [1, 2, 3], B: [1, 0, 3] });
    const selection = completeCases(dataset, ['A', 'B']);
    assert.equal(selection.n, 3);
  });

  test('整例删除并如实报告剔除数量', () => {
    const dataset = makeDataset({
      A: [1, 2, null as unknown as number, 4, 5],
      B: [1, 2, 3, null as unknown as number, 5],
    });
    const selection = completeCases(dataset, ['A', 'B']);
    assert.equal(selection.n, 3, '应保留 3 例完整样本');
    assert.equal(selection.dropped, 2);
    assert.equal(selection.missing_per_variable['A'], 1);
    assert.equal(selection.missing_per_variable['B'], 1);
    assert.match(selection.note, /listwise/);
    assert.match(selection.note, /剔除 2 例/);
    assert.match(selection.note, /不进行插补/);
  });

  test('所有缺失时 n = 0 并给出说明', () => {
    const dataset = makeDataset({ A: [null, null, null] as unknown as number[] });
    const selection = completeCases(dataset, ['A']);
    assert.equal(selection.n, 0);
    assert.match(selection.note, /n = 0/);
  });
});

/* ================================================================== */
/* Descriptive                                                        */
/* ================================================================== */

describe('描述统计', () => {
  test('均值、标准差、中位数与四分位数（可手工核对）', () => {
    // 1..10：均值 5.5，样本方差 9.1667，中位数 5.5，Q1 3.25，Q3 7.75
    const dataset = makeDataset({ V: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] });
    const stats = describeVariable(dataset.by_name.get('V')!, 10);

    closeTo(stats.mean, 5.5, 1e-4, '均值');
    // 引擎按 4 位小数报告，因此容差取 1e-4
    closeTo(stats.standard_deviation, Math.sqrt(9.166666), 1e-4, '标准差');
    closeTo(stats.median, 5.5, 1e-4, '中位数');
    closeTo(stats.q1, 3.25, 1e-4, 'Q1');
    closeTo(stats.q3, 7.75, 1e-4, 'Q3');
    closeTo(stats.iqr, 4.5, 1e-4, 'IQR');
    assert.equal(stats.minimum, 1);
    assert.equal(stats.maximum, 10);
    assert.equal(stats.range, 9);
    assert.equal(stats.n, 10);
    assert.equal(stats.missing, 0);
  });

  test('缺失不参与统计，且缺失数被单独报告', () => {
    const dataset = makeDataset({ V: [1, 2, 3, null, null] as unknown as number[] });
    const stats = describeVariable(dataset.by_name.get('V')!, 5);
    closeTo(stats.mean, 2, 1e-9, '均值仅基于 3 例');
    assert.equal(stats.n, 3);
    assert.equal(stats.missing, 2);
    closeTo(stats.missing_percent, 40, 1e-9, '缺失率');
  });

  test('完全无作答的变量返回 null 而不是 0', () => {
    const dataset = makeDataset({ V: [null, null] as unknown as number[] });
    const stats = describeVariable(dataset.by_name.get('V')!, 2);
    assert.equal(stats.n, 0);
    assert.equal(stats.mean, null);
    assert.equal(stats.standard_deviation, null);
    assert.equal(stats.median, null);
    assert.equal(stats.skewness, null);
  });

  test('偏度与峰度：对称数据接近 0', () => {
    const dataset = makeDataset({ V: [1, 2, 3, 4, 5, 6, 7, 8, 9] });
    const stats = describeVariable(dataset.by_name.get('V')!, 9);
    closeTo(stats.skewness, 0, 1e-6, '对称分布偏度');
    closeTo(stats.kurtosis, -1.2, 0.05, '均匀分布峰度');
  });

  test('右偏数据偏度为正', () => {
    const dataset = makeDataset({ V: [1, 1, 1, 1, 1, 2, 3, 10, 30] });
    const stats = describeVariable(dataset.by_name.get('V')!, 9);
    assert.ok(stats.skewness !== null && stats.skewness > 0, `应右偏，实际 ${stats.skewness}`);
  });

  test('名义变量不给均值、百分位、极值与偏度', () => {
    // 选项编码 1=x、2=y、3=z。若把它们当数量求均值会得到 2.0，看起来像
    // 「平均选择第二个选项」，但这个数字完全取决于编码方式：改成 10/20/30
    // 均值就变成 20。因此名义变量只报告频数分布与样本量。
    const dataset = makeDataset(
      { SEX: [1, 1, 2, 3, 3, 3] },
      { dataTypes: { SEX: 'nominal' } },
    );
    const stats = describeVariable(dataset.by_name.get('SEX')!, 6);

    assert.equal(stats.n, 6);
    assert.equal(stats.missing, 0);
    assert.equal(stats.mean, null, '名义变量不应给出均值');
    assert.equal(stats.median, null);
    assert.equal(stats.standard_deviation, null);
    assert.equal(stats.standard_error, null);
    assert.equal(stats.variance, null);
    assert.equal(stats.minimum, null);
    assert.equal(stats.maximum, null);
    assert.equal(stats.range, null);
    assert.equal(stats.q1, null);
    assert.equal(stats.q3, null);
    assert.equal(stats.iqr, null);
    assert.equal(stats.skewness, null);
    assert.equal(stats.kurtosis, null);
  });

  test('有序变量的均值与百分位照常给出', () => {
    // 有序编码自带次序信息，均值虽不精确但可解释，必须保留。
    const dataset = makeDataset(
      { EDU: [1, 2, 2, 3, 4] },
      { dataTypes: { EDU: 'ordinal' } },
    );
    const stats = describeVariable(dataset.by_name.get('EDU')!, 5);
    closeTo(stats.mean, 2.4, 1e-9, '有序变量均值');
    assert.equal(stats.minimum, 1);
    assert.equal(stats.maximum, 4);
    assert.equal(stats.median, 2);
  });
});

/* ================================================================== */
/* Correlation                                                        */
/* ================================================================== */

describe('相关分析', () => {
  test('Pearson：完全线性关系 r = 1，p = 0', () => {
    const dataset = makeDataset({ X: [1, 2, 3, 4, 5], Y: [2, 4, 6, 8, 10] });
    const pair = correlatePair(dataset, 'X', 'Y');
    closeTo(pair.r, 1, 1e-9, 'r');
    assert.equal(pair.method, 'pearson');
    assert.ok((pair.p_value ?? 1) < 0.001);
    assert.equal(pair.n, 5);
  });

  test('Spearman 用于有序变量，且能识别非线性单调关系', () => {
    // y = x³ 为单调但非线性：Spearman = 1，Pearson < 1
    const x = [1, 2, 3, 4, 5, 6];
    const y = x.map((value) => value ** 3);
    const rho = spearmanCorrelation(x, y);
    closeTo(rho, 1, 1e-9, 'Spearman');

    const dataset = makeDataset({ X: x, Y: y }, { dataTypes: { X: 'ordinal', Y: 'ordinal' } });
    const pair = correlatePair(dataset, 'X', 'Y');
    assert.equal(pair.method, 'spearman', '有序变量应自动选用 Spearman');
    assert.match(pair.method_reason, /顺序|有序/);
  });

  test('方法选择依据测量层次而非默认 Pearson', () => {
    const dataset = makeDataset(
      { ORD: [1, 2, 3, 4, 5], CONT: [1.5, 2.5, 3.5, 4.5, 5.5] },
      { dataTypes: { ORD: 'ordinal', CONT: 'interval' } },
    );
    const choice = chooseCorrelationMethod(dataset.by_name.get('ORD')!, dataset.by_name.get('CONT')!);
    assert.equal(choice.method, 'spearman');
    assert.match(choice.reason, /有序分类/);
  });

  test('秩计算对结点取平均秩', () => {
    // [1, 2, 2, 2, 5] → 秩 [1, 3, 3, 3, 5]
    assert.deepEqual(ranks([1, 2, 2, 2, 5]), [1, 3, 3, 3, 5]);
    assert.deepEqual(ranks([5, 1, 3]), [3, 1, 2]);
  });

  test('相关矩阵包含 r、p、n 且对称', () => {
    const dataset = makeDataset({
      A: [1, 2, 3, 4, 5, 6, 7, 8],
      B: [2, 4, 6, 8, 10, 12, 14, 16],
      C: [8, 7, 6, 5, 4, 3, 2, 1],
    });
    const result = correlationMatrixWithTests(dataset, ['A', 'B', 'C']);

    closeTo(result.matrix[0]![1]!, 1, 1e-9, 'A-B');
    closeTo(result.matrix[0]![2]!, -1, 1e-9, 'A-C');
    closeTo(result.matrix[1]![2]!, -1, 1e-9, 'B-C');
    assert.equal(result.n[0]![1], 8);
    assert.ok((result.p_values[0]![1] ?? 1) < 0.001);
    for (let i = 0; i < 3; i += 1) {
      closeTo(result.matrix[i]![i]!, 1, 1e-12, `对角 ${i}`);
    }
    assert.match(result.note, /成对删除/);
    assert.match(result.note, /相关不等于因果/);
  });

  test('相关系数置信区间包含点估计且方向正确', () => {
    const dataset = makeDataset({
      A: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
      B: [2, 3, 5, 4, 7, 8, 9, 11, 10, 13],
    });
    const pair = correlatePair(dataset, 'A', 'B');
    assert.ok(pair.r !== null && pair.ci_lower !== null && pair.ci_upper !== null);
    assert.ok(pair.ci_lower! < pair.r! && pair.r! < pair.ci_upper!, '置信区间应包含 r');
    assert.ok(pair.shared_variance_percent !== null && pair.shared_variance_percent > 0);
  });

  test('样本不足时返回 null 并说明原因', () => {
    const dataset = makeDataset({ A: [1, 2], B: [2, 4] });
    const pair = correlatePair(dataset, 'A', 'B');
    assert.equal(pair.r, null);
    assert.match(pair.note, /至少需要 4 例/);
  });
});

/* ================================================================== */
/* Reliability                                                        */
/* ================================================================== */

describe('信度分析', () => {
  test('完全相关但方差不等的量表：原始 α < 1，标准化 α = 1', () => {
    // I2 = 2·I1，I3 = 3·I1，三者相关均为 1，但方差不同。
    // 原始 α 基于协方差，会受题目方差差异拖低：
    //   var(I1)=6, var(I2)=24, var(I3)=54, var(总分)=216
    //   α = 3/2 × (1 − 84/216) = 0.9167
    // 标准化 α 基于相关系数，因此等于 1。
    // 这个区别很重要：把"完全相关"直接等同于"α = 1"是常见的误判。
    const columns = [
      [1, 2, 3, 4, 5, 6, 7, 8],
      [2, 4, 6, 8, 10, 12, 14, 16],
      [3, 6, 9, 12, 15, 18, 21, 24],
    ];
    closeTo(cronbachAlpha(columns), 0.9167, 1e-3, '原始 α');

    const dataset = makeDataset(
      { I1: columns[0]!, I2: columns[1]!, I3: columns[2]! },
      { dataTypes: { I1: 'ordinal', I2: 'ordinal', I3: 'ordinal' } },
    );
    const result = reliabilityOfScale(dataset, ['I1', 'I2', 'I3'], {
      scale: 'T',
      label: 'T',
      dimension: 'T',
    });
    closeTo(result.standardized_alpha, 1, 1e-6, '标准化 α');
    closeTo(result.mean_inter_item_correlation, 1, 1e-6, '平均题间相关');
  });

  test('相互独立的项目 α 接近 0', () => {
    // 交替模式使项目间相关接近 0
    const a = [1, 2, 1, 2, 1, 2, 1, 2];
    const b = [1, 1, 2, 2, 1, 1, 2, 2];
    const c = [1, 2, 2, 1, 1, 2, 2, 1];
    const alpha = cronbachAlpha([a, b, c]);
    assert.ok(alpha !== null && alpha < 0.5, `应很低，实际 ${alpha}`);
  });

  test('等方差项目的原始 α 与标准化 α 一致（自校验恒等式）', () => {
    // 当各项目方差相等时，α = k·r̄ / (1 + (k-1)·r̄) 应与原始 α 相同
    const dataset = makeDataset(
      {
        I1: [3, 4, 5, 2, 4, 5, 3, 4, 5, 3],
        I2: [2, 3, 5, 3, 4, 4, 2, 3, 5, 4],
        I3: [4, 4, 5, 3, 5, 5, 3, 4, 5, 3],
      },
      { dataTypes: { I1: 'ordinal', I2: 'ordinal', I3: 'ordinal' } },
    );
    // 先标准化使方差相等
    for (const name of ['I1', 'I2', 'I3']) {
      const variable = dataset.by_name.get(name)!;
      const values = variable.values as number[];
      const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
      const sd = Math.sqrt(
        values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (values.length - 1),
      );
      variable.values = values.map((value) => (value - mean) / sd);
    }

    const result = reliabilityOfScale(dataset, ['I1', 'I2', 'I3'], {
      scale: 'TEST',
      label: '测试量表',
      dimension: '测试',
    });

    assert.ok(result.cronbach_alpha !== null && result.standardized_alpha !== null);
    closeTo(result.cronbach_alpha, result.standardized_alpha!, 1e-6, '原始 α 与标准化 α');
    assert.equal(result.k, 3);
    assert.equal(result.n, 10);
  });

  test('逐条目诊断：题总相关与删除后 α', () => {
    const dataset = makeDataset({
      I1: [5, 4, 5, 4, 5, 4, 5, 4, 5, 4],
      I2: [4, 4, 5, 3, 4, 5, 4, 3, 5, 4],
      I3: [5, 5, 4, 4, 5, 4, 5, 5, 4, 4],
      // 与外向的三个条目几乎无关
      ODD: [1, 5, 1, 5, 1, 5, 1, 5, 1, 5],
    });
    const result = reliabilityOfScale(dataset, ['I1', 'I2', 'I3', 'ODD'], {
      scale: 'TEST',
      label: '测试量表',
      dimension: '测试',
    });

    assert.equal(result.items.length, 4);
    const odd = result.items.find((item) => item.item === 'ODD')!;
    assert.ok(
      odd.item_total_correlation !== null && odd.item_total_correlation < 0.3,
      `无关条目题总相关应偏低，实际 ${odd.item_total_correlation}`,
    );
    assert.ok(
      result.warnings.some((warning) => warning.includes('ODD')),
      '应针对低题总相关条目给出提示',
    );
    assert.match(result.interpretation, /不等于量表有效/);
  });

  test('条目不足 2 个时如实报告无法计算', () => {
    const dataset = makeDataset({ I1: [1, 2, 3, 4] }, { dataTypes: { I1: 'ordinal' } });
    const result = reliabilityOfScale(dataset, ['I1'], {
      scale: 'X',
      label: 'X',
      dimension: 'X',
    });
    assert.equal(result.cronbach_alpha, null);
    assert.match(result.interpretation, /少于 2 个/);
  });
});

/* ================================================================== */
/* EFA                                                                */
/* ================================================================== */

describe('因素分析', () => {
  /**
   * Two clean factors: A1–A3 load on factor 1, B1–B3 on factor 2.
   *
   * Noise comes from a seeded linear congruential generator rather than a
   * deterministic sinusoid: sinusoids of nearby frequencies are themselves
   * highly correlated, which would make the items within a factor nearly
   * collinear and the correlation matrix ill-conditioned — a pathological input
   * that says nothing about whether factor analysis works.
   */
  function twoFactorDataset(): Dataset {
    let seed = 20260101;
    const random = (): number => {
      seed = (seed * 1103515245 + 12345) % 2147483648;
      return seed / 2147483648 - 0.5;
    };

    const n = 200;
    const factor1: number[] = [];
    const factor2: number[] = [];
    for (let index = 0; index < n; index += 1) {
      factor1.push(random() * 4);
      factor2.push(random() * 4);
    }

    const item = (base: number[]): number[] => base.map((value) => value + random() * 2);

    return makeDataset({
      A1: item(factor1),
      A2: item(factor1),
      A3: item(factor1),
      B1: item(factor2),
      B2: item(factor2),
      B3: item(factor2),
    });
  }

  test('KMO 与 Bartlett 能识别适合因素分析的数据', () => {
    const dataset = twoFactorDataset();
    const efa = exploratoryFactorAnalysis(dataset, ['A1', 'A2', 'A3', 'B1', 'B2', 'B3']);

    assert.ok(efa.kmo.overall !== null && efa.kmo.overall > 0.5, `KMO 应较高，实际 ${efa.kmo.overall}`);
    assert.equal(efa.kmo.per_variable.length, 6, '应给出每个变量的 MSA');
    assert.equal(efa.bartlett.unavailable, false);
    assert.ok((efa.bartlett.p_value ?? 1) < 0.05, 'Bartlett 应显著');
    assert.ok((efa.bartlett.degrees_of_freedom ?? 0) === 15, 'df = p(p-1)/2 = 15');
  });

  test('特征值结构与声量解释比例自洽', () => {
    const dataset = twoFactorDataset();
    const efa = exploratoryFactorAnalysis(dataset, ['A1', 'A2', 'A3', 'B1', 'B2', 'B3']);

    assert.equal(efa.eigenvalues.length, 6);
    // 相关矩阵对角为 1，特征值之和 = 变量数
    closeTo(efa.eigenvalues.reduce((sum, value) => sum + value, 0), 6, 1e-3, '特征值之和');
    // 特征值降序
    for (let index = 1; index < efa.eigenvalues.length; index += 1) {
      assert.ok(efa.eigenvalues[index]! <= efa.eigenvalues[index - 1]! + 1e-9, '特征值应降序');
    }
    // 累计解释方差为 100%
    closeTo(efa.cumulative_variance[5]!, 100, 1e-2, '累计方差');
  });

  test('两个因子结构与设计一致', () => {
    const dataset = twoFactorDataset();
    const efa = exploratoryFactorAnalysis(dataset, ['A1', 'A2', 'A3', 'B1', 'B2', 'B3'], {
      factors: 2,
    });

    assert.equal(efa.factors_retained, 2);
    const a1 = efa.loadings.find((item) => item.variable === 'A1')!;
    const b1 = efa.loadings.find((item) => item.variable === 'B1')!;
    assert.notEqual(a1.primary_factor, b1.primary_factor, 'A 组与 B 组应落在不同因子上');
    // A1..A3 应落在同一因子
    const aFactors = ['A1', 'A2', 'A3'].map(
      (name) => efa.loadings.find((item) => item.variable === name)!.primary_factor,
    );
    assert.equal(new Set(aFactors).size, 1, `A 组应同属一个因子，实际 ${aFactors.join(',')}`);
    assert.ok(a1.communality > 0.5, `共同度应较高，实际 ${a1.communality}`);
  });

  test('给出声量图数据与解释说明', () => {
    const dataset = twoFactorDataset();
    const efa = exploratoryFactorAnalysis(dataset, ['A1', 'A2', 'A3', 'B1', 'B2', 'B3']);
    assert.equal(efa.scree.length, 6);
    assert.equal(efa.scree[0]!.component, 1);
    assert.match(efa.interpretation, /主成分法/);
    assert.match(efa.interpretation, /不能确认理论模型/);
    assert.match(efa.interpretation, /验证性因素分析/);
  });

  test('变量不足时拒绝并说明原因', () => {
    const dataset = makeDataset({ A: [1, 2, 3, 4], B: [2, 3, 4, 5] });
    const efa = exploratoryFactorAnalysis(dataset, ['A', 'B']);
    assert.equal(efa.loadings.length, 0);
    assert.match(efa.interpretation, /至少需要 3 个变量/);
  });
});

/* ================================================================== */
/* OLS regression                                                     */
/* ================================================================== */

describe('多元线性回归', () => {
  test('精确线性关系可完全还原系数（R² = 1）', () => {
    // y = 1 + 2·x1 + 3·x2
    const x1 = [1, 2, 3, 4, 5, 6, 7, 8];
    const x2 = [2, 1, 4, 3, 6, 5, 8, 7];
    const y = x1.map((value, index) => 1 + 2 * value + 3 * x2[index]!);

    const dataset = makeDataset({ X1: x1, X2: x2, Y: y });
    const model = olsRegression(dataset, 'Y', ['X1', 'X2']);

    assert.equal(model.n, 8);
    closeTo(model.coefficients[0]!.b, 1, 1e-6, '常数项');
    closeTo(model.coefficients[1]!.b, 2, 1e-6, 'X1 系数');
    closeTo(model.coefficients[2]!.b, 3, 1e-6, 'X2 系数');
    closeTo(model.r_squared, 1, 1e-6, 'R²');
    assert.ok(model.equation.includes('Y = 1'));
  });

  test('输出包含 β、SE、t、p、R²、调整 R²、VIF 与置信区间', () => {
    const dataset = makeDataset({
      X1: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      X2: [12, 10, 9, 11, 8, 7, 6, 5, 4, 3, 2, 1],
      Y: [5, 7, 9, 10, 13, 14, 16, 17, 19, 21, 22, 25],
    });
    const model = olsRegression(dataset, 'Y', ['X1', 'X2']);

    assert.equal(model.model, 'ols');
    assert.equal(model.coefficients.length, 3, '含常数项');
    for (const coefficient of model.coefficients) {
      assert.ok(Number.isFinite(coefficient.b), 'B 应为数值');
      assert.ok(Number.isFinite(coefficient.standard_error), 'SE 应为数值');
      assert.ok(Number.isFinite(coefficient.t), 't 应为数值');
      assert.ok(coefficient.p_value !== null, 'p 应存在');
      assert.ok(coefficient.ci_lower < coefficient.ci_upper, '置信区间应有序');
    }
    assert.ok(model.r_squared !== null && model.r_squared > 0.9, '拟合应良好');
    assert.ok(model.adjusted_r_squared !== null && model.adjusted_r_squared! < model.r_squared!);
    assert.ok(model.standard_error_estimate !== null);
    assert.ok(model.f_statistic !== null && model.f_statistic > 0);
    assert.equal(model.degrees_of_freedom_model, 2);
    assert.equal(model.degrees_of_freedom_residual, 9);
    // 常量项不应有 VIF
    assert.equal(model.coefficients[0]!.vif, null);
  });

  test('β 为标准分系数，且与 B 的符号一致', () => {
    const dataset = makeDataset({
      X: [1, 2, 3, 4, 5, 6, 7, 8],
      Y: [2, 5, 4, 8, 9, 12, 11, 15],
    });
    const model = olsRegression(dataset, 'Y', ['X']);
    const slope = model.coefficients[1]!;
    assert.ok(slope.beta !== null);
    assert.equal(Math.sign(slope.beta!), Math.sign(slope.b));
    // 简单回归中 β 等于 Pearson r
    const pair = correlatePair(dataset, 'X', 'Y');
    closeTo(slope.beta, pair.r!, 1e-3, 'β 应等于 r');
  });

  test('完全共线时拒绝估计并说明原因', () => {
    const dataset = makeDataset({
      X1: [1, 2, 3, 4, 5, 6],
      X2: [2, 4, 6, 8, 10, 12],
      Y: [1, 3, 5, 7, 9, 11],
    });
    const model = olsRegression(dataset, 'Y', ['X1', 'X2']);
    assert.ok(
      model.coefficients.length === 0 || model.warnings.some((warning) => /共线|不可逆/.test(warning)),
      '完全共线应被检出',
    );
  });

  test('多重共线性产生 VIF 警告', () => {
    // X2 与 X1 高度相关但不完全相同
    const x1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
    const x2 = x1.map((value) => value * 2 + (value % 2 === 0 ? 0.001 : -0.001));
    const y = x1.map((value, index) => value + x2[index]! * 0.5 + 3);

    const dataset = makeDataset({ X1: x1, X2: x2, Y: y });
    const model = olsRegression(dataset, 'Y', ['X1', 'X2']);

    const vifs = model.coefficients.filter((c) => c.vif !== null).map((c) => c.vif!);
    assert.ok(Math.max(...vifs) > 5, `应检出共线性，实际 VIF = ${vifs.join(',')}`);
    assert.ok(
      model.collinearity_warnings.length > 0,
      '应给出共线性警告',
    );
  });

  test('无变异自变量被排除并说明', () => {
    const dataset = makeDataset({
      CONST: [3, 3, 3, 3, 3, 3, 3, 3],
      X: [1, 2, 3, 4, 5, 6, 7, 8],
      Y: [2, 4, 6, 8, 10, 12, 14, 16],
    });
    const model = olsRegression(dataset, 'Y', ['CONST', 'X']);
    assert.deepEqual(model.dropped_predictors, ['CONST']);
    assert.ok(model.warnings.some((warning) => warning.includes('CONST')));
  });

  test('样本过小时拒绝估计', () => {
    const dataset = makeDataset({ X: [1, 2], Y: [2, 4] });
    const model = olsRegression(dataset, 'Y', ['X']);
    assert.equal(model.n, 0);
    assert.match(model.interpretation, /不足|过小/);
  });

  test('残差诊断被报告', () => {
    const dataset = makeDataset({
      X: Array.from({ length: 20 }, (_, index) => index + 1),
      Y: Array.from({ length: 20 }, (_, index) => 2 * (index + 1) + (index % 3) - 1),
    });
    const model = olsRegression(dataset, 'Y', ['X']);
    assert.ok(model.diagnostics.durbin_watson !== null);
    assert.ok(model.diagnostics.residual_skewness !== null);
    assert.ok(model.diagnostics.max_abs_standardized_residual !== null);
  });

  test('解释文字明确说明不能推断因果', () => {
    const dataset = makeDataset({
      X: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
      Y: [2, 4, 5, 8, 9, 11, 13, 14, 17, 19],
    });
    const model = olsRegression(dataset, 'Y', ['X']);
    assert.match(model.interpretation, /不能据此推断因果|不等于因果/);
  });
});

/* ================================================================== */
/* Group comparison                                                   */
/* ================================================================== */

describe('组间比较', () => {
  test('t 检验：可手工核对的精确结果', () => {
    // A = [1..5]（M=3, SD=√2.5），B = [6..10]（M=8, SD=√2.5）
    // 合并方差 = 2.5 → SE = 1 → t = −5，df = 8
    const a = [1, 2, 3, 4, 5];
    const b = [6, 7, 8, 9, 10];
    const result = independentTTest(a, b, { a: 'A组', b: 'B组' });

    assert.equal(result.method, 'student', '方差齐性成立时应使用 Student t');
    closeTo(result.mean_a, 3, 1e-9, 'M_A');
    closeTo(result.mean_b, 8, 1e-9, 'M_B');
    closeTo(result.mean_difference, -5, 1e-9, '均值差');
    closeTo(result.t, -5, 1e-6, 't');
    assert.equal(result.degrees_of_freedom, 8);
    closeTo(result.p_value, 0.001052, 1e-5, 'p');
    closeTo(result.cohens_d, -5 / Math.sqrt(2.5), 1e-4, "Cohen's d");
    assert.equal(result.n_a, 5);
    assert.equal(result.n_b, 5);
  });

  test('方差不齐时自动改用 Welch 检验', () => {
    const a = [1, 2, 3, 4, 5];
    const b = [1, 20, 40, 60, 100];
    const result = independentTTest(a, b, { a: 'A', b: 'B' });
    assert.equal(result.method, 'welch');
    assert.match(result.interpretation, /Welch/);
    // Welch 自由度不应等于 n1+n2-2
    assert.ok(Math.abs(result.degrees_of_freedom - 8) > 0.5, '自由度应被校正');
  });

  test('Levene 检验：同方差时为不显著', () => {
    const result = leveneTest([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]], ['A', 'B']);
    assert.ok(result !== null);
    closeTo(result!.statistic, 0, 1e-9, '统计量');
    closeTo(result!.p_value, 1, 1e-9, 'p');
    assert.equal(result!.equal_variances, true);
    assert.equal(result!.degrees_of_freedom, 1);
  });

  test('Levene 检验：可同时检验多于两组', () => {
    // A 与 B 的离散程度完全相同，C 明显更分散。
    // 中位数绝对偏差：A、B → [1,1,0,0,1,1] 均值 0.6667；C → [4,4,0,0,4,4] 均值 2.6667。
    // 总均值 1.3333；组间 SS = 6(0.4444)×2 + 6(1.7778) = 16；
    // 组内 SS = 1.3333 + 1.3333 + 21.3333 = 24；F(2,15) = (16/2)/(24/15) = 5.0。
    const a = [4, 4, 5, 5, 6, 6];
    const b = [4, 4, 5, 5, 6, 6];
    const c = [1, 1, 5, 5, 9, 9];

    const allThree = leveneTest([a, b, c], ['A', 'B', 'C']);
    assert.ok(allThree !== null);
    assert.equal(allThree!.degrees_of_freedom, 2);
    closeTo(allThree!.statistic, 5, 1e-3, '三组 Levene 统计量');
    assert.equal(allThree!.equal_variances, false, 'C 组方差明显更大，应判为方差不齐');

    // 只看前两组会得出"方差齐性"的结论，从而漏掉 C 组 —— 这正是必须检验全部组的原因。
    const firstTwoOnly = leveneTest([a, b], ['A', 'B']);
    assert.ok(firstTwoOnly !== null);
    closeTo(firstTwoOnly!.statistic, 0, 1e-9, '前两组离散程度相同');
    assert.equal(firstTwoOnly!.equal_variances, true);
  });

  test('Levene 检验：任一组不足 3 例时如实返回 null', () => {
    assert.equal(leveneTest([[1, 2], [3, 4, 5]], ['A', 'B']), null);
    assert.equal(leveneTest([[1, 2, 3]], ['A']), null);
  });

  test('单因素方差分析：可手工核对的精确结果', () => {
    // 三组 [1,2,3]/[4,5,6]/[7,8,9]：SSB = 54，SSW = 6 → F(2,6) = 27，η² = 0.9
    const dataset = makeDataset({
      G: [1, 1, 1, 2, 2, 2, 3, 3, 3],
      Y: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    });
    dataset.by_name.get('G')!.value_labels = { '1': '低', '2': '中', '3': '高' };

    const result = oneWayAnova(dataset, 'Y', 'G');

    closeTo(result.ss_between, 54, 1e-6, 'SSB');
    closeTo(result.ss_within, 6, 1e-6, 'SSW');
    closeTo(result.ss_total, 60, 1e-6, 'SST');
    assert.equal(result.df_between, 2);
    assert.equal(result.df_within, 6);
    closeTo(result.f, 27, 1e-6, 'F');
    assert.ok(result.p_value < 0.01, `p 应很小，实际 ${result.p_value}`);
    closeTo(result.eta_squared, 0.9, 1e-6, 'η²');
    assert.equal(result.groups.length, 3);
  });

  test('方差分析给出 Holm 校正后的两两比较', () => {
    const dataset = makeDataset({
      G: [
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
      ],
      Y: [
        1, 2, 1, 2, 1, 2, 1, 2, 1, 2,
        5, 6, 5, 6, 5, 6, 5, 6, 5, 6,
        9, 10, 9, 10, 9, 10, 9, 10, 9, 10,
      ],
    });
    const result = oneWayAnova(dataset, 'Y', 'G');
    assert.equal(result.post_hoc.length, 3, '三组应有 3 对比较');
    for (const pair of result.post_hoc) {
      assert.ok(pair.p_adjusted >= pair.p_raw - 1e-9, 'Holm 校正后的 p 不应小于原始 p');
    }
  });

  test('单组时拒绝方差分析', () => {
    const dataset = makeDataset({ G: [1, 1, 1, 1], Y: [1, 2, 3, 4] });
    const result = oneWayAnova(dataset, 'Y', 'G');
    assert.match(result.interpretation, /只有一个水平/);
  });

  test('Mann–Whitney U：完全分离的组', () => {
    const a = [1, 2, 3];
    const b = [10, 11, 12];
    const result = mannWhitneyU(a, b, { a: 'A', b: 'B' });
    closeTo(result.u, 0, 1e-9, 'U（完全分离）');
    closeTo(result.mean_rank_a, 2, 1e-9, 'A 组平均秩');
    closeTo(result.mean_rank_b, 5, 1e-9, 'B 组平均秩');
    closeTo(result.rank_biserial_r, -1, 1e-9, '秩二列相关');
    assert.ok(result.p_value < 0.2, `p 应较小，实际 ${result.p_value}`);
  });

  test('Mann–Whitney U：大样本完全分离时高度显著', () => {
    const a = Array.from({ length: 20 }, (_, index) => index + 1);
    const b = Array.from({ length: 20 }, (_, index) => index + 101);
    const result = mannWhitneyU(a, b, { a: 'A', b: 'B' });
    closeTo(result.u, 0, 1e-9, 'U');
    assert.ok(result.p_value < 0.001, `p 应高度显著，实际 ${result.p_value}`);
  });

  test('Mann–Whitney U 对结点做校正', () => {
    const a = [1, 1, 2, 2, 3];
    const b = [3, 4, 4, 5, 5];
    const result = mannWhitneyU(a, b, { a: 'A', b: 'B' });
    assert.equal(result.tie_corrected, true);
    assert.match(result.interpretation, /结点校正/);
  });

  test('Kruskal–Wallis：三组完全分离时 H 很大', () => {
    const dataset = makeDataset({
      G: [1, 1, 1, 2, 2, 2, 3, 3, 3],
      Y: [1, 2, 3, 10, 11, 12, 20, 21, 22],
    });
    const result = kruskalWallis(dataset, 'Y', 'G');
    assert.equal(result.degrees_of_freedom, 2);
    assert.ok(result.h > 6, `H 应较大，实际 ${result.h}`);
    assert.ok(result.p_value < 0.05, `p 应显著，实际 ${result.p_value}`);
    assert.equal(result.groups.length, 3);
    assert.match(result.interpretation, /分布位置/);
  });

  test('卡方检验：可手工核对的精确结果', () => {
    // [[10,20],[20,10]]：期望均为 15 → χ² = 6.6667，df = 1
    const dataset = makeDataset({
      R: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
      C: [1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
    });

    const result = chiSquareTest(dataset, 'R', 'C');
    assert.equal(result.n, 60);
    closeTo(result.chi_square, 6.6667, 1e-3, 'χ²');
    assert.equal(result.degrees_of_freedom, 1);
    closeTo(result.p_value, 0.009823, 1e-5, 'p');
    assert.equal(result.observed[0]![0], 10);
    assert.equal(result.observed[0]![1], 20);
    assert.equal(result.observed[1]![0], 20);
    assert.equal(result.observed[1]![1], 10);
    closeTo(result.expected[0]![0]!, 15, 1e-6, '期望频数');
    assert.ok(result.phi !== null, '2×2 表应给出 phi');
  });

  test('卡方检验报告标准化残量以定位偏离', () => {
    const dataset = makeDataset({
      R: [...Array(30).fill(1), ...Array(30).fill(2)],
      C: [...Array(25).fill(1), ...Array(5).fill(2), ...Array(5).fill(1), ...Array(25).fill(2)],
    });
    const result = chiSquareTest(dataset, 'R', 'C');
    assert.equal(result.standardized_residuals.length, 2);
    assert.ok(Math.abs(result.standardized_residuals[0]![0]!) > 1, '偏离单元格残量应较大');
    assert.ok(result.cramers_v !== null);
    assert.match(result.interpretation, /不能说明关联的方向/);
  });

  test('期望频数过小时给出警告', () => {
    const dataset = makeDataset({
      R: [1, 1, 1, 1, 1, 2, 2, 2, 2, 2],
      C: [1, 1, 2, 2, 2, 1, 1, 1, 2, 2],
    });
    const result = chiSquareTest(dataset, 'R', 'C');
    assert.ok(
      result.warnings.some((warning) => /期望频数/.test(warning) || /偏小/.test(warning)),
      '应提示样本量或期望频数问题',
    );
  });
});

/* ================================================================== */
/* Ordinal logistic                                                   */
/* ================================================================== */

describe('有序 Logistic 回归', () => {
  function ordinalDataset(): Dataset {
    // 强单调关系的三分类因变量
    const predictor: number[] = [];
    const outcome: number[] = [];
    for (let index = 0; index < 90; index += 1) {
      const x = (index % 30) / 10; // 0.0 — 2.9 循环
      predictor.push(x);
      const latent = 2.5 * x + ((index % 7) - 3) * 0.4;
      outcome.push(latent < 1 ? 1 : latent < 4 ? 2 : 3);
    }
    return makeDataset({ X: predictor, Y: outcome }, { dataTypes: { Y: 'ordinal' } });
  }

  test('模型收敛并给出系数、阈值、拟合指标', () => {
    const dataset = ordinalDataset();
    const model = ordinalLogistic(dataset, 'Y', ['X']);

    assert.equal(model.model, 'ordinal_logit');
    assert.equal(model.converged, true, `应收敛，迭代 ${model.iterations} 次`);
    assert.equal(model.categories.length, 3);
    assert.equal(model.thresholds.length, 2, '三分类应有 2 个阈值');
    assert.equal(model.coefficients.length, 1);
    assert.equal(model.n, 90);
    assert.ok(model.minus2_log_likelihood < model.minus2_log_likelihood_null, '模型应优于零模型');
  });

  test('系数方向正确，OR 等于 exp(b)', () => {
    const dataset = ordinalDataset();
    const model = ordinalLogistic(dataset, 'Y', ['X']);
    const coefficient = model.coefficients[0]!;

    assert.ok(coefficient.b > 0, `正向关系应得到正系数，实际 ${coefficient.b}`);
    // OR 由未取整的系数取幂，而 b 报告为 4 位小数，因此按相对误差比较。
    const relativeError = Math.abs(coefficient.odds_ratio - Math.exp(coefficient.b)) / coefficient.odds_ratio;
    assert.ok(relativeError < 1e-3, `OR 应等于 exp(b)，相对误差 ${relativeError}`);
    assert.ok(coefficient.odds_ratio > 1, 'OR 应大于 1');
    assert.ok(coefficient.odds_ratio_ci_lower < coefficient.odds_ratio);
    assert.ok(coefficient.odds_ratio_ci_upper > coefficient.odds_ratio);
    assert.ok(coefficient.p_value < 0.05, `p 应显著，实际 ${coefficient.p_value}`);
  });

  test('似然比检验与伪 R² 被报告', () => {
    const dataset = ordinalDataset();
    const model = ordinalLogistic(dataset, 'Y', ['X']);
    assert.ok(model.lr_chi_square > 0);
    assert.equal(model.lr_degrees_of_freedom, 1);
    assert.ok((model.lr_p_value ?? 1) < 0.05);
    assert.ok(model.mcfadden_r_squared !== null && model.mcfadden_r_squared > 0);
    assert.ok(model.nagelkerke_r_squared !== null);
    assert.ok(model.percent_correct !== null && model.percent_correct > 33, '分类正确率应高于随机');
  });

  test('比例优势假设被检验而非默认成立', () => {
    const dataset = ordinalDataset();
    const model = ordinalLogistic(dataset, 'Y', ['X']);
    assert.ok(model.proportional_odds_test.degrees_of_freedom > 0);
    assert.match(model.proportional_odds_test.interpretation, /比例优势/);
    assert.match(model.proportional_odds_test.interpretation, /不等于假设一定成立|建议/);
  });

  test('二分类因变量时提示等价于二元 Logistic', () => {
    const dataset = makeDataset(
      {
        X: Array.from({ length: 40 }, (_, index) => index / 10),
        Y: Array.from({ length: 40 }, (_, index) => (index < 20 ? 1 : 2)),
      },
      { dataTypes: { Y: 'ordinal' } },
    );
    const model = ordinalLogistic(dataset, 'Y', ['X']);
    assert.equal(model.categories.length, 2);
    assert.ok(
      model.warnings.some((warning) => warning.includes('二分类') || warning.includes('两个有序类别')),
      '应提示与二元 Logistic 等价',
    );
  });

  test('解释文字包含 n、类别数与伪 R²，并排除因果表述', () => {
    const dataset = ordinalDataset();
    const model = ordinalLogistic(dataset, 'Y', ['X']);
    assert.match(model.interpretation, /n = 90/);
    assert.match(model.interpretation, /3 个有序类别|3 个有序/);
    assert.match(model.interpretation, /不等于因果效应|条件关联/);
  });
});

/* ================================================================== */
/* Model selection                                                    */
/* ================================================================== */

describe('估计方法自动选择', () => {
  test('有序分类因变量选择有序 Logistic 而非 OLS', () => {
    const dataset = makeDataset(
      {
        Y: [1, 2, 3, 4, 5, 1, 2, 3, 4, 5],
        X: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
      },
      { dataTypes: { Y: 'ordinal' } },
    );
    const choice = chooseRegressionModel(dataset, 'Y');
    assert.equal(choice.model, 'ordinal_logit');
    if (choice.model === 'ordinal_logit') {
      assert.match(choice.reason, /有序分类/);
      assert.match(choice.reason, /OLS 会违反/);
    }
  });

  test('连续因变量选择 OLS', () => {
    const dataset = makeDataset({
      Y: [1.2, 2.7, 3.1, 4.8, 5.2, 6.9, 7.1, 8.4, 9.0, 10.5, 11.2, 12.8],
      X: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    });
    const choice = chooseRegressionModel(dataset, 'Y');
    assert.equal(choice.model, 'ols');
  });
});

/* ================================================================== */
/* Hypothesis testing                                                 */
/* ================================================================== */

describe('研究假设检验', () => {
  const definition: HypothesisDefinition = {
    code: 'HX',
    statement: 'A 与 B 呈正向关系。',
    independent: 'A',
    dependent: 'B',
    expected: 'positive',
    rationale: '测试用假设。',
  };

  test('显著且方向一致 → supported', () => {
    const dataset = makeDataset({
      A: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
      B: [2, 5, 4, 8, 9, 12, 11, 15, 17, 18, 21, 22, 25, 27, 28],
    });
    const result = testHypothesis(dataset, definition);
    assert.equal(result.verdict, 'supported');
    assert.ok(result.p_value !== null && result.p_value < 0.05);
    assert.equal(result.observed_direction, 'positive');
    assert.match(result.conclusion, /支持该假设/);
    assert.match(result.conclusion, /不能据此认为前者导致了后者/);
  });

  test('显著但方向相反 → not_supported（不并入"证据不足"）', () => {
    const dataset = makeDataset({
      A: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
      B: [28, 27, 25, 22, 21, 18, 17, 15, 11, 12, 9, 8, 4, 5, 2],
    });
    const result = testHypothesis(dataset, definition);
    assert.equal(result.verdict, 'not_supported');
    assert.equal(result.observed_direction, 'negative');
    assert.match(result.conclusion, /不支持该假设的方向/);
    assert.match(result.conclusion, /而不是改写假设/);
  });

  test('不显著 → inconclusive，并说明不等于证明无关', () => {
    const dataset = makeDataset({
      A: [1, 5, 3, 8, 2, 9, 4, 7, 6, 10, 1, 5, 3, 8, 2],
      B: [7, 3, 9, 1, 5, 2, 8, 4, 10, 6, 3, 9, 1, 5, 8],
    });
    const result = testHypothesis(dataset, definition);
    if (result.verdict === 'inconclusive') {
      assert.match(result.conclusion, /证据不足/);
      assert.match(result.conclusion, /不等于证明两者无关/);
    } else {
      assert.ok(result.p_value !== null && result.p_value < 0.05, '若显著则说明该随机数据确实相关');
    }
  });

  test('变量缺失 → untestable 并列出缺失变量', () => {
    const dataset = makeDataset({ A: [1, 2, 3, 4, 5, 6] });
    const result = testHypothesis(dataset, definition);
    assert.equal(result.verdict, 'untestable');
    assert.match(result.conclusion, /无法检验/);
    assert.ok(result.evidence.some((line) => line.includes('B')));
  });

  test('证据链包含方法、r、p、n 与效应量', () => {
    const dataset = makeDataset({
      A: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      B: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24],
    });
    const result = testHypothesis(dataset, definition);
    const evidence = result.evidence.join('\n');
    assert.match(evidence, /统计方法/);
    assert.match(evidence, /r =/);
    assert.match(evidence, /p =/);
    assert.match(evidence, /n = 12/);
    assert.match(evidence, /效应量/);
  });

  test('默认八条假设全部可运行并给出三值判定', () => {
    const n = 60;
    const make = (fn: (index: number) => number): number[] =>
      Array.from({ length: n }, (_, index) => fn(index));

    const dataset = makeDataset({
      FEK: make((index) => (index % 5) + 1),
      FSE: make((index) => (index % 5) + 1 + (index % 3) * 0.2),
      FPB: make((index) => (index % 5) + 1 + (index % 4) * 0.15),
      FED: make((index) => (index % 5) + 1),
      DSD: make((index) => (index % 5) + 1 + (index % 3) * 0.25),
      PSA: make((index) => (index % 5) + 1),
      PSUI: make((index) => (index % 5) + 1 + (index % 3) * 0.2),
      STI: make((index) => (index % 5) + 1),
      AIPV: make((index) => (index % 5) + 1),
      UI: make((index) => (index % 5) + 1 + (index % 3) * 0.3),
      PRC: make((index) => 5 - (index % 5)),
      WTP: make((index) => (index % 5) + 1),
    });

    const report = testAllHypotheses(dataset);
    assert.equal(report.results.length, 8);
    assert.equal(
      report.summary.supported +
        report.summary.not_supported +
        report.summary.inconclusive +
        report.summary.untestable,
      8,
    );
    for (const result of report.results) {
      assert.ok(
        ['supported', 'not_supported', 'inconclusive', 'untestable'].includes(result.verdict),
        `${result.code} 判定值非法：${result.verdict}`,
      );
      if (result.verdict !== 'untestable') {
        assert.ok(result.caveats.length > 0, `${result.code} 应给出解读注意事项`);
      }
    }
    assert.match(report.note, /不等同于证明假设不成立/);
    assert.match(report.note, /多重比较/);
    assert.match(report.note, /因果/);
  });

  test('默认假设定义引用的变量来自 V4.0 模板核心变量', () => {
    const templateVariables = new Set([
      'FEK', 'FSE', 'FPB', 'FED', 'DSD', 'PSA', 'PSUI', 'PSU',
      'STI', 'AIPV', 'UI', 'PRC', 'WTP',
    ]);
    for (const hypothesis of DEFAULT_HYPOTHESES) {
      assert.ok(
        templateVariables.has(hypothesis.independent),
        `${hypothesis.code} 的自变量 ${hypothesis.independent} 不在核心变量列表中`,
      );
      assert.ok(
        templateVariables.has(hypothesis.dependent),
        `${hypothesis.code} 的因变量 ${hypothesis.dependent} 不在核心变量列表中`,
      );
      assert.ok(hypothesis.rationale.length > 20, `${hypothesis.code} 缺少操作性定义说明`);
    }
  });
});

