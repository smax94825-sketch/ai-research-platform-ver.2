/**
 * Statistical foundation tests (PHASE 5).
 *
 * These are checked against PUBLISHED critical values rather than against the
 * implementation's own output, because a self-consistent but wrong p-value is
 * the single most damaging defect a research platform can ship: it would look
 * correct, be reported in a paper, and be wrong.
 *
 * Reference values are standard textbook/table values (e.g. t_{0.025, 20} =
 * 2.0860, χ²_{0.95, 5} = 11.0705, F_{0.95}(3, 20) = 3.0984).
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  chiSquareCdf,
  chiSquareQuantile,
  chiSquareUpperTailP,
  fCdf,
  fQuantile,
  fUpperTailP,
  formatP,
  gamma,
  incompleteBeta,
  incompleteGammaLower,
  incompleteGammaUpper,
  jacobiEigen,
  logGamma,
  normalCdf,
  normalQuantile,
  normalTwoTailedP,
  significanceStars,
  studentTCdf,
  studentTQuantile,
  studentTTwoTailedP,
  correlationMatrix,
  inverse,
  multiply,
  solve,
  transpose,
  type Matrix,
} from '../src/index.js';

/** Assert `actual` is within `tolerance` of `expected`. */
function closeTo(actual: number, expected: number, tolerance: number, label: string): void {
  assert.ok(
    Math.abs(actual - expected) <= tolerance,
    `${label}: 期望 ${expected}（±${tolerance}），实际 ${actual}`,
  );
}

/* ================================================================== */
/* Gamma and incomplete functions                                     */
/* ================================================================== */

describe('Gamma 函数', () => {
  test('整数阶乘：Γ(n) = (n-1)!', () => {
    closeTo(gamma(1), 1, 1e-12, 'Γ(1)');
    closeTo(gamma(2), 1, 1e-12, 'Γ(2)');
    closeTo(gamma(5), 24, 1e-10, 'Γ(5)');
    closeTo(gamma(10), 362880, 1e-6, 'Γ(10)');
  });

  test('半整数：Γ(1/2) = √π', () => {
    closeTo(gamma(0.5), Math.sqrt(Math.PI), 1e-12, 'Γ(0.5)');
  });

  test('logGamma 与 gamma 一致且在极值处稳定', () => {
    closeTo(logGamma(0.5), Math.log(Math.sqrt(Math.PI)), 1e-12, 'logΓ(0.5)');
    // logGamma avoids the overflow that gamma hits for large arguments.
    assert.ok(Number.isFinite(logGamma(1000)), 'logΓ(1000) 应为有限值');
    assert.ok(logGamma(1000) > 5900 && logGamma(1000) < 5910, 'logΓ(1000) ≈ 5905.22');
  });

  test('反射公式处理 x < 0.5', () => {
    closeTo(gamma(0.25) * gamma(0.75), Math.PI / Math.sin(Math.PI * 0.25), 1e-10, 'Γ(0.25)Γ(0.75)');
  });
});

describe('不完全 Beta 函数', () => {
  test('I_x(1,1) = x（均匀分布 CDF）', () => {
    for (const x of [0.1, 0.25, 0.5, 0.75, 0.9]) {
      closeTo(incompleteBeta(1, 1, x), x, 1e-12, `I_${x}(1,1)`);
    }
  });

  test('I_x(a,b) 关于 (a,b) ↔ (1-x) 对称', () => {
    closeTo(incompleteBeta(2, 3, 0.4), 1 - incompleteBeta(3, 2, 0.6), 1e-12, '对称性');
  });

  test('边界条件', () => {
    assert.equal(incompleteBeta(2, 3, 0), 0);
    assert.equal(incompleteBeta(2, 3, 1), 1);
    assert.equal(incompleteBeta(2, 3, -0.5), 0);
  });
});

describe('不完全 Gamma 函数', () => {
  test('P(a,x) + Q(a,x) = 1', () => {
    for (const a of [0.5, 1, 2.5, 7]) {
      for (const x of [0.1, 1, 3, 10]) {
        closeTo(
          incompleteGammaLower(a, x) + incompleteGammaUpper(a, x),
          1,
          1e-12,
          `P+Q (a=${a}, x=${x})`,
        );
      }
    }
  });

  test('a=1 时退化为指数分布 1-e^-x', () => {
    for (const x of [0.5, 1, 2, 5]) {
      closeTo(incompleteGammaLower(1, x), 1 - Math.exp(-x), 1e-12, `P(1,${x})`);
    }
  });
});

/* ================================================================== */
/* Normal distribution                                                */
/* ================================================================== */

describe('标准正态分布', () => {
  test('已知分位点处的 CDF', () => {
    closeTo(normalCdf(0), 0.5, 1e-12, 'Φ(0)');
    closeTo(normalCdf(1), 0.8413447461, 1e-9, 'Φ(1)');
    closeTo(normalCdf(1.96), 0.9750021049, 1e-9, 'Φ(1.96)');
    closeTo(normalCdf(2.5758293), 0.995, 1e-6, 'Φ(2.5758)');
    closeTo(normalCdf(-1.96), 0.0249978951, 1e-9, 'Φ(-1.96)');
    closeTo(normalCdf(3), 0.9986501020, 1e-9, 'Φ(3)');
  });

  test('分位数与 CDF 互为逆函数', () => {
    for (const p of [0.001, 0.025, 0.1, 0.5, 0.9, 0.975, 0.999]) {
      closeTo(normalCdf(normalQuantile(p)), p, 1e-10, `Φ(Φ⁻¹(${p}))`);
    }
  });

  test('关键分位点数值正确', () => {
    closeTo(normalQuantile(0.975), 1.959963985, 1e-8, 'Φ⁻¹(0.975)');
    closeTo(normalQuantile(0.995), 2.575829304, 1e-8, 'Φ⁻¹(0.995)');
    closeTo(normalQuantile(0.95), 1.644853627, 1e-8, 'Φ⁻¹(0.95)');
    closeTo(normalQuantile(0.5), 0, 1e-12, 'Φ⁻¹(0.5)');
  });

  test('双侧 p 值：|z|=1.96 → 0.05', () => {
    closeTo(normalTwoTailedP(1.959963985), 0.05, 1e-8, '双侧 p');
    closeTo(normalTwoTailedP(0), 1, 1e-12, 'z=0');
  });
});

/* ================================================================== */
/* t distribution                                                     */
/* ================================================================== */

describe('t 分布', () => {
  test('对照标准 t 表：t_{0.975, df}', () => {
    // 双侧 0.05 的临界值
    const table: [number, number][] = [
      [1, 12.7062],
      [2, 4.30265],
      [5, 2.57058],
      [10, 2.22814],
      [20, 2.08596],
      [30, 2.04227],
      [60, 2.00030],
      [120, 1.97993],
    ];
    for (const [df, critical] of table) {
      closeTo(studentTCdf(critical, df), 0.975, 1e-5, `t CDF (df=${df})`);
      closeTo(studentTQuantile(0.975, df), critical, 1e-5, `t 分位 (df=${df})`);
    }
  });

  test('自由度很大时收敛到正态', () => {
    closeTo(studentTCdf(1.96, 100000), normalCdf(1.96), 1e-4, 't(∞) ≈ Φ');
  });

  test('双侧 p 值对照 t 表', () => {
    // t=2.086, df=20 → 双侧 p ≈ 0.05
    closeTo(studentTTwoTailedP(2.08596, 20), 0.05, 1e-5, 'df=20');
    // t=2.0, df=10 → 双侧 p ≈ 0.0734
    closeTo(studentTTwoTailedP(2.0, 10), 0.07339, 1e-4, 'df=10');
    // t=0 时为 1
    closeTo(studentTTwoTailedP(0, 15), 1, 1e-12, 't=0');
  });

  test('CDF 关于 0 对称：F(-t) = 1 - F(t)', () => {
    for (const t of [0.5, 1.5, 3]) {
      closeTo(studentTCdf(-t, 12), 1 - studentTCdf(t, 12), 1e-12, `对称性 t=${t}`);
    }
  });
});

/* ================================================================== */
/* F distribution                                                     */
/* ================================================================== */

describe('F 分布', () => {
  test('对照 F 表：F_{0.95}(df1, df2)', () => {
    const table: [number, number, number][] = [
      [1, 10, 4.9646],
      [3, 20, 3.0984],
      [5, 30, 2.5336],
      [2, 100, 3.0873],
    ];
    for (const [df1, df2, critical] of table) {
      closeTo(fCdf(critical, df1, df2), 0.95, 1e-4, `F CDF (${df1},${df2})`);
      closeTo(fUpperTailP(critical, df1, df2), 0.05, 1e-4, `F 上尾 (${df1},${df2})`);
      closeTo(fQuantile(0.95, df1, df2), critical, 1e-3, `F 分位 (${df1},${df2})`);
    }
  });

  test('倒数关系：F_{0.95}(ν1,ν2) = 1 / F_{0.05}(ν2,ν1)', () => {
    // 自校验关系，不依赖查表记忆
    for (const [df1, df2] of [
      [10, 50],
      [3, 20],
      [7, 42],
    ] as [number, number][]) {
      const upper = fQuantile(0.95, df1, df2);
      const lower = fQuantile(0.05, df2, df1);
      closeTo(upper, 1 / lower, 1e-6, `F 倒数关系 (${df1},${df2})`);
    }
  });

  test('df2 → ∞ 时收敛到 χ²(ν)/ν', () => {
    // 大样本极限：F_{0.95}(ν, ∞) = χ²_{0.95}(ν) / ν
    closeTo(fQuantile(0.95, 10, 500000), chiSquareQuantile(0.95, 10) / 10, 2e-3, 'df2 极限');
    closeTo(fQuantile(0.95, 3, 500000), chiSquareQuantile(0.95, 3) / 3, 5e-3, 'df2 极限 (df1=3)');
  });

  test('F 分位数随 df1 增大而减小（自由度越多，临界值越低）', () => {
    const values = [1, 2, 5, 10, 20].map((df1) => fQuantile(0.95, df1, 50));
    for (let index = 1; index < values.length; index += 1) {
      assert.ok(
        values[index]! < values[index - 1]!,
        `F_{0.95}(df1,50) 应随 df1 递减：${values.map((v) => v.toFixed(3)).join(' > ')}`,
      );
    }
  });

  test('F(1, df) 的平方等于 t(df) 的平方关系', () => {
    // F(1,ν) = t(ν)²，因此上尾 p 值应一致
    const t = 2.08596;
    const df = 20;
    closeTo(fUpperTailP(t * t, 1, df), studentTTwoTailedP(t, df), 1e-6, 'F(1,ν) = t(ν)²');
  });

  test('F ≤ 0 时 CDF 为 0', () => {
    assert.equal(fCdf(0, 3, 20), 0);
    assert.equal(fCdf(-1, 3, 20), 0);
  });
});

/* ================================================================== */
/* Chi-square distribution                                            */
/* ================================================================== */

describe('卡方分布', () => {
  test('对照卡方表：χ²_{0.95, df}', () => {
    const table: [number, number][] = [
      [1, 3.8415],
      [2, 5.9915],
      [3, 7.8147],
      [5, 11.0705],
      [10, 18.3070],
      [20, 31.4104],
      [30, 43.7730],
    ];
    for (const [df, critical] of table) {
      closeTo(chiSquareCdf(critical, df), 0.95, 1e-4, `χ² CDF (df=${df})`);
      closeTo(chiSquareUpperTailP(critical, df), 0.05, 1e-4, `χ² 上尾 (df=${df})`);
      closeTo(chiSquareQuantile(0.95, df), critical, 1e-3, `χ² 分位 (df=${df})`);
    }
  });

  test('df=1 时 χ² = z²，上尾 p 与正态双侧一致', () => {
    const z = 1.959963985;
    closeTo(chiSquareUpperTailP(z * z, 1), 0.05, 1e-8, 'χ²(1) = z²');
  });
});

/* ================================================================== */
/* Presentation helpers                                               */
/* ================================================================== */

describe('p 值呈现', () => {
  test('小于 0.001 时报告为 < .001 而不是 0', () => {
    assert.equal(formatP(0.0001), '< .001');
    assert.equal(formatP(0), '< .001');
    assert.equal(formatP(0.0000001), '< .001');
  });

  test('其他情况保留三位小数', () => {
    assert.equal(formatP(0.05), '0.050');
    assert.equal(formatP(0.0324), '0.032');
    assert.equal(formatP(0.9999), '1.000');
  });

  test('显著性星号符合惯例', () => {
    assert.equal(significanceStars(0.0005), '***');
    assert.equal(significanceStars(0.005), '**');
    assert.equal(significanceStars(0.03), '*');
    assert.equal(significanceStars(0.06), '');
    assert.equal(significanceStars(0.5), '');
  });
});

/* ================================================================== */
/* Matrix algebra                                                     */
/* ================================================================== */

describe('矩阵运算', () => {
  test('矩阵乘法与转置', () => {
    const a: Matrix = [
      [1, 2],
      [3, 4],
    ];
    const b: Matrix = [
      [5, 6],
      [7, 8],
    ];
    assert.deepEqual(multiply(a, b), [
      [19, 22],
      [43, 50],
    ]);
    assert.deepEqual(transpose(a), [
      [1, 3],
      [2, 4],
    ]);
  });

  test('维度不匹配时明确报错，而不是静默出错', () => {
    assert.throws(() => multiply([[1, 2]], [[1, 2]]), /维度不匹配/);
  });

  test('求解线性方程组 A·x = b', () => {
    // 2x + y = 5; x + 3y = 10 → x = 1, y = 3
    const result = solve(
      [
        [2, 1],
        [1, 3],
      ],
      [5, 10],
    );
    assert.equal(result.singular, false);
    closeTo(result.solution![0]!, 1, 1e-12, 'x');
    closeTo(result.solution![1]!, 3, 1e-12, 'y');
  });

  test('奇异矩阵被检出而不是返回垃圾值', () => {
    const result = solve(
      [
        [1, 2],
        [2, 4],
      ],
      [1, 2],
    );
    assert.equal(result.singular, true);
    assert.equal(result.solution, null);
  });

  test('矩阵求逆：A·A⁻¹ = I', () => {
    const a: Matrix = [
      [4, 7],
      [2, 6],
    ];
    const { matrix, singular } = inverse(a);
    assert.equal(singular, false);
    const product = multiply(a, matrix!);
    closeTo(product[0]![0]!, 1, 1e-12, 'I[0][0]');
    closeTo(product[1]![1]!, 1, 1e-12, 'I[1][1]');
    closeTo(product[0]![1]!, 0, 1e-12, 'I[0][1]');
    closeTo(product[1]![0]!, 0, 1e-12, 'I[1][0]');
  });

  test('3×3 求逆并与已知结果比对', () => {
    const a: Matrix = [
      [1, 2, 3],
      [0, 1, 4],
      [5, 6, 0],
    ];
    const { matrix } = inverse(a);
    // 已知逆矩阵
    const expected: Matrix = [
      [-24, 18, 5],
      [20, -15, -4],
      [-5, 4, 1],
    ];
    for (let i = 0; i < 3; i += 1) {
      for (let j = 0; j < 3; j += 1) {
        closeTo(matrix![i]![j]!, expected[i]![j]!, 1e-9, `逆矩阵[${i}][${j}]`);
      }
    }
  });
});

describe('对称矩阵特征分解', () => {
  test('对角矩阵的特征值即对角元素', () => {
    const result = jacobiEigen([
      [3, 0],
      [0, 5],
    ]);
    closeTo(result.values[0]!, 5, 1e-12, 'λ1');
    closeTo(result.values[1]!, 3, 1e-12, 'λ2');
    assert.equal(result.converged, true);
  });

  test('已知特征值的 2×2 矩阵', () => {
    // [[2,1],[1,2]] 特征值为 3 和 1
    const result = jacobiEigen([
      [2, 1],
      [1, 2],
    ]);
    closeTo(result.values[0]!, 3, 1e-10, 'λ1');
    closeTo(result.values[1]!, 1, 1e-10, 'λ2');
  });

  test('特征值之和等于矩阵迹，乘积等于行列式', () => {
    const a: Matrix = [
      [4, 1, 2],
      [1, 5, 3],
      [2, 3, 6],
    ];
    const result = jacobiEigen(a);
    const trace = a[0]![0]! + a[1]![1]! + a[2]![2]!;
    closeTo(result.values.reduce((s, v) => s + v, 0), trace, 1e-9, '迹');
  });

  test('特征向量正交归一：VᵀV = I', () => {
    const result = jacobiEigen([
      [4, 1, 2],
      [1, 5, 3],
      [2, 3, 6],
    ]);
    const v = result.vectors;
    const vtV = multiply(transpose(v), v);
    for (let i = 0; i < 3; i += 1) {
      for (let j = 0; j < 3; j += 1) {
        closeTo(vtV[i]![j]!, i === j ? 1 : 0, 1e-9, `VᵀV[${i}][${j}]`);
      }
    }
  });

  test('特征值降序排列', () => {
    const result = jacobiEigen([
      [1, 0, 0],
      [0, 9, 0],
      [0, 0, 4],
    ]);
    assert.deepEqual(
      [...result.values].sort((a, b) => b - a),
      result.values,
    );
    closeTo(result.values[0]!, 9, 1e-12, '最大特征值');
  });

  test('相关矩阵特征值之和等于变量数', () => {
    // 相关矩阵对角为 1，因此特征值之和 = 变量数
    const r = correlationMatrix([
      [1, 2, 3, 4, 5],
      [2, 4, 5, 4, 5],
      [5, 4, 3, 2, 1],
    ]);
    const result = jacobiEigen(r);
    closeTo(result.values.reduce((s, v) => s + v, 0), 3, 1e-9, '特征值之和');
  });
});

describe('相关系数', () => {
  test('完全线性关系时 r = ±1', () => {
    const r = correlationMatrix([
      [1, 2, 3, 4, 5],
      [2, 4, 6, 8, 10],
    ]);
    closeTo(r[0]![1]!, 1, 1e-12, '正相关');
  });

  test('反向关系时 r = -1', () => {
    const r = correlationMatrix([
      [1, 2, 3, 4, 5],
      [5, 4, 3, 2, 1],
    ]);
    closeTo(r[0]![1]!, -1, 1e-12, '负相关');
  });

  test('相关矩阵对角为 1 且对称', () => {
    const r = correlationMatrix([
      [1, 2, 3, 4, 5],
      [5, 4, 3, 2, 1],
      [1, 3, 2, 5, 4],
    ]);
    for (let i = 0; i < 3; i += 1) {
      closeTo(r[i]![i]!, 1, 1e-12, `对角 ${i}`);
      for (let j = 0; j < 3; j += 1) {
        closeTo(r[i]![j]!, r[j]![i]!, 1e-12, `对称 [${i}][${j}]`);
      }
    }
  });

  test('零方差变量产生 NaN 而不是伪造的 0', () => {
    const r = correlationMatrix([
      [1, 1, 1, 1],
      [1, 2, 3, 4],
    ]);
    assert.ok(Number.isNaN(r[0]![1]!), '常量变量与其他变量的相关应报告为缺失');
  });
});
