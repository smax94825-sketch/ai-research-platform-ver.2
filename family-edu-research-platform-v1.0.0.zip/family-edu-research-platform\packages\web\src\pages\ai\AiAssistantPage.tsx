/**
 * AI research assistant (PHASE 7).
 *
 * The model is the only part of this platform that can produce text nobody
 * measured, so the page is built around showing where the engine stops and the
 * model starts:
 *
 *  - **Availability first.** `GET /ai/status` is read before anything can be
 *    generated, and the API's own Chinese reason is shown verbatim. When no API
 *    key is configured the page says so plainly and states that the deterministic
 *    engine-derived summary is what a click will produce — the degraded output is
 *    never presented as if a model wrote it.
 *  - **Four levels, four groups.** 事实 / 统计发现 / 解释 / 建议 are rendered as
 *    separate sections, never merged into one block, so a recommendation can
 *    never be mistaken for a measurement.
 *  - **Evidence trace on every statement.** Each `{path, value, source}` is
 *    printed as the bundle path plus the value found there, which is what lets a
 *    reader check a sentence against the analysis console.
 *  - **Rejected claims are shown, not hidden.** A number the model could not
 *    trace to the bundle voids its statement; the voiding is presented as the
 *    guard working, with the offending figure quoted.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Alert, Badge, Button, Card, CardHeader, Input, LoadingBlock, Select, StatCard } from '../../components/ui';
import type { BadgeTone } from '../../lib/format';
import { formatDateTime, formatNumber } from '../../lib/format';
import {
  AI_LEVELS,
  AI_LEVEL_LABELS_ZH,
  AI_INTERPRETATION_SECTIONS,
  AI_SECTION_LABELS_ZH,
  api,
  ApiClientError,
  type AiEvidence,
  type AiHistoryItem,
  type AiInterpretRequest,
  type AiInterpretationResult,
  type AiLevel,
  type AiRejectedClaim,
  type AiStatement,
  type AiStatus,
  type HypothesisTestResult,
} from '../../lib/api';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from '../analysis/shared';

/* ------------------------------------------------------------------ */
/* Level presentation                                                 */
/* ------------------------------------------------------------------ */

interface LevelMeta {
  level: AiLevel;
  /** Which array of `layers` holds this level. */
  key: 'facts' | 'statistical_findings' | 'interpretations' | 'recommendations';
  tone: BadgeTone;
  /** Frame + glyph make the four groups distinguishable without relying on hue. */
  frame: string;
  glyph: string;
  meaning: string;
}

/**
 * The four levels, in reading order.
 *
 * `FACT` and `RECOMMENDATION` are deliberately the furthest apart in treatment:
 * one is a value copied out of the bundle, the other is the model's suggestion,
 * and the two must never look alike on screen.
 */
const LEVEL_META: LevelMeta[] = [
  {
    level: 'FACT',
    key: 'facts',
    tone: 'success',
    frame: 'border-emerald-300 bg-emerald-50',
    glyph: '=',
    meaning: '逐字取自统计结果包的数值（例如 n、样本量）。这一层没有模型判断。',
  },
  {
    level: 'STATISTICAL_FINDING',
    key: 'statistical_findings',
    tone: 'info',
    frame: 'border-brand-300 bg-brand-50',
    glyph: 'r',
    meaning: '统计引擎计算出的统计量（r、p、α、F 等），同样不是模型算的。',
  },
  {
    level: 'INTERPRETATION',
    key: 'interpretations',
    tone: 'warning',
    frame: 'border-amber-300 bg-amber-50',
    glyph: '?',
    meaning: '模型对这些统计量的解读：可能、提示、伴随。解读可以争论，统计量不能。',
  },
  {
    level: 'RECOMMENDATION',
    key: 'recommendations',
    tone: 'neutral',
    frame: 'border-ink-300 bg-ink-50',
    glyph: '→',
    meaning: '模型基于上述结果给出的可执行建议。建议不是发现，落地前需研究者判断。',
  },
];

const REJECTED_CODE_LABELS: Record<string, string> = {
  untraceable_number: '数字无法在结果包中溯源',
  no_evidence: '没有任何可溯源的证据',
  evidence_path_not_found: '声明的证据路径不存在',
  evidence_value_mismatch: '证据值与结果包不一致',
  empty_statement: '只有标签、没有陈述内容',
};

/** Evidence values are printed as the bundle stores them; null stays visible. */
function evidenceValueText(value: AiEvidence['value']): string {
  if (value === null) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  return String(value);
}

/* ------------------------------------------------------------------ */
/* Small pieces                                                       */
/* ------------------------------------------------------------------ */

function EvidenceList({ evidence }: { evidence: AiEvidence[] }): ReactNode {
  if (evidence.length === 0) {
    return (
      <p className="text-xs text-ink-500">
        该条没有可回溯的结果包引用：它陈述的是一个「没有出现」的事实（例如没有显著相关、没有可计算的 α），
        没有具体数值可以引用，因此没有证据路径。
      </p>
    );
  }

  return (
    <ul className="space-y-1">
      {evidence.map((item) => (
        <li key={`${item.path}=${evidenceValueText(item.value)}`} className="flex flex-wrap items-baseline gap-2 text-xs">
          <code className="rounded bg-ink-100 px-1.5 py-0.5 font-mono text-[11px] text-ink-700">
            {item.path}
          </code>
          <span className="text-ink-400">=</span>
          <span className="font-mono tabular-nums text-ink-900">{evidenceValueText(item.value)}</span>
          <span className="text-[11px] text-ink-500">
            {item.source === 'declared' ? '（模型声明的引用）' : '（由正文中可溯源的数值推定）'}
          </span>
        </li>
      ))}
    </ul>
  );
}

function StatementCard({ statement }: { statement: AiStatement }): ReactNode {
  const meta = LEVEL_META.find((item) => item.level === statement.level);

  return (
    <li className="rounded-md border border-ink-200 bg-white px-3.5 py-3">
      <div className="flex flex-wrap items-center gap-2">
        <Badge tone={meta?.tone ?? 'neutral'}>
          {`${meta?.glyph ?? '·'} ${AI_LEVEL_LABELS_ZH[statement.level]}`}
        </Badge>
        <span className="font-mono text-[11px] text-ink-400">{statement.level}</span>
        {statement.hypothesis_code && (
          <span className="font-mono text-[11px] text-ink-600">{`假设 ${statement.hypothesis_code}`}</span>
        )}
        {statement.label_inferred && (
          <Badge tone="warning">模型未标注层级，按措辞推断</Badge>
        )}
      </div>

      <p className="mt-2 text-sm leading-relaxed text-ink-900">{statement.text}</p>

      <div className="mt-2">
        <p className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-ink-500">
          证据留痕（可在分析页逐条核对）
        </p>
        <EvidenceList evidence={statement.evidence} />
      </div>
    </li>
  );
}

function LevelGroup({
  meta,
  statements,
}: {
  meta: LevelMeta;
  statements: AiStatement[];
}): ReactNode {
  return (
    <section className={`rounded-lg border px-4 py-4 ${meta.frame}`}>
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="flex items-center gap-2 text-base font-semibold text-ink-900">
          <span aria-hidden="true" className="font-mono">
            {meta.glyph}
          </span>
          {AI_LEVEL_LABELS_ZH[meta.level]}
          <span className="font-mono text-[11px] font-normal text-ink-500">{meta.level}</span>
        </h2>
        <span className="text-xs text-ink-600">{`${statements.length} 条`}</span>
      </div>
      <p className="mt-1 text-xs leading-relaxed text-ink-700">{meta.meaning}</p>

      {statements.length === 0 ? (
        <p className="mt-3 text-xs text-ink-500">
          本层没有任何陈述：{meta.level === 'RECOMMENDATION' ? '模型没有给出建议' : '模型没有给出这一层的内容'}。
          此处留空而不是补写，避免把不存在的结论呈现为结果。
        </p>
      ) : (
        <ul className="mt-3 space-y-2">
          {statements.map((statement) => (
            <StatementCard key={statement.id} statement={statement} />
          ))}
        </ul>
      )}
    </section>
  );
}

function RejectedClaims({ claims }: { claims: AiRejectedClaim[] }): ReactNode {
  if (claims.length === 0) return null;

  return (
    <div className="rounded-lg border-2 border-red-300 bg-red-50 px-4 py-4">
      <h2 className="text-base font-semibold text-red-900">
        {`已剔除 ${claims.length} 条无法溯源的模型陈述（防护机制生效）`}
      </h2>
      <p className="mt-1 text-xs leading-relaxed text-red-900">
        以下内容由模型生成，但其中的数字无法在统计结果包中溯源，或声明的证据不存在。
        平台的校验逻辑因此删除了整条陈述：这些数字没有出现在上方的任何一层结论中，也不会进入研究报告。
        这是平台的溯源保护在按设计工作，不是系统故障；保留下来的每一条都可以在分析页核对。
      </p>

      <ul className="mt-3 space-y-2">
        {claims.map((claim, index) => (
          <li key={`${claim.code}-${index}`} className="rounded-md border border-red-200 bg-white px-3.5 py-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="danger">{REJECTED_CODE_LABELS[claim.code] ?? claim.code}</Badge>
              {claim.level && <span className="font-mono text-[11px] text-ink-500">{claim.level}</span>}
              {claim.raw_number && (
                <span className="text-xs text-red-800">
                  无法溯源的数字：
                  <span className="ml-1 font-mono tabular-nums font-semibold text-red-900">{claim.raw_number}</span>
                </span>
              )}
            </div>
            <p className="mt-2 text-sm leading-relaxed text-ink-700 line-through decoration-red-300">
              {claim.text}
            </p>
            <p className="mt-1 text-xs leading-relaxed text-red-900">{claim.reason}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                               */
/* ------------------------------------------------------------------ */

export function AiAssistantPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [status, setStatus] = useState<AiStatus | null>(null);
  const [history, setHistory] = useState<AiHistoryItem[]>([]);
  const [hypotheses, setHypotheses] = useState<HypothesisTestResult[]>([]);
  const [result, setResult] = useState<AiInterpretationResult | null>(null);

  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [historyError, setHistoryError] = useState<string | null>(null);
  const [runError, setRunError] = useState<string | null>(null);

  const [section, setSection] = useState('');
  const [hypothesisCode, setHypothesisCode] = useState('');
  const [focus, setFocus] = useState('');

  const loadHistory = useCallback(async (id: string) => {
    try {
      setHistory(await api.ai.history(id, 20));
      setHistoryError(null);
    } catch (err) {
      setHistory([]);
      setHistoryError(err instanceof ApiClientError ? err.message : '无法加载 AI 解释历史。');
    }
  }, []);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setStatus(await api.ai.status(projectId));
    } catch (err) {
      setStatus(null);
      setError(err instanceof ApiClientError ? err.message : '无法读取 AI 解释状态。');
    } finally {
      setLoading(false);
    }
    // Neither the history nor the hypothesis list gates the page: the status and
    // the generate button still work when they are unavailable.
    await loadHistory(projectId);
    try {
      const report = await api.analysis.hypotheses(projectId);
      setHypotheses(report.results);
    } catch {
      setHypotheses([]);
    }
  }, [projectId, loadHistory]);

  useEffect(() => {
    void load();
  }, [load]);

  async function handleRun(): Promise<void> {
    if (!projectId) return;
    setRunning(true);
    setRunError(null);
    try {
      const body: AiInterpretRequest = {};
      if (section !== '') body.section = section;
      if (hypothesisCode !== '') body.hypothesis_code = hypothesisCode;
      if (focus.trim() !== '') body.focus = focus.trim();
      setResult(await api.ai.interpret(projectId, body));
      await loadHistory(projectId);
    } catch (err) {
      setRunError(err instanceof ApiClientError ? err.message : '生成 AI 解释失败。');
    } finally {
      setRunning(false);
    }
  }

  const configured = status?.configured === true;
  const hasBundle = status?.has_bundle === true;
  const degraded = result?.mode === 'degraded';

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="AI Research Assistant"
          subtitle="AI 解释：只解释统计引擎已经算出的结果包，四层分立并逐条留痕；无法溯源的数字会被剔除。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !status ? (
          <LoadingBlock label="正在读取 AI 解释状态…" />
        ) : !status ? null : (
          <>
            <Card>
              <CardHeader
                title="AI 解释可用性"
                description="以下状态由服务端实时读取：是否配置了模型接口、结果包是否已生成。"
                actions={
                  <Badge tone={configured ? 'success' : 'warning'}>
                    {configured ? '已配置模型' : '未配置模型（不可用）'}
                  </Badge>
                }
              />
              <p className="text-sm leading-relaxed text-ink-800">{status.reason}</p>

              <dl className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">运行模式</dt>
                  <dd className="mt-1 text-sm text-ink-900">
                    {status.mode === 'live' ? 'live（调用模型）' : 'degraded（引擎摘要）'}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">模型</dt>
                  <dd className="mt-1 font-mono text-sm text-ink-800">{status.model}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">接口地址</dt>
                  <dd className="mt-1 break-all font-mono text-xs text-ink-700">{status.base_url}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">超时</dt>
                  <dd className="mt-1 tabular-nums text-sm text-ink-800">{`${formatNumber(status.timeout_ms)} 毫秒`}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">统计结果包</dt>
                  <dd className="mt-1 text-sm text-ink-800">
                    {status.has_bundle ? '已生成' : '尚未生成'}
                    {status.bundle_generated_at ? `（${formatDateTime(status.bundle_generated_at)}）` : ''}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">最近一次解释</dt>
                  <dd className="mt-1 text-sm text-ink-800">
                    {status.latest_interaction_at
                      ? `${formatDateTime(status.latest_interaction_at)}（${status.latest_mode === 'live' ? '模型生成' : '引擎摘要'}）`
                      : '尚无记录'}
                  </dd>
                </div>
              </dl>
            </Card>

            {!configured && (
              <Alert tone="warning" title="AI 解释当前不可用：未配置模型接口">
                <p>
                  平台不会伪造解释。点击「生成 AI 解释」不会调用任何生成式模型，返回的将是
                  <strong>由统计引擎直接依据统计结果包生成的中文摘要</strong>
                  （其中 <code className="font-mono">engine_summary.ai_generated = false</code>），
                  内容全部是结果包里的真实统计量，不含任何模型推断，也不会引入结果包之外的数字。
                </p>
                <p className="mt-1">
                  如需模型生成的解读，请在服务端配置 <code className="font-mono">DEEPSEEK_API_KEY</code> 后重启服务；
                  在此之前，页面上的所有文字都属于「引擎摘要」，不应被引用为 AI 生成内容。
                </p>
              </Alert>
            )}

            {!hasBundle && (
              <Alert tone="warning" title="尚未运行过完整统计分析">
                <p>
                  AI 只能解释已经存在的统计结果包。请先在「统计分析」页执行「运行全部分析」，
                  之后才能生成 AI 解释（服务端会直接拒绝本次请求并说明原因）。
                </p>
                <p className="mt-3">
                  <Link to={`/analysis?project=${projectId}`}>
                    <Button variant="primary">前往统计分析</Button>
                  </Link>
                </p>
              </Alert>
            )}

            <Card>
              <CardHeader
                title="生成 AI 解释"
                description="范围只决定模型重点讨论哪一部分，不会改变它能看到的内容：提示词始终包含完整的结果包与全部可引用路径。"
              />

              <div className="grid gap-4 sm:grid-cols-3">
                <label className="block">
                  <span className="ferp-label">解释范围（板块）</span>
                  <Select value={section} onChange={(event) => setSection(event.target.value)}>
                    <option value="">全部板块</option>
                    {AI_INTERPRETATION_SECTIONS.map((item) => (
                      <option key={item} value={item}>
                        {`${AI_SECTION_LABELS_ZH[item]}（${item}）`}
                      </option>
                    ))}
                  </Select>
                </label>

                <label className="block">
                  <span className="ferp-label">聚焦某条假设</span>
                  <Select
                    value={hypothesisCode}
                    onChange={(event) => setHypothesisCode(event.target.value)}
                    disabled={hypotheses.length === 0}
                  >
                    <option value="">不限假设</option>
                    {hypotheses.map((item) => (
                      <option key={item.code} value={item.code}>
                        {`${item.code}｜${item.statement}`}
                      </option>
                    ))}
                  </Select>
                  <span className="mt-1 block text-xs text-ink-500">
                    {hypotheses.length === 0
                      ? '当前项目没有可选的假设（未登记假设，或假设结果尚不可用）。'
                      : `可选 ${hypotheses.length} 条假设，取自统计分析结果。`}
                  </span>
                </label>

                <label className="block">
                  <span className="ferp-label">研究者关注点（可选）</span>
                  <Input
                    value={focus}
                    maxLength={2000}
                    placeholder="例如：请重点说明服务缺口与付费意愿的关系"
                    onChange={(event) => setFocus(event.target.value)}
                  />
                  <span className="mt-1 block text-xs text-ink-500">
                    该文字仅用于说明关注方向，不能提供任何数字。
                  </span>
                </label>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-3">
                <Button
                  variant="primary"
                  loading={running}
                  disabled={!hasBundle}
                  onClick={() => void handleRun()}
                >
                  生成 AI 解释
                </Button>
                <span className="text-xs text-ink-500">
                  {hasBundle
                    ? '生成结果会写入审计记录（ai_interactions），可在下方历史中逐条核对。'
                    : '需要先生成统计结果包，按钮已停用。'}
                </span>
              </div>

              {runError && (
                <div className="mt-3">
                  <ErrorNotice message={runError} />
                </div>
              )}
            </Card>
          </>
        )}

        {result && (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard
                label="本次运行模式"
                value={result.mode === 'live' ? 'live' : 'degraded'}
                tone={result.mode === 'live' ? 'info' : 'warning'}
                hint={result.mode === 'live' ? '调用模型生成' : '统计引擎直接生成'}
              />
              <StatCard label="可发布陈述" value={formatNumber(result.statement_count)} hint="已通过溯源校验" />
              <StatCard
                label="被剔除的陈述"
                value={formatNumber(result.rejected_claims.length)}
                tone={result.rejected_claims.length > 0 ? 'danger' : 'success'}
                hint={result.rejected_claims.length > 0 ? '数字无法溯源，已整条删除' : '没有发现无法溯源的内容'}
              />
              <StatCard
                label="覆盖层级"
                value={`${result.levels_used.length}/4`}
                hint={result.levels_used.map((level) => AI_LEVEL_LABELS_ZH[level]).join('、') || '无'}
              />
            </div>

            {degraded ? (
              <Alert tone="warning" title="本次结果由统计引擎直接生成，不是模型写的">
                <p>{result.engine_summary?.headline ?? '以下内容由统计引擎直接依据统计结果包生成。'}</p>
                <p className="mt-1">
                  {result.ai_unavailable
                    ? `未使用模型的原因：${result.ai_unavailable.message}`
                    : '未使用模型：本次运行处于降级模式。'}
                </p>
                <p className="mt-1">
                  下方四层中的每一条都取自结果包，界面不会把它标注为 AI 生成内容；引用时请写明「由统计引擎生成」。
                </p>
              </Alert>
            ) : (
              <Alert tone="info" title="本次结果由模型生成，数字全部来自结果包">
                <p>{result.notice}</p>
              </Alert>
            )}

            {result.truncated && (
              <Alert tone="warning" title="模型输出被截断">
                模型回复达到输出长度上限（finish_reason = length），只返回了已完成的部分陈述。
                这里的结论是完整的句子，但不覆盖全部分析内容；提高服务端的输出上限后重新生成可获得完整结果。
              </Alert>
            )}

            <Card>
              <CardHeader
                title="本次解释的元数据"
                description="用于审计与复现：提示词哈希对应提示词版本，任何一次生成都可以据此追溯。"
              />
              <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">生成时间</dt>
                  <dd className="mt-1 text-sm text-ink-800">{formatDateTime(result.generated_at)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">统计引擎版本</dt>
                  <dd className="mt-1 font-mono text-sm text-ink-800">{result.engine_version}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">结果包生成时间</dt>
                  <dd className="mt-1 text-sm text-ink-800">{formatDateTime(result.bundle_generated_at)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">事实来源</dt>
                  <dd className="mt-1 font-mono text-sm text-ink-800">{result.source_of_truth}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">模型</dt>
                  <dd className="mt-1 font-mono text-sm text-ink-800">{result.model}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">提示词版本 / 哈希</dt>
                  <dd className="mt-1 break-all font-mono text-xs text-ink-700">
                    {`${result.prompt_version} / ${result.prompt_hash ?? '未发送提示词（未配置模型）'}`}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">Token 用量</dt>
                  <dd className="mt-1 tabular-nums text-sm text-ink-800">
                    {result.usage
                      ? `提示 ${formatNumber(result.usage.prompt_tokens)} · 输出 ${formatNumber(result.usage.completion_tokens)} · 合计 ${formatNumber(result.usage.total_tokens)}`
                      : '未使用模型，无用量记录'}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs uppercase tracking-wide text-ink-500">解释范围</dt>
                  <dd className="mt-1 text-sm text-ink-800">
                    {`板块：${
                      result.scope.section
                        ? AI_SECTION_LABELS_ZH[result.scope.section as keyof typeof AI_SECTION_LABELS_ZH] ??
                          result.scope.section
                        : '全部'
                    }；假设：${result.scope.hypothesis_code ?? '不限'}${
                      result.scope.focus ? `；关注点：${result.scope.focus}` : ''
                    }`}
                  </dd>
                </div>
              </dl>

              {result.warnings.length > 0 && (
                <div className="mt-4">
                  <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-amber-700">校验警告</p>
                  <ul className="list-disc space-y-1 pl-4 text-xs leading-relaxed text-amber-800">
                    {result.warnings.map((warning, index) => (
                      <li key={`${index}-${warning.slice(0, 24)}`}>{warning}</li>
                    ))}
                  </ul>
                </div>
              )}
            </Card>

            <RejectedClaims claims={result.rejected_claims} />

            {LEVEL_META.map((meta) => (
              <LevelGroup key={meta.level} meta={meta} statements={result.layers[meta.key]} />
            ))}

            {result.caveats.length > 0 && (
              <MethodNote title="结果包解读前提（原文，任何引用都必须同时引用这些限制）">
                <ol className="list-decimal space-y-1 pl-5">
                  {result.caveats.map((caveat, index) => (
                    <li key={`${index}-${caveat.slice(0, 24)}`}>{caveat}</li>
                  ))}
                </ol>
              </MethodNote>
            )}

            {degraded && result.engine_summary && (
              <details className="rounded-md border border-ink-200 bg-white px-3.5 py-3">
                <summary className="cursor-pointer text-sm font-medium text-ink-800">
                  {`引擎摘要的原始分节（${result.engine_summary.sections.length} 节，由统计引擎生成）`}
                </summary>
                <p className="mt-2 text-xs text-ink-500">
                  与上方四层是同一批陈述，只是按引擎摘要的章节重新分组，便于与结果包对照。
                </p>
                <div className="mt-2 space-y-3">
                  {result.engine_summary.sections.map((sectionItem) => (
                    <div key={sectionItem.title}>
                      <p className="text-xs font-semibold text-ink-700">{sectionItem.title}</p>
                      <ul className="mt-1 list-disc space-y-1 pl-4 text-xs leading-relaxed text-ink-600">
                        {sectionItem.lines.map((line, index) => (
                          <li key={`${index}-${line.slice(0, 24)}`}>{line}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </details>
            )}
          </>
        )}

        <Card>
          <CardHeader
            title="AI 解释历史"
            description="每一次尝试都会留痕，包括失败与降级运行，因此报告中每一句话都能追到当时的提示词与校验结果。"
          />

          {historyError && <ErrorNotice message={historyError} />}

          {!historyError && history.length === 0 ? (
            <p className="text-sm text-ink-500">该项目还没有任何 AI 解释记录。</p>
          ) : (
            !historyError && (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[820px] text-sm">
                  <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-3 py-2 text-left">生成时间</th>
                      <th className="px-3 py-2 text-left">模式</th>
                      <th className="px-3 py-2 text-left">模型</th>
                      <th className="px-3 py-2 text-left">引擎版本</th>
                      <th className="px-3 py-2 text-right">陈述数</th>
                      <th className="px-3 py-2 text-right">剔除数</th>
                      <th className="px-3 py-2 text-left">异常</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {history.map((item) => (
                      <tr key={item.id}>
                        <td className="px-3 py-2 text-ink-800">{formatDateTime(item.created_at)}</td>
                        <td className="px-3 py-2">
                          <Badge tone={item.mode === 'live' ? 'info' : 'warning'}>
                            {item.mode === 'live' ? 'live' : 'degraded'}
                          </Badge>
                        </td>
                        <td className="px-3 py-2 font-mono text-xs text-ink-700">{item.model}</td>
                        <td className="px-3 py-2 font-mono text-xs text-ink-700">{item.engine_version}</td>
                        <td className="px-3 py-2 text-right tabular-nums text-ink-800">{item.statement_count}</td>
                        <td
                          className={`px-3 py-2 text-right tabular-nums ${
                            item.rejected_claim_count > 0 ? 'text-red-700' : 'text-ink-800'
                          }`}
                        >
                          {item.rejected_claim_count}
                        </td>
                        <td className="px-3 py-2 text-xs text-ink-600">{item.error_code ?? '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          )}
        </Card>
      </div>
    </AnalysisProjectGate>
  );
}
