/**
 * Research hypothesis testing (PHASE 5, spec §29).
 *
 * The default V4.0 instrument ships eight a-priori hypotheses (H1–H8). This
 * module tests each one against the collected data and returns one of three
 * verdicts — and the three-valued outcome is the point:
 *
 *   - **supported**     — significant, and in the hypothesised direction
 *   - **not_supported** — significant, but in the OPPOSITE direction
 *   - **inconclusive**  — not significant
 *
 * Collapsing "not supported" and "no evidence" into one label is the most common
 * way a null result gets misreported, so they are kept distinct here and the
 * wording is chosen to avoid implying that absence of evidence is evidence of
 * absence.
 */

import { roundTo } from './special.js';
import { classifyCorrelation, correlatePair, type CorrelationPair, type EffectMagnitude } from './association.js';
import type { Dataset } from './dataset.js';

/* ------------------------------------------------------------------ */
/* Types                                                              */
/* ------------------------------------------------------------------ */

export type HypothesisVerdict = 'supported' | 'not_supported' | 'inconclusive' | 'untestable';

export type HypothesisDirection = 'positive' | 'negative' | 'difference';

export interface HypothesisDefinition {
  code: string;
  statement: string;
  /** What is being related to what. */
  independent: string;
  dependent: string;
  /** Expected direction of the association. */
  expected: HypothesisDirection;
  /** Why these variables test this hypothesis — shown in the UI and report. */
  rationale: string;
  /** Alternative variable names accepted if the primary is absent. */
  fallback_independent?: string[];
  fallback_dependent?: string[];
}

export interface HypothesisTestResult {
  code: string;
  statement: string;
  verdict: HypothesisVerdict;
  /** Plain-language conclusion, phrased to avoid overclaiming. */
  conclusion: string;
  direction: HypothesisDirection;
  method: string;
  independent: string;
  dependent: string;
  independent_label: string;
  dependent_label: string;
  r: number | null;
  p_value: number | null;
  n: number;
  ci_lower: number | null;
  ci_upper: number | null;
  effect_size: EffectMagnitude | null;
  /** Observed direction, when it can be determined. */
  observed_direction: 'positive' | 'negative' | null;
  /** Evidence strings so the AI layer can cite the numbers it uses. */
  evidence: string[];
  caveats: string[];
}

export interface HypothesisReport {
  results: HypothesisTestResult[];
  summary: {
    total: number;
    supported: number;
    not_supported: number;
    inconclusive: number;
    untestable: number;
  };
  note: string;
  /** Variables the instrument defines but which had too little data to use. */
  unavailable_variables: string[];
}

/* ------------------------------------------------------------------ */
/* Default hypotheses (V4.0)                                          */
/* ------------------------------------------------------------------ */

/**
 * The eight a-priori hypotheses.
 *
 * Variable choices and their rationale are explicit so that a reader can judge
 * whether the operationalisation matches the verbal statement — the usual place
 * where hypothesis tests quietly go wrong.
 */
export const DEFAULT_HYPOTHESES: HypothesisDefinition[] = [
  {
    code: 'H1',
    statement: '家庭教育知识水平与家庭教育自我效能呈正向关系。',
    independent: 'FEK',
    dependent: 'FSE',
    expected: 'positive',
    rationale:
      'FEK 为家长对自身家庭教育知识水平的主观评分（Q9），FSE 为九题自我效能均值（Q22—Q30）。' +
      'H1 检验"知识越充分，教育信心越强"这一预期。注意 FEK 是主观自评，不能等同于客观知识（LKA）。',
  },
  {
    code: 'H2',
    statement: '家庭教育自我效能与科学家庭教育实践呈正向关系。',
    independent: 'FSE',
    dependent: 'FPB',
    expected: 'positive',
    rationale:
      'FSE 为自我效能（Q22—Q30），FPB 为科学实践频率均值（Q31、Q33、Q34）。' +
      '按社会认知理论，效能感通常预测行为投入；但横截面数据无法区分"效能促进行为"与"行为增强效能"。',
  },
  {
    code: 'H3',
    statement: '家庭教育困难程度越高，专业家庭教育服务需求越强。',
    independent: 'FED',
    dependent: 'DSD',
    expected: 'positive',
    rationale:
      'FED 为七个方面困难程度均值（Q35），DSD 为六类数字化服务需求均值（Q49）。' +
      '需要说明：这里用数字化服务需求代表"专业服务需求"，若研究设计另有界定应替换变量。',
  },
  {
    code: 'H4',
    statement: '政府家庭教育公共服务可及性越高，公共服务使用意愿越高。',
    independent: 'PSA',
    dependent: 'PSUI',
    expected: 'positive',
    fallback_dependent: ['PSU'],
    rationale:
      'PSA 为知晓清晰度与获取便利性均值（Q43、Q44），PSUI 为未来使用意愿（Q47）。' +
      '若问卷未包含 PSUI，则回退使用 PSU（使用与评价综合指标），并在结论中说明口径变化。',
  },
  {
    code: 'H5',
    statement: '专业服务信任度越高，数字化家庭教育服务使用意愿越强。',
    independent: 'STI',
    dependent: 'DSD',
    expected: 'positive',
    rationale:
      'STI 为六类服务主体信任度均值（Q48），DSD 为数字化服务需求均值（Q49）。' +
      'STI 中第 6 行为对 AI 智能助手的信任度；此处使用整体均值，若需专门检验 AI 信任应单独分析该行变量（STI6）。',
  },
  {
    code: 'H6',
    statement: 'AI服务感知价值越高，AI使用意愿越强。',
    independent: 'AIPV',
    dependent: 'UI',
    expected: 'positive',
    rationale:
      'AIPV 为 AI 有效性的感知价值（Q52），UI 为 AI 辅助服务使用意愿（Q50）。' +
      '这属于技术接受模型中的"感知有用性 → 使用意愿"路径。',
  },
  {
    code: 'H7',
    statement: '隐私和专业性担忧越高，AI使用意愿越低。',
    independent: 'PRC',
    dependent: 'UI',
    expected: 'negative',
    rationale:
      'PRC 为五类 AI 风险认知均值（Q51），UI 为 AI 使用意愿（Q50）。' +
      '预期为负向关系；若结果为正，应检查是否因风险认知高的家长同时更关注教育质量。',
  },
  {
    code: 'H8',
    statement: '家庭教育服务需求越高，付费意愿越高。',
    independent: 'DSD',
    dependent: 'WTP',
    expected: 'positive',
    rationale:
      'DSD 为数字化服务需求均值（Q49），WTP 为付费意愿（Q53，有序 1—5）。' +
      '注意 WTP 为有序分类变量，此处用等级相关（Spearman）检验其与需求强度的单调关系，未使用有序回归。',
  },
];

/* ------------------------------------------------------------------ */
/* Testing                                                            */
/* ------------------------------------------------------------------ */

function resolveVariable(
  dataset: Dataset,
  primary: string,
  fallbacks: string[] | undefined,
): { name: string; usedFallback: boolean } | null {
  const candidates = [primary, ...(fallbacks ?? [])];
  for (const candidate of candidates) {
    const variable = dataset.by_name.get(candidate);
    if (!variable) continue;
    const present = variable.values.filter((value) => value !== null);
    if (present.length >= 4 && new Set(present).size > 1) {
      return { name: candidate, usedFallback: candidate !== primary };
    }
  }
  return null;
}

function interpretVerdict(
  verdict: HypothesisVerdict,
  definition: HypothesisDefinition,
  pair: CorrelationPair,
  observedDirection: 'positive' | 'negative' | null,
): string {
  const directionWord = definition.expected === 'positive' ? '正向' : '负向';
  const rText = pair.r === null ? 'NA' : roundTo(pair.r, 3);
  const pText =
    pair.p_value === null ? 'NA' : pair.p_value < 0.001 ? '< .001' : roundTo(pair.p_value, 3);

  switch (verdict) {
    case 'supported':
      return (
        `数据支持该假设：${definition.independent} 与 ${definition.dependent} 呈显著的${directionWord}关系` +
        `（r = ${rText}, p = ${pText}, n = ${pair.n}）。` +
        '需要强调：显著相关只表明两者在样本中同向变动，不能据此认为前者导致了后者。'
      );
    case 'not_supported':
      return (
        `数据不支持该假设的方向：预期为${directionWord}关系，但实际观察到${
          observedDirection === 'positive' ? '正向' : '负向'
        }且统计显著的关系（r = ${rText}, p = ${pText}, n = ${pair.n}）。` +
        '这属于与假设方向相反的发现，应如实报告并探讨可能的原因，而不是改写假设。'
      );
    case 'inconclusive':
      return (
        `证据不足，无法判断：${definition.independent} 与 ${definition.dependent} 的关系未达到统计显著` +
        `（r = ${rText}, p = ${pText}, n = ${pair.n}）。` +
        '这表示当前样本未能提供支持该假设的证据，但**不等于证明两者无关**——可能受样本量、测量误差或取值范围限制影响。'
      );
    case 'untestable':
    default:
      return (
        '该假设在当前数据下无法检验：所需变量缺失，或有效样本量/变异不足。' +
        '请确认问卷是否包含相应题目、是否已收集足够样本。'
      );
  }
}

export function testHypothesis(
  dataset: Dataset,
  definition: HypothesisDefinition,
  options: { alpha?: number } = {},
): HypothesisTestResult {
  const alpha = options.alpha ?? 0.05;
  const independent = resolveVariable(dataset, definition.independent, definition.fallback_independent);
  const dependent = resolveVariable(dataset, definition.dependent, definition.fallback_dependent);

  if (!independent || !dependent) {
    const missing: string[] = [];
    if (!independent) missing.push(definition.independent);
    if (!dependent) missing.push(definition.dependent);
    return {
      code: definition.code,
      statement: definition.statement,
      verdict: 'untestable',
      conclusion:
        `无法检验：变量 ${missing.join('、')} 在数据集中缺失，或有效样本量与变异不足（至少需要 4 例且有变异）。`,
      direction: definition.expected,
      method: '未执行',
      independent: definition.independent,
      dependent: definition.dependent,
      independent_label: definition.independent,
      dependent_label: definition.dependent,
      r: null,
      p_value: null,
      n: 0,
      ci_lower: null,
      ci_upper: null,
      effect_size: null,
      observed_direction: null,
      evidence: [`缺失变量：${missing.join('、')}`],
      caveats: ['请确认问卷包含相应题目且已收集足够样本。'],
    };
  }

  const pair = correlatePair(dataset, independent.name, dependent.name);
  const caveats: string[] = [definition.rationale];

  if (independent.usedFallback) {
    caveats.push(
      `假设原本指定 ${definition.independent}，但该变量不可用，已改用 ${independent.name} 进行检验，解读时请注意口径变化。`,
    );
  }
  if (dependent.usedFallback) {
    caveats.push(
      `假设原本指定 ${definition.dependent}，但该变量不可用，已改用 ${dependent.name} 进行检验，解读时请注意口径变化。`,
    );
  }
  if (pair.method === 'spearman') {
    caveats.push(
      '因变量或自变量为有序分类变量，采用 Spearman 等级相关，其解释为单调关联强度而非线性关联。',
    );
  }
  if (pair.n < 30) {
    caveats.push(`有效样本 n = ${pair.n} 偏小，检验效力有限，不显著结果难以区分"无关系"与"样本不足"。`);
  }
  if (pair.ci_lower !== null && pair.ci_upper !== null) {
    caveats.push(
      `r 的 95% 置信区间为 [${pair.ci_lower}, ${pair.ci_upper}]，解读时应参考区间宽度而非仅看点估计。`,
    );
  }

  const evidence = [
    `变量：${independent.name}（${pair.left}）× ${dependent.name}（${pair.right}）`,
    `统计方法：${pair.method === 'pearson' ? 'Pearson 积矩相关' : 'Spearman 等级相关'}`,
    `r = ${pair.r ?? 'NA'}`,
    `p = ${pair.p_value ?? 'NA'}`,
    `n = ${pair.n}`,
    pair.ci_lower !== null ? `95% CI = [${pair.ci_lower}, ${pair.ci_upper}]` : '未报告置信区间',
    pair.effective_size ? `效应量：${pair.effective_size.text}（${pair.effective_size.convention}）` : '',
  ].filter((line) => line !== '');

  if (pair.r === null || pair.p_value === null) {
    return {
      code: definition.code,
      statement: definition.statement,
      verdict: 'untestable',
      conclusion: `无法检验：${pair.note}`,
      direction: definition.expected,
      method: pair.method === 'pearson' ? 'Pearson 相关' : 'Spearman 相关',
      independent: independent.name,
      dependent: dependent.name,
      independent_label: dataset.by_name.get(independent.name)?.label ?? independent.name,
      dependent_label: dataset.by_name.get(dependent.name)?.label ?? dependent.name,
      r: null,
      p_value: null,
      n: pair.n,
      ci_lower: null,
      ci_upper: null,
      effect_size: null,
      observed_direction: null,
      evidence,
      caveats: [...caveats, pair.note],
    };
  }

  const observedDirection: 'positive' | 'negative' = pair.r >= 0 ? 'positive' : 'negative';
  const significant = pair.p_value < alpha;

  const verdict: HypothesisVerdict = !significant
    ? 'inconclusive'
    : observedDirection === definition.expected
      ? 'supported'
      : 'not_supported';

  return {
    code: definition.code,
    statement: definition.statement,
    verdict,
    conclusion: interpretVerdict(verdict, definition, pair, observedDirection),
    direction: definition.expected,
    method: pair.method === 'pearson' ? 'Pearson 积矩相关' : 'Spearman 等级相关',
    independent: independent.name,
    dependent: dependent.name,
    independent_label: dataset.by_name.get(independent.name)?.label ?? independent.name,
    dependent_label: dataset.by_name.get(dependent.name)?.label ?? dependent.name,
    r: pair.r,
    p_value: pair.p_value,
    n: pair.n,
    ci_lower: pair.ci_lower,
    ci_upper: pair.ci_upper,
    effect_size: pair.effective_size,
    observed_direction: observedDirection,
    evidence,
    caveats,
  };
}

/** Run every hypothesis and summarise the outcome. */
export function testAllHypotheses(
  dataset: Dataset,
  hypotheses: HypothesisDefinition[] = DEFAULT_HYPOTHESES,
  options: { alpha?: number } = {},
): HypothesisReport {
  const results = hypotheses.map((definition) => testHypothesis(dataset, definition, options));

  const summary = {
    total: results.length,
    supported: results.filter((result) => result.verdict === 'supported').length,
    not_supported: results.filter((result) => result.verdict === 'not_supported').length,
    inconclusive: results.filter((result) => result.verdict === 'inconclusive').length,
    untestable: results.filter((result) => result.verdict === 'untestable').length,
  };

  const unavailable = [...new Set(results.flatMap((result) => result.evidence.filter((line) => line.startsWith('缺失变量'))))];

  return {
    results,
    summary,
    unavailable_variables: unavailable,
    note:
      `假设检验采用双侧检验，显著性水平 α = ${options.alpha ?? 0.05}。` +
      `共检验 ${summary.total} 条假设：支持 ${summary.supported} 条、方向相反 ${summary.not_supported} 条、` +
      `证据不足 ${summary.inconclusive} 条、无法检验 ${summary.untestable} 条。` +
      '判定规则：p < α 且方向与假设一致记为「支持」；p < α 但方向与假设相反记为「不支持」（这是与假设相反的发现，不应改写假设）；' +
      'p ≥ α 记为「证据不足」，不等同于证明假设不成立。' +
      '所有检验均基于横截面数据，相关关系不能推断因果关系；且未对多重比较进行校正，' +
      '在 8 条假设同时检验时，出现至少一次假阳性的概率约为 ' +
      `${roundTo((1 - (1 - (options.alpha ?? 0.05)) ** summary.total) * 100, 1)}%，解读时请予考虑。`,
  };
}

export { classifyCorrelation };
