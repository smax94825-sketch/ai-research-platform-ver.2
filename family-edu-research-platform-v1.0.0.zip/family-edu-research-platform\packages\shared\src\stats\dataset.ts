/**
 * Dataset construction (PHASE 5).
 *
 * Turns stored questionnaire responses into the numeric variables the
 * statistical engine operates on. This is the module where research-integrity
 * decisions are actually made, so they are made explicitly:
 *
 *  - **Missing is never zero.** An unanswered item yields `null`, and every
 *    analysis reports the exact n it used.
 *  - **Sensitive refusal is missing, not a category.** A respondent who chose
 *    "不愿回答" is excluded from that variable's statistics rather than counted
 *    as "never".
 *  - **Listwise deletion is reported.** `completeCases` returns how many cases
 *    were dropped and why, because silently dropping half the sample is the
 *    classic way a result becomes unreproducible.
 *  - **Matrix rows become first-class variables** (`FED1`…`FED7`) alongside the
 *    dimension composite (`FED`), matching the exported codebook exactly.
 */

import type { Question } from '../types.js';
import { matrixRowScores, scoreQuestionAnswer, MISSING, SENSITIVE_NONRESPONSE } from '../scoring.js';
import { isQuestionVisible, sortQuestions } from '../logic.js';
import type { AnswerMap, AnswerValue } from '../values.js';
import { FAMILY_EDU_V4_COMPOSITES, FAMILY_EDU_V4_SCALES } from '../template/familyEduV4.js';
import type { CompositeSpec, ScaleDefinition } from '../template/familyEduV4.js';

/* ------------------------------------------------------------------ */
/* Types                                                              */
/* ------------------------------------------------------------------ */

export type MeasurementLevel = 'nominal' | 'ordinal' | 'interval' | 'ratio' | 'count' | 'text';

export interface DatasetVariable {
  /** Variable name as it appears in the codebook (e.g. "FED3", "FSE"). */
  name: string;
  label: string;
  dimension: string;
  question_code: string;
  data_type: MeasurementLevel;
  /** Numeric values aligned to `Dataset.respondentIds`; null means missing. */
  values: (number | null)[];
  /** Original answers, for categorical reporting and answer labelling. */
  raw: AnswerValue[];
  /** Option code → option label, for categorical variables. */
  value_labels: Record<string, string>;
  is_derived: boolean;
  /** Source question codes, for composite variables. */
  sources: string[];
}

export interface DatasetRow {
  respondent_id: string;
  answers: AnswerMap;
}

export interface Dataset {
  respondent_ids: string[];
  variables: DatasetVariable[];
  by_name: Map<string, DatasetVariable>;
  scales: ScaleDefinition[];
  n_respondents: number;
  /** Variables the questionnaire defines but for which nothing was collected. */
  empty_variables: string[];
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

function levelOf(question: Question, fallback: MeasurementLevel = 'ordinal'): MeasurementLevel {
  const rule = question.scoring_rule;
  if (rule?.type === 'categorical') return 'nominal';
  if (rule?.type === 'ordinal') return 'ordinal';
  if (rule?.type === 'count') return 'count';
  if (question.question_type === 'matrix') return 'interval';
  if (question.question_type === 'knowledge_test') return 'interval';
  if (question.question_type === 'multiple') return 'count';
  if (question.question_type === 'number') return 'ratio';
  if (question.question_type === 'text' || question.question_type === 'textarea') return 'text';
  if (question.question_type === 'ranking') return 'ordinal';
  if (rule?.type === 'mean' || rule?.type === 'sum') return 'interval';
  return fallback;
}

function valueLabelsOf(question: Question): Record<string, string> {
  const labels: Record<string, string> = {};
  for (const choice of question.options.choices ?? []) {
    labels[String(choice.value)] = choice.label;
  }
  return labels;
}

/** Numeric value for one item, mapping both missing kinds to null. */
function numericOrNull(question: Question, answer: AnswerValue): number | null {
  if (answer === undefined || answer === null) return null;
  const scored = scoreQuestionAnswer(question, answer);
  if (scored === MISSING || scored === SENSITIVE_NONRESPONSE) return null;
  return Number.isFinite(scored) ? scored : null;
}

/* ------------------------------------------------------------------ */
/* Building                                                           */
/* ------------------------------------------------------------------ */

export interface BuildDatasetOptions {
  /** Composite specifications; defaults to the V4.0 template set. */
  composites?: CompositeSpec[];
  /** Scale definitions for reliability/EFA; defaults to the V4.0 template set. */
  scales?: ScaleDefinition[];
}

/**
 * Build the analysis dataset.
 *
 * Only questions actually administered (visible) for a respondent contribute a
 * value; a question skipped by the questionnaire's logic is missing for that
 * respondent, which is the correct representation of "never asked".
 */
export function buildDataset(
  questions: Question[],
  rows: DatasetRow[],
  options: BuildDatasetOptions = {},
): Dataset {
  const ordered = sortQuestions(questions).filter((question) => question.question_type !== 'page_break');
  const respondentIds = rows.map((row) => row.respondent_id);
  const variables: DatasetVariable[] = [];

  for (const question of ordered) {
    const administered = rows.map((row) => isQuestionVisible(question, row.answers));
    const raw = rows.map((row, index) =>
      administered[index] ? (row.answers[question.question_code] as AnswerValue) : undefined,
    );
    const labels = valueLabelsOf(question);

    if (question.question_type === 'matrix') {
      // One variable per row, plus the dimension composite below.
      const prefix = question.variable_name ?? question.question_code;
      for (const matrixRow of question.options.matrix?.rows ?? []) {
        const name = `${prefix}${matrixRow.value}`;
        variables.push({
          name,
          label: `${question.question_text} — ${matrixRow.label}`,
          dimension: question.dimension ?? '未分类',
          question_code: question.question_code,
          data_type: 'ordinal',
          values: rows.map((row, index) => {
            if (!administered[index]) return null;
            const scores = matrixRowScores(question, raw[index]);
            const value = scores[matrixRow.value];
            return value === undefined || value === null ? null : value;
          }),
          raw: raw.map((answer) => {
            if (!answer || typeof answer !== 'object' || Array.isArray(answer)) return undefined;
            return (answer as Record<string, string>)[matrixRow.value];
          }),
          value_labels: labels,
          is_derived: false,
          sources: [question.question_code],
        });
      }

      const compositeName = prefix;
      variables.push({
        name: compositeName,
        label: question.question_text,
        dimension: question.dimension ?? '未分类',
        question_code: question.question_code,
        data_type: 'interval',
        values: rows.map((row, index) =>
          administered[index] ? numericOrNull(question, raw[index]) : null,
        ),
        raw: raw.map((answer) => answer ?? null),
        value_labels: labels,
        is_derived: true,
        sources: [question.question_code],
      });
      continue;
    }

    // Text variables carry no numeric column but are still tracked.
    const isText = question.question_type === 'text' || question.question_type === 'textarea';

    variables.push({
      name: question.variable_name ?? question.question_code,
      label: question.question_text,
      dimension: question.dimension ?? '未分类',
      question_code: question.question_code,
      data_type: levelOf(question),
      values: isText
        ? rows.map(() => null)
        : rows.map((row, index) => (administered[index] ? numericOrNull(question, raw[index]) : null)),
      raw: raw.map((answer) => answer ?? null),
      value_labels: labels,
      is_derived: false,
      sources: [question.question_code],
    });
  }

  /* ---------------------------------------------------------------- */
  /* Composite variables                                               */
  /* ---------------------------------------------------------------- */

  const composites = options.composites ?? FAMILY_EDU_V4_COMPOSITES;
  const byName = new Map(variables.map((variable) => [variable.name, variable]));
  const questionByCode = new Map(ordered.map((question) => [question.question_code, question]));

  /** Expand a question code into the variable names it contributes. */
  const itemNamesFor = (code: string): string[] => {
    const question = questionByCode.get(code);
    if (!question) return [];
    if (question.question_type === 'matrix') {
      const prefix = question.variable_name ?? question.question_code;
      return (question.options.matrix?.rows ?? []).map((row) => `${prefix}${row.value}`);
    }
    return [question.variable_name ?? question.question_code];
  };

  for (const spec of composites) {
    // Skip composites whose items are not part of this questionnaire.
    const itemNames: string[] = [];
    for (const source of spec.sources) {
      const names = itemNamesFor(source);
      if (names.length === 0) continue;
      for (const name of names) if (byName.has(name)) itemNames.push(name);
    }
    if (itemNames.length === 0) continue;
    if (byName.has(spec.variable_name)) continue;

    const values = respondentIds.map((_, index) => {
      const present = itemNames
        .map((name) => byName.get(name)!.values[index])
        .filter((value): value is number => value !== null && value !== undefined);
      if (present.length === 0) return null;

      switch (spec.aggregation) {
        case 'sum':
          return present.reduce((sum, value) => sum + value, 0);
        case 'count':
          return present.length;
        case 'index':
        case 'mean':
        default:
          return present.reduce((sum, value) => sum + value, 0) / present.length;
      }
    });

    variables.push({
      name: spec.variable_name,
      label: spec.label,
      dimension: spec.dimension,
      question_code: spec.sources.join('、'),
      data_type: spec.data_type === 'count' ? 'count' : spec.data_type === 'ordinal' ? 'ordinal' : 'interval',
      values,
      raw: values.map((value) => value),
      value_labels: {},
      is_derived: true,
      sources: itemNames,
    });
  }

  const finalByName = new Map(variables.map((variable) => [variable.name, variable]));

  return {
    respondent_ids: respondentIds,
    variables,
    by_name: finalByName,
    scales: options.scales ?? FAMILY_EDU_V4_SCALES,
    n_respondents: respondentIds.length,
    empty_variables: variables
      .filter((variable) => variable.values.every((value) => value === null))
      .map((variable) => variable.name),
  };
}

/* ------------------------------------------------------------------ */
/* Case selection                                                     */
/* ------------------------------------------------------------------ */

export interface CompleteCaseSelection {
  /** Column-major numeric data for the retained cases, one array per variable. */
  columns: number[][];
  /** Respondent ids retained, in the same order as the data. */
  respondent_ids: string[];
  /** Variables actually used. */
  variable_names: string[];
  n: number;
  /** Cases dropped because at least one required variable was missing. */
  dropped: number;
  /** How many cases were missing each variable, for honest reporting. */
  missing_per_variable: Record<string, number>;
  /** Human-readable note suitable for a methods section. */
  note: string;
}

/**
 * Select cases with no missing values on the requested variables (listwise).
 *
 * Listwise deletion is the honest default for a first pass, but it must be
 * *visible*: the returned `note` and `missing_per_variable` are meant to be
 * surfaced in the UI and the report, so a reader can see that an analysis ran
 * on 412 of 527 cases rather than on the full sample.
 */
export function completeCases(
  dataset: Dataset,
  variableNames: string[],
): CompleteCaseSelection {
  const variables = variableNames
    .map((name) => dataset.by_name.get(name))
    .filter((variable): variable is DatasetVariable => variable !== undefined);

  const usedNames = variables.map((variable) => variable.name);
  const missingPerVariable: Record<string, number> = {};
  for (const variable of variables) {
    missingPerVariable[variable.name] = variable.values.filter((value) => value === null).length;
  }

  const retained: number[] = [];
  for (let index = 0; index < dataset.n_respondents; index += 1) {
    const complete = variables.every((variable) => {
      const value = variable.values[index];
      return value !== null && value !== undefined && Number.isFinite(value);
    });
    if (complete) retained.push(index);
  }

  const columns = variables.map((variable) =>
    retained.map((index) => variable.values[index] as number),
  );

  const dropped = dataset.n_respondents - retained.length;
  const note =
    `基于变量 ${usedNames.join('、')} 进行整例删除（listwise），` +
    `有效样本 n = ${retained.length}${dropped > 0 ? `，因存在缺失值剔除 ${dropped} 例` : ''}。` +
    `缺失不进行插补。`;

  return {
    columns,
    respondent_ids: retained.map((index) => dataset.respondent_ids[index]!),
    variable_names: usedNames,
    n: retained.length,
    dropped,
    missing_per_variable: missingPerVariable,
    note,
  };
}

/** Extract a single variable's values aligned to all respondents. */
export function variableValues(dataset: Dataset, name: string): (number | null)[] {
  return dataset.by_name.get(name)?.values ?? [];
}

/** Extract a variable's raw answers (for categorical tables). */
export function variableRaw(dataset: Dataset, name: string): AnswerValue[] {
  return dataset.by_name.get(name)?.raw ?? [];
}

/** A variable with too few distinct values cannot support correlation or EFA. */
function lacksVariance(variable: DatasetVariable): boolean {
  const present = variable.values.filter((value): value is number => value !== null);
  if (present.length < 2) return true;
  return new Set(present).size < 2;
}

/**
 * Variables eligible for Pearson-based methods: interval/ratio with variance.
 * Ordinal variables are excluded here and routed to Spearman instead, so the
 * engine's automatic method selection is grounded in measurement level rather
 * than convenience.
 */
export function continuousVariables(dataset: Dataset): DatasetVariable[] {
  return dataset.variables.filter(
    (variable) =>
      (variable.data_type === 'interval' || variable.data_type === 'ratio') &&
      !lacksVariance(variable),
  );
}

/** Ordinal scale variables, used by non-parametric procedures. */
export function ordinalVariables(dataset: Dataset): DatasetVariable[] {
  return dataset.variables.filter(
    (variable) => variable.data_type === 'ordinal' && !lacksVariance(variable),
  );
}

/** Variables that are safe to treat as categorical outcomes/predictors. */
export function categoricalVariables(dataset: Dataset): DatasetVariable[] {
  return dataset.variables.filter(
    (variable) =>
      (variable.data_type === 'nominal' || variable.data_type === 'ordinal') &&
      Object.keys(variable.value_labels).length > 0 &&
      !lacksVariance(variable),
  );
}
