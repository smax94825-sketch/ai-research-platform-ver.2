/**
 * Hypothesis testing (PHASE 6).
 *
 * The three-valued verdict is the whole point of this page, so the layout
 * refuses to flatten it: 支持 (significant, hypothesised direction),
 * 不支持 (significant, OPPOSITE direction) and 证据不足 (not significant) get
 * three visually distinct treatments, each with its own glyph and wording.
 *
 * The wording matters as much as the colour: 证据不足 is never allowed to read as
 * "there is no relationship". A non-significant test with a small sample is
 * consistent with a real effect that this study could not detect, and the page
 * says so next to every such verdict. The engine's fourth state, 无法检验, is
 * kept as well rather than folded into "not supported".
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import type { HypothesisVerdict } from '@ferp/shared';
import { Alert, Badge, Card, CardHeader, LoadingBlock, StatCard } from '../../components/ui';
import type { BadgeTone } from '../../lib/format';
import {
  api,
  ApiClientError,
  type AnalysisHypothesisResponse,
  type HypothesisTestResult,
} from '../../lib/api';
import { formatNumber, formatPValue, formatStat, significanceMark } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from './shared';

interface VerdictMeta {
  label: string;
  tone: BadgeTone;
  glyph: string;
  /** Border/background of the verdict banner — a distinct shape, not just a hue. */
  frame: string;
  meaning: string;
}

const VERDICT_META: Record<HypothesisVerdict, VerdictMeta> = {
  supported: {
    label: '支持',
    tone: 'success',
    glyph: '✓',
    frame: 'border-emerald-300 bg-emerald-50',
    meaning: '检验结果显著，且方向与假设一致。',
  },
  not_supported: {
    label: '不支持',
    tone: 'danger',
    glyph: '✕',
    frame: 'border-red-300 bg-red-50',
    meaning: '检验结果显著，但方向与假设相反——这是与原假设相反的发现，不应改写假设来迁就结果。',
  },
  inconclusive: {
    label: '证据不足',
    tone: 'warning',
    glyph: '?',
    frame: 'border-amber-300 bg-amber-50',
    meaning:
      '本次检验未达到显著水平。「证据不足」只表示当前样本没有提供足够证据支持该假设，' +
      '并不等于证明两个变量之间无关：样本量偏小、测量范围受限或缺失较多时，真实存在的关联也可能检验不出来。',
  },
  untestable: {
    label: '无法检验',
    tone: 'neutral',
    glyph: '—',
    frame: 'border-ink-300 bg-ink-50',
    meaning: '缺少必要变量或有效样本量过低，本次未能进行检验，因此没有任何关于该假设的结论。',
  },
};

function VerdictBanner({ meta }: { meta: VerdictMeta }): ReactNode {
  return (
    <div className={`rounded-md border px-3.5 py-3 ${meta.frame}`}>
      <p className="text-sm font-medium text-ink-900">
        <span aria-hidden="true" className="mr-2 font-mono">
          {meta.glyph}
        </span>
        {`判定：${meta.label}`}
      </p>
      <p className="mt-1 text-xs leading-relaxed text-ink-700">{meta.meaning}</p>
    </div>
  );
}

function HypothesisCard({ result }: { result: HypothesisTestResult }): ReactNode {
  const meta = VERDICT_META[result.verdict] ?? VERDICT_META.untestable;

  return (
    <Card>
      <CardHeader
        title={
          <span className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-sm text-ink-500">{result.code}</span>
            <span>{result.statement}</span>
          </span>
        }
        description={`${result.independent_label}（${result.independent}）× ${result.dependent_label}（${result.dependent}）· 预期方向：${
          result.direction === 'positive' ? '正向' : result.direction === 'negative' ? '负向' : '组间差异'
        }`}
        actions={<Badge tone={meta.tone}>{`${meta.glyph} ${meta.label}`}</Badge>}
      />

      <div className="space-y-4">
        <VerdictBanner meta={meta} />

        <p className="text-sm leading-relaxed text-ink-800">{result.conclusion}</p>

        <dl className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">统计方法</dt>
            <dd className="mt-1 text-sm text-ink-800">{result.method}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">r</dt>
            <dd className="mt-1 tabular-nums text-sm text-ink-900">
              {formatStat(result.r, 3)} {significanceMark(result.p_value)}
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">显著性</dt>
            <dd className="mt-1 tabular-nums text-sm text-ink-800">{formatPValue(result.p_value)}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">有效样本 n</dt>
            <dd className="mt-1 tabular-nums text-sm text-ink-800">{formatNumber(result.n)}</dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">95% CI（r）</dt>
            <dd className="mt-1 tabular-nums text-sm text-ink-800">
              {result.ci_lower === null || result.ci_upper === null
                ? '—'
                : `[${formatStat(result.ci_lower, 3)}, ${formatStat(result.ci_upper, 3)}]`}
            </dd>
          </div>
          <div>
            <dt className="text-xs uppercase tracking-wide text-ink-500">实际观测方向</dt>
            <dd className="mt-1 text-sm text-ink-800">
              {result.observed_direction === null
                ? '—'
                : result.observed_direction === 'positive'
                  ? '正向'
                  : '负向'}
            </dd>
          </div>
        </dl>

        {result.effect_size && (
          <p className="text-xs text-ink-600">
            效应量：{result.effect_size.text}
            {`（${result.effect_size.convention}）`}
          </p>
        )}

        <div className="grid gap-4 lg:grid-cols-2">
          <div>
            <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-500">判定依据</h3>
            <ul className="list-disc space-y-1 pl-4 text-xs leading-relaxed text-ink-600">
              {result.evidence.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-ink-500">注意事项</h3>
            {result.caveats.length === 0 ? (
              <p className="text-xs text-ink-500">本次检验未触发额外限制说明。</p>
            ) : (
              <ul className="list-disc space-y-1 pl-4 text-xs leading-relaxed text-amber-800">
                {result.caveats.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

export function HypothesisPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisHypothesisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setData(await api.analysis.hypotheses(projectId));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载假设检验结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Hypothesis Testing"
          subtitle="假设检验：逐条给出三态判定、统计方法、效应量、判定依据与限制。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在检验研究假设…" />
        ) : !data ? null : data.results.length === 0 ? (
          <Alert tone="warning" title="没有可检验的假设">
            该项目未定义研究假设，或假设所依赖的变量在数据中不存在。
          </Alert>
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard
                label="支持"
                value={data.summary.supported}
                tone="success"
                hint="显著且方向一致"
              />
              <StatCard
                label="不支持"
                value={data.summary.not_supported}
                tone="danger"
                hint="显著但方向相反"
              />
              <StatCard
                label="证据不足"
                value={data.summary.inconclusive}
                tone="warning"
                hint="不显著，不等于证明无关"
              />
              <StatCard
                label="无法检验"
                value={data.summary.untestable}
                tone="neutral"
                hint="缺少变量或样本过少"
              />
            </div>

            <MethodNote>
              <p>{data.note}</p>
              <p>
                引擎版本 {data.engine_version}；共检验 {data.summary.total} 条假设，
                与各条结果中的方法、r、p 与 n 一一对应，可按此复现。
              </p>
            </MethodNote>

            {data.unavailable_variables.length > 0 && (
              <Alert tone="info" title="数据中缺失的变量">
                <ul className="list-disc space-y-1 pl-4">
                  {data.unavailable_variables.map((line) => (
                    <li key={line}>{line}</li>
                  ))}
                </ul>
              </Alert>
            )}

            <Alert tone="warning" title="三态判定应如何使用">
              <p>
                「不支持」表示结果显著但与假设方向相反，是可能推翻原假设的发现，应如实报告而不得改写假设；
                「证据不足」表示本次检验未达显著水平，只说明当前样本证据不够，<strong>不等于证明两者无关</strong>；
                「无法检验」表示连检验条件都不满足，不能据此作出任何关于该假设的结论。
              </p>
              <p className="mt-1">
                同时检验 {data.summary.total} 条假设而未做多重比较校正，至少出现一次假阳性的概率不容忽视；
                所有结论均基于横截面数据，属共变关系，不能推断因果。
              </p>
            </Alert>

            {data.results.map((result) => (
              <HypothesisCard key={result.code} result={result} />
            ))}
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
