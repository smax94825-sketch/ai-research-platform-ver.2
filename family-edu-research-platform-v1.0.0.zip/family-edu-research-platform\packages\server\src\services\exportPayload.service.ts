/**
 * Export payload assembly (PHASE 8).
 *
 * The export routes are deliberately thin: everything that has to agree with
 * the rest of the platform — the analysable sample, the export context, the
 * codebook rows, the analysis workbooks and the SPSS archive — is assembled
 * here so it can be reasoned about (and tested) without HTTP.
 *
 * Two boundaries are respected strictly.
 *
 *  - This module computes **no statistics**. The workbook's analysis sheets are
 *    projections of the persisted `AnalysisBundle`; a bundle section that is
 *    absent or unusable produces an explicit Chinese note in its sheet instead
 *    of an empty table, which could otherwise be read as "no effect".
 *  - This module decides **no missing value**. Every `null` it copies out of the
 *    bundle or the dataset stays `null`, which the export service turns into an
 *    empty CSV field, an empty Excel cell and a JSON `null`.
 */

import type { ResearchProject } from '@ferp/shared';

import {
  DICTIONARY_HEADERS,
  codebookRows,
  exportFilenames,
  toCsv,
  toJson,
  toSpssBundle,
  type ExportCodebookEntry,
  type ExportContext,
  type ExportSheet,
  type JsonExportPayload,
} from './export.service.js';
import {
  loadAnalysableSample,
  type AnalysisBundle,
  type LoadedSample,
  type SampleSummary,
} from './analysis.service.js';
import { requireProject } from './project.service.js';
import { VERDICT_LABELS } from './report.service.js';
import { nowIso } from '../util/ids.js';
import { createZip } from '../util/zip.js';
import type { Db } from '../db/index.js';

/* ------------------------------------------------------------------ */
/* Context                                                            */
/* ------------------------------------------------------------------ */

export interface ExportPayload {
  project: ResearchProject;
  loaded: LoadedSample;
  context: ExportContext;
  /**
   * The variable dictionary as the export service itself produces it, reused
   * verbatim (including its per-variable valid/missing counts) rather than
   * re-derived here — two implementations of the codebook would eventually
   * disagree, and a reader could not tell which one was right.
   */
  codebook: ExportCodebookEntry[];
}

/**
 * The analysable sample is the export base.
 *
 * Excluded samples stay excluded, and the exclusion is *stated* in the context
 * (`excludedNote`) so a downloaded file can never be mistaken for the full
 * collection. `respondentsTotal` therefore legitimately differs from the number
 * of rows in the file, and both numbers travel in the JSON metadata.
 */
export function buildExportContext(project: ResearchProject, loaded: LoadedSample): ExportContext {
  const { summary, questionnaire } = loaded;
  return {
    projectTitle: project.title,
    questionnaireTitle: questionnaire?.title ?? '（未命名问卷）',
    questionnaireVersion: questionnaire?.version ?? '（无版本）',
    exportedAt: nowIso(),
    respondentsTotal: summary.respondents_total,
    excludedNote:
      summary.excluded > 0
        ? `已排除 ${summary.excluded} 份样本（研究者人工判定不适用，原因见质量与样本审核模块）`
        : null,
    questions: loaded.questions,
  };
}

/** Load everything an export endpoint needs, enforcing project ownership. */
export function loadExportPayload(db: Db, projectId: string, researcherId: string): ExportPayload {
  const project = requireProject(db, projectId, researcherId);
  const loaded = loadAnalysableSample(db, projectId);
  const context = buildExportContext(project, loaded);
  return { project, loaded, context, codebook: codebookOf(loaded, context) };
}

function codebookOf(loaded: LoadedSample, context: ExportContext): ExportCodebookEntry[] {
  const payload = JSON.parse(toJson(loaded.dataset, context)) as JsonExportPayload;
  return payload.codebook;
}

/** The wide-format CSV the dataset endpoint serves (UTF-8 with BOM). */
export function datasetCsv(payload: ExportPayload): string {
  return toCsv(payload.loaded.dataset, payload.context);
}

/** The JSON export of the dataset endpoint. */
export function datasetJson(payload: ExportPayload): string {
  return toJson(payload.loaded.dataset, payload.context);
}

/* ------------------------------------------------------------------ */
/* CSV helpers                                                        */
/* ------------------------------------------------------------------ */

/** UTF-8 byte order mark — what makes Excel open a Chinese CSV correctly. */
export const UTF8_BOM = '\uFEFF';

/**
 * RFC 4180 serialisation.
 *
 * The export service keeps its own serializer private, so the same rules are
 * applied here for the artefacts this module owns (the codebook file): quote
 * only when the field contains a delimiter, a quote or a line break, double the
 * quotes inside, and end lines with LF so the platform never hands a researcher
 * two different newline conventions.
 */
export function csvText(rows: (string | number | null)[][]): string {
  return rows
    .map((row) =>
      row
        .map((cell) => {
          if (cell === null || cell === undefined) return '';
          const text = String(cell);
          return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
        })
        .join(','),
    )
    .join('\n');
}

/**
 * The codebook download: the variable dictionary followed by the option-level
 * codebook, each with its own header row.
 *
 * Both halves are in one file because a researcher decoding a column needs both
 * — which variable is which, and what each numeric code means — and either half
 * alone is unusable. They are separated by a blank line and each carries its own
 * header, so a reader (or a spreadsheet import) can split them without guessing.
 */
export function codebookFileText(payload: ExportPayload): string {
  const rows: (string | number | null)[][] = [];
  rows.push(DICTIONARY_HEADERS.slice());

  for (const definition of payload.codebook) {
    rows.push([
      definition.variable_name,
      definition.question_code,
      definition.question_text,
      definition.dimension,
      definition.data_type,
      definition.coding,
      definition.missing_value,
      definition.scoring_rule,
      definition.analysis_method,
      definition.is_derived ? '是' : '否',
    ]);
  }

  rows.push([]);
  for (const row of codebookRows(payload.loaded.dataset)) rows.push(row);

  return `${UTF8_BOM}${csvText(rows)}\n`;
}

/* ------------------------------------------------------------------ */
/* SPSS archive                                                       */
/* ------------------------------------------------------------------ */

export interface SpssArchive {
  filename: string;
  buffer: Buffer;
  syntaxFilename: string;
  dataFilename: string;
}

/**
 * The two SPSS files as one ZIP archive.
 *
 * A ZIP is used rather than a JSON-with-base64 payload because both files are
 * *inputs to SPSS*: a researcher must be able to unzip them and point the syntax
 * at the CSV without a decoding step. Node ships no ZIP writer, so `createZip`
 * implements the stored-entry subset (see that module) — no new dependency is
 * introduced. Both files are also served by their own endpoints, so neither is
 * reachable only through the archive.
 */
export function buildSpssArchive(payload: ExportPayload): SpssArchive {
  const bundle = toSpssBundle(payload.loaded.dataset, payload.context);
  const filenames = exportFilenames(payload.context);

  return {
    filename: `${filenames.spssSyntax.replace(/\.sps$/, '')}.zip`,
    syntaxFilename: filenames.spssSyntax,
    dataFilename: filenames.spssData,
    buffer: createZip([
      { name: filenames.spssSyntax, content: bundle.syntax },
      { name: filenames.spssData, content: bundle.data },
    ]),
  };
}

/** The `.sps` syntax on its own, and the BOM-free data CSV it reads. */
export function buildSpssFiles(payload: ExportPayload): { syntax: string; data: string } {
  return toSpssBundle(payload.loaded.dataset, payload.context);
}

/* ------------------------------------------------------------------ */
/* Workbook sheets                                                    */
/* ------------------------------------------------------------------ */

/**
 * Sheet headers.
 *
 * These are declared here rather than imported from the export service because
 * that service keeps its placeholder header rows private. The sheet *names*
 * must stay aligned with its `ANALYSIS_SHEETS` constants: a contribution is
 * merged into the sheet of the same name and the contribution's header row
 * replaces the placeholder's, so a name mismatch would append a second table
 * instead of filling in the first.
 */
export const DATA_QUALITY_HEADERS = ['Metric', 'Value', 'Note'];
export const DESCRIPTIVE_HEADERS = [
  'Variable Name',
  'Variable Label',
  'Dimension',
  'N',
  'Missing',
  'Mean',
  'SD',
  'Min',
  'Max',
  'Median',
];
export const RELIABILITY_HEADERS = ['Scale', 'Items', 'Cronbach α', 'N of Cases', 'Note'];
export const VALIDITY_HEADERS = ['Test', 'Statistic', 'df', 'p', 'Note'];
export const CORRELATION_HEADERS = ['Variable 1', 'Variable 2', 'Method', 'N', 'r', 'p'];
export const REGRESSION_HEADERS = [
  'Model',
  'Dependent Variable',
  'Predictor',
  'B',
  'SE',
  'Beta',
  't',
  'p',
  'R²',
  'Adjusted R²',
  'N',
];
/** The ordinal model needs its own columns, so it becomes a second block. */
export const ORDINAL_REGRESSION_HEADERS = [
  'Model',
  'Dependent Variable',
  'Term',
  'Log-odds B',
  'SE',
  'OR',
  'Wald z',
  'p',
  'McFadden R²',
  'Nagelkerke R²',
  'N',
];
export const HYPOTHESIS_HEADERS = ['Hypothesis', 'Statement', 'Test', 'Statistic', 'p', 'Decision'];
export const FINDINGS_HEADERS = ['序号', '发现', '支撑分析', '局限性'];

/**
 * Verdict wording, imported from the report service so the workbook and the
 * report can never describe the same verdict differently. The `inconclusive`
 * wording is the one that matters: a null result is reported as "this sample
 * provided no evidence", never as proof that the variables are unrelated.
 */


/** Note used whenever a bundle section exists but holds no usable result. */
function unavailableNote(reason: string): string {
  return `该项分析在本次结果包中不可用：${reason}`;
}

/**
 * Sheets contributed to the results workbook.
 *
 * Every cell is either a value copied out of the bundle, or `null` when the
 * bundle reports the statistic as unavailable. Nothing is defaulted to 0 and
 * nothing is rounded differently from the bundle, so any cell in this workbook
 * can be matched against the stored analysis that produced it.
 */
export function analysisSheets(bundle: AnalysisBundle): ExportSheet[] {
  return [
    dataQualitySheet(bundle),
    descriptiveSheet(bundle),
    reliabilitySheet(bundle),
    validitySheet(bundle),
    correlationSheet(bundle),
    ...regressionSheets(bundle),
    hypothesisSheet(bundle),
    findingsSheet(bundle),
  ];
}

function dataQualitySheet(bundle: AnalysisBundle): ExportSheet {
  const { sample, dataset_summary: dataset } = bundle;
  return {
    name: 'Data Quality',
    headers: DATA_QUALITY_HEADERS.slice(),
    rows: [
      ['收集样本总数', sample.respondents_total, '不区分作答状态'],
      ['已完成', sample.completed, ''],
      ['作答中', sample.in_progress, ''],
      ['中途退出', sample.abandoned, ''],
      ['研究者排除', sample.excluded, '排除决定由研究者作出，平台不自动删除样本'],
      [
        '进入分析样本',
        sample.analysable,
        '已完成且未被排除；各统计量另有其自身的有效 n，缺失值采用整例删除',
      ],
      ['装载到统计引擎的行数', sample.rows_loaded, ''],
      [
        '渠道数',
        sample.sources.length,
        sample.sources.map((item) => `${item.source}:${item.total}`).join('；'),
      ],
      ['变量数', dataset.variable_count, ''],
      ['派生变量数', dataset.derived_variable_count, ''],
      ['无有效作答的变量数', dataset.empty_variables.length, dataset.empty_variables.join('、')],
      ['统计引擎版本', bundle.engine_version, ''],
      ['分析生成时间', bundle.generated_at, ''],
      ['结果包解读前提条数', bundle.caveats.length, bundle.caveats.join(' ')],
    ],
  };
}

function descriptiveSheet(bundle: AnalysisBundle): ExportSheet {
  const report = bundle.descriptive;
  return {
    name: 'Descriptive Statistics',
    headers: DESCRIPTIVE_HEADERS.slice(),
    rows:
      report.variables.length === 0
        ? [[unavailableNote('数据集中没有任何可描述的非文本变量。')]]
        : report.variables.map((stats) => [
            stats.variable,
            stats.label,
            stats.dimension,
            stats.n,
            stats.missing,
            stats.mean,
            stats.standard_deviation,
            stats.minimum,
            stats.maximum,
            stats.median,
          ]),
  };
}

function reliabilitySheet(bundle: AnalysisBundle): ExportSheet {
  const report = bundle.reliability;
  return {
    name: 'Reliability',
    headers: RELIABILITY_HEADERS.slice(),
    rows:
      report.scales.length === 0
        ? [
            [
              unavailableNote(
                '问卷未声明任何量表，平台无法判断哪些题项构成同一维度，因此不计算 Cronbach α。',
              ),
            ],
          ]
        : report.scales.map((scale) => [
            scale.scale,
            scale.k,
            scale.cronbach_alpha,
            scale.n,
            scale.items.length === 0
              ? scale.interpretation
              : `${scale.interpretation} 条目：${scale.items.map((item) => item.item).join('、')}`,
          ]),
  };
}

function validitySheet(bundle: AnalysisBundle): ExportSheet {
  const validity = bundle.validity;
  const rows: (string | number | null)[][] = [
    [
      'KMO 取样适切性（整体）',
      validity.overall_kmo.overall,
      null,
      null,
      validity.overall_kmo.interpretation,
    ],
    [
      `Bartlett 球形检验${validity.overall_bartlett.unavailable ? '（不可用）' : ''}`,
      validity.overall_bartlett.chi_square,
      validity.overall_bartlett.degrees_of_freedom,
      validity.overall_bartlett.p_value,
      validity.overall_bartlett.interpretation,
    ],
  ];

  for (const entry of validity.scale_efa) {
    rows.push([
      `EFA：${entry.scale}`,
      entry.result.rotated_cumulative_variance,
      entry.result.factors_retained,
      entry.result.bartlett.p_value,
      `${entry.label}：n = ${entry.result.n}，题项 ${entry.result.p} 个，` +
        `保留 ${entry.result.factors_retained} 个因子（旋转后累计解释方差 ${entry.result.rotated_cumulative_variance}）；` +
        `共同度低于 0.40 的变量 ${entry.result.low_communality.length} 个`,
    ]);
  }

  return { name: 'Validity', headers: VALIDITY_HEADERS.slice(), rows };
}

function correlationSheet(bundle: AnalysisBundle): ExportSheet {
  const correlation = bundle.correlation;
  return {
    name: 'Correlation',
    headers: CORRELATION_HEADERS.slice(),
    rows: correlation
      ? correlation.pairs.map((pair) => [
          pair.left,
          pair.right,
          pair.method,
          pair.n,
          pair.r,
          pair.p_value,
        ])
      : [
          [
            unavailableNote(
              '可用的连续/有序变量少于 2 个，或有效样本不足，无法计算相关矩阵。',
            ),
          ],
        ],
  };
}

function regressionSheets(bundle: AnalysisBundle): ExportSheet[] {
  const block = bundle.regression;
  if (!block) {
    return [
      {
        name: 'Regression',
        headers: REGRESSION_HEADERS.slice(),
        rows: [[unavailableNote('因变量或自变量不存在，未运行回归分析。')]],
      },
    ];
  }

  const olsRows: (string | number | null)[][] = [];
  if (block.ols) {
    const ols = block.ols;
    for (const coefficient of ols.coefficients) {
      olsRows.push([
        'ols',
        ols.dependent,
        coefficient.term,
        coefficient.b,
        coefficient.standard_error,
        coefficient.beta,
        coefficient.t,
        coefficient.p_value,
        null,
        null,
        ols.n,
      ]);
    }
    olsRows.push([
      'ols（模型整体）',
      ols.dependent,
      '（模型）',
      null,
      ols.standard_error_estimate,
      ols.r,
      ols.f_statistic,
      ols.f_p_value,
      ols.r_squared,
      ols.adjusted_r_squared,
      ols.n,
    ]);
  } else {
    olsRows.push([unavailableNote('本次结果包未包含线性回归结果。')]);
  }

  const sheets: ExportSheet[] = [
    { name: 'Regression', headers: REGRESSION_HEADERS.slice(), rows: olsRows },
  ];

  const ordinal = block.ordinal;
  if (ordinal) {
    const ordinalRows: (string | number | null)[][] = ordinal.coefficients.map((coefficient) => [
      `ordinal_logit${ordinal.converged ? '' : '（未收敛）'}`,
      ordinal.dependent,
      coefficient.term,
      coefficient.b,
      coefficient.standard_error,
      coefficient.odds_ratio,
      coefficient.z,
      coefficient.p_value,
      null,
      null,
      ordinal.n,
    ]);
    ordinalRows.push([
      `ordinal_logit${ordinal.converged ? '' : '（未收敛）'}`,
      ordinal.dependent,
      '（模型整体）',
      null,
      null,
      null,
      ordinal.lr_chi_square,
      ordinal.lr_p_value,
      ordinal.mcfadden_r_squared,
      ordinal.nagelkerke_r_squared,
      ordinal.n,
    ]);
    sheets.push({
      name: 'Regression',
      headers: ORDINAL_REGRESSION_HEADERS.slice(),
      rows: ordinalRows,
    });
  }

  return sheets;
}

function hypothesisSheet(bundle: AnalysisBundle): ExportSheet {
  const report = bundle.hypotheses;
  return {
    name: 'Hypothesis Testing',
    headers: HYPOTHESIS_HEADERS.slice(),
    rows:
      report.results.length === 0
        ? [[unavailableNote('本次结果包未包含假设检验结果。')]]
        : report.results.map((result) => [
            result.code,
            result.statement,
            result.method,
            result.r,
            result.p_value,
            VERDICT_LABELS[result.verdict] ?? result.verdict,
          ]),
  };
}

/**
 * Research findings, derived strictly from the bundle.
 *
 * Each row names the analysis it came from, so a reader can open the matching
 * sheet and check the number rather than take the sentence on trust.
 */
function findingsSheet(bundle: AnalysisBundle): ExportSheet {
  const rows: (string | number | null)[][] = [];
  const { hypotheses, reliability, comparisons } = bundle;

  for (const result of hypotheses.results) {
    if (result.verdict !== 'supported') continue;
    rows.push([
      rows.length + 1,
      `${result.code}：${result.statement}`,
      `${result.method}，r = ${result.r}，p = ${result.p_value}，n = ${result.n}；` +
        `${result.effect_size ? result.effect_size.text : '未报告效应量'}`,
      '横截面数据只能说明共变关系，不能推断因果关系',
    ]);
  }

  for (const result of hypotheses.results) {
    if (result.verdict !== 'inconclusive') continue;
    rows.push([
      rows.length + 1,
      `${result.code} 证据不足：${result.statement}`,
      `${result.method}，r = ${result.r}，p = ${result.p_value}，n = ${result.n}`,
      '未达统计显著只说明当前样本未提供证据，不能解读为两者没有关系',
    ]);
  }

  const best = bestReliability(reliability.scales);
  if (best) {
    rows.push([
      rows.length + 1,
      `量表 ${best.scale} 的 Cronbach α 为 ${best.cronbach_alpha}`,
      `信度分析，n = ${best.n}，条目 ${best.k} 个`,
      'α 只反映内部一致性，不构成效度证据，也不证明量表单维',
    ]);
  }

  for (const comparison of comparisons) {
    const anova = comparison.anova;
    if (!anova) continue;
    rows.push([
      rows.length + 1,
      `${comparison.dependent} 在不同${comparison.factor_label}分组间存在差异`,
      `单因素方差分析 F = ${anova.f}，p = ${anova.p_value}；` +
        `Kruskal–Wallis H = ${comparison.kruskal_wallis?.h ?? '未计算'}，` +
        `p = ${comparison.kruskal_wallis?.p_value ?? '未计算'}`,
      comparison.recommended === 'parametric'
        ? '以参数检验为主要结论，非参数结果作为稳健性对照'
        : '数据触发样本量或方差齐性警告，建议以非参数检验为主要结论',
    ]);
  }

  if (rows.length === 0) rows.push([1, unavailableNote('没有可报告的分析结果。'), '', '']);
  return { name: 'Research Findings', headers: FINDINGS_HEADERS.slice(), rows };
}

type ReliabilityResult = AnalysisBundle['reliability']['scales'][number];

function bestReliability(scales: ReliabilityResult[]): ReliabilityResult | null {
  let best: ReliabilityResult | null = null;
  for (const scale of scales) {
    if (scale.cronbach_alpha === null) continue;
    if (best === null || best.cronbach_alpha === null || scale.cronbach_alpha > best.cronbach_alpha) {
      best = scale;
    }
  }
  return best;
}

/* ------------------------------------------------------------------ */
/* Agreement between the dataset and the bundle                       */
/* ------------------------------------------------------------------ */

/**
 * True when the dataset about to be exported is the one the stored analysis was
 * computed on.
 *
 * Serving data and results together is a promise that they describe the same
 * sample, and a workbook that silently pairs one round of collection with
 * another round's statistics is worse than one that says nothing. The check is
 * *reported* through a response header rather than thrown, because refusing a
 * download the researcher legitimately asked for would be the worse failure.
 */
export function datasetMatchesBundle(summary: SampleSummary, bundle: AnalysisBundle): boolean {
  return (
    summary.analysable === bundle.sample.analysable &&
    summary.respondents_total === bundle.sample.respondents_total
  );
}
