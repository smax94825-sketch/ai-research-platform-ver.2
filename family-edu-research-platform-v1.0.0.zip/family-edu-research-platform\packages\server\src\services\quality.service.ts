/**
 * Data quality service (PHASE 4).
 *
 * Wraps the pure rules in `@ferp/shared/quality` with IO: loading responses,
 * computing cross-sample duplicate counts, persisting flags and scores.
 *
 * Guarantees enforced here:
 *  - **No sample is ever deleted or modified as a result of quality scoring.**
 *    Only `quality_flags` rows and the quality columns on `respondents` change.
 *  - Scoring is idempotent: recomputing a project clears that project's flags
 *    and rewrites them, so running it twice produces the same result.
 *  - The engine version is stored alongside every score, so a score computed
 *    under older thresholds is never mistaken for a current one.
 */

import {
  QUALITY_ENGINE_VERSION,
  QUALITY_RULES,
  answerSignature,
  bucketQualityScores,
  evaluateQuality,
  type AnswerMap,
  type AnswerValue,
  type QualityEvaluationResult,
  type QualityRuleCode,
  type QualitySeverity,
  type Question,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import { parseJson } from './mappers.js';
import { listQuestions } from './questionnaire.service.js';
import type { RespondentRow } from './mappers.js';

/** How many respondents one recompute will score, to bound request cost. */
const MAX_RESPONDENTS_PER_RUN = 20_000;

/* ------------------------------------------------------------------ */
/* Loading                                                            */
/* ------------------------------------------------------------------ */

function loadQuestionsForQuestionnaire(db: Db, questionnaireId: string): Question[] {
  return listQuestions(db, questionnaireId);
}

/**
 * Count how many respondents share each answer signature.
 * Reads the stored `answer_signature` column rather than rescanning answers.
 */
export function signatureCounts(db: Db, projectId: string): Map<string, number> {
  const rows = db.all<{ answer_signature: string; n: number }>(
    `SELECT answer_signature, COUNT(*) AS n
       FROM respondents
      WHERE project_id = ? AND answer_signature IS NOT NULL AND answer_signature <> ''
      GROUP BY answer_signature`,
    [projectId],
  );
  return new Map(rows.map((row) => [row.answer_signature, Number(row.n)]));
}

/* ------------------------------------------------------------------ */
/* Persistence                                                        */
/* ------------------------------------------------------------------ */

function persistEvaluation(
  db: Db,
  respondentId: string,
  result: QualityEvaluationResult,
  timestamp: string,
): void {
  db.run('DELETE FROM quality_flags WHERE respondent_id = ?', [respondentId]);

  for (const finding of result.findings) {
    db.run(
      `INSERT INTO quality_flags
         (id, respondent_id, project_id, rule_code, severity, detail, resolved, resolved_note,
          created_at, score_impact, label, engine_version)
       VALUES (?, ?, (SELECT project_id FROM respondents WHERE id = ?), ?, ?, ?, 0, NULL, ?, ?, ?, ?)`,
      [
        newId(),
        respondentId,
        respondentId,
        finding.code,
        finding.severity,
        `${finding.detail}\n[证据] ${JSON.stringify(finding.evidence)}`,
        timestamp,
        finding.scoreImpact,
        finding.label,
        result.engine_version,
      ],
    );
  }

  db.run(
    `UPDATE respondents
        SET quality_score = ?, quality_severity = ?, quality_computed_at = ?, quality_engine_version = ?
      WHERE id = ?`,
    [result.score, result.severity, timestamp, result.engine_version, respondentId],
  );
}

/* ------------------------------------------------------------------ */
/* Single respondent                                                  */
/* ------------------------------------------------------------------ */

export interface RespondentQualityResult {
  respondent_id: string;
  anonymous_id: string;
  evaluation: QualityEvaluationResult;
  duplicate_count: number;
}

/**
 * Score one respondent. Used on completion and when a researcher opens a sample.
 * Duplicate context comes from the stored signature index.
 */
export function evaluateRespondentQuality(
  db: Db,
  respondentId: string,
  options: { persist?: boolean } = {},
): RespondentQualityResult {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw ApiError.notFound('样本不存在。');

  const questions = loadQuestionsForQuestionnaire(db, row.questionnaire_id);
  const answers = loadAnswers(db, respondentId);

  let duplicateCount = 0;
  const signature = answerSignature(questions, answers);
  if (row.answer_signature) {
    duplicateCount = Number(
      db.scalar<number>(
        'SELECT COUNT(*) AS n FROM respondents WHERE project_id = ? AND answer_signature = ?',
        [row.project_id, row.answer_signature],
      ) ?? 0,
    );
  }

  const project = db.get<{ settings: string | null; id: string }>(
    'SELECT id, settings FROM research_projects WHERE id = ?',
    [row.project_id],
  );
  const settings = parseJson<{ min_duration_seconds?: number | null } | null>(project?.settings ?? null, null);

  const evaluation = evaluateQuality({
    questions,
    answers,
    durationSeconds: row.duration_seconds,
    minDurationSeconds: settings?.min_duration_seconds ?? null,
    duplicateCount,
  });

  if (options.persist !== false) {
    const timestamp = nowIso();
    db.transaction(() => {
      // Refresh the stored signature in case answers changed before completion.
      if (signature !== row.answer_signature) {
        db.run('UPDATE respondents SET answer_signature = ? WHERE id = ?', [signature, respondentId]);
      }
      persistEvaluation(db, respondentId, evaluation, timestamp);
    });
  }

  return {
    respondent_id: respondentId,
    anonymous_id: row.anonymous_id,
    evaluation,
    duplicate_count: duplicateCount,
  };
}

function loadAnswers(db: Db, respondentId: string): AnswerMap {
  const rows = db.all<{ question_code: string; answer: string | null }>(
    'SELECT question_code, answer FROM responses WHERE respondent_id = ?',
    [respondentId],
  );
  const answers: AnswerMap = {};
  for (const row of rows) {
    answers[row.question_code] = parseJson<AnswerValue>(row.answer, null);
  }
  return answers;
}

/**
 * Record the answer signature for a completed session.
 * Called on completion so duplicate detection stays a cheap GROUP BY.
 */
export function recordAnswerSignature(db: Db, respondentId: string): string {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw ApiError.notFound('样本不存在。');
  const questions = loadQuestionsForQuestionnaire(db, row.questionnaire_id);
  const signature = answerSignature(questions, loadAnswers(db, respondentId));
  db.run('UPDATE respondents SET answer_signature = ? WHERE id = ?', [signature, respondentId]);
  return signature;
}

/**
 * Re-score every respondent sharing an answer signature.
 *
 * Duplicate detection is inherently cross-sample: the FIRST of two identical
 * submissions cannot know a twin is coming, so when the twin arrives both must
 * be re-scored. Without this, the earlier sample would keep an unearned 100
 * until someone happened to re-run the engine over the whole project.
 *
 * Returns the number of additional respondents whose scores were refreshed.
 */
export function rescoreSignaturePeers(
  db: Db,
  projectId: string,
  signature: string,
  excludeRespondentId: string,
): number {
  if (!signature || !projectId) return 0;

  const peers = db.all<{ id: string }>(
    `SELECT id FROM respondents
      WHERE project_id = ? AND answer_signature = ? AND id <> ?`,
    [projectId, signature, excludeRespondentId],
  );

  for (const peer of peers) {
    evaluateRespondentQuality(db, peer.id, { persist: true });
  }
  return peers.length;
}

/**
 * Score a freshly completed submission, including its duplicate peers.
 *
 * This is the single entry point the collection route calls, so the
 * cross-sample rule can never be forgotten at a call site.
 */
export function scoreCompletedSubmission(
  db: Db,
  respondentId: string,
): { duplicateCount: number; peersRescored: number; score: number } {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw ApiError.notFound('样本不存在。');

  const signature = recordAnswerSignature(db, respondentId);
  const self = evaluateRespondentQuality(db, respondentId, { persist: true });

  const peersRescored =
    self.duplicate_count >= 2
      ? rescoreSignaturePeers(db, row.project_id, signature, respondentId)
      : 0;

  return {
    duplicateCount: self.duplicate_count,
    peersRescored,
    score: self.evaluation.score,
  };
}

/* ------------------------------------------------------------------ */
/* Project-wide recompute                                             */
/* ------------------------------------------------------------------ */

export interface RecomputeResult {
  project_id: string;
  engine_version: string;
  respondents_scored: number;
  flags_written: number;
  clean_respondents: number;
  flagged_respondents: number;
  rule_counts: Record<string, number>;
  computed_at: string;
}

/**
 * Recompute quality for every respondent with at least one answer.
 *
 * A respondent with no answers at all is left unscored rather than given a
 * misleading 0 — "nothing to judge" is a different state from "judged poor".
 */
export function recomputeProjectQuality(db: Db, projectId: string): RecomputeResult {
  const respondents = db.all<RespondentRow>(
    `SELECT * FROM respondents
      WHERE project_id = ? AND EXISTS (SELECT 1 FROM responses r WHERE r.respondent_id = respondents.id)
      ORDER BY started_at ASC
      LIMIT ?`,
    [projectId, MAX_RESPONDENTS_PER_RUN],
  );

  const timestamp = nowIso();
  const ruleCounts: Record<string, number> = {};
  let flagsWritten = 0;
  let clean = 0;

  const project = db.get<{ settings: string | null }>(
    'SELECT settings FROM research_projects WHERE id = ?',
    [projectId],
  );
  const settings = parseJson<{ min_duration_seconds?: number | null } | null>(
    project?.settings ?? null,
    null,
  );

  db.transaction(() => {
    // Pass 1: refresh every stored signature. Duplicate counts are read after
    // this, so a respondent whose answers changed is grouped correctly rather
    // than against a stale signature.
    const signatures = new Map<string, string>();
    for (const row of respondents) {
      const questions = loadQuestionsForQuestionnaire(db, row.questionnaire_id);
      const signature = answerSignature(questions, loadAnswers(db, row.id));
      signatures.set(row.id, signature);
      db.run('UPDATE respondents SET answer_signature = ? WHERE id = ?', [signature, row.id]);
    }

    const signatureIndex = signatureCounts(db, projectId);

    // Pass 2: evaluate with the now-correct cross-sample context.
    for (const row of respondents) {
      const questions = loadQuestionsForQuestionnaire(db, row.questionnaire_id);
      const answers = loadAnswers(db, row.id);
      const signature = signatures.get(row.id) ?? '';
      const duplicateCount = signature === '' ? 0 : (signatureIndex.get(signature) ?? 0);

      const evaluation = evaluateQuality({
        questions,
        answers,
        durationSeconds: row.duration_seconds,
        minDurationSeconds: settings?.min_duration_seconds ?? null,
        duplicateCount,
      });

      persistEvaluation(db, row.id, evaluation, timestamp);

      flagsWritten += evaluation.findings.length;
      if (evaluation.findings.length === 0) clean += 1;
      for (const finding of evaluation.findings) {
        ruleCounts[finding.code] = (ruleCounts[finding.code] ?? 0) + 1;
      }
    }
  });

  return {
    project_id: projectId,
    engine_version: QUALITY_ENGINE_VERSION,
    respondents_scored: respondents.length,
    flags_written: flagsWritten,
    clean_respondents: clean,
    flagged_respondents: respondents.length - clean,
    rule_counts: ruleCounts,
    computed_at: timestamp,
  };
}

/* ------------------------------------------------------------------ */
/* Reporting                                                          */
/* ------------------------------------------------------------------ */

export interface QualityFlagRecord {
  rule_code: QualityRuleCode;
  label: string;
  severity: QualitySeverity;
  score_impact: number;
  detail: string;
  evidence: Record<string, unknown>;
  created_at: string;
}

export interface RespondentQualityView {
  respondent_id: string;
  anonymous_id: string;
  score: number | null;
  severity: QualitySeverity | 'clean' | 'unscored';
  computed_at: string | null;
  engine_version: string | null;
  review_status: string;
  review_note: string | null;
  flags: QualityFlagRecord[];
}

export function getRespondentQualityView(db: Db, respondentId: string): RespondentQualityView {
  const row = db.get<RespondentRow>('SELECT * FROM respondents WHERE id = ?', [respondentId]);
  if (!row) throw ApiError.notFound('样本不存在。');

  const flags = db.all<{
    rule_code: string;
    label: string | null;
    severity: string;
    score_impact: number;
    detail: string | null;
    engine_version: string;
    created_at: string;
  }>(
    'SELECT rule_code, label, severity, score_impact, detail, engine_version, created_at FROM quality_flags WHERE respondent_id = ? ORDER BY score_impact DESC',
    [respondentId],
  );

  return {
    respondent_id: respondentId,
    anonymous_id: row.anonymous_id,
    score: row.quality_score,
    severity: (row.quality_severity as QualitySeverity | 'clean' | null) ?? 'unscored',
    computed_at: row.quality_computed_at ?? null,
    engine_version: row.quality_engine_version ?? null,
    review_status: row.review_status ?? 'unreviewed',
    review_note: row.review_note ?? null,
    flags: flags.map((flag) => {
      const [detailLine, evidenceLine] = (flag.detail ?? '').split('\n[证据] ');
      let evidence: Record<string, unknown> = {};
      if (evidenceLine) {
        try {
          evidence = JSON.parse(evidenceLine) as Record<string, unknown>;
        } catch {
          evidence = {};
        }
      }
      return {
        rule_code: flag.rule_code as QualityRuleCode,
        label: flag.label ?? QUALITY_RULES[flag.rule_code as QualityRuleCode]?.label ?? flag.rule_code,
        severity: flag.severity as QualitySeverity,
        score_impact: flag.score_impact,
        detail: detailLine ?? '',
        evidence,
        created_at: flag.created_at,
      };
    }),
  };
}

export interface ProjectQualityReport {
  project_id: string;
  engine_version: string;
  thresholds_note: string;
  scored_respondents: number;
  unscored_respondents: number;
  mean_score: number | null;
  median_score: number | null;
  bands: { label: string; min: number; max: number; count: number }[];
  rule_frequency: { rule_code: QualityRuleCode; label: string; count: number; severity: QualitySeverity }[];
  /** The most recently flagged samples, for the researcher to review. */
  flagged_samples: {
    respondent_id: string;
    anonymous_id: string;
    score: number;
    severity: string;
    review_status: string;
    rule_codes: QualityRuleCode[];
  }[];
  /** Samples the researcher has explicitly excluded, with their reasons. */
  excluded_samples: { anonymous_id: string; note: string | null; reviewed_at: string | null }[];
  /** Rules that could not run for this instrument. */
  inactive_rules: { rule_code: string; reason: string }[];
}

export function getProjectQualityReport(db: Db, projectId: string): ProjectQualityReport {
  const respondents = db.all<RespondentRow>(
    'SELECT * FROM respondents WHERE project_id = ? ORDER BY started_at DESC LIMIT ?',
    [projectId, MAX_RESPONDENTS_PER_RUN],
  );

  const scored = respondents.filter((row) => row.quality_score !== null);
  const scores = scored.map((row) => Number(row.quality_score));
  const sorted = [...scores].sort((a, b) => a - b);

  const ruleRows = db.all<{ rule_code: string; severity: string; n: number }>(
    `SELECT rule_code, MIN(severity) AS severity, COUNT(*) AS n
       FROM quality_flags WHERE project_id = ?
      GROUP BY rule_code
      ORDER BY n DESC`,
    [projectId],
  );

  const flaggedRows = db.all<{
    respondent_id: string;
    anonymous_id: string;
    quality_score: number;
    quality_severity: string;
    review_status: string | null;
    rule_codes: string;
  }>(
    `SELECT r.id AS respondent_id, r.anonymous_id, r.quality_score, r.quality_severity,
            COALESCE(r.review_status, 'unreviewed') AS review_status,
            GROUP_CONCAT(f.rule_code) AS rule_codes
       FROM respondents r
       JOIN quality_flags f ON f.respondent_id = r.id
      WHERE r.project_id = ?
      GROUP BY r.id
      ORDER BY r.quality_score ASC
      LIMIT 50`,
    [projectId],
  );

  const excludedRows = db.all<{ anonymous_id: string; review_note: string | null; reviewed_at: string | null }>(
    `SELECT anonymous_id, review_note, reviewed_at FROM respondents
      WHERE project_id = ? AND review_status = 'excluded'
      ORDER BY reviewed_at DESC LIMIT 50`,
    [projectId],
  );

  // Report which rules could not run, rather than silently reporting "no flags".
  const questionnaireRow = db.get<{ id: string }>(
    'SELECT id FROM questionnaires WHERE project_id = ? ORDER BY is_current DESC, created_at DESC LIMIT 1',
    [projectId],
  );
  const inactive: { rule_code: string; reason: string }[] = [];
  if (questionnaireRow) {
    const questions = loadQuestionsForQuestionnaire(db, questionnaireRow.id);
    const hasKnowledgeItems = questions.some((q) => q.question_type === 'knowledge_test');
    const hasSubjective = questions.some((q) => q.variable_name === 'FEK');
    if (!hasKnowledgeItems || !hasSubjective) {
      inactive.push({
        rule_code: 'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
        reason: '该问卷未同时包含知识测试题与主观知识自评题（变量 FEK）。',
      });
    }
    if (!questions.some((q) => q.question_type === 'matrix')) {
      inactive.push({
        rule_code: 'MATRIX_STRAIGHT_LINE',
        reason: '该问卷不含矩阵题。',
      });
    }
  }

  return {
    project_id: projectId,
    engine_version: QUALITY_ENGINE_VERSION,
    thresholds_note:
      '质量评分为启发式指标，用于提示需要人工复核的样本，不等同于对受访者的评价，也不构成剔除依据。',
    scored_respondents: scored.length,
    unscored_respondents: respondents.length - scored.length,
    mean_score: scores.length > 0 ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 100) / 100 : null,
    median_score:
      sorted.length === 0
        ? null
        : sorted.length % 2 === 1
          ? sorted[(sorted.length - 1) / 2]!
          : Math.round(((sorted[sorted.length / 2 - 1]! + sorted[sorted.length / 2]!) / 2) * 100) / 100,
    bands: bucketQualityScores(scores),
    rule_frequency: ruleRows.map((row) => ({
      rule_code: row.rule_code as QualityRuleCode,
      label: QUALITY_RULES[row.rule_code as QualityRuleCode]?.label ?? row.rule_code,
      count: Number(row.n),
      severity: row.severity as QualitySeverity,
    })),
    flagged_samples: flaggedRows.map((row) => ({
      respondent_id: row.respondent_id,
      anonymous_id: row.anonymous_id,
      score: Number(row.quality_score),
      severity: row.quality_severity,
      review_status: row.review_status ?? 'unreviewed',
      rule_codes: (row.rule_codes ?? '').split(',').filter(Boolean) as QualityRuleCode[],
    })),
    excluded_samples: excludedRows.map((row) => ({
      anonymous_id: row.anonymous_id,
      note: row.review_note,
      reviewed_at: row.reviewed_at,
    })),
    inactive_rules: inactive,
  };
}

/** Rule catalogue for the console, so the UI never invents its own copy. */
export function qualityRuleCatalogue(): typeof QUALITY_RULES {
  return QUALITY_RULES;
}
