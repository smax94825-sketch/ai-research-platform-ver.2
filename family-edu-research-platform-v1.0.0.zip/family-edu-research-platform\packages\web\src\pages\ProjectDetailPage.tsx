import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  Checkbox,
  Field,
  Input,
  LoadingBlock,
  Modal,
  Select,
  Textarea,
} from '../components/ui';
import {
  api,
  ApiClientError,
  type ProjectDetail,
  type QuotaDimension,
  type QuotaStatus,
  type ResearchProject,
  type Questionnaire,
} from '../lib/api';
import {
  formatDate,
  formatNumber,
  formatPercent,
  projectStatusMeta,
  questionnaireStatusMeta,
} from '../lib/format';

const STATUS_OPTIONS: { value: ResearchProject['status']; label: string }[] = [
  { value: 'draft', label: '草稿' },
  { value: 'collecting', label: '收集中' },
  { value: 'paused', label: '已暂停' },
  { value: 'analyzing', label: '分析中' },
  { value: 'completed', label: '已完成' },
  { value: 'archived', label: '已归档' },
];

export function ProjectDetailPage(): ReactNode {
  const { projectId = '' } = useParams();
  const [detail, setDetail] = useState<ProjectDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');

  // Editable research-design fields.
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [background, setBackground] = useState('');
  const [objectives, setObjectives] = useState('');
  const [population, setPopulation] = useState('');
  const [sampleSize, setSampleSize] = useState('');
  const [status, setStatus] = useState<ResearchProject['status']>('draft');

  /* PHASE 4 — quota */
  const [quota, setQuota] = useState<QuotaStatus | null>(null);
  const [dimensions, setDimensions] = useState<QuotaDimension[]>([]);
  const [quotaEditorOpen, setQuotaEditorOpen] = useState(false);
  const [quotaSaving, setQuotaSaving] = useState(false);
  const [quotaError, setQuotaError] = useState<string | null>(null);
  const [quotaEnabled, setQuotaEnabled] = useState(true);
  const [quotaPreserveStructure, setQuotaPreserveStructure] = useState(true);
  const [quotaDimension, setQuotaDimension] = useState('');
  const [quotaCategories, setQuotaCategories] = useState<{ category: string; target_n: number }[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.projects.get(projectId);
      setDetail(result);
      const project = result.project;
      setTitle(project.title);
      setDescription(project.description ?? '');
      setBackground(project.background ?? '');
      setObjectives(project.objectives ?? '');
      setPopulation(project.target_population ?? '');
      setSampleSize(project.target_sample_size === null ? '' : String(project.target_sample_size));
      setStatus(project.status);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载项目详情。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  /* PHASE 4 — quota status is loaded alongside the project. */
  useEffect(() => {
    if (!projectId) return;
    let cancelled = false;
    void (async () => {
      try {
        const status = await api.quota.status(projectId);
        if (!cancelled) setQuota(status);
      } catch {
        // A missing quota is not an error worth interrupting the page for.
        if (!cancelled) setQuota(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [projectId]);

  /** Open the editor, loading the candidate dimensions on first use. */
  async function openQuotaEditor(): Promise<void> {
    setQuotaError(null);
    setQuotaEditorOpen(true);
    try {
      const available = dimensions.length > 0 ? dimensions : await api.quota.dimensions(projectId);
      setDimensions(available);

      const existing = quota?.enabled ? quota : null;
      const currentVariable = existing?.dimension_variable ?? available[0]?.variable ?? '';
      setQuotaDimension(currentVariable);
      setQuotaEnabled(quota?.enabled ?? true);
      setQuotaPreserveStructure(quota?.preserve_structure ?? true);

      const dimension = available.find((item) => item.variable === currentVariable);
      if (existing && existing.progress.items.length > 0) {
        setQuotaCategories(
          existing.progress.items.map((item) => ({
            category: item.category,
            target_n: item.target_n,
          })),
        );
      } else if (dimension) {
        setQuotaCategories(dimension.categories.map((category) => ({ category, target_n: 200 })));
      } else {
        setQuotaCategories([]);
      }
    } catch (err) {
      setQuotaError(err instanceof ApiClientError ? err.message : '无法加载配额维度。');
    }
  }

  async function saveQuota(): Promise<void> {
    setQuotaSaving(true);
    setQuotaError(null);
    try {
      const config =
        quotaEnabled && quotaDimension && quotaCategories.length > 0
          ? {
              enabled: true,
              preserve_structure: quotaPreserveStructure,
              categories: quotaCategories.map((item) => ({
                dimension: quotaDimension,
                category: item.category,
                target_n: Number(item.target_n),
              })),
            }
          : quotaEnabled
            ? null
            : {
                enabled: false,
                preserve_structure: quotaPreserveStructure,
                categories: [],
              };

      const updated = await api.quota.update(projectId, config as never);
      setQuota(updated);
      setQuotaEditorOpen(false);
      setNotice('配额配置已保存。');
      await load();
    } catch (err) {
      if (err instanceof ApiClientError) {
        const details = err.fieldErrors;
        setQuotaError(
          details.length > 0
            ? `${err.message} ${details.map((item) => item.message).join(' ')}`
            : err.message,
        );
      } else {
        setQuotaError('保存配额配置失败。');
      }
    } finally {
      setQuotaSaving(false);
    }
  }

  async function saveDesign(): Promise<void> {
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      await api.projects.update(projectId, {
        title: title.trim(),
        description: description.trim() || null,
        background: background.trim() || null,
        objectives: objectives.trim() || null,
        target_population: population.trim() || null,
        target_sample_size: sampleSize === '' ? null : Number(sampleSize),
        status,
      });
      setNotice('研究设计已保存。');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '保存失败。');
    } finally {
      setSaving(false);
    }
  }

  async function addQuestionnaire(template: string): Promise<void> {
    setCreating(true);
    setError(null);
    try {
      await api.projects.createQuestionnaire(projectId, {
        template,
        ...(newTitle.trim() ? { title: newTitle.trim() } : {}),
      });
      setNewTitle('');
      setNotice(template === 'blank' ? '已创建空白问卷。' : '已按模板创建问卷（58 道题）。');
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '创建问卷失败。');
    } finally {
      setCreating(false);
    }
  }

  if (loading) return <LoadingBlock label="正在加载项目…" />;
  if (!detail) {
    return (
      <Alert tone="danger" title="无法打开项目">
        {error ?? '项目不存在，或您没有访问权限。'}
      </Alert>
    );
  }

  const project = detail.project;
  const meta = projectStatusMeta(project.status);

  return (
    <div className="space-y-6">
      <div>
        <Link to="/projects" className="text-sm text-ink-500 hover:text-ink-800">
          ← 返回项目列表
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="text-xl font-semibold text-ink-900">{project.title}</h1>
          <Badge tone={meta.tone}>{meta.label}</Badge>
        </div>
        <p className="mt-1 text-sm text-ink-500">
          创建于 {formatDate(project.created_at)} · 最后更新 {formatDate(project.updated_at)}
        </p>
      </div>

      {error && (
        <Alert tone="danger" title="操作失败">
          {error}
        </Alert>
      )}
      {notice && <Alert tone="success">{notice}</Alert>}

      <div className="flex flex-wrap gap-2">
        {detail.questionnaires[0] && (
          <Link to={`/projects/${projectId}/questionnaires/${detail.questionnaires[0].id}/builder`}>
            <Button variant="primary">打开问卷构建器</Button>
          </Link>
        )}
        <Link to={`/?project=${projectId}`}>
          <Button>查看该项目仪表盘</Button>
        </Link>
      </div>

      {/* Questionnaires ------------------------------------------------- */}
      <Card>
        <CardHeader
          title="问卷版本"
          description="已发布的版本会被锁定；如需修改请建立新版本，以保证作答数据与题目版本严格对应。"
        />
        {detail.questionnaires.length === 0 ? (
          <Alert tone="info" title="该项目还没有问卷">
            可以按默认模板创建（58 道题），或创建空白问卷自行设计。
          </Alert>
        ) : (
          <ul className="divide-y divide-ink-100">
            {detail.questionnaires.map((questionnaire: Questionnaire) => {
              const qMeta = questionnaireStatusMeta(questionnaire.status);
              return (
                <li key={questionnaire.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs text-ink-500">{questionnaire.version}</span>
                      <span className="text-sm font-medium text-ink-900">{questionnaire.title}</span>
                      <Badge tone={qMeta.tone}>{qMeta.label}</Badge>
                      {questionnaire.is_current && <Badge tone="info">当前版本</Badge>}
                      {questionnaire.locked && <Badge tone="warning">已锁定</Badge>}
                    </div>
                    <p className="mt-1 text-xs text-ink-500">
                      {questionnaire.published_at
                        ? `发布于 ${formatDate(questionnaire.published_at)}`
                        : '尚未发布'}
                      {questionnaire.share_token && ` · 分享令牌 ${questionnaire.share_token.slice(0, 10)}…`}
                    </p>
                  </div>
                  <Link to={`/projects/${projectId}/questionnaires/${questionnaire.id}/builder`}>
                    <Button>编辑 / 预览</Button>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}

        <div className="mt-4 flex flex-wrap items-end gap-3 border-t border-ink-100 pt-4">
          <label className="min-w-56 flex-1">
            <span className="ferp-label">新问卷标题（可选）</span>
            <Input
              value={newTitle}
              onChange={(event) => setNewTitle(event.target.value)}
              placeholder="留空则使用模板默认标题"
            />
          </label>
          <Button loading={creating} onClick={() => void addQuestionnaire('family-edu-v4')}>
            按模板新建（58 题）
          </Button>
          <Button loading={creating} onClick={() => void addQuestionnaire('blank')}>
            新建空白问卷
          </Button>
        </div>
      </Card>

      {/* Research design ------------------------------------------------ */}
      <Card>
        <CardHeader title="研究设计" description="这些信息将用于报告生成与方法章节。" />
        <div className="space-y-4">
          <Field label="研究名称" required>
            <Input value={title} onChange={(event) => setTitle(event.target.value)} />
          </Field>

          <div className="grid gap-4 lg:grid-cols-2">
            <Field label="研究背景">
              <Textarea rows={4} value={background} onChange={(event) => setBackground(event.target.value)} />
            </Field>
            <Field label="研究目的">
              <Textarea rows={4} value={objectives} onChange={(event) => setObjectives(event.target.value)} />
            </Field>
          </div>

          <Field label="研究简介">
            <Textarea rows={2} value={description} onChange={(event) => setDescription(event.target.value)} />
          </Field>

          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="研究对象">
              <Input value={population} onChange={(event) => setPopulation(event.target.value)} />
            </Field>
            <Field label="目标样本量">
              <Input
                type="number"
                min={1}
                max={100000}
                value={sampleSize}
                onChange={(event) => setSampleSize(event.target.value)}
              />
            </Field>
            <Field label="项目状态">
              <Select
                value={status}
                onChange={(event) => setStatus(event.target.value as ResearchProject['status'])}
              >
                {STATUS_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <div className="flex justify-end">
            <Button variant="primary" loading={saving} onClick={() => void saveDesign()}>
              保存研究设计
            </Button>
          </div>
        </div>
      </Card>

      {/* Research questions & hypotheses -------------------------------- */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title={`研究问题（${project.research_questions.length}）`}
            description="来自研究设计，用于报告第 4 章。"
          />
          {project.research_questions.length === 0 ? (
            <p className="text-sm text-ink-400">尚未填写研究问题。</p>
          ) : (
            <ol className="list-decimal space-y-2 pl-5 text-sm text-ink-700">
              {project.research_questions.map((question, index) => (
                <li key={index}>{question}</li>
              ))}
            </ol>
          )}
        </Card>

        <Card>
          <CardHeader
            title={`研究假设（${project.hypotheses.length}）`}
            description="全部以「未检验」状态保存；统计引擎完成检验前不会显示任何结论。"
          />
          {project.hypotheses.length === 0 ? (
            <p className="text-sm text-ink-400">尚未填写研究假设，后续将无法执行假设检验。</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {project.hypotheses.map((hypothesis) => (
                <li key={hypothesis.code} className="flex gap-2">
                  <span className="shrink-0 font-mono text-xs font-semibold text-brand-700">
                    {hypothesis.code}
                  </span>
                  <span className="text-ink-700">{hypothesis.statement}</span>
                  <Badge tone="neutral">
                    {hypothesis.status === 'untested' ? '未检验' : hypothesis.status}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {/* Quota ------------------------------------------------------- */}
      <Card>
        <CardHeader
          title="样本配额"
          description="按研究设计的分类控制样本结构。配额用于监控与提示，平台不会自动改变目标结构，也不会因配额而增删样本。"
          actions={
            <Button variant="primary" onClick={() => void openQuotaEditor()}>
              配置配额
            </Button>
          }
        />

        {quota && quota.enabled && quota.progress.items.length > 0 ? (
          <>
            <div className="mb-3 flex flex-wrap items-center gap-3 text-sm">
              <Badge tone="success">已启用</Badge>
              <span className="text-ink-600">
                总体完成度
                <span className="ml-1 font-semibold tabular-nums text-ink-900">
                  {quota.progress.total_current}/{quota.progress.total_target}
                </span>
                <span className="ml-1 text-ink-500">（{formatPercent(quota.progress.percent)}）</span>
              </span>
              <span className="text-ink-500">
                保持目标样本结构：{quota.preserve_structure ? '是' : '否'}
              </span>
              {quota.excluded_samples > 0 && (
                <span className="text-xs text-amber-700">
                  已排除 {quota.excluded_samples} 份（不计入配额）
                </span>
              )}
            </div>

            <ul className="space-y-3">
              {quota.progress.items.map((item) => (
                <li key={item.category}>
                  <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
                    <span className="text-ink-800">{item.category}</span>
                    <span className="tabular-nums text-ink-600">
                      {item.current_n}/{item.target_n}
                      <span className={`ml-2 ${item.met ? 'text-emerald-600' : 'text-amber-600'}`}>
                        {item.percent}%
                      </span>
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-ink-100">
                    <div
                      className={`h-full rounded-full ${item.met ? 'bg-emerald-500' : 'bg-amber-500'}`}
                      style={{ width: `${Math.min(item.percent, 100)}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>

            {quota.recommendations.length > 0 && (
              <div className="mt-4 space-y-2">
                {quota.recommendations.map((recommendation, index) => (
                  <Alert
                    key={`${recommendation.kind}-${index}`}
                    tone={
                      recommendation.severity === 'critical'
                        ? 'danger'
                        : recommendation.severity === 'warning'
                          ? 'warning'
                          : 'info'
                    }
                    title={recommendation.kind === 'none' ? '收集建议' : undefined}
                  >
                    <p>{recommendation.text}</p>
                    {recommendation.evidence.length > 0 && (
                      <ul className="mt-1.5 list-disc space-y-0.5 pl-4 text-xs opacity-80">
                        {recommendation.evidence.map((line, lineIndex) => (
                          <li key={lineIndex}>{line}</li>
                        ))}
                      </ul>
                    )}
                  </Alert>
                ))}
              </div>
            )}

            <p className="mt-3 text-xs text-ink-500">{quota.counting_note}</p>
          </>
        ) : project.quota_config && project.quota_config.categories.length > 0 ? (
          <>
            <p className="text-sm text-ink-600">
              配额已配置但未启用。已定义的分类：
              {project.quota_config.categories.map((category) => category.category).join('、')}
            </p>
          </>
        ) : (
          <p className="text-sm text-ink-400">
            尚未配置样本配额。使用默认模板创建的项目会自动带入分阶段配额。
          </p>
        )}
      </Card>

      {/* Quota editor ------------------------------------------------- */}
      <Modal
        open={quotaEditorOpen}
        title="配置样本配额"
        onClose={() => setQuotaEditorOpen(false)}
        wide
        footer={
          <>
            <Button onClick={() => setQuotaEditorOpen(false)}>取消</Button>
            <Button variant="primary" loading={quotaSaving} onClick={() => void saveQuota()}>
              保存配额配置
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {quotaError && <Alert tone="danger">{quotaError}</Alert>}

          <p className="text-sm text-ink-600">
            选择用于控制样本结构的分类变量，并为每个分类设定目标数量。保存后即可在
            「流量来源」「样本列表」与仪表盘中查看实时进度。
          </p>

          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="配额维度（分类变量）">
              <Select
                value={quotaDimension}
                onChange={(event) => {
                  setQuotaDimension(event.target.value);
                  const dimension = dimensions.find((item) => item.variable === event.target.value);
                  if (dimension) {
                    setQuotaCategories(
                      dimension.categories.map((category) => ({
                        category,
                        target_n: quotaCategories.find((item) => item.category === category)?.target_n ?? 100,
                      })),
                    );
                  }
                }}
              >
                <option value="">请选择…</option>
                {dimensions.map((dimension) => (
                  <option key={dimension.variable} value={dimension.variable}>
                    {dimension.variable} — {dimension.label.slice(0, 24)}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="启用配额">
              <Select
                value={quotaEnabled ? 'yes' : 'no'}
                onChange={(event) => setQuotaEnabled(event.target.value === 'yes')}
              >
                <option value="yes">启用</option>
                <option value="no">不启用</option>
              </Select>
            </Field>
          </div>

          <Checkbox
            checked={quotaPreserveStructure}
            onChange={setQuotaPreserveStructure}
            label="保持目标样本结构（平台只提示偏差，不会自动调整目标配额）"
          />

          {quotaCategories.length > 0 && (
            <div>
              <p className="ferp-label">各分类目标数量</p>
              <ul className="space-y-2">
                {quotaCategories.map((category, index) => (
                  <li key={category.category} className="flex items-center gap-2">
                    <span className="min-w-40 flex-1 text-sm text-ink-800">{category.category}</span>
                    <Input
                      className="w-28"
                      type="number"
                      min={1}
                      value={category.target_n}
                      onChange={(event) => {
                        const next = [...quotaCategories];
                        next[index] = { ...category, target_n: Number(event.target.value) };
                        setQuotaCategories(next);
                      }}
                    />
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-xs text-ink-500">
                目标合计：
                <span className="tabular-nums font-medium text-ink-800">
                  {quotaCategories.reduce((sum, item) => sum + (Number.isFinite(item.target_n) ? item.target_n : 0), 0)}
                </span>
                （研究设计中的目标样本量为 {formatNumber(project.target_sample_size)}，两者不必相等，但差异过大时建议核对）
              </p>
            </div>
          )}

          {dimensions.length === 0 && (
            <Alert tone="info" title="没有可用的配额维度">
              配额维度需要是问卷中的单选或下拉题（选项数 2—12）。请先在问卷构建器中添加此类题目。
            </Alert>
          )}
        </div>
      </Modal>
    </div>
  );
}
