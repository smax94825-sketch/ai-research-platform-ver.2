/**
 * Regression coefficient plot (a forest plot of B with its 95% CI whiskers).
 *
 * Chosen over an observed-vs-predicted scatter for a hard reason: neither
 * analysis endpoint returns case-level fitted values or residuals — they return
 * coefficients, fit statistics and aggregate residual diagnostics — so an
 * observed-vs-predicted plot could only be drawn from invented data. The
 * coefficient plot needs exactly what the engine does return, and it is the more
 * informative of the two anyway: it shows the size of each effect, the precision
 * of its estimate (whisker width) and whether the interval crosses zero, all at
 * once.
 *
 * Significance is encoded twice: the marker is filled when the 95% CI excludes
 * zero and hollow when it does not, and the p value is printed in the row.
 */

import type { ReactNode } from 'react';
import { formatPValue, formatStat, truncate } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg, axisTicks } from './primitives';

export interface CoefficientPlotDatum {
  label: string;
  /** Point estimate: B for OLS, the log-odds coefficient for the ordinal model. */
  estimate: number;
  ciLower: number;
  ciUpper: number;
  /** Standardised coefficient, reported in the row when present. */
  beta?: number | null;
  pValue?: number | null;
  vif?: number | null;
  oddsRatio?: number | null;
}

export interface RegressionPlotProps {
  coefficients: CoefficientPlotDatum[];
  /** What the plotted estimate is, e.g. 「非标准化系数 B」. */
  estimateLabel?: string;
  emptyText?: string;
  caption?: ReactNode;
}

const WIDTH = 680;
const ROW_HEIGHT = 48;
const AXIS_HEIGHT = 30;

export function RegressionPlot({
  coefficients,
  estimateLabel = '非标准化系数 B',
  emptyText = '暂无可展示的回归系数。',
  caption,
}: RegressionPlotProps): ReactNode {
  if (coefficients.length === 0) return <ChartEmpty text={emptyText} />;

  const values = coefficients.flatMap((item) => [item.ciLower, item.ciUpper, item.estimate, 0]);
  const dataMin = Math.min(...values);
  const dataMax = Math.max(...values);
  const padding = dataMax === dataMin ? 1 : (dataMax - dataMin) * 0.06;
  const min = dataMin - padding;
  const max = dataMax + padding;
  const scale = (value: number) => ((value - min) / (max - min)) * WIDTH;
  const ticks = axisTicks(min, max, 4);
  const height = 4 + coefficients.length * ROW_HEIGHT + AXIS_HEIGHT;

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={height} label="回归系数森林图（含 95% 置信区间）">
        <line
          x1={scale(0)}
          y1={2}
          x2={scale(0)}
          y2={4 + coefficients.length * ROW_HEIGHT}
          stroke="#8794a9"
          strokeWidth={1}
          strokeDasharray="4 3"
        />
        <text x={scale(0)} y={height - 18} fontSize={FONT_SMALL} fill="#68778e" textAnchor="middle">
          0
        </text>

        {coefficients.map((item, index) => {
          const rowTop = 4 + index * ROW_HEIGHT;
          const mid = rowTop + 30;
          const crossesZero = item.ciLower <= 0 && item.ciUpper >= 0;
          const details = [
            item.beta === null || item.beta === undefined ? null : `β = ${formatStat(item.beta, 3)}`,
            item.oddsRatio === null || item.oddsRatio === undefined
              ? null
              : `OR = ${formatStat(item.oddsRatio, 3)}`,
            item.vif === null || item.vif === undefined ? null : `VIF = ${formatStat(item.vif, 2)}`,
            formatPValue(item.pValue),
          ].filter((part): part is string => part !== null);

          return (
            <g key={`${item.label}-${index}`}>
              <text x={0} y={rowTop + 11} fontSize={FONT} fill="#3a4150">
                {truncate(item.label, 24)}
              </text>
              <text x={WIDTH} y={rowTop + 11} fontSize={FONT_SMALL} fill="#535f74" textAnchor="end">
                {`${formatStat(item.estimate, 3)} [${formatStat(item.ciLower, 3)}, ${formatStat(item.ciUpper, 3)}]`}
              </text>
              <line x1={scale(item.ciLower)} y1={mid} x2={scale(item.ciUpper)} y2={mid} stroke="#1f47f5" strokeWidth={1.5} />
              <line x1={scale(item.ciLower)} y1={mid - 4} x2={scale(item.ciLower)} y2={mid + 4} stroke="#1f47f5" strokeWidth={1.5} />
              <line x1={scale(item.ciUpper)} y1={mid - 4} x2={scale(item.ciUpper)} y2={mid + 4} stroke="#1f47f5" strokeWidth={1.5} />
              <circle
                cx={scale(item.estimate)}
                cy={mid}
                r={4}
                fill={crossesZero ? '#ffffff' : '#1f47f5'}
                stroke="#1f47f5"
                strokeWidth={1.5}
              />
              <text x={0} y={rowTop + 43} fontSize={FONT_SMALL} fill="#68778e">
                {details.join(' · ')}
                {crossesZero ? ' · 95% CI 包含 0（与 0 无显著差异）' : ''}
              </text>
            </g>
          );
        })}

        {ticks.map((tick) => (
          <g key={tick}>
            <line
              x1={scale(tick)}
              y1={4 + coefficients.length * ROW_HEIGHT}
              x2={scale(tick)}
              y2={4 + coefficients.length * ROW_HEIGHT + 4}
              stroke="#b1bac9"
            />
            <text
              x={scale(tick)}
              y={4 + coefficients.length * ROW_HEIGHT + 16}
              fontSize={FONT_SMALL}
              fill="#68778e"
              textAnchor="middle"
            >
              {formatStat(tick, tick % 1 === 0 ? 0 : 2)}
            </text>
          </g>
        ))}
      </ResponsiveSvg>

      <ChartCaption>
        {caption ?? `横轴为${estimateLabel}及其 95% 置信区间；实心点为区间不含 0，空心点为区间包含 0。`}
      </ChartCaption>
    </div>
  );
}
