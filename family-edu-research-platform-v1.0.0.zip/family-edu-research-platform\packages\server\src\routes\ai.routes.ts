/**
 * AI interpretation routes (PHASE 7).
 *
 *   POST /api/projects/:projectId/ai/interpret — interpret the latest bundle
 *   GET  /api/projects/:projectId/ai/latest    — most recent stored interpretation
 *   GET  /api/projects/:projectId/ai/history   — audit trail of every attempt
 *   GET  /api/projects/:projectId/ai/status    — is AI configured, and why not
 *
 * Conventions match the analysis router: `{ data }` envelope, snake_case JSON,
 * Chinese messages, `requireAuth` plus project ownership, and a 400 (not an
 * empty result) when no analysis bundle exists yet.
 *
 * The router deliberately exposes no endpoint that can alter statistics, and it
 * returns the four interpretation layers as separate arrays so a client cannot
 * accidentally present model prose as an engine result.
 */

import { Router } from 'express';

import type { Config, FetchLike } from '../config.js';
import type { Db } from '../db/index.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import { ApiError, asyncHandler } from '../util/errors.js';
import { requireProject } from '../services/project.service.js';
import {
  createAiService,
  getLatestAiInteraction,
  listAiInteractions,
  INTERPRETATION_SECTIONS,
  type InterpretationSection,
} from '../services/ai.service.js';

export interface AiRouterContext {
  db: Db;
  config: Config;
  /** Injection seam: tests pass a deterministic client, production uses config. */
  fetchImpl?: FetchLike;
}

/** Read an optional string field, rejecting wrong types loudly. */
function optionalString(body: Record<string, unknown>, key: string, maxLength: number): string | null {
  const value = body[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string') {
    throw ApiError.validation(`请求体字段 ${key} 必须是字符串。`);
  }
  const trimmed = value.trim();
  if (trimmed === '') return null;
  if (trimmed.length > maxLength) {
    throw ApiError.validation(`请求体字段 ${key} 过长（上限 ${maxLength} 个字符）。`);
  }
  return trimmed;
}

export function createAiRouter(ctx: AiRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  const service = createAiService({
    db: ctx.db,
    config: ctx.config,
    fetchImpl: ctx.fetchImpl,
  });

  /* ---------------------------------------------------------------- */
  /* Status                                                            */
  /* ---------------------------------------------------------------- */

  /**
   * Whether AI interpretation is available, before the researcher clicks.
   *
   * The API key is never echoed; only whether one exists.
   */
  router.get(
    '/:projectId/ai/status',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      res.json({ data: service.status(projectId, researcher.id) });
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Interpretation                                                    */
  /* ---------------------------------------------------------------- */

  /**
   * Interpret the latest statistical bundle.
   *
   * The bundle is the only input: the request body can narrow the *focus* and
   * name a section or hypothesis, but it cannot supply numbers. A statement the
   * model cannot trace back to the bundle is dropped and reported in
   * `rejected_claims` rather than returned.
   */
  router.post(
    '/:projectId/ai/interpret',
    asyncHandler(async (req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const body = (req.body ?? {}) as Record<string, unknown>;

      const section = optionalString(body, 'section', 40);
      if (section !== null && !(INTERPRETATION_SECTIONS as readonly string[]).includes(section)) {
        throw ApiError.validation(
          `未知的解释范围 section：${section}。可用取值：${INTERPRETATION_SECTIONS.join('、')}。`,
        );
      }

      const result = await service.interpret({
        projectId,
        researcherId: researcher.id,
        section: section as InterpretationSection | null,
        hypothesis_code: optionalString(body, 'hypothesis_code', 16),
        focus: optionalString(body, 'focus', 2000),
      });

      res.json({ data: result });
    }),
  );

  /** The most recent interpretation, including one that ran degraded. */
  router.get(
    '/:projectId/ai/latest',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const latest = getLatestAiInteraction(ctx.db, projectId, researcher.id);

      if (!latest) {
        res.json({
          data: {
            available: false,
            reason:
              '该项目还没有任何 AI 解释记录。请先在「统计分析」中运行全部分析，再点击「AI 解释」。',
          },
        });
        return;
      }

      res.json({
        data: {
          available: true,
          id: latest.id,
          mode: latest.mode,
          model: latest.model,
          engine_version: latest.engine_version,
          prompt_hash: latest.prompt_hash,
          prompt_version: latest.prompt_version,
          prompt_tokens: latest.prompt_tokens,
          completion_tokens: latest.completion_tokens,
          total_tokens: latest.total_tokens,
          duration_ms: latest.duration_ms,
          scope: latest.scope,
          statement_count: latest.result?.statement_count ?? 0,
          rejected_claim_count: latest.rejected_count,
          error_code: latest.error_code,
          error_message: latest.error_message,
          created_at: latest.created_at,
          result: latest.result,
        },
      });
    }),
  );

  /**
   * Audit trail: one row per attempt, including failed and degraded ones.
   *
   * The raw provider response is part of the record on purpose — a claim in a
   * report must be checkable against exactly what the model said.
   */
  router.get(
    '/:projectId/ai/history',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const rawLimit = req.query['limit'];
      const limit = typeof rawLimit === 'string' && rawLimit.trim() !== '' ? Number(rawLimit) : 20;
      if (!Number.isFinite(limit) || limit < 1) {
        throw ApiError.validation('limit 必须是正整数（上限 100）。');
      }

      const rows = listAiInteractions(ctx.db, projectId, researcher.id, limit);
      res.json({
        data: rows.map((row) => ({
          id: row.id,
          mode: row.mode,
          model: row.model,
          engine_version: row.engine_version,
          prompt_hash: row.prompt_hash,
          prompt_version: row.prompt_version,
          prompt_tokens: row.prompt_tokens,
          completion_tokens: row.completion_tokens,
          total_tokens: row.total_tokens,
          duration_ms: row.duration_ms,
          scope: row.scope,
          statement_count: row.result?.statement_count ?? 0,
          rejected_claims: row.rejected_claims,
          rejected_claim_count: row.rejected_count,
          error_code: row.error_code,
          error_message: row.error_message,
          raw_response: row.raw_response,
          result: row.result,
          researcher_id: row.researcher_id,
          created_at: row.created_at,
        })),
      });
    }),
  );

  return router;
}
