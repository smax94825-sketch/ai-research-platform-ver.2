/**
 * Research report API tests (PHASE 8).
 *
 * The report is generated from a bundle produced by a real analysis run over a
 * sample collected through the public survey API, so every assertion below is
 * checked against the statistics the platform actually computed.
 *
 * The sample is deliberately larger than the export fixture (46 sessions, still
 * well under the public API's 60-per-15-minutes session limit): the structural
 * validity path runs over the 42 items of the declared scales, and Bartlett's
 * test is only computable when the sample size exceeds p + 1. A smaller sample
 * would make the validity section legitimately unavailable and the χ² assertion
 * below untestable.
 *
 * What these tests are really guarding:
 *  - exactly 23 numbered sections, in a fixed, documented order;
 *  - every number in an available section comes from the bundle;
 *  - a section the platform cannot fill is `available: false` with a Chinese
 *    reason, and its body contains no citation-shaped text at all;
 *  - an `inconclusive` hypothesis is never restated as proof that the variables
 *    are unrelated.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { api, createProject, registerResearcher, type TestContext } from './helpers.js';
import { createPhase8TestContext } from './phase8.harness.js';
import { collectPhase8Sample, runAnalysis, type Phase8Sample } from './phase8.fixture.js';
import type { AnalysisBundle } from '../src/services/analysis.service.js';
import { REPORT_SECTION_ORDER, type ResearchReport } from '../src/services/report.service.js';

/* ================================================================== */
/* Shared fixture                                                     */
/* ================================================================== */

const SAMPLE_SIZE = 46;

let ctx: TestContext;
let owner: string;
let sample: Phase8Sample;
let bundle: AnalysisBundle;
let report: ResearchReport;

before(async () => {
  ctx = await createPhase8TestContext();
  const researcher = await registerResearcher(ctx, { name: '报告测试研究者' });
  owner = researcher.token;

  sample = await collectPhase8Sample(ctx, owner, {
    size: SAMPLE_SIZE,
    seed: 20260816,
    title: '研究报告测试',
    refusalIndex: 7,
    excludeIndex: 0,
  });

  await runAnalysis(ctx, owner, sample.projectId);

  const bundleResponse = await api<AnalysisBundle>(
    ctx,
    'GET',
    `/api/projects/${sample.projectId}/analysis/bundle`,
    { token: owner },
  );
  assert.equal(bundleResponse.status, 200, JSON.stringify(bundleResponse.error));
  bundle = bundleResponse.data;

  const reportResponse = await api<ResearchReport>(ctx, 'GET', `/api/projects/${sample.projectId}/report`, {
    token: owner,
  });
  assert.equal(reportResponse.status, 200, JSON.stringify(reportResponse.error));
  report = reportResponse.data;
});

after(async () => {
  await ctx.close();
});

function section(key: string) {
  const found = report.sections.find((entry) => entry.key === key);
  assert.ok(found, `缺少章节 ${key}`);
  return found!;
}

/** Every finite number stored in the bundle, in the form the report prints it. */
function collectNumbers(value: unknown, into: Set<string>): void {
  if (typeof value === 'number') {
    if (Number.isFinite(value)) into.add(String(value));
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectNumbers(item, into);
    return;
  }
  if (value !== null && typeof value === 'object') {
    for (const item of Object.values(value)) collectNumbers(item, into);
  }
}

/* ================================================================== */
/* Structure                                                          */
/* ================================================================== */

describe('研究报告：结构', () => {
  test('恰好 23 节，编号唯一且升序，顺序与文档一致', () => {
    assert.equal(report.sections.length, 23, '研究报告必须恰好 23 节');
    assert.equal(report.section_count, 23);
    assert.deepEqual(
      report.sections.map((entry) => entry.index),
      Array.from({ length: 23 }, (_, index) => index + 1),
    );
    assert.deepEqual(
      report.sections.map((entry) => entry.key),
      REPORT_SECTION_ORDER.map((entry) => entry.key),
    );
    assert.deepEqual(
      report.sections.map((entry) => entry.title),
      REPORT_SECTION_ORDER.map((entry) => entry.title),
    );

    assert.equal(new Set(report.sections.map((entry) => entry.key)).size, 23, '章节 key 不得重复');
    for (const entry of report.sections) {
      assert.ok(entry.title.length > 0);
      assert.ok(entry.body.length > 0, `${entry.key} 必须有正文`);
      assert.equal(typeof entry.available, 'boolean');
      if (entry.available) {
        assert.equal(entry.unavailable_reason, null, '可用章节不应带未生成原因');
      } else {
        assert.ok(
          entry.unavailable_reason && entry.unavailable_reason.length > 0,
          `${entry.key} 标记为不可用但缺少原因`,
        );
      }
    }

    assert.equal(report.available_sections + report.unavailable_sections, 23);
  });

  test('报告元信息来自结果包，Markdown 与结构化章节同源', () => {
    assert.equal(report.engine_version, bundle.engine_version);
    assert.equal(report.project_id, bundle.project.id);
    assert.equal(report.project_title, bundle.project.title);
    assert.equal(report.analyser_generated_at, bundle.generated_at);
    assert.ok(!Number.isNaN(new Date(report.generated_at).getTime()));
    assert.deepEqual(report.caveats, bundle.caveats, '结果包的解读前提必须原样携带');

    assert.ok(report.markdown.startsWith('# '), 'Markdown 应以一级标题开头');
    assert.ok(report.markdown.includes('## 1. 标题与摘要'));
    assert.ok(report.markdown.includes('## 23. 参考文献与附录'));
    for (const entry of report.sections) {
      assert.ok(
        report.markdown.includes(`## ${entry.index}. ${entry.title}`),
        `Markdown 缺少章节 ${entry.index}`,
      );
    }
    // The rendered form must carry the same bodies, not a re-written summary.
    for (const caveat of bundle.caveats) {
      assert.ok(report.markdown.includes(caveat));
    }
    assert.ok(report.word_count > 1000, `字数统计异常：${report.word_count}`);
  });
});

/* ================================================================== */
/* Numbers come from the bundle                                       */
/* ================================================================== */

describe('研究报告：数字溯源', () => {
  test('每个可用章节的正文都包含结果包中的真实数字', () => {
    // The oracle is the set of numeric *values* the engine stored, stringified
    // exactly as the report stringifies them. A coincidental digit (a section
    // number, a scale point) therefore cannot satisfy the check — the token has
    // to be a value that actually occurs in the bundle.
    const values = new Set<string>();
    collectNumbers(bundle, values);
    assert.ok(values.size > 100, `结果包中的数字过少：${values.size}`);

    const available = report.sections.filter((entry) => entry.available);
    assert.ok(available.length >= 15, `可用章节过少：${available.length}`);

    for (const entry of available) {
      const tokens = entry.body.match(/-?\d+(?:\.\d+)?/g) ?? [];
      assert.ok(tokens.length > 0, `${entry.key} 的正文没有任何数字`);
      const matched = tokens.filter((token) => values.has(token));
      assert.ok(
        matched.length > 0,
        `${entry.key} 的正文没有任何一个数字能在结果包中找到：${tokens.slice(0, 8).join('、')}`,
      );
    }
  });

  test('抽样与样本概况来自结果包的真实计数', () => {
    const sampling = section('sampling');
    assert.equal(sampling.available, true);
    assert.ok(sampling.body.includes(String(bundle.sample.respondents_total)));
    assert.ok(sampling.body.includes(String(bundle.sample.completed)));
    assert.ok(sampling.body.includes(String(bundle.sample.excluded)));
    assert.ok(sampling.body.includes(String(bundle.sample.analysable)));
    for (const source of bundle.sample.sources) {
      assert.ok(sampling.body.includes(`${source.source}：${source.total} 份`), source.source);
    }
    assert.equal(bundle.sample.excluded, 1, '本夹具应排除一份样本');
  });

  test('信度章节给出的是引擎计算的 Cronbach α', () => {
    const reliability = section('reliability');
    assert.equal(reliability.available, true);
    const scored = bundle.reliability.scales.filter((scale) => scale.cronbach_alpha !== null);
    assert.ok(scored.length > 0, '本夹具应能计算量表信度');
    for (const scale of scored) {
      assert.ok(
        reliability.body.includes(String(scale.cronbach_alpha)),
        `缺少 ${scale.scale} 的 α = ${scale.cronbach_alpha}`,
      );
      assert.ok(reliability.body.includes(String(scale.n)));
    }
  });

  test('效度章节报告的 χ² 与结果包完全一致', () => {
    const validity = section('validity');
    assert.equal(validity.available, true);
    const bartlett = bundle.validity.overall_bartlett;
    assert.ok(
      bartlett.chi_square !== null,
      '本样本量应足以计算 Bartlett 球形检验，否则该断言无法验证',
    );
    assert.ok(
      validity.body.includes(`χ² = ${String(bartlett.chi_square)}`),
      `正文未使用结果包的 χ² = ${String(bartlett.chi_square)}`,
    );
    assert.ok(validity.body.includes(String(bartlett.degrees_of_freedom)));
    assert.equal(validity.evidence.find((e) => e.path === 'validity.overall_bartlett.chi_square')?.value, String(bartlett.chi_square));
  });

  test('相关章节报告引擎给出的相关系数', () => {
    const correlation = section('correlation');
    assert.ok(bundle.correlation, '本夹具应能计算相关矩阵');
    assert.equal(correlation.available, true);
    for (const pair of bundle.correlation.pairs.slice(0, 6)) {
      assert.ok(
        correlation.body.includes(String(pair.r)),
        `缺少 ${pair.left}×${pair.right} 的 r = ${String(pair.r)}`,
      );
    }
    assert.ok(correlation.body.includes(bundle.correlation.note), '必须携带结果包的口径说明');
  });

  test('回归章节使用结果包的模型选择与 R²', () => {
    const regression = section('regression');
    assert.equal(regression.available, true);
    assert.ok(bundle.regression, '本夹具应能运行回归');
    assert.ok(regression.body.includes(bundle.regression.auto_selection.model));
    const ols = bundle.regression.ols;
    assert.ok(ols && ols.r_squared !== null, '本夹具应给出线性回归的解释力');
    assert.ok(regression.body.includes(String(ols.r_squared)));
    assert.ok(regression.body.includes(String(ols.f_statistic)));
    assert.ok(regression.body.includes(String(ols.n)));
  });

  test('描述统计表格覆盖结果包中的全部变量', () => {
    const descriptive = section('descriptive');
    assert.equal(descriptive.available, true);
    assert.equal(bundle.descriptive.variables.length > 0, true);
    for (const stats of bundle.descriptive.variables) {
      assert.ok(descriptive.body.includes(`| ${stats.variable} |`), `缺少变量 ${stats.variable}`);
    }
    assert.ok(descriptive.body.includes(bundle.descriptive.note), '必须携带结果包的口径说明');
  });
});

/* ================================================================== */
/* Hypothesis verdicts                                                */
/* ================================================================== */

describe('研究报告：假设检验表述', () => {
  test('假设清单与三态汇总与结果包完全一致', () => {
    const hypotheses = section('hypotheses');
    const tests = section('hypothesis_tests');
    assert.equal(hypotheses.available, true);
    assert.equal(tests.available, true);

    const summary = bundle.hypotheses.summary;
    assert.equal(summary.total, bundle.hypotheses.results.length);

    const tally = `支持 ${summary.supported} 条、方向与假设相反 ${summary.not_supported} 条、证据不足 ${summary.inconclusive} 条、无法检验 ${summary.untestable} 条`;
    assert.ok(hypotheses.body.includes(tally), `假设章节缺少真实汇总：${tally}`);
    assert.ok(tests.body.includes(tally), `假设检验章节缺少真实汇总：${tally}`);

    for (const result of bundle.hypotheses.results) {
      assert.ok(tests.body.includes(result.code), `缺少假设 ${result.code}`);
      assert.ok(tests.body.includes(String(result.r)), `缺少 ${result.code} 的 r`);
      assert.ok(tests.body.includes(String(result.n)), `缺少 ${result.code} 的 n`);
    }
  });

  test('证据不足的假设不会被表述为已证明无关', () => {
    const tests = section('hypothesis_tests');
    const inconclusive = bundle.hypotheses.results.filter(
      (result) => result.verdict === 'inconclusive',
    );
    assert.ok(inconclusive.length > 0, '本夹具应至少产生一条证据不足的假设');
    assert.equal(tests.body.includes('证据不足'), true);

    for (const result of inconclusive) {
      assert.ok(tests.body.includes(result.code));
    }

    // Absence of evidence must never be restated as evidence of absence.
    assert.ok(!tests.body.includes('证明无关'), '不得把证据不足表述为证明无关');
    assert.ok(!tests.body.includes('证明两者无关'));
    assert.ok(!tests.body.includes('证明不相关'));
    assert.ok(
      tests.body.includes('绝不表示已经证明两个变量没有关系'),
      '必须明确说明证据不足不等于没有关系',
    );
  });
});

/* ================================================================== */
/* Honest unavailable sections                                        */
/* ================================================================== */

describe('研究报告：不可用章节的诚实处理', () => {
  test('文献与参考文献两节始终不可用，并给出中文原因', () => {
    const literature = section('literature');
    const references = section('references_appendix');

    for (const entry of [literature, references]) {
      assert.equal(entry.available, false, `${entry.key} 必须标记为不可用`);
      assert.ok(entry.unavailable_reason && entry.unavailable_reason.length > 0);
      assert.ok(/[\u4e00-\u9fff]/.test(entry.unavailable_reason!), '未生成原因必须是中文说明');
      assert.deepEqual(entry.evidence, [], '不可用章节不应声称有数据依据');
    }

    assert.ok(literature.unavailable_reason!.includes('文献'));
    assert.ok(references.unavailable_reason!.includes('参考文献'));
    assert.ok(
      literature.body.includes('研究者') || literature.body.includes('自行'),
      '占位内容必须指明由研究者补充',
    );
  });

  test('不可用章节不含任何形似引用的内容', () => {
    const unavailable = report.sections.filter((entry) => !entry.available);
    assert.ok(unavailable.length >= 2, '至少文献与附录两节应为占位');

    for (const entry of unavailable) {
      const body = entry.body;
      assert.ok(!body.toLowerCase().includes('doi'), `${entry.key} 出现了 DOI 字样`);
      assert.ok(!body.includes('et al.'), `${entry.key} 出现了 et al. 引用格式`);
      assert.ok(!body.includes('等（'), `${entry.key} 出现了中文引用格式`);
      assert.ok(
        !/\(\s*(?:19|20)\d\d[a-z]?\s*\)/.test(body),
        `${entry.key} 出现了年份引用格式`,
      );
      assert.ok(
        !/\d{4}\s*年\s*第\s*\d+\s*期/.test(body),
        `${entry.key} 出现了卷期页码格式`,
      );
      assert.ok(!/pp\.\s*\d+/i.test(body), `${entry.key} 出现了页码格式`);
    }
  });

  test('局限性与结论完整携带结果包的解读前提', () => {
    const limitations = section('limitations');
    const conclusion = section('conclusion');
    assert.equal(limitations.available, true);
    assert.equal(conclusion.available, true);

    for (const caveat of bundle.caveats) {
      assert.ok(limitations.body.includes(caveat), `局限性缺少解读前提：${caveat}`);
    }
    assert.ok(limitations.body.includes(String(bundle.caveats.length)));
    assert.ok(conclusion.body.includes(String(bundle.sample.analysable)));
    assert.ok(conclusion.body.includes('因果'), '结论必须声明相关不等于因果');
  });

  test('建议章节的每一条都附带其数据依据', () => {
    const policy = section('policy_recommendations');
    const service = section('service_recommendations');

    for (const entry of [policy, service]) {
      assert.equal(entry.available, true);
      assert.ok(
        entry.body.includes('不含文献依据'),
        `${entry.key} 必须声明不含文献依据`,
      );
      assert.ok(entry.body.length > 200);
    }

    const psa = bundle.descriptive.variables.find((item) => item.variable === 'PSA');
    assert.ok(psa && psa.mean !== null);
    assert.ok(policy.body.includes(String(psa.mean)), '政策建议必须引用真实均值');
    const dsd = bundle.descriptive.variables.find((item) => item.variable === 'DSD');
    assert.ok(dsd && dsd.mean !== null);
    assert.ok(service.body.includes(String(dsd.mean)), '服务建议必须引用真实均值');
  });
});

/* ================================================================== */
/* Markdown download and access control                               */
/* ================================================================== */

describe('研究报告：下载与访问控制', () => {
  test('Markdown 下载返回可用的纯文本文件', async () => {
    const response = await fetch(`${ctx.baseUrl}/api/projects/${sample.projectId}/report.md`, {
      headers: { authorization: `Bearer ${owner}` },
    });
    assert.equal(response.status, 200);
    assert.ok(response.headers.get('content-type')?.includes('text/markdown'));

    const disposition = response.headers.get('content-disposition') ?? '';
    assert.ok(disposition.startsWith('attachment'));
    assert.ok(disposition.includes('.md'));

    const text = await response.text();
    assert.ok(text.includes('## 23. 参考文献与附录'));
    assert.ok(text.includes(bundle.project.title));
    assert.ok(text.includes(bundle.caveats[0]!));
  });

  test('未登录不能生成报告', async () => {
    const response = await api(ctx, 'GET', `/api/projects/${sample.projectId}/report`);
    assert.equal(response.status, 401);
  });

  test('他人项目不可生成报告', async () => {
    const outsider = await registerResearcher(ctx, { name: '无关报告研究者' });
    for (const path of ['report', 'report.md']) {
      const response = await api(ctx, 'GET', `/api/projects/${sample.projectId}/${path}`, {
        token: outsider.token,
      });
      assert.ok(
        response.status === 403 || response.status === 404,
        `${path} 对他人项目返回了 ${response.status}`,
      );
    }
  });

  test('尚未运行分析时返回 400 并说明应先运行分析', async () => {
    const other = await createProject(ctx, owner, { title: '尚未分析的报告项目' });

    for (const path of ['report', 'report.md']) {
      const response = await fetch(`${ctx.baseUrl}/api/projects/${other.id}/${path}`, {
        headers: { authorization: `Bearer ${owner}` },
      });
      assert.equal(response.status, 400, `${path} 应返回 400`);

      const payload = (await response.json()) as { error: { message: string } };
      assert.ok(
        payload.error.message.includes('运行全部分析'),
        `错误信息应说明下一步操作：${payload.error.message}`,
      );
    }
  });
});
