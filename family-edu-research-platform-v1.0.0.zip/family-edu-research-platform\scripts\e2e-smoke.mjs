/**
 * End-to-end smoke test against a RUNNING server.
 *
 * This is not a replacement for the automated test suites (which build an
 * isolated in-memory app); it verifies the deployed binary — real database file,
 * real HTTP, real JWT, real QR rendering — by walking the exact path a
 * researcher takes on day one.
 *
 * The script is self-contained and idempotent: it registers its own researcher
 * and creates its own project on every run, so it can be executed repeatedly
 * against a long-lived database without depending on prior state.
 *
 * Usage:
 *   node scripts/e2e-smoke.mjs [apiBase]
 *
 * Note: the public survey API rate-limits session creation per client IP. The
 * shipped default (600 per 15 minutes, override with PUBLIC_SESSION_LIMIT) is
 * large enough for repeated runs; if a run does exhaust it, the script reports
 * the limiter's own Chinese message rather than a misleading assertion failure.
 */

const API = process.argv[2] ?? 'http://127.0.0.1:4000';

let passed = 0;
let failed = 0;

function check(label, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`  ✔ ${label}`);
  } else {
    failed += 1;
    console.log(`  ✖ ${label}${detail ? ` — ${detail}` : ''}`);
  }
}

function section(title) {
  console.log(`\n${title}`);
}

async function call(method, path, { token, body, raw } = {}) {
  const headers = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (token) headers.authorization = `Bearer ${token}`;

  const response = await fetch(`${API}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  if (raw) return response;

  const text = await response.text();
  let payload = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    payload = null;
  }
  return { status: response.status, ok: response.ok, data: payload?.data ?? null, error: payload?.error ?? null };
}

async function main() {
  console.log(`家庭教育科研智能研究平台 — 端到端冒烟测试`);
  console.log(`API: ${API}`);

  /* ---------------------------------------------------------------- */
  section('1. 健康检查');
  const health = await call('GET', '/api/health');
  check('GET /api/health 返回 200', health.status === 200, `status=${health.status}`);
  check('服务状态为 ok', health.data?.status === 'ok');
  check('数据库为文件模式', health.data?.database === 'file', String(health.data?.database));

  /* ---------------------------------------------------------------- */
  section('2. 研究者注册与登录');
  const email = `e2e-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@test.local`;
  const password = 'Password123';

  const registered = await call('POST', '/api/auth/register', {
    body: { name: 'E2E 研究者', email, password, affiliation: 'E2E 自动化测试' },
  });
  check('注册研究者账号返回 201', registered.status === 201, registered.error?.message ?? `status=${registered.status}`);

  const weakPassword = await call('POST', '/api/auth/register', {
    body: { name: 'x', email: `weak-${Date.now()}@test.local`, password: '123' },
  });
  check('弱密码被拒绝（400）', weakPassword.status === 400, `status=${weakPassword.status}`);

  const login = await call('POST', '/api/auth/login', { body: { email, password } });
  check('使用注册凭据登录成功', login.status === 200, login.error?.message ?? `status=${login.status}`);
  const token = login.data?.token;
  check('返回 JWT（三段式）', typeof token === 'string' && token.split('.').length === 3);

  const badLogin = await call('POST', '/api/auth/login', { body: { email, password: 'WrongPassword1' } });
  check('错误密码返回 401', badLogin.status === 401);

  const unauth = await call('GET', '/api/projects');
  check('未携带令牌访问受保护接口返回 401', unauth.status === 401);

  const me = await call('GET', '/api/auth/me', { token });
  check('GET /api/auth/me 返回当前研究者', me.data?.email === email);

  /* ---------------------------------------------------------------- */
  section('3. 研究项目与模板问卷');
  const templates = await call('GET', '/api/templates', { token });
  check('读取研究模板', templates.data?.[0]?.key === 'family-edu-v4');
  check('模板包含 58 道题', templates.data?.[0]?.question_count === 58);
  check('模板包含 13 个部分', templates.data?.[0]?.section_count === 13);

  const created = await call('POST', '/api/projects/from-template', { token });
  check('一键创建默认研究设计', created.status === 201, created.error?.message ?? `status=${created.status}`);
  check('创建时载入 58 道题', created.data?.seeded_questions === 58, String(created.data?.seeded_questions));

  const project = created.data?.project;
  check('包含 H1—H8 八条假设', project?.hypotheses?.length === 8, String(project?.hypotheses?.length));
  check(
    '研究假设均以「未检验」状态创建（不预设结论）',
    (project?.hypotheses ?? []).every((h) => h.status === 'untested'),
  );
  check('目标样本量为 1000', project?.target_sample_size === 1000, String(project?.target_sample_size));
  check('研究问题不少于 8 条', (project?.research_questions?.length ?? 0) >= 8);

  const detail = await call('GET', `/api/projects/${project.id}`, { token });
  const questionnaire = detail.data.questionnaires[0];
  check('项目详情包含问卷', Boolean(questionnaire), 'questionnaires 为空');
  check('问卷版本为 V4.0', questionnaire?.version === 'V4.0', String(questionnaire?.version));

  /* ---------------------------------------------------------------- */
  section('4. 问卷构建器');
  const builder = await call('GET', `/api/questionnaires/${questionnaire.id}/builder`, { token });
  check('构建器返回 58 道题', builder.data?.questions?.length === 58, String(builder.data?.questions?.length));
  check('构建器处于可编辑状态', builder.data?.editable === true);
  check('下一题号为 Q59', builder.data?.suggested_next_code === 'Q59', String(builder.data?.suggested_next_code));

  const types = new Set((builder.data?.questions ?? []).map((q) => q.question_type));
  for (const type of ['single', 'multiple', 'likert', 'matrix', 'knowledge_test']) {
    check(`包含题型 ${type}`, types.has(type));
  }

  const q35 = builder.data.questions.find((q) => q.question_code === 'Q35');
  check('Q35 为 7 行矩阵题', q35?.options?.matrix?.rows?.length === 7, String(q35?.options?.matrix?.rows?.length));

  const q32 = builder.data.questions.find((q) => q.question_code === 'Q32');
  const refusal = q32?.options?.choices?.find((c) => c.sensitiveNonResponse);
  check('Q32 含敏感拒答选项', refusal?.label === '不愿回答', String(refusal?.label));
  check('Q32 非必答', q32?.required === false);

  /* ---------------------------------------------------------------- */
  section('5. 条件跳转逻辑');
  const logic = await call('GET', `/api/questionnaires/${questionnaire.id}/logic`, { token });
  const skip = (logic.data?.rules ?? []).find((r) => r.question_code === 'Q39');
  check('Q39 声明了跳转规则', Boolean(skip), '未找到 Q39 规则');
  check('跳转描述可读且指向 Q41', /IF Q39/.test(skip?.description ?? '') && /Q41/.test(skip?.description ?? ''), skip?.description);
  check('逻辑校验无错误', (logic.data?.issues ?? []).filter((i) => i.severity === 'error').length === 0);

  const previewSkip = await call('POST', `/api/questionnaires/${questionnaire.id}/preview`, {
    token,
    body: { answers: { Q39: '1' } },
  });
  check('选择「从未使用」后跳过 Q40', !previewSkip.data.answered_path.includes('Q40'));
  check('跳过后进入 Q41', previewSkip.data.answered_path.includes('Q41'));

  const previewLaw = await call('POST', `/api/questionnaires/${questionnaire.id}/preview`, {
    token,
    body: { answers: { Q10: '1' } },
  });
  check(
    '未听说过法律时隐藏 Q11',
    !previewLaw.data.visible.some((q) => q.question_code === 'Q11'),
  );

  const previewDefault = await call('POST', `/api/questionnaires/${questionnaire.id}/preview`, {
    token,
    body: { answers: {} },
  });
  check('默认路径覆盖全部 58 题', previewDefault.data.answered_path.length === 58);

  /* ---------------------------------------------------------------- */
  section('6. 变量字典');
  const dict = await call('GET', `/api/questionnaires/${questionnaire.id}/dictionary`, { token });
  const names = new Set((dict.data?.dictionary ?? []).map((d) => d.variable_name));
  for (const variable of ['FEI', 'FEK', 'LSK', 'LKA', 'ISC', 'FSE', 'FPB', 'FED', 'FIU', 'PSA', 'STI', 'DSD', 'WTP', 'UI', 'QN']) {
    check(`字典包含核心变量 ${variable}`, names.has(variable));
  }
  const lkaRow = (dict.data?.dictionary ?? []).find((d) => d.variable_name === 'LKA');
  check('LKA 为派生变量且可追溯到 Q12—Q16', lkaRow?.is_derived === true && /Q12/.test(lkaRow?.question_code ?? ''));

  const csv = await call('GET', `/api/questionnaires/${questionnaire.id}/dictionary?format=csv`, { token, raw: true });
  const csvBytes = new Uint8Array(await csv.arrayBuffer());
  check('CSV 导出成功', csv.status === 200);
  check(
    'CSV 带 UTF-8 BOM（Excel 中文兼容）',
    csvBytes[0] === 0xef && csvBytes[1] === 0xbb && csvBytes[2] === 0xbf,
    Array.from(csvBytes.slice(0, 3)).join(','),
  );

  /* ---------------------------------------------------------------- */
  section('7. 发布与分享');
  const publish = await call('POST', `/api/questionnaires/${questionnaire.id}/publish`, { token });
  check('发布成功', publish.status === 200, publish.error?.message ?? `status=${publish.status}`);
  check('状态变为 published', publish.data?.questionnaire?.status === 'published');
  check('问卷被锁定', publish.data?.questionnaire?.locked === true);

  const shareToken = publish.data?.share_token;
  check('生成分享令牌', typeof shareToken === 'string' && shareToken.length >= 16);

  const locked = await call('PATCH', `/api/questions/${builder.data.questions[0].id}`, {
    token,
    body: { question_text: '发布后修改' },
  });
  check('发布后拒绝修改题目（423）', locked.status === 423, `status=${locked.status}`);

  /* ---------------------------------------------------------------- */
  section('8. 公开问卷接口与二维码');
  const publicMeta = await call('GET', `/api/public/survey/${shareToken}`);
  check('公开接口无需登录即可读取问卷元信息', publicMeta.status === 200);
  check('公开接口声明可接收作答', publicMeta.data?.accepting_responses === true);

  const qr = await call('GET', `/api/public/survey/${shareToken}/qrcode?format=svg`, { raw: true });
  const qrText = await qr.text();
  check('二维码返回 SVG', qr.status === 200 && qrText.includes('<svg'), `status=${qr.status}`);
  check('SVG 带有方形模块矩阵 viewBox', /viewBox="0 0 (\d+) \1"/.test(qrText), qrText.slice(0, 120));
  // A real QR payload is a long module path; a placeholder image would not be.
  const modulePathLength = Math.max(
    0,
    ...(qrText.match(/d="[^"]*"/g) ?? []).map((value) => value.length),
  );
  check('二维码包含完整模块数据', modulePathLength > 200, `longest d=${modulePathLength}`);

  // Same token must be stable, so a printed code keeps working.
  const qrAgain = await call('GET', `/api/public/survey/${shareToken}/qrcode?format=svg`, { raw: true });
  check('同一令牌的二维码可复现', (await qrAgain.text()) === qrText);

  const qrPng = await call('GET', `/api/public/survey/${shareToken}/qrcode?format=png`, { raw: true });
  const pngBytes = new Uint8Array(await qrPng.arrayBuffer());
  check(
    '二维码支持 PNG 输出',
    pngBytes[0] === 0x89 && pngBytes[1] === 0x50 && pngBytes[2] === 0x4e && pngBytes[3] === 0x47,
  );

  const badToken = await call('GET', '/api/public/survey/not-a-real-token');
  check('无效分享令牌返回 404', badToken.status === 404);

  /* ---------------------------------------------------------------- */
  section('9. 仪表盘（真实数据，无样本时为真零值）');
  const dash = await call('GET', `/api/dashboard?project_id=${project.id}`, { token });
  check('仪表盘返回 200', dash.status === 200);
  check('尚未开始收集时如实标记', dash.data?.collection_started === false);
  check('总样本为 0（不产生模拟数据）', dash.data?.sample?.total === 0);
  check('有效率为 null 而非 0', dash.data?.sample?.valid_rate === null);
  check('问卷统计为 58 题', dash.data?.questionnaire?.question_count === 58);
  check(
    '给出「尚未收集样本」的事实说明',
    /尚未收集到任何样本/.test(dash.data?.findings?.[0]?.text ?? ''),
    dash.data?.findings?.[0]?.text,
  );

  /* ---------------------------------------------------------------- */
  section('10. 数据隔离');
  const other = await call('POST', '/api/auth/register', {
    body: {
      name: 'E2E 隔离测试',
      email: `e2e-isolation-${Date.now()}@test.local`,
      password: 'Password123',
    },
  });
  check('注册第二个研究者账号', other.status === 201, other.error?.message ?? `status=${other.status}`);

  const crossRead = await call('GET', `/api/projects/${project.id}`, { token: other.data.token });
  check('他人项目返回 404（不泄露存在性）', crossRead.status === 404, `status=${crossRead.status}`);

  const crossDash = await call('GET', `/api/dashboard?project_id=${project.id}`, { token: other.data.token });
  check('他人仪表盘返回 404', crossDash.status === 404);

  const ownList = await call('GET', '/api/projects', { token: other.data.token });
  check('新账号看不到他人项目', ownList.data?.total === 0, `total=${ownList.data?.total}`);

  /* ---------------------------------------------------------------- */
  section('11. 版本控制闭环');
  const newVersion = await call('POST', `/api/questionnaires/${questionnaire.id}/versions`, {
    token,
    body: { kind: 'minor' },
  });
  check('建立新版本成功', newVersion.status === 201, newVersion.error?.message ?? `status=${newVersion.status}`);
  check('版本号递增为 V4.1', newVersion.data?.version === 'V4.1', String(newVersion.data?.version));

  const v2Builder = await call('GET', `/api/questionnaires/${newVersion.data.id}/builder`, { token });
  check('新版本克隆 58 道题', v2Builder.data?.questions?.length === 58);
  check('新版本可编辑', v2Builder.data?.editable === true);

  const added = await call('POST', `/api/questionnaires/${newVersion.data.id}/questions`, {
    token,
    body: {
      question_text: 'E2E 新增题目',
      question_type: 'textarea',
      options: { maxLength: 200 },
      required: false,
    },
  });
  check('可向新版本添加题目', added.status === 201, added.error?.message ?? `status=${added.status}`);
  check('新题号自动生成为 Q59', added.data?.question_code === 'Q59', String(added.data?.question_code));

  const cleanUp = await call('DELETE', `/api/questions/${added.data.id}`, { token });
  check('可删除新增题目', cleanUp.status === 200);

  const v2Publish = await call('POST', `/api/questionnaires/${newVersion.data.id}/publish`, { token });
  check('新版本可独立发布', v2Publish.status === 200, v2Publish.error?.message ?? `status=${v2Publish.status}`);
  check('新版本获得独立分享令牌', v2Publish.data?.share_token !== shareToken);

  const v2Qr = await call('GET', `/api/public/survey/${v2Publish.data.share_token}/qrcode?format=svg`, {
    raw: true,
  });
  check('不同令牌编码出不同二维码（说明二维码确实承载链接）', (await v2Qr.text()) !== qrText);

  /* ---------------------------------------------------------------- */
  section('12. PHASE 3：受访者作答闭环（公开接口）');
  const collectionProject = await call('POST', '/api/projects/from-template', { token });
  const collectionQuestionnaire = (
    await call('GET', `/api/projects/${collectionProject.data.project.id}`, { token })
  ).data.questionnaires[0];
  const collectionShare = (
    await call('POST', `/api/questionnaires/${collectionQuestionnaire.id}/publish`, { token })
  ).data.share_token;
  check('为采集测试创建并发布问卷', typeof collectionShare === 'string' && collectionShare.length > 10);

  const publicInstrument = await call('GET', `/api/public/survey/${collectionShare}/instrument`);
  check('公开接口返回完整问卷', publicInstrument.data?.questions?.length === 58);
  check('公开接口返回知情同意文本', /匿名/.test(publicInstrument.data?.consent_text ?? ''));
  check('公开接口返回伦理要点', (publicInstrument.data?.ethics_points?.length ?? 0) >= 3);
  check('公开接口无需登录即可访问', publicInstrument.status === 200);

  const session1 = await call('POST', `/api/public/survey/${collectionShare}/sessions`, {
    body: { source: 'wechat' },
  });
  check('开启作答会话', session1.status === 201, session1.error?.message ?? `status=${session1.status}`);
  check('分配匿名编号 A0001', session1.data?.respondent?.anonymous_id === 'A0001', String(session1.data?.respondent?.anonymous_id));
  check('记录来源渠道 wechat', session1.data?.respondent?.source === 'wechat');
  check('记录知情同意时间', Boolean(session1.data?.respondent?.consent_given_at));

  const sessionToken = session1.data.session_token;

  // 走真实作答路径：每次保存后由服务端告知哪些题目被隐藏
  const instrumentQuestions = publicInstrument.data.questions;
  const byCode = new Map(instrumentQuestions.map((q) => [q.question_code, q]));
  function firstValidAnswer(question) {
    const target = byCode.get(question.question_code);
    if (question.question_type === 'matrix') {
      return Object.fromEntries(
        target.options.matrix.rows.map((row) => [row.value, target.options.matrix.columns[0].value]),
      );
    }
    if (question.question_type === 'textarea' || question.question_type === 'text') return '端到端测试作答';
    if (question.question_type === 'number') return 1;
    if (question.question_type === 'multiple') return [target.options.choices[0].value];
    return target.options.choices[0].value;
  }

  let answered = 0;
  let prunedSeen = 0;
  for (let guard = 0; guard < 200; guard += 1) {
    const state = await call('GET', `/api/public/sessions/${sessionToken}`);
    const hidden = new Set(state.data.hidden_question_codes);
    const answers = state.data.answers;
    const next = instrumentQuestions.find(
      (q) => q.question_type !== 'page_break' && q.required && !hidden.has(q.question_code) && answers[q.question_code] === undefined,
    );
    if (!next) break;
    const saved = await call('PATCH', `/api/public/sessions/${sessionToken}/answers`, {
      body: { question_code: next.question_code, value: firstValidAnswer(next) },
    });
    if (saved.status !== 200) {
      check(`保存 ${next.question_code}`, false, JSON.stringify(saved.error));
      break;
    }
    prunedSeen += saved.data.pruned_question_codes.length;
    answered += 1;
  }

  check('可逐题自动保存作答', answered === 53, `实际保存 ${answered} 题`);
  check('跳过的题目未被作答（Q11/Q40）', prunedSeen === 0);

  // 敏感题 Q32 按设计为非必答，因此不在必答题遍历中。这里显式选择「不愿回答」，
  // 验证拒答被作为独立的缺失编码保存，而不是被并入「从未」。
  const sensitiveSave = await call('PATCH', `/api/public/sessions/${sessionToken}/answers`, {
    body: { question_code: 'Q32', value: '5' },
  });
  check('敏感题可选择「不愿回答」', sensitiveSave.status === 200, JSON.stringify(sensitiveSave.error));
  check('拒答以原始代码 5 保存（未被改写为 0）', sensitiveSave.data?.stored === '5', String(sensitiveSave.data?.stored));
  const totalSaved = answered + 1;

  const hiddenState = await call('GET', `/api/public/sessions/${sessionToken}`);
  check('Q11 在默认路径下被隐藏', hiddenState.data.hidden_question_codes.includes('Q11'));
  check('Q40 在默认路径下被跳过', hiddenState.data.hidden_question_codes.includes('Q40'));

  const bypass = await call('PATCH', `/api/public/sessions/${sessionToken}/answers`, {
    body: { question_code: 'Q40', value: '1' },
  });
  check('无法通过接口直接作答被跳过的题目', bypass.status === 400, `status=${bypass.status}`);

  const badOption = await call('PATCH', `/api/public/sessions/${sessionToken}/answers`, {
    body: { question_code: 'Q1', value: '99' },
  });
  check('无法写入不存在的选项代码', badOption.status === 400);

  const resumed = await call('GET', `/api/public/sessions/${sessionToken}`);
  check('刷新后可恢复全部作答', Object.keys(resumed.data.answers).length === totalSaved, `${Object.keys(resumed.data.answers).length} vs ${totalSaved}`);

  const submitted = await call('POST', `/api/public/sessions/${sessionToken}/complete`, { body: {} });
  check('提交问卷成功', submitted.status === 200, submitted.error?.message ?? `status=${submitted.status}`);
  check('状态变为已完成', submitted.data?.respondent?.status === 'completed');
  check('记录作答用时', typeof submitted.data?.respondent?.duration_seconds === 'number');

  const resubmit = await call('PATCH', `/api/public/sessions/${sessionToken}/answers`, {
    body: { question_code: 'Q1', value: '2' },
  });
  check('提交后拒绝修改作答（409）', resubmit.status === 409, `status=${resubmit.status}`);

  // 第二份样本：不同渠道，用于渠道统计
  const session2 = await call('POST', `/api/public/survey/${collectionShare}/sessions`, {
    body: { source: 'school' },
  });
  check('第二份样本获得递增编号 A0002', session2.data?.respondent?.anonymous_id === 'A0002');

  // 非法来源被规范化
  const session3 = await call('POST', `/api/public/survey/${collectionShare}/sessions`, {
    body: { source: '<script>alert(1)</script>' },
  });
  check('非法来源被规范化为 direct', session3.data?.respondent?.source === 'direct', String(session3.data?.respondent?.source));

  /* ---------------------------------------------------------------- */
  section('13. PHASE 3：样本管理与渠道统计');
  const sampleList = await call(
    'GET',
    `/api/projects/${collectionProject.data.project.id}/respondents?limit=10`,
    { token },
  );
  check('样本列表返回已收集样本', sampleList.data?.total === 3, `total=${sampleList.data?.total}`);
  check('汇总已完成样本数', sampleList.data?.summary?.completed === 1);
  check('汇总进行中样本数', sampleList.data?.summary?.in_progress === 2);
  check('列出匿名编号与来源', sampleList.data?.items?.[0]?.anonymous_id?.startsWith('A'));

  const completedOnly = await call(
    'GET',
    `/api/projects/${collectionProject.data.project.id}/respondents?status=completed`,
    { token },
  );
  check('可按状态筛选已完成样本', completedOnly.data?.total === 1);

  const wechatOnly = await call(
    'GET',
    `/api/projects/${collectionProject.data.project.id}/respondents?source=wechat`,
    { token },
  );
  check('可按来源筛选样本', wechatOnly.data?.total === 1);

  const sampleDetail = await call('GET', `/api/respondents/${session1.data.respondent.id}`, { token });
  check('样本详情返回作答明细', (sampleDetail.data?.answered_count ?? 0) === totalSaved, `${sampleDetail.data?.answered_count} vs ${totalSaved}`);
  const q39 = sampleDetail.data.responses.find((r) => r.question_code === 'Q39');
  check('作答代码解析为可读选项文本', typeof q39?.answer_label === 'string' && q39.answer_label.length > 0, String(q39?.answer_label));
  const sensitiveRow = sampleDetail.data.responses.find((r) => r.question_code === 'Q32');
  check('敏感题出现在作答明细中', Boolean(sensitiveRow), '未找到 Q32');
  check(
    '敏感拒答在详情中被明确标注（不会与「从未」混淆）',
    /不愿回答/.test(sensitiveRow?.answer_label ?? '') && /敏感拒答/.test(sensitiveRow?.answer_label ?? ''),
    String(sensitiveRow?.answer_label),
  );
  check('详情列出未被展示的题目', (sampleDetail.data?.hidden_question_codes?.length ?? 0) === 2);

  const sourceStats = await call('GET', `/api/projects/${collectionProject.data.project.id}/sources`, { token });
  const bySource = new Map((sourceStats.data?.items ?? []).map((item) => [item.source, item]));
  check('渠道统计包含 wechat', bySource.get('wechat')?.total === 1);
  check('渠道统计包含 school', bySource.get('school')?.total === 1);
  check('渠道统计包含 direct', bySource.get('direct')?.total === 1);
  check('渠道完成率正确（wechat 100%）', bySource.get('wechat')?.completion_rate === 100);
  check('未完成渠道完成率为 0', bySource.get('school')?.completion_rate === 0);

  const review = await call('POST', `/api/respondents/${session1.data.respondent.id}/review`, {
    token,
    body: { status: 'accepted', note: '端到端测试：作答完整' },
  });
  check('研究者可标记样本为已采用', review.status === 200 && review.data?.review_status === 'accepted');

  const excludeWithoutNote = await call('POST', `/api/respondents/${session2.data.respondent.id}/review`, {
    token,
    body: { status: 'excluded' },
  });
  check('排除样本时强制要求填写原因', excludeWithoutNote.status === 400);

  const excludeWithNote = await call('POST', `/api/respondents/${session2.data.respondent.id}/review`, {
    token,
    body: { status: 'excluded', note: '端到端测试：标记为排除' },
  });
  check('填写原因后可排除样本', excludeWithNote.status === 200);

  const stillStored = await call('GET', `/api/respondents/${session2.data.respondent.id}`, { token });
  check('排除后样本数据仍然保留（平台不自动删除）', stillStored.status === 200 && stillStored.data?.respondent?.review_status === 'excluded');

  const sweep = await call('POST', `/api/projects/${collectionProject.data.project.id}/respondents/sweep`, {
    token,
    body: { older_than_hours: 24 },
  });
  check('超时样本标记接口可用', sweep.status === 200 && sweep.data?.marked === 0);

  const collectionDashboard = await call(
    'GET',
    `/api/dashboard?project_id=${collectionProject.data.project.id}`,
    { token },
  );
  check('仪表盘反映真实采集数据', collectionDashboard.data?.collection_started === true);
  check('仪表盘样本总数与采集一致', collectionDashboard.data?.sample?.total === 3, String(collectionDashboard.data?.sample?.total));
  check('仪表盘已完成样本数为 1', collectionDashboard.data?.sample?.completed === 1);
  const stageDist = collectionDashboard.data?.distributions?.find((d) => d.variable_name === 'STAGE');
  check('仪表盘按真实作答计算分布', stageDist?.n === 1, `n=${stageDist?.n}`);
  check('分布守恒：n + 缺失 + 敏感拒答 = 分析基数', stageDist ? stageDist.n + stageDist.missing + stageDist.sensitive_nonresponse === stageDist.base_n : false);

  const crossResearcher = await call('GET', `/api/projects/${collectionProject.data.project.id}/respondents`, {
    token: other.data.token,
  });
  check('他人无法读取该项目样本（404）', crossResearcher.status === 404, `status=${crossResearcher.status}`);

  /* ---------------------------------------------------------------- */
  section('14. PHASE 4：数据质量检测引擎');

  const ruleCatalogue = await call('GET', `/api/projects/${collectionProject.data.project.id}/quality/rules`, {
    token,
  });
  check('质量规则目录可读取', ruleCatalogue.status === 200);
  check(
    '规则目录覆盖规格要求的检测项',
    ['SUSPICIOUS_SPEED', 'LONG_STRING', 'HIGH_MISSING', 'SUBJECTIVE_OBJECTIVE_DISCREPANCY', 'DUPLICATE_SUBMISSION'].every(
      (code) => (ruleCatalogue.data ?? []).some((rule) => rule.code === code),
    ),
  );
  check(
    '每条规则都附带检测说明、解读与扣分权重',
    (ruleCatalogue.data ?? []).every(
      (rule) =>
        rule.description?.length > 10 && rule.interpretation?.length > 10 && rule.score_impact > 0,
    ),
  );

  const qualityReport = await call('GET', `/api/projects/${collectionProject.data.project.id}/quality`, {
    token,
  });
  check('质量报告可读取', qualityReport.status === 200);
  check('已对提交的样本评分', qualityReport.data?.scored_respondents >= 1, `scored=${qualityReport.data?.scored_respondents}`);
  check('引擎版本已记录', qualityReport.data?.engine_version === '1.0.0');
  check('报告声明评分不构成剔除依据', /不构成剔除依据/.test(qualityReport.data?.thresholds_note ?? ''));

  const submittedSampleQuality = await call('GET', `/api/respondents/${session1.data.respondent.id}/quality`, {
    token,
  });
  check('单样本质量评分可读取', submittedSampleQuality.status === 200);
  check('样本带有质量评分', typeof submittedSampleQuality.data?.score === 'number');
  // 端到端脚本在数秒内完成了 53 道题，因此这是一份真实的"完成时间过短"样本。
  check(
    '机器快速填写被真实检出为完成时间过短',
    (submittedSampleQuality.data?.flags ?? []).some((flag) => flag.rule_code === 'SUSPICIOUS_SPEED'),
    JSON.stringify((submittedSampleQuality.data?.flags ?? []).map((f) => f.rule_code)),
  );
  check(
    '每条标记都带有可核对的证据',
    (submittedSampleQuality.data?.flags ?? []).every((flag) => Object.keys(flag.evidence ?? {}).length > 0),
  );

  const samplesBeforeRecompute = Number(
    (await call('GET', `/api/projects/${collectionProject.data.project.id}/respondents`, { token })).data?.total ?? 0,
  );
  const recompute1 = await call('POST', `/api/projects/${collectionProject.data.project.id}/quality/recompute`, {
    token,
  });
  const recompute2 = await call('POST', `/api/projects/${collectionProject.data.project.id}/quality/recompute`, {
    token,
  });
  check('质量检测可重新运行', recompute1.status === 200 && recompute2.status === 200);
  check(
    '重算可复现（标记数与规则分布一致）',
    recompute1.data?.flags_written === recompute2.data?.flags_written &&
      JSON.stringify(recompute1.data?.rule_counts) === JSON.stringify(recompute2.data?.rule_counts),
  );
  const samplesAfterRecompute = Number(
    (await call('GET', `/api/projects/${collectionProject.data.project.id}/respondents`, { token })).data?.total ?? 0,
  );
  check('重算质量不会删除样本', samplesAfterRecompute === samplesBeforeRecompute, `${samplesBeforeRecompute} -> ${samplesAfterRecompute}`);

  const answersStillThere = await call('GET', `/api/respondents/${session1.data.respondent.id}`, { token });
  check('重算质量不会改动作答', answersStillThere.data?.answered_count === totalSaved);

  const flaggedFilter = await call(
    'GET',
    `/api/projects/${collectionProject.data.project.id}/respondents?flagged_only=true`,
    { token },
  );
  check('可按"已被标记"筛选样本', (flaggedFilter.data?.total ?? 0) >= 1, `total=${flaggedFilter.data?.total}`);

  /* ---------------------------------------------------------------- */
  section('15. PHASE 4：样本配额与动态收集建议');

  const quotaStatus = await call('GET', `/api/projects/${collectionProject.data.project.id}/quota`, {
    token,
  });
  check('配额状态可读取', quotaStatus.status === 200);
  check('模板项目自带配额维度 STAGE', quotaStatus.data?.dimension_variable === 'STAGE');
  check('配额维度对应题目为 Q4', quotaStatus.data?.dimension_question_code === 'Q4');
  check('配额目标总量为 1000', quotaStatus.data?.progress?.total_target === 1000);
  check(
    '仅已完成且未排除的样本计入配额',
    quotaStatus.data?.progress?.total_current === 1,
    `current=${quotaStatus.data?.progress?.total_current}（1 份完成、2 份进行中）`,
  );
  check('统计口径在响应中说明', /Q4/.test(quotaStatus.data?.counting_note ?? ''));
  check('产生了收集建议', (quotaStatus.data?.recommendations ?? []).length >= 1);
  const shortfallAdvice = (quotaStatus.data?.recommendations ?? []).find((item) => item.kind === 'quota_shortfall');
  check('给出分类缺口建议', Boolean(shortfallAdvice));
  check(
    '建议附带可核对的证据',
    (shortfallAdvice?.evidence ?? []).length >= 2,
    JSON.stringify(shortfallAdvice?.evidence ?? []),
  );

  const quotaDimensions = await call(
    'GET',
    `/api/projects/${collectionProject.data.project.id}/quota/dimensions`,
    { token },
  );
  check('可列出可用配额维度', quotaDimensions.status === 200 && (quotaDimensions.data ?? []).length >= 2);
  check(
    '教育阶段可作为配额维度且分类正确',
    JSON.stringify(
      (quotaDimensions.data ?? []).find((item) => item.variable === 'STAGE')?.categories ?? [],
    ) === JSON.stringify(['学前（0—6岁）', '小学', '初中', '高中']),
  );

  const badQuota = await call('PUT', `/api/projects/${collectionProject.data.project.id}/quota`, {
    token,
    body: {
      quota_config: {
        enabled: true,
        preserve_structure: true,
        categories: [{ dimension: 'STAGE', category: '小学', target_n: 0 }],
      },
    },
  });
  check('非法配额目标数量被拒绝', badQuota.status === 400, `status=${badQuota.status}`);

  const updatedQuota = await call('PUT', `/api/projects/${collectionProject.data.project.id}/quota`, {
    token,
    body: {
      quota_config: {
        enabled: true,
        preserve_structure: true,
        categories: [
          { dimension: 'STAGE', category: '学前（0—6岁）', target_n: 2 },
          { dimension: 'STAGE', category: '小学', target_n: 3 },
        ],
      },
    },
  });
  check('可更新配额配置', updatedQuota.status === 200);
  check('配额更新后立即重算进度', updatedQuota.data?.progress?.total_target === 5);
  const preschool = (updatedQuota.data?.progress?.items ?? []).find((item) => item.category === '学前（0—6岁）');
  check('已有样本被正确计入分类', preschool?.current_n === 1, `学前 current=${preschool?.current_n}`);
  check('未达标分类被标记', preschool?.met === false);

  const clearedQuota = await call('PUT', `/api/projects/${collectionProject.data.project.id}/quota`, {
    token,
    body: { quota_config: null },
  });
  check('可清除配额配置', clearedQuota.status === 200 && clearedQuota.data?.enabled === false);

  /* ---------------------------------------------------------------- */
  section('16. PHASE 5：统计分析引擎（真实样本 → 统计结果 → 结果包）');
  // A separate template-based project is used here because the analysis engine
  // materialises the derived constructs (FSE, DSD, UI …) only for a template-
  // derived instrument, and because section 12 answers every question with the
  // FIRST option — data with no variance, which the engine is right to refuse.
  const analysisProject = await call('POST', '/api/projects/from-template', { token });
  const analysisProjectId = analysisProject.data.project.id;
  const analysisQuestionnaire = (
    await call('GET', `/api/projects/${analysisProjectId}`, { token })
  ).data.questionnaires[0];
  const analysisShare = (
    await call('POST', `/api/questionnaires/${analysisQuestionnaire.id}/publish`, { token })
  ).data.share_token;

  const analysisInstrument = await call('GET', `/api/public/survey/${analysisShare}/instrument`);
  const analysisQuestions = analysisInstrument.data.questions;
  const analysisByCode = new Map(analysisQuestions.map((q) => [q.question_code, q]));

  /** Choices that carry a score — the 5-point scales — in questionnaire order. */
  function scoredChoices(question) {
    const choices = analysisByCode.get(question.question_code)?.options?.choices ?? [];
    const scored = choices.filter((choice) => typeof choice.score === 'number');
    return scored.length > 0 ? scored : choices;
  }

  /** FNV-1a — a stable hash so the "random" answers are identical on every run. */
  function hashString(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash >>> 0;
  }

  /** xorshift32 — deterministic, and good enough to decorrelate answer choices. */
  function pseudoRandom(seed) {
    let x = seed || 1;
    x ^= x << 13;
    x >>>= 0;
    x ^= x >>> 17;
    x ^= x << 5;
    return (x >>> 0) / 4294967296;
  }

  /**
   * Pick an answer option.
   *
   * Two independent components: a respondent-level tendency (so different
   * constructs are genuinely correlated, as they are for real people) and an
   * item-specific jitter. Without the jitter every construct would be a
   * deterministic function of the respondent index, which makes the design
   * matrix exactly collinear — the engine refuses such data, and it is right to.
   */
  function choiceIndexFor(respondentIndex, key, count) {
    const tendency = Math.floor(pseudoRandom(hashString(`tendency:${respondentIndex}`)) * count);
    const jitter = Math.floor(pseudoRandom(hashString(`${respondentIndex}:${key}`)) * count);
    return (tendency + jitter) % count;
  }

  /**
   * Vary the answer by respondent and by question.
   * The engine can only report relationships that exist in the data, so an
   * end-to-end test that always picks the first option proves nothing.
   */
  function variedAnswer(question, respondentIndex) {
    const target = analysisByCode.get(question.question_code);
    const code = question.question_code;
    if (question.question_type === 'matrix') {
      const matrix = target.options.matrix;
      return Object.fromEntries(
        matrix.rows.map((row) => [
          row.value,
          matrix.columns[choiceIndexFor(respondentIndex, `${code}:${row.value}`, matrix.columns.length)]
            .value,
        ]),
      );
    }
    if (question.question_type === 'textarea' || question.question_type === 'text') {
      return `端到端统计分析测试作答 ${respondentIndex}`;
    }
    if (question.question_type === 'number') {
      return 1 + Math.floor(pseudoRandom(hashString(`${respondentIndex}:${code}`)) * 5);
    }
    const scored = scoredChoices(question);
    if (scored.length === 0) return '1';
    const index = choiceIndexFor(respondentIndex, code, scored.length);
    if (question.question_type === 'multiple') return [scored[index].value];
    return scored[index].value;
  }

  // Kept small so the script stays fast and so the public API's per-IP session
  // limiter is never the thing under test; a large sample would fail on the
  // limiter rather than on a real defect.
  const ANALYSIS_RESPONDENTS = 12;
  const analysisAnswers = [];

  for (let index = 0; index < ANALYSIS_RESPONDENTS; index += 1) {
    const session = await call('POST', `/api/public/survey/${analysisShare}/sessions`, {
      body: { source: index % 2 === 0 ? 'wechat' : 'school' },
    });
    if (session.status !== 201) {
      check(`开启第 ${index + 1} 份分析样本会话`, false, session.error?.message ?? `status=${session.status}`);
      break;
    }
    const sessionToken = session.data.session_token;
    const sent = {};
    let exhausted = false;

    for (let guard = 0; guard < 200; guard += 1) {
      const state = await call('GET', `/api/public/sessions/${sessionToken}`);
      const hidden = new Set(state.data.hidden_question_codes);
      const answers = state.data.answers;
      const next = analysisQuestions.find(
        (q) =>
          q.question_type !== 'page_break' &&
          q.required &&
          !hidden.has(q.question_code) &&
          answers[q.question_code] === undefined,
      );
      if (!next) break;
      const value = variedAnswer(next, index);
      const saved = await call('PATCH', `/api/public/sessions/${sessionToken}/answers`, {
        body: { question_code: next.question_code, value },
      });
      if (saved.status !== 200) {
        check(`保存分析样本 ${next.question_code}`, false, JSON.stringify(saved.error));
        exhausted = true;
        break;
      }
      sent[next.question_code] = value;
      if (guard === 199) exhausted = true;
    }
    if (exhausted) break;

    const completed = await call('POST', `/api/public/sessions/${sessionToken}/complete`, { body: {} });
    if (completed.status !== 200) {
      check(`提交第 ${index + 1} 份分析样本`, false, JSON.stringify(completed.error));
      break;
    }
    analysisAnswers.push(sent);
  }

  check(
    `采集 ${ANALYSIS_RESPONDENTS} 份有变异的分析样本`,
    analysisAnswers.length === ANALYSIS_RESPONDENTS,
    `实际 ${analysisAnswers.length}`,
  );

  const analysisDataset = await call('GET', `/api/projects/${analysisProjectId}/analysis/dataset`, { token });
  check('分析数据集接口返回 200', analysisDataset.status === 200, analysisDataset.error?.message ?? '');
  check('分析样本量等于采集数量', analysisDataset.data?.sample?.analysable === ANALYSIS_RESPONDENTS);
  check('无样本被排除', analysisDataset.data?.sample?.excluded === 0);
  const analysisVarNames = (analysisDataset.data?.variables ?? []).map((v) => v.name);
  check(
    '派生构念 FSE / DSD / UI / WTP 已物化',
    ['FSE', 'DSD', 'UI', 'WTP'].every((name) => analysisVarNames.includes(name)),
    analysisVarNames.filter((n) => ['FSE', 'DSD', 'UI', 'WTP'].includes(n)).join(','),
  );
  check('默认回归因变量为 UI，且可用', analysisDataset.data?.available?.regression_dependent === 'UI');
  check(
    '默认相关变量集全部可用',
    JSON.stringify(analysisDataset.data?.available?.correlation_variables ?? []) ===
      JSON.stringify(['FSE', 'FED', 'PSA', 'STI', 'DSD', 'UI', 'WTP']),
    JSON.stringify(analysisDataset.data?.available?.correlation_variables ?? []),
  );

  const descriptive = await call('GET', `/api/projects/${analysisProjectId}/analysis/descriptive`, { token });
  check('描述统计接口返回 200', descriptive.status === 200, descriptive.error?.message ?? '');
  check('描述统计的 n 与样本量一致', descriptive.data?.n_respondents === ANALYSIS_RESPONDENTS);
  const feiStats = (descriptive.data?.variables ?? []).find((v) => v.variable === 'FEI');
  check('描述统计包含派生构念 FEI', Boolean(feiStats));
  check('有效作答数等于样本量，缺失为 0', feiStats?.n === ANALYSIS_RESPONDENTS && feiStats?.missing === 0);

  // Cross-check the engine against the answers this script actually sent: the FEI
  // construct is the mean of Q6—Q8, so it must equal the mean of the scores of
  // those three answers. This is the strongest available end-to-end check that
  // scoring, aggregation and statistics agree with the raw input.
  function scoreOf(code, value) {
    const choices = analysisByCode.get(code)?.options?.choices ?? [];
    const position = choices.findIndex((choice) => String(choice.value) === String(value));
    if (position === -1) return null;
    const choice = choices[position];
    const score = typeof choice.score === 'number' ? choice.score : position + 1;
    return choice.sensitiveNonResponse ? null : score;
  }
  const feiPerRespondent = [];
  for (const sent of analysisAnswers) {
    const items = ['Q6', 'Q7', 'Q8'].map((code) => scoreOf(code, sent[code]));
    if (items.some((value) => value === null)) continue;
    feiPerRespondent.push(items.reduce((sum, value) => sum + value, 0) / items.length);
  }
  const expectedFei = feiPerRespondent.reduce((sum, value) => sum + value, 0) / feiPerRespondent.length;
  check(
    '派生构念 FEI 的均值与原始作答逐项重算一致',
    Math.abs((feiStats?.mean ?? -1) - expectedFei) < 0.001,
    `接口 ${feiStats?.mean} vs 重算 ${expectedFei.toFixed(4)}`,
  );

  const stageStats = (descriptive.data?.variables ?? []).find((v) => v.variable === 'STAGE');
  check(
    '有序变量（学段）给出可解释的集中趋势',
    typeof stageStats?.mean === 'number' && stageStats.mean >= 1 && stageStats.mean <= 4,
    `mean=${stageStats?.mean}`,
  );
  check('给出分组频数', (stageStats?.frequencies ?? []).length === 4);
  check(
    '分组频数覆盖全部有效样本',
    (stageStats?.frequencies ?? []).reduce((sum, row) => sum + row.count, 0) === ANALYSIS_RESPONDENTS,
  );

  // The measurement-level rule must hold wherever it applies: a variable the
  // engine classifies as nominal is never given a mean, regardless of which
  // question produced it.
  const nominalVariables = (analysisDataset.data?.variables ?? []).filter((v) => v.data_type === 'nominal');
  const descriptiveByVariable = new Map(
    (descriptive.data?.variables ?? []).map((v) => [v.variable, v]),
  );
  check(
    `名义变量一律不报告均值（本次 ${nominalVariables.length} 个）`,
    nominalVariables.every((v) => descriptiveByVariable.get(v.name)?.mean === null),
    nominalVariables
      .filter((v) => descriptiveByVariable.get(v.name)?.mean !== null)
      .map((v) => v.name)
      .join(','),
  );

  const reliability = await call('GET', `/api/projects/${analysisProjectId}/analysis/reliability`, { token });
  const fseReliability = (reliability.data?.scales ?? []).find((scale) => scale.scale === 'FSE');
  check('信度接口返回 200 并解析出量表', reliability.status === 200 && (reliability.data?.scales ?? []).length > 0);
  check('FSE 量表包含 9 个条目', fseReliability?.k === 9, String(fseReliability?.k));
  check('计算了 Cronbach α', typeof fseReliability?.cronbach_alpha === 'number');
  check(
    'α 的判定阈值随结果一并给出',
    (fseReliability?.alpha_reference?.excellent ?? 0) > (fseReliability?.alpha_reference?.good ?? 0),
  );
  check(
    '条目层面给出校正后题总相关',
    (fseReliability?.items ?? []).every((item) => typeof item.item_total_correlation === 'number'),
  );

  const validity = await call('GET', `/api/projects/${analysisProjectId}/analysis/validity`, { token });
  check('效度接口返回 200', validity.status === 200);
  // With a small sample the overall Bartlett test can legitimately be
  // unavailable; what must never happen is a silently missing field or a
  // fabricated statistic. Either a real χ² is returned, or the report says why.
  const overallBartlett = validity.data?.overall_bartlett;
  check(
    '整体 Bartlett 球形检验：给出统计量，或明确说明为何无法计算',
    Boolean(overallBartlett) &&
      (typeof overallBartlett.chi_square === 'number' ||
        (overallBartlett.chi_square === null &&
          /无法计算|不可用|行列式/.test(overallBartlett.interpretation ?? ''))),
    JSON.stringify(overallBartlett)?.slice(0, 140),
  );
  check('给出整体 KMO', 'overall_kmo' in (validity.data ?? {}));
  check('给出逐量表的探索性因素分析', (validity.data?.scale_efa ?? []).length > 0);
  check('效度报告附带方法学说明', (validity.data?.note ?? '').length > 0);

  const correlation = await call('GET', `/api/projects/${analysisProjectId}/analysis/correlation`, { token });
  check('相关分析接口返回 200', correlation.status === 200);
  check('相关变量集符合研究设计', correlation.data?.variables?.length === 7);
  const corrDiagOk = (correlation.data?.matrix ?? []).every((row, i) => row[i] === 1);
  check('相关矩阵对角线为 1', corrDiagOk);
  const corrInRange = (correlation.data?.matrix ?? [])
    .flat()
    .every((value) => value === null || (value >= -1 && value <= 1));
  check('相关系数全部落在 [-1,1]', corrInRange);
  check('各配对均给出显著性 p 值', (correlation.data?.pairs ?? []).length > 0);

  // Method selection must follow the measurement levels actually in the dataset:
  // Pearson only when BOTH variables are interval/ratio, Spearman otherwise.
  const dataTypeOf = new Map((analysisDataset.data?.variables ?? []).map((v) => [v.name, v.data_type]));
  const continuousTypes = new Set(['interval', 'ratio']);
  const methodDisagreements = (correlation.data?.pairs ?? []).filter((pair) => {
    const expected =
      continuousTypes.has(dataTypeOf.get(pair.left)) && continuousTypes.has(dataTypeOf.get(pair.right))
        ? 'pearson'
        : 'spearman';
    return pair.method !== expected;
  });
  check(
    '相关系数方法严格按测量层次选择',
    methodDisagreements.length === 0,
    methodDisagreements
      .slice(0, 3)
      .map((p) => `${p.left}×${p.right}: ${p.method}（应为 ${continuousTypes.has(dataTypeOf.get(p.left)) && continuousTypes.has(dataTypeOf.get(p.right)) ? 'pearson' : 'spearman'}）`)
      .join('; '),
  );
  check(
    '配对样本量与变量类型一致（不超过有效样本）',
    (correlation.data?.pairs ?? []).every((pair) => pair.n > 0 && pair.n <= ANALYSIS_RESPONDENTS),
  );

  const regression = await call('GET', `/api/projects/${analysisProjectId}/analysis/regression`, { token });
  check('回归接口返回 200', regression.status === 200);
  // The auto-selection must match the measurement level the dataset reports for
  // UI, and must explain itself either way.
  const uiType = dataTypeOf.get('UI');
  check(
    '估计方法自动选择与因变量的测量层次一致',
    regression.data?.auto_selection?.model === (uiType === 'ordinal' ? 'ordinal_logit' : 'ols'),
    `UI 类型 ${uiType}，选择 ${regression.data?.auto_selection?.model}`,
  );
  check('说明选择该估计方法的理由', (regression.data?.auto_selection?.reason ?? '').length > 0);
  check('始终给出 OLS 结果供对照', Boolean(regression.data?.ols));
  check(
    'OLS 的 n 与整例删除数之和等于分析样本量',
    regression.data?.ols?.n + regression.data?.ols?.dropped_cases === ANALYSIS_RESPONDENTS,
    `n=${regression.data?.ols?.n} dropped=${regression.data?.ols?.dropped_cases}`,
  );
  check(
    'OLS 自变量顺序符合研究设计',
    JSON.stringify((regression.data?.ols?.coefficients ?? []).map((c) => c.term)) ===
      JSON.stringify(['(常量)', 'DSD', 'STI', 'PSA', 'FSE', 'FED']),
    JSON.stringify((regression.data?.ols?.coefficients ?? []).map((c) => c.term)),
  );
  check(
    'OLS 报告 VIF 与标准化系数',
    (regression.data?.ols?.coefficients ?? []).slice(1).every((c) => typeof c.vif === 'number' && c.beta !== undefined),
  );
  check(
    'OLS 报告 Durbin-Watson 与残差诊断',
    typeof regression.data?.ols?.diagnostics?.durbin_watson === 'number' &&
      typeof regression.data?.ols?.diagnostics?.residual_skewness === 'number',
  );
  check(
    'R² 落在 [0,1]',
    regression.data?.ols?.r_squared === null ||
      (regression.data.ols.r_squared >= 0 && regression.data.ols.r_squared <= 1),
  );
  if (uiType === 'ordinal') {
    check('有序因变量给出比例优势模型', Boolean(regression.data?.ordinal));
    check(
      '有序模型给出递增的阈值',
      (regression.data?.ordinal?.thresholds ?? []).length >= 2 &&
        (regression.data?.ordinal?.thresholds ?? []).every(
          (t, i, arr) => i === 0 || t.threshold > arr[i - 1].threshold,
        ),
    );
    check('有序模型报告是否收敛', typeof regression.data?.ordinal?.converged === 'boolean');
    check('检验了比例优势假设', Boolean(regression.data?.ordinal?.proportional_odds_test?.interpretation));
  } else {
    check('因变量为等距测量时不强行拟合有序模型', regression.data?.ordinal === null);
  }
  check('明确说明以哪个模型为主要结论', /有序|线性/.test(regression.data?.recommendation ?? ''));

  const comparisons = await call('GET', `/api/projects/${analysisProjectId}/analysis/comparisons`, { token });
  check('组间差异接口返回 200', comparisons.status === 200);
  check('按要求比较 FED / UI / WTP', JSON.stringify((comparisons.data?.comparisons ?? []).map((c) => c.dependent)) === JSON.stringify(['FED', 'UI', 'WTP']));
  check(
    '每个因变量同时给出参数与非参数结果',
    (comparisons.data?.comparisons ?? []).every((c) => c.anova && c.kruskal_wallis),
  );
  check(
    '给出前置假设筛查与推荐理由',
    (comparisons.data?.comparisons ?? []).every((c) => c.screening.length > 0 && c.recommendation_reason.length > 0),
  );
  const fedComparison = (comparisons.data?.comparisons ?? []).find((c) => c.dependent === 'FED');
  check(
    '方差分析的分组样本量合计等于有效样本',
    (fedComparison?.anova?.groups ?? []).reduce((sum, g) => sum + g.n, 0) === ANALYSIS_RESPONDENTS,
  );
  const postHocGroups = fedComparison?.anova?.groups ?? [];
  // The engine only runs a pairwise Welch test when both groups have at least 3
  // cases (a Welch test on n = 2 has about one degree of freedom and is
  // meaningless), so the expected number of pairs follows from the group sizes.
  const eligiblePairs =
    postHocGroups.filter((group) => group.n >= 3).length *
    Math.max(0, postHocGroups.filter((group) => group.n >= 3).length - 1) /
    2;
  check(
    '事后比较覆盖所有可检验的组对（两组均需 ≥3 例）',
    (fedComparison?.anova?.post_hoc ?? []).length === eligiblePairs,
    `post_hoc=${(fedComparison?.anova?.post_hoc ?? []).length} 期望=${eligiblePairs} groups=${postHocGroups.map((g) => g.n).join('/')}`,
  );
  const homogeneity = fedComparison?.anova?.homogeneity;
  check(
    '方差齐性检验覆盖全部组；无法计算时说明原因并建议非参数结论',
    homogeneity === null
      ? (fedComparison?.anova?.warnings ?? []).some((warning) => /Levene|方差不齐性检验/.test(warning))
      : typeof homogeneity.statistic === 'number' && homogeneity.degrees_of_freedom === postHocGroups.length - 1,
    JSON.stringify(homogeneity)?.slice(0, 120),
  );

  const hypotheses = await call('GET', `/api/projects/${analysisProjectId}/analysis/hypotheses`, { token });
  check('假设检验接口返回 200', hypotheses.status === 200);
  check('逐条检验 H1—H8', (hypotheses.data?.results ?? []).length === 8);
  check(
    '每条假设的结论落在三态之内',
    (hypotheses.data?.results ?? []).every((r) =>
      ['supported', 'not_supported', 'inconclusive', 'untestable'].includes(r.verdict),
    ),
  );
  check(
    '结论与显著性一致（有结论则 p < 0.05，证据不足则 p ≥ 0.05）',
    (hypotheses.data?.results ?? []).every((r) => {
      if (r.verdict === 'untestable') return true;
      const decisive = r.verdict === 'supported' || r.verdict === 'not_supported';
      return decisive === (r.p_value < 0.05);
    }),
    (hypotheses.data?.results ?? [])
      .filter((r) => {
        if (r.verdict === 'untestable') return false;
        const decisive = r.verdict === 'supported' || r.verdict === 'not_supported';
        return decisive !== (r.p_value < 0.05);
      })
      .map((r) => `${r.code}:${r.verdict}/p=${r.p_value}`)
      .join(','),
  );
  check(
    '每条假设附带统计方法与留痕证据',
    (hypotheses.data?.results ?? []).every((r) => r.method.length > 0 && r.evidence.length > 0),
  );
  const hypothesisSummary = hypotheses.data?.summary ?? {};
  check(
    '结论统计与逐条结果一致',
    hypothesisSummary.total === 8 &&
      hypothesisSummary.supported + hypothesisSummary.not_supported + hypothesisSummary.inconclusive + hypothesisSummary.untestable === 8,
  );
  check('提示多重比较问题', /多重比较/.test(hypotheses.data?.note ?? ''));

  const bundleRun = await call('POST', `/api/projects/${analysisProjectId}/analysis/run`, { token });
  check('运行全部分析返回结果包', bundleRun.status === 200, bundleRun.error?.message ?? '');
  check('结果包带引擎版本', typeof bundleRun.data?.engine_version === 'string' && bundleRun.data.engine_version.length > 0);
  check('结果包包含描述统计/信度/效度/相关/回归/组间/假设七类结果',
    Boolean(bundleRun.data?.descriptive) &&
      Boolean(bundleRun.data?.reliability) &&
      Boolean(bundleRun.data?.validity) &&
      Boolean(bundleRun.data?.correlation) &&
      Boolean(bundleRun.data?.regression) &&
      (bundleRun.data?.comparisons ?? []).length === 3 &&
      (bundleRun.data?.hypotheses?.results ?? []).length === 8,
  );
  check('结果包携带解读前提（不少于 3 条）', (bundleRun.data?.caveats ?? []).length >= 3);
  check(
    '解读前提声明了缺失处理方式',
    (bundleRun.data?.caveats ?? []).some((c) => /缺失|整例/.test(c)),
  );
  check(
    '解读前提声明相关不等于因果',
    (bundleRun.data?.caveats ?? []).some((c) => /因果/.test(c)),
  );

  const storedBundle = await call('GET', `/api/projects/${analysisProjectId}/analysis/bundle`, { token });
  check('可读取已持久化的结果包', storedBundle.data?.available === true);
  check(
    '读取到的是同一份结果包（时间戳一致）',
    storedBundle.data?.generated_at === bundleRun.data?.generated_at,
  );

  const rerun = await call('POST', `/api/projects/${analysisProjectId}/analysis/run`, { token });
  check(
    '重复运行结果完全一致（统计口径可复现）',
    JSON.stringify(rerun.data?.descriptive) === JSON.stringify(bundleRun.data?.descriptive) &&
      JSON.stringify(rerun.data?.regression) === JSON.stringify(bundleRun.data?.regression),
  );

  const analysisHistory = await call('GET', `/api/projects/${analysisProjectId}/analysis/history`, { token });
  const historyTypes = new Set((analysisHistory.data ?? []).map((row) => row.analysis_type));
  check(
    '分析历史留痕包含每一类分析与结果包',
    ['descriptive', 'reliability', 'validity', 'correlation', 'regression', 'group_comparison', 'hypothesis_testing', 'bundle'].every(
      (type) => historyTypes.has(type),
    ),
    [...historyTypes].join(','),
  );

  const analysisUnauth = await call('GET', `/api/projects/${analysisProjectId}/analysis/descriptive`);
  check('未登录不可读取统计分析结果', analysisUnauth.status === 401);
  const analysisForeign = await call('GET', `/api/projects/${analysisProjectId}/analysis/descriptive`, {
    token: other.data.token,
  });
  check(
    '他人无法访问该项目的统计分析结果',
    analysisForeign.status === 403 || analysisForeign.status === 404,
    `status=${analysisForeign.status}`,
  );

  /* ---------------------------------------------------------------- */
  section('17. PHASE 7：AI 研究助手（无密钥时如实降级，且不编造数字）');

  const aiStatus = await call('GET', `/api/projects/${analysisProjectId}/ai/status`, { token });
  check('AI 状态接口返回 200', aiStatus.status === 200, aiStatus.error?.message ?? '');
  check('如实报告未配置 API 密钥', aiStatus.data?.configured === false, JSON.stringify(aiStatus.data?.configured));
  check('降级模式被明确标注', aiStatus.data?.mode === 'degraded', String(aiStatus.data?.mode));
  check('说明降级原因', (aiStatus.data?.reason ?? '').length > 0);
  check('确认已有可解释的统计结果包', aiStatus.data?.has_bundle === true);
  check('状态接口不回显密钥', !JSON.stringify(aiStatus.data ?? {}).toLowerCase().includes('sk-'));

  const aiInterpret = await call('POST', `/api/projects/${analysisProjectId}/ai/interpret`, {
    token,
    body: {},
  });
  check('AI 解释接口返回 200（而非 500）', aiInterpret.status === 200, aiInterpret.error?.message ?? '');
  check('无密钥时返回降级结果', aiInterpret.data?.mode === 'degraded', String(aiInterpret.data?.mode));
  check('降级结果说明 AI 不可用及原因', Boolean(aiInterpret.data?.ai_unavailable?.code ?? aiInterpret.data?.ai_unavailable));
  check(
    '降级摘要明确标注由统计引擎生成而非模型生成',
    aiInterpret.data?.engine_summary?.derived_by === 'statistical_engine' &&
      aiInterpret.data?.engine_summary?.ai_generated === false,
    JSON.stringify(aiInterpret.data?.engine_summary ?? {}).slice(0, 120),
  );
  check(
    '降级摘要正文非空',
    (aiInterpret.data?.engine_summary?.text ?? '').length > 100,
    `长度 ${(aiInterpret.data?.engine_summary?.text ?? '').length}`,
  );
  check(
    'AI 不可用时不给出来自模型的「解释」与「建议」（不伪装成模型输出）',
    (aiInterpret.data?.layers?.interpretations ?? []).length === 0 &&
      (aiInterpret.data?.layers?.recommendations ?? []).length === 0,
  );
  check('四层结构在响应中彼此独立', Boolean(aiInterpret.data?.layers) && Array.isArray(aiInterpret.data?.layers?.facts));
  check('携带结果包的解读前提', (aiInterpret.data?.caveats ?? []).length >= 3);
  check('未产生被拦截的编造数字', (aiInterpret.data?.rejected_claims ?? []).length === 0);

  const aiLatest = await call('GET', `/api/projects/${analysisProjectId}/ai/latest`, { token });
  check('可读取最近一次 AI 交互', aiLatest.status === 200 && aiLatest.data?.available === true);
  const aiHistory = await call('GET', `/api/projects/${analysisProjectId}/ai/history`, { token });
  check(
    'AI 交互有审计留痕（含模式与结果包版本）',
    (aiHistory.data ?? []).length >= 1 && (aiHistory.data ?? [])[0]?.mode === 'degraded',
    JSON.stringify((aiHistory.data ?? [])[0] ?? {}).slice(0, 140),
  );

  /* ---------------------------------------------------------------- */
  section('18. PHASE 8：研究报告与数据导出');

  const report = await call('GET', `/api/projects/${analysisProjectId}/report`, { token });
  check('研究报告接口返回 200', report.status === 200, report.error?.message ?? '');
  const sections = report.data?.sections ?? [];
  check('报告恰好包含 23 个章节', sections.length === 23, `实际 ${sections.length}`);
  check(
    '章节编号为 1—23 且连续递增',
    JSON.stringify(sections.map((section) => section.index)) ===
      JSON.stringify(Array.from({ length: 23 }, (_, i) => i + 1)),
  );
  check(
    '每个章节都带有可用性标记与证据',
    sections.every((section) => typeof section.available === 'boolean' && Array.isArray(section.evidence)),
  );
  check(
    '不可用章节必须给出中文原因，而不是空白章节',
    sections
      .filter((section) => section.available === false)
      .every((section) => (section.unavailable_reason ?? '').length > 0),
    sections.filter((s) => s.available === false && !(s.unavailable_reason ?? '').length).map((s) => s.key).join(','),
  );
  check(
    '文献与参考文献章节如不可用，则不得出现形似引用的内容',
    sections
      .filter((section) => section.available === false)
      .every((section) => !/doi|et al\.|\(\d{4}[a-z]?\)/i.test(section.body ?? '')),
  );
  check('报告统计了可用与不可用章节数', typeof report.data?.available_sections === 'number' && typeof report.data?.unavailable_sections === 'number');
  check('报告给出字数统计', typeof report.data?.word_count === 'number' && report.data.word_count > 200);
  check('报告携带结果包的解读前提', (report.data?.caveats ?? []).length >= 3);
  check(
    '报告的 Markdown 正文非空且包含章节标题',
    typeof report.data?.markdown === 'string' && report.data.markdown.length > 1000,
  );

  const reportMd = await call('GET', `/api/projects/${analysisProjectId}/report.md`, { token, raw: true });
  check('Markdown 报告可下载', reportMd.status === 200);
  check(
    '下载响应声明为 Markdown 附件',
    /text\/markdown/.test(reportMd.headers.get('content-type') ?? '') &&
      /attachment/.test(reportMd.headers.get('content-disposition') ?? ''),
    reportMd.headers.get('content-disposition') ?? '',
  );
  check(
    '中文文件名使用 RFC 5987 编码（不出现乱码文件名）',
    /filename\*=UTF-8''/i.test(reportMd.headers.get('content-disposition') ?? ''),
    reportMd.headers.get('content-disposition') ?? '',
  );

  const datasetCsvResponse = await call('GET', `/api/projects/${analysisProjectId}/export/dataset.csv`, { token, raw: true });
  const datasetCsvBytes = new Uint8Array(await datasetCsvResponse.arrayBuffer());
  check('CSV 导出返回 200', datasetCsvResponse.status === 200);
  check(
    'CSV 带 UTF-8 BOM（Excel 打开中文不乱码）',
    datasetCsvBytes[0] === 0xef && datasetCsvBytes[1] === 0xbb && datasetCsvBytes[2] === 0xbf,
    `前 3 字节 ${datasetCsvBytes[0]},${datasetCsvBytes[1]},${datasetCsvBytes[2]}`,
  );
  const datasetCsvText = new TextDecoder('utf-8').decode(datasetCsvBytes);
  const datasetCsvLines = datasetCsvText.replace(/^\uFEFF/, '').trimEnd().split('\n');
  check('CSV 表头以 respondent_id 开头', datasetCsvLines[0]?.startsWith('respondent_id'), datasetCsvLines[0]?.slice(0, 40));
  check(
    'CSV 行数等于有效样本数 + 表头',
    datasetCsvLines.length === ANALYSIS_RESPONDENTS + 1,
    `行数 ${datasetCsvLines.length}`,
  );
  check('CSV 以附件形式下载', /attachment/.test(datasetCsvResponse.headers.get('content-disposition') ?? ''));

  const jsonResponse = await call('GET', `/api/projects/${analysisProjectId}/export/dataset.json`, { token, raw: true });
  const jsonExport = JSON.parse(await jsonResponse.text());
  check('JSON 导出返回 200', jsonResponse.status === 200);
  check(
    'JSON 分别报告总样本量与导出样本量（不会把筛选样本当成全样本）',
    jsonExport?.metadata?.respondents_exported === ANALYSIS_RESPONDENTS &&
      typeof jsonExport?.metadata?.respondents_total === 'number',
    JSON.stringify(jsonExport?.metadata ?? {}).slice(0, 160),
  );
  check('JSON 含变量字典', Object.keys(jsonExport?.codebook ?? {}).length > 0 || Array.isArray(jsonExport?.codebook));

  const codebookResponse = await call('GET', `/api/projects/${analysisProjectId}/export/codebook.csv`, { token, raw: true });
  const codebookBytes = new Uint8Array(await codebookResponse.arrayBuffer());
  check('变量字典 CSV 返回 200 且带 BOM', codebookResponse.status === 200 && codebookBytes[0] === 0xef);
  check(
    '变量字典包含变量名与题号列（表头用 ASCII 便于统计软件直接读取）',
    /Variable Name/.test(new TextDecoder('utf-8').decode(codebookBytes)) &&
      /Question Code/.test(new TextDecoder('utf-8').decode(codebookBytes)),
    new TextDecoder('utf-8').decode(codebookBytes).slice(0, 80).replace(/\n/g, ' | '),
  );

  const spssResponse = await call('GET', `/api/projects/${analysisProjectId}/export/spss`, { token, raw: true });
  const spssBytes = new Uint8Array(await spssResponse.arrayBuffer());
  check('SPSS 导出返回 200', spssResponse.status === 200);
  check(
    'SPSS 导出为 ZIP 归档（PK 魔数）',
    spssBytes[0] === 0x50 && spssBytes[1] === 0x4b,
    `前 2 字节 ${spssBytes[0]},${spssBytes[1]}`,
  );
  const spssSyntax = await call('GET', `/api/projects/${analysisProjectId}/export/spss/syntax`, { token, raw: true });
  const syntaxText = await spssSyntax.text();
  check('可单独下载 SPSS 语法文件', spssSyntax.status === 200);
  check(
    'SPSS 语法包含 GET DATA 与 EXECUTE，且只声明 SYSMIS 缺失码',
    /GET DATA/.test(syntaxText) &&
      /EXECUTE\./.test(syntaxText) &&
      /SYSMIS/.test(syntaxText) &&
      !/MISSING VALUES[^.]*\b(99|-1)\b/.test(syntaxText),
  );

  const xlsxResponse = await call('GET', `/api/projects/${analysisProjectId}/export/results.xlsx`, { token, raw: true });
  const xlsxBytes = new Uint8Array(await xlsxResponse.arrayBuffer());
  check('Excel 导出返回 200', xlsxResponse.status === 200);
  check(
    'Excel 为真实 xlsx（PK 魔数）且内容非空',
    xlsxBytes[0] === 0x50 && xlsxBytes[1] === 0x4b && xlsxBytes.length > 5000,
    `长度 ${xlsxBytes.length}`,
  );

  /* ---------------------------------------------------------------- */
  section('19. PHASE 9：创业竞赛分析（有界推断，拒绝编造市场数字）');

  const competitionRun = await call('POST', `/api/projects/${analysisProjectId}/competition/run`, {
    token,
    body: {},
  });
  check('生成创业洞察返回 200', competitionRun.status === 200, competitionRun.error?.message ?? '');
  const blocks = competitionRun.data?.blocks ?? [];
  check('包含九个分析区块', blocks.length === 9, `实际 ${blocks.length}`);
  check(
    '每个区块都带有中文标题、可用性标记与原因字段',
    blocks.every(
      (block) =>
        typeof block.title === 'string' &&
        block.title.length > 0 &&
        typeof block.available === 'boolean' &&
        'reason' in block,
    ),
  );
  check(
    '不可用区块给出中文原因，且不携带结构化数据',
    blocks
      .filter((block) => block.available === false)
      .every((block) => (block.reason ?? '').length > 0 && block.data === null),
    blocks.filter((b) => b.available === false && (!(b.reason ?? '').length || b.data !== null)).map((b) => b.key).join(','),
  );
  check(
    '可用区块附带可追溯的证据路径与取值',
    blocks
      .filter((block) => block.available === true)
      .every((block) => (block.evidence ?? []).length > 0 && (block.evidence ?? []).every((item) => typeof item.path === 'string')),
    blocks.filter((b) => b.available === true && (b.evidence ?? []).length === 0).map((b) => b.key).join(','),
  );
  check('标注可用区块数量', typeof competitionRun.data?.blocks_available === 'number');
  check(
    '四条必备前提全部声明（非概率抽样 / 非因果 / 声称付费意愿≠购买行为 / 当前接受度≠未来采用）',
    ['非概率', '因果', '付费意愿', '接受度'].every((keyword) =>
      (competitionRun.data?.caveats ?? []).some((caveat) => caveat.includes(keyword)),
    ),
    JSON.stringify((competitionRun.data?.caveats ?? []).slice(0, 4)).slice(0, 240),
  );

  const marketBlock = blocks.find((block) => block.key === 'market_opportunity');
  if (marketBlock) {
    check(
      '市场机会区块明确标注为「仅来自本次样本」的推断',
      /样本/.test(marketBlock.narrative ?? '') &&
        typeof (marketBlock.data?.inference_label ?? marketBlock.inference_label) === 'string' &&
        (marketBlock.data?.inference_label ?? marketBlock.inference_label).length > 0,
      JSON.stringify(marketBlock.data?.inference_label ?? marketBlock.inference_label ?? null),
    );
    check(
      '市场容量估算被明确拒绝：不给出金额与币种，而不是填 0',
      marketBlock.data?.market_size_estimate?.available === false &&
        marketBlock.data?.market_size_estimate?.amount === null &&
        marketBlock.data?.market_size_estimate?.currency === null,
      JSON.stringify(marketBlock.data?.market_size_estimate ?? {}).slice(0, 160),
    );
  } else {
    check('市场机会区块存在', false, '未找到 market_opportunity');
  }

  const competitionReport = await call('GET', `/api/projects/${analysisProjectId}/competition/report`, { token });
  check('可读取已持久化的创业洞察报告', competitionReport.data?.available === true);
  check(
    '读取到的是同一次运行（run_seq 一致）',
    competitionReport.data?.run_seq === competitionRun.data?.run_seq,
    `${competitionReport.data?.run_seq} vs ${competitionRun.data?.run_seq}`,
  );
  const competitionHistory = await call('GET', `/api/projects/${analysisProjectId}/competition/history`, { token });
  check(
    '创业洞察留痕按运行序号倒序',
    (competitionHistory.data?.items ?? []).length >= 1 &&
      (competitionHistory.data?.items ?? []).every((item) => typeof item.run_seq === 'number'),
    JSON.stringify((competitionHistory.data?.items ?? [])[0] ?? {}).slice(0, 140),
  );

  const aiUnauth = await call('GET', `/api/projects/${analysisProjectId}/ai/status`);
  check('未登录不可读取 AI 状态', aiUnauth.status === 401);
  const reportUnauth = await call('GET', `/api/projects/${analysisProjectId}/report`);
  check('未登录不可下载研究报告', reportUnauth.status === 401);
  const exportUnauth = await call('GET', `/api/projects/${analysisProjectId}/export/dataset.csv`);
  check('未登录不可导出数据', exportUnauth.status === 401);
  const competitionUnauth = await call('GET', `/api/projects/${analysisProjectId}/competition/report`);
  check('未登录不可读取创业洞察', competitionUnauth.status === 401);

  /* ---------------------------------------------------------------- */
  section('20. 登出与令牌撤销');
  const isolatedToken = other.data.token;
  const logout = await call('POST', '/api/auth/logout', { token: isolatedToken });
  check('登出成功', logout.status === 200);
  const afterLogout = await call('GET', '/api/auth/me', { token: isolatedToken });
  check('登出后旧令牌立即失效', afterLogout.status === 401, `status=${afterLogout.status}`);

  /* ---------------------------------------------------------------- */
  console.log(`\n${'─'.repeat(56)}`);
  console.log(`结果：${passed} 项通过，${failed} 项失败`);
  console.log(`${'─'.repeat(56)}`);

  if (failed > 0) process.exitCode = 1;
}

main().catch((error) => {
  console.error('\n冒烟测试异常终止：', error);
  process.exitCode = 1;
});
