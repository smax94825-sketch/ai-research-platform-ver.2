/**
 * Core domain types for the Family Education Research Platform (FER P).
 *
 * These types are the single source of truth shared by the API server, the
 * researcher console and the respondent survey. They are deliberately
 * serialisation-friendly (plain JSON) because `questions.options`,
 * `questions.logic` and `questions.scoring_rule` are persisted in TEXT columns.
 */

/* ------------------------------------------------------------------ */
/* Question types                                                     */
/* ------------------------------------------------------------------ */

export const QUESTION_TYPES = [
  'single',
  'multiple',
  'dropdown',
  'likert',
  'matrix',
  'ranking',
  'text',
  'textarea',
  'number',
  'date',
  'knowledge_test',
  'page_break',
] as const;

export type QuestionType = (typeof QUESTION_TYPES)[number];

export const QUESTION_TYPE_LABELS: Record<QuestionType, string> = {
  single: '单选题',
  multiple: '多选题',
  dropdown: '下拉选择',
  likert: '李克特量表',
  matrix: '矩阵量表',
  ranking: '排序题',
  text: '文本填空',
  textarea: '多行文本',
  number: '数字输入',
  date: '日期',
  knowledge_test: '知识测试题',
  page_break: '分页/章节',
};

/** Question types that carry a choice list in `options.choices`. */
export const CHOICE_BASED_TYPES: readonly QuestionType[] = [
  'single',
  'multiple',
  'dropdown',
  'likert',
  'ranking',
  'knowledge_test',
];

/** Question types that produce ordinal 1..k scores usable in composites. */
export const SCALE_BASED_TYPES: readonly QuestionType[] = ['single', 'likert', 'dropdown', 'knowledge_test'];

/* ------------------------------------------------------------------ */
/* Options                                                            */
/* ------------------------------------------------------------------ */

export interface QuestionOption {
  /** Stored answer code (kept as string for lossless JSON round-trips). */
  value: string;
  /** Human readable label. */
  label: string;
  /** Optional numeric score used by the scoring engine. */
  score?: number;
  /** Knowledge-test only: whether this option is the correct answer. */
  isCorrect?: boolean;
  /**
   * Mutually exclusive option (e.g. "以上都不知道", "不愿回答").
   * Selecting it clears the other selections in a multi-select question.
   */
  exclusive?: boolean;
  /**
   * Sensitive non-response (e.g. "不愿回答"). Must never be recoded into a
   * substantive category such as "从未" — it stays a distinct missing code.
   */
  sensitiveNonResponse?: boolean;
}

export interface MatrixRow {
  /** Row variable suffix, e.g. "FED1". */
  value: string;
  label: string;
}

export interface MatrixConfig {
  rows: MatrixRow[];
  /** Shared response scale for every row. */
  columns: QuestionOption[];
}

export interface QuestionOptions {
  /** Choice list for single/multiple/dropdown/likert/ranking/knowledge_test. */
  choices?: QuestionOption[];
  /** Row/column definition for matrix questions. */
  matrix?: MatrixConfig;
  /** Likert scale bounds (used for validation and documentation). */
  scaleMin?: number;
  scaleMax?: number;
  /** Optional anchor labels for the Likert extremes. */
  scaleLabels?: Record<string, string>;
  /** Free-text / number input hints. */
  placeholder?: string;
  maxLength?: number;
  min?: number;
  max?: number;
  step?: number;
  /** Ranking questions: how many items the respondent must order. */
  rankCount?: number;
}

/* ------------------------------------------------------------------ */
/* Scoring rules                                                      */
/* ------------------------------------------------------------------ */

export type ScoringRule =
  | { type: 'none' }
  /** Reverse-coded single item inside a scale (1<->k). */
  | { type: 'reverse'; min: number; max: number }
  /** Sum of the item scores. */
  | { type: 'sum'; min?: number; max?: number }
  /** Mean of the item scores. */
  | { type: 'mean'; min?: number; max?: number }
  /** Knowledge test: explicit scores for correct / incorrect / don't-know. */
  | {
      type: 'knowledge';
      correctScore: number;
      incorrectScore: number;
      unknownScore: number;
      /** Option value that represents "不清楚 / 不知道". */
      unknownValue?: string;
      /** Total achievable score, used for the 0..maxScore accuracy index. */
      maxScore: number;
    }
  /** Categorical mapping from option value to analysis code (nominal level). */
  | { type: 'categorical'; codes: Record<string, number | null> }
  /**
   * Ordered mapping from option value to analysis code. Declares ordinal
   * measurement explicitly, because a 1..k code sequence alone does not prove
   * that the underlying construct is ordered (e.g. 父亲/母亲/祖辈 is nominal).
   */
  | { type: 'ordinal'; codes: Record<string, number | null> }
  /** Multi-select breadth (count of selected options). */
  | { type: 'count'; excludeExclusive?: boolean };

/* ------------------------------------------------------------------ */
/* Conditional logic                                                  */
/* ------------------------------------------------------------------ */

export type LogicOperator =
  | 'eq'
  | 'neq'
  | 'in'
  | 'not_in'
  | 'gt'
  | 'gte'
  | 'lt'
  | 'lte'
  | 'contains_any'
  | 'contains_all'
  | 'answered'
  | 'not_answered';

export const LOGIC_OPERATOR_LABELS: Record<LogicOperator, string> = {
  eq: '等于',
  neq: '不等于',
  in: '属于以下任意一项',
  not_in: '不属于以下任意一项',
  gt: '大于',
  gte: '大于或等于',
  lt: '小于',
  lte: '小于或等于',
  contains_any: '多选中包含任意一项',
  contains_all: '多选中同时包含',
  answered: '已作答',
  not_answered: '未作答',
};

export interface LogicCondition {
  questionCode: string;
  operator: LogicOperator;
  /** Comparison value; array for in/not_in/contains_*. */
  value?: string | number | string[] | number[] | null;
}

export type LogicAction =
  /** Skip forward (or back) to `target` question code, or "END". */
  | { type: 'jump_to'; target: string }
  /** Show the question only when the condition holds. */
  | { type: 'show' }
  /** Hide the question when the condition holds. */
  | { type: 'hide' }
  /** Force the question to be required when the condition holds. */
  | { type: 'require' };

export interface LogicRule {
  id: string;
  /** `all` = AND, `any` = OR. Applies when several conditions are present. */
  match?: 'all' | 'any';
  /** Legacy single-condition form kept for backwards compatibility. */
  when?: LogicCondition;
  /** Preferred multi-condition form. */
  conditions?: LogicCondition[];
  action: LogicAction;
  /** Optional human note shown in the logic editor. */
  note?: string;
}

export interface QuestionLogic {
  rules: LogicRule[];
}

/* ------------------------------------------------------------------ */
/* Entities                                                           */
/* ------------------------------------------------------------------ */

export type ProjectStatus = 'draft' | 'collecting' | 'paused' | 'analyzing' | 'completed' | 'archived';
export type QuestionnaireStatus = 'draft' | 'published' | 'closed';
export type RespondentStatus = 'in_progress' | 'completed' | 'abandoned';

/**
 * Researcher review decision for a collected sample.
 *
 * The platform never deletes a sample on its own. Quality flags and review
 * decisions are recorded so that every exclusion is attributable to a human
 * judgement that can be reported in the methods section.
 */
export type ReviewStatus = 'unreviewed' | 'accepted' | 'flagged' | 'excluded';

export const REVIEW_STATUS_LABELS: Record<ReviewStatus, string> = {
  unreviewed: '未审核',
  accepted: '已采用',
  flagged: '存疑',
  excluded: '已排除',
};

/**
 * Known acquisition channels (spec §16). Any other value supplied through
 * `?source=` is still stored, so a researcher can add channels without a
 * deployment, but these are the ones the console labels in Chinese.
 */
export const KNOWN_SOURCES: readonly string[] = [
  'direct',
  'wechat',
  'xiaohongshu',
  'school',
  'community',
  'offline',
  'douyin',
  'friend',
  'other',
] as const;

export const SOURCE_LABELS: Record<string, string> = {
  direct: '直接访问',
  wechat: '微信',
  xiaohongshu: '小红书',
  school: '学校',
  community: '社区',
  offline: '线下',
  douyin: '抖音',
  friend: '亲友转发',
  other: '其他',
};

export interface Researcher {
  id: string;
  name: string;
  email: string;
  affiliation: string | null;
  created_at: string;
  updated_at: string;
}

export interface Hypothesis {
  code: string;
  statement: string;
  /** Nullable — a hypothesis is only "concluded" once tested. */
  status?: 'untested' | 'supported' | 'not_supported' | 'inconclusive';
}

export interface ResearchProject {
  id: string;
  researcher_id: string;
  title: string;
  description: string | null;
  background: string | null;
  objectives: string | null;
  research_questions: string[];
  hypotheses: Hypothesis[];
  target_population: string | null;
  target_sample_size: number | null;
  start_date: string | null;
  end_date: string | null;
  status: ProjectStatus;
  quota_config: QuotaConfig | null;
  settings: ProjectSettings | null;
  created_at: string;
  updated_at: string;
}

export interface QuotaCategory {
  dimension: string;
  category: string;
  target_n: number;
}

export interface QuotaConfig {
  enabled: boolean;
  /** Never let the platform silently re-balance the target structure. */
  preserve_structure: boolean;
  categories: QuotaCategory[];
}

export interface ProjectSettings {
  /** Anonymous collection is mandatory; kept explicit for the ethics record. */
  anonymous: boolean;
  allow_partial: boolean;
  consent_text: string | null;
  min_duration_seconds: number | null;
}

export interface Questionnaire {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  version: string;
  status: QuestionnaireStatus;
  share_token: string | null;
  is_current: boolean;
  /** Frozen once the first response arrives; edits then require a new version. */
  locked: boolean;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Question {
  id: string;
  questionnaire_id: string;
  question_code: string;
  question_text: string;
  question_type: QuestionType;
  options: QuestionOptions;
  required: boolean;
  dimension: string | null;
  variable_name: string | null;
  sort_order: number;
  section: string | null;
  help_text: string | null;
  logic: QuestionLogic | null;
  scoring_rule: ScoringRule | null;
  created_at: string;
  updated_at: string;
}

/* ------------------------------------------------------------------ */
/* Respondents (collected samples)                                    */
/* ------------------------------------------------------------------ */

export interface Respondent {
  id: string;
  questionnaire_id: string;
  project_id: string;
  anonymous_id: string;
  source: string;
  started_at: string;
  completed_at: string | null;
  duration_seconds: number | null;
  status: RespondentStatus;
  quality_score: number | null;
  current_question_code: string | null;
  answered_count: number;
  last_activity_at: string | null;
  consent_given_at: string | null;
  review_status: ReviewStatus;
  review_note: string | null;
  created_at: string;
}

/** One stored answer, resolved against its question for display. */
export interface ResponseRecord {
  question_id: string;
  question_code: string;
  question_text: string;
  question_type: QuestionType;
  dimension: string | null;
  variable_name: string | null;
  /** Raw stored answer (string | string[] | number | matrix map). */
  answer: unknown;
  /** Human readable rendering of the answer, e.g. "从未使用". */
  answer_label: string;
  created_at: string;
  updated_at: string;
}

/* ------------------------------------------------------------------ */
/* Variable dictionary                                                */
/* ------------------------------------------------------------------ */

export type DataType = 'nominal' | 'ordinal' | 'interval' | 'ratio' | 'text' | 'count' | 'boolean';

export interface VariableDefinition {
  variable_name: string;
  question_code: string;
  question_text: string;
  dimension: string;
  data_type: DataType;
  coding: string;
  missing_value: string;
  scoring_rule: string;
  analysis_method: string;
  is_derived: boolean;
  note: string;
}

/* ------------------------------------------------------------------ */
/* API envelope                                                       */
/* ------------------------------------------------------------------ */

export interface ApiError {
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export interface ApiOk<T> {
  data: T;
}
