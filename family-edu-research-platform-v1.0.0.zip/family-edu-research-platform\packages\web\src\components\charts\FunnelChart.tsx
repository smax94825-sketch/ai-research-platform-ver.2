/**
 * Collection funnel: started → completed → analysable → excluded.
 *
 * Every stage prints its own count, and each step prints the absolute and
 * relative drop-off from the previous stage, because "1,000 started" says
 * nothing useful until the reader can see how many of them survived to the
 * analysis base.
 *
 * A stage flagged `detached` is NOT a subset of the one before it — excluded
 * samples are a subset of the completed ones counted in parallel, not a further
 * shrinking of the analysable base — so the component refuses to compute a
 * drop-off for it and says why instead.
 */

import type { ReactNode } from 'react';
import { truncate } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg } from './primitives';

export interface FunnelStage {
  label: string;
  count: number;
  /** Extra explanation printed next to the count. */
  note?: string;
  /** True when this stage overlaps the previous one rather than being its subset. */
  detached?: boolean;
}

export interface FunnelChartProps {
  stages: FunnelStage[];
  unit?: string;
  emptyText?: string;
  caption?: ReactNode;
}

const WIDTH = 680;
const ROW_HEIGHT = 48;

export function FunnelChart({
  stages,
  unit = '份',
  emptyText = '暂无可展示的样本流程数据。',
  caption,
}: FunnelChartProps): ReactNode {
  if (stages.length === 0) return <ChartEmpty text={emptyText} />;

  const largest = Math.max(1, ...stages.map((stage) => stage.count));
  const height = 4 + stages.length * ROW_HEIGHT;

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={height} label="样本收集漏斗图">
        {stages.map((stage, index) => {
          const rowTop = 4 + index * ROW_HEIGHT;
          const width = (stage.count / largest) * WIDTH;
          const x = (WIDTH - width) / 2;
          const previous = index > 0 ? stages[index - 1] : undefined;
          let stepText: string | null = null;
          let stepTone = '#68778e';

          if (previous && stage.detached) {
            stepText = '该阶段与上一阶段并列计数，不属于上一阶段的子集，因此不计算流失率。';
          } else if (previous) {
            const difference = previous.count - stage.count;
            const percent = previous.count > 0 ? (difference / previous.count) * 100 : 0;
            if (difference >= 0) {
              stepText = `较「${previous.label}」减少 ${difference} ${unit}（${percent.toFixed(1)}%）`;
              stepTone = difference > 0 ? '#a15c07' : '#535f74';
            } else {
              stepText = `较「${previous.label}」增加 ${Math.abs(difference)} ${unit}（${Math.abs(percent).toFixed(1)}%）`;
            }
          }

          return (
            <g key={`${stage.label}-${index}`}>
              <text x={0} y={rowTop + 11} fontSize={FONT} fill="#3a4150">
                {truncate(stage.label, 26)}
              </text>
              <text x={WIDTH} y={rowTop + 11} fontSize={FONT} fill="#535f74" textAnchor="end">
                {`${stage.count} ${unit}${stage.note ? ` · ${stage.note}` : ''}`}
              </text>
              <rect
                x={x}
                y={rowTop + 16}
                width={Math.max(width, stage.count > 0 ? 2 : 0)}
                height={12}
                rx={3}
                fill={stage.detached ? '#b1bac9' : '#3366ff'}
              />
              {stepText && (
                <text x={WIDTH / 2} y={rowTop + 43} fontSize={FONT_SMALL} fill={stepTone} textAnchor="middle">
                  {stepText}
                </text>
              )}
            </g>
          );
        })}
      </ResponsiveSvg>

      <ChartCaption>
        {caption ??
          '样本流程按问卷状态与研究者审核结果统计；「已排除」为与已完成样本并列的计数，不参与漏斗流失率计算。'}
      </ChartCaption>
    </div>
  );
}
