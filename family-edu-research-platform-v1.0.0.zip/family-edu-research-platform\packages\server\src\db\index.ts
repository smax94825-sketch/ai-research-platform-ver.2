/**
 * Database access layer.
 *
 * Uses Node's built-in `node:sqlite` (no native build step, no external
 * dependency) behind a thin wrapper so that statements stay parameterised and
 * every write is transactional. The SQL kept here is portable, which is what
 * allows a PostgreSQL deployment later without rewriting call sites.
 */

import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

/** Value types accepted for SQL parameters. */
export type SqlValue = string | number | bigint | null | Uint8Array;

export interface RunResult {
  changes: number;
  lastInsertRowid: number | bigint;
}

/**
 * Normalise a JavaScript value into something the driver accepts.
 * Booleans become 0/1 and `undefined` becomes NULL so callers never have to
 * think about the difference between "absent" and "null" at the SQL boundary.
 */
export function normalizeValue(value: unknown): SqlValue {
  if (value === undefined || value === null) return null;
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (typeof value === 'number') return value;
  if (typeof value === 'bigint') return value;
  if (typeof value === 'string') return value;
  if (value instanceof Uint8Array) return value;
  if (value instanceof Date) return value.toISOString();
  // Objects and arrays must be serialised explicitly by the caller; silently
  // coercing them to "[object Object]" would corrupt the dataset.
  throw new TypeError(
    `Unsupported SQL parameter type: ${Object.prototype.toString.call(value)}. ` +
      'Serialise objects/arrays to JSON at the call site.',
  );
}

export class Db {
  readonly raw: DatabaseSync;
  readonly filename: string;

  constructor(filename: string) {
    this.filename = filename;
    if (filename !== ':memory:') {
      mkdirSync(dirname(filename), { recursive: true });
    }
    this.raw = new DatabaseSync(filename);
    // Referential integrity is not on by default in SQLite.
    this.raw.exec('PRAGMA foreign_keys = ON');
    if (filename !== ':memory:') {
      // WAL keeps concurrent readers from blocking the collection writer.
      this.raw.exec('PRAGMA journal_mode = WAL');
      this.raw.exec('PRAGMA synchronous = NORMAL');
    }
    this.raw.exec('PRAGMA busy_timeout = 5000');
  }

  exec(sql: string): void {
    this.raw.exec(sql);
  }

  all<T = Record<string, unknown>>(sql: string, params: readonly unknown[] = []): T[] {
    const statement = this.raw.prepare(sql);
    return statement.all(...(params.map(normalizeValue) as never[])) as T[];
  }

  get<T = Record<string, unknown>>(sql: string, params: readonly unknown[] = []): T | undefined {
    const statement = this.raw.prepare(sql);
    return statement.get(...(params.map(normalizeValue) as never[])) as T | undefined;
  }

  run(sql: string, params: readonly unknown[] = []): RunResult {
    const statement = this.raw.prepare(sql);
    const result = statement.run(...(params.map(normalizeValue) as never[]));
    return {
      changes: Number(result.changes),
      lastInsertRowid: result.lastInsertRowid,
    };
  }

  /** Convenience: fetch a single scalar value (first column of first row). */
  scalar<T extends SqlValue>(sql: string, params: readonly unknown[] = []): T | undefined {
    const row = this.get<Record<string, T>>(sql, params);
    if (!row) return undefined;
    const values = Object.values(row);
    return values.length > 0 ? values[0] : undefined;
  }

  /**
   * Run `fn` inside a transaction, rolling back on any throw.
   * Nested calls use SAVEPOINTs, because SQLite rejects a second BEGIN and
   * services legitimately compose (e.g. create project, then seed its
   * questionnaire from a template).
   */
  transaction<T>(fn: () => T): T {
    const isOuter = this.txDepth === 0;
    const savepoint = `ferp_sp_${this.txDepth}`;
    this.raw.exec(isOuter ? 'BEGIN' : `SAVEPOINT ${savepoint}`);
    this.txDepth += 1;
    try {
      const result = fn();
      this.txDepth -= 1;
      this.raw.exec(isOuter ? 'COMMIT' : `RELEASE ${savepoint}`);
      return result;
    } catch (error) {
      this.txDepth -= 1;
      try {
        this.raw.exec(isOuter ? 'ROLLBACK' : `ROLLBACK TO ${savepoint}`);
        if (!isOuter) this.raw.exec(`RELEASE ${savepoint}`);
      } catch {
        // A rollback failure must not mask the original error.
      }
      throw error;
    }
  }

  private txDepth = 0;

  close(): void {
    this.raw.close();
  }
}

/** Build a parameterised INSERT from a plain object row. */
export function buildInsert(
  table: string,
  row: Record<string, unknown>,
): { sql: string; params: unknown[] } {
  const keys = Object.keys(row);
  if (keys.length === 0) throw new Error(`buildInsert(${table}) called with an empty row`);
  const sql = `INSERT INTO ${table} (${keys.join(', ')}) VALUES (${keys.map(() => '?').join(', ')})`;
  return { sql, params: keys.map((key) => row[key]) };
}

/** Build a parameterised UPDATE from a plain object patch plus a WHERE clause. */
export function buildUpdate(
  table: string,
  patch: Record<string, unknown>,
  where: Record<string, unknown>,
): { sql: string; params: unknown[] } {
  const patchKeys = Object.keys(patch);
  if (patchKeys.length === 0) throw new Error(`buildUpdate(${table}) called with an empty patch`);
  const whereKeys = Object.keys(where);
  if (whereKeys.length === 0) throw new Error(`buildUpdate(${table}) requires a WHERE clause`);
  const sql =
    `UPDATE ${table} SET ${patchKeys.map((k) => `${k} = ?`).join(', ')} ` +
    `WHERE ${whereKeys.map((k) => `${k} = ?`).join(' AND ')}`;
  return {
    sql,
    params: [...patchKeys.map((k) => patch[k]), ...whereKeys.map((k) => where[k])],
  };
}

/** Insert a row using an auto-built statement. */
export function insertRow(db: Db, table: string, row: Record<string, unknown>): RunResult {
  const { sql, params } = buildInsert(table, row);
  return db.run(sql, params);
}

/** Update rows using an auto-built statement. */
export function updateRow(
  db: Db,
  table: string,
  patch: Record<string, unknown>,
  where: Record<string, unknown>,
): RunResult {
  const { sql, params } = buildUpdate(table, patch, where);
  return db.run(sql, params);
}
