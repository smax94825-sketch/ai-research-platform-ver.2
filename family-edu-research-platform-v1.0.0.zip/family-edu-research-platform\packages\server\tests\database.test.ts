/**
 * Database layer tests: schema, migrations, constraints, transactions.
 *
 * These guard the properties the rest of the platform assumes — that
 * migrations are idempotent, that foreign keys are actually enforced (SQLite
 * does not enable them by default), and that a failed transaction leaves no
 * partial writes behind.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { Db, buildInsert, buildUpdate, insertRow, updateRow, normalizeValue } from '../src/db/index.js';
import { appliedMigrations, dropAllTables, listTables, migrate } from '../src/db/migrate.js';
import { MIGRATIONS } from '../src/db/migrations.js';

/**
 * Derived from the migration registry rather than hardcoded, so adding a
 * migration does not require editing every assertion that counts them.
 */
const ALL_MIGRATION_IDS = [...MIGRATIONS].map((migration) => migration.id).sort();

const EXPECTED_TABLES = [
  'analysis_results',
  'audit_logs',
  'quality_flags',
  'questionnaire_snapshots',
  'questionnaires',
  'questions',
  'research_projects',
  'research_reports',
  'researchers',
  'respondents',
  'responses',
  'schema_migrations',
];

let db: Db;

before(() => {
  db = new Db(':memory:');
  migrate(db);
});

after(() => {
  db.close();
});

describe('迁移管理', () => {
  test('应用初始迁移后创建全部业务数据表', () => {
    const tables = listTables(db);
    for (const table of EXPECTED_TABLES) {
      assert.ok(tables.includes(table), `缺少数据表 ${table}`);
    }
  });

  test('迁移被记录在 schema_migrations 中', () => {
    const applied = appliedMigrations(db);
    assert.deepEqual(
      applied.map((row) => row.id),
      ALL_MIGRATION_IDS,
    );
    for (const row of applied) {
      assert.ok(row.name.length > 0, `迁移 ${row.id} 缺少名称`);
      assert.ok(row.applied_at.length > 0, `迁移 ${row.id} 缺少应用时间`);
    }
  });

  test('重复运行迁移是幂等的（不会重复应用）', () => {
    const result = migrate(db);
    assert.deepEqual(result.applied, []);
    assert.deepEqual(result.skipped, ALL_MIGRATION_IDS);
    assert.equal(appliedMigrations(db).length, ALL_MIGRATION_IDS.length);
  });

  test('PHASE 3 迁移为 respondents 增加了会话、同意与审核字段', () => {
    const columns = db.all<{ name: string }>('PRAGMA table_info(respondents)').map((row) => row.name);
    for (const column of [
      'session_token',
      'consent_given_at',
      'current_question_code',
      'answered_count',
      'last_activity_at',
      'review_status',
      'review_note',
      'reviewed_at',
      'reviewed_by',
    ]) {
      assert.ok(columns.includes(column), `respondents 缺少字段 ${column}`);
    }
  });

  test('会话令牌在数据库层面唯一', () => {
    // Self-contained fixture: do not depend on rows created by a later suite.
    db.run(
      `INSERT INTO researchers (id, name, email, password_hash, created_at, updated_at)
       VALUES ('r-token-owner','n','token-owner@test.local','h','t','t')`,
    );
    db.run(
      `INSERT INTO research_projects (id, researcher_id, title, created_at, updated_at)
       VALUES ('p-token','r-token-owner','t','t','t')`,
    );
    db.run(
      `INSERT INTO questionnaires (id, project_id, title, version, status, is_current, locked, created_at, updated_at)
       VALUES ('q-token','p-token','t','V1.0','draft',1,0,'t','t')`,
    );
    const insertRespondent = (id: string, token: string): void => {
      db.run(
        `INSERT INTO respondents (id, questionnaire_id, project_id, anonymous_id, source, started_at,
                                  status, created_at, session_token)
         VALUES (?, 'q-token', 'p-token', ?, 'direct', 't', 'in_progress', 't', ?)`,
        [id, `A-${id}`, token],
      );
    };
    insertRespondent('r-token-1', 'shared-session-token');
    assert.throws(() => insertRespondent('r-token-2', 'shared-session-token'), /UNIQUE|constraint/i);
  });

  test('外键约束已开启（SQLite 默认关闭）', () => {
    assert.equal(db.scalar<number>('PRAGMA foreign_keys'), 1);
  });

  test('关键索引已建立', () => {
    const indexes = db
      .all<{ name: string }>("SELECT name FROM sqlite_master WHERE type = 'index' AND name LIKE 'idx_%'")
      .map((row) => row.name);
    for (const expected of [
      'idx_projects_researcher',
      'idx_questionnaires_project',
      'idx_questions_questionnaire',
      'idx_respondents_questionnaire',
      'idx_responses_respondent',
      'idx_analysis_project',
      'idx_flags_project',
    ]) {
      assert.ok(indexes.includes(expected), `缺少索引 ${expected}`);
    }
  });
});

describe('参数规范化', () => {
  test('布尔值转为 0/1', () => {
    assert.equal(normalizeValue(true), 1);
    assert.equal(normalizeValue(false), 0);
  });

  test('undefined 转为 NULL', () => {
    assert.equal(normalizeValue(undefined), null);
    assert.equal(normalizeValue(null), null);
  });

  test('Date 转为 ISO 字符串', () => {
    const date = new Date('2026-01-02T03:04:05.000Z');
    assert.equal(normalizeValue(date), '2026-01-02T03:04:05.000Z');
  });

  test('对象直接抛出错误，绝不静默转成 [object Object]', () => {
    assert.throws(() => normalizeValue({ a: 1 }), /Unsupported SQL parameter type/);
    assert.throws(() => normalizeValue([1, 2]), /Unsupported SQL parameter type/);
  });
});

describe('SQL 构造器', () => {
  test('buildInsert 生成参数化语句', () => {
    const { sql, params } = buildInsert('researchers', { id: 'x', name: 'n', email: 'e' });
    assert.equal(sql, 'INSERT INTO researchers (id, name, email) VALUES (?, ?, ?)');
    assert.deepEqual(params, ['x', 'n', 'e']);
  });

  test('buildInsert 拒绝空对象', () => {
    assert.throws(() => buildInsert('researchers', {}), /empty row/);
  });

  test('buildUpdate 生成带 WHERE 的参数化语句', () => {
    const { sql, params } = buildUpdate('researchers', { name: 'new' }, { id: 'x' });
    assert.equal(sql, 'UPDATE researchers SET name = ? WHERE id = ?');
    assert.deepEqual(params, ['new', 'x']);
  });

  test('buildUpdate 拒绝缺少 WHERE 的调用（防止全表更新）', () => {
    assert.throws(() => buildUpdate('researchers', { name: 'new' }, {}), /WHERE/);
  });

  test('insertRow / updateRow 端到端可用', () => {
    const scratch = new Db(':memory:');
    scratch.exec('CREATE TABLE t (id TEXT PRIMARY KEY, v TEXT)');
    insertRow(scratch, 't', { id: 'a', v: '1' });
    assert.equal(scratch.scalar<string>('SELECT v FROM t WHERE id = ?', ['a']), '1');
    updateRow(scratch, 't', { v: '2' }, { id: 'a' });
    assert.equal(scratch.scalar<string>('SELECT v FROM t WHERE id = ?', ['a']), '2');
    scratch.close();
  });
});

describe('约束执行', () => {
  test('邮箱唯一约束生效（防止重复账号）', () => {
    db.run(
      "INSERT INTO researchers (id, name, email, password_hash, created_at, updated_at) VALUES ('r1','A','dup@test.local','h','t','t')",
    );
    assert.throws(
      () =>
        db.run(
          "INSERT INTO researchers (id, name, email, password_hash, created_at, updated_at) VALUES ('r2','B','dup@test.local','h','t','t')",
        ),
      /UNIQUE|constraint/i,
    );
  });

  test('外键约束阻止孤立记录（问卷必须属于真实项目）', () => {
    assert.throws(
      () =>
        db.run(
          `INSERT INTO questionnaires (id, project_id, title, version, status, is_current, locked, created_at, updated_at)
           VALUES ('q1','no-such-project','t','V1.0','draft',1,0,'t','t')`,
        ),
      /FOREIGN KEY|constraint/i,
    );
  });

  test('外键约束阻止孤儿作答记录', () => {
    assert.throws(
      () =>
        db.run(
          `INSERT INTO responses (id, respondent_id, question_id, question_code, answer, created_at, updated_at)
           VALUES ('resp1','no-such-respondent','no-such-question','Q1','"1"','t','t')`,
        ),
      /FOREIGN KEY|constraint/i,
    );
  });

  test('删除项目级联删除其问卷与题目', () => {
    db.run(
      `INSERT INTO research_projects (id, researcher_id, title, created_at, updated_at)
       VALUES ('p-cascade','r1','t','t','t')`,
    );
    db.run(
      `INSERT INTO questionnaires (id, project_id, title, version, status, is_current, locked, created_at, updated_at)
       VALUES ('q-cascade','p-cascade','t','V1.0','draft',1,0,'t','t')`,
    );
    db.run(
      `INSERT INTO questions (id, questionnaire_id, question_code, question_text, question_type, options, required, sort_order, created_at, updated_at)
       VALUES ('qq1','q-cascade','Q1','t','text','{}',1,1,'t','t')`,
    );

    db.run("DELETE FROM research_projects WHERE id = 'p-cascade'");

    assert.equal(db.scalar<number>("SELECT COUNT(*) FROM questionnaires WHERE id='q-cascade'"), 0);
    assert.equal(db.scalar<number>("SELECT COUNT(*) FROM questions WHERE id='qq1'"), 0);
  });

  test('题目代码在同一问卷内唯一，但跨问卷可重复', () => {
    db.run(
      `INSERT INTO research_projects (id, researcher_id, title, created_at, updated_at)
       VALUES ('p-uniq','r1','t','t','t')`,
    );
    db.run(
      `INSERT INTO questionnaires (id, project_id, title, version, status, is_current, locked, created_at, updated_at)
       VALUES ('q-a','p-uniq','t','V1.0','draft',1,0,'t','t'), ('q-b','p-uniq','t','V1.1','draft',0,0,'t','t')`,
    );
    const insertQuestion = (id: string, qid: string): void => {
      db.run(
        `INSERT INTO questions (id, questionnaire_id, question_code, question_text, question_type, options, required, sort_order, created_at, updated_at)
         VALUES (?, ?, 'Q1', 't', 'text', '{}', 1, 1, 't', 't')`,
        [id, qid],
      );
    };
    insertQuestion('qa1', 'q-a');
    insertQuestion('qb1', 'q-b'); // same code, different questionnaire — allowed
    assert.throws(() => insertQuestion('qa2', 'q-a'), /UNIQUE|constraint/i);
  });
});

describe('事务', () => {
  test('提交后数据可见', () => {
    const scratch = new Db(':memory:');
    scratch.exec('CREATE TABLE t (id TEXT PRIMARY KEY, v INTEGER)');
    scratch.transaction(() => {
      scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['a', 1]);
      scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['b', 2]);
    });
    assert.equal(scratch.scalar<number>('SELECT COUNT(*) FROM t'), 2);
    scratch.close();
  });

  test('抛出异常时全部回滚，不留半成品数据', () => {
    const scratch = new Db(':memory:');
    scratch.exec('CREATE TABLE t (id TEXT PRIMARY KEY, v INTEGER)');
    assert.throws(() => {
      scratch.transaction(() => {
        scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['a', 1]);
        throw new Error('boom');
      });
    }, /boom/);
    assert.equal(scratch.scalar<number>('SELECT COUNT(*) FROM t'), 0);
    scratch.close();
  });

  test('嵌套事务使用 SAVEPOINT，内层失败不影响外层已提交内容', () => {
    const scratch = new Db(':memory:');
    scratch.exec('CREATE TABLE t (id TEXT PRIMARY KEY, v INTEGER)');

    scratch.transaction(() => {
      scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['outer', 1]);
      try {
        scratch.transaction(() => {
          scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['inner', 2]);
          throw new Error('inner-fail');
        });
      } catch {
        // Inner rolled back to its savepoint; the outer transaction survives.
      }
      scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['after', 3]);
    });

    const ids = scratch.all<{ id: string }>('SELECT id FROM t ORDER BY id').map((r) => r.id);
    assert.deepEqual(ids, ['after', 'outer']);
    scratch.close();
  });

  test('嵌套事务内层失败且异常外抛时整体回滚', () => {
    const scratch = new Db(':memory:');
    scratch.exec('CREATE TABLE t (id TEXT PRIMARY KEY, v INTEGER)');
    assert.throws(() => {
      scratch.transaction(() => {
        scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['outer', 1]);
        scratch.transaction(() => {
          scratch.run('INSERT INTO t (id, v) VALUES (?, ?)', ['inner', 2]);
          throw new Error('propagate');
        });
      });
    }, /propagate/);
    assert.equal(scratch.scalar<number>('SELECT COUNT(*) FROM t'), 0);
    scratch.close();
  });

  test('事务结束后仍可继续正常写入', () => {
    const scratch = new Db(':memory:');
    scratch.exec('CREATE TABLE t (id TEXT PRIMARY KEY)');
    assert.throws(() => scratch.transaction(() => {
      throw new Error('x');
    }));
    scratch.transaction(() => scratch.run('INSERT INTO t (id) VALUES (?)', ['ok']));
    assert.equal(scratch.scalar<number>('SELECT COUNT(*) FROM t'), 1);
    scratch.close();
  });
});

describe('数据库重置', () => {
  test('dropAllTables 之后可以重新迁移到干净状态', () => {
    const scratch = new Db(':memory:');
    migrate(scratch);
    scratch.run(
      "INSERT INTO researchers (id, name, email, password_hash, created_at, updated_at) VALUES ('x','n','x@y.z','h','t','t')",
    );
    assert.equal(scratch.scalar<number>('SELECT COUNT(*) FROM researchers'), 1);

    dropAllTables(scratch);
    assert.ok(!listTables(scratch).includes('researchers'));

    const result = migrate(scratch);
    assert.deepEqual(result.applied, ALL_MIGRATION_IDS);
    assert.equal(scratch.scalar<number>('SELECT COUNT(*) FROM researchers'), 0);
    scratch.close();
  });
});
