/**
 * Sample management API tests (PHASE 3).
 *
 * Covers the researcher-facing side of collection: paging and filtering the
 * sample, reading one respondent's answers resolved for display, channel
 * reporting, and the review decisions that are the ONLY way a sample stops
 * counting towards analysis.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import {
  api,
  createPublishedQuestionnaire,
  createTestContext,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

const QUESTIONS = [
  {
    question_code: 'Q1',
    question_text: '您是否使用过家庭教育服务？',
    question_type: 'single',
    required: true,
    variable_name: 'SVC',
    options: {
      choices: [
        { value: '1', label: '从未使用' },
        { value: '2', label: '使用过' },
      ],
    },
  },
  {
    question_code: 'Q2',
    question_text: '请评价您的满意程度。',
    question_type: 'likert',
    required: true,
    variable_name: 'SAT',
    options: {
      choices: [
        { value: '1', label: '非常不满意', score: 1 },
        { value: '2', label: '一般', score: 2 },
        { value: '3', label: '非常满意', score: 3 },
      ],
    },
  },
  {
    question_code: 'Q3',
    question_text: '请简要说明原因（选填）。',
    question_type: 'textarea',
    required: false,
    options: { maxLength: 100 },
  },
];

interface Fixture {
  projectId: string;
  questionnaireId: string;
  shareToken: string;
  token: string;
}

async function makeFixture(title: string): Promise<Fixture> {
  const researcher = await registerResearcher(ctx);
  const published = await createPublishedQuestionnaire(ctx, researcher.token, QUESTIONS, title);
  return { ...published, token: researcher.token };
}

/** Open a session and complete it with the given answers. */
async function collect(
  fixture: Fixture,
  source: string,
  answers: Record<string, unknown>,
  submit = true,
): Promise<{ sessionToken: string; respondentId: string; anonymousId: string }> {
  const session = await startSession(ctx, fixture.shareToken, source);
  for (const [code, value] of Object.entries(answers)) {
    const saved = await saveAnswer(ctx, session.token, code, value);
    assert.equal(saved.status, 200, `${code} 保存失败：${JSON.stringify(saved.error)}`);
  }
  if (submit) {
    const done = await submitSession(ctx, session.token);
    assert.equal(done.status, 200, `提交失败：${JSON.stringify(done.error)}`);
  }
  return {
    sessionToken: session.token,
    respondentId: session.respondentId,
    anonymousId: session.anonymousId,
  };
}

/* ================================================================== */
/* Listing                                                            */
/* ================================================================== */

describe('样本列表', () => {
  test('分页返回样本并给出状态汇总', async () => {
    const fixture = await makeFixture('样本列表测试');
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'school', { Q1: '1', Q2: '2' });
    await collect(fixture, 'school', { Q1: '1' }, false); // 未提交

    const response = await api<{
      items: { anonymous_id: string; source: string; status: string }[];
      total: number;
      limit: number;
      offset: number;
      summary: { total: number; completed: number; in_progress: number; abandoned: number };
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/respondents`, { token: fixture.token });

    assert.equal(response.status, 200);
    assert.equal(response.data.total, 3);
    assert.equal(response.data.items.length, 3);
    assert.equal(response.data.limit, 50);
    assert.equal(response.data.summary.total, 3);
    assert.equal(response.data.summary.completed, 2);
    assert.equal(response.data.summary.in_progress, 1);
    assert.equal(response.data.summary.abandoned, 0);
  });

  test('按状态筛选', async () => {
    const fixture = await makeFixture('状态筛选');
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'school', { Q1: '1' }, false);

    const completed = await api<{ items: { status: string }[]; total: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?status=completed`,
      { token: fixture.token },
    );
    assert.equal(completed.data.total, 1);
    assert.ok(completed.data.items.every((item) => item.status === 'completed'));

    const inProgress = await api<{ total: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?status=in_progress`,
      { token: fixture.token },
    );
    assert.equal(inProgress.data.total, 1);
  });

  test('按来源筛选', async () => {
    const fixture = await makeFixture('来源筛选');
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'xiaohongshu', { Q1: '1', Q2: '1' });

    const wechat = await api<{ items: { source: string }[]; total: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?source=wechat`,
      { token: fixture.token },
    );
    assert.equal(wechat.data.total, 1);
    assert.equal(wechat.data.items[0]?.source, 'wechat');
  });

  test('按匿名编号搜索', async () => {
    const fixture = await makeFixture('编号搜索');
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'wechat', { Q1: '1', Q2: '1' });

    const response = await api<{ items: { anonymous_id: string }[]; total: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?search=A0002`,
      { token: fixture.token },
    );
    assert.equal(response.data.total, 1);
    assert.equal(response.data.items[0]?.anonymous_id, 'A0002');
  });

  test('分页 limit/offset 生效', async () => {
    const fixture = await makeFixture('分页测试');
    for (let i = 0; i < 5; i += 1) {
      await collect(fixture, 'school', { Q1: '2', Q2: '3' });
    }

    const page = await api<{ items: unknown[]; total: number; limit: number; offset: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?limit=2&offset=1`,
      { token: fixture.token },
    );
    assert.equal(page.data.total, 5);
    assert.equal(page.data.items.length, 2);
    assert.equal(page.data.limit, 2);
    assert.equal(page.data.offset, 1);
  });

  test('拒绝非法的状态与审核状态筛选值', async () => {
    const fixture = await makeFixture('非法筛选');
    const badStatus = await api(ctx, 'GET', `/api/projects/${fixture.projectId}/respondents?status=bogus`, {
      token: fixture.token,
    });
    assert.equal(badStatus.status, 400);

    const badReview = await api(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?review_status=bogus`,
      { token: fixture.token },
    );
    assert.equal(badReview.status, 400);
  });

  test('空项目返回空列表而非报错', async () => {
    const fixture = await makeFixture('空项目');
    const response = await api<{ items: unknown[]; total: number; summary: { total: number } }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents`,
      { token: fixture.token },
    );
    assert.equal(response.status, 200);
    assert.deepEqual(response.data.items, []);
    assert.equal(response.data.total, 0);
    assert.equal(response.data.summary.total, 0);
  });
});

/* ================================================================== */
/* Detail                                                             */
/* ================================================================== */

describe('单个样本详情', () => {
  test('返回全部作答并解析为可读文本', async () => {
    const fixture = await makeFixture('样本详情');
    const created = await collect(fixture, 'wechat', {
      Q1: '2',
      Q2: '3',
      Q3: '希望有更多社区活动',
    });

    const response = await api<{
      respondent: { anonymous_id: string; source: string; status: string };
      questionnaire: { version: string };
      responses: {
        question_code: string;
        question_text: string;
        answer: unknown;
        answer_label: string;
        variable_name: string | null;
        dimension: string | null;
      }[];
      answered_count: number;
    }>(ctx, 'GET', `/api/respondents/${created.respondentId}`, { token: fixture.token });

    assert.equal(response.status, 200);
    assert.equal(response.data.respondent.anonymous_id, created.anonymousId);
    assert.equal(response.data.respondent.source, 'wechat');
    assert.equal(response.data.answered_count, 3);

    const byCode = new Map(response.data.responses.map((item) => [item.question_code, item]));
    assert.equal(byCode.get('Q1')?.answer_label, '使用过', '选项代码应被解析为选项文本');
    assert.equal(byCode.get('Q2')?.answer_label, '非常满意');
    assert.equal(byCode.get('Q3')?.answer_label, '希望有更多社区活动');
    assert.equal(byCode.get('Q1')?.variable_name, 'SVC');
  });

  test('作答按问卷题目顺序返回', async () => {
    const fixture = await makeFixture('详情顺序');
    const created = await collect(fixture, 'wechat', { Q3: '文本', Q1: '2', Q2: '3' });

    const response = await api<{ responses: { question_code: string }[] }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.deepEqual(
      response.data.responses.map((item) => item.question_code),
      ['Q1', 'Q2', 'Q3'],
    );
  });

  test('未完成样本的详情仍可查看', async () => {
    const fixture = await makeFixture('未完成详情');
    const created = await collect(fixture, 'school', { Q1: '1' }, false);

    const response = await api<{ respondent: { status: string }; answered_count: number }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.equal(response.data.respondent.status, 'in_progress');
    assert.equal(response.data.answered_count, 1);
  });

  test('不存在的样本返回 404', async () => {
    const fixture = await makeFixture('不存在样本');
    const response = await api(
      ctx,
      'GET',
      '/api/respondents/00000000-0000-0000-0000-000000000000',
      { token: fixture.token },
    );
    assert.equal(response.status, 404);
  });
});

/* ================================================================== */
/* Sources                                                            */
/* ================================================================== */

describe('来源渠道统计', () => {
  test('按渠道汇总样本量与完成率', async () => {
    const fixture = await makeFixture('渠道统计');
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'wechat', { Q1: '1' }, false);
    await collect(fixture, 'school', { Q1: '2', Q2: '3' });
    await collect(fixture, 'xiaohongshu', { Q1: '1' }, false);

    const response = await api<{
      items: { source: string; total: number; completed: number; in_progress: number; completion_rate: number | null }[];
      total: number;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/sources`, { token: fixture.token });

    assert.equal(response.status, 200);
    assert.equal(response.data.total, 5);

    const bySource = new Map(response.data.items.map((item) => [item.source, item]));
    assert.equal(bySource.get('wechat')?.total, 3);
    assert.equal(bySource.get('wechat')?.completed, 2);
    assert.equal(bySource.get('wechat')?.in_progress, 1);
    assert.equal(bySource.get('wechat')?.completion_rate, 66.67);
    assert.equal(bySource.get('school')?.total, 1);
    assert.equal(bySource.get('school')?.completion_rate, 100);
    assert.equal(bySource.get('xiaohongshu')?.completion_rate, 0);
  });

  test('渠道列表按样本量降序排列', async () => {
    const fixture = await makeFixture('渠道排序');
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'school', { Q1: '2', Q2: '3' });

    const response = await api<{ items: { source: string; total: number }[] }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/sources`,
      { token: fixture.token },
    );
    assert.equal(response.data.items[0]?.source, 'wechat');
    assert.equal(response.data.items[1]?.source, 'school');
  });

  test('无样本时返回空统计', async () => {
    const fixture = await makeFixture('空渠道');
    const response = await api<{ items: unknown[]; total: number }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/sources`,
      { token: fixture.token },
    );
    assert.deepEqual(response.data.items, []);
    assert.equal(response.data.total, 0);
  });
});

/* ================================================================== */
/* Review                                                             */
/* ================================================================== */

describe('研究者审核（平台不会自动删除样本）', () => {
  test('标记样本为已采用', async () => {
    const fixture = await makeFixture('审核采用');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });

    const response = await api<{ review_status: string }>(
      ctx,
      'POST',
      `/api/respondents/${created.respondentId}/review`,
      { token: fixture.token, body: { status: 'accepted', note: '作答完整' } },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.review_status, 'accepted');
  });

  test('标记存疑并记录原因', async () => {
    const fixture = await makeFixture('审核存疑');
    const created = await collect(fixture, 'school', { Q1: '1', Q2: '1' });

    const response = await api<{ review_status: string; review_note: string }>(
      ctx,
      'POST',
      `/api/respondents/${created.respondentId}/review`,
      { token: fixture.token, body: { status: 'flagged', note: '作答时间明显偏短' } },
    );
    assert.equal(response.data.review_status, 'flagged');
    assert.equal(response.data.review_note, '作答时间明显偏短');
  });

  test('排除样本必须填写原因', async () => {
    const fixture = await makeFixture('排除需原因');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });

    const withoutNote = await api(ctx, 'POST', `/api/respondents/${created.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'excluded' },
    });
    assert.equal(withoutNote.status, 400);
    assert.match(withoutNote.error?.message ?? '', /必须填写原因/);

    const withNote = await api(ctx, 'POST', `/api/respondents/${created.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'excluded', note: '重复提交（与 A0001 答案完全一致）' },
    });
    assert.equal(withNote.status, 200);
  });

  test('排除不会删除样本记录（数据保留，可回溯）', async () => {
    const fixture = await makeFixture('排除保留');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });

    await api(ctx, 'POST', `/api/respondents/${created.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'excluded', note: '测试排除' },
    });

    const stillThere = await api<{ respondent: { review_status: string }; answered_count: number }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.equal(stillThere.status, 200);
    assert.equal(stillThere.data.respondent.review_status, 'excluded');
    assert.equal(stillThere.data.answered_count, 2, '排除后作答记录仍保留');

    const rows = Number(
      ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM respondents WHERE id = ?', [created.respondentId]) ?? 0,
    );
    assert.equal(rows, 1, '平台不得自动删除样本');
  });

  test('拒绝未知审核状态', async () => {
    const fixture = await makeFixture('非法审核状态');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });

    const response = await api(ctx, 'POST', `/api/respondents/${created.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'deleted' },
    });
    assert.equal(response.status, 400);
  });

  test('审核状态汇总反映在样本列表中', async () => {
    const fixture = await makeFixture('审核汇总');
    const a = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    const b = await collect(fixture, 'wechat', { Q1: '1', Q2: '1' });
    await collect(fixture, 'school', { Q1: '2', Q2: '2' });

    await api(ctx, 'POST', `/api/respondents/${a.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'accepted' },
    });
    await api(ctx, 'POST', `/api/respondents/${b.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'excluded', note: '重复' },
    });

    const response = await api<{
      summary: { by_review_status: Record<string, number> };
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/respondents`, { token: fixture.token });

    assert.equal(response.data.summary.by_review_status['accepted'], 1);
    assert.equal(response.data.summary.by_review_status['excluded'], 1);
    assert.equal(response.data.summary.by_review_status['unreviewed'], 1);
  });

  test('可按审核状态筛选', async () => {
    const fixture = await makeFixture('审核筛选');
    const a = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    await collect(fixture, 'wechat', { Q1: '1', Q2: '1' });

    await api(ctx, 'POST', `/api/respondents/${a.respondentId}/review`, {
      token: fixture.token,
      body: { status: 'accepted' },
    });

    const accepted = await api<{ total: number; items: { review_status: string }[] }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/respondents?review_status=accepted`,
      { token: fixture.token },
    );
    assert.equal(accepted.data.total, 1);
    assert.equal(accepted.data.items[0]?.review_status, 'accepted');
  });
});

/* ================================================================== */
/* Abandoned sweep                                                    */
/* ================================================================== */

describe('超时未完成样本标记', () => {
  test('超过阈值的进行中会话被标记为已中断', async () => {
    const fixture = await makeFixture('超时标记');
    const created = await collect(fixture, 'wechat', { Q1: '1' }, false);

    // 把最后活动时间提前，模拟长时间未回来填答
    const old = new Date(Date.now() - 48 * 3600 * 1000).toISOString();
    ctx.db.run('UPDATE respondents SET last_activity_at = ?, started_at = ? WHERE id = ?', [
      old,
      old,
      created.respondentId,
    ]);

    const sweep = await api<{ marked: number }>(
      ctx,
      'POST',
      `/api/projects/${fixture.projectId}/respondents/sweep`,
      { token: fixture.token, body: { older_than_hours: 24 } },
    );
    assert.equal(sweep.status, 200);
    assert.equal(sweep.data.marked, 1);

    const detail = await api<{ respondent: { status: string } }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.equal(detail.data.respondent.status, 'abandoned');
  });

  test('未超过阈值的会话不受影响', async () => {
    const fixture = await makeFixture('未超时');
    const created = await collect(fixture, 'wechat', { Q1: '1' }, false);

    const sweep = await api<{ marked: number }>(
      ctx,
      'POST',
      `/api/projects/${fixture.projectId}/respondents/sweep`,
      { token: fixture.token, body: { older_than_hours: 24 } },
    );
    assert.equal(sweep.data.marked, 0);

    const detail = await api<{ respondent: { status: string } }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.equal(detail.data.respondent.status, 'in_progress');
  });

  test('已完成的样本不会被超时标记覆盖', async () => {
    const fixture = await makeFixture('已完成不覆盖');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });

    const old = new Date(Date.now() - 72 * 3600 * 1000).toISOString();
    ctx.db.run('UPDATE respondents SET last_activity_at = ?, started_at = ? WHERE id = ?', [
      old,
      old,
      created.respondentId,
    ]);

    await api(ctx, 'POST', `/api/projects/${fixture.projectId}/respondents/sweep`, {
      token: fixture.token,
      body: { older_than_hours: 24 },
    });

    const detail = await api<{ respondent: { status: string } }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.equal(detail.data.respondent.status, 'completed');
  });
});

/* ================================================================== */
/* Isolation                                                          */
/* ================================================================== */

describe('样本数据隔离', () => {
  test('他人无法列出我的项目样本', async () => {
    const fixture = await makeFixture('隔离列表');
    const intruder = await registerResearcher(ctx);

    const response = await api(ctx, 'GET', `/api/projects/${fixture.projectId}/respondents`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });

  test('他人无法查看我的样本详情', async () => {
    const fixture = await makeFixture('隔离详情');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    const intruder = await registerResearcher(ctx);

    const response = await api(ctx, 'GET', `/api/respondents/${created.respondentId}`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });

  test('他人无法修改我的样本审核状态', async () => {
    const fixture = await makeFixture('隔离审核');
    const created = await collect(fixture, 'wechat', { Q1: '2', Q2: '3' });
    const intruder = await registerResearcher(ctx);

    const response = await api(ctx, 'POST', `/api/respondents/${created.respondentId}/review`, {
      token: intruder.token,
      body: { status: 'excluded', note: '越权操作' },
    });
    assert.equal(response.status, 404);

    const check = await api<{ respondent: { review_status: string } }>(
      ctx,
      'GET',
      `/api/respondents/${created.respondentId}`,
      { token: fixture.token },
    );
    assert.equal(check.data.respondent.review_status, 'unreviewed');
  });

  test('他人无法读取我的渠道统计', async () => {
    const fixture = await makeFixture('隔离渠道');
    const intruder = await registerResearcher(ctx);

    const response = await api(ctx, 'GET', `/api/projects/${fixture.projectId}/sources`, {
      token: intruder.token,
    });
    assert.equal(response.status, 404);
  });

  test('未登录无法访问样本接口', async () => {
    const fixture = await makeFixture('未登录样本');
    const list = await api(ctx, 'GET', `/api/projects/${fixture.projectId}/respondents`);
    assert.equal(list.status, 401);

    const sources = await api(ctx, 'GET', `/api/projects/${fixture.projectId}/sources`);
    assert.equal(sources.status, 401);
  });
});
