/**
 * Dependency-free distribution charts.
 *
 * Rendered as plain SVG rather than pulling in a charting library: the
 * dashboard only needs bar charts and quota progress bars, and hand-rolled SVG
 * keeps the bundle small and the encoding unambiguous. A richer charting layer
 * (ECharts/Recharts) belongs to the visualisation phase.
 */

import type { ReactNode } from 'react';
import type { Distribution, QuotaProgress } from '../lib/api';
import { formatStat } from '../lib/format';

/* ------------------------------------------------------------------ */
/* Horizontal bars — right choice for long Chinese category labels     */
/* ------------------------------------------------------------------ */

export function DistributionBarChart({ distribution }: { distribution: Distribution }): ReactNode {
  const items = distribution.counts.filter((item) => item.count > 0 || distribution.kind !== 'multi');
  const max = Math.max(1, ...items.map((item) => (distribution.kind === 'matrix_row_means' ? item.percent : item.count)));

  if (distribution.n === 0) {
    return (
      <p className="py-6 text-center text-sm text-ink-400">
        该变量暂无有效作答（缺失 {distribution.missing}，敏感拒答 {distribution.sensitive_nonresponse}）。
      </p>
    );
  }

  return (
    <ul className="space-y-2">
      {items.map((item) => {
        const isMean = distribution.kind === 'matrix_row_means';
        const value = isMean ? item.percent : item.count;
        const width = max > 0 ? (value / max) * 100 : 0;
        return (
          <li key={item.value}>
            <div className="mb-1 flex items-baseline justify-between gap-3 text-xs">
              <span className="truncate text-ink-700" title={item.label}>
                {item.label}
              </span>
              <span className="shrink-0 tabular-nums text-ink-500">
                {isMean
                  ? `均值 ${formatStat(item.percent)} (n=${item.count})`
                  : `${item.count} 人 · ${item.percent.toFixed(1)}%`}
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-ink-100">
              <div
                className="h-full rounded-full bg-brand-500"
                style={{ width: `${Math.max(width, value > 0 ? 2 : 0)}%` }}
              />
            </div>
          </li>
        );
      })}
    </ul>
  );
}

/* ------------------------------------------------------------------ */
/* Likert distribution (diverging stacks)                             */
/* ------------------------------------------------------------------ */

export function LikertStack({ distribution }: { distribution: Distribution }): ReactNode {
  if (distribution.n === 0) {
    return <p className="py-6 text-center text-sm text-ink-400">暂无有效作答。</p>;
  }
  const palette = ['bg-ink-300', 'bg-ink-400', 'bg-ink-200', 'bg-brand-400', 'bg-brand-600'];
  return (
    <div>
      <div className="flex h-4 w-full overflow-hidden rounded-full">
        {distribution.counts.map((item, index) => (
          <div
            key={item.value}
            className={`${palette[index] ?? 'bg-ink-300'} h-full`}
            style={{ width: `${item.percent}%` }}
            title={`${item.label}: ${item.count} 人（${item.percent}%）`}
          />
        ))}
      </div>
      <ul className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-ink-600 sm:grid-cols-3">
        {distribution.counts.map((item, index) => (
          <li key={item.value} className="flex items-center gap-2">
            <span className={`inline-block h-2.5 w-2.5 rounded-sm ${palette[index] ?? 'bg-ink-300'}`} />
            <span className="truncate" title={item.label}>
              {item.label}
            </span>
            <span className="ml-auto tabular-nums text-ink-500">{item.percent.toFixed(1)}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Quota progress                                                     */
/* ------------------------------------------------------------------ */

export function QuotaProgressList({ progress }: { progress: QuotaProgress[] }): ReactNode {
  if (progress.length === 0) return null;
  return (
    <ul className="space-y-3">
      {progress.map((item) => (
        <li key={`${item.dimension}-${item.category}`}>
          <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
            <span className="text-ink-800">{item.category}</span>
            <span className="tabular-nums text-ink-600">
              {item.current_n}/{item.target_n}
              <span className={`ml-2 ${item.met ? 'text-emerald-600' : 'text-amber-600'}`}>
                {item.percent.toFixed(1)}%
              </span>
            </span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-ink-100">
            <div
              className={`h-full rounded-full ${item.met ? 'bg-emerald-500' : 'bg-amber-500'}`}
              style={{ width: `${Math.min(item.percent, 100)}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

/* ------------------------------------------------------------------ */
/* Missing-data summary                                               */
/* ------------------------------------------------------------------ */

export function DataCompletenessNote({ distribution }: { distribution: Distribution }): ReactNode {
  return (
    <p className="mt-3 text-xs text-ink-500">
      分析基数 n={distribution.base_n} · 有效作答 {distribution.n} · 缺失 {distribution.missing}
      {distribution.sensitive_nonresponse > 0 && (
        <span className="ml-1 text-amber-700">
          · 敏感拒答 {distribution.sensitive_nonresponse}（单独计数，未并入任何类别）
        </span>
      )}
      {distribution.mean !== null && (
        <span className="ml-1">
          · 均值 {formatStat(distribution.mean)}
          {distribution.sd !== null && ` · SD ${formatStat(distribution.sd)}`}
          {distribution.median !== null && ` · 中位数 ${formatStat(distribution.median)}`}
        </span>
      )}
    </p>
  );
}
