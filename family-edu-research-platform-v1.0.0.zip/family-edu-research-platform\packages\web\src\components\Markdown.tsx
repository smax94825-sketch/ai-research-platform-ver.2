/**
 * A small Markdown renderer for the research report (PHASE 8).
 *
 * Hand-written and dependency-free on purpose: the platform ships offline and
 * adding a Markdown library (plus its transitive dependencies) for one report
 * would be the largest dependency in the console.
 *
 * Two properties matter more than completeness:
 *
 *  - **No HTML is ever injected.** Every node is built as a React element, so a
 *    body containing `<script>` renders as text. Nothing here needs a sanitiser.
 *  - **Line structure is preserved.** The report is written as one paragraph per
 *    line (the service builds bodies from explicit arrays), so each non-blank
 *    line becomes its own block instead of being re-flowed into a wall of text.
 *    Blank lines are separators only.
 *
 * Supported: `#`–`####` headings, `---` rules, `>` quotes, `-`/`*` bullets,
 * `1.` ordered items, `|`-tables with a `---` separator row, and inline
 * `**bold**`, `*italic*` and `` `code` ``.
 */

import { Fragment, type ReactNode } from 'react';

/** Split a line into inline runs, leaving everything else as plain text. */
function renderInline(text: string, keyPrefix: string): ReactNode[] {
  const pattern = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g;
  const parts = text.split(pattern);

  return parts.map((part, index) => {
    const key = `${keyPrefix}-${index}`;
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return <strong key={key}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      return (
        <code key={key} className="rounded bg-ink-100 px-1 py-0.5 font-mono text-[0.9em]">
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
      return <em key={key}>{part.slice(1, -1)}</em>;
    }
    return <Fragment key={key}>{part}</Fragment>;
  });
}

/** `| a | b |` -> `['a', 'b']`; a missing leading/trailing pipe is tolerated. */
function tableCells(line: string): string[] {
  return line
    .replace(/^\s*\|/, '')
    .replace(/\|\s*$/, '')
    .split('|')
    .map((cell) => cell.trim());
}

function isTableSeparator(line: string): boolean {
  return /^\s*\|?[\s:|-]*-[\s:|-]*\|?\s*$/.test(line) && line.includes('-');
}

const HEADING_CLASS: Record<number, string> = {
  1: 'text-lg font-semibold text-ink-900',
  2: 'text-base font-semibold text-ink-900',
  3: 'text-sm font-semibold text-ink-900',
  4: 'text-sm font-medium text-ink-800',
};

interface TableBlock {
  headers: string[];
  rows: string[][];
}

function renderTable(block: TableBlock, key: string): ReactNode {
  return (
    <div key={key} className="overflow-x-auto">
      <table className="w-full min-w-[520px] border-collapse text-xs">
        <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
          <tr>
            {block.headers.map((header, index) => (
              <th key={`${key}-h-${index}`} className="border border-ink-200 px-2 py-1.5 text-left">
                {renderInline(header, `${key}-h-${index}`)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {block.rows.map((row, rowIndex) => (
            <tr key={`${key}-r-${rowIndex}`}>
              {row.map((cell, cellIndex) => (
                <td
                  key={`${key}-r-${rowIndex}-${cellIndex}`}
                  className="border border-ink-200 px-2 py-1.5 align-top tabular-nums text-ink-800"
                >
                  {renderInline(cell, `${key}-r-${rowIndex}-${cellIndex}`)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Markdown({ text, className = '' }: { text: string; className?: string }): ReactNode {
  const lines = text.split(/\r?\n/);
  const blocks: ReactNode[] = [];

  let index = 0;
  while (index < lines.length) {
    const line = lines[index] ?? '';
    const trimmed = line.trim();
    const key = `md-${index}`;

    if (trimmed === '') {
      index += 1;
      continue;
    }

    // Table: a `|`-row whose next line is the `---` separator.
    if (trimmed.startsWith('|') && isTableSeparator(lines[index + 1] ?? '')) {
      const headers = tableCells(trimmed);
      const rows: string[][] = [];
      let cursor = index + 2;
      while (cursor < lines.length && (lines[cursor] ?? '').trim().startsWith('|')) {
        rows.push(tableCells((lines[cursor] ?? '').trim()));
        cursor += 1;
      }
      blocks.push(renderTable({ headers, rows }, key));
      index = cursor;
      continue;
    }

    if (/^-{3,}$/.test(trimmed)) {
      blocks.push(<hr key={key} className="border-ink-200" />);
      index += 1;
      continue;
    }

    const heading = /^(#{1,4})\s+(.*)$/.exec(trimmed);
    if (heading) {
      const level = (heading[1] ?? '#').length;
      const Tag = (level === 1 ? 'h1' : level === 2 ? 'h2' : level === 3 ? 'h3' : 'h4') as
        | 'h1'
        | 'h2'
        | 'h3'
        | 'h4';
      blocks.push(
        <Tag key={key} className={`mt-1 ${HEADING_CLASS[level] ?? 'text-sm'}`}>
          {renderInline(heading[2] ?? '', `${key}-i`)}
        </Tag>,
      );
      index += 1;
      continue;
    }

    if (trimmed.startsWith('> ')) {
      const quote: string[] = [];
      let cursor = index;
      while (cursor < lines.length && (lines[cursor] ?? '').trim().startsWith('> ')) {
        quote.push((lines[cursor] ?? '').trim().slice(2));
        cursor += 1;
      }
      blocks.push(
        <blockquote
          key={key}
          className="border-l-4 border-brand-300 bg-brand-50 px-3 py-2 text-sm text-ink-800"
        >
          {quote.map((item, quoteIndex) => (
            <p key={`${key}-q-${quoteIndex}`} className="mt-0.5 first:mt-0">
              {renderInline(item, `${key}-q-${quoteIndex}`)}
            </p>
          ))}
        </blockquote>,
      );
      index = cursor;
      continue;
    }

    if (/^[-*]\s+/.test(trimmed)) {
      const items: string[] = [];
      let cursor = index;
      while (cursor < lines.length && /^[-*]\s+/.test((lines[cursor] ?? '').trim())) {
        items.push((lines[cursor] ?? '').trim().replace(/^[-*]\s+/, ''));
        cursor += 1;
      }
      blocks.push(
        <ul key={key} className="list-disc space-y-1 pl-5 text-sm leading-relaxed text-ink-800">
          {items.map((item, itemIndex) => (
            <li key={`${key}-l-${itemIndex}`}>{renderInline(item, `${key}-l-${itemIndex}`)}</li>
          ))}
        </ul>,
      );
      index = cursor;
      continue;
    }

    if (/^\d+[.)]\s+/.test(trimmed)) {
      const items: string[] = [];
      let cursor = index;
      while (cursor < lines.length && /^\d+[.)]\s+/.test((lines[cursor] ?? '').trim())) {
        items.push((lines[cursor] ?? '').trim().replace(/^\d+[.)]\s+/, ''));
        cursor += 1;
      }
      blocks.push(
        <ol key={key} className="list-decimal space-y-1 pl-5 text-sm leading-relaxed text-ink-800">
          {items.map((item, itemIndex) => (
            <li key={`${key}-o-${itemIndex}`}>{renderInline(item, `${key}-o-${itemIndex}`)}</li>
          ))}
        </ol>,
      );
      index = cursor;
      continue;
    }

    blocks.push(
      <p key={key} className="text-sm leading-relaxed text-ink-800">
        {renderInline(trimmed, `${key}-p`)}
      </p>,
    );
    index += 1;
  }

  return <div className={`space-y-2 ${className}`}>{blocks}</div>;
}
