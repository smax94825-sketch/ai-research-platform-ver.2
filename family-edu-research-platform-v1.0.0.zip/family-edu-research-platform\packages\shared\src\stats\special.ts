/**
 * Special functions and probability distributions (PHASE 5).
 *
 * Everything the statistical engine needs to turn a test statistic into a
 * p-value. Implemented directly rather than pulling in a numerics library so the
 * results are auditable and reproducible, and so the engine has no runtime
 * dependency that could change a reported p-value underneath a published paper.
 *
 * Accuracy target: ~1e-10 relative for the central region, which is far tighter
 * than the precision at which p-values are reported (3 decimals). The tests
 * check against published critical values.
 */

/* ------------------------------------------------------------------ */
/* Gamma functions                                                    */
/* ------------------------------------------------------------------ */

/** Lanczos coefficients for g = 7, n = 9 (standard, ~15 significant digits). */
const LANCZOS_G = 7;
const LANCZOS_COEFFICIENTS = [
  0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313,
  -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6,
  1.5056327351493116e-7,
];

export function logGamma(x: number): number {
  if (Number.isNaN(x)) return Number.NaN;
  if (x <= 0) {
    // Reflection formula for x < 0.5; poles at non-positive integers.
    if (Number.isInteger(x)) return Number.POSITIVE_INFINITY;
    return (
      Math.log(Math.PI / Math.abs(Math.sin(Math.PI * x))) - logGamma(1 - x)
    );
  }
  if (x < 0.5) {
    return Math.log(Math.PI / Math.sin(Math.PI * x)) - logGamma(1 - x);
  }

  const z = x - 1;
  let sum = LANCZOS_COEFFICIENTS[0]!;
  for (let index = 1; index < LANCZOS_COEFFICIENTS.length; index += 1) {
    sum += LANCZOS_COEFFICIENTS[index]! / (z + index);
  }
  const t = z + LANCZOS_G + 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(sum);
}

export function gamma(x: number): number {
  return Math.exp(logGamma(x));
}

/* ------------------------------------------------------------------ */
/* Incomplete beta                                                    */
/* ------------------------------------------------------------------ */

/** Continued fraction for the regularized incomplete beta function. */
function betaContinuedFraction(a: number, b: number, x: number): number {
  const MAX_ITERATIONS = 300;
  const EPSILON = 3e-16;
  const TINY = 1e-300;

  const qab = a + b;
  const qap = a + 1;
  const qam = a - 1;

  let c = 1;
  let d = 1 - (qab * x) / qap;
  if (Math.abs(d) < TINY) d = TINY;
  d = 1 / d;
  let h = d;

  for (let m = 1; m <= MAX_ITERATIONS; m += 1) {
    const m2 = 2 * m;

    // Even step.
    let aa = (m * (b - m) * x) / ((qam + m2) * (a + m2));
    d = 1 + aa * d;
    if (Math.abs(d) < TINY) d = TINY;
    c = 1 + aa / c;
    if (Math.abs(c) < TINY) c = TINY;
    d = 1 / d;
    h *= d * c;

    // Odd step.
    aa = (-(a + m) * (qab + m) * x) / ((a + m2) * (qap + m2));
    d = 1 + aa * d;
    if (Math.abs(d) < TINY) d = TINY;
    c = 1 + aa / c;
    if (Math.abs(c) < TINY) c = TINY;
    d = 1 / d;
    const delta = d * c;
    h *= delta;

    if (Math.abs(delta - 1) < EPSILON) break;
  }

  return h;
}

/**
 * Regularized incomplete beta function I_x(a, b).
 * The CDF of the t, F and binomial distributions all reduce to this.
 *
 * The complement branch is evaluated directly rather than by recursing with
 * (b, a, 1-x): at the boundary x = (a+1)/(a+b+2) the recursive form re-enters
 * with identical arguments whenever a == b and x == 0.5 (which happens for
 * I_0.5(1,1)), producing unbounded recursion.
 */
export function incompleteBeta(a: number, b: number, x: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;

  const logBeta = logGamma(a + b) - logGamma(a) - logGamma(b);

  if (x < (a + 1) / (a + b + 2)) {
    const front = Math.exp(logBeta + a * Math.log(x) + b * Math.log(1 - x)) / a;
    return front * betaContinuedFraction(a, b, x);
  }

  const complementFront = Math.exp(logBeta + b * Math.log(1 - x) + a * Math.log(x)) / b;
  return 1 - complementFront * betaContinuedFraction(b, a, 1 - x);
}

/* ------------------------------------------------------------------ */
/* Incomplete gamma                                                   */
/* ------------------------------------------------------------------ */

/** Regularized lower incomplete gamma P(a, x) via series expansion. */
function gammaSeries(a: number, x: number): number {
  const MAX_ITERATIONS = 500;
  const EPSILON = 3e-16;

  let ap = a;
  let sum = 1 / a;
  let del = sum;

  for (let n = 1; n <= MAX_ITERATIONS; n += 1) {
    ap += 1;
    del *= x / ap;
    sum += del;
    if (Math.abs(del) < Math.abs(sum) * EPSILON) break;
  }

  return sum * Math.exp(-x + a * Math.log(x) - logGamma(a));
}

/** Regularized upper incomplete gamma Q(a, x) via continued fraction. */
function gammaContinuedFraction(a: number, x: number): number {
  const MAX_ITERATIONS = 500;
  const EPSILON = 3e-16;
  const TINY = 1e-300;

  let b = x + 1 - a;
  let c = 1 / TINY;
  let d = 1 / b;
  let h = d;

  for (let i = 1; i <= MAX_ITERATIONS; i += 1) {
    const an = -i * (i - a);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < TINY) d = TINY;
    c = b + an / c;
    if (Math.abs(c) < TINY) c = TINY;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < EPSILON) break;
  }

  return Math.exp(-x + a * Math.log(x) - logGamma(a)) * h;
}

/** Regularized lower incomplete gamma P(a, x). */
export function incompleteGammaLower(a: number, x: number): number {
  if (x <= 0) return 0;
  if (x < a + 1) return gammaSeries(a, x);
  return 1 - gammaContinuedFraction(a, x);
}

/** Regularized upper incomplete gamma Q(a, x) = 1 - P(a, x). */
export function incompleteGammaUpper(a: number, x: number): number {
  if (x <= 0) return 1;
  if (x < a + 1) return 1 - gammaSeries(a, x);
  return gammaContinuedFraction(a, x);
}

/* ------------------------------------------------------------------ */
/* Error function and normal distribution                             */
/* ------------------------------------------------------------------ */

export function erf(x: number): number {
  if (x === 0) return 0;
  const sign = x < 0 ? -1 : 1;
  const value = incompleteGammaLower(0.5, x * x);
  return sign * value;
}

export function erfc(x: number): number {
  return 1 - erf(x);
}

/** Standard normal CDF Φ(z). */
export function normalCdf(z: number): number {
  if (!Number.isFinite(z)) return z > 0 ? 1 : 0;
  return 0.5 * erfc(-z / Math.SQRT2);
}

/** Standard normal PDF φ(z). */
export function normalPdf(z: number): number {
  return Math.exp(-0.5 * z * z) / Math.sqrt(2 * Math.PI);
}

/**
 * Standard normal quantile Φ⁻¹(p).
 * Acklam's rational approximation, refined by one Halley step so the result is
 * accurate to ~1e-15 — needed because confidence intervals are reported to 3dp.
 */
export function normalQuantile(p: number): number {
  if (p <= 0) return Number.NEGATIVE_INFINITY;
  if (p >= 1) return Number.POSITIVE_INFINITY;

  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.38357751867269e2, -3.066479806614716e1, 2.506628277459239];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];

  const pLow = 0.02425;
  const pHigh = 1 - pLow;
  let x: number;

  if (p < pLow) {
    const q = Math.sqrt(-2 * Math.log(p));
    x =
      (((((c[0]! * q + c[1]!) * q + c[2]!) * q + c[3]!) * q + c[4]!) * q + c[5]!) /
      ((((d[0]! * q + d[1]!) * q + d[2]!) * q + d[3]!) * q + 1);
  } else if (p <= pHigh) {
    const q = p - 0.5;
    const r = q * q;
    x =
      ((((((a[0]! * r + a[1]!) * r + a[2]!) * r + a[3]!) * r + a[4]!) * r + a[5]!) * q) /
      (((((b[0]! * r + b[1]!) * r + b[2]!) * r + b[3]!) * r + b[4]!) * r + 1);
  } else {
    const q = Math.sqrt(-2 * Math.log(1 - p));
    x =
      -(((((c[0]! * q + c[1]!) * q + c[2]!) * q + c[3]!) * q + c[4]!) * q + c[5]!) /
      ((((d[0]! * q + d[1]!) * q + d[2]!) * q + d[3]!) * q + 1);
  }

  // One Halley refinement step.
  const e = normalCdf(x) - p;
  const u = e * Math.sqrt(2 * Math.PI) * Math.exp((x * x) / 2);
  return x - u / (1 + (x * u) / 2);
}

/* ------------------------------------------------------------------ */
/* t distribution                                                     */
/* ------------------------------------------------------------------ */

/** Student t CDF. */
export function studentTCdf(t: number, degreesOfFreedom: number): number {
  if (degreesOfFreedom <= 0) return Number.NaN;
  if (!Number.isFinite(t)) return t > 0 ? 1 : 0;
  const x = degreesOfFreedom / (degreesOfFreedom + t * t);
  const probability = 0.5 * incompleteBeta(degreesOfFreedom / 2, 0.5, x);
  return t > 0 ? 1 - probability : probability;
}

/** Two-tailed p-value for a t statistic. */
export function studentTTwoTailedP(t: number, degreesOfFreedom: number): number {
  if (!Number.isFinite(t)) return 0;
  const x = degreesOfFreedom / (degreesOfFreedom + t * t);
  return incompleteBeta(degreesOfFreedom / 2, 0.5, x);
}

/** One-tailed p-value (upper tail) for a t statistic. */
export function studentTUpperTailP(t: number, degreesOfFreedom: number): number {
  return t >= 0 ? studentTTwoTailedP(t, degreesOfFreedom) / 2 : 1 - studentTTwoTailedP(t, degreesOfFreedom) / 2;
}

/** t quantile (inverse CDF) by bisection — robust and adequate for reporting. */
export function studentTQuantile(p: number, degreesOfFreedom: number): number {
  if (p <= 0) return Number.NEGATIVE_INFINITY;
  if (p >= 1) return Number.POSITIVE_INFINITY;

  let low = -1e6;
  let high = 1e6;
  for (let iteration = 0; iteration < 200; iteration += 1) {
    const mid = (low + high) / 2;
    if (studentTCdf(mid, degreesOfFreedom) < p) low = mid;
    else high = mid;
    if (high - low < 1e-12) break;
  }
  return (low + high) / 2;
}

/* ------------------------------------------------------------------ */
/* F distribution                                                     */
/* ------------------------------------------------------------------ */

/** F CDF. */
export function fCdf(f: number, df1: number, df2: number): number {
  if (f <= 0) return 0;
  if (df1 <= 0 || df2 <= 0) return Number.NaN;
  const x = (df1 * f) / (df1 * f + df2);
  return incompleteBeta(df1 / 2, df2 / 2, x);
}

/** Upper-tail p-value for an F statistic. */
export function fUpperTailP(f: number, df1: number, df2: number): number {
  if (!Number.isFinite(f) || f <= 0) return 1;
  return 1 - fCdf(f, df1, df2);
}

export function fQuantile(p: number, df1: number, df2: number): number {
  if (p <= 0) return 0;
  if (p >= 1) return Number.POSITIVE_INFINITY;
  let low = 0;
  let high = 1e7;
  for (let iteration = 0; iteration < 200; iteration += 1) {
    const mid = (low + high) / 2;
    if (fCdf(mid, df1, df2) < p) low = mid;
    else high = mid;
    if (high - low < 1e-12 * Math.max(1, low)) break;
  }
  return (low + high) / 2;
}

/* ------------------------------------------------------------------ */
/* Chi-square distribution                                            */
/* ------------------------------------------------------------------ */

/** Chi-square CDF. */
export function chiSquareCdf(x: number, degreesOfFreedom: number): number {
  if (x <= 0) return 0;
  if (degreesOfFreedom <= 0) return Number.NaN;
  return incompleteGammaLower(degreesOfFreedom / 2, x / 2);
}

/** Upper-tail p-value for a chi-square statistic. */
export function chiSquareUpperTailP(x: number, degreesOfFreedom: number): number {
  if (!Number.isFinite(x) || x <= 0) return 1;
  return incompleteGammaUpper(degreesOfFreedom / 2, x / 2);
}

export function chiSquareQuantile(p: number, degreesOfFreedom: number): number {
  if (p <= 0) return 0;
  if (p >= 1) return Number.POSITIVE_INFINITY;
  let low = 0;
  let high = 1e6;
  for (let iteration = 0; iteration < 200; iteration += 1) {
    const mid = (low + high) / 2;
    if (chiSquareCdf(mid, degreesOfFreedom) < p) low = mid;
    else high = mid;
    if (high - low < 1e-12 * Math.max(1, low)) break;
  }
  return (low + high) / 2;
}

/* ------------------------------------------------------------------ */
/* Helpers used across the engine                                     */
/* ------------------------------------------------------------------ */

/** Two-tailed p from a z statistic (large-sample tests). */
export function normalTwoTailedP(z: number): number {
  if (!Number.isFinite(z)) return 0;
  return 2 * (1 - normalCdf(Math.abs(z)));
}

/**
 * Round for presentation without changing the underlying value.
 * The engine keeps full precision internally and rounds only at the edges.
 */
export function roundTo(value: number, digits = 4): number {
  if (!Number.isFinite(value)) return value;
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

/**
 * Format a p-value the way journals expect: 3 decimals, with a floor of .001
 * rather than a bare 0 (which would overstate certainty).
 */
export function formatP(p: number): string {
  if (!Number.isFinite(p)) return 'NA';
  if (p < 0.001) return '< .001';
  return p.toFixed(3);
}

/** Significance marker used in result tables. */
export function significanceStars(p: number): string {
  if (!Number.isFinite(p)) return '';
  if (p < 0.001) return '***';
  if (p < 0.01) return '**';
  if (p < 0.05) return '*';
  return '';
}
