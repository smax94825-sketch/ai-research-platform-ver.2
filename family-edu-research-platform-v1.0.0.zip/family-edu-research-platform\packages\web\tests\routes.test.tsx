/**
 * Route wiring for the PHASE 7/8/9 console pages.
 *
 * The sidebar test asserts the links themselves; this one renders the real `App`
 * router at each new path, so a link that exists but points at a route nobody
 * declared (or at a page that throws on mount) fails here rather than in front of
 * a researcher.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { flush, render, text, unmount } from './render';

const { App } = await import('../src/App');
const { AuthProvider } = await import('../src/lib/auth');

const RESEARCHER = {
  id: 'r-1',
  name: '张研究者',
  email: 'zhang@example.edu',
  affiliation: '某大学教育学院',
  created_at: '2026-01-01T00:00:00.000Z',
  updated_at: '2026-01-01T00:00:00.000Z',
};

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育投入研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'analyzing',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

/** One routing table covering everything the four new pages touch on mount. */
function stubApi() {
  return stubFetch((call: FetchCall) => {
    const url = call.url;
    if (url.includes('/api/auth/me')) return jsonResponse({ data: RESEARCHER });
    if (url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
    if (url.includes('/ai/status')) {
      return jsonResponse({
        data: {
          configured: false,
          mode: 'degraded',
          reason: '未配置 DEEPSEEK_API_KEY 环境变量，AI 解释功能不可用。',
          model: 'deepseek-chat',
          base_url: 'https://api.deepseek.com/v1',
          timeout_ms: 60000,
          has_bundle: true,
          bundle_generated_at: '2026-02-01T09:30:00.000Z',
          latest_interaction_at: null,
          latest_mode: null,
        },
      });
    }
    if (url.includes('/ai/history')) return jsonResponse({ data: [] });
    if (url.includes('/analysis/hypotheses')) {
      return jsonResponse({
        data: {
          engine_version: '1.0.0',
          summary: { total: 0, supported: 0, not_supported: 0, inconclusive: 0, untestable: 0 },
          unavailable_variables: [],
          note: '尚无假设。',
          results: [],
        },
      });
    }
    if (url.includes('/competition/report')) {
      return jsonResponse({ data: { available: false, reason: '尚未生成创业洞察报告。' } });
    }
    if (url.includes('/competition/history')) {
      return jsonResponse({ data: { blocks: {}, items: [] } });
    }
    if (url.includes('/analysis/bundle')) {
      return jsonResponse({
        data: { available: false, engine_version: '1.0.0', reason: '尚未运行过完整统计分析。' },
      });
    }
    if (url.includes('/report')) {
      return jsonResponse({
        data: {
          error: { code: 'VALIDATION_ERROR', message: '尚未运行完整统计分析，无法生成研究报告。' },
        },
      }, 400);
    }
    return jsonResponse({ data: null });
  });
}

/**
 * Mount the real app at a path, with a session token in place.
 *
 * The token is written here rather than in a `beforeEach` hook on purpose: this
 * runner shares one process across test files and runs every file's hooks before
 * every test, so another file's hook can clear storage between a hook and the
 * test body. Writing it immediately before mounting keeps the bootstrap request
 * deterministic.
 */
async function renderAt(path: string): Promise<void> {
  window.localStorage.setItem('ferp.token', 'test-token');
  await render(
    createElement(
      MemoryRouter,
      { initialEntries: [path] },
      createElement(AuthProvider, null, createElement(App)),
    ),
  );
  await flush();
  await flush();
  await flush();
}

beforeEach(() => {
  clearContainer();
});

after(() => {
  // The suite shares one process and one jsdom: leave no token behind.
  window.localStorage.clear();
  closeDom();
});

describe('PHASE 7/8/9 路由', () => {
  test('/ai 渲染 AI 解释页', async () => {
    const stub = stubApi();
    try {
      await renderAt('/ai');
      const content = text();
      assert.match(content, /AI 研究助手|AI Research Assistant/);
      assert.match(content, /AI 解释可用性/);
      assert.match(content, /未配置 DEEPSEEK_API_KEY/, '页面挂载时应读取状态接口');
    } finally {
      await unmount();
      stub.restore();
    }
  });

  test('/report 渲染研究报告页（无结果包时给出接口原因）', async () => {
    const stub = stubApi();
    try {
      await renderAt('/report');
      const content = text();
      assert.match(content, /Research Reports/);
      assert.match(content, /尚未运行完整统计分析，无法生成研究报告/);
    } finally {
      await unmount();
      stub.restore();
    }
  });

  test('/export 渲染数据导出页', async () => {
    const stub = stubApi();
    try {
      await renderAt('/export');
      const content = text();
      assert.match(content, /数据导出：原始数据、变量字典、SPSS 文件与分析结果工作簿/);
      assert.match(content, /缺失值一律导出为空/);
      assert.ok(content.includes('results.xlsx'));
    } finally {
      await unmount();
      stub.restore();
    }
  });

  test('/competition 渲染创业洞察页', async () => {
    const stub = stubApi();
    try {
      await renderAt('/competition');
      const content = text();
      assert.match(content, /Insights \/ Competition Mode/);
      assert.match(content, /尚未生成创业洞察报告/);
      assert.match(content, /生成创业洞察/);
    } finally {
      await unmount();
      stub.restore();
    }
  });
});
