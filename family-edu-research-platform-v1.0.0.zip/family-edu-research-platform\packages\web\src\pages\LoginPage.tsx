import { useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Alert, Button, Card, Field, Input } from '../components/ui';
import { useAuth } from '../lib/auth';

export function LoginPage(): ReactNode {
  const { login, error, clearError } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent): Promise<void> {
    event.preventDefault();
    setSubmitting(true);
    try {
      await login(email.trim(), password);
      navigate('/', { replace: true });
    } catch {
      // The error message is surfaced from the auth context.
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <h1 className="text-xl font-semibold text-ink-900">家庭教育科研智能研究平台</h1>
          <p className="mt-1 text-sm text-ink-500">研究者登录</p>
        </div>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert tone="danger" title="登录失败">
                {error}
              </Alert>
            )}

            <Field label="邮箱" required>
              <Input
                type="email"
                autoComplete="username"
                required
                value={email}
                onChange={(event) => {
                  clearError();
                  setEmail(event.target.value);
                }}
                placeholder="researcher@example.com"
              />
            </Field>

            <Field label="密码" required>
              <Input
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(event) => {
                  clearError();
                  setPassword(event.target.value);
                }}
                placeholder="请输入密码"
              />
            </Field>

            <Button type="submit" variant="primary" className="w-full" loading={submitting}>
              登录
            </Button>
          </form>

          <p className="mt-4 text-center text-sm text-ink-500">
            还没有账号？
            <Link to="/register" className="ml-1 font-medium text-brand-600 hover:underline">
              注册研究者账号
            </Link>
          </p>
        </Card>

        <p className="mt-4 text-center text-xs text-ink-400">
          研究数据按研究者账号严格隔离；平台不收集受访者姓名、手机号等可识别身份的信息。
        </p>
      </div>
    </div>
  );
}
