/**
 * AI interpretation service (PHASE 7).
 *
 * The AI layer never produces facts. It receives the persisted `AnalysisBundle`
 * — the single artefact the statistical engine produced — and returns prose
 * *about* it. Five properties are enforced here rather than left to the prompt:
 *
 *  1. **No recomputation.** The bundle is read with `getLatestBundle`; nothing in
 *     this file computes, corrects or interpolates a statistic. With no bundle
 *     the service refuses (400) instead of interpreting nothing.
 *  2. **Four-level layering.** Every statement is classified as FACT,
 *     STATISTICAL_FINDING, INTERPRETATION or RECOMMENDATION, and the levels are
 *     returned in separate arrays. They are never merged into one blob, because
 *     a reader must be able to see where the engine stops and the model starts.
 *  3. **Evidence trace.** Every statement carries the exact bundle path(s) it
 *     rests on plus the value found there. A statement that cannot be traced to
 *     the bundle is dropped and reported, never shipped.
 *  4. **Numeric validation.** Every number the model quotes is checked against
 *     the bundle (`validateNumbers`). One untraceable number voids the whole
 *     statement, and the voiding is reported in `rejected_claims` rather than
 *     silently dropped — the model may not introduce a single number the engine
 *     did not compute.
 *  5. **Honest degraded mode.** With no API key (or an unreachable provider) the
 *     service returns `mode: 'degraded'` plus a deterministic Chinese summary
 *     assembled only from the bundle, clearly labelled as engine-derived. It
 *     never fabricates interpretation and never throws a 500 for a provider
 *     problem.
 *
 * Every interaction — including failed and degraded ones — is written to
 * `ai_interactions`, so a sentence in a report can always be traced back to the
 * prompt, the raw reply and the validation verdict that produced it.
 */

import { createHash } from 'node:crypto';

import type { Config, FetchLike } from '../config.js';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import { getLatestBundle, type AnalysisBundle } from './analysis.service.js';
import { parseJson } from './mappers.js';
import { requireProject } from './project.service.js';

/* ================================================================== */
/* Constants                                                          */
/* ================================================================== */

/** Shown whenever a caller asks for interpretation before an analysis run. */
export const NO_BUNDLE_MESSAGE =
  '尚未运行过完整统计分析，无法生成 AI 解释。请先在「统计分析」中执行「运行全部分析」，' +
  '之后 AI 才能基于统计引擎真实计算的结果包进行解释。';

/**
 * Rounding tolerance used when a quoted number is matched against the bundle.
 *
 * A model legitimately re-states a value with fewer decimals than the engine
 * stored, so an exact comparison would reject honest output. Two decimal places
 * (0.005 absolute) covers the usual "r = .36" style, and 0.5% relative covers
 * large counts. Nothing outside this window is accepted.
 */
export const NUMBER_ABSOLUTE_TOLERANCE = 0.005;
export const NUMBER_RELATIVE_TOLERANCE = 0.005;

/** Fields whose stored value is a percentage rather than a proportion or a count. */
const PERCENT_KEYS = new Set([
  'percent',
  'percent_of_total',
  'missing_percent',
  'percent_correct',
  'shared_variance_percent',
]);

/** Fields used to address an element of an array of records (e.g. `[FSE]`). */
const ARRAY_IDENTITY_FIELDS = [
  'variable',
  'scale',
  'code',
  'dependent',
  'term',
  'item',
  'group',
  'threshold',
  'name',
  'value',
] as const;

/** Paths that are strings of pure metadata; their digits are not statistics. */
const METADATA_PATH_KEYS = new Set(['id', 'generated_at', 'created_at', 'updated_at', 'project_id']);

const ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T/;

/**
 * A number token: an optional thousands-separated integer or a plain integer,
 * with optional decimals. Digits that are part of a word (H3, Q35, FSE1) are
 * never matched — a hypothesis code is not a statistic.
 */
const QUOTED_NUMBER_SOURCE = '(?<![\\w.])(\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?(?![\\w])';

/* ================================================================== */
/* Types — layering and evidence                                      */
/* ================================================================== */

/**
 * The four levels, in the order the API reports them.
 *
 * The order is the point: a reader walks from what the engine measured to what
 * a human (or a model) concluded.
 */
export type AiLevel = 'FACT' | 'STATISTICAL_FINDING' | 'INTERPRETATION' | 'RECOMMENDATION';

export const AI_LEVELS: readonly AiLevel[] = [
  'FACT',
  'STATISTICAL_FINDING',
  'INTERPRETATION',
  'RECOMMENDATION',
];

/**
 * Chinese rendering of each level.
 *
 * Returned alongside every statement so the layering survives being quoted into
 * a report: a reader of the prose must be able to see where the engine stopped
 * and the model started, without consulting the JSON structure.
 */
export const LEVEL_LABELS_ZH: Record<AiLevel, string> = {
  FACT: '事实',
  STATISTICAL_FINDING: '统计发现',
  INTERPRETATION: '解释',
  RECOMMENDATION: '建议',
};

export function labelStatement(level: AiLevel, text: string): string {
  return `【${LEVEL_LABELS_ZH[level]}】${text}`;
}

export type AiMode = 'live' | 'degraded';

/** One citation of an exact bundle location. */
export interface AiEvidence {
  /** Bundle path, e.g. `hypotheses.results[H3].r`. */
  path: string;
  /** The value found at that path, quoted from the bundle. */
  value: string | number | boolean | null;
  /** `declared` — the model cited it; `inferred` — derived from a validated number. */
  source: 'declared' | 'inferred';
}

export interface AiStatement {
  id: string;
  level: AiLevel;
  text: string;
  /**
   * The statement with its Chinese level label prefixed (`【统计发现】…`), so the
   * prose itself carries the layering into any downstream report.
   */
  labelled_text: string;
  evidence: AiEvidence[];
  /** True when the model omitted the level label and it was inferred from wording. */
  label_inferred: boolean;
  /** Hypothesis the statement is about, when one can be determined. */
  hypothesis_code: string | null;
}

/** Why a claim was refused. Machine-readable so the UI can explain it. */
export type RejectedClaimCode =
  | 'untraceable_number'
  | 'no_evidence'
  | 'evidence_path_not_found'
  | 'evidence_value_mismatch'
  | 'empty_statement';

export interface AiRejectedClaim {
  text: string;
  code: RejectedClaimCode;
  reason: string;
  /** The offending number, when the rejection was caused by one. */
  quoted_number: number | null;
  /** The number exactly as the model wrote it (keeps the unit/formatting). */
  raw_number: string | null;
  level: AiLevel | null;
}

/** The four levels, kept separate all the way to the client. */
export interface AiLayers {
  facts: AiStatement[];
  statistical_findings: AiStatement[];
  interpretations: AiStatement[];
  recommendations: AiStatement[];
}

export interface AiUsage {
  prompt_tokens: number | null;
  completion_tokens: number | null;
  total_tokens: number | null;
}

export type AiUnavailableCode =
  | 'missing_api_key'
  | 'provider_http_error'
  | 'network_error'
  | 'timeout'
  | 'malformed_json'
  | 'unexpected_shape'
  | 'empty_choices'
  | 'empty_content';

export interface AiUnavailable {
  code: AiUnavailableCode;
  /** Chinese explanation shown to the researcher. */
  message: string;
  provider_status: number | null;
}

/**
 * Deterministic, engine-derived summary returned when the model cannot be used.
 *
 * `ai_generated` is a literal `false` so a client cannot mistake it for model
 * output even if it ignores `mode`.
 */
export interface EngineSummary {
  derived_by: 'statistical_engine';
  ai_generated: false;
  headline: string;
  text: string;
  statement_count: number;
  sections: { title: string; lines: string[] }[];
}

export interface InterpretationScope {
  section: string | null;
  hypothesis_code: string | null;
  focus: string | null;
}

/**
 * Sections a researcher can ask the model to concentrate on.
 *
 * The scope narrows what is *discussed*, never what is *available*: the prompt
 * always carries the whole evidence menu, so a focused request cannot tempt the
 * model to fill gaps from memory.
 */
export const INTERPRETATION_SECTIONS = [
  'overview',
  'descriptive',
  'reliability',
  'correlation',
  'regression',
  'comparisons',
  'hypotheses',
] as const;

export type InterpretationSection = (typeof INTERPRETATION_SECTIONS)[number];

export interface AiInterpretationResult {
  mode: AiMode;
  interaction_id: string;
  generated_at: string;
  engine_version: string;
  prompt_version: string;
  /** `null` when no prompt was ever sent (missing key). */
  prompt_hash: string | null;
  model: string;
  base_url: string;
  scope: InterpretationScope;
  bundle_generated_at: string;
  /** The only source of truth, stated in the payload itself. */
  source_of_truth: 'analysis_bundle';
  layers: AiLayers;
  statement_count: number;
  levels_used: AiLevel[];
  rejected_claims: AiRejectedClaim[];
  warnings: string[];
  /** Bundle caveats, verbatim and always present. */
  caveats: string[];
  /** True when the provider stopped early (finish_reason = length). */
  truncated: boolean;
  ai_unavailable: AiUnavailable | null;
  engine_summary: EngineSummary | null;
  usage: AiUsage | null;
  notice: string;
}

/* ================================================================== */
/* Bundle addressing                                                  */
/* ================================================================== */

export type BundleValueUnit = 'plain' | 'percent';

export interface BundleValue {
  path: string;
  value: number;
  unit: BundleValueUnit;
}

export interface PathResolution {
  found: boolean;
  value: unknown;
  reason: string | null;
}

function lastKeyOfPath(path: string): string {
  const segment = path.split('.').pop() ?? '';
  return segment.replace(/\[.*$/, '');
}

function unitForKey(key: string): BundleValueUnit {
  return PERCENT_KEYS.has(key) || key.endsWith('_percent') ? 'percent' : 'plain';
}

/** Address an element of an array by its identifying field, else by index. */
function keyForArrayItem(item: unknown, index: number): string {
  if (item !== null && typeof item === 'object' && !Array.isArray(item)) {
    const record = item as Record<string, unknown>;
    const left = record['left'];
    const right = record['right'];
    if (typeof left === 'string' && typeof right === 'string') return `${left}|${right}`;
    for (const field of ARRAY_IDENTITY_FIELDS) {
      const value = record[field];
      if (typeof value === 'string' && value !== '') return value;
      if (typeof value === 'number' && Number.isFinite(value)) return String(value);
    }
  }
  return String(index);
}

/**
 * Harvest numbers that appear inside a free-text bundle field.
 *
 * The engine's own notes, caveats and effect-size sentences quote real results,
 * so a model citing "0.05" (the α level) or the family-wise error rate is
 * quoting the bundle, not inventing a number. Digits that belong to metadata
 * (ids, timestamps) are skipped instead, so they cannot be used as cover.
 */
function harvestStringNumbers(text: string, path: string, out: BundleValue[]): void {
  const key = lastKeyOfPath(path);
  if (METADATA_PATH_KEYS.has(key)) return;
  if (ISO_DATETIME.test(text)) return;

  const pattern = new RegExp(QUOTED_NUMBER_SOURCE, 'g');
  let match = pattern.exec(text);
  while (match !== null) {
    const raw = match[0]!;
    const value = Number(raw.replace(/,/g, ''));
    if (Number.isFinite(value)) {
      const unit: BundleValueUnit = /^[%％]/.test(text.slice(match.index + raw.length))
        ? 'percent'
        : 'plain';
      out.push({ path, value, unit });
    }
    match = pattern.exec(text);
  }
}

function walkBundle(node: unknown, path: string, out: BundleValue[], depth: number): void {
  if (depth > 12) return;

  if (typeof node === 'number') {
    if (Number.isFinite(node)) {
      out.push({ path, value: node, unit: unitForKey(lastKeyOfPath(path)) });
    }
    return;
  }
  if (typeof node === 'string') {
    harvestStringNumbers(node, path, out);
    return;
  }
  if (Array.isArray(node)) {
    node.forEach((item, index) => {
      walkBundle(item, `${path}[${keyForArrayItem(item, index)}]`, out, depth + 1);
    });
    return;
  }
  if (node !== null && typeof node === 'object') {
    for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
      walkBundle(value, path === '' ? key : `${path}.${key}`, out, depth + 1);
    }
  }
}

/** Every number the engine produced, with the path it can be cited by. */
export function collectBundleValues(bundle: unknown): BundleValue[] {
  const out: BundleValue[] = [];
  walkBundle(bundle, '', out, 0);
  return out;
}

/** Parse `a.b[K].c` into path segments. */
function parsePathSegments(path: string): { key: string; bracket: boolean }[] {
  const segments: { key: string; bracket: boolean }[] = [];
  const pattern = /([^.[\]]+)|\[([^\]]*)\]/g;
  let match = pattern.exec(path);
  while (match !== null) {
    const plain = match[1];
    const bracket = match[2];
    if (plain !== undefined) segments.push({ key: plain, bracket: false });
    else if (bracket !== undefined) segments.push({ key: bracket, bracket: true });
    match = pattern.exec(path);
  }
  return segments;
}

/**
 * Resolve an evidence path against the bundle.
 *
 * The addressing scheme is the same one `collectBundleValues` writes, which is
 * what lets a declared citation be checked rather than trusted: an array is
 * addressed by an identifying field (`hypotheses.results[H3]`,
 * `correlation.pairs[FED|DSD]`, `comparisons[FED]`) and falls back to a numeric
 * index when no field matches.
 */
export function resolveBundlePath(bundle: unknown, path: string): PathResolution {
  const segments = parsePathSegments(path.trim());
  if (segments.length === 0) {
    return { found: false, value: null, reason: `证据路径为空：${path}` };
  }

  let current: unknown = bundle;
  const visited: string[] = [];

  for (const segment of segments) {
    if (segment.bracket) {
      if (!Array.isArray(current)) {
        return {
          found: false,
          value: null,
          reason: `证据路径 ${path} 无法解析：${visited.join('.') || '(根)'} 不是数组。`,
        };
      }
      const foundByKey = current.find((item) => {
        if (item === null || typeof item !== 'object' || Array.isArray(item)) return false;
        const record = item as Record<string, unknown>;
        if (`${record['left'] ?? ''}|${record['right'] ?? ''}` === segment.key) return true;
        return ARRAY_IDENTITY_FIELDS.some((field) => String(record[field] ?? '') === segment.key);
      });

      if (foundByKey !== undefined) {
        current = foundByKey;
      } else if (/^\d+$/.test(segment.key)) {
        const index = Number(segment.key);
        if (index >= current.length) {
          return { found: false, value: null, reason: `证据路径 ${path} 的数组下标越界。` };
        }
        current = current[index];
      } else {
        return {
          found: false,
          value: null,
          reason: `证据路径 ${path} 未找到元素 [${segment.key}]。`,
        };
      }
    } else {
      if (current === null || typeof current !== 'object' || Array.isArray(current)) {
        return {
          found: false,
          value: null,
          reason: `证据路径 ${path} 无法解析：${visited.join('.') || '(根)'} 不是对象。`,
        };
      }
      const record = current as Record<string, unknown>;
      if (!(segment.key in record)) {
        return {
          found: false,
          value: null,
          reason: `证据路径 ${path} 不存在：${[...visited, segment.key].join('.')} 在结果包中没有对应字段。`,
        };
      }
      current = record[segment.key];
    }
    visited.push(segment.bracket ? `[${segment.key}]` : segment.key);
  }

  return { found: true, value: current ?? null, reason: null };
}

/* ================================================================== */
/* Numeric validation                                                 */
/* ================================================================== */

/**
 * Numbers are matched on magnitude: a model that writes "r = 0.31" for a stored
 * `-0.31` is still quoting the engine's result, and the sign is carried by the
 * surrounding prose ("负相关"). Magnitude is what must not be invented.
 */
export function numbersMatch(quoted: number, candidate: number): boolean {
  const a = Math.abs(quoted);
  const b = Math.abs(candidate);
  return Math.abs(a - b) <= Math.max(NUMBER_ABSOLUTE_TOLERANCE, b * NUMBER_RELATIVE_TOLERANCE);
}

/** A number found in text, with the unit its formatting implies. */
export interface QuotedNumberToken {
  /** Exactly as written, e.g. `0.013` or `47%`. */
  raw: string;
  value: number;
  unit: BundleValueUnit;
}

/** Extract every number written in a piece of text, de-duplicated. */
export function extractQuotedNumbers(text: string): QuotedNumberToken[] {
  const tokens: QuotedNumberToken[] = [];
  const seen = new Set<string>();
  const pattern = new RegExp(QUOTED_NUMBER_SOURCE, 'g');

  let match = pattern.exec(text);
  while (match !== null) {
    const literal = match[0]!;
    const value = Number(literal.replace(/,/g, ''));
    // The unit travels with the token so a rejection can quote the figure as
    // the model actually wrote it ("87%" rather than "87").
    const percentChar = /^[%％]/.exec(text.slice(match.index + literal.length))?.[0] ?? '';
    const unit: BundleValueUnit = percentChar === '' ? 'plain' : 'percent';
    const raw = `${literal}${percentChar}`;
    if (Number.isFinite(value) && !seen.has(raw)) {
      seen.add(raw);
      tokens.push({ raw, value, unit });
    }
    match = pattern.exec(text);
  }

  return tokens;
}

export type NumberIssue = 'ok' | 'not_found' | 'unit_mismatch';

export interface QuotedNumberCheck {
  raw: string;
  value: number;
  unit: BundleValueUnit;
  matched: boolean;
  matched_path: string | null;
  matched_value: number | null;
  issue: NumberIssue;
  /** Chinese explanation, present whenever `matched` is false. */
  reason: string | null;
}

export interface NumberValidationResult {
  numbers: QuotedNumberCheck[];
  unmatched: QuotedNumberCheck[];
  ok: boolean;
}

function findClosest(values: BundleValue[], quoted: number): BundleValue | null {
  let best: BundleValue | null = null;
  let bestDistance = Number.POSITIVE_INFINITY;
  for (const candidate of values) {
    const distance = Math.abs(Math.abs(quoted) - Math.abs(candidate.value));
    if (numbersMatch(quoted, candidate.value) && distance < bestDistance) {
      best = candidate;
      bestDistance = distance;
    }
  }
  return best;
}

/**
 * Verify every number in `text` against the bundle.
 *
 * This is the core safety property of the AI layer: a statement may be rejected
 * wholesale for quoting one number the engine never computed. Percentages are
 * matched only against percentage-valued fields, so a proportion written as a
 * percentage (0.87 -> "87%") is a rejection rather than a rounding accident. The
 * unit check also catches the scaled form of that mistake (0.87 written as
 * "87%", or a 25.53% frequency written as "0.2553"), because those are the same
 * error seen from opposite directions.
 *
 * `bundle` is typed `unknown` on purpose: the same function is unit-tested
 * against hand-built fragments, and it only ever walks the value.
 */
export function validateNumbers(text: string, bundle: unknown): NumberValidationResult {
  const inventory = collectBundleValues(bundle);
  const plain = inventory.filter((entry) => entry.unit === 'plain');
  const percent = inventory.filter((entry) => entry.unit === 'percent');

  const numbers: QuotedNumberCheck[] = extractQuotedNumbers(text).map((token) => {
    const pool = token.unit === 'percent' ? percent : plain;
    const hit = findClosest(pool, token.value);

    if (hit) {
      return {
        raw: token.raw,
        value: token.value,
        unit: token.unit,
        matched: true,
        matched_path: hit.path,
        matched_value: hit.value,
        issue: 'ok',
        reason: null,
      };
    }

    // Distinguish "wrong unit" from "does not exist": the two need different
    // corrections, and conflating them would tell the model nothing. Both the
    // same-magnitude and the ×100/÷100 forms count as a unit error.
    const scaled = token.unit === 'percent' ? token.value / 100 : token.value * 100;
    const otherHit =
      findClosest(token.unit === 'percent' ? plain : percent, token.value) ??
      findClosest(token.unit === 'percent' ? plain : percent, scaled);

    if (otherHit) {
      const otherUnit = token.unit === 'percent' ? '比例（0—1）' : '百分比';
      const expected = token.unit === 'percent' ? otherHit.value : `${otherHit.value}%`;
      return {
        raw: token.raw,
        value: token.value,
        unit: token.unit,
        matched: false,
        matched_path: otherHit.path,
        matched_value: otherHit.value,
        issue: 'unit_mismatch',
        reason:
          `单位/口径不一致：结果包中的 ${otherHit.path} = ${expected} 是${otherUnit}，` +
          `不能写成 ${token.raw}。引用统计量时必须保持结果包中的单位与数值口径。`,
      };
    }

    return {
      raw: token.raw,
      value: token.value,
      unit: token.unit,
      matched: false,
      matched_path: null,
      matched_value: null,
      issue: 'not_found',
      reason:
        `结果包中不存在数值 ${token.raw}。AI 只能引用统计引擎计算过的数字，` +
        '该数字无法溯源，因此包含它的整条陈述已被剔除。',
    };
  });

  const unmatched = numbers.filter((entry) => !entry.matched);
  return { numbers, unmatched, ok: unmatched.length === 0 };
}

/* ================================================================== */
/* Prompt construction (pure)                                         */
/* ================================================================== */

export interface InterpretationPrompt {
  system: string;
  user: string;
  prompt_hash: string;
  prompt_version: string;
}

export interface PromptInput {
  bundle: AnalysisBundle;
  /** Research questions from the project record; part of the study design. */
  research_questions?: string[];
  scope?: InterpretationScope;
  prompt_version?: string;
}

export function emptyScope(): InterpretationScope {
  return { section: null, hypothesis_code: null, focus: null };
}

function formatNumber(value: number | null | undefined): string {
  return typeof value === 'number' && Number.isFinite(value) ? String(value) : 'NA';
}

function citedText(value: unknown): string {
  if (value === null || value === undefined) return 'NA';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return JSON.stringify(value);
}

/**
 * Build the list of bundle locations the model is allowed to cite.
 *
 * Every entry is resolved through `resolveBundlePath` before being published, so
 * the prompt can never advertise a path that does not exist — an advertised
 * broken path would produce evidence traces that fail validation for reasons the
 * model cannot fix.
 */
export function buildEvidenceMenu(bundle: AnalysisBundle): { path: string; value: unknown }[] {
  const menu: { path: string; value: unknown }[] = [];
  const push = (path: string): void => {
    const resolved = resolveBundlePath(bundle, path);
    if (resolved.found) menu.push({ path, value: resolved.value });
  };

  push('project.title');
  push('questionnaire.title');
  push('sample.respondents_total');
  push('sample.completed');
  push('sample.abandoned');
  push('sample.in_progress');
  push('sample.excluded');
  push('sample.analysable');
  push('dataset_summary.n_respondents');

  for (const stats of bundle.descriptive.variables) {
    if (stats.mean === null) continue;
    const base = `descriptive.variables[${stats.variable}]`;
    push(`${base}.mean`);
    push(`${base}.standard_deviation`);
    push(`${base}.n`);
    push(`${base}.missing`);
  }

  for (const scale of bundle.reliability.scales) {
    if (scale.cronbach_alpha === null) continue;
    push(`reliability.scales[${scale.scale}].cronbach_alpha`);
    push(`reliability.scales[${scale.scale}].n`);
    push(`reliability.scales[${scale.scale}].k`);
  }

  if (bundle.correlation) {
    for (const pair of bundle.correlation.pairs) {
      if (pair.r === null) continue;
      const base = `correlation.pairs[${pair.left}|${pair.right}]`;
      push(`${base}.r`);
      push(`${base}.p_value`);
      push(`${base}.n`);
      if (pair.effective_size) push(`${base}.effective_size.value`);
    }
  }

  if (bundle.regression?.ols) {
    const ols = bundle.regression.ols;
    push('regression.ols.r_squared');
    push('regression.ols.adjusted_r_squared');
    push('regression.ols.f_statistic');
    push('regression.ols.f_p_value');
    push('regression.ols.n');
    for (const coefficient of ols.coefficients) {
      push(`regression.ols.coefficients[${coefficient.term}].b`);
      push(`regression.ols.coefficients[${coefficient.term}].p_value`);
    }
  }

  if (bundle.regression?.ordinal) {
    const ordinal = bundle.regression.ordinal;
    push('regression.ordinal.mcfadden_r_squared');
    push('regression.ordinal.nagelkerke_r_squared');
    push('regression.ordinal.lr_chi_square');
    push('regression.ordinal.lr_p_value');
    push('regression.ordinal.n');
    for (const coefficient of ordinal.coefficients) {
      push(`regression.ordinal.coefficients[${coefficient.term}].b`);
      push(`regression.ordinal.coefficients[${coefficient.term}].p_value`);
      push(`regression.ordinal.coefficients[${coefficient.term}].odds_ratio`);
    }
  }

  for (const comparison of bundle.comparisons) {
    const base = `comparisons[${comparison.dependent}]`;
    if (comparison.anova) {
      push(`${base}.anova.f`);
      push(`${base}.anova.p_value`);
      push(`${base}.anova.eta_squared`);
      for (const group of comparison.anova.groups) {
        push(`${base}.anova.groups[${group.group}].mean`);
        push(`${base}.anova.groups[${group.group}].n`);
      }
    }
    if (comparison.kruskal_wallis) {
      push(`${base}.kruskal_wallis.h`);
      push(`${base}.kruskal_wallis.p_value`);
    }
  }

  for (const result of bundle.hypotheses.results) {
    const base = `hypotheses.results[${result.code}]`;
    push(`${base}.verdict`);
    push(`${base}.r`);
    push(`${base}.p_value`);
    push(`${base}.n`);
  }
  push('hypotheses.summary.total');
  push('hypotheses.summary.supported');
  push('hypotheses.summary.not_supported');
  push('hypotheses.summary.inconclusive');
  push('hypotheses.summary.untestable');

  bundle.caveats.forEach((_caveat, index) => push(`caveats[${index}]`));

  return menu;
}

const SYSTEM_PROMPT = [
  '你是家庭教育研究项目的统计结果解释助手，服务于学术研究场景。',
  '你的唯一职责是解释「统计结果包」中已经计算好的数字。你不能计算、推算、估计或引入任何新数字。',
  '',
  '你必须把每一条输出都归入下面四层之一，并以行首标签标注：',
  '[FACT] 事实——逐字抄自结果包中的数值，例如 n = 47；',
  '[STATISTICAL_FINDING] 统计发现——统计引擎给出的统计量，例如 r = 0.3652, p = 0.0032；',
  '[INTERPRETATION] 解释——你对这些统计发现的解读；',
  '[RECOMMENDATION] 建议——基于上述结果的可执行建议。',
  '',
  '硬性规则：',
  '1. 只能引用「可用引用路径」中列出的数值，必须保持原有位数与正负号；严禁编造、换算或改写任何数字。',
  '2. 不得把比例（0—1）写成百分比，也不得把百分比写成比例。',
  '3. 本数据为横截面问卷数据，禁止由相关推断因果；只能使用「相关」「同向变动」「伴随」「可能」「提示」等表述。',
  '4. 必须尊重三态判定：supported（数据支持）、not_supported（方向与假设相反）、inconclusive（证据不足）。',
  '   绝不能把 inconclusive 表述为「已证明无关」「假设不成立」或「没有关系」。',
  '5. 样本量偏小、方差齐性不足、非参数检验推荐等限制必须如实提及，不确定之处要显式标注。',
  '6. 每条陈述（FACT 之外尤其）都必须紧跟一行证据，格式为：证据: 路径=数值; 路径=数值',
  '7. 只输出带标签的陈述行，不要输出标题、前言、结语、表格或代码块。',
  '8. 全部使用中文输出。',
].join('\n');

function buildGroundTruthSections(bundle: AnalysisBundle): string[] {
  const lines: string[] = [];

  lines.push('【样本】');
  lines.push(
    `已完成作答 ${bundle.sample.completed} 份，被研究者排除 ${bundle.sample.excluded} 份，` +
      `进入分析的有效样本 analysable = ${bundle.sample.analysable}（结果包记录的分析 respondent 数 n = ${bundle.dataset_summary.n_respondents}）。`,
  );

  lines.push('');
  lines.push('【关键变量描述统计】');
  for (const stats of bundle.descriptive.variables) {
    if (stats.mean === null) continue;
    lines.push(
      `${stats.variable}（${stats.label}）：均值 ${formatNumber(stats.mean)}，` +
        `标准差 ${formatNumber(stats.standard_deviation)}，n = ${stats.n}，缺失 ${stats.missing}。`,
    );
  }

  lines.push('');
  lines.push('【信度】');
  const scales = bundle.reliability.scales.filter((scale) => scale.cronbach_alpha !== null);
  if (scales.length === 0) lines.push('本次分析未能计算任何量表的内部一致性系数。');
  for (const scale of scales) {
    lines.push(
      `${scale.scale}（${scale.label}，${scale.k} 个条目，n = ${scale.n}）：` +
        `Cronbach α = ${formatNumber(scale.cronbach_alpha)}。`,
    );
  }

  lines.push('');
  lines.push('【成对相关（含显著性检验与效应量）】');
  if (!bundle.correlation) {
    lines.push('本次分析没有可用的相关矩阵。');
  } else {
    for (const pair of bundle.correlation.pairs) {
      if (pair.r === null) continue;
      lines.push(
        `${pair.left} × ${pair.right}：r = ${formatNumber(pair.r)}，p = ${formatNumber(pair.p_value)}，` +
          `n = ${pair.n}，方法 ${pair.method}` +
          (pair.effective_size ? `，${pair.effective_size.text}` : '') +
          '。',
      );
    }
  }

  lines.push('');
  lines.push('【回归】');
  if (!bundle.regression) {
    lines.push('本次分析没有可用的回归结果。');
  } else {
    lines.push(`模型选择：${bundle.regression.auto_selection.model}。${bundle.regression.recommendation}`);
    const ols = bundle.regression.ols;
    if (ols) {
      lines.push(
        `线性回归（因变量 ${ols.dependent}，n = ${ols.n}）：R² = ${formatNumber(ols.r_squared)}，` +
          `F = ${formatNumber(ols.f_statistic)}，F 检验 p = ${formatNumber(ols.f_p_value)}。`,
      );
      for (const coefficient of ols.coefficients) {
        lines.push(
          `  ${coefficient.term}：B = ${formatNumber(coefficient.b)}，p = ${formatNumber(coefficient.p_value)}` +
            (coefficient.beta === null ? '' : `，β = ${formatNumber(coefficient.beta)}`) +
            (coefficient.vif === null ? '' : `，VIF = ${formatNumber(coefficient.vif)}`) +
            '。',
        );
      }
    }
    const ordinal = bundle.regression.ordinal;
    if (ordinal) {
      lines.push(
        `有序 Logistic 回归（n = ${ordinal.n}，收敛 = ${ordinal.converged}）：` +
          `McFadden R² = ${formatNumber(ordinal.mcfadden_r_squared)}，` +
          `似然比检验 p = ${formatNumber(ordinal.lr_p_value)}。`,
      );
      for (const coefficient of ordinal.coefficients) {
        lines.push(
          `  ${coefficient.term}：B = ${formatNumber(coefficient.b)}，` +
            `p = ${formatNumber(coefficient.p_value)}，OR = ${formatNumber(coefficient.odds_ratio)}。`,
        );
      }
    }
  }

  lines.push('');
  lines.push('【组间差异】');
  if (bundle.comparisons.length === 0) lines.push('本次分析没有可用的组间比较。');
  for (const comparison of bundle.comparisons) {
    const parts: string[] = [];
    if (comparison.anova) {
      parts.push(
        `ANOVA F = ${formatNumber(comparison.anova.f)}，p = ${formatNumber(comparison.anova.p_value)}，` +
          `η² = ${formatNumber(comparison.anova.eta_squared)}`,
      );
    }
    if (comparison.kruskal_wallis) {
      parts.push(
        `Kruskal–Wallis H = ${formatNumber(comparison.kruskal_wallis.h)}，` +
          `p = ${formatNumber(comparison.kruskal_wallis.p_value)}`,
      );
    }
    lines.push(
      `${comparison.dependent}（${comparison.dependent_label}）按 ${comparison.factor_label} 分组` +
        `（${comparison.groups} 组）：${parts.join('；')}。推荐口径：${comparison.recommended}。` +
        comparison.recommendation_reason,
    );
  }

  lines.push('');
  lines.push('【假设检验（三态判定，必须逐条尊重）】');
  for (const result of bundle.hypotheses.results) {
    lines.push(
      `${result.code}：${result.statement} 判定 = ${result.verdict}；` +
        `自变量 ${result.independent}，因变量 ${result.dependent}，方法 ${result.method}，` +
        `r = ${formatNumber(result.r)}，p = ${formatNumber(result.p_value)}，n = ${result.n}。`,
    );
    for (const caveat of result.caveats) lines.push(`  解读限制：${caveat}`);
  }
  lines.push(
    `假设汇总：total = ${bundle.hypotheses.summary.total}，supported = ${bundle.hypotheses.summary.supported}，` +
      `not_supported = ${bundle.hypotheses.summary.not_supported}，` +
      `inconclusive = ${bundle.hypotheses.summary.inconclusive}，` +
      `untestable = ${bundle.hypotheses.summary.untestable}。`,
  );
  lines.push(bundle.hypotheses.note);

  lines.push('');
  lines.push('【解读前提（结果包原文，必须遵守）】');
  bundle.caveats.forEach((caveat, index) => lines.push(`caveats[${index}]：${caveat}`));

  return lines;
}

/**
 * Build the prompt. Pure: same bundle in, byte-identical prompt out.
 *
 * Purity is not cosmetic — the prompt hash is stored as the audit key for an
 * interaction, so an impure builder would make two identical requests
 * unauditable.
 */
export function buildInterpretationPrompt(input: PromptInput): InterpretationPrompt {
  const { bundle } = input;
  const scope = input.scope ?? emptyScope();
  const promptVersion = input.prompt_version ?? '1.0.0';

  const lines: string[] = [];
  lines.push(`【研究主题】${bundle.project.title}`);
  if (bundle.questionnaire) {
    lines.push(
      `【问卷】${bundle.questionnaire.title}（版本 ${bundle.questionnaire.version}，` +
        `${bundle.questionnaire.question_count} 题）`,
    );
  }

  const questions = input.research_questions ?? [];
  lines.push('');
  lines.push('【研究问题】');
  if (questions.length === 0) lines.push('（项目未记录研究问题，请围绕统计结果包中的变量关系展开。）');
  questions.forEach((question, index) => lines.push(`${index + 1}. ${question}`));

  lines.push('');
  lines.push(
    `【本次解释范围】板块：${scope.section ?? '全部'}；假设：${scope.hypothesis_code ?? '不限'}；` +
      `研究者要求：${scope.focus ?? '无'}`,
  );

  lines.push('');
  lines.push('【统计结果包（唯一事实来源，引擎版本 ' + bundle.engine_version + '，生成时间 ' + bundle.generated_at + '）】');
  lines.push(...buildGroundTruthSections(bundle));

  lines.push('');
  lines.push('【可用引用路径（引用任何数字都必须来自这里，格式为 路径 = 数值）】');
  for (const entry of buildEvidenceMenu(bundle)) {
    lines.push(`${entry.path} = ${citedText(entry.value)}`);
  }

  lines.push('');
  lines.push('【输出格式示例】');
  lines.push('[STATISTICAL_FINDING] FED 与 DSD 呈显著正相关（r = 0.4123, p = 0.0032, n = 24）。证据: correlation.pairs[FED|DSD].r=0.4123; correlation.pairs[FED|DSD].p_value=0.0032');
  lines.push('[INTERPRETATION] 该结果提示家庭教育困难越多，数字化服务需求可能越强。证据: correlation.pairs[FED|DSD].r=0.4123');
  lines.push('[RECOMMENDATION] 建议在服务设计上优先覆盖困难程度较高的家庭。证据: correlation.pairs[FED|DSD].p_value=0.0032');

  const system = SYSTEM_PROMPT;
  const user = lines.join('\n');

  return {
    system,
    user,
    prompt_hash: createHash('sha256').update(`${system}\n---\n${user}`).digest('hex'),
    prompt_version: promptVersion,
  };
}

/* ================================================================== */
/* Response parsing                                                   */
/* ================================================================== */

const LEVEL_ALIASES: Record<string, AiLevel> = {
  fact: 'FACT',
  facts: 'FACT',
  '事实': 'FACT',
  'statistical_finding': 'STATISTICAL_FINDING',
  'statistical finding': 'STATISTICAL_FINDING',
  'statisticalfindings': 'STATISTICAL_FINDING',
  finding: 'STATISTICAL_FINDING',
  statistic: 'STATISTICAL_FINDING',
  '统计发现': 'STATISTICAL_FINDING',
  '统计结果': 'STATISTICAL_FINDING',
  '统计事实': 'STATISTICAL_FINDING',
  interpretation: 'INTERPRETATION',
  '解释': 'INTERPRETATION',
  '解读': 'INTERPRETATION',
  recommendation: 'RECOMMENDATION',
  recommendations: 'RECOMMENDATION',
  '建议': 'RECOMMENDATION',
  '推荐': 'RECOMMENDATION',
};

const LEVEL_TAG_ALTERNATIVES =
  'FACT|FACTS|STATISTICAL[ _]FINDINGS?|FINDINGS?|STATISTIC|INTERPRETATIONS?|RECOMMENDATIONS?|事实|统计发现|统计结果|统计事实|解释|解读|建议|推荐';

/** `[FACT] …` / `【事实】…` */
const ENCLOSED_LABEL = new RegExp(
  `^\\s*(?:[-*•·]|\\(?\\d+[.)、])?\\s*(?:\\*\\*)?\\s*[\\[【]\\s*(${LEVEL_TAG_ALTERNATIVES})\\s*[\\]】]\\s*(?:\\*\\*)?\\s*[:：\\-—]?\\s*`,
  'i',
);

/** `**FACT** …` — bold labels are common even when brackets are not. */
const BOLD_LABEL = new RegExp(
  `^\\s*(?:[-*•·]|\\(?\\d+[.)、])?\\s*\\*\\*\\s*(${LEVEL_TAG_ALTERNATIVES})\\s*\\*\\*\\s*[:：\\-—]?\\s*`,
  'i',
);

/** `统计发现：…` / `INTERPRETATION: …` / `FACT — …` */
const COLON_LABEL = new RegExp(
  `^\\s*(?:[-*•·]|\\(?\\d+[.)、])?\\s*(?:\\*\\*)?\\s*(${LEVEL_TAG_ALTERNATIVES})\\s*(?:\\*\\*)?\\s*[:：\\-—–]\\s*`,
  'i',
);

const EVIDENCE_MARKER = /(?:证据|依据|出处|来源|evidence|sources?)\s*[:：]\s*/i;

/** A line that only carries evidence, and so belongs to the statement above. */
const EVIDENCE_ONLY_LINE = /^\s*[（(\[【]?\s*(?:证据|依据|出处|来源|evidence|sources?)\s*[:：]/i;

/** Sentence terminators, used to tell a new statement from wrapped prose. */
const SENTENCE_END = /[。！？；;.!?]\s*$/;

/** Wording that marks a recommendation when the model forgot the label. */
const RECOMMENDATION_HINTS = ['建议', '应当', '应该', '推荐', '需要优先', '可以考虑', '下一步'];
/** Wording that marks a statistical result when the model forgot the label. */
const STATISTICAL_HINTS = [
  'r =',
  'p =',
  'α',
  'beta',
  'β',
  'F =',
  'H =',
  'OR =',
  'η²',
  '显著',
  '相关',
  '回归',
  '检验',
  '方差',
  '均值',
  '标准差',
  '系数',
];

function normalizeLevel(tag: string): AiLevel | null {
  const key = tag.trim().toLowerCase().replace(/\s+/g, ' ');
  return LEVEL_ALIASES[key] ?? null;
}

interface RawBlock {
  text: string;
  declared_level: AiLevel | null;
}

/**
 * Split a model reply into statements.
 *
 * A labelled line always starts a new statement. An unlabelled line continues
 * the current one only when the current prose looks unfinished (no sentence
 * terminator), which keeps a wrapped sentence together while treating the
 * one-statement-per-line output the prompt asks for as separate statements. A
 * line that carries nothing but an evidence clause always attaches to the
 * statement above it.
 */
function splitIntoBlocks(raw: string): RawBlock[] {
  const blocks: RawBlock[] = [];
  let current: RawBlock | null = null;

  const flush = (): void => {
    if (current && current.text.trim() !== '') blocks.push(current);
    current = null;
  };

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed === '') {
      flush();
      continue;
    }

    const enclosed = ENCLOSED_LABEL.exec(line);
    const bold = enclosed ? null : BOLD_LABEL.exec(line);
    const colon = enclosed || bold ? null : COLON_LABEL.exec(line);
    const label = enclosed ?? bold ?? colon;
    if (label) {
      flush();
      current = {
        text: line.slice(label[0].length).trim(),
        declared_level: normalizeLevel(label[1]!),
      };
      continue;
    }

    if (current && EVIDENCE_ONLY_LINE.test(line)) {
      current.text = `${current.text} ${trimmed}`.trim();
      continue;
    }

    // Terminality is judged on the statement's own prose: a trailing evidence
    // clause ("…样本。 证据: x=1") must not hide that the sentence was finished.
    const prose = current
      ? current.text.split(EVIDENCE_MARKER)[0]!.replace(/[\s（(\[【]+$/, '')
      : '';
    if (current && SENTENCE_END.test(prose)) {
      flush();
      current = { text: trimmed, declared_level: null };
      continue;
    }

    if (current) current.text = `${current.text} ${trimmed}`.trim();
    else current = { text: trimmed, declared_level: null };
  }

  flush();
  return blocks;
}

/**
 * Infer the level from wording when the model ignored the labelling rule.
 *
 * Deliberately conservative: only the two levels that can be recognised from
 * wording alone are inferred, and an unrecognisable sentence is filed as
 * INTERPRETATION rather than guessed into FACT (which would overstate it as a
 * value copied from the bundle). The statement still has to pass evidence and
 * number validation, and the response is flagged as non-compliant.
 */
function inferLevel(text: string): AiLevel {
  if (RECOMMENDATION_HINTS.some((hint) => text.includes(hint))) return 'RECOMMENDATION';
  if (STATISTICAL_HINTS.some((hint) => text.includes(hint))) return 'STATISTICAL_FINDING';
  return 'INTERPRETATION';
}

function evidenceValue(value: unknown): string | number | boolean | null | undefined {
  if (value === null) return null;
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }
  return undefined;
}

interface EvidenceCheck {
  evidence: AiEvidence | null;
  reason: string | null;
}

/** Verify one declared citation against the bundle. */
function checkDeclaredEvidence(
  bundle: AnalysisBundle,
  path: string,
  declared: string | null,
): EvidenceCheck {
  const resolved = resolveBundlePath(bundle, path);
  if (!resolved.found) {
    return { evidence: null, reason: resolved.reason ?? `证据路径 ${path} 无法溯源。` };
  }

  const value = evidenceValue(resolved.value);
  if (value === undefined) {
    return {
      evidence: null,
      reason: `证据路径 ${path} 指向的是结构化对象或数组，不是可引用的具体数值。`,
    };
  }

  if (declared !== null) {
    const expected = declared.trim().replace(/[`"']/g, '');
    if (typeof value === 'number') {
      const numeric = Number(expected.replace(/[%％]/g, '').replace(/,/g, ''));
      if (!Number.isFinite(numeric) || !numbersMatch(numeric, value)) {
        return {
          evidence: null,
          reason:
            `证据值与结果包不一致：声明 ${path} = ${declared}，` +
            `但结果包中为 ${path} = ${value}。`,
        };
      }
    } else if (typeof value === 'boolean') {
      if (String(value) !== expected.toLowerCase()) {
        return {
          evidence: null,
          reason: `证据值与结果包不一致：声明 ${path} = ${declared}，实际为 ${String(value)}。`,
        };
      }
    } else if (typeof value === 'string' && value.trim() !== expected) {
      return {
        evidence: null,
        reason: `证据值与结果包不一致：声明 ${path} = ${declared}，实际为 ${value}。`,
      };
    }
  }

  return { evidence: { path, value, source: 'declared' }, reason: null };
}

interface ParsedEvidenceClause {
  prose: string;
  declared: { path: string; value: string | null }[];
}

/**
 * Strip the punctuation a model wraps a citation in: full-width parentheses,
 * brackets, backticks, quotes and a trailing sentence mark. Without this,
 * "（证据：sample.analysable=24）" would carry "24）" as the value and fail a
 * comparison that is really about formatting, not about the number.
 */
function cleanEvidenceToken(value: string): string {
  return value
    .trim()
    .replace(/^[（(\[【"'`]+/, '')
    .replace(/[）)\]】"'`]+$/, '')
    .replace(/[。；;，,、]+$/, '')
    .trim();
}

/** Split a statement into its prose and its declared evidence clauses. */
function splitEvidenceClause(text: string): ParsedEvidenceClause {
  const match = EVIDENCE_MARKER.exec(text);
  if (!match) return { prose: text.trim(), declared: [] };

  // Drop the parenthesis the clause was wrapped in ("（证据：…）") so it does not
  // linger in the published statement.
  const prose = text
    .slice(0, match.index)
    .replace(/[\s（(\[【]+$/, '')
    .trim();

  // The clause ends at the closing parenthesis or the end of the sentence; text
  // beyond that belongs to the prose, not to the citation.
  let clause = text.slice(match.index + match[0].length);
  const closeParen = clause.indexOf('）');
  if (closeParen >= 0) clause = clause.slice(0, closeParen);
  const sentenceEnd = clause.search(/[。！？]/);
  if (sentenceEnd >= 0) clause = clause.slice(0, sentenceEnd);

  const declared = clause
    .split(/[;；\n]|,(?=[^,]*=)|，(?=[^，]*=)/)
    .map((part) => cleanEvidenceToken(part.replace(/^[-*•·]\s*/, '')))
    .filter((part) => part !== '')
    .map((part) => {
      const assignment = /^(.+?)\s*=\s*(.+)$/.exec(part);
      if (!assignment) return { path: cleanEvidenceToken(part), value: null };
      return {
        path: cleanEvidenceToken(assignment[1]!),
        value: cleanEvidenceToken(assignment[2]!),
      };
    })
    .filter((entry) => entry.path !== '');

  return { prose, declared };
}

function detectHypothesisCode(text: string, bundle: AnalysisBundle): string | null {
  for (const result of bundle.hypotheses.results) {
    if (new RegExp(`\\b${result.code}\\b`).test(text)) return result.code;
  }
  return null;
}

/**
 * Attribute a statement to a hypothesis through its evidence.
 *
 * A statement that cites `hypotheses.results[H3].r` is about H3 even when the
 * prose never spells the code out, and the report needs that link.
 */
function hypothesisFromEvidence(evidence: AiEvidence[], bundle: AnalysisBundle): string | null {
  for (const item of evidence) {
    const match = /^hypotheses\.results\[([^\]]+)\]/.exec(item.path);
    if (match && bundle.hypotheses.results.some((result) => result.code === match[1])) {
      return match[1]!;
    }
  }
  return null;
}

export interface ParsedModelOutput {
  layers: AiLayers;
  rejected_claims: AiRejectedClaim[];
  labelling_compliant: boolean;
  warnings: string[];
  statement_count: number;
}

function emptyLayers(): AiLayers {
  return {
    facts: [],
    statistical_findings: [],
    interpretations: [],
    recommendations: [],
  };
}

function addStatement(layers: AiLayers, statement: AiStatement): void {
  switch (statement.level) {
    case 'FACT':
      layers.facts.push(statement);
      return;
    case 'STATISTICAL_FINDING':
      layers.statistical_findings.push(statement);
      return;
    case 'INTERPRETATION':
      layers.interpretations.push(statement);
      return;
    case 'RECOMMENDATION':
    default:
      layers.recommendations.push(statement);
  }
}

/**
 * Parse and validate a model reply.
 *
 * Three refusals are possible, all of them reported rather than swallowed:
 *  - an untraceable number voids the statement (`untraceable_number`);
 *  - a statement with no usable evidence is dropped (`no_evidence`);
 *  - a declared citation that does not resolve is dropped from the trace, and if
 *    nothing else remains the statement goes with it.
 */
export function parseModelOutput(raw: string, bundle: AnalysisBundle): ParsedModelOutput {
  const layers = emptyLayers();
  const rejected: AiRejectedClaim[] = [];
  const warnings: string[] = [];
  let inferredLabels = 0;
  let index = 0;

  for (const block of splitIntoBlocks(raw)) {
    const { prose, declared } = splitEvidenceClause(block.text);
    const level = block.declared_level ?? inferLevel(block.text);
    const labelInferred = block.declared_level === null;
    if (labelInferred) inferredLabels += 1;

    if (prose.trim() === '') {
      rejected.push({
        text: block.text.trim(),
        code: 'empty_statement',
        reason: '该条只有标签或证据，没有可发表的陈述内容。',
        quoted_number: null,
        raw_number: null,
        level,
      });
      continue;
    }

    const evidence: AiEvidence[] = [];
    const evidenceProblems: string[] = [];

    for (const entry of declared) {
      const checked = checkDeclaredEvidence(bundle, entry.path, entry.value);
      if (checked.evidence) evidence.push(checked.evidence);
      else if (checked.reason) evidenceProblems.push(checked.reason);
    }

    const validation = validateNumbers(prose, bundle);
    const unmatched = validation.unmatched[0];
    if (unmatched) {
      rejected.push({
        text: prose,
        code: 'untraceable_number',
        reason: unmatched.reason ?? `数值 ${unmatched.raw} 无法在结果包中溯源。`,
        quoted_number: unmatched.value,
        raw_number: unmatched.raw,
        level,
      });
      continue;
    }

    // A citation the model volunteered that does not exist is itself a
    // fabrication signal: the statement claims a basis it does not have, so it
    // is refused rather than rescued by the numbers that happen to be real.
    if (declared.length > 0 && evidence.length === 0) {
      rejected.push({
        text: prose,
        code: 'evidence_path_not_found',
        reason:
          '声明的证据全部无法在统计结果包中溯源，已剔除该条陈述。' +
          ` ${evidenceProblems.join(' ')}`.trim(),
        quoted_number: null,
        raw_number: null,
        level,
      });
      continue;
    }

    for (const match of validation.numbers) {
      if (match.matched_path === null || match.matched_value === null) continue;
      const duplicate = evidence.some(
        (item) => item.path === match.matched_path && item.value === match.matched_value,
      );
      if (!duplicate) {
        evidence.push({
          path: match.matched_path,
          value: match.matched_value,
          source: 'inferred',
        });
      }
    }

    if (evidence.length === 0) {
      rejected.push({
        text: prose,
        code: 'no_evidence',
        reason:
          '无法溯源到统计结果包，已剔除该条陈述：该条既没有声明证据，正文中也没有任何可溯源的数值。',
        quoted_number: null,
        raw_number: null,
        level,
      });
      continue;
    }

    if (evidenceProblems.length > 0) {
      warnings.push(`部分声明证据无法溯源，已从留痕中移除：${evidenceProblems.join(' ')}`);
    }

    index += 1;
    addStatement(layers, {
      id: `ai-st-${index}`,
      level,
      text: prose,
      labelled_text: labelStatement(level, prose),
      evidence,
      label_inferred: labelInferred,
      hypothesis_code:
        detectHypothesisCode(prose, bundle) ?? hypothesisFromEvidence(evidence, bundle),
    });
  }

  const labelling_compliant = inferredLabels === 0;
  if (!labelling_compliant) {
    warnings.push(
      `模型未完全遵守分层标签要求：${inferredLabels} 条陈述缺少标签，已按措辞推断层级。` +
        '层级推断仅供参考，请以证据留痕为准。',
    );
  }
  if (index === 0 && raw.trim() !== '') {
    warnings.push('模型输出中的全部陈述都未能通过溯源校验，因此没有可发布的结论。');
  }

  return {
    layers,
    rejected_claims: rejected,
    labelling_compliant,
    warnings,
    statement_count: index,
  };
}

/* ================================================================== */
/* Deterministic engine-derived summary (degraded mode)               */
/* ================================================================== */

const VERDICT_LABELS: Record<string, string> = {
  supported: '数据支持',
  not_supported: '方向与假设相反（数据不支持原假设方向）',
  inconclusive: '证据不足，无法判断',
  untestable: '无法检验',
};

/** Constructs worth naming in a plain-language summary, in reading order. */
const SUMMARY_VARIABLES = ['FSE', 'FEK', 'FPB', 'FED', 'PSA', 'PSU', 'STI', 'DSD', 'PRC', 'AIPV', 'UI', 'WTP'];

function alphaBand(
  alpha: number,
  reference: { excellent: number; good: number; acceptable: number; questionable: number },
): string {
  if (alpha >= reference.excellent) return `内部一致性很高（达到结果包中的 excellent 阈值 ${reference.excellent}）`;
  if (alpha >= reference.good) return `内部一致性较好（达到结果包中的 good 阈值 ${reference.good}）`;
  if (alpha >= reference.acceptable) return `内部一致性可接受（达到结果包中的 acceptable 阈值 ${reference.acceptable}）`;
  if (alpha >= reference.questionable) return `内部一致性偏低（低于结果包中的 acceptable 阈值 ${reference.acceptable}）`;
  return `内部一致性不足（低于结果包中的 questionable 阈值 ${reference.questionable}）`;
}

interface SummaryLine {
  level: AiLevel;
  text: string;
  evidence: { path: string; value: unknown }[];
}

/**
 * Assemble the fallback summary using ONLY values read out of the bundle.
 *
 * Every line carries the bundle paths it quotes, so the same evidence-trace rule
 * that governs model output governs this text too. Nothing here is inferred: the
 * sentences state what the engine computed and what the engine itself flagged as
 * a limitation. The few lines that report an *absence* ("no significant pair",
 * "no reliable α") carry no citation because there is no value to cite; that is
 * why `AiStatement.evidence` is allowed to be empty for engine-derived text.
 */
export function buildEngineDerivedSummary(bundle: AnalysisBundle): {
  summary: EngineSummary;
  statements: AiStatement[];
} {
  const sections: { title: string; lines: string[] }[] = [];
  const summaryLines: SummaryLine[] = [];

  const section = (title: string): void => {
    sections.push({ title, lines: [] });
  };
  const line = (level: AiLevel, text: string, evidence: { path: string; value: unknown }[]): void => {
    summaryLines.push({ level, text, evidence });
    sections[sections.length - 1]?.lines.push(text);
  };

  /* 一、样本情况 */
  section('一、样本情况');
  line('FACT', `已完成作答 ${bundle.sample.completed} 份样本，其中被研究者人工排除 ${bundle.sample.excluded} 份，进入统计分析的有效样本为 ${bundle.sample.analysable} 份。`, [
    { path: 'sample.completed', value: bundle.sample.completed },
    { path: 'sample.excluded', value: bundle.sample.excluded },
    { path: 'sample.analysable', value: bundle.sample.analysable },
  ]);
  if (bundle.questionnaire) {
    line('FACT', `本次分析基于问卷「${bundle.questionnaire.title}」（版本 ${bundle.questionnaire.version}），共 ${bundle.questionnaire.question_count} 题，统计引擎版本为 ${bundle.engine_version}。`, [
      { path: 'questionnaire.title', value: bundle.questionnaire.title },
      { path: 'questionnaire.question_count', value: bundle.questionnaire.question_count },
    ]);
  }

  /* 二、关键变量描述统计 */
  section('二、关键变量描述统计');
  const described = bundle.descriptive.variables.filter(
    (stats) => SUMMARY_VARIABLES.includes(stats.variable) && stats.mean !== null,
  );
  if (described.length === 0) {
    line('FACT', '本次分析没有得到可用于描述统计的核心构念均值。', []);
  }
  for (const stats of described) {
    line('STATISTICAL_FINDING', `${stats.label}（${stats.variable}）的均值为 ${formatNumber(stats.mean)}，标准差为 ${formatNumber(stats.standard_deviation)}，有效作答 n = ${stats.n}，缺失 ${stats.missing}。`, [
      { path: `descriptive.variables[${stats.variable}].mean`, value: stats.mean },
      { path: `descriptive.variables[${stats.variable}].standard_deviation`, value: stats.standard_deviation },
      { path: `descriptive.variables[${stats.variable}].n`, value: stats.n },
    ]);
  }

  /* 三、量表信度 */
  section('三、量表信度');
  const scales = bundle.reliability.scales.filter((scale) => scale.cronbach_alpha !== null);
  if (scales.length === 0) {
    line('FACT', '本次分析没有得到可计算的信度系数（条目数或有效样本不足）。', []);
  }
  for (const scale of scales) {
    const alpha = scale.cronbach_alpha!;
    line('STATISTICAL_FINDING', `${scale.label}（${scale.scale}）量表含 ${scale.k} 个条目，Cronbach α = ${formatNumber(alpha)}，n = ${scale.n}；${alphaBand(alpha, scale.alpha_reference)}。`, [
      { path: `reliability.scales[${scale.scale}].cronbach_alpha`, value: alpha },
      { path: `reliability.scales[${scale.scale}].k`, value: scale.k },
      { path: `reliability.scales[${scale.scale}].n`, value: scale.n },
    ]);
  }

  /* 四、显著相关 */
  section('四、显著相关（含效应量）');
  const pairs = (bundle.correlation?.pairs ?? [])
    .filter((pair) => pair.r !== null && pair.p_value !== null && pair.p_value < 0.05)
    .sort((a, b) => Math.abs(b.r!) - Math.abs(a.r!))
    .slice(0, 8);
  if (pairs.length === 0) {
    line('FACT', '在本次分析的变量组合中，没有出现达到显著性水平的成对相关；未达显著不等于证明两者无关。', []);
  }
  for (const pair of pairs) {
    const method = pair.method === 'spearman' ? 'Spearman 等级相关' : 'Pearson 积差相关';
    line('STATISTICAL_FINDING', `${pair.left} 与 ${pair.right} 呈显著相关（${method}）：r = ${formatNumber(pair.r)}，p = ${formatNumber(pair.p_value)}，n = ${pair.n}${pair.effective_size ? `，${pair.effective_size.text}` : ''}。`, [
      { path: `correlation.pairs[${pair.left}|${pair.right}].r`, value: pair.r },
      { path: `correlation.pairs[${pair.left}|${pair.right}].p_value`, value: pair.p_value },
      { path: `correlation.pairs[${pair.left}|${pair.right}].n`, value: pair.n },
    ]);
  }

  /* 五、组间差异 */
  const comparisons = bundle.comparisons.filter(
    (comparison) => comparison.anova !== null || comparison.kruskal_wallis !== null,
  );
  if (comparisons.length > 0) {
    section('五、组间差异');
    for (const comparison of comparisons) {
      if (comparison.recommended === 'nonparametric' && comparison.kruskal_wallis) {
        line('STATISTICAL_FINDING', `${comparison.dependent_label}（${comparison.dependent}）在不同${comparison.factor_label}间的差异（Kruskal–Wallis 检验）：H = ${formatNumber(comparison.kruskal_wallis.h)}，p = ${formatNumber(comparison.kruskal_wallis.p_value)}；${comparison.recommendation_reason}`, [
          { path: `comparisons[${comparison.dependent}].kruskal_wallis.h`, value: comparison.kruskal_wallis.h },
          { path: `comparisons[${comparison.dependent}].kruskal_wallis.p_value`, value: comparison.kruskal_wallis.p_value },
        ]);
      } else if (comparison.anova) {
        line('STATISTICAL_FINDING', `${comparison.dependent_label}（${comparison.dependent}）在不同${comparison.factor_label}间的差异（单因素方差分析）：F = ${formatNumber(comparison.anova.f)}，p = ${formatNumber(comparison.anova.p_value)}，η² = ${formatNumber(comparison.anova.eta_squared)}；${comparison.recommendation_reason}`, [
          { path: `comparisons[${comparison.dependent}].anova.f`, value: comparison.anova.f },
          { path: `comparisons[${comparison.dependent}].anova.p_value`, value: comparison.anova.p_value },
          { path: `comparisons[${comparison.dependent}].anova.eta_squared`, value: comparison.anova.eta_squared },
        ]);
      }
    }
  }

  /* 六、回归结果 */
  if (bundle.regression && (bundle.regression.ols || bundle.regression.ordinal)) {
    section('六、回归结果');
    const ordinal = bundle.regression.ordinal;
    if (ordinal) {
      const significant = ordinal.coefficients.filter((coefficient) => coefficient.p_value < 0.05);
      line('STATISTICAL_FINDING', `有序 Logistic 回归（因变量 ${bundle.regression.ols?.dependent ?? ordinal.dependent ?? 'UI'}，n = ${ordinal.n}）：整体似然比检验 p = ${formatNumber(ordinal.lr_p_value)}，McFadden R² = ${formatNumber(ordinal.mcfadden_r_squared)}。`, [
        { path: 'regression.ordinal.lr_p_value', value: ordinal.lr_p_value },
        { path: 'regression.ordinal.mcfadden_r_squared', value: ordinal.mcfadden_r_squared },
        { path: 'regression.ordinal.n', value: ordinal.n },
      ]);
      if (significant.length === 0) {
        line('FACT', '有序 Logistic 回归中没有单个预测变量的系数达到显著性水平。', []);
      }
      for (const coefficient of significant) {
        line('STATISTICAL_FINDING', `预测变量 ${coefficient.term} 的系数显著：B = ${formatNumber(coefficient.b)}，p = ${formatNumber(coefficient.p_value)}，OR = ${formatNumber(coefficient.odds_ratio)}。`, [
          { path: `regression.ordinal.coefficients[${coefficient.term}].b`, value: coefficient.b },
          { path: `regression.ordinal.coefficients[${coefficient.term}].p_value`, value: coefficient.p_value },
          { path: `regression.ordinal.coefficients[${coefficient.term}].odds_ratio`, value: coefficient.odds_ratio },
        ]);
      }
    }
    const ols = bundle.regression.ols;
    if (ols) {
      line('STATISTICAL_FINDING', `线性回归（因变量 ${ols.dependent}，n = ${ols.n}）：R² = ${formatNumber(ols.r_squared)}，F 检验 p = ${formatNumber(ols.f_p_value)}。`, [
        { path: 'regression.ols.r_squared', value: ols.r_squared },
        { path: 'regression.ols.f_p_value', value: ols.f_p_value },
        { path: 'regression.ols.n', value: ols.n },
      ]);
    }
  }

  /* 七、假设检验结论 */
  section('七、假设检验结论');
  const summary = bundle.hypotheses.summary;
  line('STATISTICAL_FINDING', `共检验 ${summary.total} 条假设：数据支持 ${summary.supported} 条，方向与假设相反 ${summary.not_supported} 条，证据不足 ${summary.inconclusive} 条，无法检验 ${summary.untestable} 条。`, [
    { path: 'hypotheses.summary.total', value: summary.total },
    { path: 'hypotheses.summary.supported', value: summary.supported },
    { path: 'hypotheses.summary.not_supported', value: summary.not_supported },
    { path: 'hypotheses.summary.inconclusive', value: summary.inconclusive },
    { path: 'hypotheses.summary.untestable', value: summary.untestable },
  ]);
  for (const result of bundle.hypotheses.results) {
    const verdictLabel = VERDICT_LABELS[result.verdict] ?? result.verdict;
    if (result.r === null || result.p_value === null) {
      line('STATISTICAL_FINDING', `${result.code}：${result.statement} 结论为「${verdictLabel}」。`, [
        { path: `hypotheses.results[${result.code}].verdict`, value: result.verdict },
      ]);
    } else {
      line('STATISTICAL_FINDING', `${result.code}：${result.statement} 结论为「${verdictLabel}」（${result.method}，r = ${formatNumber(result.r)}，p = ${formatNumber(result.p_value)}，n = ${result.n}）。`, [
        { path: `hypotheses.results[${result.code}].verdict`, value: result.verdict },
        { path: `hypotheses.results[${result.code}].r`, value: result.r },
        { path: `hypotheses.results[${result.code}].p_value`, value: result.p_value },
        { path: `hypotheses.results[${result.code}].n`, value: result.n },
      ]);
    }
  }
  line('FACT', '其中「证据不足」表示当前样本未能提供支持该假设的证据，不等于证明两者之间没有关系。', []);

  /* 八、解读前提 */
  section('八、解读前提（统计结果包原文）');
  bundle.caveats.forEach((caveat, index) => {
    line('FACT', caveat, [{ path: `caveats[${index}]`, value: caveat }]);
  });

  const statements: AiStatement[] = summaryLines.map((entry, position) => ({
    id: `engine-st-${position + 1}`,
    level: entry.level,
    text: entry.text,
    labelled_text: labelStatement(entry.level, entry.text),
    evidence: entry.evidence.map((item) => ({
      path: item.path,
      value: evidenceValue(item.value) ?? null,
      source: 'declared' as const,
    })),
    label_inferred: false,
    hypothesis_code: null,
  }));

  // The rendered text carries the Chinese level label on every line, so the
  // fallback is self-describing even when a client renders only the text.
  const text = statements.map((statement) => statement.labelled_text).join('\n');
  const summaryPayload: EngineSummary = {
    derived_by: 'statistical_engine',
    ai_generated: false,
    headline: '以下内容由统计引擎直接依据统计结果包生成，未经任何生成式模型改写。',
    text,
    statement_count: statements.length,
    sections,
  };

  return { summary: summaryPayload, statements };
}

/* ================================================================== */
/* Provider call                                                      */
/* ================================================================== */

interface ProviderOutcome {
  ok: boolean;
  content: string;
  usage: AiUsage | null;
  finish_reason: string | null;
  raw: string;
  http_status: number | null;
  unavailable: AiUnavailable | null;
  duration_ms: number;
}

function unavailable(
  code: AiUnavailableCode,
  message: string,
  status: number | null = null,
): AiUnavailable {
  return { code, message, provider_status: status };
}

function truncate(text: string, limit = 4000): string {
  return text.length <= limit ? text : `${text.slice(0, limit)}…（响应过长，已截断）`;
}

function readUsage(payload: unknown): AiUsage | null {
  if (payload === null || typeof payload !== 'object') return null;
  const usage = (payload as Record<string, unknown>)['usage'];
  if (usage === null || typeof usage !== 'object') return null;
  const record = usage as Record<string, unknown>;
  const toNumber = (value: unknown): number | null =>
    typeof value === 'number' && Number.isFinite(value) ? value : null;
  return {
    prompt_tokens: toNumber(record['prompt_tokens']),
    completion_tokens: toNumber(record['completion_tokens']),
    total_tokens: toNumber(record['total_tokens']),
  };
}

interface ProviderOptions {
  fetchImpl: FetchLike;
  baseUrl: string;
  apiKey: string;
  model: string;
  system: string;
  user: string;
  timeoutMs: number;
  maxOutputTokens: number;
  temperature: number;
}

/**
 * Call the chat-completions endpoint.
 *
 * Every failure mode returns a typed `unavailable` reason instead of throwing:
 * the caller degrades honestly, and the audit row records why. A truncated reply
 * (finish_reason = length) is NOT a failure — whatever the model finished is
 * validated and shipped, with `truncated` set.
 */
async function callProvider(options: ProviderOptions): Promise<ProviderOutcome> {
  const started = Date.now();
  const url = `${options.baseUrl}/chat/completions`;
  const body = JSON.stringify({
    model: options.model,
    messages: [
      { role: 'system', content: options.system },
      { role: 'user', content: options.user },
    ],
    temperature: options.temperature,
    max_tokens: options.maxOutputTokens,
    stream: false,
  });

  const failure = (
    code: AiUnavailableCode,
    message: string,
    raw = '',
    httpStatus: number | null = null,
  ): ProviderOutcome => ({
    ok: false,
    content: '',
    usage: null,
    finish_reason: null,
    raw: truncate(raw),
    http_status: httpStatus,
    unavailable: unavailable(code, message, httpStatus),
    duration_ms: Date.now() - started,
  });

  let response: Response;
  try {
    response = await options.fetchImpl(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${options.apiKey}`,
      },
      body,
      signal: AbortSignal.timeout(options.timeoutMs),
    });
  } catch (error) {
    const name = error instanceof Error ? error.name : '';
    const detail = error instanceof Error ? error.message : String(error);
    if (name === 'TimeoutError' || name === 'AbortError') {
      return failure(
        'timeout',
        `调用 AI 服务超时（超过 ${options.timeoutMs} 毫秒）：${detail}。已改用统计引擎直接生成的摘要。`,
      );
    }
    return failure('network_error', `无法连接 AI 服务（网络错误）：${detail}。已改用统计引擎直接生成的摘要。`);
  }

  let rawText = '';
  try {
    rawText = await response.text();
  } catch (error) {
    return failure(
      'network_error',
      `读取 AI 服务响应失败：${error instanceof Error ? error.message : String(error)}。`,
      '',
      response.status,
    );
  }

  if (!response.ok) {
    const providerMessage = extractProviderMessage(rawText);
    return failure(
      'provider_http_error',
      `AI 服务返回错误状态 HTTP ${response.status}${providerMessage ? `：${providerMessage}` : ''}。` +
        '已改用统计引擎直接生成的摘要，AI 解释未生成。',
      rawText,
      response.status,
    );
  }

  if (rawText.trimStart().startsWith('data:')) {
    return failure(
      'unexpected_shape',
      'AI 服务返回了流式（SSE）响应，而本接口需要一次性的 JSON 响应；请检查服务端是否被代理改写。',
      rawText,
      response.status,
    );
  }

  let payload: unknown;
  try {
    payload = JSON.parse(rawText);
  } catch {
    return failure(
      'malformed_json',
      'AI 服务的响应不是合法 JSON，无法解析本次解释结果。已改用统计引擎直接生成的摘要。',
      rawText,
      response.status,
    );
  }

  if (payload === null || typeof payload !== 'object') {
    return failure('unexpected_shape', 'AI 服务的响应结构不符合预期（不是 JSON 对象）。', rawText, response.status);
  }

  const choices = (payload as Record<string, unknown>)['choices'];
  if (!Array.isArray(choices) || choices.length === 0) {
    return failure(
      'empty_choices',
      'AI 服务的响应中没有 choices 内容，本次未获得任何解释文本。',
      rawText,
      response.status,
    );
  }

  const first = choices[0];
  if (first === null || typeof first !== 'object') {
    return failure('unexpected_shape', 'AI 服务的响应中 choices 的结构不符合预期。', rawText, response.status);
  }

  const firstRecord = first as Record<string, unknown>;
  const message = firstRecord['message'];
  const content =
    message !== null && typeof message === 'object'
      ? (message as Record<string, unknown>)['content']
      : undefined;

  if (typeof content !== 'string' || content.trim() === '') {
    return failure('empty_content', 'AI 服务返回了空内容（content 为空），本次没有可用的解释文本。', rawText, response.status);
  }

  const finishReason = typeof firstRecord['finish_reason'] === 'string' ? firstRecord['finish_reason'] : null;

  return {
    ok: true,
    content,
    usage: readUsage(payload),
    finish_reason: finishReason,
    raw: truncate(rawText),
    http_status: response.status,
    unavailable: null,
    duration_ms: Date.now() - started,
  };
}

function extractProviderMessage(rawText: string): string {
  try {
    const parsed = JSON.parse(rawText) as Record<string, unknown>;
    const error = parsed['error'];
    if (error !== null && typeof error === 'object') {
      const message = (error as Record<string, unknown>)['message'];
      if (typeof message === 'string') return truncate(message, 300);
    }
  } catch {
    // Fall through to a trimmed snippet of the raw body.
  }
  return truncate(rawText.trim(), 200);
}

/* ================================================================== */
/* Audit trail                                                        */
/* ================================================================== */

export interface AiInteraction {
  id: string;
  project_id: string;
  researcher_id: string | null;
  engine_version: string;
  mode: AiMode;
  model: string;
  prompt_hash: string;
  prompt_version: string;
  prompt_tokens: number | null;
  completion_tokens: number | null;
  total_tokens: number | null;
  duration_ms: number | null;
  scope: InterpretationScope;
  raw_response: string | null;
  result: AiInterpretationResult | null;
  rejected_claims: AiRejectedClaim[];
  rejected_count: number;
  error_code: string | null;
  error_message: string | null;
  created_at: string;
}

interface AiInteractionRow {
  id: string;
  project_id: string;
  researcher_id: string | null;
  engine_version: string;
  mode: string;
  model: string;
  prompt_hash: string;
  prompt_version: string;
  prompt_tokens: number | null;
  completion_tokens: number | null;
  total_tokens: number | null;
  duration_ms: number | null;
  scope: string | null;
  raw_response: string | null;
  result_json: string;
  rejected_claims: string | null;
  rejected_count: number;
  error_code: string | null;
  error_message: string | null;
  created_at: string;
}

function toAiInteraction(row: AiInteractionRow): AiInteraction {
  return {
    id: row.id,
    project_id: row.project_id,
    researcher_id: row.researcher_id,
    engine_version: row.engine_version,
    mode: row.mode === 'live' ? 'live' : 'degraded',
    model: row.model,
    prompt_hash: row.prompt_hash,
    prompt_version: row.prompt_version,
    prompt_tokens: row.prompt_tokens,
    completion_tokens: row.completion_tokens,
    total_tokens: row.total_tokens,
    duration_ms: row.duration_ms,
    scope: parseJson<InterpretationScope>(row.scope, emptyScope()),
    raw_response: row.raw_response,
    result: parseJson<AiInterpretationResult | null>(row.result_json, null),
    rejected_claims: parseJson<AiRejectedClaim[]>(row.rejected_claims, []),
    rejected_count: Number(row.rejected_count ?? 0),
    error_code: row.error_code,
    error_message: row.error_message,
    created_at: row.created_at,
  };
}

/** Read the audit trail. Ownership is enforced here, as in the analysis history. */
export function listAiInteractions(
  db: Db,
  projectId: string,
  researcherId: string,
  limit = 20,
): AiInteraction[] {
  requireProject(db, projectId, researcherId);
  const bounded = Math.min(Math.max(Math.trunc(limit) || 20, 1), 100);
  const rows = db.all<AiInteractionRow>(
    'SELECT * FROM ai_interactions WHERE project_id = ? ORDER BY created_at DESC, rowid DESC LIMIT ?',
    [projectId, bounded],
  );
  return rows.map(toAiInteraction);
}

/** The most recent interaction of any kind, including failed and degraded ones. */
export function getLatestAiInteraction(
  db: Db,
  projectId: string,
  researcherId: string,
): AiInteraction | null {
  requireProject(db, projectId, researcherId);
  const row = db.get<AiInteractionRow>(
    'SELECT * FROM ai_interactions WHERE project_id = ? ORDER BY created_at DESC, rowid DESC LIMIT 1',
    [projectId],
  );
  return row ? toAiInteraction(row) : null;
}

interface PersistInput {
  id: string;
  projectId: string;
  researcherId: string;
  engineVersion: string;
  mode: AiMode;
  model: string;
  promptHash: string;
  promptVersion: string;
  scope: InterpretationScope;
  rawResponse: string | null;
  result: AiInterpretationResult;
  rejected: AiRejectedClaim[];
  usage: AiUsage | null;
  durationMs: number | null;
  error: AiUnavailable | null;
}

function persistInteraction(db: Db, input: PersistInput): void {
  db.run(
    `INSERT INTO ai_interactions
       (id, project_id, researcher_id, engine_version, mode, model, prompt_hash, prompt_version,
        prompt_tokens, completion_tokens, total_tokens, duration_ms, scope, raw_response,
        result_json, rejected_claims, rejected_count, error_code, error_message, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      input.id,
      input.projectId,
      input.researcherId,
      input.engineVersion,
      input.mode,
      input.model,
      input.promptHash,
      input.promptVersion,
      input.usage?.prompt_tokens ?? null,
      input.usage?.completion_tokens ?? null,
      input.usage?.total_tokens ?? null,
      input.durationMs,
      JSON.stringify(input.scope),
      input.rawResponse,
      JSON.stringify(input.result),
      JSON.stringify(input.rejected),
      input.rejected.length,
      input.error?.code ?? null,
      input.error?.message ?? null,
      input.result.generated_at,
    ],
  );
}

/* ================================================================== */
/* Service                                                            */
/* ================================================================== */

export interface AiStatus {
  configured: boolean;
  mode: AiMode;
  /** Chinese explanation the UI can show before the researcher clicks. */
  reason: string;
  model: string;
  base_url: string;
  timeout_ms: number;
  has_bundle: boolean;
  bundle_generated_at: string | null;
  latest_interaction_at: string | null;
  latest_mode: AiMode | null;
}

export interface AiServiceOptions {
  db: Db;
  config: Config;
  /** Injection seam for tests; defaults to `config.ai.fetchImpl`. */
  fetchImpl?: FetchLike;
  model?: string;
  baseUrl?: string;
  timeoutMs?: number;
}

export interface AiInterpretRequest {
  projectId: string;
  researcherId: string;
  section?: string | null;
  hypothesis_code?: string | null;
  focus?: string | null;
}

export interface AiService {
  interpret(request: AiInterpretRequest): Promise<AiInterpretationResult>;
  status(projectId: string, researcherId: string): AiStatus;
}

const LIVE_NOTICE =
  '本结果分为四层：FACT 直接抄自统计结果包；STATISTICAL_FINDING 为统计引擎计算的统计量；' +
  'INTERPRETATION 与 RECOMMENDATION 由 AI 生成。所有被引用的数字都已逐一对结果包校验，' +
  '无法溯源的数字会使整条陈述被剔除，并记录在 rejected_claims 中。';

const DEGRADED_NOTICE =
  'AI 解释当前不可用，因此没有生成任何解释或建议。以下内容全部由统计引擎依据统计结果包直接生成' +
  '（engine_summary.ai_generated = false），不含生成式模型的推断，也未引入结果包之外的任何数字。';

export function createAiService(options: AiServiceOptions): AiService {
  const { db } = options;
  const ai = options.config.ai;
  const fetchImpl = options.fetchImpl ?? ai.fetchImpl;
  const model = options.model ?? ai.model;
  const baseUrl = options.baseUrl ?? ai.baseUrl;
  const timeoutMs = options.timeoutMs ?? ai.timeoutMs;

  function status(projectId: string, researcherId: string): AiStatus {
    requireProject(db, projectId, researcherId);
    const bundle = getLatestBundle(db, projectId, researcherId);
    const latest = getLatestAiInteraction(db, projectId, researcherId);
    const configured = ai.apiKey !== null;

    return {
      configured,
      mode: configured ? 'live' : 'degraded',
      reason: configured
        ? `已配置 DeepSeek 接口（模型 ${model}），AI 解释可用；所有解释均在统计结果包的基础上生成，并逐条校验数字来源。`
        : '未配置 DEEPSEEK_API_KEY 环境变量，AI 解释功能不可用。平台不会伪造解释，' +
          '而是返回由统计引擎直接生成的中文摘要（为结果包中的真实统计量）。',
      model,
      base_url: baseUrl,
      timeout_ms: timeoutMs,
      has_bundle: bundle !== null,
      bundle_generated_at: bundle?.generated_at ?? null,
      latest_interaction_at: latest?.created_at ?? null,
      latest_mode: latest?.mode ?? null,
    };
  }

  function buildDegradedResult(
    bundle: AnalysisBundle,
    interactionId: string,
    scope: InterpretationScope,
    promptHash: string | null,
    promptVersion: string,
    reason: AiUnavailable,
    usage: AiUsage | null,
    truncated: boolean,
    warnings: string[],
  ): AiInterpretationResult {
    const { summary, statements } = buildEngineDerivedSummary(bundle);
    const layers = emptyLayers();
    for (const statement of statements) addStatement(layers, statement);

    return {
      mode: 'degraded',
      interaction_id: interactionId,
      generated_at: nowIso(),
      engine_version: bundle.engine_version,
      prompt_version: promptVersion,
      prompt_hash: promptHash,
      model,
      base_url: baseUrl,
      scope,
      bundle_generated_at: bundle.generated_at,
      source_of_truth: 'analysis_bundle',
      layers,
      statement_count: statements.length,
      levels_used: levelsUsed(layers),
      rejected_claims: [],
      warnings,
      caveats: bundle.caveats,
      truncated,
      ai_unavailable: reason,
      engine_summary: summary,
      usage,
      notice: `${DEGRADED_NOTICE}\n${reason.message}`,
    };
  }

  async function interpret(request: AiInterpretRequest): Promise<AiInterpretationResult> {
    const { projectId, researcherId } = request;
    const project = requireProject(db, projectId, researcherId);
    const bundle = getLatestBundle(db, projectId, researcherId);

    if (!bundle) throw ApiError.validation(NO_BUNDLE_MESSAGE);

    const scope: InterpretationScope = {
      section: request.section ?? null,
      hypothesis_code: request.hypothesis_code ?? null,
      focus: request.focus ?? null,
    };

    if (scope.hypothesis_code !== null) {
      const known = bundle.hypotheses.results.map((result) => result.code);
      if (!known.includes(scope.hypothesis_code)) {
        throw ApiError.validation(
          `统计结果包中不存在假设 ${scope.hypothesis_code}。可用假设：${known.join('、')}。`,
        );
      }
    }

    const interactionId = newId();
    const promptVersion = ai.promptVersion;

    /* ---- Degraded: no key. No request is made and nothing is fabricated. ---- */
    if (ai.apiKey === null) {
      const result = buildDegradedResult(
        bundle,
        interactionId,
        scope,
        null,
        promptVersion,
        unavailable(
          'missing_api_key',
          '未配置 DEEPSEEK_API_KEY，AI 解释不可用；已返回由统计引擎直接生成的中文摘要。',
        ),
        null,
        false,
        [],
      );
      persistInteraction(db, {
        id: interactionId,
        projectId,
        researcherId,
        engineVersion: bundle.engine_version,
        mode: 'degraded',
        model,
        promptHash: '',
        promptVersion,
        scope,
        rawResponse: null,
        result,
        rejected: [],
        usage: null,
        durationMs: null,
        error: result.ai_unavailable,
      });
      return result;
    }

    /* ---- Live path ---- */
    const prompt = buildInterpretationPrompt({
      bundle,
      research_questions: project.research_questions,
      scope,
      prompt_version: promptVersion,
    });

    const outcome = await callProvider({
      fetchImpl,
      baseUrl,
      apiKey: ai.apiKey,
      model,
      system: prompt.system,
      user: prompt.user,
      timeoutMs,
      maxOutputTokens: ai.maxOutputTokens,
      temperature: ai.temperature,
    });

    if (!outcome.ok || outcome.unavailable) {
      const reason =
        outcome.unavailable ??
        unavailable('unexpected_shape', 'AI 服务返回了无法识别的结果。');
      const result = buildDegradedResult(
        bundle,
        interactionId,
        scope,
        prompt.prompt_hash,
        promptVersion,
        reason,
        outcome.usage,
        false,
        [`AI 调用失败：${reason.message}`],
      );
      persistInteraction(db, {
        id: interactionId,
        projectId,
        researcherId,
        engineVersion: bundle.engine_version,
        mode: 'degraded',
        model,
        promptHash: prompt.prompt_hash,
        promptVersion,
        scope,
        rawResponse: outcome.raw === '' ? null : outcome.raw,
        result,
        rejected: [],
        usage: outcome.usage,
        durationMs: outcome.duration_ms,
        error: reason,
      });
      return result;
    }

    const parsed = parseModelOutput(outcome.content, bundle);
    const truncated = outcome.finish_reason === 'length';
    const warnings = [...parsed.warnings];
    if (truncated) {
      warnings.push(
        '模型输出被截断（finish_reason = length，达到 max_tokens 上限），仅返回已完成的部分陈述；' +
          '建议提高 DEEPSEEK_MAX_TOKENS 后重试。',
      );
    }

    const result: AiInterpretationResult = {
      mode: 'live',
      interaction_id: interactionId,
      generated_at: nowIso(),
      engine_version: bundle.engine_version,
      prompt_version: promptVersion,
      prompt_hash: prompt.prompt_hash,
      model,
      base_url: baseUrl,
      scope,
      bundle_generated_at: bundle.generated_at,
      source_of_truth: 'analysis_bundle',
      layers: parsed.layers,
      statement_count: parsed.statement_count,
      levels_used: levelsUsed(parsed.layers),
      rejected_claims: parsed.rejected_claims,
      warnings,
      caveats: bundle.caveats,
      truncated,
      ai_unavailable: null,
      engine_summary: null,
      usage: outcome.usage,
      notice: LIVE_NOTICE,
    };

    persistInteraction(db, {
      id: interactionId,
      projectId,
      researcherId,
      engineVersion: bundle.engine_version,
      mode: 'live',
      model,
      promptHash: prompt.prompt_hash,
      promptVersion,
      scope,
      rawResponse: outcome.raw,
      result,
      rejected: parsed.rejected_claims,
      usage: outcome.usage,
      durationMs: outcome.duration_ms,
      error: null,
    });

    return result;
  }

  return { interpret, status };
}

function levelsUsed(layers: AiLayers): AiLevel[] {
  const used: AiLevel[] = [];
  if (layers.facts.length > 0) used.push('FACT');
  if (layers.statistical_findings.length > 0) used.push('STATISTICAL_FINDING');
  if (layers.interpretations.length > 0) used.push('INTERPRETATION');
  if (layers.recommendations.length > 0) used.push('RECOMMENDATION');
  return used;
}
