/**
 * Bundle the jsdom test files for `node --test`.
 *
 * Tests are discovered rather than listed, so adding a test file is enough to
 * have it run; the previous hand-maintained entry list is exactly how the PHASE 6
 * tests went missing from `npm test` for a while.
 *
 * Output goes to `dist-tests/` (not `dist/`), because `dist/` is what the static
 * server publishes — test bundles have no business being fetchable by URL.
 *
 *   node scripts/build-tests.mjs
 *   node --test --test-isolation=none --test-force-exit "dist-tests/*.test.js"
 *
 * esbuild runs as a CLI child process with inherited stdio: this environment
 * blocks piped stdio for spawned processes, and esbuild's JS API spawns its
 * service binary with pipes (EPERM).
 */

import { spawn } from 'node:child_process';
import { readdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const repoRoot = resolve(root, '..', '..');

// Run the esbuild CLI through node rather than through the `.cmd` shim: the
// repository path contains a space, and spawning a `.cmd` on Windows requires a
// shell, which would split that path into two arguments.
const esbuildCli = resolve(repoRoot, 'node_modules', 'esbuild', 'bin', 'esbuild');

const entries = readdirSync(resolve(root, 'tests'))
  .filter((name) => name.endsWith('.test.ts') || name.endsWith('.test.tsx'))
  .sort()
  .map((name) => `tests/${name}`);

if (entries.length === 0) {
  console.error('[ferp-web] tests/ 下没有找到任何测试文件');
  process.exit(1);
}

const child = spawn(
  process.execPath,
  [
    esbuildCli,
    ...entries,
    '--bundle',
    '--outdir=dist-tests',
    '--format=esm',
    '--platform=node',
    '--target=node22',
    '--jsx=automatic',
    '--external:jsdom',
    '--log-level=warning',
  ],
  { cwd: root, stdio: 'inherit' },
);

child.on('exit', (code) => {
  if (code === 0) console.log(`[ferp-web] 已打包 ${entries.length} 个测试文件 -> dist-tests/`);
  process.exit(code ?? 1);
});
