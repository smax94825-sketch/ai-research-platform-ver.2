/**
 * Categorical bar chart.
 *
 * Used for frequency distributions and for any short list of counts. Horizontal
 * bars rather than vertical ones because the category labels are Chinese
 * phrases: laying them out along the left edge keeps every label complete
 * instead of rotating or truncating it.
 *
 * The value axis supports negative values with a zero baseline (item–total
 * correlations can be negative, and a negative bar drawn as a zero-length one
 * would hide exactly the item that needs attention).
 */

import type { ReactNode } from 'react';
import { truncate } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, ResponsiveSvg } from './primitives';

export interface BarChartDatum {
  label: string;
  value: number;
  /** Share of the whole; computed from `total` when omitted. */
  percent?: number;
}

export interface BarChartProps {
  data: BarChartDatum[];
  /** Denominator for the percentages. Defaults to the sum of `data`. */
  total?: number;
  /** Unit printed after the count, e.g. 人 / 份 / 个. */
  unit?: string;
  emptyText?: string;
  /** Character budget for the label column before it is ellipsised. */
  labelChars?: number;
  /** Caption under the chart (units, denominators, caveats). */
  caption?: ReactNode;
}

const WIDTH = 680;
const LABEL_CHARS_DEFAULT = 26;

export function BarChart({
  data,
  total,
  unit = '人',
  emptyText = '暂无可展示的数据。',
  labelChars = LABEL_CHARS_DEFAULT,
  caption,
}: BarChartProps): ReactNode {
  if (data.length === 0) return <ChartEmpty text={emptyText} />;

  const denominator = total ?? data.reduce((sum, item) => sum + item.value, 0);
  const values = data.map((item) => item.value);
  const domainMin = Math.min(0, ...values);
  const domainMax = Math.max(0, ...values);
  const span = domainMax - domainMin > 0 ? domainMax - domainMin : 1;
  const zeroX = ((0 - domainMin) / span) * WIDTH;

  const rowHeight = 30;
  const barHeight = 7;
  const topPadding = 4;
  const height = topPadding + data.length * rowHeight + 2;

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={height} label="频数分布条形图">
        {domainMin < 0 && (
          <line x1={zeroX} y1={topPadding} x2={zeroX} y2={topPadding + data.length * rowHeight} stroke="#b1bac9" strokeWidth={1} />
        )}
        {data.map((item, index) => {
          const rowTop = topPadding + index * rowHeight;
          const barWidth = (Math.abs(item.value) / span) * WIDTH;
          const percent = item.percent ?? (denominator > 0 ? (item.value / denominator) * 100 : 0);
          return (
            <g key={`${item.label}-${index}`}>
              <text x={0} y={rowTop + 11} fontSize={FONT} fill="#3a4150">
                {truncate(item.label, labelChars)}
              </text>
              <text x={WIDTH} y={rowTop + 11} fontSize={FONT} fill="#535f74" textAnchor="end">
                {`${item.value} ${unit} · ${percent.toFixed(1)}%`}
              </text>
              <rect
                x={item.value >= 0 ? zeroX : zeroX - barWidth}
                y={rowTop + 16}
                width={Math.max(barWidth, item.value !== 0 ? 2 : 0)}
                height={barHeight}
                rx={3}
                fill={item.value >= 0 ? '#3366ff' : '#c8222c'}
              />
            </g>
          );
        })}
      </ResponsiveSvg>
      <ChartCaption>
        {caption ?? `合计 ${denominator} ${unit}；百分比按合计计算。`}
      </ChartCaption>
    </div>
  );
}
