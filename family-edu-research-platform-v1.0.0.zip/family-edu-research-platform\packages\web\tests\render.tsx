/** React render helpers for the jsdom-based UI tests. */

import { act, type ReactElement } from 'react';
import { createRoot, type Root } from 'react-dom/client';

let root: Root | null = null;

/** Mount a React element into the jsdom #root container. */
export async function render(element: ReactElement, container?: HTMLElement): Promise<void> {
  const target = container ?? document.getElementById('root');
  if (!target) throw new Error('#root container not found');
  root = createRoot(target);
  await act(async () => {
    root!.render(element);
  });
}

/** Re-render / flush pending state updates. */
export async function flush(action?: () => void | Promise<void>): Promise<void> {
  await act(async () => {
    if (action) await action();
    // Let microtasks (fetch promises) settle inside the same act() scope.
    await Promise.resolve();
  });
}

export async function unmount(): Promise<void> {
  if (!root) return;
  const current = root;
  root = null;
  await act(async () => {
    current.unmount();
  });
}

/* ------------------------------------------------------------------ */
/* Query helpers                                                      */
/* ------------------------------------------------------------------ */

export function text(): string {
  return document.body.textContent ?? '';
}

export function queryAll(selector: string): Element[] {
  return Array.from(document.querySelectorAll(selector));
}

export function findByText(selector: string, needle: string): Element | undefined {
  return queryAll(selector).find((element) => (element.textContent ?? '').includes(needle));
}

/** Click an element inside act(), so React state updates are flushed. */
export async function click(element: Element): Promise<void> {
  await act(async () => {
    element.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));
    await Promise.resolve();
  });
}

/** Type into an input/textarea/select inside act(). */
export async function typeInto(element: Element, value: string): Promise<void> {
  const input = element as HTMLInputElement;
  const prototype =
    input instanceof window.HTMLTextAreaElement
      ? window.HTMLTextAreaElement.prototype
      : input instanceof window.HTMLSelectElement
        ? window.HTMLSelectElement.prototype
        : window.HTMLInputElement.prototype;

  const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
  await act(async () => {
    if (setter) setter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new window.Event('input', { bubbles: true }));
    input.dispatchEvent(new window.Event('change', { bubbles: true }));
    await Promise.resolve();
  });
}

/** Submit a form inside act(). */
export async function submit(form: Element): Promise<void> {
  await act(async () => {
    form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
    await Promise.resolve();
    await Promise.resolve();
  });
}
