import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import type { Question, QuestionLogic, QuestionType, VariableDefinition } from '@ferp/shared';
import { Alert, Badge, Button, Card, CardHeader, LoadingBlock, Modal } from '../components/ui';
import { QuestionList } from '../components/builder/QuestionList';
import { QuestionPreview } from '../components/QuestionPreview';
import { QuestionSettings, type QuestionDraft } from '../components/builder/QuestionSettings';
import { LogicEditor } from '../components/builder/LogicEditor';
import { PreviewPanel } from '../components/builder/PreviewPanel';
import { PublishPanel } from '../components/builder/PublishPanel';
import {
  api,
  ApiClientError,
  type BuilderState,
  type LogicView,
} from '../lib/api';
import { questionnaireStatusMeta } from '../lib/format';

type Tab = 'questions' | 'logic' | 'preview' | 'publish' | 'dictionary';

const TABS: { id: Tab; label: string }[] = [
  { id: 'questions', label: 'Builder 题目' },
  { id: 'logic', label: 'Logic 逻辑' },
  { id: 'preview', label: 'Preview 预览' },
  { id: 'publish', label: 'Publish 发布' },
  { id: 'dictionary', label: '变量字典' },
];

export function BuilderPage(): ReactNode {
  const { projectId = '', questionnaireId = '' } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = (searchParams.get('tab') as Tab | null) ?? 'questions';

  const [state, setState] = useState<BuilderState | null>(null);
  const [logic, setLogic] = useState<LogicView | null>(null);
  const [dictionary, setDictionary] = useState<VariableDefinition[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [fieldError, setFieldError] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Question | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const [builder, logicView] = await Promise.all([
        api.questionnaires.builder(questionnaireId),
        api.questionnaires.logic(questionnaireId),
      ]);
      setState(builder);
      setLogic(logicView);
      setSelectedId((current) => current ?? builder.questions[0]?.id ?? null);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载问卷构建器。');
    } finally {
      setLoading(false);
    }
  }, [questionnaireId]);

  useEffect(() => {
    setLoading(true);
    setSelectedId(null);
    setDictionary(null);
    void load();
  }, [load]);

  // Load the codebook lazily — it is comparatively expensive to build.
  useEffect(() => {
    if (tab !== 'dictionary' || dictionary) return;
    let cancelled = false;
    void (async () => {
      try {
        const result = await api.questionnaires.dictionary(questionnaireId);
        if (!cancelled) setDictionary(result.dictionary);
      } catch (err) {
        if (!cancelled) setError(err instanceof ApiClientError ? err.message : '无法生成变量字典。');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [tab, dictionary, questionnaireId]);

  const selected = state?.questions.find((question) => question.id === selectedId) ?? null;
  const editable = state?.editable ?? false;

  function flash(message: string): void {
    setNotice(message);
    window.setTimeout(() => setNotice(null), 3500);
  }

  /** Run a mutation, then refresh both the builder state and the logic view. */
  async function run(action: () => Promise<unknown>, successMessage?: string): Promise<boolean> {
    setBusy(true);
    setError(null);
    setFieldError(null);
    try {
      await action();
      await load();
      if (successMessage) flash(successMessage);
      return true;
    } catch (err) {
      if (err instanceof ApiClientError) {
        const details = err.fieldErrors;
        setFieldError(details.length > 0 ? details.map((item) => item.message).join(' ') : err.message);
        setError(details.length > 0 ? null : err.message);
      } else {
        setError('操作失败，请稍后重试。');
      }
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function saveQuestion(draft: QuestionDraft): Promise<void> {
    if (!selected) return;
    await run(
      () =>
        api.questions.update(selected.id, {
          question_text: draft.question_text,
          question_type: draft.question_type,
          options: draft.options,
          required: draft.required,
          dimension: draft.dimension,
          variable_name: draft.variable_name,
          section: draft.section,
          help_text: draft.help_text,
          scoring_rule: draft.scoring_rule,
        }),
      '题目已保存。',
    );
  }

  async function addQuestion(type: QuestionType): Promise<void> {
    const defaults: Record<string, Record<string, unknown>> = {
      single: {
        question_text: '新建单选题',
        options: {
          choices: [
            { value: '1', label: '选项一', score: 1 },
            { value: '2', label: '选项二', score: 2 },
          ],
        },
        scoring_rule: { type: 'none' },
      },
      multiple: {
        question_text: '新建多选题',
        options: {
          choices: [
            { value: '1', label: '选项一', score: 1 },
            { value: '2', label: '选项二', score: 2 },
          ],
        },
        scoring_rule: { type: 'count', excludeExclusive: true },
      },
      likert: {
        question_text: '新建李克特量表题',
        options: {
          choices: [
            { value: '1', label: '非常不同意', score: 1 },
            { value: '2', label: '比较不同意', score: 2 },
            { value: '3', label: '一般', score: 3 },
            { value: '4', label: '比较同意', score: 4 },
            { value: '5', label: '非常同意', score: 5 },
          ],
          scaleMin: 1,
          scaleMax: 5,
        },
        scoring_rule: { type: 'mean', min: 1, max: 5 },
      },
      matrix: {
        question_text: '新建矩阵量表题',
        options: {
          matrix: {
            rows: [
              { value: '1', label: '行项目一' },
              { value: '2', label: '行项目二' },
            ],
            columns: [
              { value: '1', label: '很低', score: 1 },
              { value: '2', label: '较低', score: 2 },
              { value: '3', label: '一般', score: 3 },
              { value: '4', label: '较高', score: 4 },
              { value: '5', label: '很高', score: 5 },
            ],
          },
        },
        scoring_rule: { type: 'mean', min: 1, max: 5 },
      },
      ranking: {
        question_text: '新建排序题',
        options: {
          choices: [
            { value: '1', label: '项目一' },
            { value: '2', label: '项目二' },
            { value: '3', label: '项目三' },
          ],
        },
        scoring_rule: { type: 'none' },
      },
      knowledge_test: {
        question_text: '判断：请在此填写需要受访者判断的陈述。',
        options: {
          choices: [
            { value: '1', label: '正确', score: 1, isCorrect: true },
            { value: '2', label: '错误', score: 0 },
            { value: '3', label: '不清楚', score: 0 },
          ],
        },
        scoring_rule: {
          type: 'knowledge',
          correctScore: 1,
          incorrectScore: 0,
          unknownScore: 0,
          unknownValue: '3',
          maxScore: 1,
        },
      },
      text: { question_text: '新建文本题', options: { maxLength: 200 }, scoring_rule: { type: 'none' } },
      textarea: { question_text: '新建多行文本题', options: { maxLength: 500 }, scoring_rule: { type: 'none' } },
      number: { question_text: '新建数字题', options: { min: 0, max: 100 }, scoring_rule: { type: 'none' } },
      date: { question_text: '新建日期题', options: {}, scoring_rule: { type: 'none' } },
      page_break: { question_text: '新章节标题', options: {}, scoring_rule: { type: 'none' }, required: false },
    };

    const payload = {
      question_type: type,
      required: type !== 'page_break',
      ...(defaults[type] ?? { question_text: '新建题目', options: {} }),
    };

    const created = await run(() => api.questionnaires.addQuestion(questionnaireId, payload), '已添加题目。');
    if (created) {
      const fresh = await api.questionnaires.builder(questionnaireId);
      const added = fresh.questions.find((question) => question.question_code === fresh.suggested_next_code);
      const last = fresh.questions[fresh.questions.length - 1];
      setSelectedId(added?.id ?? last?.id ?? null);
    }
  }

  async function saveLogic(questionId: string, nextLogic: QuestionLogic | null): Promise<void> {
    await run(() => api.questions.update(questionId, { logic: nextLogic }), '逻辑规则已保存。');
  }

  async function downloadDictionary(): Promise<void> {
    try {
      const csv = await api.questionnaires.dictionaryCsv(questionnaireId);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `variable-dictionary-${state?.questionnaire.version ?? 'v1'}.csv`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '导出变量字典失败。');
    }
  }

  if (loading) return <LoadingBlock label="正在加载问卷…" />;
  if (!state) {
    return (
      <Alert tone="danger" title="无法加载问卷">
        {error ?? '问卷不存在，或您没有访问权限。'}
      </Alert>
    );
  }

  const meta = questionnaireStatusMeta(state.questionnaire.status);

  return (
    <div className="space-y-4">
      {/* Header --------------------------------------------------------- */}
      <div>
        <Link to={`/projects/${projectId}`} className="text-sm text-ink-500 hover:text-ink-800">
          ← 返回项目「{state.project.title}」
        </Link>
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <h1 className="text-xl font-semibold text-ink-900">{state.questionnaire.title}</h1>
          <span className="font-mono text-xs text-ink-500">{state.questionnaire.version}</span>
          <Badge tone={meta.tone}>{meta.label}</Badge>
          {state.questionnaire.locked && <Badge tone="warning">已锁定</Badge>}
          <span className="text-xs text-ink-500">{state.questions.length} 道题</span>
        </div>
      </div>

      {error && (
        <Alert tone="danger" title="操作失败">
          {error}
        </Alert>
      )}
      {notice && <Alert tone="success">{notice}</Alert>}
      {!editable && state.lock_reason && (
        <Alert tone="warning" title="当前版本已锁定">
          {state.lock_reason}
        </Alert>
      )}

      {/* Tabs ----------------------------------------------------------- */}
      <div className="flex flex-wrap gap-1 border-b border-ink-200">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setSearchParams({ tab: item.id })}
            className={`rounded-t-md px-3 py-2 text-sm transition-colors ${
              tab === item.id
                ? 'border-b-2 border-brand-600 font-medium text-brand-700'
                : 'text-ink-600 hover:bg-ink-100'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Panels --------------------------------------------------------- */}
      {tab === 'questions' && (
        <div className="grid gap-4 xl:grid-cols-[280px_1fr_360px]">
          <Card padded={false} className="overflow-hidden">
            <QuestionList
              questions={state.questions}
              selectedId={selectedId}
              editable={editable}
              nextCode={state.suggested_next_code}
              busy={busy}
              onSelect={setSelectedId}
              onMove={(id, direction) => void run(() => api.questions.move(id, direction))}
              onDuplicate={(id) =>
                void run(async () => {
                  const copy = await api.questions.duplicate(id);
                  setSelectedId(copy.id);
                }, '已复制题目。')
              }
              onDelete={(id) => setPendingDelete(state.questions.find((q) => q.id === id) ?? null)}
              onAdd={(type) => void addQuestion(type)}
            />
          </Card>

          <Card>
            <CardHeader
              title="实时预览"
              description="按受访者视角渲染当前题目。切换题目或修改设置后立即更新。"
            />
            {selected ? (
              <div className="space-y-4">
                <QuestionPreview question={selected} value={null} readOnly />
                <dl className="grid grid-cols-2 gap-3 border-t border-ink-100 pt-3 text-xs">
                  <div>
                    <dt className="text-ink-500">研究维度</dt>
                    <dd className="mt-0.5 text-ink-800">{selected.dimension ?? '未设置'}</dd>
                  </div>
                  <div>
                    <dt className="text-ink-500">变量名</dt>
                    <dd className="mt-0.5 font-mono text-ink-800">{selected.variable_name ?? '未设置'}</dd>
                  </div>
                  <div>
                    <dt className="text-ink-500">必答</dt>
                    <dd className="mt-0.5 text-ink-800">{selected.required ? '是' : '否'}</dd>
                  </div>
                  <div>
                    <dt className="text-ink-500">排序位置</dt>
                    <dd className="mt-0.5 tabular-nums text-ink-800">第 {selected.sort_order} 题</dd>
                  </div>
                  <div className="col-span-2">
                    <dt className="text-ink-500">所属部分</dt>
                    <dd className="mt-0.5 text-ink-800">{selected.section ?? '未分组'}</dd>
                  </div>
                </dl>

                {selected.logic && selected.logic.rules.length > 0 && (
                  <Alert tone="info" title="本题设置了条件逻辑">
                    共 {selected.logic.rules.length} 条规则，可在「Logic 逻辑」标签页查看与编辑。
                  </Alert>
                )}
              </div>
            ) : (
              <p className="py-10 text-center text-sm text-ink-400">请选择一道题目进行预览。</p>
            )}
          </Card>

          {selected ? (
            <Card padded={false} className="overflow-hidden">
              <QuestionSettings
                question={selected}
                editable={editable}
                saving={busy}
                fieldError={fieldError}
                onSave={saveQuestion}
                onCancel={() => void load()}
                onDelete={() => setPendingDelete(selected)}
                onDuplicate={() =>
                  void run(async () => {
                    const copy = await api.questions.duplicate(selected.id);
                    setSelectedId(copy.id);
                  }, '已复制题目。')
                }
              />
            </Card>
          ) : (
            <Card>
              <p className="py-10 text-center text-sm text-ink-400">Question Settings</p>
            </Card>
          )}
        </div>
      )}

      {tab === 'logic' && (
        <LogicEditor
          questions={state.questions}
          selected={selected}
          editable={editable}
          issues={logic?.issues ?? []}
          saving={busy}
          onSelectQuestion={setSelectedId}
          onSave={saveLogic}
        />
      )}

      {tab === 'preview' && (
        <PreviewPanel
          questionnaireId={questionnaireId}
          questions={state.questions}
          version={state.questionnaire.version}
        />
      )}

      {tab === 'publish' && (
        <PublishPanel
          questionnaire={state.questionnaire}
          editable={editable}
          lockReason={state.lock_reason}
          logicIssues={logic?.issues ?? []}
          questionCount={state.questions.length}
          onChanged={load}
        />
      )}

      {tab === 'dictionary' && (
        <Card padded={false}>
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink-200 px-5 py-4">
            <div>
              <h2 className="text-base font-semibold text-ink-900">Variable Dictionary / Codebook</h2>
              <p className="mt-1 text-sm text-ink-500">
                由当前问卷定义自动生成，可直接交付给 SPSS / R / Stata。共 {dictionary?.length ?? 0} 个变量。
              </p>
            </div>
            <Button variant="primary" onClick={() => void downloadDictionary()}>
              导出 CSV（含 BOM）
            </Button>
          </div>

          {!dictionary ? (
            <LoadingBlock label="正在生成变量字典…" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1000px] text-sm">
                <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                  <tr>
                    <th className="px-3 py-2 text-left">Variable</th>
                    <th className="px-3 py-2 text-left">Q</th>
                    <th className="px-3 py-2 text-left">题干 / 标签</th>
                    <th className="px-3 py-2 text-left">维度</th>
                    <th className="px-3 py-2 text-left">类型</th>
                    <th className="px-3 py-2 text-left">编码</th>
                    <th className="px-3 py-2 text-left">缺失值</th>
                    <th className="px-3 py-2 text-left">分析方法</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {dictionary.map((variable, index) => (
                    <tr key={`${variable.variable_name}-${index}`} className="align-top">
                      <td className="px-3 py-2">
                        <span className="font-mono text-xs font-medium text-brand-700">
                          {variable.variable_name}
                        </span>
                        {variable.is_derived && (
                          <span className="ml-1 rounded bg-ink-100 px-1 text-[10px] text-ink-600">派生</span>
                        )}
                      </td>
                      <td className="px-3 py-2 font-mono text-xs text-ink-600">{variable.question_code}</td>
                      <td className="max-w-[260px] px-3 py-2 text-ink-800">{variable.question_text}</td>
                      <td className="px-3 py-2 text-xs text-ink-600">{variable.dimension}</td>
                      <td className="px-3 py-2 text-xs text-ink-600">{variable.data_type}</td>
                      <td className="max-w-[240px] px-3 py-2 text-xs text-ink-600">{variable.coding}</td>
                      <td className="max-w-[220px] px-3 py-2 text-xs text-amber-800">
                        {variable.missing_value}
                      </td>
                      <td className="max-w-[260px] px-3 py-2 text-xs text-ink-600">
                        {variable.analysis_method}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {/* Delete confirmation ------------------------------------------- */}
      <Modal
        open={pendingDelete !== null}
        title="确认删除题目"
        onClose={() => setPendingDelete(null)}
        footer={
          <>
            <Button onClick={() => setPendingDelete(null)}>取消</Button>
            <Button
              variant="danger"
              loading={busy}
              onClick={() => {
                const target = pendingDelete;
                setPendingDelete(null);
                if (target) {
                  void run(async () => {
                    const result = await api.questions.remove(target.id);
                    if (result.dangling_logic.length > 0) {
                      setError(
                        `题目已删除，但有 ${result.dangling_logic.length} 条逻辑规则引用了它，请前往「Logic 逻辑」标签页修复：` +
                          result.dangling_logic.map((item) => item.message).join('；'),
                      );
                    }
                  }, '已删除题目。');
                }
              }}
            >
              确认删除
            </Button>
          </>
        }
      >
        <p className="text-sm text-ink-700">
          即将删除 <span className="font-mono">{pendingDelete?.question_code}</span>
          {pendingDelete?.variable_name && (
            <>
              （变量名 <span className="font-mono">{pendingDelete.variable_name}</span>）
            </>
          )}
          ，其后题目的序号会自动前移。
        </p>
        <div className="mt-3">
          <Alert tone="warning" title="注意">
            统计引擎不会自动删除样本，但删除题目会使该题已收集的作答无法再进入分析。若问卷已收集数据，
            请改用「建立新版本」。
          </Alert>
        </div>
      </Modal>
    </div>
  );
}
