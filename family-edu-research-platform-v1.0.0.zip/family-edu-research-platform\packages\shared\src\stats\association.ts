/**
 * Correlation and effect sizes (PHASE 5).
 *
 * The engine chooses Pearson or Spearman from the variables' measurement level
 * rather than defaulting to Pearson, because reporting a Pearson r for two
 * ordinal Likert items is a common and avoidable methodological error.
 *
 * Every effect size comes with the interpretation bands it is being read
 * against, so a reader can disagree with the threshold instead of having to
 * guess which convention was used.
 */

import { roundTo, studentTTwoTailedP, studentTQuantile, normalQuantile } from './special.js';
import { pearsonCorrelation } from './matrix.js';
import type { Dataset, DatasetVariable } from './dataset.js';
import { completeCases } from './dataset.js';

/* ------------------------------------------------------------------ */
/* Rank correlation                                                   */
/* ------------------------------------------------------------------ */

/** Average ranks, so ties do not distort Spearman's rho. */
export function ranks(values: number[]): number[] {
  const indexed = values.map((value, index) => ({ value, index }));
  indexed.sort((left, right) => left.value - right.value);

  const result = new Array<number>(values.length).fill(0);
  let position = 0;
  while (position < indexed.length) {
    let end = position;
    while (end + 1 < indexed.length && indexed[end + 1]!.value === indexed[position]!.value) end += 1;
    const averageRank = (position + end) / 2 + 1;
    for (let k = position; k <= end; k += 1) result[indexed[k]!.index] = averageRank;
    position = end + 1;
  }
  return result;
}

export function spearmanCorrelation(x: number[], y: number[]): number {
  if (x.length !== y.length || x.length < 3) return Number.NaN;
  return pearsonCorrelation(ranks(x), ranks(y));
}

/* ------------------------------------------------------------------ */
/* Method selection                                                   */
/* ------------------------------------------------------------------ */

export type CorrelationMethod = 'pearson' | 'spearman';

export function chooseCorrelationMethod(
  left: DatasetVariable,
  right: DatasetVariable,
): { method: CorrelationMethod; reason: string } {
  const continuous: DatasetVariable['data_type'][] = ['interval', 'ratio'];
  const bothContinuous = continuous.includes(left.data_type) && continuous.includes(right.data_type);

  if (bothContinuous) {
    return {
      method: 'pearson',
      reason: `两个变量均为连续/等距测量（${left.data_type}、${right.data_type}），采用 Pearson 积矩相关。`,
    };
  }
  return {
    method: 'spearman',
    reason:
      `至少一个变量为有序分类或计数测量（${left.data_type}、${right.data_type}），` +
      '采用 Spearman 等级相关，避免对有序变量误用 Pearson 相关。',
  };
}

/* ------------------------------------------------------------------ */
/* Effect size interpretation                                         */
/* ------------------------------------------------------------------ */

export interface EffectMagnitude {
  /** Absolute value the bands were applied to. */
  value: number;
  band: 'negligible' | 'small' | 'medium' | 'large';
  text: string;
  /** The convention the bands come from, stated so it can be challenged. */
  convention: string;
}

export function classifyCorrelation(r: number): EffectMagnitude {
  const magnitude = Math.abs(r);
  const convention = 'Cohen (1988) 相关系数惯例：.10 小、.30 中、.50 大';
  const band: EffectMagnitude['band'] =
    magnitude < 0.1 ? 'negligible' : magnitude < 0.3 ? 'small' : magnitude < 0.5 ? 'medium' : 'large';
  const label = { negligible: '可忽略', small: '小', medium: '中等', large: '大' }[band];
  return { value: roundTo(magnitude, 4), band, text: `效应量${label}（|r| = ${roundTo(magnitude, 3)}）`, convention };
}

export function classifyCohensD(d: number): EffectMagnitude {
  const magnitude = Math.abs(d);
  const convention = 'Cohen (1988) d 惯例：0.20 小、0.50 中、0.80 大';
  const band: EffectMagnitude['band'] =
    magnitude < 0.2 ? 'negligible' : magnitude < 0.5 ? 'small' : magnitude < 0.8 ? 'medium' : 'large';
  const label = { negligible: '可忽略', small: '小', medium: '中等', large: '大' }[band];
  return { value: roundTo(magnitude, 4), band, text: `效应量${label}（|d| = ${roundTo(magnitude, 3)}）`, convention };
}

export function classifyEtaSquared(etaSquared: number, partial = false): EffectMagnitude {
  const magnitude = Math.abs(etaSquared);
  const convention = partial
    ? 'Cohen (1988) partial η² 惯例：.01 小、.06 中、.14 大'
    : 'Cohen (1988) η² 惯例：.01 小、.06 中、.14 大';
  const band: EffectMagnitude['band'] =
    magnitude < 0.01 ? 'negligible' : magnitude < 0.06 ? 'small' : magnitude < 0.14 ? 'medium' : 'large';
  const label = { negligible: '可忽略', small: '小', medium: '中等', large: '大' }[band];
  const symbol = partial ? 'partial η²' : 'η²';
  return {
    value: roundTo(magnitude, 4),
    band,
    text: `效应量${label}（${symbol} = ${roundTo(magnitude, 3)}）`,
    convention,
  };
}

export function classifyCramersV(v: number, minimumDimension: number): EffectMagnitude {
  const magnitude = Math.abs(v);
  const convention = `Cramér's V 惯例（最小维度 − 1 = ${minimumDimension - 1}）：按自由度调整的小/中/大阈值`;
  const small = Math.sqrt(0.01 / Math.max(minimumDimension - 1, 1));
  const medium = Math.sqrt(0.09 / Math.max(minimumDimension - 1, 1));
  const large = Math.sqrt(0.25 / Math.max(minimumDimension - 1, 1));
  const band: EffectMagnitude['band'] =
    magnitude < small ? 'negligible' : magnitude < medium ? 'small' : magnitude < large ? 'medium' : 'large';
  const label = { negligible: '可忽略', small: '小', medium: '中等', large: '大' }[band];
  return { value: roundTo(magnitude, 4), band, text: `关联强度${label}（V = ${roundTo(magnitude, 3)}）`, convention };
}

/* ------------------------------------------------------------------ */
/* Pairwise correlation                                               */
/* ------------------------------------------------------------------ */

export interface CorrelationPair {
  left: string;
  right: string;
  method: CorrelationMethod;
  method_reason: string;
  r: number | null;
  p_value: number | null;
  n: number;
  /** Fisher-z 95% confidence interval for r (Pearson only). */
  ci_lower: number | null;
  ci_upper: number | null;
  /** Proportion of shared variance, r²×100. */
  shared_variance_percent: number | null;
  effective_size: EffectMagnitude | null;
  note: string;
}

/**
 * Correlate two variables.
 *
 * The confidence interval uses Fisher's z transformation and is reported only
 * for Pearson's r; for Spearman's rho the interval is not distribution-free and
 * is therefore omitted rather than approximated.
 */
export function correlatePair(
  dataset: Dataset,
  leftName: string,
  rightName: string,
  options: { confidence?: number } = {},
): CorrelationPair {
  const left = dataset.by_name.get(leftName);
  const right = dataset.by_name.get(rightName);
  if (!left || !right) {
    return {
      left: leftName,
      right: rightName,
      method: 'pearson',
      method_reason: '',
      r: null,
      p_value: null,
      n: 0,
      ci_lower: null,
      ci_upper: null,
      shared_variance_percent: null,
      effective_size: null,
      note: '变量不存在于数据集中。',
    };
  }

  const { method, reason } = chooseCorrelationMethod(left, right);
  const selection = completeCases(dataset, [leftName, rightName]);
  const n = selection.n;

  if (n < 4) {
    return {
      left: leftName,
      right: rightName,
      method,
      method_reason: reason,
      r: null,
      p_value: null,
      n,
      ci_lower: null,
      ci_upper: null,
      shared_variance_percent: null,
      effective_size: null,
      note: `有效样本 n = ${n}，不足以估计相关系数（至少需要 4 例）。`,
    };
  }

  const x = selection.columns[0]!;
  const y = selection.columns[1]!;
  const r = method === 'pearson' ? pearsonCorrelation(x, y) : spearmanCorrelation(x, y);

  if (!Number.isFinite(r)) {
    return {
      left: leftName,
      right: rightName,
      method,
      method_reason: reason,
      r: null,
      p_value: null,
      n,
      ci_lower: null,
      ci_upper: null,
      shared_variance_percent: null,
      effective_size: null,
      note: '至少一个变量在该子样本中无变异，相关系数无法计算。',
    };
  }

  const clamped = Math.max(-0.999999999, Math.min(0.999999999, r));
  const t = clamped * Math.sqrt((n - 2) / (1 - clamped * clamped));
  const pValue = studentTTwoTailedP(t, n - 2);

  let ciLower: number | null = null;
  let ciUpper: number | null = null;
  if (method === 'pearson' && n > 3) {
    const confidence = options.confidence ?? 0.95;
    const z = normalQuantile(1 - (1 - confidence) / 2);
    const fisher = Math.atanh(clamped);
    const standardError = 1 / Math.sqrt(n - 3);
    ciLower = roundTo(Math.tanh(fisher - z * standardError), 4);
    ciUpper = roundTo(Math.tanh(fisher + z * standardError), 4);
  }

  return {
    left: leftName,
    right: rightName,
    method,
    method_reason: reason,
    r: roundTo(clamped, 4),
    p_value: roundTo(pValue, 6),
    n,
    ci_lower: ciLower,
    ci_upper: ciUpper,
    shared_variance_percent: roundTo(clamped * clamped * 100, 2),
    effective_size: classifyCorrelation(clamped),
    note:
      method === 'spearman'
        ? 'Spearman 相关系数的置信区间无分布无关估计，故不报告区间估计。'
        : '置信区间基于 Fisher z 变换。',
  };
}

/* ------------------------------------------------------------------ */
/* Correlation matrix                                                 */
/* ------------------------------------------------------------------ */

export interface CorrelationMatrixResult {
  variables: string[];
  labels: string[];
  /** r values; matrix[i][j] is the correlation between variables[i] and [j]. */
  matrix: (number | null)[][];
  /** Two-tailed p values, same layout. */
  p_values: (number | null)[][];
  /** Pairwise n, same layout. */
  n: (number | null)[][];
  /** Method used for each cell. */
  methods: CorrelationMethod[][];
  pairs: CorrelationPair[];
  /** True when at least one pair used Spearman. */
  mixed_methods: boolean;
  note: string;
}

export function correlationMatrixWithTests(
  dataset: Dataset,
  variableNames: string[],
): CorrelationMatrixResult {
  const names = variableNames.filter((name) => dataset.by_name.has(name));
  const size = names.length;

  const matrix: (number | null)[][] = Array.from({ length: size }, () => new Array(size).fill(null));
  const pValues: (number | null)[][] = Array.from({ length: size }, () => new Array(size).fill(null));
  const counts: (number | null)[][] = Array.from({ length: size }, () => new Array(size).fill(null));
  const methods: CorrelationMethod[][] = Array.from({ length: size }, () =>
    new Array<CorrelationMethod>(size).fill('pearson'),
  );
  const pairs: CorrelationPair[] = [];
  let mixed = false;

  for (let i = 0; i < size; i += 1) {
    matrix[i]![i] = 1;
    pValues[i]![i] = 0;
    const variable = dataset.by_name.get(names[i]!)!;
    counts[i]![i] = variable.values.filter((value) => value !== null).length;
  }

  for (let i = 0; i < size; i += 1) {
    for (let j = i + 1; j < size; j += 1) {
      const pair = correlatePair(dataset, names[i]!, names[j]!);
      pairs.push(pair);
      matrix[i]![j] = pair.r;
      matrix[j]![i] = pair.r;
      pValues[i]![j] = pair.p_value;
      pValues[j]![i] = pair.p_value;
      counts[i]![j] = pair.n;
      counts[j]![i] = pair.n;
      methods[i]![j] = pair.method;
      methods[j]![i] = pair.method;
      if (pair.method === 'spearman') mixed = true;
    }
  }

  return {
    variables: names,
    labels: names.map((name) => dataset.by_name.get(name)?.label ?? name),
    matrix,
    p_values: pValues,
    n: counts,
    methods,
    pairs,
    mixed_methods: mixed,
    note:
      '相关系数为成对删除（pairwise）计算，因此每个单元格的 n 可能不同；' +
      (mixed
        ? '由于存在有序分类变量，部分变量对使用 Spearman 等级相关，矩阵中不同单元格的系数类型不完全一致，解读时请注意。'
        : '所有变量对均使用 Pearson 积矩相关。') +
      ' 相关不等于因果。',
  };
}

/* ------------------------------------------------------------------ */
/* Standardised mean difference                                       */
/* ------------------------------------------------------------------ */

export interface MeanDifference {
  group_a: string;
  group_b: string;
  mean_a: number;
  mean_b: number;
  mean_difference: number;
  /** Cohen's d using the pooled standard deviation. */
  cohens_d: number | null;
  /** Hedges' g, the small-sample bias-corrected d. */
  hedges_g: number | null;
  /** 95% CI for the mean difference. */
  ci_lower: number | null;
  ci_upper: number | null;
  effect_size: EffectMagnitude | null;
  interpretation: string;
}

export function meanDifference(
  groupA: number[],
  groupB: number[],
  labels: { a: string; b: string },
  options: { confidence?: number } = {},
): MeanDifference {
  const nA = groupA.length;
  const nB = groupB.length;
  const meanA = nA > 0 ? groupA.reduce((sum, value) => sum + value, 0) / nA : Number.NaN;
  const meanB = nB > 0 ? groupB.reduce((sum, value) => sum + value, 0) / nB : Number.NaN;
  const difference = meanA - meanB;

  const varianceA = nA > 1 ? groupA.reduce((sum, value) => sum + (value - meanA) ** 2, 0) / (nA - 1) : 0;
  const varianceB = nB > 1 ? groupB.reduce((sum, value) => sum + (value - meanB) ** 2, 0) / (nB - 1) : 0;

  let cohensD: number | null = null;
  let hedgesG: number | null = null;
  if (nA > 1 && nB > 1) {
    const pooledVariance = ((nA - 1) * varianceA + (nB - 1) * varianceB) / (nA + nB - 2);
    if (pooledVariance > 0) {
      cohensD = difference / Math.sqrt(pooledVariance);
      const correction = 1 - 3 / (4 * (nA + nB) - 9);
      hedgesG = cohensD * correction;
    }
  }

  let ciLower: number | null = null;
  let ciUpper: number | null = null;
  if (nA > 1 && nB > 1) {
    const confidence = options.confidence ?? 0.95;
    const pooledVariance = ((nA - 1) * varianceA + (nB - 1) * varianceB) / (nA + nB - 2);
    const standardError = Math.sqrt(pooledVariance * (1 / nA + 1 / nB));
    const critical = studentTQuantile(1 - (1 - confidence) / 2, nA + nB - 2);
    ciLower = roundTo(difference - critical * standardError, 4);
    ciUpper = roundTo(difference + critical * standardError, 4);
  }

  return {
    group_a: labels.a,
    group_b: labels.b,
    mean_a: roundTo(meanA, 4),
    mean_b: roundTo(meanB, 4),
    mean_difference: roundTo(difference, 4),
    cohens_d: cohensD === null ? null : roundTo(cohensD, 4),
    hedges_g: hedgesG === null ? null : roundTo(hedgesG, 4),
    ci_lower: ciLower,
    ci_upper: ciUpper,
    effect_size: cohensD === null ? null : classifyCohensD(cohensD),
    interpretation:
      cohensD === null
        ? '组内变异为 0 或样本不足，无法计算标准化均值差。'
        : `均值差 ${roundTo(difference, 3)}，${classifyCohensD(cohensD).text}；` +
          `95% CI [${ciLower ?? 'NA'}, ${ciUpper ?? 'NA'}]。` +
          '注意：均值差与效应量描述的是样本差异，不代表干预效果。',
  };
}
