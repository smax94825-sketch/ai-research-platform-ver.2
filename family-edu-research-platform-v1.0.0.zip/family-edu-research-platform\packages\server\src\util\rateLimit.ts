/**
 * In-memory rate limiter.
 *
 * Used to blunt credential-stuffing against the login endpoint. Deliberately
 * simple (fixed window, per-process): it is a defence-in-depth measure, not a
 * distributed quota system, and it fails open on internal errors so it can
 * never lock a researcher out because of a bug in the limiter itself.
 */

import type { NextFunction, Request, RequestHandler, Response } from 'express';
import { ApiError } from './errors.js';

export interface RateLimitOptions {
  windowMs: number;
  max: number;
  /** Build the bucket key, e.g. `email + ip`. */
  keyFn: (req: Request) => string;
  message?: string;
}

interface Bucket {
  count: number;
  resetAt: number;
}

export interface RateLimiter {
  middleware: RequestHandler;
  /** Clear a bucket (called after a successful login). */
  reset: (key: string) => void;
  /** Number of live buckets — exposed for tests. */
  size: () => number;
}

export function createRateLimiter(options: RateLimitOptions): RateLimiter {
  const buckets = new Map<string, Bucket>();

  function sweep(now: number): void {
    for (const [key, bucket] of buckets) {
      if (bucket.resetAt <= now) buckets.delete(key);
    }
  }

  const middleware: RequestHandler = (req: Request, _res: Response, next: NextFunction) => {
    try {
      const now = Date.now();
      // Opportunistic cleanup keeps memory bounded without a timer.
      if (buckets.size > 1000) sweep(now);

      const key = options.keyFn(req);
      const bucket = buckets.get(key);

      if (!bucket || bucket.resetAt <= now) {
        buckets.set(key, { count: 1, resetAt: now + options.windowMs });
        next();
        return;
      }
      if (bucket.count >= options.max) {
        const retryAfter = Math.ceil((bucket.resetAt - now) / 1000);
        next(
          new ApiError(
            'RATE_LIMITED',
            options.message ?? `尝试过于频繁，请在 ${retryAfter} 秒后重试。`,
            { retry_after_seconds: retryAfter },
          ),
        );
        return;
      }
      bucket.count += 1;
      next();
    } catch {
      // Fail open: a limiter bug must not deny legitimate access.
      next();
    }
  };

  return {
    middleware,
    reset: (key: string) => {
      buckets.delete(key);
    },
    size: () => buckets.size,
  };
}

/** Client address used for rate-limit bucketing. */
export function clientKey(req: Request): string {
  return req.ip ?? req.socket.remoteAddress ?? 'unknown';
}
