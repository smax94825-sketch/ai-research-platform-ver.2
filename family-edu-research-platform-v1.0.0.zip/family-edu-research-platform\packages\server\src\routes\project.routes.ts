/**
 * Research project routes.
 *
 * GET    /api/projects                        — list (search / status / paging)
 * POST   /api/projects                        — create (blank or from a template)
 * POST   /api/projects/from-template          — one-click default research design
 * GET    /api/projects/:projectId             — detail
 * PATCH  /api/projects/:projectId             — update
 * DELETE /api/projects/:projectId             — delete (cascades)
 * GET    /api/projects/:projectId/questionnaires
 * POST   /api/projects/:projectId/questionnaires
 * GET    /api/projects/:projectId/dashboard
 */

import { Router } from 'express';
import type { Hypothesis, ProjectSettings, ProjectStatus, QuotaConfig } from '@ferp/shared';
import { buildFamilyEduV4Template } from '@ferp/shared';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import {
  createProject,
  createProjectFromDefaultTemplate,
  deleteProject,
  listProjects,
  requireProject,
  updateProject,
} from '../services/project.service.js';
import {
  createEmptyQuestionnaire,
  createQuestionnaireFromTemplate,
  listQuestionnaires,
} from '../services/questionnaire.service.js';
import { getDashboardOverview } from '../services/dashboard.service.js';
import { ApiError, asyncHandler } from '../util/errors.js';

export interface ProjectRouterContext {
  db: Db;
  config: Config;
}

function asStringArray(value: unknown): string[] | undefined {
  if (!Array.isArray(value)) return undefined;
  return value.filter((v): v is string => typeof v === 'string');
}

function asHypotheses(value: unknown): Hypothesis[] | undefined {
  if (!Array.isArray(value)) return undefined;
  const out: Hypothesis[] = [];
  for (const item of value) {
    if (!item || typeof item !== 'object') continue;
    const record = item as Record<string, unknown>;
    if (typeof record['code'] !== 'string' || typeof record['statement'] !== 'string') continue;
    out.push({
      code: record['code'],
      statement: record['statement'],
      status:
        record['status'] === 'supported' ||
        record['status'] === 'not_supported' ||
        record['status'] === 'inconclusive' ||
        record['status'] === 'untested'
          ? record['status']
          : 'untested',
    });
  }
  return out;
}

export function createProjectRouter(ctx: ProjectRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /* ---------------------------------------------------------------- */
  router.get(
    '/',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const status = typeof req.query['status'] === 'string' ? (req.query['status'] as ProjectStatus) : undefined;
      const search = typeof req.query['search'] === 'string' ? req.query['search'] : undefined;
      const limit = req.query['limit'] !== undefined ? Number(req.query['limit']) : undefined;
      const offset = req.query['offset'] !== undefined ? Number(req.query['offset']) : undefined;

      const result = listProjects(ctx.db, researcher.id, { status, search, limit, offset });
      res.json({ data: result });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.post(
    '/',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const body = (req.body ?? {}) as Record<string, unknown>;

      const result = createProject(ctx.db, researcher.id, {
        title: typeof body['title'] === 'string' ? body['title'] : '',
        description: typeof body['description'] === 'string' ? body['description'] : null,
        background: typeof body['background'] === 'string' ? body['background'] : null,
        objectives: typeof body['objectives'] === 'string' ? body['objectives'] : null,
        research_questions: asStringArray(body['research_questions']),
        hypotheses: asHypotheses(body['hypotheses']),
        target_population: typeof body['target_population'] === 'string' ? body['target_population'] : null,
        target_sample_size:
          body['target_sample_size'] === undefined || body['target_sample_size'] === null
            ? null
            : Number(body['target_sample_size']),
        start_date: typeof body['start_date'] === 'string' ? body['start_date'] : null,
        end_date: typeof body['end_date'] === 'string' ? body['end_date'] : null,
        template: typeof body['template'] === 'string' ? body['template'] : null,
      });

      res.status(201).json({ data: result });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.post(
    '/from-template',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const result = createProjectFromDefaultTemplate(ctx.db, researcher.id);
      res.status(201).json({ data: result });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.get(
    '/:projectId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const project = requireProject(ctx.db, req.params['projectId']!, researcher.id);
      const questionnaires = listQuestionnaires(ctx.db, project.id);
      res.json({ data: { project, questionnaires } });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.patch(
    '/:projectId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const projectId = req.params['projectId']!;

      const patch: Parameters<typeof updateProject>[3] = {};
      if (typeof body['title'] === 'string') patch.title = body['title'];
      if ('description' in body) patch.description = (body['description'] as string | null) ?? null;
      if ('background' in body) patch.background = (body['background'] as string | null) ?? null;
      if ('objectives' in body) patch.objectives = (body['objectives'] as string | null) ?? null;
      if ('research_questions' in body) {
        const parsed = asStringArray(body['research_questions']);
        if (parsed === undefined) throw ApiError.validation('research_questions 必须是字符串数组。');
        patch.research_questions = parsed;
      }
      if ('hypotheses' in body) {
        const parsed = asHypotheses(body['hypotheses']);
        if (parsed === undefined) throw ApiError.validation('hypotheses 必须是对象数组。');
        patch.hypotheses = parsed;
      }
      if ('target_population' in body) {
        patch.target_population = (body['target_population'] as string | null) ?? null;
      }
      if ('target_sample_size' in body) {
        patch.target_sample_size =
          body['target_sample_size'] === null ? null : Number(body['target_sample_size']);
      }
      if ('start_date' in body) patch.start_date = (body['start_date'] as string | null) ?? null;
      if ('end_date' in body) patch.end_date = (body['end_date'] as string | null) ?? null;
      if (typeof body['status'] === 'string') patch.status = body['status'] as ProjectStatus;
      if ('quota_config' in body) patch.quota_config = (body['quota_config'] as QuotaConfig | null) ?? null;
      if ('settings' in body) patch.settings = (body['settings'] as ProjectSettings | null) ?? null;

      const project = updateProject(ctx.db, projectId, researcher.id, patch);
      res.json({ data: { project } });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.delete(
    '/:projectId',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const result = deleteProject(ctx.db, req.params['projectId']!, researcher.id);
      res.json({ data: result });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.get(
    '/:projectId/questionnaires',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const project = requireProject(ctx.db, req.params['projectId']!, researcher.id);
      res.json({ data: listQuestionnaires(ctx.db, project.id) });
    }),
  );

  router.post(
    '/:projectId/questionnaires',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const project = requireProject(ctx.db, req.params['projectId']!, researcher.id);
      const body = (req.body ?? {}) as Record<string, unknown>;
      const template = typeof body['template'] === 'string' ? body['template'] : 'blank';

      if (template !== 'blank') {
        const questionnaire = createQuestionnaireFromTemplate(ctx.db, project.id, template, {
          title: typeof body['title'] === 'string' ? body['title'] : undefined,
        });
        res.status(201).json({ data: questionnaire });
        return;
      }

      if (typeof body['title'] !== 'string' || body['title'].trim() === '') {
        throw ApiError.validation('新建空白问卷需要提供标题。');
      }
      const questionnaire = createEmptyQuestionnaire(ctx.db, project.id, {
        title: body['title'],
        description: typeof body['description'] === 'string' ? body['description'] : null,
      });
      res.status(201).json({ data: questionnaire });
    }),
  );

  /* ---------------------------------------------------------------- */
  router.get(
    '/:projectId/dashboard',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const project = requireProject(ctx.db, req.params['projectId']!, researcher.id);
      res.json({ data: getDashboardOverview(ctx.db, researcher.id, { project }) });
    }),
  );

  return router;
}

/** Available research templates, surfaced to the "新建研究" UI. */
export function createTemplateRouter(_ctx: ProjectRouterContext): Router {
  const router = Router();
  router.use(requireAuth(_ctx));

  router.get(
    '/',
    asyncHandler((_req, res) => {
      const template = buildFamilyEduV4Template();
      res.json({
        data: [
          {
            key: template.key,
            version: template.version,
            title: template.title,
            description: template.description,
            question_count: template.questions.length,
            section_count: template.sections.length,
            default_project: {
              title: template.project.title,
              description: template.project.description,
              target_population: template.project.target_population,
              target_sample_size: template.project.target_sample_size,
              research_question_count: template.project.research_questions.length,
              hypothesis_count: template.project.hypotheses.length,
            },
          },
        ],
      });
    }),
  );

  return router;
}
