import type { ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Layout } from './components/Layout';
import { LoadingBlock } from './components/ui';
import { useAuth } from './lib/auth';
import { BuilderEntryPage } from './pages/BuilderEntryPage';
import { BuilderPage } from './pages/BuilderPage';
import { DashboardPage } from './pages/DashboardPage';
import { LoginPage } from './pages/LoginPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { ProjectCreatePage } from './pages/ProjectCreatePage';
import { ProjectDetailPage } from './pages/ProjectDetailPage';
import { ProjectsPage } from './pages/ProjectsPage';
import { QualityPage } from './pages/QualityPage';
import { RegisterPage } from './pages/RegisterPage';
import { RespondentDetailPage } from './pages/RespondentDetailPage';
import { SamplesPage } from './pages/SamplesPage';
import { SettingsPage } from './pages/SettingsPage';
import { SourcesPage } from './pages/SourcesPage';
import { SurveyPage } from './pages/SurveyPage';
import { SurveyFlatPage } from './pages/SurveyFlatPage';
import { AiAssistantPage } from './pages/ai/AiAssistantPage';
import { AnalysisHomePage } from './pages/analysis/AnalysisHomePage';
import { ComparisonPage } from './pages/analysis/ComparisonPage';
import { CorrelationPage } from './pages/analysis/CorrelationPage';
import { DescriptivePage } from './pages/analysis/DescriptivePage';
import { HypothesisPage } from './pages/analysis/HypothesisPage';
import { RegressionPage } from './pages/analysis/RegressionPage';
import { ReliabilityPage } from './pages/analysis/ReliabilityPage';
import { ValidityPage } from './pages/analysis/ValidityPage';
import { CompetitionPage } from './pages/competition/CompetitionPage';
import { ExportPage } from './pages/report/ExportPage';
import { ReportPage } from './pages/report/ReportPage';

/** Gate that waits for the session bootstrap before deciding. */
function RequireAuth({ children }: { children: ReactNode }): ReactNode {
  const { status } = useAuth();
  const location = useLocation();

  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <LoadingBlock label="正在校验登录状态…" />
      </div>
    );
  }
  if (status === 'anonymous') {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  return <>{children}</>;
}

/** Send already-authenticated users away from the login/register screens. */
function RequireAnonymous({ children }: { children: ReactNode }): ReactNode {
  const { status } = useAuth();
  if (status === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <LoadingBlock label="正在校验登录状态…" />
      </div>
    );
  }
  if (status === 'authenticated') return <Navigate to="/" replace />;
  return <>{children}</>;
}

export function App(): ReactNode {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <RequireAnonymous>
            <LoginPage />
          </RequireAnonymous>
        }
      />
      <Route
        path="/register"
        element={
          <RequireAnonymous>
            <RegisterPage />
          </RequireAnonymous>
        }
      />

      {/*
        Public respondent survey. Deliberately OUTSIDE RequireAuth: a respondent
        has no account, and the session is carried by the share token in the URL
        plus a per-respondent session token in localStorage.
      */}
      <Route path="/research/:shareToken" element={<SurveyPage />} />
      {/*
        Alternative PUBLIC respondent layout for the same instrument: the whole
        questionnaire on one page, submitted once at the bottom. Same share token,
        same session token, same collection pipeline — only the layout differs.
      */}
      <Route path="/research/:shareToken/all" element={<SurveyFlatPage />} />

      <Route
        element={
          <RequireAuth>
            <Layout />
          </RequireAuth>
        }
      >
        <Route path="/" element={<DashboardPage />} />
        <Route path="/projects" element={<ProjectsPage />} />
        <Route path="/projects/new" element={<ProjectCreatePage />} />
        <Route path="/projects/:projectId" element={<ProjectDetailPage />} />
        <Route
          path="/projects/:projectId/questionnaires/:questionnaireId/builder"
          element={<BuilderPage />}
        />
        <Route path="/builder" element={<BuilderEntryPage />} />

        {/* PHASE 3 — data collection */}
        <Route path="/collection/responses" element={<SamplesPage mode="responses" />} />
        <Route path="/collection/samples" element={<SamplesPage mode="samples" />} />
        <Route path="/collection/samples/:respondentId" element={<RespondentDetailPage />} />
        <Route path="/collection/sources" element={<SourcesPage />} />
        <Route path="/collection/quality" element={<QualityPage />} />

        {/* PHASE 6 — statistical analysis console */}
        <Route path="/analysis" element={<AnalysisHomePage />} />
        <Route path="/analysis/descriptive" element={<DescriptivePage />} />
        <Route path="/analysis/reliability" element={<ReliabilityPage />} />
        <Route path="/analysis/validity" element={<ValidityPage />} />
        <Route path="/analysis/correlation" element={<CorrelationPage />} />
        <Route path="/analysis/regression" element={<RegressionPage />} />
        <Route path="/analysis/comparison" element={<ComparisonPage />} />
        <Route path="/analysis/hypotheses" element={<HypothesisPage />} />

        {/* PHASE 7/8/9 — AI assistant, report, export, competition mode */}
        <Route path="/ai" element={<AiAssistantPage />} />
        <Route path="/report" element={<ReportPage />} />
        <Route path="/export" element={<ExportPage />} />
        <Route path="/competition" element={<CompetitionPage />} />

        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
