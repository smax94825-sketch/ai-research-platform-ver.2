/**
 * Questionnaire Builder API tests (PHASE 2).
 *
 * Exercises the builder end to end: all ten question types, CRUD, ordering,
 * duplication, conditional logic, preview, codebook generation, publish and
 * version control.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { api, createProject, createTestContext, createTemplatedProject, registerResearcher, type TestContext } from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

/* ------------------------------------------------------------------ */
/* Payload builders for each supported question type                  */
/* ------------------------------------------------------------------ */

const choiceOptions = {
  choices: [
    { value: '1', label: '选项一', score: 1 },
    { value: '2', label: '选项二', score: 2 },
    { value: '3', label: '选项三', score: 3 },
  ],
};

const QUESTION_TYPE_PAYLOADS: Record<string, Record<string, unknown>> = {
  single: { question_text: '单选题测试', question_type: 'single', options: choiceOptions },
  multiple: { question_text: '多选题测试', question_type: 'multiple', options: choiceOptions },
  dropdown: { question_text: '下拉题测试', question_type: 'dropdown', options: choiceOptions },
  likert: {
    question_text: '李克特题测试',
    question_type: 'likert',
    options: {
      choices: [
        { value: '1', label: '非常不同意', score: 1 },
        { value: '2', label: '不同意', score: 2 },
        { value: '3', label: '一般', score: 3 },
        { value: '4', label: '同意', score: 4 },
        { value: '5', label: '非常同意', score: 5 },
      ],
      scaleMin: 1,
      scaleMax: 5,
    },
  },
  matrix: {
    question_text: '矩阵题测试',
    question_type: 'matrix',
    options: {
      matrix: {
        rows: [
          { value: '1', label: '行一' },
          { value: '2', label: '行二' },
        ],
        columns: [
          { value: '1', label: '很低', score: 1 },
          { value: '2', label: '较低', score: 2 },
          { value: '3', label: '一般', score: 3 },
          { value: '4', label: '较高', score: 4 },
          { value: '5', label: '很高', score: 5 },
        ],
      },
    },
  },
  ranking: { question_text: '排序题测试', question_type: 'ranking', options: { ...choiceOptions, rankCount: 3 } },
  text: { question_text: '文本题测试', question_type: 'text', options: { maxLength: 100 } },
  textarea: { question_text: '多行文本测试', question_type: 'textarea', options: { maxLength: 500 } },
  number: { question_text: '数字题测试', question_type: 'number', options: { min: 0, max: 100, step: 1 } },
  date: { question_text: '日期题测试', question_type: 'date', options: {} },
  knowledge_test: {
    question_text: '知识题测试：判断下列说法是否正确。',
    question_type: 'knowledge_test',
    options: {
      choices: [
        { value: '1', label: '正确', score: 1, isCorrect: true },
        { value: '2', label: '错误', score: 0 },
        { value: '3', label: '不清楚', score: 0 },
      ],
    },
    scoring_rule: {
      type: 'knowledge',
      correctScore: 1,
      incorrectScore: 0,
      unknownScore: 0,
      unknownValue: '3',
      maxScore: 1,
    },
  },
  page_break: { question_text: '第一部分', question_type: 'page_break', options: {} },
};

/* ------------------------------------------------------------------ */

describe('构建器状态', () => {
  test('模板项目返回 58 道题与可编辑状态', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token);

    const response = await api<{
      questionnaire: { version: string; status: string };
      questions: unknown[];
      suggested_next_code: string;
      editable: boolean;
      lock_reason: string | null;
    }>(ctx, 'GET', `/api/questionnaires/${project.questionnaireId}/builder`, {
      token: researcher.token,
    });

    assert.equal(response.status, 200);
    assert.equal(response.data.questions.length, 58);
    assert.equal(response.data.suggested_next_code, 'Q59');
    assert.equal(response.data.editable, true);
    assert.equal(response.data.lock_reason, null);
  });

  test('题目按 sort_order 升序返回，且序号连续', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token);
    const response = await api<{ questions: { sort_order: number; question_code: string }[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${project.questionnaireId}/builder`,
      { token: researcher.token },
    );
    const orders = response.data.questions.map((q) => q.sort_order);
    assert.deepEqual(orders, Array.from({ length: 58 }, (_, i) => i + 1));
    assert.equal(response.data.questions[0]?.question_code, 'Q1');
    assert.equal(response.data.questions[57]?.question_code, 'Q58');
  });
});

describe('题目类型支持', () => {
  test('平台支持全部十种核心题型', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '题型测试' });
    const questionnaire = await api<{ id: string }>(
      ctx,
      'POST',
      `/api/projects/${project.id}/questionnaires`,
      { token: researcher.token, body: { title: '题型问卷' } },
    );
    const qid = questionnaire.data.id;

    for (const [type, payload] of Object.entries(QUESTION_TYPE_PAYLOADS)) {
      const created = await api<{ id: string; question_type: string; question_code: string }>(
        ctx,
        'POST',
        `/api/questionnaires/${qid}/questions`,
        { token: researcher.token, body: payload },
      );
      assert.equal(created.status, 201, `题型 ${type} 创建失败: ${JSON.stringify(created.error)}`);
      assert.equal(created.data.question_type, type);
    }

    const builder = await api<{ questions: unknown[] }>(ctx, 'GET', `/api/questionnaires/${qid}/builder`, {
      token: researcher.token,
    });
    assert.equal(builder.data.questions.length, Object.keys(QUESTION_TYPE_PAYLOADS).length);
  });

  test('自动生成连续的题号', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '题号生成' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token: researcher.token,
      body: { title: '题号问卷' },
    });

    const codes: string[] = [];
    for (let i = 0; i < 3; i += 1) {
      const created = await api<{ question_code: string }>(
        ctx,
        'POST',
        `/api/questionnaires/${questionnaire.data.id}/questions`,
        { token: researcher.token, body: QUESTION_TYPE_PAYLOADS['text'] },
      );
      codes.push(created.data.question_code);
    }
    assert.deepEqual(codes, ['Q1', 'Q2', 'Q3']);
  });

  test('拒绝重复题号', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '题号冲突' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token: researcher.token,
      body: { title: '冲突问卷' },
    });

    await api(ctx, 'POST', `/api/questionnaires/${questionnaire.data.id}/questions`, {
      token: researcher.token,
      body: { ...QUESTION_TYPE_PAYLOADS['text'], question_code: 'Q1' },
    });
    const duplicate = await api(ctx, 'POST', `/api/questionnaires/${questionnaire.data.id}/questions`, {
      token: researcher.token,
      body: { ...QUESTION_TYPE_PAYLOADS['text'], question_code: 'Q1' },
    });
    assert.equal(duplicate.status, 409);
  });
});

describe('题目定义校验', () => {
  let qid: string;
  let token: string;

  before(async () => {
    const researcher = await registerResearcher(ctx);
    token = researcher.token;
    const project = await createProject(ctx, token, { title: '校验测试' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '校验问卷' },
    });
    qid = questionnaire.data.id;
  });

  test('拒绝未知题型', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { question_text: 'x', question_type: 'teleport' },
    });
    assert.equal(response.status, 400);
  });

  test('拒绝没有选项的选择题', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { question_text: 'x', question_type: 'single', options: { choices: [] } },
    });
    assert.equal(response.status, 400);
  });

  test('拒绝缺少行列定义的矩阵题', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { question_text: 'x', question_type: 'matrix', options: {} },
    });
    assert.equal(response.status, 400);
    assert.ok(
      (response.error?.details as { field: string }[]).some((d) => d.field.includes('matrix')),
    );
  });

  test('拒绝没有正确答案的知识测试题', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: {
        question_text: 'x',
        question_type: 'knowledge_test',
        options: { choices: [{ value: '1', label: '正确' }, { value: '2', label: '错误' }] },
      },
    });
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /正确答案/);
  });

  test('拒绝重复的选项代码', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: {
        question_text: 'x',
        question_type: 'single',
        options: { choices: [{ value: '1', label: 'A' }, { value: '1', label: 'B' }] },
      },
    });
    assert.equal(response.status, 400);
  });

  test('拒绝非法的 SPSS 变量名', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { ...QUESTION_TYPE_PAYLOADS['text'], variable_name: '2bad-name' },
    });
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /变量名/);
  });

  test('拒绝缺少比较值的逻辑条件', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: {
        ...QUESTION_TYPE_PAYLOADS['single'],
        logic: {
          rules: [
            { id: 'r1', conditions: [{ questionCode: 'Q1', operator: 'eq' }], action: { type: 'hide' } },
          ],
        },
      },
    });
    assert.equal(response.status, 400);
  });

  test('分类编码缺少选项映射时拒绝（防止静默丢数据）', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: {
        ...QUESTION_TYPE_PAYLOADS['single'],
        scoring_rule: { type: 'categorical', codes: { '1': 1 } },
      },
    });
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /选项 2/);
  });
});

describe('题目编辑', () => {
  let qid: string;
  let token: string;
  let questionId: string;

  before(async () => {
    const researcher = await registerResearcher(ctx);
    token = researcher.token;
    const project = await createProject(ctx, token, { title: '编辑测试' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '编辑问卷' },
    });
    qid = questionnaire.data.id;
    const created = await api<{ id: string }>(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: QUESTION_TYPE_PAYLOADS['likert'],
    });
    questionId = created.data.id;
  });

  test('可修改题干、必答、变量名、维度与计分方式', async () => {
    const response = await api<{
      question_text: string;
      required: boolean;
      variable_name: string;
      dimension: string;
      scoring_rule: { type: string };
      help_text: string;
    }>(ctx, 'PATCH', `/api/questions/${questionId}`, {
      token,
      body: {
        question_text: '修改后的题干',
        required: false,
        variable_name: 'FSE1',
        dimension: '家庭教育自我效能',
        scoring_rule: { type: 'mean', min: 1, max: 5 },
        help_text: '请根据实际情况作答',
      },
    });

    assert.equal(response.status, 200);
    assert.equal(response.data.question_text, '修改后的题干');
    assert.equal(response.data.required, false);
    assert.equal(response.data.variable_name, 'FSE1');
    assert.equal(response.data.dimension, '家庭教育自我效能');
    assert.equal(response.data.scoring_rule.type, 'mean');
    assert.equal(response.data.help_text, '请根据实际情况作答');
  });

  test('修改题号到已占用的值会被拒绝', async () => {
    await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { ...QUESTION_TYPE_PAYLOADS['text'], question_code: 'QX' },
    });
    const response = await api(ctx, 'PATCH', `/api/questions/${questionId}`, {
      token,
      body: { question_code: 'QX' },
    });
    assert.equal(response.status, 409);
  });

  test('可以设置条件跳转逻辑', async () => {
    const response = await api<{ logic: { rules: unknown[] } }>(ctx, 'PATCH', `/api/questions/${questionId}`, {
      token,
      body: {
        question_code: 'QL1',
        logic: {
          rules: [
            {
              id: 'rule-1',
              match: 'all',
              conditions: [{ questionCode: 'QX', operator: 'eq', value: '1' }],
              action: { type: 'jump_to', target: 'END' },
              note: '选择第一个选项则直接结束',
            },
          ],
        },
      },
    });
    assert.equal(response.status, 200);
    assert.equal(response.data.logic.rules.length, 1);
  });

  test('可以清空逻辑规则', async () => {
    const response = await api<{ logic: unknown }>(ctx, 'PATCH', `/api/questions/${questionId}`, {
      token,
      body: { logic: null },
    });
    assert.equal(response.status, 200);
    assert.equal(response.data.logic, null);
  });

  test('更新不存在的题目返回 404', async () => {
    const response = await api(ctx, 'PATCH', '/api/questions/00000000-0000-0000-0000-000000000000', {
      token,
      body: { question_text: 'x' },
    });
    assert.equal(response.status, 404);
  });
});

describe('题目复制与删除', () => {
  test('复制题目插入到原题之后，并生成新题号与变量名', async () => {
    const researcher = await registerResearcher(ctx);
    const token = researcher.token;
    const project = await createProject(ctx, token, { title: '复制测试' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '复制问卷' },
    });
    const qid = questionnaire.data.id;

    const first = await api<{ id: string; question_code: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${qid}/questions`,
      { token, body: { ...QUESTION_TYPE_PAYLOADS['likert'], variable_name: 'FSE1' } },
    );
    const second = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { ...QUESTION_TYPE_PAYLOADS['text'], question_code: 'Q2' },
    });
    assert.equal(second.status, 201);

    const copy = await api<{ question_code: string; variable_name: string; sort_order: number; question_text: string }>(
      ctx,
      'POST',
      `/api/questions/${first.data.id}/duplicate`,
      { token },
    );

    assert.equal(copy.status, 201);
    assert.equal(copy.data.sort_order, 2, '副本应紧随原题');
    assert.equal(copy.data.variable_name, 'FSE1_C', '变量名必须区分，否则会在统计中合并');
    assert.match(copy.data.question_text, /副本/);
    assert.notEqual(copy.data.question_code, first.data.question_code);

    // 原 Q2 应被顺延为第 3 题。
    const builder = await api<{ questions: { question_code: string; sort_order: number }[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${qid}/builder`,
      { token },
    );
    const q2 = builder.data.questions.find((q) => q.question_code === 'Q2');
    assert.equal(q2?.sort_order, 3);
  });

  test('复制时会剔除副本中指向原题的自我引用逻辑', async () => {
    const researcher = await registerResearcher(ctx);
    const token = researcher.token;
    const project = await createProject(ctx, token, { title: '复制逻辑' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '逻辑复制问卷' },
    });
    const qid = questionnaire.data.id;

    const created = await api<{ id: string; question_code: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${qid}/questions`,
      {
        token,
        body: {
          ...QUESTION_TYPE_PAYLOADS['single'],
          question_code: 'QA',
          logic: {
            rules: [
              {
                id: 'self-ref',
                conditions: [{ questionCode: 'QA', operator: 'eq', value: '1' }],
                action: { type: 'jump_to', target: 'QA' },
              },
            ],
          },
        },
      },
    );
    assert.equal(created.status, 201);

    const copy = await api<{ logic: { rules: unknown[] } | null }>(
      ctx,
      'POST',
      `/api/questions/${created.data.id}/duplicate`,
      { token },
    );
    assert.equal(copy.status, 201);
    assert.equal(copy.data.logic, null, '副本不应保留指向自身的逻辑');
  });

  test('删除题目并报告其他题目中悬空的逻辑引用', async () => {
    const researcher = await registerResearcher(ctx);
    const token = researcher.token;
    const project = await createProject(ctx, token, { title: '删除测试' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '删除问卷' },
    });
    const qid = questionnaire.data.id;

    const target = await api<{ id: string }>(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: { ...QUESTION_TYPE_PAYLOADS['single'], question_code: 'QT' },
    });
    await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token,
      body: {
        ...QUESTION_TYPE_PAYLOADS['text'],
        question_code: 'QP',
        logic: {
          rules: [
            {
              id: 'points-at-qt',
              conditions: [{ questionCode: 'QT', operator: 'eq', value: '1' }],
              action: { type: 'jump_to', target: 'END' },
            },
          ],
        },
      },
    });

    const deleted = await api<{ deleted: boolean; dangling_logic: { question_code: string }[] }>(
      ctx,
      'DELETE',
      `/api/questions/${target.data.id}`,
      { token },
    );

    assert.equal(deleted.status, 200);
    assert.equal(deleted.data.deleted, true);
    assert.equal(deleted.data.dangling_logic.length, 1);
    assert.equal(deleted.data.dangling_logic[0]?.question_code, 'QP');
  });

  test('删除后题目序号重新连续', async () => {
    const researcher = await registerResearcher(ctx);
    const token = researcher.token;
    const project = await createProject(ctx, token, { title: '重排测试' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '重排问卷' },
    });
    const qid = questionnaire.data.id;

    const ids: string[] = [];
    for (let i = 0; i < 4; i += 1) {
      const created = await api<{ id: string }>(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
        token,
        body: { ...QUESTION_TYPE_PAYLOADS['text'], question_code: `QR${i}` },
      });
      ids.push(created.data.id);
    }

    await api(ctx, 'DELETE', `/api/questions/${ids[1]}`, { token });

    const builder = await api<{ questions: { sort_order: number }[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${qid}/builder`,
      { token },
    );
    assert.deepEqual(
      builder.data.questions.map((q) => q.sort_order),
      [1, 2, 3],
    );
  });
});

describe('题目排序', () => {
  let qid: string;
  let token: string;
  let ids: string[];

  before(async () => {
    const researcher = await registerResearcher(ctx);
    token = researcher.token;
    const project = await createProject(ctx, token, { title: '排序测试' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token,
      body: { title: '排序问卷' },
    });
    qid = questionnaire.data.id;
    ids = [];
    for (let i = 0; i < 3; i += 1) {
      const created = await api<{ id: string }>(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
        token,
        body: { ...QUESTION_TYPE_PAYLOADS['text'], question_code: `QS${i + 1}` },
      });
      ids.push(created.data.id);
    }
  });

  test('按给定顺序整体重排', async () => {
    const reversed = [ids[2]!, ids[1]!, ids[0]!];
    const response = await api<{ questions: { question_code: string }[]; warnings: string[] }>(
      ctx,
      'POST',
      `/api/questionnaires/${qid}/questions/reorder`,
      { token, body: { ordered_ids: reversed } },
    );

    assert.equal(response.status, 200);
    assert.deepEqual(
      response.data.questions.map((q) => q.question_code),
      ['QS3', 'QS2', 'QS1'],
    );
  });

  test('拒绝题目数量不匹配的排序请求', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions/reorder`, {
      token,
      body: { ordered_ids: [ids[0]!] },
    });
    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /完整且不重复/);
  });

  test('拒绝含重复 ID 的排序请求', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions/reorder`, {
      token,
      body: { ordered_ids: [ids[0]!, ids[0]!, ids[1]!] },
    });
    assert.equal(response.status, 400);
  });

  test('拒绝不属于该问卷的题目 ID', async () => {
    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/questions/reorder`, {
      token,
      body: { ordered_ids: [ids[0]!, ids[1]!, '00000000-0000-0000-0000-000000000000'] },
    });
    assert.equal(response.status, 400);
  });

  test('单题上移/下移（与当前顺序无关）', async () => {
    const before = await api<{ questions: { id: string; question_code: string }[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${qid}/builder`,
      { token },
    );
    const firstCode = before.data.questions[0]!.question_code;
    const secondCode = before.data.questions[1]!.question_code;
    const firstId = before.data.questions[0]!.id;

    const down = await api<{ question_code: string }[]>(ctx, 'POST', `/api/questions/${firstId}/move`, {
      token,
      body: { direction: 'down' },
    });
    assert.equal(down.status, 200);
    assert.equal(down.data[0]?.question_code, secondCode, '下移后原第一题应位于第二位');
    assert.equal(down.data[1]?.question_code, firstCode);

    const up = await api<{ question_code: string }[]>(ctx, 'POST', `/api/questions/${firstId}/move`, {
      token,
      body: { direction: 'up' },
    });
    assert.equal(up.data[0]?.question_code, firstCode, '上移后应回到第一位');
  });

  test('边界移动是安全的空操作', async () => {
    const builder = await api<{ questions: { id: string; question_code: string }[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${qid}/builder`,
      { token },
    );
    const first = builder.data.questions[0]!;
    const response = await api<{ question_code: string }[]>(ctx, 'POST', `/api/questions/${first.id}/move`, {
      token,
      body: { direction: 'up' },
    });
    assert.equal(response.status, 200);
  });
});

describe('逻辑视图与预览', () => {
  let qid: string;
  let token: string;

  before(async () => {
    const researcher = await registerResearcher(ctx);
    token = researcher.token;
    const project = await createTemplatedProject(ctx, token, '逻辑预览研究');
    qid = project.questionnaireId!;
  });

  test('GET /logic 返回模板中的跳转规则与可读描述', async () => {
    const response = await api<{
      rules: { question_code: string; description: string; action: { type: string } }[];
      issues: { severity: string }[];
    }>(ctx, 'GET', `/api/questionnaires/${qid}/logic`, { token });

    assert.equal(response.status, 200);
    const skipRule = response.data.rules.find((r) => r.question_code === 'Q39');
    assert.ok(skipRule, '应能读到 Q39 的跳转规则');
    assert.match(skipRule.description, /IF Q39/);
    assert.match(skipRule.description, /从未使用/);
    assert.match(skipRule.description, /Q41/);
    assert.equal(response.data.issues.filter((i) => i.severity === 'error').length, 0);
  });

  test('预览：选择"从未使用"后 Q40 不出现在作答路径中', async () => {
    const response = await api<{
      answered_path: string[];
      answered_count: number;
      visible_count: number;
      total_questions: number;
    }>(ctx, 'POST', `/api/questionnaires/${qid}/preview`, {
      token,
      body: { answers: { Q39: '1' } },
    });

    assert.equal(response.status, 200);
    assert.equal(response.data.total_questions, 58);
    assert.ok(!response.data.answered_path.includes('Q40'), 'Q40 应被跳过');
    assert.ok(response.data.answered_path.includes('Q39'));
    assert.ok(response.data.answered_path.includes('Q41'));
  });

  test('预览：使用过机构时 Q40 保留在路径中', async () => {
    const response = await api<{ answered_path: string[] }>(
      ctx,
      'POST',
      `/api/questionnaires/${qid}/preview`,
      { token, body: { answers: { Q39: '2' } } },
    );
    assert.ok(response.data.answered_path.includes('Q40'));
  });

  test('预览：从未听说过法律时 Q11 被隐藏', async () => {
    const response = await api<{ answered_path: string[]; visible: { question_code: string }[] }>(
      ctx,
      'POST',
      `/api/questionnaires/${qid}/preview`,
      { token, body: { answers: { Q10: '1' } } },
    );
    assert.ok(!response.data.visible.some((q) => q.question_code === 'Q11'));
  });

  test('预览：默认路径覆盖全部 58 题', async () => {
    const response = await api<{ answered_path: string[] }>(
      ctx,
      'POST',
      `/api/questionnaires/${qid}/preview`,
      { token, body: { answers: {} } },
    );
    assert.equal(response.data.answered_path.length, 58);
  });
});

describe('变量字典', () => {
  test('为模板问卷生成包含核心变量的字典', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '字典研究');

    const response = await api<{ dictionary: { variable_name: string; data_type: string }[]; version: string }>(
      ctx,
      'GET',
      `/api/questionnaires/${project.questionnaireId}/dictionary`,
      { token: researcher.token },
    );

    assert.equal(response.status, 200);
    assert.equal(response.data.version, 'V4.0');
    const names = response.data.dictionary.map((d) => d.variable_name);
    for (const required of ['FEI', 'FEK', 'LSK', 'LKA', 'ISC', 'FSE', 'FPB', 'FED', 'FIU', 'PSA', 'STI', 'DSD', 'WTP', 'UI', 'QN']) {
      assert.ok(names.includes(required), `变量字典缺少 ${required}`);
    }
  });

  test('支持 CSV 导出并带 BOM 以便 Excel 正确显示中文', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '字典 CSV 研究');

    const response = await fetch(
      `${ctx.baseUrl}/api/questionnaires/${project.questionnaireId}/dictionary?format=csv`,
      { headers: { authorization: `Bearer ${researcher.token}` } },
    );
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type') ?? '', /text\/csv/);

    // Check the raw bytes: WHATWG `Response.text()` strips a leading BOM, so a
    // string comparison would give a false negative here.
    const bytes = new Uint8Array(await response.arrayBuffer());
    assert.deepEqual(
      Array.from(bytes.slice(0, 3)),
      [0xef, 0xbb, 0xbf],
      'CSV 应以 UTF-8 BOM 开头',
    );

    const text = new TextDecoder('utf-8').decode(bytes);
    assert.match(text, /Variable Name,Question Code/);
    assert.match(text, /LKA/);
  });
});

describe('发布与共享令牌', () => {
  test('发布成功返回分享链接与令牌，并将问卷锁定', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '发布研究');

    const response = await api<{
      questionnaire: { status: string; locked: boolean; published_at: string };
      share_token: string;
      share_url: string;
      warnings: string[];
    }>(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });

    assert.equal(response.status, 200);
    assert.equal(response.data.questionnaire.status, 'published');
    assert.equal(response.data.questionnaire.locked, true);
    assert.ok(response.data.questionnaire.published_at);
    assert.ok(response.data.share_token.length >= 16);
    assert.match(response.data.share_url, /\/research\/[\w-]+$/);
  });

  test('分享令牌在数据库中唯一且可检索', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '令牌唯一性');
    const published = await api<{ share_token: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/publish`,
      { token: researcher.token },
    );

    const row = ctx.db.get<{ id: string }>('SELECT id FROM questionnaires WHERE share_token = ?', [
      published.data.share_token,
    ]);
    assert.equal(row?.id, project.questionnaireId);
  });

  test('重复发布返回同一个令牌（已印出的二维码不失效）', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '重复发布');
    const first = await api<{ share_token: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/publish`,
      { token: researcher.token },
    );
    const second = await api<{ share_token: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/publish`,
      { token: researcher.token },
    );
    assert.equal(second.data.share_token, first.data.share_token);
  });

  test('发布时生成问卷快照，保证数据与版本对应', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '快照研究');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });

    const snapshot = ctx.db.get<{ question_count: number; version: string }>(
      'SELECT question_count, version FROM questionnaire_snapshots WHERE questionnaire_id = ?',
      [project.questionnaireId],
    );
    assert.equal(snapshot?.question_count, 58);
    assert.equal(snapshot?.version, 'V4.0');
  });

  test('发布后禁止直接修改题目（423 锁定）', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '锁定研究');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });

    const builder = await api<{ questions: { id: string }[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${project.questionnaireId}/builder`,
      { token: researcher.token },
    );
    const questionId = builder.data.questions[0]!.id;

    const patch = await api<{ message: string }>(ctx, 'PATCH', `/api/questions/${questionId}`, {
      token: researcher.token,
      body: { question_text: '发布后偷偷改题' },
    });
    assert.equal(patch.status, 423);
    assert.equal(patch.error?.code, 'LOCKED');
    assert.match(patch.error?.message ?? '', /建立新版本/);

    const add = await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/questions`, {
      token: researcher.token,
      body: QUESTION_TYPE_PAYLOADS['text'],
    });
    assert.equal(add.status, 423);

    const del = await api(ctx, 'DELETE', `/api/questions/${questionId}`, { token: researcher.token });
    assert.equal(del.status, 423);

    const reorder = await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/questions/reorder`, {
      token: researcher.token,
      body: { ordered_ids: [] },
    });
    assert.equal(reorder.status, 423);
  });

  test('builder 状态在锁定时给出明确原因', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '锁定原因');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });

    const response = await api<{ editable: boolean; lock_reason: string }>(
      ctx,
      'GET',
      `/api/questionnaires/${project.questionnaireId}/builder`,
      { token: researcher.token },
    );
    assert.equal(response.data.editable, false);
    assert.match(response.data.lock_reason, /已发布并锁定/);
  });

  test('空问卷无法发布', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '空问卷发布' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token: researcher.token,
      body: { title: '空的' },
    });

    const response = await api(ctx, 'POST', `/api/questionnaires/${questionnaire.data.id}/publish`, {
      token: researcher.token,
    });
    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /没有任何题目/);
  });

  test('存在循环跳转时拒绝发布', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createProject(ctx, researcher.token, { title: '循环逻辑发布' });
    const questionnaire = await api<{ id: string }>(ctx, 'POST', `/api/projects/${project.id}/questionnaires`, {
      token: researcher.token,
      body: { title: '循环问卷' },
    });
    const qid = questionnaire.data.id;

    await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token: researcher.token,
      body: { ...QUESTION_TYPE_PAYLOADS['single'], question_code: 'QC1' },
    });
    await api(ctx, 'POST', `/api/questionnaires/${qid}/questions`, {
      token: researcher.token,
      body: {
        ...QUESTION_TYPE_PAYLOADS['single'],
        question_code: 'QC2',
        logic: {
          rules: [
            {
              id: 'back-jump',
              conditions: [{ questionCode: 'QC2', operator: 'eq', value: '1' }],
              action: { type: 'jump_to', target: 'QC1' },
            },
          ],
        },
      },
    });

    const response = await api(ctx, 'POST', `/api/questionnaires/${qid}/publish`, {
      token: researcher.token,
    });
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /循环/);
  });

  test('关闭收集后状态变为 closed，但数据与题目保留', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '关闭收集');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });

    const response = await api<{ status: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/close`,
      { token: researcher.token },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.status, 'closed');

    const instrument = await api<{ questions: unknown[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${project.questionnaireId}`,
      { token: researcher.token },
    );
    assert.equal(instrument.data.questions.length, 58);
  });
});

describe('版本控制', () => {
  test('建立新版本：克隆 58 道题、版本号递增、新版本可编辑', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '版本控制研究');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });

    const response = await api<{ id: string; version: string; status: string; locked: boolean }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/versions`,
      { token: researcher.token, body: { kind: 'minor' } },
    );

    assert.equal(response.status, 201);
    assert.equal(response.data.version, 'V4.1');
    assert.equal(response.data.status, 'draft');
    assert.equal(response.data.locked, false);
    assert.notEqual(response.data.id, project.questionnaireId);

    const builder = await api<{ questions: unknown[]; editable: boolean }>(
      ctx,
      'GET',
      `/api/questionnaires/${response.data.id}/builder`,
      { token: researcher.token },
    );
    assert.equal(builder.data.questions.length, 58, '新版本应完整克隆题目');
    assert.equal(builder.data.editable, true);
  });

  test('旧版本被标记为非当前版本，但保留其数据与版本号', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '版本切换');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, {
      token: researcher.token,
    });
    const newVersion = await api<{ id: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/versions`,
      { token: researcher.token, body: { kind: 'minor' } },
    );

    const list = await api<{ id: string; version: string; is_current: boolean; status: string }[]>(
      ctx,
      'GET',
      `/api/projects/${project.id}/questionnaires`,
      { token: researcher.token },
    );

    const old = list.data.find((q) => q.id === project.questionnaireId);
    const fresh = list.data.find((q) => q.id === newVersion.data.id);
    assert.equal(old?.is_current, false);
    assert.equal(old?.version, 'V4.0');
    assert.equal(old?.status, 'published');
    assert.equal(fresh?.is_current, true);
  });

  test('主版本号递增', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '主版本');
    const response = await api<{ version: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/versions`,
      { token: researcher.token, body: { kind: 'major' } },
    );
    assert.equal(response.data.version, 'V5.0');
  });

  test('新建版本会在归档旧版本前生成快照', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '快照归档');
    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/versions`, {
      token: researcher.token,
      body: { kind: 'minor' },
    });

    const count = Number(
      ctx.db.scalar<number>(
        'SELECT COUNT(*) FROM questionnaire_snapshots WHERE questionnaire_id = ?',
        [project.questionnaireId],
      ) ?? 0,
    );
    assert.ok(count >= 1, '旧版本应留下快照');
  });

  test('新版本发布后可获得独立的分享令牌', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '独立令牌');
    const first = await api<{ share_token: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/publish`,
      { token: researcher.token },
    );
    const newVersion = await api<{ id: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/versions`,
      { token: researcher.token, body: { kind: 'minor' } },
    );
    const second = await api<{ share_token: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${newVersion.data.id}/publish`,
      { token: researcher.token },
    );

    assert.notEqual(second.data.share_token, first.data.share_token);
  });

  test('版本链路的完整闭环：发布 → 锁定 → 新版本 → 编辑 → 再发布', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '闭环测试');

    await api(ctx, 'POST', `/api/questionnaires/${project.questionnaireId}/publish`, { token: researcher.token });

    const v2 = await api<{ id: string; version: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${project.questionnaireId}/versions`,
      { token: researcher.token, body: { kind: 'minor' } },
    );
    assert.equal(v2.data.version, 'V4.1');

    const added = await api<{ question_code: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${v2.data.id}/questions`,
      { token: researcher.token, body: { ...QUESTION_TYPE_PAYLOADS['textarea'], question_code: 'Q59' } },
    );
    assert.equal(added.status, 201);

    const published = await api<{ questionnaire: { status: string }; share_token: string }>(
      ctx,
      'POST',
      `/api/questionnaires/${v2.data.id}/publish`,
      { token: researcher.token },
    );
    assert.equal(published.data.questionnaire.status, 'published');

    const builder = await api<{ questions: unknown[] }>(
      ctx,
      'GET',
      `/api/questionnaires/${v2.data.id}/builder`,
      { token: researcher.token },
    );
    assert.equal(builder.data.questions.length, 59);
  });
});
