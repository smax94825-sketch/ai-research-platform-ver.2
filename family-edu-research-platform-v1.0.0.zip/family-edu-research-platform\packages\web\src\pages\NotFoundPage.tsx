import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Button, EmptyState } from '../components/ui';

export function NotFoundPage(): ReactNode {
  return (
    <EmptyState
      title="页面不存在"
      description="您访问的地址可能已被移动或删除。"
      action={
        <Link to="/">
          <Button variant="primary">返回 Dashboard</Button>
        </Link>
      }
    />
  );
}
