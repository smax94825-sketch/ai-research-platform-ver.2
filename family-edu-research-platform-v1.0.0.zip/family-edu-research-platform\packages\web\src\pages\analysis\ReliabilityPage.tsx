/**
 * Reliability analysis (PHASE 6).
 *
 * Cronbach's α is reported with the two things that make it interpretable: the
 * item-level diagnostics that show WHERE the internal consistency comes from
 * (corrected item–total correlation, α-if-deleted) and the reference thresholds
 * the engine itself uses. α is a statement about internal consistency only — the
 * page says so, because α is routinely over-read as evidence of validity or of
 * unidimensionality.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { BarChart, ScatterPlot } from '../../components/charts';
import { Alert, Card, CardHeader, LoadingBlock } from '../../components/ui';
import {
  api,
  ApiClientError,
  type AnalysisReliabilityResponse,
  type ReliabilityResult,
} from '../../lib/api';
import { formatNumber, formatStat } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from './shared';

/** Threshold table built from the API's own reference values. */
function AlphaReference({ scale }: { scale: ReliabilityResult }): ReactNode {
  const reference = scale.alpha_reference;
  const rows: { range: string; judgement: string }[] = [
    { range: `≥ ${formatStat(reference.excellent, 2)}`, judgement: '极好（excellent）' },
    {
      range: `${formatStat(reference.good, 2)} — ${formatStat(reference.excellent - 0.01, 2)}`,
      judgement: '良好（good）',
    },
    {
      range: `${formatStat(reference.acceptable, 2)} — ${formatStat(reference.good - 0.01, 2)}`,
      judgement: '可接受（acceptable）',
    },
    {
      range: `${formatStat(reference.questionable, 2)} — ${formatStat(reference.acceptable - 0.01, 2)}`,
      judgement: '存疑（questionable）',
    },
    { range: `< ${formatStat(reference.questionable, 2)}`, judgement: '不理想，需重新审视量表' },
  ];

  return (
    <div className="mt-4 rounded-md border border-ink-200 bg-ink-50 px-3.5 py-3">
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">α 判定参考阈值</p>
      <ul className="mt-1 grid gap-1 text-xs text-ink-600 sm:grid-cols-2 lg:grid-cols-3">
        {rows.map((row) => (
          <li key={row.judgement}>
            <span className="font-mono text-ink-800">{row.range}</span>
            <span className="ml-2">{row.judgement}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ScaleCard({ scale, sampleN }: { scale: ReliabilityResult; sampleN: number }): ReactNode {
  const itemTotalPoints = scale.items
    .filter((item) => item.item_total_correlation !== null && Number.isFinite(item.mean))
    .map((item) => ({
      x: item.mean,
      y: item.item_total_correlation as number,
      label: item.label,
    }));

  return (
    <Card>
      <CardHeader
        title={scale.label}
        description={`量表代号 ${scale.scale} · 维度 ${scale.dimension} · ${scale.k} 个条目 · 整例有效样本 n = ${formatNumber(scale.n)}${
          scale.dropped > 0 ? ` · 因条目缺失被整例删除 ${scale.dropped} 例` : ''
        }`}
      />

      <dl className="grid gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">Cronbach α</dt>
          <dd className="mt-1 text-2xl font-semibold tabular-nums text-ink-900">
            {formatStat(scale.cronbach_alpha, 3)}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">标准化 α</dt>
          <dd className="mt-1 text-2xl font-semibold tabular-nums text-ink-900">
            {formatStat(scale.standardized_alpha, 3)}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">平均条目间相关</dt>
          <dd className="mt-1 text-2xl font-semibold tabular-nums text-ink-900">
            {formatStat(scale.mean_inter_item_correlation, 3)}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">量表总分均值</dt>
          <dd className="mt-1 text-lg tabular-nums text-ink-800">{formatStat(scale.scale_mean, 2)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-ink-500">量表总分 SD</dt>
          <dd className="mt-1 text-lg tabular-nums text-ink-800">
            {formatStat(scale.scale_standard_deviation, 2)}
          </dd>
        </div>
      </dl>

      <p className="mt-4 text-sm leading-relaxed text-ink-700">{scale.interpretation}</p>

      {scale.warnings.length > 0 && (
        <div className="mt-3">
          <Alert tone="warning" title="条目层面的提示">
            <ul className="list-disc space-y-1 pl-4">
              {scale.warnings.map((warning) => (
                <li key={warning}>{warning}</li>
              ))}
            </ul>
          </Alert>
        </div>
      )}

      <AlphaReference scale={scale} />

      <div className="mt-5 overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-3 py-2 text-left">条目</th>
              <th className="px-3 py-2 text-right">n</th>
              <th className="px-3 py-2 text-right">均值</th>
              <th className="px-3 py-2 text-right">标准差</th>
              <th className="px-3 py-2 text-right">校正后题总相关</th>
              <th className="px-3 py-2 text-right">删除该条目后的 α</th>
              <th className="px-3 py-2 text-left">提示</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {scale.items.map((item) => {
              const weak = item.item_total_correlation !== null && item.item_total_correlation < 0.3;
              const improves =
                item.alpha_if_deleted !== null &&
                scale.cronbach_alpha !== null &&
                item.alpha_if_deleted > scale.cronbach_alpha + 0.05;
              return (
                <tr key={item.item}>
                  <td className="px-3 py-2">
                    <span className="text-ink-900">{item.label}</span>
                    <span className="ml-2 font-mono text-[11px] text-ink-500">{item.item}</span>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-600">{item.n}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-800">{formatStat(item.mean, 3)}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                    {formatStat(item.standard_deviation, 3)}
                  </td>
                  <td
                    className={`px-3 py-2 text-right tabular-nums ${weak ? 'text-amber-700' : 'text-ink-800'}`}
                  >
                    {formatStat(item.item_total_correlation, 3)}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                    {formatStat(item.alpha_if_deleted, 3)}
                  </td>
                  <td className="px-3 py-2 text-xs text-amber-700">
                    {weak ? '题总相关低于 0.30' : ''}
                    {weak && improves ? '；' : ''}
                    {improves ? '删除后 α 提升超过 0.05' : ''}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">各条目校正后题总相关</h3>
          <BarChart
            data={scale.items.map((item) => ({
              label: item.label,
              value: item.item_total_correlation ?? 0,
            }))}
            unit="r"
            emptyText="该量表没有可计算的题总相关。"
            caption={
              `共 ${scale.items.length} 个条目；横条长度为校正后题总相关系数 r，数值越大表示该条目与量表其余条目的合计得分关系越强。` +
              '引擎以 r < 0.30 作为提示阈值，低于该值会同时在上表中标出；负值条目以 0 为基线向左绘制，是需要重点检查的信号。'
            }
          />
        </div>
        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">条目诊断散点（均值 × 题总相关）</h3>
          {itemTotalPoints.length >= 3 ? (
            <ScatterPlot
              points={itemTotalPoints}
              xLabel="条目均值"
              yLabel="校正后题总相关 r"
              caption={`每个点是一个条目（共 ${itemTotalPoints.length} 个）。`}
            />
          ) : (
            <p className="py-6 text-center text-sm text-ink-400">
              条目数不足 3 个或无题总相关，无法绘制诊断散点图。
            </p>
          )}
        </div>
      </div>

      <MethodNote title="为什么只看 α 还不够">
        <p>
          α 反映条目间的一致程度，会随条目数增加而升高，因此不能用来比较条目数不同的量表，
          也不构成效度证据，更不证明量表只有一个维度（α 高且多维的量表很常见）。
        </p>
        <p>
          本页 α 基于整例删除后的完整样本（n = {formatNumber(scale.n)}）计算，与被删除的 {scale.dropped} 例无关；
          报告时应同时给出该 n。分析基数为 {formatNumber(sampleN)} 份可分析样本，差值为条目缺失导致的整例删除。
        </p>
      </MethodNote>
    </Card>
  );
}

export function ReliabilityPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisReliabilityResponse | null>(null);
  const [sampleN, setSampleN] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      const [reliability, descriptive] = await Promise.all([
        api.analysis.reliability(projectId),
        api.analysis.descriptive(projectId),
      ]);
      setData(reliability);
      setSampleN(descriptive.sample.analysable);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载信度分析结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Reliability"
          subtitle="信度分析：各量表内部一致性系数与条目层面的诊断。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在计算信度系数…" />
        ) : !data ? null : data.scales.length === 0 ? (
          <Alert tone="warning" title="没有可计算信度的量表">
            该问卷未定义任何多条目量表，或量表条目在数据中不存在。
            信度分析需要同一维度下至少两个条目；请检查问卷的量表结构（该问卷若不基于本平台模板，派生量表不会被创建）。
          </Alert>
        ) : (
          <>
            <MethodNote>
              <p>{data.note}</p>
              <p>
                引擎版本 {data.engine_version}；共 {data.scales.length} 个量表，
                分析基数为 {sampleN === null ? '—' : formatNumber(sampleN)} 份可分析样本，
                各量表另有其整例有效 n。
              </p>
            </MethodNote>

            {data.scales.map((scale) => (
              <ScaleCard key={scale.scale} scale={scale} sampleN={sampleN ?? 0} />
            ))}
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
