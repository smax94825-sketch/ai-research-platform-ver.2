/**
 * Data Collection → Quality (PHASE 4).
 *
 * This page exists to help a researcher decide, not to decide for them. Every
 * number is shown with its rule, its weight and the evidence behind it, and the
 * page states plainly that the score is a heuristic trigger for review rather
 * than a verdict on a respondent.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Alert,
  Badge,
  Button,
  Card,
  CardHeader,
  EmptyState,
  LoadingBlock,
  Select,
  StatCard,
} from '../components/ui';
import {
  api,
  ApiClientError,
  type ProjectListResult,
  type ProjectQualityReport,
  type QualityRecomputeResult,
  type QualityRuleDefinition,
  type QualitySeverity,
} from '../lib/api';
import { formatDateTime, formatStat } from '../lib/format';

const SEVERITY_TONE: Record<QualitySeverity | 'clean' | 'unscored', 'neutral' | 'info' | 'success' | 'warning' | 'danger'> = {
  clean: 'success',
  info: 'info',
  warning: 'warning',
  critical: 'danger',
  unscored: 'neutral',
};

const SEVERITY_LABEL: Record<QualitySeverity | 'clean' | 'unscored', string> = {
  clean: '未发现可疑模式',
  info: '提示',
  warning: '需复核',
  critical: '强烈建议复核',
  unscored: '未评分',
};

export function QualityPage(): ReactNode {
  const [searchParams, setSearchParams] = useSearchParams();

  const [projects, setProjects] = useState<ProjectListResult | null>(null);
  const [projectId, setProjectId] = useState('');
  const [report, setReport] = useState<ProjectQualityReport | null>(null);
  const [rules, setRules] = useState<QualityRuleDefinition[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const list = await api.projects.list({ limit: 200 });
        if (cancelled) return;
        setProjects(list);
        setProjectId(searchParams.get('project') ?? list.items[0]?.id ?? '');
        if (list.items.length === 0) setLoading(false);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiClientError ? err.message : '无法加载研究项目。');
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      const [qualityReport, catalogue] = await Promise.all([
        api.quality.report(projectId),
        api.quality.rules(projectId),
      ]);
      setReport(qualityReport);
      setRules(catalogue);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载质量报告。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function recompute(): Promise<void> {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result: QualityRecomputeResult = await api.quality.recompute(projectId);
      setNotice(
        `质量检测已完成：评分 ${result.respondents_scored} 份样本，写入 ${result.flags_written} 条标记，` +
          `其中 ${result.flagged_respondents} 份需要复核、${result.clean_respondents} 份未发现可疑模式。` +
          '（本操作不会删除或修改任何样本）',
      );
      await load();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '质量检测运行失败。');
    } finally {
      setBusy(false);
    }
  }

  if (!projects) return <LoadingBlock label="正在加载研究项目…" />;

  if (projects.items.length === 0) {
    return (
      <EmptyState
        title="还没有研究项目"
        description="数据质量检测需要先有研究项目与已收集的样本。"
        action={
          <Link to="/projects/new">
            <Button variant="primary">新建研究项目</Button>
          </Link>
        }
      />
    );
  }

  const ruleByCode = new Map(rules.map((rule) => [rule.code, rule]));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-ink-900">Quality</h1>
          <p className="mt-1 text-sm text-ink-500">
            数据质量检测：自动标记可疑作答模式，供研究人员人工判断。
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-2 text-sm text-ink-600">
            当前研究项目
            <Select
              className="min-w-56"
              value={projectId}
              onChange={(event) => {
                setProjectId(event.target.value);
                setSearchParams({ project: event.target.value });
              }}
            >
              {projects.items.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </Select>
          </label>
          <Button variant="primary" loading={busy} onClick={() => void recompute()}>
            重新运行质量检测
          </Button>
        </div>
      </div>

      <Alert tone="warning" title="重要说明：评分不会改变任何数据">
        质量评分是<strong>启发式指标</strong>，用于提示需要人工复核的样本，
        <strong>不等同于对受访者的评价，也不构成剔除依据</strong>。
        平台不会自动删除或修改任何样本；是否排除由研究者判断，且必须填写原因。
        自动评分在样本提交时完成，跨样本规则（如疑似重复提交）会随新样本到达而回溯更新。
      </Alert>

      {error && (
        <Alert tone="danger" title="操作失败">
          {error}
        </Alert>
      )}
      {notice && <Alert tone="success">{notice}</Alert>}

      {loading && !report ? (
        <LoadingBlock />
      ) : !report ? null : (
        <>
          {/* Summary ---------------------------------------------------- */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <StatCard label="已评分样本" value={report.scored_respondents} />
            <StatCard
              label="需复核样本"
              value={report.flagged_samples.length}
              tone={report.flagged_samples.length > 0 ? 'warning' : 'neutral'}
              hint="至少命中一条规则"
            />
            <StatCard label="未评分样本" value={report.unscored_respondents} hint="尚无作答，无法判断" />
            <StatCard label="平均分" value={formatStat(report.mean_score, 1)} />
            <StatCard label="中位数" value={formatStat(report.median_score, 1)} />
          </div>

          {/* Bands ------------------------------------------------------ */}
          <Card>
            <CardHeader
              title="评分分布"
              description={`引擎版本 ${report.engine_version}。${report.thresholds_note}`}
            />
            <ul className="space-y-3">
              {report.bands.map((band) => {
                const total = report.bands.reduce((sum, item) => sum + item.count, 0);
                const percent = total > 0 ? (band.count / total) * 100 : 0;
                const tone =
                  band.min >= 90 ? 'bg-emerald-500' : band.min >= 70 ? 'bg-brand-500' : band.min >= 40 ? 'bg-amber-500' : 'bg-red-500';
                return (
                  <li key={band.label}>
                    <div className="mb-1 flex items-baseline justify-between text-sm">
                      <span className="text-ink-700">{band.label}</span>
                      <span className="tabular-nums text-ink-600">
                        {band.count} 份 · {percent.toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-ink-100">
                      <div className={`h-full rounded-full ${tone}`} style={{ width: `${percent}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          </Card>

          {/* Rule frequency -------------------------------------------- */}
          <Card>
            <CardHeader
              title="规则命中情况"
              description="每条规则的含义与解读说明，来自引擎自身的规则定义。"
            />
            {report.rule_frequency.length === 0 ? (
              <p className="py-4 text-center text-sm text-ink-500">
                尚未命中任何规则。若样本量很少，这通常只是样本不足的表现。
              </p>
            ) : (
              <ul className="space-y-3">
                {report.rule_frequency.map((item) => {
                  const rule = ruleByCode.get(item.rule_code);
                  return (
                    <li key={item.rule_code} className="rounded-md border border-ink-200 p-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs text-ink-500">{item.rule_code}</span>
                        <span className="text-sm font-medium text-ink-900">{item.label}</span>
                        <Badge tone={SEVERITY_TONE[item.severity]}>{SEVERITY_LABEL[item.severity]}</Badge>
                        <span className="text-sm tabular-nums text-ink-600">命中 {item.count} 份</span>
                        {rule && <span className="text-xs text-ink-500">每条扣 {rule.score_impact} 分</span>}
                      </div>
                      {rule && (
                        <>
                          <p className="mt-2 text-xs text-ink-600">{rule.description}</p>
                          <p className="mt-1 text-xs text-amber-800">解读：{rule.interpretation}</p>
                        </>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}

            {report.inactive_rules.length > 0 && (
              <div className="mt-4">
                <Alert tone="info" title="以下规则对该问卷不适用">
                  <ul className="list-disc space-y-1 pl-4">
                    {report.inactive_rules.map((rule) => (
                      <li key={rule.rule_code}>
                        <span className="font-mono text-xs">{rule.rule_code}</span>：{rule.reason}
                      </li>
                    ))}
                  </ul>
                </Alert>
              </div>
            )}
          </Card>

          {/* Flagged samples ------------------------------------------- */}
          <Card padded={false}>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink-200 px-5 py-4">
              <div>
                <h2 className="text-base font-semibold text-ink-900">
                  待复核样本（{report.flagged_samples.length}）
                </h2>
                <p className="mt-1 text-sm text-ink-500">
                  按评分由低到高排列。点击任一编号查看该样本的全部作答与命中的规则。
                </p>
              </div>
              <Link to={`/collection/samples?project=${projectId}&quality_severity=critical`}>
                <Button>在样本列表中筛选</Button>
              </Link>
            </div>

            {report.flagged_samples.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-ink-500">
                当前没有需要复核的样本。
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] text-sm">
                  <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-5 py-2 text-left">匿名编号</th>
                      <th className="px-5 py-2 text-right">质量评分</th>
                      <th className="px-5 py-2 text-left">命中规则</th>
                      <th className="px-5 py-2 text-left">审核状态</th>
                      <th className="px-5 py-2 text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {report.flagged_samples.map((sample) => (
                      <tr key={sample.respondent_id}>
                        <td className="px-5 py-2 font-mono text-xs text-ink-800">
                          {sample.anonymous_id}
                        </td>
                        <td className="px-5 py-2 text-right tabular-nums font-medium text-ink-900">
                          {sample.score}
                        </td>
                        <td className="px-5 py-2">
                          <div className="flex flex-wrap gap-1">
                            {sample.rule_codes.map((code) => (
                              <span
                                key={code}
                                title={ruleByCode.get(code)?.label ?? code}
                                className="rounded bg-ink-100 px-1.5 py-0.5 text-[10px] text-ink-700"
                              >
                                {ruleByCode.get(code)?.label ?? code}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-5 py-2 text-xs text-ink-600">{sample.review_status}</td>
                        <td className="px-5 py-2 text-right">
                          <Link to={`/collection/samples/${sample.respondent_id}`}>
                            <Button variant="ghost">查看作答</Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>

          {/* Excluded --------------------------------------------------- */}
          {report.excluded_samples.length > 0 && (
            <Card>
              <CardHeader
                title={`已被研究者排除的样本（${report.excluded_samples.length}）`}
                description="平台不会删除任何样本。以下为人工判断结果，可在方法部分如实报告排除标准。"
              />
              <ul className="divide-y divide-ink-100">
                {report.excluded_samples.map((sample) => (
                  <li key={sample.anonymous_id} className="flex flex-wrap items-baseline gap-3 py-2 text-sm">
                    <span className="font-mono text-xs text-ink-800">{sample.anonymous_id}</span>
                    <span className="text-ink-700">{sample.note ?? '（未填写原因）'}</span>
                    <span className="ml-auto text-xs text-ink-500">{formatDateTime(sample.reviewed_at)}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
