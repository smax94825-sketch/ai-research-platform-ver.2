/**
 * Quota management and dynamic collection recommendations (PHASE 4, spec §18/§35).
 *
 * Pure functions: the dashboard, the quota API and the (future) report
 * generator all derive the same numbers and the same advice from the same code.
 *
 * The recommendation engine is deliberately deterministic and evidence-bearing:
 * every recommendation states the counts it is based on, so a researcher can
 * check it rather than trust it. It also honours `preserve_structure` — when a
 * researcher has said "do not change my target structure", the engine reports
 * the shortfall but does not propose changing the targets.
 */

import type { QuotaCategory, QuotaConfig } from './types.js';

/* ------------------------------------------------------------------ */
/* Progress                                                           */
/* ------------------------------------------------------------------ */

export interface QuotaProgressItem {
  dimension: string;
  category: string;
  target_n: number;
  current_n: number;
  /** current / target × 100, rounded to 2dp. */
  percent: number;
  remaining: number;
  met: boolean;
  /** True when the category has reached at least 100% of target. */
  exceeded: boolean;
}

export interface QuotaProgressSummary {
  items: QuotaProgressItem[];
  total_target: number;
  total_current: number;
  /** Overall completion, or null when no targets are configured. */
  percent: number | null;
  met_categories: number;
  unmet_categories: number;
  /** Categories with the largest absolute shortfall, worst first. */
  largest_shortfalls: QuotaProgressItem[];
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

/**
 * Compute progress for each configured category.
 *
 * `countsByCategory` maps a category label to the number of *usable* samples
 * observed for it — callers decide whether "usable" means completed only, or
 * completed-and-not-excluded. That choice is a research decision, so it is made
 * at the call site and not hidden here.
 */
export function computeQuotaProgress(
  categories: readonly QuotaCategory[],
  countsByCategory: Readonly<Record<string, number>>,
): QuotaProgressSummary {
  const items: QuotaProgressItem[] = categories.map((category) => {
    const current = countsByCategory[category.category] ?? 0;
    const target = category.target_n;
    return {
      dimension: category.dimension,
      category: category.category,
      target_n: target,
      current_n: current,
      percent: target > 0 ? round2((current / target) * 100) : 0,
      remaining: Math.max(0, target - current),
      met: target > 0 ? current >= target : true,
      exceeded: target > 0 ? current > target : false,
    };
  });

  const totalTarget = items.reduce((sum, item) => sum + item.target_n, 0);
  const totalCurrent = items.reduce((sum, item) => sum + item.current_n, 0);
  const unmet = items.filter((item) => !item.met);

  return {
    items,
    total_target: totalTarget,
    total_current: totalCurrent,
    percent: totalTarget > 0 ? round2((totalCurrent / totalTarget) * 100) : null,
    met_categories: items.filter((item) => item.met).length,
    unmet_categories: unmet.length,
    largest_shortfalls: [...unmet].sort((a, b) => b.remaining - a.remaining),
  };
}

/* ------------------------------------------------------------------ */
/* Balanced-structure diagnostics                                     */
/* ------------------------------------------------------------------ */

export interface BalanceDiagnostic {
  /** True when the observed distribution is materially skewed. */
  imbalanced: boolean;
  /** Observed share per category (of the total collected). */
  observed_share: Record<string, number>;
  /** Target share per category (of the total target). */
  target_share: Record<string, number>;
  /** Largest positive deviation, i.e. the most over-represented category. */
  most_over: { category: string; deviation_pp: number } | null;
  /** Largest negative deviation, i.e. the most under-represented category. */
  most_under: { category: string; deviation_pp: number } | null;
  /** Deviation in percentage points beyond which we call it imbalanced. */
  threshold_pp: number;
}

/**
 * Compare the observed category mix against the designed mix.
 *
 * Percentages, not raw counts: a project that has collected 10 of 1000 samples
 * will show large raw shortfalls everywhere, which is not evidence of a
 * *structural* problem. Share comparison answers "is the mix wrong?", which is
 * the question the recommendation engine needs.
 */
export function diagnoseBalance(
  summary: QuotaProgressSummary,
  thresholdPercentagePoints = 10,
): BalanceDiagnostic {
  const totalCurrent = summary.total_current;
  const totalTarget = summary.total_target;

  const observedShare: Record<string, number> = {};
  const targetShare: Record<string, number> = {};
  const deviations: { category: string; deviation: number }[] = [];

  for (const item of summary.items) {
    const observed = totalCurrent > 0 ? (item.current_n / totalCurrent) * 100 : 0;
    const target = totalTarget > 0 ? (item.target_n / totalTarget) * 100 : 0;
    observedShare[item.category] = round2(observed);
    targetShare[item.category] = round2(target);
    deviations.push({ category: item.category, deviation: observed - target });
  }

  const sorted = [...deviations].sort((a, b) => b.deviation - a.deviation);
  const mostOver = sorted[0] ?? null;
  const mostUnder = sorted[sorted.length - 1] ?? null;

  return {
    imbalanced:
      totalCurrent > 0 &&
      deviations.some((item) => Math.abs(item.deviation) >= thresholdPercentagePoints),
    observed_share: observedShare,
    target_share: targetShare,
    most_over: mostOver ? { category: mostOver.category, deviation_pp: round2(mostOver.deviation) } : null,
    most_under: mostUnder ? { category: mostUnder.category, deviation_pp: round2(mostUnder.deviation) } : null,
    threshold_pp: thresholdPercentagePoints,
  };
}

/* ------------------------------------------------------------------ */
/* Recommendations                                                    */
/* ------------------------------------------------------------------ */

export type RecommendationKind = 'quota_shortfall' | 'structure' | 'channel' | 'saturation' | 'none';

export interface QuotaRecommendation {
  kind: RecommendationKind;
  severity: 'info' | 'warning' | 'critical';
  /** One-line recommendation. */
  text: string;
  /** The counts and shares the recommendation is based on. */
  evidence: string[];
}

export interface QuotaRecommendationInput {
  config: QuotaConfig | null;
  summary: QuotaProgressSummary;
  balance: BalanceDiagnostic;
  /** Sample counts per acquisition channel, most useful first. */
  sourceCounts?: { source: string; total: number; completed: number }[];
  /** Channel labels for display; unknown channels fall back to their code. */
  sourceLabels?: Record<string, string>;
  /** Categories that historically convert well through each channel, if known. */
  channelSuggestions?: Record<string, string[]>;
}

/** Suggested acquisition channels for the default education-stage quotas. */
export const DEFAULT_CHANNEL_SUGGESTIONS: Record<string, string[]> = {
  学前: ['community', 'wechat'],
  小学: ['school', 'wechat'],
  初中: ['school', 'wechat'],
  高中: ['school', 'community'],
};

export function buildQuotaRecommendations(
  input: QuotaRecommendationInput,
): QuotaRecommendation[] {
  const { config, summary, balance } = input;
  const recommendations: QuotaRecommendation[] = [];

  if (!config || !config.enabled || summary.items.length === 0) {
    recommendations.push({
      kind: 'none',
      severity: 'info',
      text: '该项目未配置样本配额，因此不产生配额相关的收集建议。如需按教育阶段等维度控制样本结构，请先设置配额。',
      evidence: ['quota_config.enabled = false'],
    });
    return recommendations;
  }

  if (summary.total_current === 0) {
    recommendations.push({
      kind: 'none',
      severity: 'info',
      text: '尚未收到任何样本，暂无可用于判断样本结构的依据。建议先通过分享链接与二维码开始收集。',
      evidence: [`目标样本量合计 ${summary.total_target}`],
    });
    return recommendations;
  }

  /* --- Shortfalls -------------------------------------------------- */
  const shortfalls = summary.largest_shortfalls;
  if (shortfalls.length > 0) {
    const detail = shortfalls
      .map((item) => `${item.category} ${item.current_n}/${item.target_n}（差 ${item.remaining}）`)
      .join('、');

    recommendations.push({
      kind: 'quota_shortfall',
      severity: summary.percent !== null && summary.percent < 50 ? 'critical' : 'warning',
      text:
        `${shortfalls.map((item) => item.category).join('、')}样本不足，建议继续收集。` +
        `当前完成度 ${summary.percent ?? 0}%（${summary.total_current}/${summary.total_target}）。`,
      evidence: [
        `各分类进度：${detail}`,
        `未达标分类 ${summary.unmet_categories} 个，已达标 ${summary.met_categories} 个`,
      ],
    });
  } else {
    recommendations.push({
      kind: 'saturation',
      severity: 'info',
      text: '所有分类均已达到目标配额。如继续收集，新增样本可能改变样本结构，建议先确认是否仍有必要。',
      evidence: [`总样本 ${summary.total_current}，总目标 ${summary.total_target}`],
    });
  }

  /* --- Structure --------------------------------------------------- */
  if (balance.imbalanced && balance.most_over && balance.most_under) {
    const over = balance.most_over;
    const under = balance.most_under;
    const preserve = config.preserve_structure;

    recommendations.push({
      kind: 'structure',
      severity: 'warning',
      text: preserve
        ? `当前样本结构存在明显不均衡：${over.category} 超出设计占比 ${over.deviation_pp > 0 ? '+' : ''}${over.deviation_pp} 个百分点，` +
          `${under.category} 低于设计占比 ${under.deviation_pp} 个百分点。` +
          `您已设置「保持目标样本结构」，因此平台不会调整目标配额，请通过渠道投放优先补齐 ${under.category}。`
        : `当前样本结构存在明显不均衡：${over.category} 超出设计占比 ${over.deviation_pp > 0 ? '+' : ''}${over.deviation_pp} 个百分点，` +
          `${under.category} 低于设计占比 ${under.deviation_pp} 个百分点。建议在下一阶段优先收集 ${under.category}。`,
      evidence: [
        `观测占比：${Object.entries(balance.observed_share)
          .map(([category, share]) => `${category} ${share}%`)
          .join('、')}`,
        `设计占比：${Object.entries(balance.target_share)
          .map(([category, share]) => `${category} ${share}%`)
          .join('、')}`,
        `判定阈值：偏差 ≥ ${balance.threshold_pp} 个百分点`,
        `preserve_structure = ${preserve}`,
      ],
    });
  }

  /* --- Channel guidance -------------------------------------------- */
  const priorityCategories = shortfalls.slice(0, 3).map((item) => item.category);
  if (priorityCategories.length > 0) {
    const label = (source: string): string => input.sourceLabels?.[source] ?? source;
    const suggestions = priorityCategories.map((category) => {
      const channels =
        input.channelSuggestions?.[category] ?? DEFAULT_CHANNEL_SUGGESTIONS[category] ?? null;
      return channels
        ? `${category} → 建议渠道：${channels.map(label).join('、')}`
        : `${category} → 请选择该群体聚集的渠道`;
    });

    const observed = input.sourceCounts ?? [];
    const activeChannels =
      observed.length > 0
        ? observed
            .slice(0, 4)
            .map((item) => `${label(item.source)} ${item.completed}/${item.total}`)
            .join('、')
        : '暂无渠道数据';

    recommendations.push({
      kind: 'channel',
      severity: 'info',
      text: `下一阶段建议优先收集：${priorityCategories.join('、')}。`,
      evidence: [...suggestions, `当前各渠道（已完成/样本数）：${activeChannels}`],
    });
  }

  return recommendations;
}

/* ------------------------------------------------------------------ */
/* Validation                                                         */
/* ------------------------------------------------------------------ */

export interface QuotaValidationIssue {
  field: string;
  message: string;
}

/**
 * Validate a quota configuration before it is saved.
 * A quota that cannot be met is worse than no quota, so the checks are strict
 * but only about internal consistency.
 */
export function validateQuotaConfig(config: unknown): {
  valid: boolean;
  errors: QuotaValidationIssue[];
  warnings: QuotaValidationIssue[];
} {
  const errors: QuotaValidationIssue[] = [];
  const warnings: QuotaValidationIssue[] = [];

  if (config === null || config === undefined) return { valid: true, errors, warnings };
  if (typeof config !== 'object') {
    return { valid: false, errors: [{ field: 'quota_config', message: '配额配置必须是对象。' }], warnings };
  }

  const candidate = config as Partial<QuotaConfig>;
  if (typeof candidate.enabled !== 'boolean') {
    errors.push({ field: 'enabled', message: '必须明确 enabled 是 true 还是 false。' });
  }
  if (typeof candidate.preserve_structure !== 'boolean') {
    errors.push({
      field: 'preserve_structure',
      message: '必须明确 preserve_structure（是否保持目标样本结构）。',
    });
  }
  if (!Array.isArray(candidate.categories)) {
    errors.push({ field: 'categories', message: 'categories 必须是数组。' });
    return { valid: errors.length === 0, errors, warnings };
  }

  const seen = new Set<string>();
  for (const [index, category] of candidate.categories.entries()) {
    const item = category as Partial<QuotaCategory>;
    if (typeof item.dimension !== 'string' || item.dimension.trim() === '') {
      errors.push({ field: `categories[${index}].dimension`, message: '缺少配额维度。' });
    }
    if (typeof item.category !== 'string' || item.category.trim() === '') {
      errors.push({ field: `categories[${index}].category`, message: '缺少配额分类名称。' });
    }
    if (
      typeof item.target_n !== 'number' ||
      !Number.isInteger(item.target_n) ||
      item.target_n <= 0
    ) {
      errors.push({
        field: `categories[${index}].target_n`,
        message: `分类「${String(item.category ?? index)}」的目标数量必须是正整数。`,
      });
    }
    const key = `${String(item.dimension)}::${String(item.category)}`;
    if (seen.has(key)) {
      errors.push({
        field: `categories[${index}]`,
        message: `分类「${String(item.category)}」在同一维度下重复定义。`,
      });
    }
    seen.add(key);
  }

  if (candidate.categories.length === 0 && candidate.enabled === true) {
    warnings.push({
      field: 'categories',
      message: '配额已启用但没有任何分类，将无法产生有效的收集建议。',
    });
  }

  const total = candidate.categories.reduce(
    (sum, category) => sum + (typeof category.target_n === 'number' ? category.target_n : 0),
    0,
  );
  if (total > 1_000_000) {
    errors.push({ field: 'categories', message: '配额目标总量超出合理上限。' });
  }

  return { valid: errors.length === 0, errors, warnings };
}
