/**
 * Respondent collection API tests (PHASE 3).
 *
 * These cover the integrity rules that matter most for a research platform:
 * that a stored answer can never be one the instrument does not define, that a
 * skipped question cannot be answered by a crafted request, and that changing an
 * earlier answer removes now-unreachable answers instead of leaving
 * structurally impossible combinations in the dataset.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import {
  api,
  createPublishedQuestionnaire,
  createTestContext,
  publishTemplatedProject,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

const TEXT_QUESTION = {
  question_code: 'T1',
  question_text: '请简要描述您的看法。',
  question_type: 'textarea',
  required: true,
  options: { maxLength: 50 },
};

const SINGLE_QUESTION = {
  question_code: 'S1',
  question_text: '您是否使用过家庭教育服务？',
  question_type: 'single',
  required: true,
  variable_name: 'SVC',
  options: {
    choices: [
      { value: '1', label: '从未使用' },
      { value: '2', label: '使用过' },
    ],
  },
};

/** Q1 gates Q2; used for skip-integrity tests. */
const GATE_QUESTIONS = [
  {
    question_code: 'G1',
    question_text: '您是否使用过家庭教育机构？',
    question_type: 'single',
    required: true,
    options: {
      choices: [
        { value: '1', label: '从未使用' },
        { value: '2', label: '使用过' },
      ],
    },
    logic: {
      rules: [
        {
          id: 'skip-g2',
          match: 'all',
          conditions: [{ questionCode: 'G1', operator: 'eq', value: '1' }],
          action: { type: 'jump_to', target: 'G3' },
        },
      ],
    },
  },
  {
    question_code: 'G2',
    question_text: '请评价您的满意程度。',
    question_type: 'likert',
    required: true,
    options: {
      choices: [
        { value: '1', label: '非常不满意', score: 1 },
        { value: '2', label: '一般', score: 2 },
        { value: '3', label: '非常满意', score: 3 },
      ],
    },
    logic: {
      rules: [
        {
          id: 'show-g2',
          match: 'all',
          conditions: [{ questionCode: 'G1', operator: 'neq', value: '1' }],
          action: { type: 'show' },
        },
      ],
    },
  },
  {
    question_code: 'G3',
    question_text: '未来您愿意使用吗？',
    question_type: 'single',
    required: true,
    options: {
      choices: [
        { value: '1', label: '不愿意' },
        { value: '2', label: '愿意' },
      ],
    },
  },
];

const ALL_TYPES_QUESTIONS = [
  SINGLE_QUESTION,
  {
    question_code: 'M1',
    question_text: '您通过哪些渠道了解？',
    question_type: 'multiple',
    required: false,
    options: {
      choices: [
        { value: '1', label: '微信' },
        { value: '2', label: '学校' },
        { value: '9', label: '以上都不知道', exclusive: true },
      ],
    },
  },
  {
    question_code: 'N1',
    question_text: '您每周投入多少小时？',
    question_type: 'number',
    required: false,
    options: { min: 0, max: 40 },
  },
  {
    question_code: 'X1',
    question_text: '请评价各个方面：',
    question_type: 'matrix',
    required: false,
    options: {
      matrix: {
        rows: [
          { value: '1', label: '内容实用性' },
          { value: '2', label: '获取便利性' },
        ],
        columns: [
          { value: '1', label: '很不满意', score: 1 },
          { value: '2', label: '一般', score: 2 },
          { value: '3', label: '很满意', score: 3 },
        ],
      },
    },
  },
  {
    question_code: 'R1',
    question_text: '请按需要程度排序。',
    question_type: 'ranking',
    required: false,
    options: {
      choices: [
        { value: '1', label: '课程' },
        { value: '2', label: '咨询' },
        { value: '3', label: '社群' },
      ],
    },
  },
];

/* ================================================================== */
/* Instrument                                                         */
/* ================================================================== */

describe('公开问卷与知情同意', () => {
  test('instrument 接口返回题目、知情同意文本与研究设置', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await publishTemplatedProject(ctx, researcher.token, '公开问卷测试');

    const response = await api<{
      questionnaire: { title: string; version: string };
      consent_text: string;
      anonymous: boolean;
      allow_partial: boolean;
      question_count: number;
      questions: unknown[];
    }>(ctx, 'GET', `/api/public/survey/${fixture.shareToken}/instrument`);

    assert.equal(response.status, 200);
    assert.equal(response.data.questions.length, 58);
    assert.equal(response.data.question_count, 58);
    assert.equal(response.data.anonymous, true);
    assert.match(response.data.consent_text ?? '', /匿名/);
    assert.match(response.data.consent_text ?? '', /自愿/);
    assert.match(response.data.consent_text ?? '', /拒绝回答/);
  });

  test('instrument 接口无需登录即可访问', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await publishTemplatedProject(ctx, researcher.token, '匿名访问测试');
    const response = await api(ctx, 'GET', `/api/public/survey/${fixture.shareToken}/instrument`);
    assert.equal(response.status, 200);
  });

  test('无效分享令牌返回 404', async () => {
    const response = await api(ctx, 'GET', '/api/public/survey/totally-invalid-token/instrument');
    assert.equal(response.status, 404);
  });

  test('未发布的问卷无法开始作答', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await api<{ questionnaire_id: string }>(ctx, 'POST', '/api/projects', {
      token: researcher.token,
      body: { title: '未发布项目', template: 'family-edu-v4' },
    });
    const questionnaireId = project.data.questionnaire_id;
    const token = ctx.db.scalar<string>('SELECT share_token FROM questionnaires WHERE id = ?', [questionnaireId]);
    assert.equal(token, null, '未发布问卷不应有分享令牌');

    const started = await api(ctx, 'POST', '/api/public/survey/nonexistent/sessions', { body: {} });
    assert.equal(started.status, 404);
  });

  test('关闭收集后公开接口如实说明', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await publishTemplatedProject(ctx, researcher.token, '关闭收集测试');
    await api(ctx, 'POST', `/api/questionnaires/${fixture.questionnaireId}/close`, {
      token: researcher.token,
    });

    const response = await api<{ accepting_responses: boolean; message: string }>(
      ctx,
      'GET',
      `/api/public/survey/${fixture.shareToken}`,
    );
    assert.equal(response.data.accepting_responses, false);
    assert.match(response.data.message, /已结束/);

    const session = await api(ctx, 'POST', `/api/public/survey/${fixture.shareToken}/sessions`, {
      body: {},
    });
    assert.equal(session.status, 400);
  });
});

/* ================================================================== */
/* Session start                                                      */
/* ================================================================== */

describe('作答会话', () => {
  test('创建会话返回会话令牌与匿名编号 A0001', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);

    const session = await startSession(ctx, fixture.shareToken);
    assert.equal(session.anonymousId, 'A0001');
    assert.ok(session.token.length >= 20);
    assert.notEqual(session.token, session.respondentId);
  });

  test('同一问卷的匿名编号依次递增', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);

    const first = await startSession(ctx, fixture.shareToken);
    const second = await startSession(ctx, fixture.shareToken);
    const third = await startSession(ctx, fixture.shareToken);

    assert.deepEqual(
      [first.anonymousId, second.anonymousId, third.anonymousId],
      ['A0001', 'A0002', 'A0003'],
    );
  });

  test('不同问卷的匿名编号相互独立', async () => {
    const researcher = await registerResearcher(ctx);
    const a = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION], '问卷A');
    const b = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION], '问卷B');

    const sessionA = await startSession(ctx, a.shareToken);
    const sessionB = await startSession(ctx, b.shareToken);
    assert.equal(sessionA.anonymousId, 'A0001');
    assert.equal(sessionB.anonymousId, 'A0001');
  });

  test('新会话初始状态为进行中且未作答', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    const state = await api<{ respondent: { status: string; answered_count: number; consent_given_at: string } }>(
      ctx,
      'GET',
      `/api/public/sessions/${session.token}`,
    );

    assert.equal(state.data.respondent.status, 'in_progress');
    assert.equal(state.data.respondent.answered_count, 0);
    assert.ok(state.data.respondent.consent_given_at, '开始作答即记录知情同意时间');
  });

  test('不存在的会话令牌返回 404', async () => {
    const response = await api(ctx, 'GET', '/api/public/sessions/not-a-real-session-token');
    assert.equal(response.status, 404);
  });
});

/* ================================================================== */
/* Source tracking                                                    */
/* ================================================================== */

describe('来源渠道追踪', () => {
  test('记录传入的 source', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken, 'xiaohongshu');
    assert.equal(session.source, 'xiaohongshu');
  });

  test('未指定来源时记为 direct', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);
    assert.equal(session.source, 'direct');
  });

  test('非法来源被规范化为 direct，不会注入任意内容', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);

    for (const bad of ['<script>alert(1)</script>', '../../etc/passwd', 'a'.repeat(64), '带中文']) {
      const session = await startSession(ctx, fixture.shareToken, bad);
      assert.equal(session.source, 'direct', `非法来源 ${bad.slice(0, 12)} 应被规范化为 direct`);
    }
  });

  test('来源大小写与空白被规范化', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken, '  WeChat  ');
    assert.equal(session.source, 'wechat');
  });

  test('未知但合法的来源被保留，便于研究者扩展渠道', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken, 'kindergarten_2026');
    assert.equal(session.source, 'kindergarten_2026');
  });
});

/* ================================================================== */
/* Autosave and validation                                            */
/* ================================================================== */

describe('自动保存与作答校验', () => {
  test('保存合法作答并更新进度', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    const saved = await saveAnswer(ctx, session.token, 'S1', '2');
    assert.equal(saved.status, 200);
    assert.equal(saved.data.stored, '2');
    assert.equal(saved.data.answered_count, 1);
  });

  test('重复作答同一题会覆盖而不是重复插入', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    await saveAnswer(ctx, session.token, 'S1', '1');
    const second = await saveAnswer(ctx, session.token, 'S1', '2');
    assert.equal(second.data.answered_count, 1, '同一题重复作答不应增加记录数');

    const stored = ctx.db.all<{ answer: string }>(
      'SELECT answer FROM responses WHERE respondent_id = ? AND question_code = ?',
      [session.respondentId, 'S1'],
    );
    assert.equal(stored.length, 1);
    assert.equal(stored[0]!.answer, '"2"');
  });

  test('拒绝不属于该问卷的题号', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'Q999', '1');
    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /不属于该问卷/);
  });

  test('拒绝不存在的选项代码（防止写入伪造作答）', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'S1', '7');
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /选项代码 7 不属于该题/);
  });

  test('拒绝超出范围的数字作答', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION, ALL_TYPES_QUESTIONS[2]!]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '1');

    const tooBig = await saveAnswer(ctx, session.token, 'N1', 999);
    assert.equal(tooBig.status, 400);
    assert.match(JSON.stringify(tooBig.error?.details), /最大值/);

    const ok = await saveAnswer(ctx, session.token, 'N1', 12);
    assert.equal(ok.status, 200);
  });

  test('拒绝超长文本', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [TEXT_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'T1', 'x'.repeat(60));
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /上限 50/);
  });

  test('多选题拒绝互斥选项与其他选项同时选择', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [ALL_TYPES_QUESTIONS[1]!]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'M1', ['1', '9']);
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /互斥/);

    const ok = await saveAnswer(ctx, session.token, 'M1', ['1', '2']);
    assert.equal(ok.status, 200);
    assert.deepEqual(ok.data.stored, ['1', '2']);
  });

  test('多选题去重', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [ALL_TYPES_QUESTIONS[1]!]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'M1', ['1', '1', '2']);
    assert.equal(response.status, 200);
    assert.deepEqual(response.data.stored, ['1', '2']);
  });

  test('排序题拒绝重复项', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [ALL_TYPES_QUESTIONS[4]!]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'R1', ['1', '1', '2']);
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /重复/);
  });

  test('矩阵题保存行到列的映射', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [ALL_TYPES_QUESTIONS[3]!]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'X1', { '1': '3', '2': '2' });
    assert.equal(response.status, 200);
    assert.deepEqual(response.data.stored, { '1': '3', '2': '2' });
  });

  test('矩阵题拒绝不存在的行或列代码', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [ALL_TYPES_QUESTIONS[3]!]);
    const session = await startSession(ctx, fixture.shareToken);

    const badRow = await saveAnswer(ctx, session.token, 'X1', { '9': '1' });
    assert.equal(badRow.status, 400);

    const badColumn = await saveAnswer(ctx, session.token, 'X1', { '1': '9' });
    assert.equal(badColumn.status, 400);
  });

  test('清空作答会删除该题记录', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);

    await saveAnswer(ctx, session.token, 'S1', '1');
    const cleared = await saveAnswer(ctx, session.token, 'S1', null);
    assert.equal(cleared.status, 200);
    assert.equal(cleared.data.answered_count, 0);
    assert.equal(cleared.data.stored, null);
  });

  test('分页题不接受作答', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [
      { question_code: 'P1', question_text: '第一部分', question_type: 'page_break', options: {} },
      SINGLE_QUESTION,
    ]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await saveAnswer(ctx, session.token, 'P1', '1');
    assert.equal(response.status, 400);
    assert.match(JSON.stringify(response.error?.details), /不接受作答/);
  });
});

/* ================================================================== */
/* Logic integrity (the important part)                               */
/* ================================================================== */

describe('跳转逻辑完整性保障', () => {
  test('被跳过的题目无法通过接口直接作答', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, GATE_QUESTIONS);
    const session = await startSession(ctx, fixture.shareToken);

    // G1 = 从未使用 → G2 被跳过
    await saveAnswer(ctx, session.token, 'G1', '1');

    const attempt = await saveAnswer(ctx, session.token, 'G2', '3');
    assert.equal(attempt.status, 400, '不应允许绕过逻辑直接作答被跳过的题目');
    assert.match(attempt.error?.message ?? '', /不展示/);
    assert.equal(attempt.error?.details !== null && typeof attempt.error?.details === 'object' ? (attempt.error.details as { hidden?: boolean }).hidden : false, true);
  });

  test('逻辑允许时该题可以正常作答', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, GATE_QUESTIONS);
    const session = await startSession(ctx, fixture.shareToken);

    await saveAnswer(ctx, session.token, 'G1', '2'); // 使用过 → G2 显示
    const saved = await saveAnswer(ctx, session.token, 'G2', '3');
    assert.equal(saved.status, 200);
  });

  test('修改前置答案后，已失效的作答被清除（不留结构性矛盾数据）', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, GATE_QUESTIONS);
    const session = await startSession(ctx, fixture.shareToken);

    // 先走"使用过"分支并答完 G2
    await saveAnswer(ctx, session.token, 'G1', '2');
    await saveAnswer(ctx, session.token, 'G2', '3');
    await saveAnswer(ctx, session.token, 'G3', '2');
    assert.equal(
      Number(ctx.db.scalar<number>('SELECT COUNT(*) AS n FROM responses WHERE respondent_id = ?', [session.respondentId])),
      3,
    );

    // 回到 G1 改为"从未使用" → G2 不再展示，其作答必须被清除
    const changed = await saveAnswer(ctx, session.token, 'G1', '1');
    assert.equal(changed.status, 200);
    assert.deepEqual(changed.data.pruned_question_codes, ['G2']);

    const remaining = ctx.db
      .all<{ question_code: string }>(
        'SELECT question_code FROM responses WHERE respondent_id = ? ORDER BY question_code',
        [session.respondentId],
      )
      .map((row) => row.question_code);
    assert.deepEqual(remaining, ['G1', 'G3']);
  });

  test('恢复状态接口如实报告被隐藏的题目', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, GATE_QUESTIONS);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'G1', '1');

    const state = await api<{ hidden_question_codes: string[]; answers: Record<string, unknown> }>(
      ctx,
      'GET',
      `/api/public/sessions/${session.token}`,
    );
    assert.ok(state.data.hidden_question_codes.includes('G2'));
  });
});

/* ================================================================== */
/* Completion                                                         */
/* ================================================================== */

describe('提交与必答校验', () => {
  test('缺必答题时拒绝提交并列出题号', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [
      SINGLE_QUESTION,
      TEXT_QUESTION,
    ]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '1');

    const response = await submitSession(ctx, session.token);
    assert.equal(response.status, 400);
    assert.match(response.error?.message ?? '', /必答题未完成/);

    const details = response.error?.details as { field: string }[];
    assert.deepEqual(details.map((item) => item.field), ['T1']);
  });

  test('必答题齐全时提交成功并记录时长', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [
      SINGLE_QUESTION,
      TEXT_QUESTION,
    ]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '2');
    await saveAnswer(ctx, session.token, 'T1', '希望有更多社区活动');

    const response = await submitSession(ctx, session.token);
    assert.equal(response.status, 200);
    assert.equal(response.data.respondent.status, 'completed');
    assert.equal(typeof response.data.respondent.duration_seconds, 'number');
    assert.ok((response.data.respondent.duration_seconds ?? -1) >= 0);
  });

  test('非必答题未作答不影响提交', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [
      SINGLE_QUESTION,
      { ...TEXT_QUESTION, required: false },
    ]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '1');

    const response = await submitSession(ctx, session.token);
    assert.equal(response.status, 200);
    assert.equal(response.data.respondent.status, 'completed');
  });

  test('提交后不允许再修改作答', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '1');
    await submitSession(ctx, session.token);

    const response = await saveAnswer(ctx, session.token, 'S1', '2');
    assert.equal(response.status, 409);
    assert.match(response.error?.message ?? '', /已提交/);
  });

  test('重复提交是幂等的', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '1');

    const first = await submitSession(ctx, session.token);
    const second = await submitSession(ctx, session.token);
    assert.equal(first.status, 200);
    assert.equal(second.status, 200);
    assert.equal(second.data.respondent.status, 'completed');
  });

  test('未提交的会话保持进行中状态', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '1');

    const state = await api<{ respondent: { status: string } }>(
      ctx,
      'GET',
      `/api/public/sessions/${session.token}`,
    );
    assert.equal(state.data.respondent.status, 'in_progress');
  });
});

/* ================================================================== */
/* Resume                                                             */
/* ================================================================== */

describe('刷新续答', () => {
  test('使用同一会话令牌可恢复全部作答与位置', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [
      SINGLE_QUESTION,
      TEXT_QUESTION,
    ]);
    const session = await startSession(ctx, fixture.shareToken);
    await saveAnswer(ctx, session.token, 'S1', '2');
    await saveAnswer(ctx, session.token, 'T1', '正在填写中');

    // 模拟刷新：客户端重新查询会话状态
    const state = await api<{
      answers: Record<string, unknown>;
      respondent: { current_question_code: string; answered_count: number };
    }>(ctx, 'GET', `/api/public/sessions/${session.token}`);

    assert.deepEqual(state.data.answers, { S1: '2', T1: '正在填写中' });
    assert.equal(state.data.respondent.answered_count, 2);
    assert.equal(state.data.respondent.current_question_code, 'T1');
  });

  test('进度上报接口可单独记录当前题目', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [
      SINGLE_QUESTION,
      TEXT_QUESTION,
    ]);
    const session = await startSession(ctx, fixture.shareToken);

    const response = await api<{ current_question_code: string }>(
      ctx,
      'PATCH',
      `/api/public/sessions/${session.token}/progress`,
      { body: { question_code: 'T1' } },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.current_question_code, 'T1');
  });

  test('会话令牌不可用于访问其他会话', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);
    const a = await startSession(ctx, fixture.shareToken);
    const b = await startSession(ctx, fixture.shareToken);

    await saveAnswer(ctx, a.token, 'S1', '1');

    const stateA = await api<{ answers: Record<string, unknown> }>(
      ctx,
      'GET',
      `/api/public/sessions/${a.token}`,
    );
    const stateB = await api<{ answers: Record<string, unknown> }>(
      ctx,
      'GET',
      `/api/public/sessions/${b.token}`,
    );

    assert.deepEqual(stateA.data.answers, { S1: '1' });
    assert.deepEqual(stateB.data.answers, {}, '另一个会话不应看到他人作答');
  });

  test('过短的会话令牌被拒绝（不会匹配到任何记录）', async () => {
    const response = await api(ctx, 'GET', '/api/public/sessions/short');
    assert.equal(response.status, 404);
  });
});

/* ================================================================== */
/* End-to-end collection                                              */
/* ================================================================== */

describe('完整收集闭环', () => {
  test('58 题模板问卷可完整走完并进入仪表盘统计', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await publishTemplatedProject(ctx, researcher.token, '完整闭环研究');

    const instrument = await api<{
      consent_text: string;
      questions: {
        question_code: string;
        question_type: string;
        required: boolean;
        options: {
          choices?: { value: string }[];
          matrix?: { rows: { value: string }[]; columns: { value: string }[] };
        };
      }[];
    }>(ctx, 'GET', `/api/public/survey/${fixture.shareToken}/instrument`);

    assert.match(instrument.data.consent_text, /匿名/, '模板项目应带有知情同意文本');

    const byCode = new Map(instrument.data.questions.map((q) => [q.question_code, q]));
    const session = await startSession(ctx, fixture.shareToken, 'school');

    /** Answer one question with its first valid option. */
    function firstValidAnswer(question: (typeof instrument.data.questions)[number]): unknown {
      const target = byCode.get(question.question_code)!;
      if (question.question_type === 'matrix') {
        const matrix = target.options.matrix!;
        return Object.fromEntries(matrix.rows.map((row) => [row.value, matrix.columns[0]!.value]));
      }
      if (question.question_type === 'textarea' || question.question_type === 'text') {
        return '测试作答内容';
      }
      if (question.question_type === 'number') return 1;
      if (question.question_type === 'multiple') return [target.options.choices![0]!.value];
      return target.options.choices![0]!.value;
    }

    // Walk the real answer path: after every save the server tells us which
    // questions the current branch hides, so a skipped item is never attempted.
    let saved = 0;
    for (let guard = 0; guard < 200; guard += 1) {
      const state = await api<{
        answers: Record<string, unknown>;
        hidden_question_codes: string[];
      }>(ctx, 'GET', `/api/public/sessions/${session.token}`);
      const hidden = new Set(state.data.hidden_question_codes);
      const answers = state.data.answers;

      const next = instrument.data.questions.find(
        (question) =>
          question.question_type !== 'page_break' &&
          question.required &&
          !hidden.has(question.question_code) &&
          answers[question.question_code] === undefined,
      );
      if (!next) break;

      const response = await saveAnswer(
        ctx,
        session.token,
        next.question_code,
        firstValidAnswer(next),
      );
      assert.equal(
        response.status,
        200,
        `${next.question_code} 保存失败：${JSON.stringify(response.error)}`,
      );
      saved += 1;
    }

    // The V4.0 template has 55 required items; two of them (Q11 and Q40) sit
    // behind conditions that the first-option answers do not satisfy, so a
    // correct flow walk must skip them. 53 is therefore the right number — an
    // assertion of 55 would mean the skip logic had been bypassed.
    const finalState = await api<{ hidden_question_codes: string[] }>(
      ctx,
      'GET',
      `/api/public/sessions/${session.token}`,
    );
    assert.ok(
      finalState.data.hidden_question_codes.includes('Q11'),
      'Q11 应在默认路径下被隐藏（因为 Q10 选择了「从未听说」）',
    );
    assert.ok(
      finalState.data.hidden_question_codes.includes('Q40'),
      'Q40 应在默认路径下被跳过（因为 Q39 选择了「从未使用」）',
    );
    assert.equal(saved, 53, `应作答 53 道可见必答题，实际 ${saved}`);

    const submitted = await submitSession(ctx, session.token);
    assert.equal(submitted.status, 200, JSON.stringify(submitted.error));
    assert.equal(submitted.data.respondent.status, 'completed');

    // The dashboard must now reflect the real collected sample.
    const dashboard = await api<{
      collection_started: boolean;
      sample: { total: number; completed: number };
      distributions: { variable_name: string; n: number }[];
    }>(ctx, 'GET', `/api/dashboard?project_id=${fixture.projectId}`, { token: researcher.token });

    assert.equal(dashboard.data.collection_started, true);
    assert.equal(dashboard.data.sample.total, 1);
    assert.equal(dashboard.data.sample.completed, 1);

    const stage = dashboard.data.distributions.find((d) => d.variable_name === 'STAGE');
    assert.ok(stage, '仪表盘应包含 STAGE 分布');
    assert.equal(stage?.n, 1);
  });

  test('同一问卷的多份作答被分别存储且互不干扰', async () => {
    const researcher = await registerResearcher(ctx);
    const fixture = await createPublishedQuestionnaire(ctx, researcher.token, [SINGLE_QUESTION]);

    const first = await startSession(ctx, fixture.shareToken, 'wechat');
    const second = await startSession(ctx, fixture.shareToken, 'school');

    await saveAnswer(ctx, first.token, 'S1', '1');
    await saveAnswer(ctx, second.token, 'S1', '2');

    await submitSession(ctx, first.token);

    const firstState = await api<{ respondent: { status: string }; answers: Record<string, unknown> }>(
      ctx,
      'GET',
      `/api/public/sessions/${first.token}`,
    );
    const secondState = await api<{ respondent: { status: string }; answers: Record<string, unknown> }>(
      ctx,
      'GET',
      `/api/public/sessions/${second.token}`,
    );

    assert.equal(firstState.data.respondent.status, 'completed');
    assert.equal(secondState.data.respondent.status, 'in_progress');
    assert.deepEqual(firstState.data.answers, { S1: '1' });
    assert.deepEqual(secondState.data.answers, { S1: '2' });
  });
});
