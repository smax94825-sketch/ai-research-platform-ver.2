/**
 * Test environment bootstrap — MUST be the first import in a test file.
 *
 * `react-dom` performs DOM feature detection at MODULE LOAD time (for example
 * `canUseDOM`, and whether the native `input` event is supported). If it is
 * imported before a `window`/`document` exists, it caches the wrong answers and
 * its change-event handling silently stops working — simulated typing updates
 * the DOM node but never reaches React state.
 *
 * ES modules evaluate their dependencies in declaration order, so importing
 * this module first guarantees the jsdom globals are installed before
 * `react-dom` is evaluated.
 */

import { setupDom } from './dom';

setupDom();
