/**
 * Authentication context.
 *
 * Holds the researcher session for the console. The token lives in
 * localStorage and is validated on boot by calling `/api/auth/me`, so a revoked
 * or expired session is detected before any protected page renders.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { api, ApiClientError, getToken, setToken, type Researcher } from './api';

interface AuthState {
  researcher: Researcher | null;
  status: 'loading' | 'authenticated' | 'anonymous';
  error: string | null;
  login(email: string, password: string): Promise<void>;
  register(input: { name: string; email: string; password: string; affiliation?: string }): Promise<void>;
  logout(): Promise<void>;
  clearError(): void;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }): ReactNode {
  const [researcher, setResearcher] = useState<Researcher | null>(null);
  const [status, setStatus] = useState<AuthState['status']>('loading');
  const [error, setError] = useState<string | null>(null);

  // Bootstrap: if a token exists, confirm it still works.
  useEffect(() => {
    let cancelled = false;

    async function bootstrap(): Promise<void> {
      if (!getToken()) {
        if (!cancelled) setStatus('anonymous');
        return;
      }
      try {
        const me = await api.auth.me();
        if (cancelled) return;
        setResearcher(me);
        setStatus('authenticated');
      } catch {
        if (cancelled) return;
        // Expired or revoked — drop it and show the login screen.
        setToken(null);
        setResearcher(null);
        setStatus('anonymous');
      }
    }

    void bootstrap();
    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setError(null);
    try {
      const result = await api.auth.login({ email, password });
      setToken(result.token);
      setResearcher(result.researcher);
      setStatus('authenticated');
    } catch (err) {
      const message =
        err instanceof ApiClientError ? err.message : '登录失败，请稍后重试。';
      setError(message);
      throw err;
    }
  }, []);

  const register = useCallback(
    async (input: { name: string; email: string; password: string; affiliation?: string }) => {
      setError(null);
      try {
        const result = await api.auth.register(input);
        setToken(result.token);
        setResearcher(result.researcher);
        setStatus('authenticated');
      } catch (err) {
        const message =
          err instanceof ApiClientError ? err.message : '注册失败，请稍后重试。';
        setError(message);
        throw err;
      }
    },
    [],
  );

  const logout = useCallback(async () => {
    try {
      await api.auth.logout();
    } catch {
      // Even if the server call fails, clear local state: the user asked to leave.
    }
    setToken(null);
    setResearcher(null);
    setStatus('anonymous');
  }, []);

  const value = useMemo<AuthState>(
    () => ({
      researcher,
      status,
      error,
      login,
      register,
      logout,
      clearError: () => setError(null),
    }),
    [researcher, status, error, login, register, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used inside <AuthProvider>');
  return context;
}
