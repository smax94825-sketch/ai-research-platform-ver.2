/**
 * Descriptive statistics and reliability (PHASE 5).
 *
 * Descriptive reporting follows the same rule as everywhere else in the
 * platform: a statistic that cannot be computed is reported as `null` with an
 * explicit reason, never as 0.
 */

import type { Question } from '../types.js';
import type { Dataset, DatasetVariable } from './dataset.js';
import { completeCases } from './dataset.js';
import { roundTo } from './special.js';
import { pearsonCorrelation } from './matrix.js';

/* ------------------------------------------------------------------ */
/* Descriptive                                                        */
/* ------------------------------------------------------------------ */

export interface FrequencyRow {
  value: string;
  label: string;
  count: number;
  /** Percentage of respondents with a valid (non-missing) answer. */
  percent: number;
  /** Percentage including missing cases in the denominator. */
  percent_of_total: number;
}

export interface DescriptiveStats {
  variable: string;
  label: string;
  dimension: string;
  question_code: string;
  data_type: DatasetVariable['data_type'];
  /** Valid (non-missing) count. */
  n: number;
  missing: number;
  /** Percentage of the dataset that is missing for this variable. */
  missing_percent: number;
  mean: number | null;
  median: number | null;
  standard_deviation: number | null;
  standard_error: number | null;
  variance: number | null;
  minimum: number | null;
  maximum: number | null;
  range: number | null;
  q1: number | null;
  q3: number | null;
  iqr: number | null;
  skewness: number | null;
  kurtosis: number | null;
  /** Present only for variables with option labels. */
  frequencies: FrequencyRow[] | null;
}

function quantile(sorted: number[], p: number): number | null {
  if (sorted.length === 0) return null;
  if (sorted.length === 1) return sorted[0]!;
  const position = (sorted.length - 1) * p;
  const lower = Math.floor(position);
  const upper = Math.ceil(position);
  if (lower === upper) return sorted[lower]!;
  const weight = position - lower;
  return sorted[lower]! * (1 - weight) + sorted[upper]! * weight;
}

/**
 * Skewness and excess kurtosis.
 *
 * Uses the sample-corrected (Fisher) definitions that SPSS reports, so numbers
 * from this engine line up with the output a researcher already has.
 */
export function moments(values: number[]): { skewness: number | null; kurtosis: number | null } {
  const n = values.length;
  if (n < 3) return { skewness: null, kurtosis: null };

  const mean = values.reduce((sum, value) => sum + value, 0) / n;
  let m2 = 0;
  let m3 = 0;
  let m4 = 0;
  for (const value of values) {
    const deviation = value - mean;
    m2 += deviation ** 2;
    m3 += deviation ** 3;
    m4 += deviation ** 4;
  }
  m2 /= n;
  m3 /= n;
  m4 /= n;

  if (m2 === 0) return { skewness: null, kurtosis: null };

  const g1 = m3 / m2 ** 1.5;
  const g2 = m4 / m2 ** 2 - 3;

  // Sample-corrected versions.
  const skewness = (Math.sqrt(n * (n - 1)) / (n - 2)) * g1;
  const kurtosis = ((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * g2 + 6);
  return { skewness: roundTo(skewness, 4), kurtosis: roundTo(kurtosis, 4) };
}

export function describeVariable(
  variable: DatasetVariable,
  totalRespondents: number,
): DescriptiveStats {
  const present = variable.values.filter((value): value is number => value !== null);
  const missing = variable.values.length - present.length;
  const n = present.length;
  const sorted = [...present].sort((a, b) => a - b);

  // Nominal categories are labels, not quantities. Averaging the codes, taking
  // percentiles of them, or measuring their skewness would all produce numbers
  // that look interpretable and are not: the result would change if the options
  // were renumbered. Only the count and the frequency distribution are reported.
  const nominal = variable.data_type === 'nominal';

  const mean = nominal || n === 0 ? null : present.reduce((sum, value) => sum + value, 0) / n;
  const variance =
    !nominal && n > 1 && mean !== null
      ? present.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (n - 1)
      : null;
  const standardDeviation = variance === null ? null : Math.sqrt(variance);
  const { skewness, kurtosis } = nominal ? { skewness: null, kurtosis: null } : moments(present);

  let frequencies: FrequencyRow[] | null = null;
  if (Object.keys(variable.value_labels).length > 0) {
    const counts = new Map<string, number>();
    for (const raw of variable.raw) {
      if (raw === null || raw === undefined || String(raw).trim() === '') continue;
      const code = String(raw);
      // Matrix rows are stored per row; only scalar answers form a frequency table.
      if (code.startsWith('{') || code.startsWith('[')) continue;
      counts.set(code, (counts.get(code) ?? 0) + 1);
    }
    const validTotal = [...counts.values()].reduce((sum, count) => sum + count, 0);
    frequencies = Object.entries(variable.value_labels).map(([code, label]) => {
      const count = counts.get(code) ?? 0;
      return {
        value: code,
        label,
        count,
        percent: validTotal > 0 ? roundTo((count / validTotal) * 100, 2) : 0,
        percent_of_total:
          totalRespondents > 0 ? roundTo((count / totalRespondents) * 100, 2) : 0,
      };
    });
  }

  return {
    variable: variable.name,
    label: variable.label,
    dimension: variable.dimension,
    question_code: variable.question_code,
    data_type: variable.data_type,
    n,
    missing,
    missing_percent:
      variable.values.length > 0 ? roundTo((missing / variable.values.length) * 100, 2) : 0,
    mean: mean === null ? null : roundTo(mean, 4),
    median: nominal || quantile(sorted, 0.5) === null ? null : roundTo(quantile(sorted, 0.5)!, 4),
    standard_deviation: standardDeviation === null ? null : roundTo(standardDeviation, 4),
    standard_error:
      standardDeviation === null || n === 0 ? null : roundTo(standardDeviation / Math.sqrt(n), 4),
    variance: variance === null ? null : roundTo(variance, 4),
    minimum: !nominal && n > 0 ? sorted[0]! : null,
    maximum: !nominal && n > 0 ? sorted[n - 1]! : null,
    range: !nominal && n > 0 ? roundTo(sorted[n - 1]! - sorted[0]!, 4) : null,
    q1: nominal || quantile(sorted, 0.25) === null ? null : roundTo(quantile(sorted, 0.25)!, 4),
    q3: nominal || quantile(sorted, 0.75) === null ? null : roundTo(quantile(sorted, 0.75)!, 4),
    iqr:
      nominal || quantile(sorted, 0.75) === null || quantile(sorted, 0.25) === null
        ? null
        : roundTo(quantile(sorted, 0.75)! - quantile(sorted, 0.25)!, 4),
    skewness,
    kurtosis,
    frequencies,
  };
}

export interface DescriptiveReport {
  n_respondents: number;
  variables: DescriptiveStats[];
  /** Variables with no usable values, listed so their absence is visible. */
  unusable_variables: { variable: string; reason: string }[];
  note: string;
}

export function describeDataset(
  dataset: Dataset,
  variableNames?: string[],
): DescriptiveReport {
  const selected = variableNames
    ? dataset.variables.filter((variable) => variableNames.includes(variable.name))
    : dataset.variables;

  const variables = selected
    .filter((variable) => variable.data_type !== 'text')
    .map((variable) => describeVariable(variable, dataset.n_respondents));

  const unusable = variables
    .filter((stats) => stats.n === 0)
    .map((stats) => ({ variable: stats.variable, reason: '该变量没有任何有效作答' }));

  return {
    n_respondents: dataset.n_respondents,
    variables,
    unusable_variables: unusable,
    note:
      '描述统计仅基于有效作答计算；缺失值不参与均值、标准差等计算，也不进行插补。' +
      '单选/李克特/矩阵题的分组频数按有效作答计算百分比（percent），并同时给出占全部样本的比例（percent_of_total）。',
  };
}

/* ------------------------------------------------------------------ */
/* Reliability                                                        */
/* ------------------------------------------------------------------ */

export interface ReliabilityItemStats {
  item: string;
  label: string;
  /** Item mean over cases used in the analysis. */
  mean: number;
  standard_deviation: number;
  /** Corrected item–total correlation (item excluded from the total). */
  item_total_correlation: number | null;
  /** Cronbach's α if this item were removed. */
  alpha_if_deleted: number | null;
  /** Number of cases contributing to this item's statistics. */
  n: number;
}

export interface ReliabilityResult {
  scale: string;
  label: string;
  dimension: string;
  items: ReliabilityItemStats[];
  /** Number of items in the scale. */
  k: number;
  /** Cases with complete data on every item. */
  n: number;
  dropped: number;
  cronbach_alpha: number | null;
  /** Standardized alpha (based on the mean inter-item correlation). */
  standardized_alpha: number | null;
  mean_inter_item_correlation: number | null;
  /** Scale-level descriptive statistics. */
  scale_mean: number | null;
  scale_standard_deviation: number | null;
  /** Plain-language reading of alpha, with the caveat attached. */
  interpretation: string;
  /** Values below this would indicate a problem; reported so the reader can judge. */
  alpha_reference: { excellent: number; good: number; acceptable: number; questionable: number };
  warnings: string[];
}

/** Cronbach's α from the item covariance structure. */
export function cronbachAlpha(columns: number[][]): number | null {
  const k = columns.length;
  const n = columns[0]?.length ?? 0;
  if (k < 2 || n < 2) return null;

  const itemVariances = columns.map((column) => sampleVariance(column));
  const totals = Array.from({ length: n }, (_, index) =>
    columns.reduce((sum, column) => sum + column[index]!, 0),
  );
  const totalVariance = sampleVariance(totals);

  if (totalVariance === 0) return null;
  const sumItemVariances = itemVariances.reduce((sum, value) => sum + value, 0);
  return (k / (k - 1)) * (1 - sumItemVariances / totalVariance);
}

function sampleVariance(values: number[]): number {
  const n = values.length;
  if (n < 2) return 0;
  const mean = values.reduce((sum, value) => sum + value, 0) / n;
  return values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (n - 1);
}

function interpretAlpha(alpha: number | null, k: number, n: number): string {
  if (alpha === null) {
    return '样本量或题目数不足，无法计算信度系数。';
  }
  const base =
    alpha >= 0.9
      ? '内部一致性很高'
      : alpha >= 0.8
        ? '内部一致性较好'
        : alpha >= 0.7
          ? '内部一致性可接受'
          : alpha >= 0.6
            ? '内部一致性偏低，建议谨慎使用'
            : '内部一致性不足，不建议将各题合并为单一维度';
  return (
    `${base}（α = ${roundTo(alpha, 3)}，${k} 个条目，n = ${n}）。` +
    '注意：α 只反映内部一致性，并不等于量表有效，也不证明单维性；' +
    '高 α 也可能来自题目高度重复。建议结合内容效度与因素分析共同判断。'
  );
}

/**
 * Cronbach's α for one scale, with item-level diagnostics.
 *
 * Cases are selected listwise across the scale's items, so α is computed on a
 * single consistent sample — computing items on different subsets would make the
 * coefficient uninterpretable.
 */
export function reliabilityOfScale(
  dataset: Dataset,
  itemNames: string[],
  meta: { scale: string; label: string; dimension: string },
): ReliabilityResult {
  const warnings: string[] = [];
  const available = itemNames.filter((name) => dataset.by_name.has(name));
  const missingItems = itemNames.filter((name) => !dataset.by_name.has(name));

  if (missingItems.length > 0) {
    warnings.push(`以下条目在本问卷中不存在，已排除：${missingItems.join('、')}。`);
  }
  if (available.length < 2) {
    return {
      scale: meta.scale,
      label: meta.label,
      dimension: meta.dimension,
      items: [],
      k: available.length,
      n: 0,
      dropped: 0,
      cronbach_alpha: null,
      standardized_alpha: null,
      mean_inter_item_correlation: null,
      scale_mean: null,
      scale_standard_deviation: null,
      interpretation: '可用条目少于 2 个，无法计算内部一致性信度。',
      alpha_reference: { excellent: 0.9, good: 0.8, acceptable: 0.7, questionable: 0.6 },
      warnings,
    };
  }

  const selection = completeCases(dataset, available);
  const { columns, n, dropped } = selection;

  if (n < 2) {
    return {
      scale: meta.scale,
      label: meta.label,
      dimension: meta.dimension,
      items: [],
      k: available.length,
      n,
      dropped,
      cronbach_alpha: null,
      standardized_alpha: null,
      mean_inter_item_correlation: null,
      scale_mean: null,
      scale_standard_deviation: null,
      interpretation: '整例删除后有效样本不足 2 例，无法计算信度系数。',
      alpha_reference: { excellent: 0.9, good: 0.8, acceptable: 0.7, questionable: 0.6 },
      warnings,
    };
  }

  const alpha = cronbachAlpha(columns);

  // Standardized alpha from the mean inter-item correlation.
  let correlationSum = 0;
  let correlationCount = 0;
  for (let i = 0; i < columns.length; i += 1) {
    for (let j = i + 1; j < columns.length; j += 1) {
      const r = pearsonCorrelation(columns[i]!, columns[j]!);
      if (Number.isFinite(r)) {
        correlationSum += r;
        correlationCount += 1;
      }
    }
  }
  const meanR = correlationCount > 0 ? correlationSum / correlationCount : null;
  const standardizedAlpha =
    meanR === null || meanR <= -1 / (columns.length - 1)
      ? null
      : (columns.length * meanR) / (1 + (columns.length - 1) * meanR);

  const items: ReliabilityItemStats[] = available.map((name, index) => {
    const column = columns[index]!;
    const others = columns.filter((_, other) => other !== index);
    const restScores = Array.from({ length: n }, (_, caseIndex) =>
      others.reduce((sum, other) => sum + other[caseIndex]!, 0),
    );
    const r = pearsonCorrelation(column, restScores);
    const alphaWithout = others.length >= 2 ? cronbachAlpha(others) : null;
    const variable = dataset.by_name.get(name);

    return {
      item: name,
      label: variable?.label ?? name,
      mean: roundTo(column.reduce((sum, value) => sum + value, 0) / n, 4),
      standard_deviation: roundTo(Math.sqrt(sampleVariance(column)), 4),
      item_total_correlation: Number.isFinite(r) ? roundTo(r, 4) : null,
      alpha_if_deleted: alphaWithout === null ? null : roundTo(alphaWithout, 4),
      n,
    };
  });

  // Diagnostics that a researcher should see rather than have to hunt for.
  for (const item of items) {
    if (item.item_total_correlation !== null && item.item_total_correlation < 0.3) {
      warnings.push(
        `条目 ${item.item} 的校正后题总相关为 ${item.item_total_correlation}，低于 0.30，` +
          '提示该条目与量表整体关系较弱，建议检查其内容是否与维度一致。',
      );
    }
    if (
      alpha !== null &&
      item.alpha_if_deleted !== null &&
      item.alpha_if_deleted > alpha + 0.05
    ) {
      warnings.push(
        `删除条目 ${item.item} 可将 α 从 ${roundTo(alpha, 3)} 提升至 ${item.alpha_if_deleted}，` +
          '但这会改变量表内容，需先判断该条目在理论上是否不可或缺。',
      );
    }
  }

  const totals = Array.from({ length: n }, (_, index) =>
    columns.reduce((sum, column) => sum + column[index]!, 0),
  );

  return {
    scale: meta.scale,
    label: meta.label,
    dimension: meta.dimension,
    items,
    k: available.length,
    n,
    dropped,
    cronbach_alpha: alpha === null ? null : roundTo(alpha, 4),
    standardized_alpha: standardizedAlpha === null ? null : roundTo(standardizedAlpha, 4),
    mean_inter_item_correlation: meanR === null ? null : roundTo(meanR, 4),
    scale_mean: roundTo(totals.reduce((sum, value) => sum + value, 0) / n, 4),
    scale_standard_deviation: roundTo(Math.sqrt(sampleVariance(totals)), 4),
    interpretation: interpretAlpha(alpha, available.length, n),
    alpha_reference: { excellent: 0.9, good: 0.8, acceptable: 0.7, questionable: 0.6 },
    warnings,
  };
}

export interface ReliabilityReport {
  scales: ReliabilityResult[];
  note: string;
}

/**
 * Resolve a scale's question codes to the item variables that carry them.
 *
 * A single question yields one item; a matrix question yields one item per row
 * (its derived mean is deliberately NOT used, otherwise the dimension mean would
 * be treated as an extra item and inflate α).
 */
export function resolveScaleItems(dataset: Dataset, questionCodes: string[]): string[] {
  const names: string[] = [];
  for (const code of questionCodes) {
    const items = dataset.variables.filter(
      (variable) => variable.question_code === code && !variable.is_derived,
    );
    for (const item of items) if (!names.includes(item.name)) names.push(item.name);
  }
  return names;
}

export function reliabilityReport(dataset: Dataset): ReliabilityReport {
  const scales = dataset.scales
    .map((scale) =>
      reliabilityOfScale(dataset, resolveScaleItems(dataset, scale.question_codes), {
        scale: scale.variable_name,
        label: scale.label,
        dimension: scale.dimension,
      }),
    )
    .filter((result) => result.k > 0);

  return {
    scales,
    note:
      '信度分析采用 Cronbach\'s α，基于整例删除后的完整样本计算，并在条目层面给出校正后题总相关与「删除该条目后的 α」。' +
      'α 反映内部一致性，不构成效度证据，也不证明量表单维。',
  };
}
