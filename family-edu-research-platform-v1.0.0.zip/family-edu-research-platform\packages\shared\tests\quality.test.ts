/**
 * Data quality rule tests (PHASE 4).
 *
 * The engine's whole purpose is to be trustworthy, so the tests pin both
 * directions: rules must fire on the patterns they claim to detect, and must
 * NOT fire on legitimate data. A rule that flags honest respondents is worse
 * than no rule at all.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  DEFAULT_QUALITY_THRESHOLDS,
  QUALITY_RULES,
  QUALITY_RULE_ORDER,
  answerSignature,
  bucketQualityScores,
  evaluateQuality,
  longestAlternatingRun,
  longestIdenticalRun,
  scaleItemSequence,
  scoreFromFindings,
  type AnswerMap,
  type Question,
  type QuestionOption,
} from '../src/index.js';

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

const AGREE_5: QuestionOption[] = [
  { value: '1', label: '非常不同意', score: 1 },
  { value: '2', label: '比较不同意', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较同意', score: 4 },
  { value: '5', label: '非常同意', score: 5 },
];

function makeQuestion(overrides: Partial<Question> & { question_code: string }): Question {
  return {
    id: `id-${overrides.question_code}`,
    questionnaire_id: 'qn-1',
    question_text: `题目 ${overrides.question_code}`,
    question_type: 'likert',
    options: { choices: AGREE_5, scaleMin: 1, scaleMax: 5 },
    required: true,
    dimension: null,
    variable_name: null,
    sort_order: Number(overrides.question_code.replace(/\D/g, '')) || 1,
    section: null,
    help_text: null,
    logic: null,
    scoring_rule: { type: 'mean', min: 1, max: 5 },
    created_at: '2026-01-01T00:00:00.000Z',
    updated_at: '2026-01-01T00:00:00.000Z',
    ...overrides,
  } as Question;
}

/** N consecutive Likert items, codes L1..Ln. */
function likertBlock(count: number, startOrder = 1): Question[] {
  return Array.from({ length: count }, (_, index) =>
    makeQuestion({
      question_code: `L${startOrder + index}`,
      sort_order: startOrder + index,
    }),
  );
}

function answersFrom(questions: Question[], codeFor: (index: number) => string): AnswerMap {
  const answers: AnswerMap = {};
  questions.forEach((question, index) => {
    answers[question.question_code] = codeFor(index);
  });
  return answers;
}

/* ================================================================== */
/* Thresholds and catalogue                                           */
/* ================================================================== */

describe('规则目录', () => {
  test('覆盖规格要求的全部检测项', () => {
    for (const code of [
      'SUSPICIOUS_SPEED',
      'LONG_STRING',
      'HIGH_MISSING',
      'SUBJECTIVE_OBJECTIVE_DISCREPANCY',
      'DUPLICATE_SUBMISSION',
      'MATRIX_STRAIGHT_LINE',
      'ALTERNATING_PATTERN',
    ]) {
      assert.ok(code in QUALITY_RULES, `缺少规则 ${code}`);
    }
  });

  test('每条规则都说明检测内容、解读方式与扣分权重', () => {
    for (const rule of Object.values(QUALITY_RULES)) {
      assert.ok(rule.label.length > 0, `${rule.code} 缺少名称`);
      assert.ok(rule.description.length > 0, `${rule.code} 缺少检测说明`);
      assert.ok(rule.interpretation.length > 0, `${rule.code} 缺少解读说明`);
      assert.ok(rule.scoreImpact > 0, `${rule.code} 的扣分权重应为正数`);
      assert.ok(rule.scoreImpact <= 40, `${rule.code} 的扣分权重过高，会使单项规则一票否决`);
    }
  });

  test('每条规则的解读都提示了可能的误判情形', () => {
    // Honest respondents must not be silently condemned by the copy.
    for (const rule of Object.values(QUALITY_RULES)) {
      assert.ok(
        /但|需注意|需谨慎|不等于|也可能|本身/.test(rule.interpretation),
        `${rule.code} 的解读未提示局限性`,
      );
    }
  });

  test('规则顺序稳定且覆盖所有规则', () => {
    assert.equal(QUALITY_RULE_ORDER.length, Object.keys(QUALITY_RULES).length);
    for (const code of Object.keys(QUALITY_RULES)) {
      assert.ok(QUALITY_RULE_ORDER.includes(code as never), `${code} 未出现在报告顺序中`);
    }
  });

  test('敏感题拒答不是一条质量规则（拒答是受访者的权利）', () => {
    const codes = Object.keys(QUALITY_RULES).join(' ');
    assert.ok(!/REFUS|SENSITIVE|拒答/i.test(codes), '不得把敏感题拒答当作低质量信号');
  });
});

/* ================================================================== */
/* Sequence helpers                                                   */
/* ================================================================== */

describe('量表条目序列', () => {
  test('矩阵题按行展开为独立条目', () => {
    const matrix = makeQuestion({
      question_code: 'M1',
      question_type: 'matrix',
      options: {
        matrix: {
          rows: [
            { value: '1', label: '行一' },
            { value: '2', label: '行二' },
            { value: '3', label: '行三' },
          ],
          columns: AGREE_5,
        },
      },
    });

    const items = scaleItemSequence([matrix], { M1: { '1': '3', '2': '3', '3': '4' } });
    assert.equal(items.length, 3, '矩阵的每一行都应成为一个条目');
    assert.deepEqual(
      items.map((item) => item.key),
      ['M1.1', 'M1.2', 'M1.3'],
    );
    assert.deepEqual(
      items.map((item) => item.code),
      ['3', '3', '4'],
    );
  });

  test('未作答的题目与行不计入序列', () => {
    const questions = likertBlock(3);
    const answers: AnswerMap = { L1: '3', L3: '5' };
    const items = scaleItemSequence(questions, answers);
    assert.deepEqual(
      items.map((item) => item.questionCode),
      ['L1', 'L3'],
    );
  });

  test('被逻辑隐藏的题目不计入序列', () => {
    const questions = [
      makeQuestion({ question_code: 'L1', sort_order: 1 }),
      makeQuestion({
        question_code: 'L2',
        sort_order: 2,
        logic: {
          rules: [
            {
              id: 'r1',
              conditions: [{ questionCode: 'L1', operator: 'eq', value: '1' }],
              action: { type: 'show' },
            },
          ],
        },
      }),
    ];
    const items = scaleItemSequence(questions, { L1: '5', L2: '3' });
    assert.deepEqual(
      items.map((item) => item.questionCode),
      ['L1'],
      '被隐藏题目的作答不应参与模式检测',
    );
  });

  test('文本题与多选题不进入量表序列', () => {
    const questions = [
      makeQuestion({ question_code: 'L1', sort_order: 1 }),
      makeQuestion({ question_code: 'T1', question_type: 'textarea', sort_order: 2, options: {} }),
      makeQuestion({ question_code: 'M1', question_type: 'multiple', sort_order: 3, options: { choices: AGREE_5 } }),
    ];
    const items = scaleItemSequence(questions, { L1: '3', T1: '文本', M1: ['1', '2'] });
    assert.deepEqual(
      items.map((item) => item.questionCode),
      ['L1'],
    );
  });
});

describe('连续同选项检测', () => {
  test('找出最长相同序列', () => {
    const items = ['1', '2', '2', '2', '3', '1'].map((code, index) => ({
      key: `k${index}`,
      questionCode: `Q${index}`,
      code,
    }));
    const run = longestIdenticalRun(items);
    assert.equal(run.length, 3);
    assert.equal(run.code, '2');
    assert.equal(run.start, 1);
  });

  test('全相同时返回整体长度', () => {
    const items = Array.from({ length: 25 }, (_, index) => ({
      key: `k${index}`,
      questionCode: `Q${index}`,
      code: '4',
    }));
    assert.equal(longestIdenticalRun(items).length, 25);
  });

  test('空序列返回 0', () => {
    assert.equal(longestIdenticalRun([]).length, 0);
  });
});

describe('交替模式检测', () => {
  test('识别 A-B-A-B 交替', () => {
    const items = ['1', '5', '1', '5', '1', '5', '1', '5'].map((code, index) => ({
      key: `k${index}`,
      questionCode: `Q${index}`,
      code,
    }));
    assert.equal(longestAlternatingRun(items).length, 8);
  });

  test('不会把仅两项的重复当作交替', () => {
    const items = ['1', '5'].map((code, index) => ({
      key: `k${index}`,
      questionCode: `Q${index}`,
      code,
    }));
    assert.ok(longestAlternatingRun(items).length < 3);
  });

  test('随机作答不产生长交替', () => {
    const items = ['1', '2', '2', '3', '1', '1', '4', '5', '2'].map((code, index) => ({
      key: `k${index}`,
      questionCode: `Q${index}`,
      code,
    }));
    assert.ok(longestAlternatingRun(items).length < 4);
  });
});

/* ================================================================== */
/* Individual rules                                                   */
/* ================================================================== */

describe('完成时间过短', () => {
  test('总用时低于阈值时触发', () => {
    const questions = likertBlock(20);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => ['1', '2', '3', '4', '5'][i % 5]!),
      durationSeconds: 40,
      minDurationSeconds: 90,
    });
    const finding = result.findings.find((f) => f.code === 'SUSPICIOUS_SPEED');
    assert.ok(finding, '应检出完成时间过短');
    assert.match(finding.detail, /低于最短时长 90 秒/);
    assert.equal(finding.severity, 'critical');
  });

  test('平均每题用时过低时同样触发', () => {
    const questions = likertBlock(60);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => ['1', '2', '3', '4', '5'][i % 5]!),
      durationSeconds: 100, // 60 题 / 100 秒 ≈ 1.67 秒每题
      minDurationSeconds: 90,
    });
    const finding = result.findings.find((f) => f.code === 'SUSPICIOUS_SPEED');
    assert.ok(finding, '平均每题用时过低也应触发');
    assert.match(finding.detail, /平均每题/);
  });

  test('正常用时不会触发', () => {
    const questions = likertBlock(20);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => ['1', '2', '3', '4', '5'][i % 5]!),
      durationSeconds: 400,
      minDurationSeconds: 90,
    });
    assert.ok(!result.findings.some((f) => f.code === 'SUSPICIOUS_SPEED'));
  });

  test('未完成的会话跳过该规则并说明原因', () => {
    const questions = likertBlock(5);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '3'),
      durationSeconds: null,
    });
    assert.ok(!result.findings.some((f) => f.code === 'SUSPICIOUS_SPEED'));
    assert.ok(
      result.skipped.some((item) => item.code === 'SUSPICIOUS_SPEED'),
      '未运行的原因必须如实报告',
    );
  });
});

describe('连续同选项作答', () => {
  test('连续 20 项相同触发', () => {
    const questions = likertBlock(25);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '4'),
      durationSeconds: 500,
    });
    const finding = result.findings.find((f) => f.code === 'LONG_STRING');
    assert.ok(finding, '应检出长串相同作答');
    assert.equal(finding.evidence['run_length'], 25);
  });

  test('19 项相同（阈值 20）不触发', () => {
    const questions = likertBlock(19);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '4'),
      durationSeconds: 500,
    });
    assert.ok(!result.findings.some((f) => f.code === 'LONG_STRING'));
  });

  test('真实作答变化不触发', () => {
    const questions = likertBlock(30);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => String((i % 5) + 1)),
      durationSeconds: 600,
    });
    assert.ok(
      !result.findings.some((f) => f.code === 'LONG_STRING'),
      '正常变化的作答不应被判定为机械作答',
    );
  });
});

describe('缺失率过高', () => {
  test('缺失率超过 20% 触发', () => {
    const questions = likertBlock(10);
    const answers: AnswerMap = {};
    questions.slice(0, 7).forEach((question) => {
      answers[question.question_code] = ['1', '2', '3'][Object.keys(answers).length % 3]!;
    });
    const result = evaluateQuality({ questions, answers, durationSeconds: 300 });
    const finding = result.findings.find((f) => f.code === 'HIGH_MISSING');
    assert.ok(finding, '30% 缺失应触发');
    assert.match(finding.detail, /缺失率 30.0%/);
  });

  test('缺失率恰好 20% 不触发（阈值边界）', () => {
    const questions = likertBlock(10);
    const answers: AnswerMap = {};
    questions.slice(0, 8).forEach((question, index) => {
      answers[question.question_code] = String((index % 5) + 1);
    });
    const result = evaluateQuality({ questions, answers, durationSeconds: 300 });
    assert.ok(!result.findings.some((f) => f.code === 'HIGH_MISSING'));
  });

  test('因条件跳转而未展示的题目不计入缺失', () => {
    const questions = [
      makeQuestion({ question_code: 'L1', sort_order: 1 }),
      makeQuestion({
        question_code: 'L2',
        sort_order: 2,
        logic: {
          rules: [
            {
              id: 'hide-l2',
              conditions: [{ questionCode: 'L1', operator: 'eq', value: '1' }],
              action: { type: 'hide' },
            },
          ],
        },
      }),
    ];
    const result = evaluateQuality({
      questions,
      answers: { L1: '1' },
      durationSeconds: 300,
    });
    assert.equal(result.stats.administered, 1, '被隐藏的题目不应计入展示题数');
    assert.equal(result.stats.missing_rate, 0);
    assert.ok(!result.findings.some((f) => f.code === 'HIGH_MISSING'));
  });
});

describe('矩阵题整列同一选项', () => {
  function matrixQuestion(code = 'M1'): Question {
    return makeQuestion({
      code,
      question_code: code,
      question_type: 'matrix',
      options: {
        matrix: {
          rows: Array.from({ length: 6 }, (_, index) => ({ value: String(index + 1), label: `行${index + 1}` })),
          columns: AGREE_5,
        },
      },
    } as never);
  }

  test('6 行全部相同触发', () => {
    const matrix = matrixQuestion();
    const answers: AnswerMap = {
      M1: Object.fromEntries(Array.from({ length: 6 }, (_, i) => [String(i + 1), '3'])),
    };
    const result = evaluateQuality({ questions: [matrix], answers, durationSeconds: 300 });
    const finding = result.findings.find((f) => f.code === 'MATRIX_STRAIGHT_LINE');
    assert.ok(finding, '应检出矩阵整列同选项');
    assert.match(finding.detail, /M1/);
  });

  test('各行有变化时不触发', () => {
    const matrix = matrixQuestion();
    const answers: AnswerMap = {
      M1: Object.fromEntries(Array.from({ length: 6 }, (_, i) => [String(i + 1), String((i % 5) + 1)])),
    };
    const result = evaluateQuality({ questions: [matrix], answers, durationSeconds: 300 });
    assert.ok(!result.findings.some((f) => f.code === 'MATRIX_STRAIGHT_LINE'));
  });

  test('行数少于阈值时不触发', () => {
    const small = makeQuestion({
      question_code: 'M2',
      question_type: 'matrix',
      options: {
        matrix: {
          rows: [
            { value: '1', label: '行1' },
            { value: '2', label: '行2' },
          ],
          columns: AGREE_5,
        },
      },
    });
    const result = evaluateQuality({
      questions: [small],
      answers: { M2: { '1': '3', '2': '3' } },
      durationSeconds: 300,
    });
    assert.ok(!result.findings.some((f) => f.code === 'MATRIX_STRAIGHT_LINE'));
  });
});

describe('主客观知识矛盾', () => {
  function knowledgeFixture(): Question[] {
    return [
      makeQuestion({
        question_code: 'Q9',
        question_type: 'likert',
        variable_name: 'FEK',
        sort_order: 1,
        options: {
          choices: [
            { value: '1', label: '非常不了解', score: 1 },
            { value: '2', label: '比较不了解', score: 2 },
            { value: '3', label: '一般', score: 3 },
            { value: '4', label: '比较了解', score: 4 },
            { value: '5', label: '非常了解', score: 5 },
          ],
        },
      }),
      makeQuestion({
        question_code: 'Q12',
        question_type: 'knowledge_test',
        variable_name: 'LKA1',
        sort_order: 2,
        options: {
          choices: [
            { value: '1', label: '正确', isCorrect: true },
            { value: '2', label: '错误' },
            { value: '3', label: '不清楚' },
          ],
        },
        scoring_rule: { type: 'knowledge', correctScore: 1, incorrectScore: 0, unknownScore: 0, maxScore: 1 },
      }),
      makeQuestion({
        question_code: 'Q13',
        question_type: 'knowledge_test',
        variable_name: 'LKA2',
        sort_order: 3,
        options: {
          choices: [
            { value: '1', label: '正确', isCorrect: true },
            { value: '2', label: '错误' },
            { value: '3', label: '不清楚' },
          ],
        },
        scoring_rule: { type: 'knowledge', correctScore: 1, incorrectScore: 0, unknownScore: 0, maxScore: 1 },
      }),
    ];
  }

  test('自认为了解但客观全错时触发', () => {
    const questions = knowledgeFixture();
    const result = evaluateQuality({
      questions,
      answers: { Q9: '5', Q12: '2', Q13: '2' },
      durationSeconds: 300,
    });
    const finding = result.findings.find((f) => f.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY');
    assert.ok(finding, '应检出自评与客观知识的差距');
    assert.match(finding.detail, /自评了解程度 5\/5/);
    assert.match(finding.detail, /0\/2/);
    assert.equal(finding.severity, 'info', '该模式反映认知差距，不应作为严重质量问题');
  });

  test('自评低且客观得分低时不触发（认知一致）', () => {
    const questions = knowledgeFixture();
    const result = evaluateQuality({
      questions,
      answers: { Q9: '2', Q12: '2', Q13: '2' },
      durationSeconds: 300,
    });
    assert.ok(!result.findings.some((f) => f.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'));
  });

  test('自评高且客观得分高时不触发', () => {
    const questions = knowledgeFixture();
    const result = evaluateQuality({
      questions,
      answers: { Q9: '5', Q12: '1', Q13: '1' },
      durationSeconds: 300,
    });
    assert.ok(!result.findings.some((f) => f.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'));
  });

  test('问卷未配置对应变量时如实报告规则未运行', () => {
    const questions = likertBlock(3);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '3'),
      durationSeconds: 300,
    });
    assert.ok(!result.findings.some((f) => f.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'));
    assert.ok(
      result.skipped.some((item) => item.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'),
      '规则未运行必须显式报告，不能表现为"通过"',
    );
  });

  test('显式传入 null 配对时跳过该规则', () => {
    const questions = knowledgeFixture();
    const result = evaluateQuality({
      questions,
      answers: { Q9: '5', Q12: '2', Q13: '2' },
      durationSeconds: 300,
      pairing: null,
    });
    assert.ok(!result.findings.some((f) => f.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'));
    assert.ok(result.skipped.some((item) => item.code === 'SUBJECTIVE_OBJECTIVE_DISCREPANCY'));
  });
});

describe('疑似重复提交', () => {
  test('两份完全一致的作答触发', () => {
    const questions = likertBlock(12);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => String((i % 5) + 1)),
      durationSeconds: 400,
      duplicateCount: 2,
    });
    const finding = result.findings.find((f) => f.code === 'DUPLICATE_SUBMISSION');
    assert.ok(finding, '应检出重复提交');
    assert.match(finding.detail, /共 2 份样本/);
    assert.equal(finding.severity, 'critical');
  });

  test('仅有自己一份时不触发', () => {
    const questions = likertBlock(12);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => String((i % 5) + 1)),
      durationSeconds: 400,
      duplicateCount: 1,
    });
    assert.ok(!result.findings.some((f) => f.code === 'DUPLICATE_SUBMISSION'));
  });

  test('作答题目过少时不判定为重复（避免误伤空白提交）', () => {
    const questions = likertBlock(12);
    const answers: AnswerMap = { L1: '3', L2: '3' };
    const result = evaluateQuality({
      questions,
      answers,
      durationSeconds: 400,
      duplicateCount: 5,
    });
    assert.ok(!result.findings.some((f) => f.code === 'DUPLICATE_SUBMISSION'));
  });

  test('未提供跨样本比对结果时如实报告规则未运行', () => {
    const questions = likertBlock(12);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '3'),
      durationSeconds: 400,
    });
    assert.ok(result.skipped.some((item) => item.code === 'DUPLICATE_SUBMISSION'));
  });
});

/* ================================================================== */
/* Signatures                                                         */
/* ================================================================== */

describe('作答向量签名', () => {
  test('相同作答产生相同签名', () => {
    const questions = likertBlock(5);
    const a = answersFrom(questions, (i) => String((i % 3) + 1));
    const b = answersFrom(questions, (i) => String((i % 3) + 1));
    assert.equal(answerSignature(questions, a), answerSignature(questions, b));
  });

  test('任一作答不同则签名不同', () => {
    const questions = likertBlock(5);
    const a = answersFrom(questions, () => '3');
    const b: AnswerMap = { ...a, L3: '4' };
    assert.notEqual(answerSignature(questions, a), answerSignature(questions, b));
  });

  test('矩阵作答按行参与签名，且与行顺序无关', () => {
    const matrix = makeQuestion({
      question_code: 'M1',
      question_type: 'matrix',
      options: {
        matrix: {
          rows: [
            { value: '1', label: 'a' },
            { value: '2', label: 'b' },
          ],
          columns: AGREE_5,
        },
      },
    });
    const first = answerSignature([matrix], { M1: { '1': '3', '2': '4' } });
    const reordered = answerSignature([matrix], { M1: { '2': '4', '1': '3' } });
    assert.equal(first, reordered, '行顺序不应影响签名');
  });

  test('排序题保留顺序（顺序本身是信息）', () => {
    const ranking = makeQuestion({
      question_code: 'R1',
      question_type: 'ranking',
      options: { choices: AGREE_5 },
      scoring_rule: { type: 'none' },
    });
    const a = answerSignature([ranking], { R1: ['1', '2', '3'] });
    const b = answerSignature([ranking], { R1: ['3', '2', '1'] });
    assert.notEqual(a, b, '排序不同应视为不同作答');
  });

  test('未作答的题目不进入签名', () => {
    const questions = likertBlock(4);
    const a = answerSignature(questions, { L1: '1', L2: '2' });
    const b = answerSignature(questions, { L2: '2', L1: '1' });
    assert.equal(a, b);
  });
});

/* ================================================================== */
/* Scoring                                                            */
/* ================================================================== */

describe('质量评分', () => {
  test('无任何问题时为 100 分', () => {
    const questions = likertBlock(10);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, (i) => String((i % 5) + 1)),
      durationSeconds: 600,
      duplicateCount: 1,
    });
    assert.equal(result.score, 100);
    assert.equal(result.severity, 'clean');
    assert.deepEqual(result.findings, []);
  });

  test('扣分与规则权重一致', () => {
    const findings = [
      { code: 'LONG_STRING' as const, label: '', severity: 'warning' as const, scoreImpact: 25, detail: '', evidence: {} },
      { code: 'HIGH_MISSING' as const, label: '', severity: 'warning' as const, scoreImpact: 20, detail: '', evidence: {} },
    ];
    assert.equal(scoreFromFindings(findings), 55);
  });

  test('评分下限为 0，不会出现负数', () => {
    const findings = Object.values(QUALITY_RULES).map((rule) => ({
      code: rule.code,
      label: rule.label,
      severity: rule.defaultSeverity,
      scoreImpact: rule.scoreImpact,
      detail: '',
      evidence: {},
    }));
    assert.equal(scoreFromFindings(findings), 0);
  });

  test('多项问题同时命中时累计扣分', () => {
    const questions = likertBlock(25);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '4'),
      durationSeconds: 30,
      minDurationSeconds: 90,
      duplicateCount: 3,
    });
    assert.ok(result.findings.length >= 3, `应命中多项规则，实际 ${result.findings.length}`);
    assert.ok(result.score < 50, `多项严重问题应使分数明显下降，实际 ${result.score}`);
    assert.equal(result.severity, 'critical');
  });

  test('结果包含可核对的统计口径', () => {
    const questions = likertBlock(10);
    const answers: AnswerMap = {};
    questions.slice(0, 9).forEach((question, index) => {
      answers[question.question_code] = String((index % 5) + 1);
    });
    const result = evaluateQuality({ questions, answers, durationSeconds: 450 });
    assert.equal(result.stats.administered, 10);
    assert.equal(result.stats.answered, 9);
    assert.equal(result.stats.missing_rate, 0.1);
    assert.equal(result.stats.seconds_per_question, 45);
    assert.equal(result.engine_version, '1.0.0');
  });

  test('发现按固定顺序返回，便于报告与对比', () => {
    const questions = likertBlock(25);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '4'),
      durationSeconds: 30,
      duplicateCount: 2,
    });
    const order = result.findings.map((f) => f.code);
    const expected = QUALITY_RULE_ORDER.filter((code) => order.includes(code));
    assert.deepEqual(order, expected);
  });
});

describe('评分分档', () => {
  test('按四档统计样本分布', () => {
    const bands = bucketQualityScores([95, 92, 80, 75, 55, 30, 10]);
    assert.equal(bands.length, 4);
    assert.equal(bands[0]?.count, 2, '90—100');
    assert.equal(bands[1]?.count, 2, '70—89');
    assert.equal(bands[2]?.count, 1, '40—69');
    assert.equal(bands[3]?.count, 2, '0—39');
  });

  test('覆盖 0—100 全区间且不重叠', () => {
    const bands = bucketQualityScores([0, 100]);
    const total = bands.reduce((sum, band) => sum + band.count, 0);
    assert.equal(total, 2);
    assert.equal(bands.reduce((sum, band) => sum + (band.max - band.min + 1), 0), 101);
  });

  test('空样本返回全零而不报错', () => {
    const bands = bucketQualityScores([]);
    assert.ok(bands.every((band) => band.count === 0));
  });
});

describe('阈值可配置', () => {
  test('自定义长串阈值生效', () => {
    const questions = likertBlock(10);
    const result = evaluateQuality({
      questions,
      answers: answersFrom(questions, () => '4'),
      durationSeconds: 600,
      thresholds: { longStringLength: 8 },
    });
    assert.ok(result.findings.some((f) => f.code === 'LONG_STRING'));
  });

  test('自定义缺失率阈值生效', () => {
    const questions = likertBlock(10);
    const answers: AnswerMap = { L1: '3' };
    const strict = evaluateQuality({
      questions,
      answers,
      durationSeconds: 600,
      thresholds: { maxMissingRate: 0.05 },
    });
    assert.ok(strict.findings.some((f) => f.code === 'HIGH_MISSING'));

    const lenient = evaluateQuality({
      questions,
      answers,
      durationSeconds: 600,
      thresholds: { maxMissingRate: 0.95 },
    });
    assert.ok(!lenient.findings.some((f) => f.code === 'HIGH_MISSING'));
  });

  test('默认阈值与规格描述一致', () => {
    assert.equal(DEFAULT_QUALITY_THRESHOLDS.longStringLength, 20);
    assert.equal(DEFAULT_QUALITY_THRESHOLDS.maxMissingRate, 0.2);
    assert.equal(DEFAULT_QUALITY_THRESHOLDS.defaultMinDurationSeconds, 90);
  });
});
