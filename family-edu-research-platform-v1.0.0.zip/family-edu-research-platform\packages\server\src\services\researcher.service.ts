/**
 * Researcher account service: registration, login, token revocation.
 *
 * Emails are normalised to lower case on write so uniqueness is enforced
 * case-insensitively without relying on engine-specific collations — the same
 * behaviour on SQLite and PostgreSQL.
 */

import type { Researcher } from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import { hashPassword, validatePasswordStrength, verifyPassword } from '../security/password.js';
import { toResearcher, type ResearcherRow } from './mappers.js';

export interface RegisterInput {
  name: string;
  email: string;
  password: string;
  affiliation?: string | null;
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateRegistrationInput(input: RegisterInput): void {
  const errors: string[] = [];
  if (typeof input.name !== 'string' || input.name.trim().length === 0) {
    errors.push('姓名不能为空。');
  } else if (input.name.trim().length > 100) {
    errors.push('姓名不能超过 100 个字符。');
  }
  if (typeof input.email !== 'string' || !EMAIL_PATTERN.test(normalizeEmail(input.email))) {
    errors.push('请输入有效的邮箱地址。');
  }
  errors.push(...validatePasswordStrength(input.password).errors);
  if (errors.length > 0) {
    throw ApiError.validation('注册信息校验失败。', errors.map((message) => ({ field: 'input', message })));
  }
}

export function findResearcherByEmail(db: Db, email: string): ResearcherRow | undefined {
  return db.get<ResearcherRow>('SELECT * FROM researchers WHERE email = ?', [normalizeEmail(email)]);
}

export function findResearcherById(db: Db, id: string): ResearcherRow | undefined {
  return db.get<ResearcherRow>('SELECT * FROM researchers WHERE id = ?', [id]);
}

export function registerResearcher(db: Db, input: RegisterInput): Researcher {
  validateRegistrationInput(input);
  const email = normalizeEmail(input.email);

  if (findResearcherByEmail(db, email)) {
    throw ApiError.conflict('该邮箱已被注册，请直接登录或使用其他邮箱。');
  }

  const id = newId();
  const timestamp = nowIso();
  db.run(
    `INSERT INTO researchers (id, name, email, password_hash, affiliation, role, token_version, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'researcher', 0, ?, ?)`,
    [
      id,
      input.name.trim(),
      email,
      hashPassword(input.password),
      input.affiliation?.trim() || null,
      timestamp,
      timestamp,
    ],
  );

  const row = findResearcherById(db, id);
  if (!row) throw new ApiError('INTERNAL_ERROR', '注册后无法读取研究者记录。');
  return toResearcher(row);
}

export interface LoginResult {
  researcher: Researcher;
  tokenVersion: number;
}

/**
 * Verify credentials.
 *
 * A missing account and a wrong password produce the identical error so the
 * endpoint cannot be used to enumerate registered e-mail addresses.
 */
export function authenticateResearcher(db: Db, email: string, password: string): LoginResult | null {
  const row = findResearcherByEmail(db, email);
  if (!row) {
    // Burn comparable CPU time so response latency does not reveal existence.
    verifyPassword(typeof password === 'string' ? password : '', hashPassword('dummy-password'));
    return null;
  }
  const result = verifyPassword(typeof password === 'string' ? password : '', row.password_hash);
  if (!result.ok) return null;

  // Transparently upgrade the stored hash if the policy has been strengthened.
  if (result.needsRehash) {
    db.run('UPDATE researchers SET password_hash = ?, updated_at = ? WHERE id = ?', [
      hashPassword(password),
      nowIso(),
      row.id,
    ]);
  }

  return { researcher: toResearcher(row), tokenVersion: row.token_version };
}

/**
 * Invalidate every token issued so far for this researcher (logout / password
 * change). JWTs carry the version they were minted with, so older ones fail.
 */
export function bumpTokenVersion(db: Db, researcherId: string): number {
  const row = findResearcherById(db, researcherId);
  if (!row) throw ApiError.notFound('研究者账号不存在。');
  const next = row.token_version + 1;
  db.run('UPDATE researchers SET token_version = ?, updated_at = ? WHERE id = ?', [
    next,
    nowIso(),
    researcherId,
  ]);
  return next;
}
