/**
 * Research Dashboard API tests.
 *
 * Because PHASE 1/2 has no respondent-facing collection yet, the fixtures here
 * write respondents and responses straight into the database. That is not a
 * shortcut around the feature under test — it is exactly the input the
 * aggregation layer must handle, and it lets the tests pin the rules that
 * matter: missing answers, sensitive refusals and percentage denominators.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { api, createProject, createTestContext, createTemplatedProject, registerResearcher, type TestContext } from './helpers.js';
import { newId } from '../src/util/ids.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

/* ------------------------------------------------------------------ */
/* Direct fixtures for collected data                                  */
/* ------------------------------------------------------------------ */

interface RespondentSeed {
  anonymousId: string;
  status?: 'in_progress' | 'completed' | 'abandoned';
  durationSeconds?: number | null;
  qualityScore?: number | null;
  source?: string;
  completedAt?: string | null;
}

function insertRespondent(
  questionnaireId: string,
  projectId: string,
  seed: RespondentSeed,
): string {
  const id = newId();
  const startedAt = new Date(Date.now() - (seed.durationSeconds ?? 300) * 1000).toISOString();
  ctx.db.run(
    `INSERT INTO respondents
       (id, questionnaire_id, project_id, anonymous_id, source, started_at, completed_at,
        duration_seconds, status, quality_score, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      questionnaireId,
      projectId,
      seed.anonymousId,
      seed.source ?? 'wechat',
      startedAt,
      seed.completedAt === undefined ? new Date().toISOString() : seed.completedAt,
      seed.durationSeconds ?? null,
      seed.status ?? 'completed',
      seed.qualityScore ?? null,
      startedAt,
    ],
  );
  return id;
}

function insertResponse(respondentId: string, questionId: string, questionCode: string, answer: unknown): void {
  const now = new Date().toISOString();
  ctx.db.run(
    `INSERT INTO responses (id, respondent_id, question_id, question_code, answer, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [newId(), respondentId, questionId, questionCode, JSON.stringify(answer), now, now],
  );
}

/** question_code -> question_id for a questionnaire. */
function questionIndex(questionnaireId: string): Map<string, string> {
  const rows = ctx.db.all<{ id: string; question_code: string }>(
    'SELECT id, question_code FROM questions WHERE questionnaire_id = ?',
    [questionnaireId],
  );
  return new Map(rows.map((row) => [row.question_code, row.id]));
}

/* ------------------------------------------------------------------ */

describe('空状态：尚未开始收集', () => {
  test('新账号的总体 Dashboard 返回真实零值而非占位数据', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api<{
      scope: string;
      collection_started: boolean;
      projects: { total: number; draft: number };
      sample: { total: number; valid_rate: number | null; average_duration_seconds: number | null };
      questionnaire: unknown;
      distributions: unknown[];
    }>(ctx, 'GET', '/api/dashboard', { token: researcher.token });

    assert.equal(response.status, 200);
    assert.equal(response.data.scope, 'all_projects');
    assert.equal(response.data.collection_started, false);
    assert.equal(response.data.projects.total, 0);
    assert.equal(response.data.sample.total, 0);
    assert.equal(response.data.sample.valid_rate, null, '无样本时有效率应为 null 而不是 0');
    assert.equal(response.data.sample.average_duration_seconds, null);
    assert.equal(response.data.questionnaire, null);
    assert.deepEqual(response.data.distributions, []);
  });

  test('有项目但无样本时 collection_started 仍为 false，并给出明确说明', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '未开始收集');

    const response = await api<{
      collection_started: boolean;
      sample: { total: number };
      questionnaire: { question_count: number; status: string; version: string };
      findings: { level: string; text: string; source: { n: number } }[];
    }>(ctx, 'GET', `/api/dashboard?project_id=${project.id}`, { token: researcher.token });

    assert.equal(response.data.collection_started, false);
    assert.equal(response.data.sample.total, 0);
    assert.equal(response.data.questionnaire.question_count, 58);
    assert.equal(response.data.questionnaire.version, 'V4.0');
    assert.equal(response.data.questionnaire.status, 'draft');

    const finding = response.data.findings[0];
    assert.equal(finding?.level, 'FACT');
    assert.match(finding?.text ?? '', /尚未收集到任何样本/);
    assert.equal(finding?.source.n, 0);
  });

  test('项目级 Dashboard 摘要项目元信息', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '元信息检查');

    const response = await api<{
      scope: string;
      project: { id: string; title: string; status: string; target_sample_size: number };
    }>(ctx, 'GET', `/api/dashboard?project_id=${project.id}`, { token: researcher.token });

    assert.equal(response.data.scope, 'single_project');
    assert.equal(response.data.project.id, project.id);
    assert.equal(response.data.project.title, '元信息检查');
    assert.equal(response.data.project.target_sample_size, 500);
  });
});

describe('样本指标计算', () => {
  let token: string;
  let projectId: string;
  let questionnaireId: string;

  before(async () => {
    const researcher = await registerResearcher(ctx);
    token = researcher.token;
    const project = await createTemplatedProject(ctx, researcher.token, '样本指标研究');
    projectId = project.id;
    questionnaireId = project.questionnaireId!;

    // 6 respondents: 4 completed (3 valid, 1 invalid), 1 in progress, 1 abandoned.
    insertRespondent(questionnaireId, projectId, { anonymousId: 'A0001', qualityScore: 92, durationSeconds: 600 });
    insertRespondent(questionnaireId, projectId, { anonymousId: 'A0002', qualityScore: 85, durationSeconds: 480 });
    insertRespondent(questionnaireId, projectId, { anonymousId: 'A0003', qualityScore: 74, durationSeconds: 720 });
    insertRespondent(questionnaireId, projectId, { anonymousId: 'A0004', qualityScore: 35, durationSeconds: 40 });
    insertRespondent(questionnaireId, projectId, {
      anonymousId: 'A0005',
      status: 'in_progress',
      completedAt: null,
      durationSeconds: null,
    });
    insertRespondent(questionnaireId, projectId, {
      anonymousId: 'A0006',
      status: 'abandoned',
      qualityScore: null,
      completedAt: null,
      durationSeconds: 120,
    });
  });

  test('样本总量、完成、进行中与中途退出分别统计', async () => {
    const response = await api<{
      sample: { total: number; completed: number; in_progress: number; abandoned: number };
    }>(ctx, 'GET', `/api/dashboard?project_id=${projectId}`, { token });

    assert.equal(response.data.sample.total, 6);
    assert.equal(response.data.sample.completed, 4);
    assert.equal(response.data.sample.in_progress, 1);
    assert.equal(response.data.sample.abandoned, 1);
  });

  test('有效/无效按质量阈值划分，并如实报告未评分数量', async () => {
    const response = await api<{
      sample: { valid: number; invalid: number; unscored: number; valid_rate: number };
    }>(ctx, 'GET', `/api/dashboard?project_id=${projectId}`, { token });

    assert.equal(response.data.sample.valid, 3);
    assert.equal(response.data.sample.invalid, 1);
    assert.equal(response.data.sample.unscored, 0);
    // 3 / 4 completed = 75%
    assert.equal(response.data.sample.valid_rate, 75);
  });

  test('有效率的分母是已完成样本，不是全部样本', async () => {
    const response = await api<{ sample: { valid_rate: number; completed: number } }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${projectId}`,
      { token },
    );
    assert.equal(response.data.sample.completed, 4);
    assert.equal(response.data.sample.valid_rate, 75, '若误用总样本作分母会得到 50%');
  });

  test('完成率的分母是全部样本', async () => {
    const response = await api<{ sample: { completion_rate: number } }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${projectId}`,
      { token },
    );
    // 4 / 6 ≈ 66.67%
    assert.equal(response.data.sample.completion_rate, 66.67);
  });

  test('平均完成时间只统计已完成且有有效时长的样本', async () => {
    const response = await api<{ sample: { average_duration_seconds: number } }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${projectId}`,
      { token },
    );
    // (600 + 480 + 720 + 40) / 4 = 460
    assert.equal(response.data.sample.average_duration_seconds, 460);
  });

  test('今日新增样本按完成时间统计', async () => {
    const response = await api<{ sample: { today_new: number } }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${projectId}`,
      { token },
    );
    assert.equal(response.data.sample.today_new, 6);
  });

  test('质量评分缺失（未评分）的完成样本不计入有效或无效', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '未评分样本');
    insertRespondent(project.questionnaireId!, project.id, {
      anonymousId: 'B0001',
      qualityScore: null,
    });

    const response = await api<{
      sample: { completed: number; valid: number; invalid: number; unscored: number; valid_rate: number | null };
    }>(ctx, 'GET', `/api/dashboard?project_id=${project.id}`, { token: researcher.token });

    assert.equal(response.data.sample.completed, 1);
    assert.equal(response.data.sample.valid, 0);
    assert.equal(response.data.sample.invalid, 0);
    assert.equal(response.data.sample.unscored, 1);
    assert.equal(response.data.sample.valid_rate, null, '全部未评分时有效率应为 null');
  });
});

describe('分布统计', () => {
  let token: string;
  let projectId: string;
  let questionnaireId: string;
  let questions: Map<string, string>;

  before(async () => {
    const researcher = await registerResearcher(ctx);
    token = researcher.token;
    const project = await createTemplatedProject(ctx, researcher.token, '分布统计研究');
    projectId = project.id;
    questionnaireId = project.questionnaireId!;
    questions = questionIndex(questionnaireId);

    // 4 respondents with deliberately known distributions.
    const seeds: { anon: string; stage: string; area: string; ui: string; wtp: string; iscb: string[]; punish: string; fed: Record<string, string> }[] = [
      {
        anon: 'C0001',
        stage: '2',
        area: '1',
        ui: '5',
        wtp: '5',
        iscb: ['1', '4'],
        punish: '1',
        fed: { '1': '4', '2': '3' },
      },
      {
        anon: 'C0002',
        stage: '2',
        area: '1',
        ui: '4',
        wtp: '4',
        iscb: ['1'],
        punish: '5', // 不愿回答 —— 敏感拒答
        fed: { '1': '5', '2': '4' },
      },
      {
        anon: 'C0003',
        stage: '3',
        area: '2',
        ui: '4',
        wtp: '3',
        iscb: ['2', '4'],
        punish: '2',
        fed: { '1': '3', '2': '3' },
      },
      {
        anon: 'C0004',
        stage: '3',
        area: null as unknown as string, // 未作答
        ui: '3',
        wtp: '4',
        iscb: [],
        punish: '1',
        fed: {},
      },
    ];

    for (const seed of seeds) {
      const respondentId = insertRespondent(questionnaireId, projectId, {
        anonymousId: seed.anon,
        qualityScore: 88,
        durationSeconds: 500,
      });
      if (seed.stage) insertResponse(respondentId, questions.get('Q4')!, 'Q4', seed.stage);
      if (seed.area !== null) insertResponse(respondentId, questions.get('Q5')!, 'Q5', seed.area);
      insertResponse(respondentId, questions.get('Q50')!, 'Q50', seed.ui);
      insertResponse(respondentId, questions.get('Q53')!, 'Q53', seed.wtp);
      if (seed.iscb.length > 0) insertResponse(respondentId, questions.get('Q17')!, 'Q17', seed.iscb);
      insertResponse(respondentId, questions.get('Q32')!, 'Q32', seed.punish);
      if (Object.keys(seed.fed).length > 0) {
        insertResponse(respondentId, questions.get('Q35')!, 'Q35', seed.fed);
      }
    }
  });

  interface DistributionShape {
    variable_name: string;
    question_code: string;
    kind: string;
    base_n: number;
    n: number;
    mean: number | null;
    sd: number | null;
    median: number | null;
    missing: number;
    sensitive_nonresponse: number;
    counts: { value: string; label: string; count: number; percent: number }[];
  }

  async function distributions(): Promise<Map<string, DistributionShape>> {
    const response = await api<{ distributions: DistributionShape[] }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${projectId}`,
      { token },
    );
    return new Map(response.data.distributions.map((d) => [d.variable_name, d]));
  }

  test('返回配置的全部仪表盘变量', async () => {
    const map = await distributions();
    for (const name of ['AREA', 'STAGE', 'ISCB', 'FED', 'UI', 'WTP', 'FPB_PUNISH']) {
      assert.ok(map.has(name), `仪表盘缺少变量 ${name}`);
    }
  });

  test('每个变量都满足 n + missing + 敏感拒答 = 分析基数（不丢失任何样本）', async () => {
    const map = await distributions();
    for (const distribution of map.values()) {
      assert.equal(
        distribution.n + distribution.missing + distribution.sensitive_nonresponse,
        distribution.base_n,
        `${distribution.variable_name} 的分类计数不守恒：${distribution.n}+${distribution.missing}+${distribution.sensitive_nonresponse} != ${distribution.base_n}`,
      );
    }
  });

  test('分析基数为已完成问卷的样本量', async () => {
    const map = await distributions();
    for (const distribution of map.values()) {
      assert.equal(distribution.base_n, 4, `${distribution.variable_name} 的分析基数应为 4 份已完成样本`);
    }
  });

  test('有序变量：频数与百分比基于有效作答', async () => {
    const map = await distributions();
    const stage = map.get('STAGE')!;
    assert.equal(stage.kind, 'scale', '教育阶段为有序变量，应给出集中趋势');
    assert.equal(stage.n, 4);

    const primary = stage.counts.find((c) => c.value === '2')!;
    const middle = stage.counts.find((c) => c.value === '3')!;
    assert.equal(primary.label, '小学');
    assert.equal(primary.count, 2);
    assert.equal(primary.percent, 50);
    assert.equal(middle.count, 2);
    assert.equal(middle.percent, 50);
  });

  test('未作答计入 missing，且不进入百分比分母', async () => {
    const map = await distributions();
    const area = map.get('AREA')!;
    assert.equal(area.n, 3, 'AREA 有 3 份有效作答');
    assert.equal(area.missing, 1, 'A0004 未作答地区题');
    const capital = area.counts.find((c) => c.value === '1')!;
    assert.equal(capital.count, 2);
    // 2/3 = 66.67%，若把缺失也算作分母会得到 50%
    assert.equal(capital.percent, 66.67, '百分比分母必须是有效作答数');
  });

  test('量表变量：给出均值、标准差与中位数', async () => {
    const map = await distributions();
    const ui = map.get('UI')!;
    assert.equal(ui.kind, 'scale');
    assert.equal(ui.n, 4);
    // UI answers 5,4,4,3 -> mean 4, median 4
    assert.equal(ui.mean, 4);
    assert.equal(ui.median, 4);
    assert.equal(ui.sd, 0.8165);
  });

  test('多选题：百分比为选择该选项的受访者比例', async () => {
    const map = await distributions();
    const iscb = map.get('ISCB')!;
    assert.equal(iscb.kind, 'multi');
    // 3 respondents answered Q17 (C0004 selected nothing -> missing)
    assert.equal(iscb.n, 3);
    assert.equal(iscb.missing, 1);

    const opt1 = iscb.counts.find((c) => c.value === '1')!;
    const opt4 = iscb.counts.find((c) => c.value === '4')!;
    assert.equal(opt1.count, 2);
    assert.equal(opt1.percent, 66.67);
    assert.equal(opt4.count, 2);
    assert.equal(opt4.percent, 66.67);
  });

  test('矩阵变量：按行给出均值，用于困难程度排序', async () => {
    const map = await distributions();
    const fed = map.get('FED')!;
    assert.equal(fed.kind, 'matrix_row_means');
    assert.equal(fed.n, 3, '只有 3 份有效矩阵作答');

    const row1 = fed.counts.find((c) => c.value === '1')!;
    // rows: 4,5,3 -> mean 4
    assert.equal(row1.count, 3);
    assert.equal(row1.percent, 4);
    assert.match(row1.label, /缺乏科学的家庭教育方法/);

    const row2 = fed.counts.find((c) => c.value === '2')!;
    // rows: 3,4,3 -> mean 3.33
    assert.equal(row2.percent, 3.33);
  });

  test('敏感题：拒答被单独计数，绝不并入"从未"', async () => {
    const map = await distributions();
    const punish = map.get('FPB_PUNISH')!;
    assert.equal(punish.kind, 'scale');
    assert.equal(punish.n, 3, '只有 3 份实质作答');
    assert.equal(punish.sensitive_nonresponse, 1, '"不愿回答"应单独计为敏感未作答');

    const never = punish.counts.find((c) => c.value === '1')!;
    assert.equal(never.label, '从未');
    assert.equal(never.count, 2, '"不愿回答"不得被计入"从未"');
    assert.equal(never.percent, 66.67);

    const refusal = punish.counts.find((c) => c.value === '5')!;
    assert.equal(refusal.count, 0, '拒答不计入任何实质性类别');
  });

  test('敏感题均值基于 0—3 严重程度编码', async () => {
    const map = await distributions();
    const punish = map.get('FPB_PUNISH')!;
    // coded values: 从未=0, 偶尔=1, 从未=0 -> mean ≈ 0.3333
    assert.equal(punish.mean, 0.3333);
  });
});

describe('主客观法律认知对照', () => {
  test('可同时获取主观自评与客观知识得分所需的数据', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '法律认知对照');
    const questions = questionIndex(project.questionnaireId!);

    // 自评"非常了解"（5），但五道客观题全错。
    const respondentId = insertRespondent(project.questionnaireId!, project.id, {
      anonymousId: 'D0001',
      qualityScore: 90,
      durationSeconds: 400,
    });
    insertResponse(respondentId, questions.get('Q10')!, 'Q10', '5');
    insertResponse(respondentId, questions.get('Q12')!, 'Q12', '2');
    insertResponse(respondentId, questions.get('Q13')!, 'Q13', '2');
    insertResponse(respondentId, questions.get('Q14')!, 'Q14', '2');
    insertResponse(respondentId, questions.get('Q15')!, 'Q15', '1');
    insertResponse(respondentId, questions.get('Q16')!, 'Q16', '1');

    // 仪表盘提供 LSK 主观分（变量未在默认列表中，改由原始数据核对）。
    const lskRow = ctx.db.get<{ answer: string }>(
      'SELECT answer FROM responses WHERE respondent_id = ? AND question_code = ?',
      [respondentId, 'Q10'],
    );
    assert.equal(lskRow?.answer, '"5"');

    // 5 道知识题均为错误作答，客观得分应为 0。
    const knowledgeRows = ctx.db.all<{ answer: string }>(
      "SELECT answer FROM responses WHERE respondent_id = ? AND question_code IN ('Q12','Q13','Q14','Q15','Q16')",
      [respondentId],
    );
    assert.equal(knowledgeRows.length, 5);
    assert.ok(knowledgeRows.every((row) => row.answer === '"2"' || row.answer === '"1"'));
  });
});

describe('配额进度与提醒', () => {
  test('按教育阶段计算配额完成度并生成不足提醒', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '配额研究');

    // 设置配额：学前 2、小学 3、初中 3、高中 2
    const patched = await api(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: true,
          categories: [
            { dimension: 'STAGE', category: '学前（0—6岁）', target_n: 2 },
            { dimension: 'STAGE', category: '小学', target_n: 3 },
            { dimension: 'STAGE', category: '初中', target_n: 3 },
            { dimension: 'STAGE', category: '高中', target_n: 2 },
          ],
        },
      },
    });
    assert.equal(patched.status, 200);

    const questions = questionIndex(project.questionnaireId!);
    // 学前 2（达标）、小学 3（达标）、初中 1（不足）、高中 0（不足）
    const stages = ['1', '1', '2', '2', '2', '3'];
    stages.forEach((stage, index) => {
      const respondentId = insertRespondent(project.questionnaireId!, project.id, {
        anonymousId: `E000${index + 1}`,
        qualityScore: 80,
        durationSeconds: 400,
      });
      insertResponse(respondentId, questions.get('Q4')!, 'Q4', stage);
    });

    const response = await api<{
      quota_progress: { category: string; target_n: number; current_n: number; percent: number; met: boolean }[];
      quota_alerts: string[];
    }>(ctx, 'GET', `/api/dashboard?project_id=${project.id}`, { token: researcher.token });

    const byCategory = new Map(response.data.quota_progress.map((q) => [q.category, q]));

    assert.equal(byCategory.get('学前（0—6岁）')?.current_n, 2);
    assert.equal(byCategory.get('学前（0—6岁）')?.met, true);
    assert.equal(byCategory.get('小学')?.current_n, 3);
    assert.equal(byCategory.get('小学')?.percent, 100);
    assert.equal(byCategory.get('初中')?.current_n, 1);
    assert.equal(byCategory.get('初中')?.percent, 33.33);
    assert.equal(byCategory.get('初中')?.met, false);
    assert.equal(byCategory.get('高中')?.current_n, 0);
    assert.equal(byCategory.get('高中')?.met, false);

    assert.equal(response.data.quota_alerts.length, 1);
    assert.match(response.data.quota_alerts[0]!, /初中/);
    assert.match(response.data.quota_alerts[0]!, /高中/);
    assert.match(response.data.quota_alerts[0]!, /建议继续收集/);
  });

  test('未启用配额时不产生配额板块', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '无配额研究');

    // A template project ships with quota configured; clear it to exercise the
    // "no quota configured" path.
    await api(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: researcher.token,
      body: { quota_config: null },
    });

    const response = await api<{ quota_progress: unknown[]; quota_alerts: string[] }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${project.id}`,
      { token: researcher.token },
    );
    assert.deepEqual(response.data.quota_progress, []);
    assert.deepEqual(response.data.quota_alerts, []);
  });

  test('模板项目自带分阶段配额（研究设计随模板一并创建）', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '模板配额');

    const detail = await api<{
      project: { quota_config: { enabled: boolean; categories: unknown[] } | null };
    }>(ctx, 'GET', `/api/projects/${project.id}`, { token: researcher.token });

    assert.equal(detail.data.project.quota_config?.enabled, true);
    assert.equal(detail.data.project.quota_config?.categories.length, 4);
  });

  test('配额提醒中体现"保持目标样本结构"设置', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '保持结构');
    await api(ctx, 'PATCH', `/api/projects/${project.id}`, {
      token: researcher.token,
      body: {
        quota_config: {
          enabled: true,
          preserve_structure: true,
          categories: [
            { dimension: 'STAGE', category: '小学', target_n: 10 },
            { dimension: 'STAGE', category: '高中', target_n: 1 },
          ],
        },
      },
    });

    const questions = questionIndex(project.questionnaireId!);
    const respondentId = insertRespondent(project.questionnaireId!, project.id, {
      anonymousId: 'F0001',
      qualityScore: 80,
      durationSeconds: 400,
    });
    insertResponse(respondentId, questions.get('Q4')!, 'Q4', '4'); // 高中 1/1 达标

    const response = await api<{ quota_alerts: string[] }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${project.id}`,
      { token: researcher.token },
    );
    assert.match(response.data.quota_alerts[0] ?? '', /保持目标样本结构/);
  });
});

describe('主要发现（Level 1 FACT）', () => {
  test('发现的每一条都标注来源题号与 n，且不越界做因果解释', async () => {
    const researcher = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, researcher.token, '发现研究');
    const questions = questionIndex(project.questionnaireId!);

    for (let i = 0; i < 3; i += 1) {
      const respondentId = insertRespondent(project.questionnaireId!, project.id, {
        anonymousId: `G000${i + 1}`,
        qualityScore: 90,
        durationSeconds: 450,
      });
      insertResponse(respondentId, questions.get('Q50')!, 'Q50', '4');
      insertResponse(respondentId, questions.get('Q5')!, 'Q5', '2');
    }

    const response = await api<{ findings: { level: string; text: string; source: { question_code: string; n: number } }[] }>(
      ctx,
      'GET',
      `/api/dashboard?project_id=${project.id}`,
      { token: researcher.token },
    );

    assert.ok(response.data.findings.length > 0);
    for (const finding of response.data.findings) {
      assert.equal(finding.level, 'FACT', '仪表盘发现只能是事实层陈述');
      assert.ok(finding.source.n >= 0);
      assert.equal(typeof finding.source.question_code, 'string');
      assert.ok(!/因果|导致|证明了|必然/.test(finding.text), `事实层不应包含因果表述: ${finding.text}`);
    }

    const uiFinding = response.data.findings.find((f) => f.text.includes('UI'));
    assert.ok(uiFinding, '应包含 UI 的均值事实陈述');
    assert.equal(uiFinding?.source.question_code, 'Q50');
    assert.equal(uiFinding?.source.n, 3);
    assert.match(uiFinding?.text ?? '', /均值为 4/);
  });
});

describe('仪表盘的数据隔离', () => {
  test('研究者只能看到自己项目的样本统计', async () => {
    const owner = await registerResearcher(ctx);
    const intruder = await registerResearcher(ctx);
    const project = await createTemplatedProject(ctx, owner.token, '隔离统计');
    insertRespondent(project.questionnaireId!, project.id, { anonymousId: 'H0001', qualityScore: 90 });

    const denied = await api(ctx, 'GET', `/api/dashboard?project_id=${project.id}`, {
      token: intruder.token,
    });
    assert.equal(denied.status, 404);
  });

  test('总体视图的样本量不包含其他研究者的项目', async () => {
    const a = await registerResearcher(ctx);
    const b = await registerResearcher(ctx);
    const projectA = await createTemplatedProject(ctx, a.token, 'A 的统计');
    insertRespondent(projectA.questionnaireId!, projectA.id, { anonymousId: 'I0001', qualityScore: 90 });

    const overviewB = await api<{ projects: { total: number } }>(ctx, 'GET', '/api/dashboard', {
      token: b.token,
    });
    assert.equal(overviewB.data.projects.total, 0);
  });
});
