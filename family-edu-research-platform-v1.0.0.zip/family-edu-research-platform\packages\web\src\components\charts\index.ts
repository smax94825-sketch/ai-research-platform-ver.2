/**
 * Statistical chart components.
 *
 * Hand-written SVG rather than a charting library: the console has to stay
 * dependency-free and installable offline, and every chart here needs to expose
 * its numbers as text so a test can assert them and a reader can verify them.
 */

export { BarChart } from './BarChart';
export type { BarChartDatum, BarChartProps } from './BarChart';

export { StackedBarChart, optionFill } from './StackedBarChart';
export type { LikertRow, StackedBarChartProps } from './StackedBarChart';

export { PieChart } from './PieChart';
export type { PieChartProps, PieDatum } from './PieChart';

export { Heatmap } from './Heatmap';
export type { HeatmapProps } from './Heatmap';

export { BoxPlot } from './BoxPlot';
export type { BoxPlotGroup, BoxPlotProps } from './BoxPlot';

export { ScatterPlot } from './ScatterPlot';
export type { ScatterPlotProps, ScatterPoint } from './ScatterPlot';

export { RegressionPlot } from './RegressionPlot';
export type { CoefficientPlotDatum, RegressionPlotProps } from './RegressionPlot';

export { FunnelChart } from './FunnelChart';
export type { FunnelChartProps, FunnelStage } from './FunnelChart';

export { ProgressBar } from './ProgressBar';
export type { ProgressBarItem, ProgressBarProps } from './ProgressBar';

export { SourceChannelChart } from './SourceChannelChart';
export type { SourceChannelDatum, SourceChannelChartProps } from './SourceChannelChart';

export { ChartCaption, ChartEmpty, ResponsiveSvg, axisTicks, divergingFill } from './primitives';
