/**
 * Respondent survey UI tests (PHASE 3).
 *
 * The survey is the only surface a real participant sees, so these drive it the
 * way a person would: accept consent, answer, hit required validation, navigate,
 * submit, and — importantly — resume after a reload.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { click, flush, queryAll, render, text, typeInto, unmount } from './render';

const { SurveyPage } = await import('../src/pages/SurveyPage');

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

interface TestQuestion {
  question_code: string;
  question_text: string;
  question_type: string;
  required: boolean;
  section?: string;
  options: Record<string, unknown>;
  logic?: unknown;
  variable_name?: string;
}

const QUESTIONS: TestQuestion[] = [
  {
    question_code: 'Q1',
    question_text: '您是否使用过家庭教育机构？',
    question_type: 'single',
    required: true,
    section: '第一部分',
    variable_name: 'FIUU',
    options: {
      choices: [
        { value: '1', label: '从未使用' },
        { value: '2', label: '使用过' },
      ],
    },
    logic: {
      rules: [
        {
          id: 'skip-q2',
          match: 'all',
          conditions: [{ questionCode: 'Q1', operator: 'eq', value: '1' }],
          action: { type: 'jump_to', target: 'Q3' },
        },
      ],
    },
  },
  {
    question_code: 'Q2',
    question_text: '请评价您的满意程度。',
    question_type: 'likert',
    required: true,
    section: '第一部分',
    options: {
      choices: [
        { value: '1', label: '非常不满意', score: 1 },
        { value: '2', label: '一般', score: 2 },
        { value: '3', label: '非常满意', score: 3 },
      ],
    },
    logic: {
      rules: [
        {
          id: 'show-q2',
          match: 'all',
          conditions: [{ questionCode: 'Q1', operator: 'neq', value: '1' }],
          action: { type: 'show' },
        },
      ],
    },
  },
  {
    question_code: 'Q3',
    question_text: '未来您愿意使用吗？',
    question_type: 'single',
    required: true,
    section: '第二部分',
    options: {
      choices: [
        { value: '1', label: '不愿意' },
        { value: '2', label: '愿意' },
      ],
    },
  },
  {
    question_code: 'Q4',
    question_text: '请留下您的建议（选填）。',
    question_type: 'textarea',
    required: false,
    section: '第二部分',
    options: { maxLength: 200, placeholder: '选填' },
  },
];

const INSTRUMENT = {
  questionnaire: {
    id: 'qn-1',
    title: '家庭教育认知、实践与社会支持需求调查',
    description: '本问卷用于了解家长在家庭教育方面的需求。',
    version: 'V4.0',
    status: 'published',
  },
  project: { title: '家庭教育研究', target_sample_size: 1000 },
  consent_text: '本研究为匿名调查。参与完全自愿，您可以拒绝回答任何问题，也可以随时退出。',
  consent_is_platform_default: false,
  ethics_points: ['本研究为匿名调查，不会收集您的姓名或手机号。', '参与完全自愿。'],
  anonymous: true,
  allow_partial: false,
  min_duration_seconds: 90,
  accepting_responses: true,
  question_count: 4,
  questions: QUESTIONS,
};

const RESPONDENT = {
  id: 'resp-1',
  questionnaire_id: 'qn-1',
  project_id: 'p-1',
  anonymous_id: 'A0007',
  source: 'wechat',
  started_at: '2026-01-01T00:00:00.000Z',
  completed_at: null,
  duration_seconds: null,
  status: 'in_progress',
  quality_score: null,
  current_question_code: 'Q1',
  answered_count: 0,
  last_activity_at: null,
  consent_given_at: '2026-01-01T00:00:00.000Z',
  review_status: 'unreviewed',
  review_note: null,
  created_at: '2026-01-01T00:00:00.000Z',
};

/** Render the survey at /research/<token>. */
async function renderSurvey(shareToken = 'share-token-abc', query = ''): Promise<void> {
  await render(
    createElement(
      MemoryRouter,
      { initialEntries: [`/research/${shareToken}${query}`] },
      createElement(
        Routes,
        null,
        createElement(Route, { path: '/research/:shareToken', element: createElement(SurveyPage) }),
      ),
    ),
  );
}

function findButton(label: string): Element | undefined {
  return queryAll('button').find((button) => (button.textContent ?? '').includes(label));
}

beforeEach(async () => {
  await unmount();
  clearContainer();
  window.localStorage.clear();
});

after(async () => {
  await unmount();
  closeDom();
});

/* ================================================================== */
/* Consent                                                            */
/* ================================================================== */

describe('知情同意页', () => {
  test('展示问卷标题、同意说明与伦理要点', async () => {
    const fetchStub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      return jsonResponse({ data: null });
    });

    try {
      await renderSurvey();
      await flush();

      const content = text();
      assert.match(content, /家庭教育认知、实践与社会支持需求调查/);
      assert.match(content, /知情同意说明/);
      assert.match(content, /本研究为匿名调查/);
      assert.match(content, /参与完全自愿/);
      assert.match(content, /不会收集您的姓名或手机号/);
      assert.match(content, /4 题/);
      assert.ok(findButton('开始作答'), '应有开始作答按钮');
    } finally {
      fetchStub.restore();
    }
  });

  test('未加载前不显示开始按钮（避免空白页误点）', async () => {
    const fetchStub = stubFetch(() => jsonResponse({ data: INSTRUMENT }));
    try {
      await renderSurvey();
      await flush();
      // 题目在同意页不展示，只有同意后才进入作答
      assert.ok(!text().includes('您是否使用过家庭教育机构'), '同意前不应展示题目');
    } finally {
      fetchStub.restore();
    }
  });

  test('问卷已关闭时展示结束提示且不提供开始按钮', async () => {
    const fetchStub = stubFetch(() =>
      jsonResponse({
        data: { ...INSTRUMENT, accepting_responses: false },
      }),
    );
    try {
      await renderSurvey();
      await flush();
      assert.match(text(), /本次调查已结束/);
      assert.equal(findButton('开始作答'), undefined);
    } finally {
      fetchStub.restore();
    }
  });

  test('链接无效时给出可操作的提示', async () => {
    const fetchStub = stubFetch(() =>
      jsonResponse({ error: { code: 'NOT_FOUND', message: '问卷链接无效或已被撤销。', details: null } }, 404),
    );
    try {
      await renderSurvey('bad-token');
      await flush();
      assert.match(text(), /无法打开问卷/);
      assert.match(text(), /链接无效或已被撤销/);
      assert.match(text(), /确认链接是否正确/);
    } finally {
      fetchStub.restore();
    }
  });
});

/* ================================================================== */
/* Flow                                                               */
/* ================================================================== */

describe('作答流程', () => {
  /** Stub covering the whole public API surface the survey touches. */
  function stubSurveyApi(): { calls: FetchCall[]; restore: () => void } {
    return stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });

      if (call.url.includes('/sessions') && call.method === 'POST' && !call.url.includes('/complete')) {
        return jsonResponse({ data: { session_token: 'session-token-xyz', respondent: RESPONDENT } }, 201);
      }

      if (call.url.includes('/answers')) {
        const body = call.body as { question_code: string; value: unknown };
        return jsonResponse({
          data: {
            respondent: { ...RESPONDENT, answered_count: 1, current_question_code: body.question_code },
            question_code: body.question_code,
            stored: body.value,
            pruned_question_codes: [],
            answered_count: 1,
          },
        });
      }

      if (call.url.includes('/progress')) return jsonResponse({ data: RESPONDENT });

      if (call.url.includes('/complete')) {
        return jsonResponse({
          data: {
            respondent: { ...RESPONDENT, status: 'completed', completed_at: '2026-01-01T00:10:00.000Z', duration_seconds: 600 },
            completed: true,
            missing_required: [],
          },
        });
      }

      return jsonResponse({ data: null });
    });
  }

  async function startSurvey(): Promise<{ calls: FetchCall[]; restore: () => void }> {
    const stub = stubSurveyApi();
    await renderSurvey('share-token-abc', '?source=wechat');
    await flush();
    const start = findButton('开始作答');
    assert.ok(start, '应能找到开始作答按钮');
    await click(start!);
    await flush();
    return stub;
  }

  test('点击开始后创建会话并展示第一题与进度', async () => {
    const stub = await startSurvey();
    try {
      const content = text();
      assert.match(content, /您是否使用过家庭教育机构/);
      assert.match(content, /第 1\/4 题/);
      assert.match(content, /从未使用/);

      const sessionCall = stub.calls.find(
        (call) => call.url.includes('/sessions') && call.method === 'POST',
      );
      assert.ok(sessionCall, '应创建作答会话');
      assert.deepEqual((sessionCall!.body as { source: string }).source, 'wechat', '应传递渠道参数');
    } finally {
      stub.restore();
    }
  });

  test('会话令牌写入 localStorage 以便刷新后续答', async () => {
    const stub = await startSurvey();
    try {
      assert.equal(window.localStorage.getItem('ferp.survey.session.share-token-abc'), 'session-token-xyz');
    } finally {
      stub.restore();
    }
  });

  test('未作答必答题时阻止进入下一题并给出提醒', async () => {
    const stub = await startSurvey();
    try {
      await click(findButton('下一题')!);
      await flush();

      assert.match(text(), /必答题/, '应提示该题为必答题');
      assert.match(text(), /第 1\/4 题/, '应停留在第一题');
      assert.equal(
        stub.calls.filter((call) => call.url.includes('/complete')).length,
        0,
        '不应提交',
      );
    } finally {
      stub.restore();
    }
  });

  test('作答必答题后可以进入下一题', async () => {
    const stub = await startSurvey();
    try {
      const radios = queryAll('input[type="radio"]');
      assert.equal(radios.length, 2);
      await click(radios[0]!); // 从未使用
      await flush();

      await click(findButton('下一题')!);
      await flush();

      assert.match(text(), /第 2\/3 题/);
    } finally {
      stub.restore();
    }
  });

  test('作答会自动保存到服务端', async () => {
    const stub = await startSurvey();
    try {
      await click(queryAll('input[type="radio"]')[1]!);
      // 等待自动保存的防抖计时器
      await new Promise((resolve) => setTimeout(resolve, 700));
      await flush();

      const saveCalls = stub.calls.filter((call) => call.url.includes('/answers'));
      assert.ok(saveCalls.length >= 1, '应至少调用一次自动保存接口');
      const body = saveCalls[0]!.body as { question_code: string; value: unknown };
      assert.equal(body.question_code, 'Q1');
      assert.equal(body.value, '2');
    } finally {
      stub.restore();
    }
  });

  test('选择「从未使用」后自动跳过 Q2（条件跳转生效）', async () => {
    const stub = await startSurvey();
    try {
      await click(queryAll('input[type="radio"]')[0]!); // 从未使用
      await flush();
      await click(findButton('下一题')!);
      await flush();

      const content = text();
      assert.match(content, /未来您愿意使用吗/, '应直接进入 Q3');
      assert.ok(!content.includes('请评价您的满意程度'), 'Q2 应被跳过');
      assert.match(content, /第 2\/3 题/);
    } finally {
      stub.restore();
    }
  });

  test('选择「使用过」时 Q2 保留在路径中', async () => {
    const stub = await startSurvey();
    try {
      await click(queryAll('input[type="radio"]')[1]!); // 使用过
      await flush();
      await click(findButton('下一题')!);
      await flush();

      assert.match(text(), /请评价您的满意程度/, 'Q2 应被展示');
    } finally {
      stub.restore();
    }
  });

  test('「上一题」可用，且第一题时禁用', async () => {
    const stub = await startSurvey();
    try {
      const previous = findButton('上一题') as HTMLButtonElement;
      assert.equal(previous.disabled, true, '第一题的上一题应禁用');

      await click(queryAll('input[type="radio"]')[0]!);
      await flush();
      await click(findButton('下一题')!);
      await flush();
      assert.match(text(), /第 2\/3 题/);

      await click(findButton('上一题')!);
      await flush();
      assert.match(text(), /第 1\/3 题/);
    } finally {
      stub.restore();
    }
  });

  test('最后一题按钮变为提交问卷', async () => {
    const stub = await startSurvey();
    try {
      await click(queryAll('input[type="radio"]')[0]!);
      await flush();
      await click(findButton('下一题')!); // → Q3
      await flush();
      assert.match(text(), /第 2\/3 题/);

      // Q3 必答，Q4 选填：跳过 Q3 由必答校验拦截，所以先作答
      await click(queryAll('input[type="radio"]')[0]!);
      await flush();
      await click(findButton('下一题')!); // → Q4（选填）
      await flush();

      assert.ok(findButton('提交问卷'), '最后一题应显示提交按钮');
    } finally {
      stub.restore();
    }
  });

  test('提交后展示成功页与匿名编号', async () => {
    const stub = await startSurvey();
    try {
      // Q1 → Q3 → Q4(选填) → 提交
      await click(queryAll('input[type="radio"]')[0]!);
      await flush();
      await click(findButton('下一题')!);
      await flush();

      await click(queryAll('input[type="radio"]')[0]!);
      await flush();
      await click(findButton('下一题')!);
      await flush();

      await click(findButton('提交问卷')!);
      await flush();

      const content = text();
      assert.match(content, /提交成功/);
      assert.match(content, /A0007/);
      assert.match(content, /不会被单独识别/);
    } finally {
      stub.restore();
    }
  });

  test('提交时服务端报告缺失必答题，客户端跳回该题', async () => {
    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      if (call.url.includes('/sessions') && call.method === 'POST' && !call.url.includes('/complete')) {
        return jsonResponse({ data: { session_token: 'session-token-xyz', respondent: RESPONDENT } }, 201);
      }
      if (call.url.includes('/answers')) {
        return jsonResponse({
          data: {
            respondent: RESPONDENT,
            question_code: 'Q1',
            stored: '1',
            pruned_question_codes: [],
            answered_count: 1,
          },
        });
      }
      if (call.url.includes('/progress')) return jsonResponse({ data: RESPONDENT });
      if (call.url.includes('/complete')) {
        return jsonResponse(
          {
            error: {
              code: 'VALIDATION_ERROR',
              message: '还有 1 道必答题未完成，无法提交。',
              details: [{ field: 'Q3', message: '必答题 Q3 尚未作答。' }],
            },
          },
          400,
        );
      }
      return jsonResponse({ data: null });
    });

    try {
      await renderSurvey();
      await flush();
      await click(findButton('开始作答')!);
      await flush();

      await click(queryAll('input[type="radio"]')[0]!);
      await flush();
      await click(findButton('下一题')!); // → Q3
      await flush();

      // 直接尝试提交（Q3 未作答）——按钮此时是「下一题」，先进入 Q4 再提交
      await click(findButton('下一题')!); // 被必答校验拦截在 Q3
      await flush();
      assert.match(text(), /第 2\/3 题/, '必答校验应停留在 Q3');
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Resume                                                             */
/* ================================================================== */

describe('刷新续答', () => {
  test('localStorage 中存在会话时自动恢复作答与位置', async () => {
    window.localStorage.setItem('ferp.survey.session.share-token-abc', 'session-token-xyz');

    const fetchStub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/session-token-xyz')) {
        return jsonResponse({
          data: {
            respondent: { ...RESPONDENT, current_question_code: 'Q3', answered_count: 2 },
            answers: { Q1: '2', Q2: '3' },
            hidden_question_codes: [],
            missing_required: [],
          },
        });
      }
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      return jsonResponse({ data: null });
    });

    try {
      await renderSurvey();
      await flush();

      const content = text();
      assert.ok(!content.includes('我已了解，开始作答'), '不应再显示知情同意页');
      assert.match(content, /未来您愿意使用吗/, '应恢复到 Q3');
      assert.match(content, /第 3\/4 题/);
      assert.match(content, /已答 2 题/, '应显示已作答数量');
    } finally {
      fetchStub.restore();
    }
  });

  test('会话已失效时回退到知情同意页并清除本地令牌', async () => {
    window.localStorage.setItem('ferp.survey.session.share-token-abc', 'expired-token');

    const fetchStub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/expired-token')) {
        return jsonResponse(
          { error: { code: 'NOT_FOUND', message: '作答会话不存在或已失效。', details: null } },
          404,
        );
      }
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      return jsonResponse({ data: null });
    });

    try {
      await renderSurvey();
      await flush();

      assert.match(text(), /知情同意说明/);
      assert.equal(window.localStorage.getItem('ferp.survey.session.share-token-abc'), null);
    } finally {
      fetchStub.restore();
    }
  });

  test('已完成的会话再次打开时直接展示完成页', async () => {
    window.localStorage.setItem('ferp.survey.session.share-token-abc', 'session-token-xyz');

    const fetchStub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/session-token-xyz')) {
        return jsonResponse({
          data: {
            respondent: { ...RESPONDENT, status: 'completed', completed_at: '2026-01-01T00:10:00.000Z' },
            answers: { Q1: '2', Q2: '3', Q3: '2' },
            hidden_question_codes: [],
            missing_required: [],
          },
        });
      }
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      return jsonResponse({ data: null });
    });

    try {
      await renderSurvey();
      await flush();
      assert.match(text(), /提交成功/);
      assert.match(text(), /A0007/);
    } finally {
      fetchStub.restore();
    }
  });
});

/* ================================================================== */
/* Sensitive question                                                 */
/* ================================================================== */

describe('敏感题在受访者端的呈现', () => {
  test('敏感题展示匿名与拒答说明，且允许跳过', async () => {
    const sensitiveInstrument = {
      ...INSTRUMENT,
      question_count: 1,
      questions: [
        {
          question_code: 'S1',
          question_text: '过去12个月内，您是否曾采取过身体上的惩罚？',
          question_type: 'single',
          required: false,
          section: '第六部分',
          options: {
            choices: [
              { value: '1', label: '从未' },
              { value: '5', label: '不愿回答', sensitiveNonResponse: true },
            ],
          },
        },
      ],
    };

    const fetchStub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: sensitiveInstrument });
      if (call.url.includes('/sessions') && call.method === 'POST' && !call.url.includes('/complete')) {
        return jsonResponse({ data: { session_token: 'session-token-xyz', respondent: RESPONDENT } }, 201);
      }
      if (call.url.includes('/answers')) {
        return jsonResponse({
          data: {
            respondent: RESPONDENT,
            question_code: 'S1',
            stored: '5',
            pruned_question_codes: [],
            answered_count: 1,
          },
        });
      }
      if (call.url.includes('/progress')) return jsonResponse({ data: RESPONDENT });
      if (call.url.includes('/complete')) {
        return jsonResponse({
          data: { respondent: { ...RESPONDENT, status: 'completed' }, completed: true, missing_required: [] },
        });
      }
      return jsonResponse({ data: null });
    });

    try {
      await renderSurvey();
      await flush();
      await click(findButton('开始作答')!);
      await flush();

      const content = text();
      assert.match(content, /敏感题/, '应标注为敏感题');
      assert.match(content, /单独编码为缺失/, '应说明拒答的处理方式');
      assert.match(content, /不愿回答/);

      // 非必答：可以直接提交
      assert.ok(findButton('提交问卷'), '唯一的非必答题应允许直接提交');
    } finally {
      fetchStub.restore();
    }
  });
});
