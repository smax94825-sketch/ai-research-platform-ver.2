/**
 * Single-page respondent questionnaire tests — `/research/:shareToken/all`.
 *
 * The single-page layout is the alternative to the stepper for the SAME
 * instrument, so these tests drive it the way a respondent would: consent,
 * answer on one page, watch conditional questions come and go, autosave,
 * get blocked on the missing required answers, then submit and resume.
 *
 * Assertions are made on real values — question codes, answer counts and the
 * exact request bodies — because the point of this layout is that it must feed
 * the identical collection pipeline, not merely look like a questionnaire.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { click, flush, queryAll, render, text, typeInto, unmount } from './render';

const { SurveyFlatPage } = await import('../src/pages/SurveyFlatPage');
const { App } = await import('../src/App');
const { AuthProvider } = await import('../src/lib/auth');

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

interface TestQuestion {
  question_code: string;
  question_text: string;
  question_type: string;
  required: boolean;
  section?: string;
  options: Record<string, unknown>;
  logic?: unknown;
}

/**
 * Five questions across two sections.
 *
 * Logic is deliberately two-sided:
 *  - Q2 (required, 第一部分) is HIDDEN once Q1 = '1' — a question that disappears;
 *  - Q5 (optional, 第二部分) is SHOWN once Q1 = '1' — a question that appears.
 * So the progress denominator must move in both directions as the respondent
 * answers the single gating question.
 */
const QUESTIONS: TestQuestion[] = [
  {
    question_code: 'Q1',
    question_text: '您是否使用过家庭教育机构？',
    question_type: 'single',
    required: true,
    section: '第一部分　基本信息',
    options: {
      choices: [
        { value: '1', label: '从未使用' },
        { value: '2', label: '使用过' },
      ],
    },
  },
  {
    question_code: 'Q2',
    question_text: '请评价您的满意程度。',
    question_type: 'single',
    required: true,
    section: '第一部分　基本信息',
    options: {
      choices: [
        { value: '1', label: '不满意' },
        { value: '2', label: '满意' },
      ],
    },
    logic: {
      rules: [
        {
          id: 'hide-q2',
          match: 'all',
          conditions: [{ questionCode: 'Q1', operator: 'eq', value: '1' }],
          action: { type: 'hide' },
        },
      ],
    },
  },
  {
    question_code: 'Q3',
    question_text: '未来您愿意使用吗？',
    question_type: 'single',
    required: true,
    section: '第二部分　需求与建议',
    options: {
      choices: [
        { value: '1', label: '不愿意' },
        { value: '2', label: '愿意' },
      ],
    },
  },
  {
    question_code: 'Q4',
    question_text: '请留下您的建议（选填）。',
    question_type: 'textarea',
    required: false,
    section: '第二部分　需求与建议',
    options: { maxLength: 200, placeholder: '选填' },
  },
  {
    question_code: 'Q5',
    question_text: '请填写您使用过的机构名称（选填）。',
    question_type: 'text',
    required: false,
    section: '第二部分　需求与建议',
    options: { maxLength: 60, placeholder: '若无请留空' },
    logic: {
      rules: [
        {
          id: 'show-q5',
          match: 'all',
          conditions: [{ questionCode: 'Q1', operator: 'eq', value: '1' }],
          action: { type: 'show' },
        },
      ],
    },
  },
];

const INSTRUMENT = {
  questionnaire: {
    id: 'qn-1',
    title: '家庭教育认知、实践与社会支持需求调查',
    description: '本问卷用于了解家长在家庭教育方面的需求。',
    version: 'V4.0',
    status: 'published',
  },
  project: { title: '家庭教育研究', target_sample_size: 1000 },
  consent_text: '本研究为匿名调查。参与完全自愿，您可以拒绝回答任何问题，也可以随时退出。',
  consent_is_platform_default: false,
  ethics_points: ['本研究为匿名调查，不会收集您的姓名或手机号。', '参与完全自愿。'],
  anonymous: true,
  allow_partial: false,
  min_duration_seconds: 90,
  accepting_responses: true,
  question_count: 5,
  questions: QUESTIONS,
};

const RESPONDENT = {
  id: 'resp-1',
  questionnaire_id: 'qn-1',
  project_id: 'p-1',
  anonymous_id: 'A0007',
  source: 'wechat',
  started_at: '2026-01-01T00:00:00.000Z',
  completed_at: null,
  duration_seconds: null,
  status: 'in_progress',
  quality_score: null,
  current_question_code: 'Q1',
  answered_count: 0,
  last_activity_at: null,
  consent_given_at: '2026-01-01T00:00:00.000Z',
  review_status: 'unreviewed',
  review_note: null,
  created_at: '2026-01-01T00:00:00.000Z',
};

const SHARE_TOKEN = 'share-token-abc';
const SESSION_TOKEN = 'session-token-xyz';
const LOCAL_KEY = 'ferp.survey.session.share-token-abc';

/** Render the single-page questionnaire at /research/<token>/all. */
async function renderFlat(shareToken = SHARE_TOKEN, query = ''): Promise<void> {
  await render(
    createElement(
      MemoryRouter,
      { initialEntries: [`/research/${shareToken}/all${query}`] },
      createElement(
        Routes,
        null,
        createElement(Route, {
          path: '/research/:shareToken/all',
          element: createElement(SurveyFlatPage),
        }),
      ),
    ),
  );
}

/** Stub covering the whole public API surface the page touches. */
function stubFlatApi(overrides: Partial<Record<'answer' | 'complete', (call: FetchCall) => Response>> = {}): {
  calls: FetchCall[];
  restore: () => void;
} {
  return stubFetch((call: FetchCall) => {
    if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });

    if (call.url.includes(`/sessions/${SESSION_TOKEN}`) && call.method === 'GET') {
      return jsonResponse({
        data: {
          respondent: RESPONDENT,
          answers: {},
          hidden_question_codes: [],
          missing_required: [],
        },
      });
    }

    if (call.url.includes('/sessions') && call.method === 'POST' && !call.url.includes('/complete')) {
      return jsonResponse({ data: { session_token: SESSION_TOKEN, respondent: RESPONDENT } }, 201);
    }

    if (call.url.includes('/answers')) {
      if (overrides.answer) return overrides.answer(call);
      const body = call.body as { question_code: string; value: unknown };
      return jsonResponse({
        data: {
          respondent: { ...RESPONDENT, answered_count: 1, current_question_code: body.question_code },
          question_code: body.question_code,
          stored: body.value,
          pruned_question_codes: [],
          answered_count: 1,
        },
      });
    }

    if (call.url.includes('/complete')) {
      if (overrides.complete) return overrides.complete(call);
      return jsonResponse({
        data: {
          respondent: {
            ...RESPONDENT,
            status: 'completed',
            completed_at: '2026-01-01T00:10:00.000Z',
            duration_seconds: 600,
          },
          completed: true,
          missing_required: [],
        },
      });
    }

    return jsonResponse({ data: null });
  });
}

/** Consent, then land on the questionnaire. */
async function startFlat(): Promise<{ calls: FetchCall[]; restore: () => void }> {
  const stub = stubFlatApi();
  await renderFlat(SHARE_TOKEN, '?source=wechat');
  await flush();
  const start = findButton('开始作答');
  assert.ok(start, '应能找到开始作答按钮');
  await click(start!);
  await flush();
  return stub;
}

function findButton(label: string): Element | undefined {
  return queryAll('button').find((button) => (button.textContent ?? '').includes(label));
}

function renderedCodes(): string[] {
  return queryAll('[data-question-code]').map(
    (element) => element.getAttribute('data-question-code') ?? '',
  );
}

function radiosOf(code: string): Element[] {
  const article = document.querySelector(`[data-question-code="${code}"]`);
  return article ? Array.from(article.querySelectorAll('input[type="radio"]')) : [];
}

function answer(code: string, optionIndex: number): Promise<void> {
  const radios = radiosOf(code);
  assert.ok(radios[optionIndex], `题目 ${code} 应至少有 ${optionIndex + 1} 个选项`);
  return click(radios[optionIndex]!);
}

beforeEach(async () => {
  await unmount();
  clearContainer();
  window.localStorage.clear();
});

after(async () => {
  await unmount();
  closeDom();
});

/* ================================================================== */
/* Consent gate                                                       */
/* ================================================================== */

describe('整页问卷：知情同意', () => {
  test('同意之前不渲染任何题目', async () => {
    const stub = stubFlatApi();
    try {
      await renderFlat();
      await flush();

      const content = text();
      assert.match(content, /知情同意说明/, '同意页应展示知情同意说明');
      assert.match(content, /参与完全自愿/);
      assert.match(content, /5 题/, '同意页应展示题目数量');
      assert.equal(queryAll('[data-question-code]').length, 0, '同意前不应渲染任何题目');
      assert.ok(!content.includes('您是否使用过家庭教育机构'), '同意前不应出现题干');
      assert.ok(findButton('开始作答'), '应有开始作答按钮');
    } finally {
      stub.restore();
    }
  });

  test('问卷已关闭时给出结束提示且没有开始按钮', async () => {
    const stub = stubFetch(() =>
      jsonResponse({ data: { ...INSTRUMENT, accepting_responses: false } }),
    );
    try {
      await renderFlat();
      await flush();
      assert.match(text(), /本次调查已结束/);
      assert.equal(findButton('开始作答'), undefined);
      assert.equal(queryAll('[data-question-code]').length, 0);
    } finally {
      stub.restore();
    }
  });

  test('链接无效时给出可操作的提示', async () => {
    const stub = stubFetch(() =>
      jsonResponse({ error: { code: 'NOT_FOUND', message: '问卷链接无效或已被撤销。', details: null } }, 404),
    );
    try {
      await renderFlat('bad-token');
      await flush();
      assert.match(text(), /无法打开问卷/);
      assert.match(text(), /确认链接是否正确/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Whole instrument on one page                                       */
/* ================================================================== */

describe('整页问卷：一页显示全部题目', () => {
  test('一页渲染全部可见题目，并按部分分组、按题号编号', async () => {
    const stub = await startFlat();
    try {
      // Q5 由分支逻辑控制（Q1 = '1' 才出现），因此可见题目为 4 道、全卷 5 道。
      assert.deepEqual(renderedCodes(), ['Q1', 'Q2', 'Q3', 'Q4'], '一页应渲染全部可见题目');

      const content = text();
      assert.match(content, /第一部分　基本信息/, '应按部分分组展示标题');
      assert.match(content, /第二部分　需求与建议/, '应展示最后一部分的标题');
      assert.match(content, /请留下您的建议（选填）/, '无需任何交互即应渲染最后一部分的题目');
      assert.match(content, /您是否使用过家庭教育机构/, '应渲染第一题');
      assert.match(content, /请评价您的满意程度/, '应渲染条件为真的题目');

      // 每道题都带有题号（QuestionPreview 渲染 question_code）与顺序编号。
      assert.match(content, /第 1 题/);
      assert.match(content, /第 4 题/);
      assert.equal(content.includes('请填写您使用过的机构名称'), false, '未满足显示条件的分支题不应出现');
      assert.match(content, /已答 0 \/ 4 题/, '进度分母应为当前可见题目数');
      assert.ok(findButton('提交问卷'), '底部应有唯一的提交按钮');
      assert.equal(
        queryAll('button').filter((button) => (button.textContent ?? '').includes('提交问卷')).length,
        1,
        '整页问卷只应有一个提交按钮',
      );
    } finally {
      stub.restore();
    }
  });

  test('顶部提供切回逐题模式的链接', async () => {
    const stub = await startFlat();
    try {
      const link = queryAll('a').find((anchor) =>
        (anchor.textContent ?? '').includes('切换为逐题模式'),
      );
      assert.ok(link, '整页问卷应提供切回逐题模式的入口');
      assert.equal(link!.getAttribute('href'), `/research/${SHARE_TOKEN}?source=wechat`);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Conditional logic + progress                                       */
/* ================================================================== */

describe('整页问卷：条件逻辑实时生效', () => {
  test('作答分支题后依赖题目消失/出现，进度分母同步变化', async () => {
    const stub = await startFlat();
    try {
      assert.deepEqual(renderedCodes(), ['Q1', 'Q2', 'Q3', 'Q4']);
      assert.match(text(), /已答 0 \/ 4 题/);

      // Q1 = 从未使用 → Q2（满意程度）隐藏，Q5（使用过的机构）出现，分母不变。
      await answer('Q1', 0);
      await flush();

      assert.deepEqual(
        renderedCodes(),
        ['Q1', 'Q3', 'Q4', 'Q5'],
        'Q2 应消失、Q5 应出现',
      );
      const content = text();
      assert.equal(content.includes('请评价您的满意程度'), false, '被隐藏的题目不应渲染');
      assert.match(content, /请填写您使用过的机构名称/, '新分支题目应出现');
      assert.match(content, /已答 1 \/ 4 题/, '作答数应更新');

      // Q1 = 使用过 → Q2 重新出现，Q5 隐藏。
      await answer('Q1', 1);
      await flush();
      assert.deepEqual(renderedCodes(), ['Q1', 'Q2', 'Q3', 'Q4'], '切回后应恢复原分支');
      assert.match(text(), /请评价您的满意程度/);
      assert.equal(text().includes('请填写您使用过的机构名称'), false);
      assert.match(text(), /已答 1 \/ 4 题/);
    } finally {
      stub.restore();
    }
  });

  test('被隐藏的题目不计入必答校验', async () => {
    const stub = await startFlat();
    try {
      await answer('Q1', 1); // 使用过 → Q2 保持必答
      await flush();
      await answer('Q2', 0); // 作答 Q2
      await flush();

      // Q3 为唯一未作答的可见必答题；Q2 已作答，Q5 隐藏（选填）。
      await click(findButton('提交问卷')!);
      await flush();

      const content = text();
      assert.match(content, /还有 1 道必答题未作答/);
      assert.match(content, /Q3/);
      assert.equal(
        stub.calls.filter((call) => call.url.includes('/complete')).length,
        0,
        '存在未答必答题时不应提交',
      );
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Autosave                                                           */
/* ================================================================== */

describe('整页问卷：自动保存', () => {
  test('修改作答后会以防抖方式提交该题的 PATCH', async () => {
    const stub = await startFlat();
    try {
      await answer('Q1', 1); // 使用过
      // 等待自动保存的防抖计时器
      await new Promise((resolve) => setTimeout(resolve, 700));
      await flush();

      const saves = stub.calls.filter((call) => call.url.includes('/answers'));
      assert.equal(saves.length, 1, '应恰好发出一次自动保存请求');
      assert.equal(saves[0]!.method, 'PATCH');
      assert.ok(saves[0]!.url.includes(SESSION_TOKEN), '应保存到当前会话');
      assert.deepEqual(saves[0]!.body, { question_code: 'Q1', value: '2' });
      assert.match(text(), /已自动保存/);
    } finally {
      stub.restore();
    }
  });

  test('防抖窗口内多题作答会各自保存', async () => {
    const stub = await startFlat();
    try {
      await answer('Q1', 1);
      await answer('Q3', 1);
      await new Promise((resolve) => setTimeout(resolve, 700));
      await flush();

      const bodies = stub.calls
        .filter((call) => call.url.includes('/answers'))
        .map((call) => call.body as { question_code: string; value: unknown });
      assert.deepEqual(bodies, [
        { question_code: 'Q1', value: '2' },
        { question_code: 'Q3', value: '2' },
      ]);
    } finally {
      stub.restore();
    }
  });

  test('保存失败时如实显示保存失败', async () => {
    const stub = stubFlatApi({
      answer: () => jsonResponse({ error: { code: 'INTERNAL_ERROR', message: '服务器暂时不可用。', details: null } }, 500),
    });
    try {
      await renderFlat();
      await flush();
      await click(findButton('开始作答')!);
      await flush();

      await answer('Q1', 1);
      await new Promise((resolve) => setTimeout(resolve, 700));
      await flush();

      assert.match(text(), /保存失败/, '应如实提示保存失败');
      assert.match(text(), /服务器暂时不可用/, '应展示服务端返回的原因');
    } finally {
      stub.restore();
    }
  });

  test('保存失败后再次作答会一并重试未保存的题目', async () => {
    let failing = true;
    const stub = stubFlatApi({
      answer: (call: FetchCall) => {
        if (failing) {
          return jsonResponse(
            { error: { code: 'INTERNAL_ERROR', message: '服务器暂时不可用。', details: null } },
            500,
          );
        }
        const body = call.body as { question_code: string; value: unknown };
        return jsonResponse({
          data: {
            respondent: RESPONDENT,
            question_code: body.question_code,
            stored: body.value,
            pruned_question_codes: [],
            answered_count: 1,
          },
        });
      },
    });
    try {
      await renderFlat();
      await flush();
      await click(findButton('开始作答')!);
      await flush();

      await answer('Q1', 1);
      await new Promise((resolve) => setTimeout(resolve, 700));
      await flush();
      assert.match(text(), /保存失败/);

      // 网络恢复后作答另一题：失败的那题应一并重试。
      failing = false;
      await answer('Q3', 1);
      await new Promise((resolve) => setTimeout(resolve, 700));
      await flush();

      const bodies = stub.calls
        .filter((call) => call.url.includes('/answers'))
        .map((call) => call.body as { question_code: string; value: unknown });
      assert.deepEqual(bodies, [
        { question_code: 'Q1', value: '2' },
        { question_code: 'Q1', value: '2' },
        { question_code: 'Q3', value: '2' },
      ], '未保存的 Q1 应在下一次保存时重试');
      assert.match(text(), /已自动保存/);
      assert.equal(text().includes('保存失败'), false, '保存恢复后不应继续显示失败状态');
      assert.match(text(), /已答 2 \/ 4 题/);
    } finally {
      stub.restore();
    }
  });

  test('提交前会先冲刷未保存的作答', async () => {
    const stub = await startFlat();
    try {
      // Q1 = 从未使用：Q2 被隐藏，可见必答题只有 Q1、Q3，两题均已作答。
      await answer('Q1', 0);
      await answer('Q3', 1);
      // 不等待防抖，直接提交：提交必须先把待保存作答发出去。
      await click(findButton('提交问卷')!);
      await flush();

      const answerCalls = stub.calls.filter((call) => call.url.includes('/answers'));
      assert.equal(answerCalls.length, 2, '提交前应保存两题');
      // 调用顺序：加载问卷 → 创建会话 → 保存 Q1 → 保存 Q3 → 提交
      assert.deepEqual(
        stub.calls.map((call) => call.method),
        ['GET', 'POST', 'PATCH', 'PATCH', 'POST'],
        '两题作答必须先于提交请求发出',
      );
      assert.match(text(), /提交成功/);
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Submit                                                             */
/* ================================================================== */

describe('整页问卷：提交', () => {
  test('存在未作答必答题时阻止提交，并指出数量与题号', async () => {
    const stub = await startFlat();
    try {
      await click(findButton('提交问卷')!);
      await flush();

      const content = text();
      assert.match(content, /还有 3 道必答题未作答/, '应指出缺失的必答题数量');
      assert.match(content, /Q1、Q2、Q3/, '应列出缺失的题号');
      assert.match(content, /请完成以下必答题后再提交/);
      assert.equal(
        stub.calls.filter((call) => call.url.includes('/complete')).length,
        0,
        '客户端校验不通过时不应发送提交请求',
      );

      // 应定位到第一道未作答的必答题。
      const focused = document.activeElement;
      const owner = focused?.closest('[data-question-code]');
      assert.equal(owner?.getAttribute('data-question-code'), 'Q1', '应定位到第一道未答必答题');
    } finally {
      stub.restore();
    }
  });

  test('全部必答题作答后提交成功并展示完成页', async () => {
    const stub = await startFlat();
    try {
      await answer('Q1', 1); // 使用过（Q2 保持可见）
      await answer('Q2', 1);
      await answer('Q3', 1);
      await flush();

      assert.match(text(), /已答 3 \/ 4 题/, '进度应按可见题目统计');

      await click(findButton('提交问卷')!);
      await flush();

      const completes = stub.calls.filter((call) => call.url.includes('/complete'));
      assert.equal(completes.length, 1, '应发出一次提交请求');
      assert.equal(completes[0]!.method, 'POST');
      assert.ok(completes[0]!.url.includes(SESSION_TOKEN));

      const content = text();
      assert.match(content, /提交成功/);
      assert.match(content, /A0007/);
      assert.match(content, /不会被单独识别/);
      assert.equal(queryAll('[data-question-code]').length, 0, '提交后不应再渲染题目');
    } finally {
      stub.restore();
    }
  });

  test('服务端仍判定缺少必答题时展示其原始中文提示', async () => {
    const stub = stubFlatApi({
      complete: () =>
        jsonResponse(
          {
            error: {
              code: 'VALIDATION_ERROR',
              message: '还有 1 道必答题未完成，无法提交。',
              details: [{ field: 'Q3', message: '必答题 Q3 尚未作答。' }],
            },
          },
          400,
        ),
    });
    try {
      await renderFlat();
      await flush();
      await click(findButton('开始作答')!);
      await flush();

      await answer('Q1', 1);
      await answer('Q2', 1);
      await answer('Q3', 1);
      await flush();

      await click(findButton('提交问卷')!);
      await flush();

      assert.match(text(), /还有 1 道必答题未完成，无法提交/, '应展示服务端的中文提示');
      assert.match(text(), /提交失败|无法提交/, '应停留在作答页');
      assert.equal(
        queryAll('[data-question-code]').length > 0,
        true,
        '提交失败后应仍显示问卷',
      );
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Resume                                                             */
/* ================================================================== */

describe('整页问卷：续答', () => {
  test('localStorage 中已有会话时载入已作答内容（与逐题模式共用会话键）', async () => {
    window.localStorage.setItem(LOCAL_KEY, SESSION_TOKEN);

    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      if (call.url.includes(`/sessions/${SESSION_TOKEN}`)) {
        return jsonResponse({
          data: {
            respondent: { ...RESPONDENT, current_question_code: 'Q3', answered_count: 2 },
            answers: { Q1: '2', Q3: '1' },
            hidden_question_codes: ['Q5'],
            missing_required: ['Q2'],
          },
        });
      }
      return jsonResponse({ data: null });
    });

    try {
      await renderFlat();
      await flush();

      const content = text();
      assert.ok(!content.includes('知情同意说明'), '已有会话时不应再次要求知情同意');
      assert.match(content, /已答 2 \/ 4 题/, '进度应反映已恢复的作答');
      assert.deepEqual(renderedCodes(), ['Q1', 'Q2', 'Q3', 'Q4']);

      const q1 = radiosOf('Q1');
      assert.equal((q1[1] as HTMLInputElement).checked, true, 'Q1 应恢复为「使用过」');
      assert.equal((q1[0] as HTMLInputElement).checked, false);
      const q3 = radiosOf('Q3');
      assert.equal((q3[0] as HTMLInputElement).checked, true, 'Q3 应恢复为「不愿意」');
    } finally {
      stub.restore();
    }
  });

  test('会话已失效时清除本地令牌并回到知情同意页', async () => {
    window.localStorage.setItem(LOCAL_KEY, 'expired-token');

    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      if (call.url.includes('/expired-token')) {
        return jsonResponse(
          { error: { code: 'NOT_FOUND', message: '作答会话不存在或已失效。', details: null } },
          404,
        );
      }
      return jsonResponse({ data: null });
    });

    try {
      await renderFlat();
      await flush();

      assert.match(text(), /知情同意说明/);
      assert.equal(window.localStorage.getItem(LOCAL_KEY), null);
      assert.equal(queryAll('[data-question-code]').length, 0);
    } finally {
      stub.restore();
    }
  });

  test('已完成的会话再次打开时直接展示完成页，不会重复提交', async () => {
    window.localStorage.setItem(LOCAL_KEY, SESSION_TOKEN);

    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      if (call.url.includes(`/sessions/${SESSION_TOKEN}`)) {
        return jsonResponse({
          data: {
            respondent: {
              ...RESPONDENT,
              status: 'completed',
              completed_at: '2026-01-01T00:10:00.000Z',
            },
            answers: { Q1: '2', Q2: '1', Q3: '1' },
            hidden_question_codes: [],
            missing_required: [],
          },
        });
      }
      return jsonResponse({ data: null });
    });

    try {
      await renderFlat();
      await flush();

      assert.match(text(), /提交成功/);
      assert.match(text(), /A0007/);
      assert.equal(
        stub.calls.filter((call) => call.url.includes('/complete')).length,
        0,
        '刷新已完成的会话不应再次提交',
      );
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Routing                                                            */
/* ================================================================== */

describe('整页问卷：公共路由', () => {
  /** Render the real App router at a public path (no login involved). */
  async function renderAppAt(path: string): Promise<void> {
    await render(
      createElement(
        MemoryRouter,
        { initialEntries: [path] },
        createElement(AuthProvider, null, createElement(App)),
      ),
    );
    await flush();
  }

  test('/research/:shareToken/all 走整页问卷，逐题模式路由保持不变', async () => {
    const stub = stubFlatApi();
    try {
      await renderAppAt(`/research/${SHARE_TOKEN}/all`);
      assert.match(text(), /整页问卷（一页答完）/, '整页模式应由新路由渲染');
      assert.match(text(), /知情同意说明/);

      await unmount();
      clearContainer();

      await renderAppAt(`/research/${SHARE_TOKEN}`);
      const stepper = text();
      assert.match(stepper, /预计用时/, '逐题模式仍由原路由渲染');
      assert.equal(stepper.includes('整页问卷（一页答完）'), false, '两条路由不应互相覆盖');
    } finally {
      stub.restore();
    }
  });
});

/* ================================================================== */
/* Network failure                                                    */
/* ================================================================== */

describe('整页问卷：网络异常', () => {
  test('加载失败时给出诚实的错误状态并可重试', async () => {
    let failing = true;
    const stub = stubFetch(() => {
      if (failing) throw new Error('socket hang up');
      return jsonResponse({ data: INSTRUMENT });
    });

    try {
      await renderFlat();
      await flush();

      assert.match(text(), /无法打开问卷/);
      assert.match(text(), /无法连接研究平台服务/, '应说明是网络/服务连接问题');

      // 网络恢复后重试应能进入问卷。
      failing = false;
      const retry = findButton('重新加载');
      assert.ok(retry, '应提供重试入口');
      await click(retry!);
      await flush();

      assert.match(text(), /知情同意说明/);
      assert.ok(findButton('开始作答'));
    } finally {
      stub.restore();
    }
  });

  test('开始作答时的网络失败不会创建本地会话令牌', async () => {
    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/instrument')) return jsonResponse({ data: INSTRUMENT });
      throw new Error('socket hang up');
    });

    try {
      await renderFlat();
      await flush();
      await click(findButton('开始作答')!);
      await flush();

      assert.match(text(), /无法连接研究平台服务/);
      assert.equal(window.localStorage.getItem(LOCAL_KEY), null, '未创建会话时不应写入令牌');
    } finally {
      stub.restore();
    }
  });
});
