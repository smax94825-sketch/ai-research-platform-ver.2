/**
 * Analysis API tests (PHASE 5).
 *
 * These tests run the statistical engine against data that was actually
 * collected through the public survey API, so the whole chain is covered:
 * questionnaire definition → respondent answers → database → dataset builder →
 * statistical engine → HTTP payload.
 *
 * The instrument deliberately reuses the real V4.0 question codes. That is not
 * cosmetic: the engine only materialises the derived construct variables (FSE,
 * DSD, UI, WTP …) and the scale definitions for reliability analysis when the
 * questionnaire is recognised as template-derived, and those variables are what
 * the default correlation and regression specifications refer to. The synthetic
 * answers are generated from a known data-generating process with a fixed seed,
 * so the assertions below can check the *direction* of real effects rather than
 * merely that a number came back.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import {
  api,
  createPublishedQuestionnaire,
  createTestContext,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type TestContext,
} from './helpers.js';

let ctx: TestContext;
let fixture: AnalysisFixture;

after(async () => {
  await ctx.close();
});

/* ================================================================== */
/* Instrument                                                         */
/* ================================================================== */

const AGREE = [
  { value: '1', label: '非常不同意', score: 1 },
  { value: '2', label: '比较不同意', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较同意', score: 4 },
  { value: '5', label: '非常同意', score: 5 },
];

const MEAN_5 = { type: 'mean', min: 1, max: 5 };
const ORDINAL_5 = { type: 'ordinal', codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 } };

/** A single-choice / Likert question scored 1—5. */
function likert(
  code: string,
  variable: string,
  dimension: string,
  rule: Record<string, unknown> = MEAN_5,
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'likert',
    required: true,
    dimension,
    variable_name: variable,
    options: { choices: AGREE, scaleMin: 1, scaleMax: 5 },
    scoring_rule: rule,
  };
}

/** A matrix question; each row becomes its own item variable. */
function matrix(
  code: string,
  variable: string,
  dimension: string,
  rowCount: number,
): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'matrix',
    required: true,
    dimension,
    variable_name: variable,
    options: {
      matrix: {
        rows: Array.from({ length: rowCount }, (_, i) => ({ value: String(i + 1), label: `方面${i + 1}` })),
        columns: AGREE,
      },
      scaleMin: 1,
      scaleMax: 5,
    },
    scoring_rule: MEAN_5,
  };
}

const STAGES = ['学前（0—6岁）', '小学', '初中', '高中'];

const STAGE_QUESTION: Record<string, unknown> = {
  question_code: 'Q5',
  question_text: '孩子目前所处学段',
  question_type: 'single',
  required: true,
  dimension: '基本信息',
  variable_name: 'STAGE',
  options: {
    choices: STAGES.map((label, i) => ({ value: String(i + 1), label, score: i + 1 })),
  },
  scoring_rule: { type: 'categorical', codes: { '1': 1, '2': 2, '3': 3, '4': 4 } },
};

const FSE_CODES = ['Q22', 'Q23', 'Q24', 'Q25', 'Q26', 'Q27', 'Q28', 'Q29', 'Q30'];

const QUESTIONS: Record<string, unknown>[] = [
  STAGE_QUESTION,
  likert('Q6', 'FEI1', '家庭教育认知'),
  likert('Q7', 'FEI2', '家庭教育认知'),
  likert('Q8', 'FEI3', '家庭教育认知'),
  likert('Q9', 'FEK', '家庭教育认知'),
  likert('Q19', 'ISC1', '信息获取渠道'),
  likert('Q20', 'ISC2', '信息获取渠道'),
  ...FSE_CODES.map((code, i) => likert(code, `FSE${i + 1}`, '家庭教育自我效能')),
  likert('Q31', 'FPB1', '家庭教育实际行为'),
  likert('Q33', 'FPB2', '家庭教育实际行为'),
  likert('Q34', 'FPB3', '家庭教育实际行为'),
  matrix('Q35', 'FED', '家庭教育困难', 7),
  likert('Q43', 'PSA1', '政府家庭教育公共服务'),
  likert('Q44', 'PSA2', '政府家庭教育公共服务'),
  likert('Q45', 'PSU1', '政府家庭教育公共服务'),
  likert('Q46', 'PSU2', '政府家庭教育公共服务'),
  matrix('Q48', 'STI', '服务主体信任', 6),
  matrix('Q49', 'DSD', '数字化家庭教育服务需求', 6),
  likert('Q50', 'UI', 'AI家庭教育服务接受度', ORDINAL_5),
  matrix('Q51', 'PRC', 'AI服务风险认知', 5),
  likert('Q52', 'AIPV', 'AI家庭教育服务接受度'),
  likert('Q53', 'WTP', '家庭教育服务付费意愿', ORDINAL_5),
];

/* ================================================================== */
/* Data-generating process                                            */
/* ================================================================== */

/**
 * Linear congruential generator.
 *
 * A fixed seed keeps the synthetic sample identical on every run, so a failure
 * points at a code change rather than at sampling noise.
 */
function lcg(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

/** Standard normal via the Irwin–Hall approximation. */
function gaussian(rand: () => number): number {
  let sum = 0;
  for (let i = 0; i < 12; i += 1) sum += rand();
  return sum - 6;
}

/** Clamp a latent score onto the 1—5 Likert scale. */
function lk(value: number): number {
  return Math.min(5, Math.max(1, Math.round(value)));
}

function mean(values: number[]): number {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function matrixAnswer(values: number[]): Record<string, string> {
  const answer: Record<string, string> = {};
  values.forEach((value, index) => {
    answer[String(index + 1)] = String(value);
  });
  return answer;
}

const SAMPLE_SIZE = 48;

interface GeneratedSample {
  stage: number;
  answers: Record<string, unknown>;
}

/**
 * One synthetic respondent.
 *
 * Every construct is driven by a *person-level* trait plus item-level noise.
 * That structure is not decoration: the engine averages a matrix question's rows
 * into one construct, and if the rows carried only independent noise the average
 * would cancel nearly all between-person variance and no relationship in the data
 * would be detectable. The traits are what make the study's hypotheses real
 * relationships in the sample rather than wishful labels.
 *
 * Encoded hypotheses (they are the assertions made further down):
 *   H1 knowledge → self-efficacy          (shared ability trait)
 *   H2 self-efficacy → practice           (practice is built from efficacy)
 *   H3 difficulty → digital demand        (demand responds to difficulty)
 *   H4 access → public-service use        (use is built from access)
 *   H5 trust → digital demand             (demand responds to trust)
 *   H6 perceived value → intention        (DELIBERATELY ABSENT — see below)
 *   H7 risk perception → intention        (risk suppresses intention)
 *   H8 demand → willingness to pay        (payment follows demand)
 *
 * H6 is deliberately left as a genuine null: perceived value is generated
 * independently of intention, so the engine must report that hypothesis as
 * "inconclusive" rather than manufacture support for it. That is the honesty
 * path, and it is only testable with a relationship that truly is not there.
 *
 * Stage additionally shifts difficulty and access, which gives the group
 * comparison something real to detect.
 */
function generateSample(rand: () => number, index: number): GeneratedSample {
  const stage = (index % STAGES.length) + 1;
  const g = (): number => gaussian(rand);

  const traitAbility = g();
  const traitDifficulty = g();
  const traitTrust = g();
  const traitRisk = g();
  const traitValue = g();
  const traitAccess = g();
  const traitDigital = g();

  const feiItems = [0, 1, 2].map(() => lk(3.2 + 0.3 * traitAbility + 0.5 * g()));
  const fek = lk(3.0 + 0.75 * traitAbility + 0.3 * g());
  const iscItems = [0, 1].map(() => lk(3.0 + 0.4 * g()));

  const fseItems = Array.from({ length: 9 }, () => lk(3.0 + 0.8 * traitAbility + 0.3 * g()));
  const fse = mean(fseItems);
  const fpbItems = [0, 1, 2].map(() => lk(0.9 + 0.6 * fse + 0.35 * g()));

  const fedRows = Array.from({ length: 7 }, () =>
    lk(1.7 + 0.35 * stage + 0.6 * traitDifficulty + 0.4 * g()),
  );
  const fed = mean(fedRows);

  const stiRows = Array.from({ length: 6 }, () => lk(2.9 + 0.75 * traitTrust + 0.45 * g()));
  const sti = mean(stiRows);

  const dsdRows = Array.from({ length: 6 }, () =>
    lk(1.3 + 0.28 * fed + 0.3 * sti + 0.5 * traitDigital + 0.4 * g()),
  );
  const dsd = mean(dsdRows);

  const psaItems = [0, 1].map(() => lk(2.9 - 0.18 * stage + 0.75 * traitAccess + 0.4 * g()));
  const psa = mean(psaItems);
  const psuItems = [0, 1].map(() => lk(1.0 + 0.6 * psa + 0.4 * g()));

  const prcRows = Array.from({ length: 5 }, () => lk(3.0 + 0.7 * traitRisk + 0.4 * g()));
  const prc = mean(prcRows);

  // traitValue shapes perceived value but deliberately does NOT enter intention.
  const aipv = lk(3.0 + 0.7 * traitValue + 0.4 * g());

  const uiLatent =
    3.0 + 0.4 * (sti - 3) - 0.4 * (prc - 3) + 0.5 * (dsd - 3) + 0.7 * g();
  const ui = lk(uiLatent);

  const wtp = lk(0.6 + 0.5 * dsd + 0.35 * aipv + 0.4 * g());

  const answers: Record<string, unknown> = {
    Q5: String(stage),
    Q6: String(feiItems[0]!),
    Q7: String(feiItems[1]!),
    Q8: String(feiItems[2]!),
    Q9: String(fek),
    Q19: String(iscItems[0]!),
    Q20: String(iscItems[1]!),
    Q31: String(fpbItems[0]!),
    Q33: String(fpbItems[1]!),
    Q34: String(fpbItems[2]!),
    Q35: matrixAnswer(fedRows),
    Q43: String(psaItems[0]!),
    Q44: String(psaItems[1]!),
    Q45: String(psuItems[0]!),
    Q46: String(psuItems[1]!),
    Q48: matrixAnswer(stiRows),
    Q49: matrixAnswer(dsdRows),
    Q50: String(ui),
    Q51: matrixAnswer(prcRows),
    Q52: String(aipv),
    Q53: String(wtp),
  };

  FSE_CODES.forEach((code, position) => {
    answers[code] = String(fseItems[position]!);
  });

  return { stage, answers };
}

/* ================================================================== */
/* Shared fixture                                                     */
/* ================================================================== */

interface AnalysisFixture {
  token: string;
  projectId: string;
  respondents: string[];
}

/**
 * Collect the whole sample once, then exclude a single completed respondent.
 *
 * The exclusion is deliberate: it is the only way to prove that excluded
 * samples are removed from the analysis base *and* that their removal is
 * reported, which is a promise the bundle makes to every downstream reader.
 */
before(async () => {
  ctx = await createTestContext();
  const researcher = await registerResearcher(ctx, { name: '统计分析研究者' });
  const created = await createPublishedQuestionnaire(
    ctx,
    researcher.token,
    QUESTIONS,
    '统计分析测试研究',
  );

  const rand = lcg(20260421);
  const respondents: string[] = [];

  for (let index = 0; index < SAMPLE_SIZE; index += 1) {
    const { answers } = generateSample(rand, index);
    const session = await startSession(ctx, created.shareToken, index % 3 === 0 ? 'wechat' : 'school');

    for (const [code, value] of Object.entries(answers)) {
      const saved = await saveAnswer(ctx, session.token, code, value);
      assert.equal(saved.status, 200, `${code} 保存失败：${JSON.stringify(saved.error)}`);
    }

    const submitted = await submitSession(ctx, session.token);
    assert.equal(submitted.status, 200, `提交失败：${JSON.stringify(submitted.error)}`);
    respondents.push(session.respondentId);
  }

  const excluded = await api(ctx, 'POST', `/api/respondents/${respondents[0]!}/review`, {
    token: researcher.token,
    body: { status: 'excluded', note: '作答时间异常的样本，已排除' },
  });
  assert.equal(excluded.status, 200, `排除样本失败：${JSON.stringify(excluded.error)}`);

  fixture = { token: researcher.token, projectId: created.projectId, respondents };
});

/* ================================================================== */
/* Dataset inventory                                                  */
/* ================================================================== */

describe('分析数据集接口', () => {
  test('派生构念与量表被正确物化，默认分析规格可用', async () => {
    const response = await api<{
      engine_version: string;
      sample: { analysable: number; excluded: number; respondents_total: number };
      variables: { name: string; is_derived: boolean; n: number; data_type: string }[];
      derived_variable_count: number;
      available: {
        correlation_variables: string[];
        regression_dependent: string | null;
        regression_predictors: string[];
        comparison_factor: string | null;
        comparison_dependents: string[];
      };
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/dataset`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    // One completed respondent was excluded, so it must not be in the base.
    assert.equal(data.sample.respondents_total, SAMPLE_SIZE);
    assert.equal(data.sample.excluded, 1);
    assert.equal(data.sample.analysable, SAMPLE_SIZE - 1);

    const names = data.variables.map((variable) => variable.name);
    for (const construct of ['FSE', 'FEK', 'FPB', 'FED', 'PSA', 'PSU', 'STI', 'DSD', 'UI', 'PRC', 'AIPV', 'WTP']) {
      assert.ok(names.includes(construct), `缺少派生构念 ${construct}`);
    }
    assert.ok(names.includes('Q35_1') === false, '矩阵题不应以未展开的名称出现');
    assert.ok(names.includes('FED1'), '矩阵题每一行都应是独立条目变量');

    const fse = data.variables.find((variable) => variable.name === 'FSE');
    assert.ok(fse, '缺少 FSE');
    assert.equal(fse.is_derived, true, 'FSE 应为派生均值变量');
    assert.equal(fse.data_type, 'interval');
    assert.equal(fse.n, SAMPLE_SIZE - 1, '样本量不足的条目会被整例删除，此处所有条目均已作答');

    // A matrix question produces both per-row items and its own dimension mean;
    // the mean is derived by a different mechanism than a multi-item composite.
    const dsd = data.variables.find((variable) => variable.name === 'DSD');
    assert.ok(dsd, '缺少矩阵题的维度均值 DSD');
    assert.equal(dsd.is_derived, true);
    assert.equal(dsd.data_type, 'interval');
    assert.equal(dsd.n, SAMPLE_SIZE - 1);

    // UI and WTP are declared ordinal by their scoring rule and must not be
    // presented as interval measures.
    assert.equal(data.variables.find((variable) => variable.name === 'UI')?.data_type, 'ordinal');
    assert.equal(data.variables.find((variable) => variable.name === 'WTP')?.data_type, 'ordinal');
    assert.equal(data.variables.find((variable) => variable.name === 'STAGE')?.data_type, 'nominal');

    assert.deepEqual(data.available.correlation_variables, ['FSE', 'FED', 'PSA', 'STI', 'DSD', 'UI', 'WTP']);
    assert.equal(data.available.regression_dependent, 'UI');
    assert.deepEqual(data.available.regression_predictors, ['DSD', 'STI', 'PSA', 'FSE', 'FED']);
    assert.equal(data.available.comparison_factor, 'STAGE');
    assert.ok(data.engine_version.length > 0);
  });

  test('未登录无法读取分析数据集', async () => {
    const response = await api(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/dataset`);
    assert.equal(response.status, 401);
  });

  test('他人项目不可见', async () => {
    const outsider = await registerResearcher(ctx, { name: '无关研究者' });
    const response = await api(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/analysis/descriptive`,
      { token: outsider.token },
    );
    assert.ok(response.status === 403 || response.status === 404, `意外的状态码 ${response.status}`);
  });
});

/* ================================================================== */
/* Descriptive statistics                                             */
/* ================================================================== */

describe('描述统计接口', () => {
  test('给出集中趋势、离散程度与缺失信息，且名义变量不给均值', async () => {
    const response = await api<{
      n_respondents: number;
      variables: {
        variable: string;
        data_type: string;
        n: number;
        missing: number;
        mean: number | null;
        standard_deviation: number | null;
        frequencies: { value: string; label: string; count: number; percent: number }[] | null;
      }[];
      note: string;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/descriptive`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.n_respondents, SAMPLE_SIZE - 1);

    const fse = response.data.variables.find((variable) => variable.variable === 'FSE');
    assert.ok(fse);
    assert.equal(fse.n, SAMPLE_SIZE - 1);
    assert.equal(fse.missing, 0);
    assert.ok(fse.mean !== null && fse.mean > 2.5 && fse.mean < 4.5, `FSE 均值异常：${fse.mean}`);
    assert.ok(fse.standard_deviation !== null && fse.standard_deviation > 0);

    // A nominal variable has no meaningful mean — the engine must say so by
    // returning null rather than a number that looks interpretable.
    const stage = response.data.variables.find((variable) => variable.variable === 'STAGE');
    assert.ok(stage);
    assert.equal(stage.mean, null, '名义变量不应给出均值');
    assert.equal(stage.standard_deviation, null);
    assert.ok(stage.frequencies && stage.frequencies.length === STAGES.length);
    const total = stage.frequencies!.reduce((sum, row) => sum + row.count, 0);
    assert.equal(total, SAMPLE_SIZE - 1, '分组频数应覆盖全部有效样本');

    assert.ok(response.data.note.includes('缺失'), '必须说明缺失值处理方式');
  });
});

/* ================================================================== */
/* Reliability and validity                                           */
/* ================================================================== */

describe('信度与效度接口', () => {
  test('九题自我效能量表的 Cronbach α 被计算并给出条目诊断', async () => {
    const response = await api<{
      scales: {
        scale: string;
        label: string;
        dimension: string;
        k: number;
        n: number;
        dropped: number;
        cronbach_alpha: number | null;
        standardized_alpha: number | null;
        mean_inter_item_correlation: number | null;
        scale_mean: number | null;
        scale_standard_deviation: number | null;
        items: {
          item: string;
          label: string;
          mean: number;
          standard_deviation: number;
          item_total_correlation: number | null;
          alpha_if_deleted: number | null;
          n: number;
        }[];
        interpretation: string;
        alpha_reference: { excellent: number; good: number; acceptable: number; questionable: number };
        warnings: string[];
      }[];
      note: string;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/reliability`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.ok(response.data.scales.length > 0, '模板派生问卷必须能解析出量表');

    const fse = response.data.scales.find((scale) => scale.scale === 'FSE');
    assert.ok(fse, '缺少 FSE 量表信度');
    assert.equal(fse.k, 9, 'FSE 量表由 Q22—Q30 九个条目构成');
    assert.equal(fse.n, SAMPLE_SIZE - 1);
    assert.equal(fse.dropped, 0, '所有条目均已作答，不应有整例删除');
    // The nine FSE items share one person-level trait, so internal consistency
    // must come out high; a low α here would mean the items are not measuring
    // one construct.
    assert.ok(
      fse.cronbach_alpha !== null && fse.cronbach_alpha > 0.7,
      `合成数据下 α 应较高，实际 ${fse.cronbach_alpha}`,
    );
    assert.ok(fse.cronbach_alpha <= 1, 'α 不应大于 1');
    assert.ok(fse.standardized_alpha !== null);
    assert.ok(
      fse.mean_inter_item_correlation !== null && fse.mean_inter_item_correlation > 0,
      '必须给出条目间平均相关',
    );
    assert.equal(fse.items.length, 9);
    for (const item of fse.items) {
      assert.ok(item.item_total_correlation !== null, `${item.item} 缺少校正后题总相关`);
      assert.ok(item.alpha_if_deleted !== null, `${item.item} 缺少删除后 α`);
      assert.equal(item.n, SAMPLE_SIZE - 1);
    }
    assert.ok(fse.interpretation.length > 0);
    // The thresholds behind the verdict must be published, so a reader can see
    // which convention the α judgement follows instead of trusting a label.
    assert.ok(fse.alpha_reference.excellent > fse.alpha_reference.good);
    assert.ok(fse.alpha_reference.good > fse.alpha_reference.acceptable);
    assert.ok(fse.alpha_reference.acceptable > fse.alpha_reference.questionable);
    assert.ok(response.data.note.includes('α') || response.data.note.includes('信度'));

    // A single-item "scale" carries no internal consistency claim at all.
    const single = response.data.scales.find((scale) => scale.k === 1);
    if (single) {
      assert.equal(single.cronbach_alpha, null, '单条目量表不应给出 α');
    }
  });

  test('效度分析给出 KMO、Bartlett 检验与因子结构', async () => {
    const response = await api<{
      overall_kmo: {
        overall: number | null;
        per_variable: { variable: string; msa: number }[];
        interpretation: string;
        adequacy: string;
      } | null;
      overall_bartlett: {
        chi_square: number;
        degrees_of_freedom: number;
        p_value: number;
        interpretation: string;
        unavailable: boolean;
      } | null;
      scale_efa: {
        scale: string;
        label: string;
        result: {
          n: number;
          p: number;
          eigenvalues: number[];
          factors_retained: number;
          cumulative_variance: number[];
          loadings: { variable: string; communality: number }[];
          kmo: { overall: number | null } | null;
          bartlett: { p_value: number } | null;
          interpretation: string;
        };
      }[];
      note: string;
      warnings: string[];
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/validity`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    assert.ok(data.overall_bartlett, '必须给出整体 Bartlett 球形检验');
    assert.ok(data.overall_bartlett!.chi_square > 0);
    assert.ok(data.overall_bartlett!.degrees_of_freedom > 0);
    // The generator builds correlated constructs, so the correlation matrix is
    // demonstrably not an identity matrix.
    assert.ok(
      data.overall_bartlett!.p_value < 0.001,
      `Bartlett p = ${data.overall_bartlett!.p_value}`,
    );
    assert.ok(data.overall_bartlett!.interpretation.length > 0);

    assert.ok(data.overall_kmo, '必须给出整体 KMO 取样适切性');
    assert.ok(data.overall_kmo!.overall !== null);
    assert.ok(
      data.overall_kmo!.overall! >= 0 && data.overall_kmo!.overall! <= 1,
      'KMO 必须落在 [0,1]',
    );
    assert.ok(data.overall_kmo!.per_variable.length > 0, '必须逐条目报告 MSA');
    for (const item of data.overall_kmo!.per_variable) {
      assert.ok(item.msa >= 0 && item.msa <= 1, `${item.variable} 的 MSA 越界：${item.msa}`);
    }
    assert.ok(data.overall_kmo!.interpretation.length > 0);

    assert.ok(data.scale_efa.length > 0, '必须给出逐量表的探索性因素分析');
    const fse = data.scale_efa.find((entry) => entry.scale === 'FSE');
    assert.ok(fse, '缺少 FSE 的因素分析');
    assert.equal(fse!.result.n, SAMPLE_SIZE - 1);
    assert.equal(fse!.result.p, 9);
    assert.equal(fse!.result.eigenvalues.length, 9);
    assert.ok(fse!.result.factors_retained >= 1);
    assert.equal(fse!.result.loadings.length, 9);
    for (const loading of fse!.result.loadings) {
      assert.ok(loading.communality >= 0 && loading.communality <= 1, '共同度必须落在 [0,1]');
    }
    assert.ok(fse!.result.interpretation.length > 0);
    assert.ok(data.note.length > 0, '效度结论必须附带方法学说明');
  });
});

/* ================================================================== */
/* Correlation                                                        */
/* ================================================================== */

describe('相关分析接口', () => {
  test('相关矩阵含显著性检验与成对样本量，并按测量层次选择方法', async () => {
    const response = await api<{
      available: boolean;
      variables: string[];
      matrix: (number | null)[][];
      p_values: (number | null)[][];
      n: (number | null)[][];
      methods: string[][];
      mixed_methods: boolean;
      pairs: { left: string; right: string; r: number; p_value: number; method: string; n: number }[];
      note: string;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/correlation`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.available, true);
    assert.deepEqual(response.data.variables, ['FSE', 'FED', 'PSA', 'STI', 'DSD', 'UI', 'WTP']);

    const size = response.data.variables.length;
    for (let i = 0; i < size; i += 1) {
      assert.equal(response.data.matrix[i]![i], 1, '对角线必须为 1');
      assert.equal(response.data.p_values[i]![i], 0);
      for (let j = 0; j < size; j += 1) {
        const r = response.data.matrix[i]?.[j];
        if (r != null) assert.ok(r >= -1 && r <= 1, `相关系数越界：${r}`);
      }
    }

    // Ordinal outcomes force Spearman for the pairs that involve them.
    assert.equal(response.data.mixed_methods, true, 'UI/WTP 为有序变量，应出现 Spearman 相关系数');
    const uiPair = response.data.pairs.find(
      (pair) =>
        (pair.left === 'UI' && pair.right === 'DSD') || (pair.left === 'DSD' && pair.right === 'UI'),
    );
    assert.ok(uiPair, '缺少 UI × DSD 配对结果');
    assert.equal(uiPair!.method, 'spearman');
    assert.equal(uiPair!.n, SAMPLE_SIZE - 1);

    // The generating process makes difficulty raise digital demand (H3), so the
    // pair must come back positive and significant.
    const fedDsd = response.data.pairs.find(
      (pair) =>
        (pair.left === 'FED' && pair.right === 'DSD') || (pair.left === 'DSD' && pair.right === 'FED'),
    );
    assert.ok(fedDsd, '缺少 FED × DSD 配对结果');
    assert.ok(fedDsd!.r > 0, `FED 与 DSD 应为正相关，实际 r = ${fedDsd!.r}`);
    assert.ok(fedDsd!.p_value < 0.05, `FED × DSD 应显著，实际 p = ${fedDsd!.p_value}`);
    assert.ok(response.data.note.length > 0);
  });

  test('指定的变量子集被尊重', async () => {
    const response = await api<{ variables: string[]; available: boolean }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/analysis/correlation?variables=FSE,DSD,UI`,
      { token: fixture.token },
    );
    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.deepEqual(response.data.variables, ['FSE', 'DSD', 'UI']);
  });
});

/* ================================================================== */
/* Regression                                                         */
/* ================================================================== */

describe('回归分析接口', () => {
  test('有序因变量以有序 Logistic 为主结论，并同时给出 OLS 对照', async () => {
    const response = await api<{
      available: boolean;
      auto_selection: { model: string; categories?: number; reason: string };
      ols: {
        n: number;
        coefficients: { term: string; b: number; p_value: number; vif: number | null; beta: number | null }[];
        r_squared: number | null;
        adjusted_r_squared: number | null;
        f_statistic: number | null;
        f_p_value: number | null;
        equation: string;
        interpretation: string;
        diagnostics: { durbin_watson: number | null; outliers: unknown[] };
        collinearity_warnings: { term: string; vif: number }[];
      } | null;
      ordinal: {
        n: number;
        converged: boolean;
        iterations: number;
        categories: { value: number; label: string; count: number }[];
        coefficients: { term: string; b: number; p_value: number; odds_ratio: number }[];
        thresholds: { threshold: number; label: string }[];
        mcfadden_r_squared: number | null;
        nagelkerke_r_squared: number | null;
        percent_correct: number | null;
        lr_chi_square: number;
        lr_p_value: number | null;
        proportional_odds_test: { chi_square: number | null; p_value: number | null; interpretation: string };
        interpretation: string;
        warnings: string[];
      } | null;
      recommendation: string;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/regression`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    assert.equal(data.available, true);
    assert.equal(data.auto_selection.model, 'ordinal_logit', 'UI 为有序变量，必须选择有序模型');
    assert.ok(data.auto_selection.reason.includes('有序'));

    // The linear model is still produced, because the research design asks for
    // it and a reader must be able to compare the two.
    assert.ok(data.ols, '必须同时给出 OLS 对照结果');
    assert.equal(data.ols!.n, SAMPLE_SIZE - 1);
    assert.deepEqual(
      data.ols!.coefficients.map((coefficient) => coefficient.term),
      ['(常量)', 'DSD', 'STI', 'PSA', 'FSE', 'FED'],
    );
    assert.ok(data.ols!.r_squared !== null && data.ols!.r_squared > 0.2, '合成数据的解释力应可检测');
    assert.ok(data.ols!.adjusted_r_squared !== null);
    assert.ok(data.ols!.f_statistic !== null && data.ols!.f_statistic > 0);
    assert.ok(data.ols!.f_p_value !== null && data.ols!.f_p_value < 0.01, '整体模型应显著');
    assert.ok(data.ols!.equation.includes('UI'));
    for (const coefficient of data.ols!.coefficients.slice(1)) {
      assert.ok(coefficient.vif !== null && coefficient.vif >= 1, 'VIF 必须报告');
      assert.ok(coefficient.beta !== null, '标准化系数必须报告');
    }
    assert.ok(data.ols!.diagnostics.durbin_watson !== null, '必须报告残差自相关诊断');

    // Trust in service providers is the driver this sample can actually detect in
    // the linear model: it must come out positive and significant, with its VIF
    // reported so the reader can see how much of the estimate rests on shared
    // variance with the other predictors.
    const sti = data.ols!.coefficients.find((coefficient) => coefficient.term === 'STI');
    assert.ok(sti && sti.b > 0, `STI 系数应为正，实际 ${sti?.b}`);
    assert.ok(sti!.p_value < 0.05, `STI 应显著，实际 p = ${sti!.p_value}`);
    assert.ok(sti!.vif !== null && sti!.vif > 1, 'STI 的 VIF 必须大于 1');

    // Collinearity reporting must agree with the VIFs actually reported: any
    // predictor above the warning threshold has to appear in the warnings, and
    // nothing below it may.
    const warned = new Set(data.ols!.collinearity_warnings.map((warning) => warning.term));
    for (const coefficient of data.ols!.coefficients.slice(1)) {
      const aboveThreshold = coefficient.vif !== null && coefficient.vif > 5;
      assert.equal(
        warned.has(coefficient.term),
        aboveThreshold,
        `${coefficient.term} 的共线性警告与 VIF（${coefficient.vif}）不一致`,
      );
    }

    assert.ok(data.ordinal, '有序因变量必须拟合有序 Logistic 模型');
    assert.equal(data.ordinal!.converged, true, '有序模型未收敛');
    assert.equal(data.ordinal!.n, SAMPLE_SIZE - 1);
    assert.ok(data.ordinal!.iterations > 0);
    assert.deepEqual(
      data.ordinal!.coefficients.map((coefficient) => coefficient.term),
      ['DSD', 'STI', 'PSA', 'FSE', 'FED'],
    );
    assert.ok(data.ordinal!.thresholds.length >= 2, '比例优势模型必须给出阈值');
    for (const threshold of data.ordinal!.thresholds) {
      assert.ok(Number.isFinite(threshold.threshold));
      assert.ok(threshold.label.includes('|'), '阈值必须标明它分隔的两个类别');
    }
    // Thresholds must be ordered, which is what makes the model monotone.
    const thresholds = data.ordinal!.thresholds.map((threshold) => threshold.threshold);
    for (let i = 1; i < thresholds.length; i += 1) {
      assert.ok(thresholds[i]! > thresholds[i - 1]!, '阈值必须严格递增');
    }

    // The outcome categories actually observed must be reported with counts that
    // account for the whole analysis sample.
    assert.ok(data.ordinal!.categories.length >= 4, 'UI 应覆盖至少 4 个有序类别');
    const totalCases = data.ordinal!.categories.reduce((sum, category) => sum + category.count, 0);
    assert.equal(totalCases, SAMPLE_SIZE - 1);
    for (const category of data.ordinal!.categories) {
      assert.ok(category.label.length > 0, '类别必须带标签，不能只给编码');
    }

    assert.ok(data.ordinal!.lr_chi_square > 0);
    assert.ok(data.ordinal!.lr_p_value !== null && data.ordinal!.lr_p_value < 0.05, '有序模型整体应显著');
    assert.ok(data.ordinal!.mcfadden_r_squared !== null);
    assert.ok(data.ordinal!.nagelkerke_r_squared !== null);
    assert.ok(data.ordinal!.percent_correct !== null && data.ordinal!.percent_correct > 0);
    // Proportional odds is tested, not assumed.
    assert.ok(data.ordinal!.proportional_odds_test.interpretation.length > 0);
    assert.ok(data.ordinal!.interpretation.length > 0);

    for (const coefficient of data.ordinal!.coefficients) {
      assert.ok(Number.isFinite(coefficient.b));
      assert.ok(coefficient.p_value >= 0 && coefficient.p_value <= 1);
      assert.ok(Math.abs(coefficient.odds_ratio - Math.exp(coefficient.b)) < 1e-3, 'OR 应为 exp(B)');
    }

    // Both directions of the generating process: demand raises intention, risk
    // perception lowers it.
    const ordinalDsd = data.ordinal!.coefficients.find((coefficient) => coefficient.term === 'DSD');
    assert.ok(ordinalDsd && ordinalDsd.b > 0, `DSD 的有序系数应为正，实际 ${ordinalDsd?.b}`);
    const ordinalFed = data.ordinal!.coefficients.find((coefficient) => coefficient.term === 'FED');
    assert.ok(ordinalFed, '缺少 FED 的有序系数');

    assert.ok(data.recommendation.includes('有序'), '必须说明以哪个模型为主要结论');
  });

  test('区间因变量走 OLS 主路径', async () => {
    const response = await api<{
      auto_selection: { model: string };
      ols: { dependent: string; coefficients: { term: string; b: number }[] } | null;
      ordinal: unknown;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/regression?dependent=FSE`, {
      token: fixture.token,
    });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.auto_selection.model, 'ols');
    assert.ok(response.data.ols);
    assert.equal(response.data.ols!.dependent, 'FSE');
    assert.equal(response.data.ordinal, null, '区间因变量不应被强行拟合有序模型');
  });

  test('因变量不存在时如实返回不可用', async () => {
    const response = await api<{ available: boolean; reason: string | null }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/analysis/regression?dependent=NOT_A_VARIABLE`,
      { token: fixture.token },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.available, false);
    assert.ok(response.data.reason && response.data.reason.length > 0);
  });
});

/* ================================================================== */
/* Group comparison                                                   */
/* ================================================================== */

describe('组间差异接口', () => {
  test('同时给出参数与非参数结果，并明确推荐依据', async () => {
    const response = await api<{
      factor: string;
      available: boolean;
      comparisons: {
        dependent: string;
        factor: string;
        groups: number;
        recommended: string;
        recommendation_reason: string;
        screening: { variable: string; group: string; n: number; acceptable: boolean; reason: string }[];
        anova: {
          groups: { group: string; n: number; mean: number; sd: number }[];
          ss_total: number;
          df_between: number;
          df_within: number;
          f: number;
          p_value: number;
          eta_squared: number | null;
          omega_squared: number | null;
          homogeneity: { statistic: number; p_value: number; equal_variances: boolean };
          post_hoc: { group_a: string; group_b: string; mean_difference: number; p_adjusted: number; significant: boolean }[];
          interpretation: string;
        } | null;
        kruskal_wallis: {
          h: number;
          p_value: number;
          epsilon_squared: number | null;
          tie_corrected: boolean;
        } | null;
        mann_whitney: unknown;
      }[];
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/comparisons`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.factor, 'STAGE');
    assert.equal(response.data.available, true);
    assert.deepEqual(
      response.data.comparisons.map((comparison) => comparison.dependent),
      ['FED', 'UI', 'WTP'],
    );

    for (const comparison of response.data.comparisons) {
      assert.ok(comparison.recommendation_reason.length > 0, '必须说明推荐理由');
      assert.ok(['parametric', 'nonparametric'].includes(comparison.recommended));
      assert.ok(comparison.screening.length > 0, '必须给出前置假设检验的筛查过程');
      // Both estimators are always present so the conclusion can be checked.
      assert.ok(comparison.anova, `${comparison.dependent} 缺少方差分析结果`);
      assert.ok(comparison.kruskal_wallis, `${comparison.dependent} 缺少非参数结果`);
      assert.ok(comparison.anova!.interpretation.length > 0, '必须给出文字解读');
      assert.ok(comparison.anova!.homogeneity.statistic >= 0, '必须给出方差齐性检验');
      for (const group of comparison.anova!.groups) {
        assert.ok(group.n > 0, '分组必须有样本');
        assert.ok(group.group.length > 0, '分组必须带标签，不能只给编码');
        assert.ok(Number.isFinite(group.mean));
      }
    }

    const fed = response.data.comparisons.find((comparison) => comparison.dependent === 'FED');
    assert.ok(fed);
    assert.equal(fed!.groups, STAGES.length);
    // The ANOVA reports its own listwise sample through the group sizes; there is
    // deliberately no separate n that could drift out of step with them.
    assert.equal(
      fed!.anova!.groups.reduce((sum, group) => sum + group.n, 0),
      SAMPLE_SIZE - 1,
    );
    assert.equal(fed!.anova!.df_between, STAGES.length - 1);
    assert.equal(fed!.anova!.df_within, SAMPLE_SIZE - 1 - STAGES.length);

    // The generator makes difficulty rise with the child's school stage, so the
    // omnibus test must detect it and the group means must be ordered.
    assert.ok(fed!.anova!.p_value < 0.01, `学段应显著影响困难程度，实际 p = ${fed!.anova!.p_value}`);
    assert.ok(fed!.anova!.eta_squared !== null && fed!.anova!.eta_squared > 0.14, '效应量应达到大效应');
    const means = fed!.anova!.groups.map((group) => group.mean);
    assert.ok(means[0]! < means[means.length - 1]!, '学段越高困难程度应越高');
    assert.ok(fed!.kruskal_wallis!.p_value < 0.01, '非参数检验应给出同样结论');
    assert.ok(fed!.anova!.post_hoc.length === 6, '四组两两比较应产生 6 对');
    for (const pair of fed!.anova!.post_hoc) {
      assert.ok(pair.p_adjusted >= 0 && pair.p_adjusted <= 1, '校正后 p 必须落在 [0,1]');
      assert.ok(pair.mean_difference < 0, '学段由低到高，差值的符号应一致');
    }
  });
});

/* ================================================================== */
/* Hypothesis testing                                                 */
/* ================================================================== */

describe('假设检验接口', () => {
  test('八条假设逐一给出方法与三态结论', async () => {
    const response = await api<{
      results: {
        code: string;
        statement: string;
        verdict: string;
        method: string;
        independent: string;
        dependent: string;
        direction: string;
        observed_direction: string;
        r: number | null;
        p_value: number | null;
        n: number | null;
        effect_size: { value: number; band: string; text: string; convention: string } | null;
        evidence: string[];
        conclusion: string;
        caveats: string[];
      }[];
      summary: {
        total: number;
        supported: number;
        not_supported: number;
        inconclusive: number;
        untestable: number;
      };
      unavailable_variables: string[];
      note: string;
    }>(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/hypotheses`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    assert.equal(data.results.length, 8);
    assert.deepEqual(
      data.results.map((result) => result.code),
      ['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'H7', 'H8'],
    );
    assert.deepEqual(data.unavailable_variables, [], '本问卷已覆盖全部假设所需变量');

    for (const result of data.results) {
      assert.ok(
        ['supported', 'not_supported', 'inconclusive'].includes(result.verdict),
        `${result.code} 结论不在允许的三态之内：${result.verdict}`,
      );
      assert.ok(result.method.length > 0, `${result.code} 必须报告统计方法`);
      assert.ok(result.evidence.length > 0, `${result.code} 必须给出留痕证据`);
      assert.ok(result.conclusion.length > 0, `${result.code} 必须给出文字结论`);
      assert.ok(result.caveats.length > 0, `${result.code} 必须给出解读限制`);
      assert.ok(result.p_value !== null && result.p_value >= 0 && result.p_value <= 1);
      assert.ok(result.r !== null && result.r >= -1 && result.r <= 1);
      assert.equal(result.n, SAMPLE_SIZE - 1);
      assert.ok(result.effect_size, `${result.code} 必须给出效应量`);
      assert.ok(result.effect_size!.convention.includes('Cohen'), '效应量判定标准必须写明出处');
      // A verdict must agree with the numbers that accompany it.
      if (result.verdict === 'supported' || result.verdict === 'not_supported') {
        assert.ok(result.p_value! < 0.05, `${result.code} 判定为有结论但 p 未达显著`);
      } else {
        assert.ok(result.p_value! >= 0.05, `${result.code} 判定为证据不足但 p 已显著`);
      }
    }

    const byCode = new Map(data.results.map((result) => [result.code, result]));

    // These three relationships are built into the data-generating process, so
    // the engine has to detect them — and with the sign the theory predicts.
    assert.equal(byCode.get('H2')!.verdict, 'supported', 'H2（效能→实践）应被数据支持');
    assert.equal(byCode.get('H3')!.verdict, 'supported', 'H3（困难→需求）应被数据支持');
    assert.ok(byCode.get('H3')!.r! > 0, 'H3 相关系数方向应为正');
    assert.equal(byCode.get('H5')!.verdict, 'supported', 'H5（信任→需求）应被数据支持');
    assert.ok(byCode.get('H5')!.r! > 0, 'H5 相关系数方向应为正');
    assert.equal(byCode.get('H8')!.verdict, 'supported', 'H8（需求→付费）应被数据支持');
    assert.ok(byCode.get('H8')!.r! > 0, 'H8 相关系数方向应为正');

    // H7 was generated as a negative effect and must be detected as such.
    const h7 = byCode.get('H7')!;
    assert.ok(h7.r! < 0, `H7 由数据过程设定为负向关系，实际 r = ${h7.r}`);
    assert.equal(h7.observed_direction, 'negative');
    assert.equal(h7.verdict, 'supported', 'H7（风险认知→意愿）应被数据支持为负向关系');

    // H6 is a deliberate null: perceived value was generated independently of
    // intention. The engine must NOT claim support for it.
    const h6 = byCode.get('H6')!;
    assert.notEqual(h6.verdict, 'supported', 'H6 在数据中无关系，不得被判为支持');
    assert.ok(Math.abs(h6.r!) < 0.35, `H6 的相关应接近 0，实际 r = ${h6.r}`);
    assert.equal(h6.verdict, 'inconclusive', '不显著的结果必须记为证据不足');
    assert.ok(
      h6.conclusion.includes('证据不足') || h6.conclusion.includes('无法判断'),
      '证据不足的结论必须写明，而不能表述为「已证明无关」',
    );

    // The summary must be a faithful count of the per-hypothesis verdicts.
    const tally = (verdict: string): number =>
      data.results.filter((result) => result.verdict === verdict).length;
    assert.equal(data.summary.total, 8);
    assert.equal(data.summary.supported, tally('supported'));
    assert.equal(data.summary.not_supported, tally('not_supported'));
    assert.equal(data.summary.inconclusive, tally('inconclusive'));
    assert.equal(data.summary.untestable, tally('untestable'));
    assert.equal(
      data.summary.supported + data.summary.not_supported + data.summary.inconclusive + data.summary.untestable,
      8,
    );

    // Multiple comparisons inflate the family-wise error rate; the report must
    // say so rather than let the reader treat six "supported" verdicts naively.
    assert.ok(data.note.includes('多重比较'), '必须提示多重比较问题');
    assert.ok(data.note.includes('因果'), '必须提示相关不等于因果');
  });
});

/* ================================================================== */
/* Full bundle, persistence and reproducibility                       */
/* ================================================================== */

describe('完整分析流程', () => {
  test('未运行前如实返回不可用', async () => {
    const response = await api<{ available: boolean; reason: string }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/analysis/bundle`,
      { token: fixture.token },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.available, false);
    assert.ok(response.data.reason.includes('统计'));
  });

  test('运行全部分析得到完整结果包并持久化', async () => {
    const response = await api<{
      engine_version: string;
      generated_at: string;
      project: { id: string; title: string };
      questionnaire: { question_count: number } | null;
      sample: { analysable: number; excluded: number };
      dataset_summary: {
        variable_count: number;
        derived_variable_count: number;
        composites: { name: string; sources: string[] }[];
        variables: { name: string }[];
      };
      descriptive: { variables: unknown[] };
      reliability: { scales: unknown[] };
      validity: unknown;
      correlation: { variables: string[] } | null;
      regression: { auto_selection: { model: string } } | null;
      comparisons: unknown[];
      hypotheses: { results: unknown[] };
      caveats: string[];
    }>(ctx, 'POST', `/api/projects/${fixture.projectId}/analysis/run`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    const bundle = response.data;

    assert.equal(bundle.engine_version, '1.0.0');
    assert.equal(bundle.project.id, fixture.projectId);
    assert.equal(bundle.questionnaire?.question_count, QUESTIONS.length);
    assert.equal(bundle.sample.analysable, SAMPLE_SIZE - 1);
    assert.equal(bundle.sample.excluded, 1);

    assert.ok(bundle.descriptive.variables.length > 0);
    assert.ok(bundle.reliability.scales.length > 0);
    assert.ok(bundle.validity);
    assert.ok(bundle.correlation && bundle.correlation.variables.includes('DSD'));
    assert.equal(bundle.regression?.auto_selection.model, 'ordinal_logit');
    assert.equal(bundle.comparisons.length, 3);
    assert.equal(bundle.hypotheses.results.length, 8);

    // Composites must be reported as derived, and every caveat that guards
    // downstream interpretation must be present.
    assert.ok(bundle.dataset_summary.derived_variable_count >= 8, '派生变量数量异常');
    // Two different derivation mechanisms are in play and both must be visible:
    // multi-item constructs averaged from several questions (FSE) and a matrix
    // question's own dimension mean (DSD, FED, STI, PRC).
    assert.ok(
      bundle.dataset_summary.composites.some((composite) => composite.name === 'FSE'),
      '多题合成变量必须列入 composites',
    );
    assert.ok(
      bundle.dataset_summary.composites.some((composite) => composite.sources.length >= 9),
      '合成变量必须报告其条目来源',
    );
    assert.ok(
      bundle.dataset_summary.variables.some((variable) => variable.name === 'DSD'),
      '矩阵题的维度均值必须出现在变量清单中',
    );
    assert.ok(bundle.caveats.length >= 3, '结果包必须携带解读前提');
    assert.ok(bundle.caveats.some((caveat) => caveat.includes('排除')), '必须声明被排除的样本');
    assert.ok(bundle.caveats.some((caveat) => caveat.includes('缺失') || caveat.includes('整例')), '必须声明缺失处理方式');

    // Retrieve the persisted copy: it must be the same analysis, not a rerun.
    const stored = await api<{ available: boolean; sample: { analysable: number }; generated_at: string }>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/analysis/bundle`,
      { token: fixture.token },
    );
    assert.equal(stored.status, 200);
    assert.equal(stored.data.available, true);
    assert.equal(stored.data.generated_at, bundle.generated_at);
    assert.equal(stored.data.sample.analysable, SAMPLE_SIZE - 1);
  });

  test('重复运行结果完全一致，统计口径可复现', async () => {
    const first = await api<{ descriptive: unknown; regression: unknown; hypotheses: unknown }>(
      ctx,
      'POST',
      `/api/projects/${fixture.projectId}/analysis/run`,
      { token: fixture.token },
    );
    const second = await api<{ descriptive: unknown; regression: unknown; hypotheses: unknown }>(
      ctx,
      'POST',
      `/api/projects/${fixture.projectId}/analysis/run`,
      { token: fixture.token },
    );

    assert.equal(first.status, 200);
    assert.equal(second.status, 200);
    assert.equal(JSON.stringify(first.data.descriptive), JSON.stringify(second.data.descriptive));
    assert.equal(JSON.stringify(first.data.regression), JSON.stringify(second.data.regression));
    assert.equal(JSON.stringify(first.data.hypotheses), JSON.stringify(second.data.hypotheses));
  });

  test('分析历史留痕，包含每一类分析与结果包本身', async () => {
    const response = await api<
      { id: string; analysis_type: string; engine_version: string; sample_n: number | null; created_at: string }[]
    >(ctx, 'GET', `/api/projects/${fixture.projectId}/analysis/history`, { token: fixture.token });

    assert.equal(response.status, 200, JSON.stringify(response.error));
    const types = new Set(response.data.map((row) => row.analysis_type));
    for (const type of ['descriptive', 'reliability', 'validity', 'correlation', 'regression', 'group_comparison', 'hypothesis_testing', 'bundle']) {
      assert.ok(types.has(type), `分析历史缺少 ${type}`);
    }
    for (const row of response.data) {
      assert.ok(row.id.length > 0);
      assert.equal(row.engine_version, '1.0.0');
      assert.ok(row.created_at.length > 0);
    }

    const correlationHistory = await api<{ analysis_type: string }[]>(
      ctx,
      'GET',
      `/api/projects/${fixture.projectId}/analysis/history?type=correlation`,
      { token: fixture.token },
    );
    assert.ok(correlationHistory.data.length > 0);
    assert.ok(correlationHistory.data.every((row) => row.analysis_type === 'correlation'));
  });

  test('无问卷的项目给出明确的业务错误而非空结果', async () => {
    const researcher = await registerResearcher(ctx, { name: '空项目研究者' });
    const project = await api<{ project: { id: string } }>(ctx, 'POST', '/api/projects', {
      token: researcher.token,
      body: { title: '还没有问卷的项目' },
    });
    assert.equal(project.status, 201);

    const response = await api(ctx, 'GET', `/api/projects/${project.data.project.id}/analysis/descriptive`, {
      token: researcher.token,
    });
    assert.equal(response.status, 400);
    assert.ok(response.error && response.error.message.includes('问卷'));
  });
});
