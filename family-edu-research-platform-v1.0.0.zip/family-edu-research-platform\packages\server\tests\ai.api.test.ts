/**
 * AI interpretation API tests (PHASE 7).
 *
 * The sample is real: 24 respondents answer a V4.0-derived questionnaire through
 * the public survey API, one is excluded, and the statistical engine builds the
 * bundle exactly as it does in production. The AI layer is then driven with an
 * injected fake `fetch`, so no network access is used and every provider failure
 * mode can be reproduced deterministically.
 *
 * Two servers share one in-memory database:
 *  - `ctxDegraded` has no API key (the situation in this environment), so it
 *    exercises the engine-derived fallback;
 *  - `ctxLive` has a key and the scripted fake client, so it exercises parsing,
 *    layering, evidence tracing and the hallucination guard.
 * Sharing the database keeps the collection fixture (and the public API's
 * session rate limit) to a single pass.
 *
 * Where assertions could be satisfied by any plausible output, they are pinned to
 * values read out of the real bundle instead — an evidence trace is checked to
 * quote the actual p-value, not merely to be non-empty.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { Server } from 'node:http';
import type { AddressInfo } from 'node:net';

import express from 'express';

import { loadConfig, type Config, type FetchLike } from '../src/config.js';
import { Db } from '../src/db/index.js';
import { migrate } from '../src/db/migrate.js';
import { createAuthRouter } from '../src/routes/auth.routes.js';
import { createProjectRouter } from '../src/routes/project.routes.js';
import {
  createQuestionRouter,
  createQuestionnaireRouter,
} from '../src/routes/questionnaire.routes.js';
import { createPublicRouter } from '../src/routes/public.routes.js';
import { createRespondentRouter } from '../src/routes/collection.routes.js';
import { createAnalysisRouter } from '../src/routes/analysis.routes.js';
import { createAiRouter } from '../src/routes/ai.routes.js';
import { createErrorHandler, notFoundHandler } from '../src/middleware/error.js';
import {
  buildEngineDerivedSummary,
  buildEvidenceMenu,
  buildInterpretationPrompt,
  collectBundleValues,
  emptyScope,
  extractQuotedNumbers,
  numbersMatch,
  resolveBundlePath,
  validateNumbers,
} from '../src/services/ai.service.js';
import {
  api,
  createPublishedQuestionnaire,
  registerResearcher,
  saveAnswer,
  startSession,
  submitSession,
  type ApiResponse,
  type TestContext,
  type TestResearcher,
} from './helpers.js';

/* ================================================================== */
/* Local app harness                                                  */
/* ================================================================== */

/**
 * Mount the routers this test needs, plus the AI router.
 *
 * `app.ts` is not modified by PHASE 7 (the integrator mounts the router), so the
 * test builds its own app. The middleware order mirrors `app.ts` so the AI routes
 * see exactly the same request pipeline they will see in production.
 */
async function startApp(
  db: Db,
  config: Config,
  aiFetch?: FetchLike,
): Promise<{ server: Server; baseUrl: string; close(): Promise<void> }> {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: false, limit: '2mb' }));

  app.use('/api/auth', createAuthRouter({ db, config }));
  app.use('/api/projects', createProjectRouter({ db, config }));
  app.use('/api/questionnaires', createQuestionnaireRouter({ db, config }));
  app.use('/api/questions', createQuestionRouter({ db, config }));
  app.use('/api/public', createPublicRouter({ db, config }));
  app.use('/api/respondents', createRespondentRouter({ db, config }));
  app.use('/api/projects', createAnalysisRouter({ db, config }));
  app.use('/api/projects', createAiRouter({ db, config, fetchImpl: aiFetch }));

  app.use(notFoundHandler);
  app.use(createErrorHandler({ logUnexpected: false }));

  const server = await new Promise<Server>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const address = server.address() as AddressInfo;

  return {
    server,
    baseUrl: `http://127.0.0.1:${address.port}`,
    close: () =>
      new Promise<void>((resolve, reject) => {
        server.close((err) => (err ? reject(err) : resolve()));
      }),
  };
}

/* ================================================================== */
/* Scripted provider                                                  */
/* ================================================================== */

interface ProviderCall {
  url: string;
  body: string;
  authorization: string | null;
  model: string | null;
}

type ScriptedProvider =
  | { kind: 'content'; content: string; finish_reason?: string }
  | { kind: 'raw'; status: number; body: string; content_type?: string }
  | { kind: 'throw'; error: Error };

let scripted: ScriptedProvider = { kind: 'content', content: '未配置脚本' };
const providerCalls: ProviderCall[] = [];

/** Deterministic stand-in for `https://api.deepseek.com`. */
const fakeFetch: FetchLike = async (url, init) => {
  const headers = (init.headers ?? {}) as Record<string, string>;
  const body = typeof init.body === 'string' ? init.body : '';
  let model: string | null = null;
  try {
    model = (JSON.parse(body) as { model?: string }).model ?? null;
  } catch {
    model = null;
  }
  providerCalls.push({
    url,
    body,
    authorization: headers['authorization'] ?? null,
    model,
  });

  if (scripted.kind === 'throw') throw scripted.error;

  if (scripted.kind === 'raw') {
    return new Response(scripted.body, {
      status: scripted.status,
      headers: { 'content-type': scripted.content_type ?? 'application/json' },
    });
  }

  return new Response(
    JSON.stringify({
      id: 'chatcmpl-test',
      object: 'chat.completion',
      model: 'deepseek-chat',
      choices: [
        {
          index: 0,
          message: { role: 'assistant', content: scripted.content },
          finish_reason: scripted.finish_reason ?? 'stop',
        },
      ],
      usage: { prompt_tokens: 1200, completion_tokens: 300, total_tokens: 1500 },
    }),
    { status: 200, headers: { 'content-type': 'application/json' } },
  );
};

/** The degraded context must never reach the network. */
let forbiddenFetchCalls = 0;
const forbiddenFetch: FetchLike = async () => {
  forbiddenFetchCalls += 1;
  throw new Error('测试失败：未配置 API 密钥时不应发起任何网络请求。');
};

/* ================================================================== */
/* Instrument (same shape as the PHASE 5 analysis fixture)            */
/* ================================================================== */

const AGREE = [
  { value: '1', label: '非常不同意', score: 1 },
  { value: '2', label: '比较不同意', score: 2 },
  { value: '3', label: '一般', score: 3 },
  { value: '4', label: '比较同意', score: 4 },
  { value: '5', label: '非常同意', score: 5 },
];

const MEAN_5 = { type: 'mean', min: 1, max: 5 };
const ORDINAL_5 = { type: 'ordinal', codes: { '1': 1, '2': 2, '3': 3, '4': 4, '5': 5 } };

function likert(code: string, variable: string, dimension: string, rule: Record<string, unknown> = MEAN_5): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'likert',
    required: true,
    dimension,
    variable_name: variable,
    options: { choices: AGREE, scaleMin: 1, scaleMax: 5 },
    scoring_rule: rule,
  };
}

function matrix(code: string, variable: string, dimension: string, rowCount: number): Record<string, unknown> {
  return {
    question_code: code,
    question_text: `${dimension}（${code}）`,
    question_type: 'matrix',
    required: true,
    dimension,
    variable_name: variable,
    options: {
      matrix: {
        rows: Array.from({ length: rowCount }, (_, i) => ({ value: String(i + 1), label: `方面${i + 1}` })),
        columns: AGREE,
      },
      scaleMin: 1,
      scaleMax: 5,
    },
    scoring_rule: MEAN_5,
  };
}

const STAGES = ['学前（0—6岁）', '小学', '初中', '高中'];

const STAGE_QUESTION: Record<string, unknown> = {
  question_code: 'Q5',
  question_text: '孩子目前所处学段',
  question_type: 'single',
  required: true,
  dimension: '基本信息',
  variable_name: 'STAGE',
  options: { choices: STAGES.map((label, i) => ({ value: String(i + 1), label, score: i + 1 })) },
  scoring_rule: { type: 'categorical', codes: { '1': 1, '2': 2, '3': 3, '4': 4 } },
};

const FSE_CODES = ['Q22', 'Q23', 'Q24', 'Q25', 'Q26', 'Q27', 'Q28', 'Q29', 'Q30'];

const QUESTIONS: Record<string, unknown>[] = [
  STAGE_QUESTION,
  likert('Q6', 'FEI1', '家庭教育认知'),
  likert('Q7', 'FEI2', '家庭教育认知'),
  likert('Q8', 'FEI3', '家庭教育认知'),
  likert('Q9', 'FEK', '家庭教育认知'),
  likert('Q19', 'ISC1', '信息获取渠道'),
  likert('Q20', 'ISC2', '信息获取渠道'),
  ...FSE_CODES.map((code, i) => likert(code, `FSE${i + 1}`, '家庭教育自我效能')),
  likert('Q31', 'FPB1', '家庭教育实际行为'),
  likert('Q33', 'FPB2', '家庭教育实际行为'),
  likert('Q34', 'FPB3', '家庭教育实际行为'),
  matrix('Q35', 'FED', '家庭教育困难', 7),
  likert('Q43', 'PSA1', '政府家庭教育公共服务'),
  likert('Q44', 'PSA2', '政府家庭教育公共服务'),
  likert('Q45', 'PSU1', '政府家庭教育公共服务'),
  likert('Q46', 'PSU2', '政府家庭教育公共服务'),
  matrix('Q48', 'STI', '服务主体信任', 6),
  matrix('Q49', 'DSD', '数字化家庭教育服务需求', 6),
  likert('Q50', 'UI', 'AI家庭教育服务接受度', ORDINAL_5),
  matrix('Q51', 'PRC', 'AI服务风险认知', 5),
  likert('Q52', 'AIPV', 'AI家庭教育服务接受度'),
  likert('Q53', 'WTP', '家庭教育服务付费意愿', ORDINAL_5),
];

/**
 * Fixed-seed data-generating process (same structure as the PHASE 5 fixture).
 *
 * FED raises DSD (H3) and STI raises DSD (H5) by construction, so the tests can
 * assert against real, non-trivial relationships rather than noise.
 */
function lcg(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function gaussian(rand: () => number): number {
  let sum = 0;
  for (let i = 0; i < 12; i += 1) sum += rand();
  return sum - 6;
}

function lk(value: number): number {
  return Math.min(5, Math.max(1, Math.round(value)));
}

function mean(values: number[]): number {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function matrixAnswer(values: number[]): Record<string, string> {
  const answer: Record<string, string> = {};
  values.forEach((value, index) => {
    answer[String(index + 1)] = String(value);
  });
  return answer;
}

/** 24 respondents is enough for every estimator and stays under the 60/15min limit. */
const SAMPLE_SIZE = 24;

function generateSample(rand: () => number, index: number): Record<string, unknown> {
  const stage = (index % STAGES.length) + 1;
  const g = (): number => gaussian(rand);

  const traitAbility = g();
  const traitDifficulty = g();
  const traitTrust = g();
  const traitRisk = g();
  const traitValue = g();
  const traitAccess = g();
  const traitDigital = g();

  const feiItems = [0, 1, 2].map(() => lk(3.2 + 0.3 * traitAbility + 0.5 * g()));
  const fek = lk(3.0 + 0.75 * traitAbility + 0.3 * g());
  const iscItems = [0, 1].map(() => lk(3.0 + 0.4 * g()));

  const fseItems = Array.from({ length: 9 }, () => lk(3.0 + 0.8 * traitAbility + 0.3 * g()));
  const fse = mean(fseItems);
  const fpbItems = [0, 1, 2].map(() => lk(0.9 + 0.6 * fse + 0.35 * g()));

  const fedRows = Array.from({ length: 7 }, () => lk(1.7 + 0.35 * stage + 0.6 * traitDifficulty + 0.4 * g()));
  const fed = mean(fedRows);
  const stiRows = Array.from({ length: 6 }, () => lk(2.9 + 0.75 * traitTrust + 0.45 * g()));
  const sti = mean(stiRows);
  const dsdRows = Array.from({ length: 6 }, () => lk(1.3 + 0.28 * fed + 0.3 * sti + 0.5 * traitDigital + 0.4 * g()));

  const psaItems = [0, 1].map(() => lk(2.9 - 0.18 * stage + 0.75 * traitAccess + 0.4 * g()));
  const psa = mean(psaItems);
  const psuItems = [0, 1].map(() => lk(1.0 + 0.6 * psa + 0.4 * g()));
  const prcRows = Array.from({ length: 5 }, () => lk(3.0 + 0.7 * traitRisk + 0.4 * g()));
  const prc = mean(prcRows);
  const aipv = lk(3.0 + 0.7 * traitValue + 0.4 * g());

  const ui = lk(3.0 + 0.4 * (sti - 3) - 0.4 * (prc - 3) + 0.5 * mean(dsdRows) - 0.5 + 0.7 * g());
  const wtp = lk(0.6 + 0.5 * mean(dsdRows) + 0.35 * aipv + 0.4 * g());

  const answers: Record<string, unknown> = {
    Q5: String(stage),
    Q6: String(feiItems[0]!),
    Q7: String(feiItems[1]!),
    Q8: String(feiItems[2]!),
    Q9: String(fek),
    Q19: String(iscItems[0]!),
    Q20: String(iscItems[1]!),
    Q31: String(fpbItems[0]!),
    Q33: String(fpbItems[1]!),
    Q34: String(fpbItems[2]!),
    Q35: matrixAnswer(fedRows),
    Q43: String(psaItems[0]!),
    Q44: String(psaItems[1]!),
    Q45: String(psuItems[0]!),
    Q46: String(psuItems[1]!),
    Q48: matrixAnswer(stiRows),
    Q49: matrixAnswer(dsdRows),
    Q50: String(ui),
    Q51: matrixAnswer(prcRows),
    Q52: String(aipv),
    Q53: String(wtp),
  };

  FSE_CODES.forEach((code, position) => {
    answers[code] = String(fseItems[position]!);
  });

  return answers;
}

/* ================================================================== */
/* Fixture types                                                      */
/* ================================================================== */

interface BundleVariable {
  variable: string;
  label: string;
  data_type: string;
  n: number;
  missing: number;
  mean: number | null;
  standard_deviation: number | null;
}

interface HypothesisEntry {
  code: string;
  statement: string;
  verdict: string;
  method: string;
  r: number | null;
  p_value: number | null;
  n: number;
}

interface BundleData {
  engine_version: string;
  generated_at: string;
  project: { id: string; title: string };
  questionnaire: { id: string; title: string; version: string; question_count: number } | null;
  sample: {
    respondents_total: number;
    completed: number;
    in_progress: number;
    abandoned: number;
    excluded: number;
    analysable: number;
    rows_loaded: number;
  };
  dataset_summary: { n_respondents: number; variables: { name: string }[] };
  descriptive: { variables: BundleVariable[] };
  reliability: {
    scales: {
      scale: string;
      label: string;
      k: number;
      n: number;
      cronbach_alpha: number | null;
      alpha_reference: { excellent: number; good: number; acceptable: number; questionable: number };
    }[];
  };
  correlation: {
    variables: string[];
    pairs: { left: string; right: string; method: string; r: number | null; p_value: number | null; n: number }[];
  } | null;
  regression: { auto_selection: { model: string } } | null;
  comparisons: unknown[];
  hypotheses: {
    results: HypothesisEntry[];
    summary: { total: number; supported: number; not_supported: number; inconclusive: number; untestable: number };
    note: string;
  };
  caveats: string[];
}

interface EvidenceData {
  path: string;
  value: string | number | boolean | null;
  source: string;
}

interface StatementData {
  id: string;
  level: string;
  text: string;
  labelled_text: string;
  evidence: EvidenceData[];
  label_inferred: boolean;
  hypothesis_code: string | null;
}

interface RejectedClaimData {
  text: string;
  code: string;
  reason: string;
  quoted_number: number | null;
  raw_number: string | null;
  level: string | null;
}

interface InterpretData {
  mode: string;
  interaction_id: string;
  generated_at: string;
  engine_version: string;
  prompt_version: string;
  prompt_hash: string | null;
  model: string;
  source_of_truth: string;
  scope: { section: string | null; hypothesis_code: string | null; focus: string | null };
  bundle_generated_at: string;
  layers: {
    facts: StatementData[];
    statistical_findings: StatementData[];
    interpretations: StatementData[];
    recommendations: StatementData[];
  };
  statement_count: number;
  levels_used: string[];
  rejected_claims: RejectedClaimData[];
  warnings: string[];
  caveats: string[];
  truncated: boolean;
  ai_unavailable: { code: string; message: string; provider_status: number | null } | null;
  engine_summary: {
    derived_by: string;
    ai_generated: boolean;
    headline: string;
    text: string;
    statement_count: number;
    sections: { title: string; lines: string[] }[];
  } | null;
  usage: { prompt_tokens: number | null; completion_tokens: number | null; total_tokens: number | null } | null;
  notice: string;
}

interface AiStatusData {
  configured: boolean;
  mode: string;
  reason: string;
  model: string;
  base_url: string;
  timeout_ms: number;
  has_bundle: boolean;
  bundle_generated_at: string | null;
  latest_interaction_at: string | null;
  latest_mode: string | null;
}

interface HistoryRow {
  id: string;
  mode: string;
  model: string;
  engine_version: string;
  prompt_hash: string;
  prompt_version: string;
  prompt_tokens: number | null;
  total_tokens: number | null;
  duration_ms: number | null;
  scope: { section: string | null; hypothesis_code: string | null; focus: string | null };
  statement_count: number;
  rejected_claims: RejectedClaimData[];
  rejected_claim_count: number;
  error_code: string | null;
  error_message: string | null;
  raw_response: string | null;
  result: InterpretData | null;
  created_at: string;
}

/* ================================================================== */
/* Shared fixture                                                     */
/* ================================================================== */

let db: Db;
let degradedCtx: TestContext;
let liveCtx: TestContext;
let researcher: TestResearcher;
let fixture: { projectId: string; questionnaireId: string; shareToken: string };
let bundle: BundleData;
/** Number of interpret calls that actually reached the service (200 responses). */
let interpretAttempts = 0;

const BASE_ENV: NodeJS.ProcessEnv = {
  NODE_ENV: 'test',
  DATABASE_PATH: ':memory:',
  JWT_SECRET: 'test-secret-that-is-long-enough-for-hs256-signing',
  JWT_EXPIRES_IN: '3600',
};

before(async () => {
  db = new Db(':memory:');
  migrate(db);

  // The same database behind both apps keeps the collection pass to one — and
  // the public session limiter (60 per 15 minutes) is per app instance.
  const degradedConfig = loadConfig({ ...BASE_ENV });
  const liveConfig = loadConfig({
    ...BASE_ENV,
    DEEPSEEK_API_KEY: 'test-key-not-a-real-secret',
    DEEPSEEK_MODEL: 'deepseek-chat',
  });

  const degradedApp = await startApp(db, degradedConfig, forbiddenFetch);
  const liveApp = await startApp(db, liveConfig, fakeFetch);

  degradedCtx = {
    db,
    config: degradedConfig,
    server: degradedApp.server,
    baseUrl: degradedApp.baseUrl,
    close: degradedApp.close,
  };
  liveCtx = {
    db,
    config: liveConfig,
    server: liveApp.server,
    baseUrl: liveApp.baseUrl,
    close: liveApp.close,
  };

  researcher = await registerResearcher(degradedCtx, { name: 'AI 解释研究者' });
  fixture = await createPublishedQuestionnaire(
    degradedCtx,
    researcher.token,
    QUESTIONS,
    'AI 解释测试研究',
  );

  const rand = lcg(20260707);
  const respondentIds: string[] = [];

  for (let index = 0; index < SAMPLE_SIZE; index += 1) {
    const answers = generateSample(rand, index);
    const session = await startSession(degradedCtx, fixture.shareToken, index % 2 === 0 ? 'wechat' : 'school');
    for (const [code, value] of Object.entries(answers)) {
      const saved = await saveAnswer(degradedCtx, session.token, code, value);
      assert.equal(saved.status, 200, `${code} 保存失败：${JSON.stringify(saved.error)}`);
    }
    const submitted = await submitSession(degradedCtx, session.token);
    assert.equal(submitted.status, 200, `提交失败：${JSON.stringify(submitted.error)}`);
    respondentIds.push(session.respondentId);
  }

  const excluded = await api(degradedCtx, 'POST', `/api/respondents/${respondentIds[0]!}/review`, {
    token: researcher.token,
    body: { status: 'excluded', note: '作答时间异常，已排除' },
  });
  assert.equal(excluded.status, 200, `排除样本失败：${JSON.stringify(excluded.error)}`);

  const run = await api<BundleData>(degradedCtx, 'POST', `/api/projects/${fixture.projectId}/analysis/run`, {
    token: researcher.token,
  });
  assert.equal(run.status, 200, `运行分析失败：${JSON.stringify(run.error)}`);

  const stored = await api<BundleData & { available: boolean }>(
    degradedCtx,
    'GET',
    `/api/projects/${fixture.projectId}/analysis/bundle`,
    { token: researcher.token },
  );
  assert.equal(stored.status, 200, JSON.stringify(stored.error));
  assert.equal(stored.data.available, true, '分析结果包必须已持久化');
  bundle = stored.data;

  // The bundle the AI reads must be the engine's own output, not a rerun.
  assert.equal(bundle.sample.analysable, SAMPLE_SIZE - 1);
  assert.equal(bundle.sample.excluded, 1);
});

after(async () => {
  await degradedCtx.close();
  await liveCtx.close();
  db.close();
});

/* ================================================================== */
/* Helpers                                                            */
/* ================================================================== */

async function interpret(
  ctx: TestContext,
  token: string | null,
  body: Record<string, unknown> = {},
  projectId: string = fixture.projectId,
): Promise<ApiResponse<InterpretData>> {
  const response = await api<InterpretData>(ctx, 'POST', `/api/projects/${projectId}/ai/interpret`, {
    token,
    body,
  });
  if (response.status === 200) interpretAttempts += 1;
  return response;
}

/** Every statement in the payload, whatever its level. */
function allStatements(data: InterpretData): StatementData[] {
  return [
    ...data.layers.facts,
    ...data.layers.statistical_findings,
    ...data.layers.interpretations,
    ...data.layers.recommendations,
  ];
}

function hypothesisByCode(code: string): HypothesisEntry {
  const entry = bundle.hypotheses.results.find((result) => result.code === code);
  assert.ok(entry, `结果包中缺少假设 ${code}`);
  return entry;
}

/** A number that provably appears nowhere in the bundle. */
function fabricatedNumber(): number {
  const candidates = [999.9999, 321.7654, 88.123412, 7.654321, 0.987654321];
  for (const candidate of candidates) {
    if (!validateNumbers(String(candidate), bundle).ok) {
      assert.equal(validateNumbers(String(candidate), bundle).numbers.length, 1);
      return candidate;
    }
  }
  throw new Error('无法构造结果包中不存在的数值，测试前置条件失败。');
}

/* ================================================================== */
/* Pure numeric validation                                            */
/* ================================================================== */

/**
 * A hand-built fragment, so each matching rule can be exercised in isolation:
 * the real bundle contains thousands of numbers and would make "not found"
 * assertions depend on data luck.
 */
const synthetic = {
  sample: { analysable: 47, excluded: 2, completed: 49 },
  reliability: {
    scales: [
      {
        scale: 'FSE',
        label: '家庭教育自我效能',
        k: 9,
        n: 47,
        cronbach_alpha: 0.87,
        alpha_reference: { excellent: 0.9, good: 0.8, acceptable: 0.7, questionable: 0.6 },
      },
    ],
  },
  descriptive: {
    variables: [
      {
        variable: 'STAGE',
        label: '孩子目前所处学段',
        n: 47,
        frequencies: [
          { value: '1', label: '学前', count: 12, percent: 25.53, percent_of_total: 24.49 },
        ],
      },
    ],
  },
  correlation: {
    pairs: [{ left: 'PRC', right: 'UI', method: 'spearman', r: -0.4, p_value: 0.0051, n: 47 }],
  },
  hypotheses: {
    results: [{ code: 'H3', verdict: 'supported', r: 0.3652, p_value: 0.013, n: 47 }],
  },
  caveats: ['分析基于 47 份已完成且未被排除的样本。'],
  generated_at: '2026-07-07T10:20:30.000Z',
  project: { id: 'prj-9f2a4c1e', title: '家庭教育测试研究' },
};

describe('数字校验（纯函数）', () => {
  test('正确的数字被接受，并给出它在结果包中的确切路径', () => {
    const result = validateNumbers('有效样本 n = 47；H3 的 r = 0.3652，p = 0.013。', synthetic);
    assert.equal(result.ok, true, JSON.stringify(result.unmatched));
    assert.equal(result.unmatched.length, 0);

    const r = result.numbers.find((entry) => entry.raw === '0.3652');
    assert.ok(r);
    assert.equal(r!.matched, true);
    assert.equal(r!.matched_path, 'hypotheses.results[H3].r');
    assert.equal(r!.matched_value, 0.3652);

    const p = result.numbers.find((entry) => entry.raw === '0.013');
    assert.equal(p?.matched_path, 'hypotheses.results[H3].p_value');
  });

  test('轻微四舍五入的正确数字仍被接受（容差已文档化）', () => {
    assert.equal(numbersMatch(0.365, 0.3652), true, '三位小数应被接受');
    assert.equal(numbersMatch(0.37, 0.3652), true, '两位小数应被接受（0.0048 < 0.005）');
    assert.equal(numbersMatch(0.013, 0.0128), true);
    assert.equal(validateNumbers('r = 0.37', synthetic).ok, true);
    assert.equal(validateNumbers('p = 0.01', synthetic).ok, true);
  });

  test('超出容差的数字被拒绝，即使与真值相近', () => {
    assert.equal(numbersMatch(0.42, 0.3652), false);
    const result = validateNumbers('模型的解释力达到 0.42。', synthetic);
    assert.equal(result.ok, false);
    assert.equal(result.unmatched[0]!.issue, 'not_found');
    assert.equal(result.unmatched[0]!.value, 0.42);
    assert.match(result.unmatched[0]!.reason!, /结果包中不存在数值 0.42/);
  });

  test('结果包中完全不存在的数字被拒绝，并保留原样写法', () => {
    const result = validateNumbers('本研究共收集 1234 份样本。', synthetic);
    assert.equal(result.ok, false);
    assert.equal(result.unmatched.length, 1);
    assert.equal(result.unmatched[0]!.raw, '1234');
    assert.equal(result.unmatched[0]!.value, 1234);
    assert.equal(result.unmatched[0]!.unit, 'plain');
    assert.equal(result.unmatched[0]!.matched_path, null);
  });

  test('百分比与比例混淆被识别为单位错误', () => {
    const result = validateNumbers('量表内部一致性达到 87%，可以合并计分。', synthetic);
    assert.equal(result.ok, false);
    assert.equal(result.unmatched.length, 1);
    assert.equal(result.unmatched[0]!.issue, 'unit_mismatch');
    assert.equal(result.unmatched[0]!.matched_path, 'reliability.scales[FSE].cronbach_alpha');
    assert.match(result.unmatched[0]!.reason!, /比例/);
  });

  test('百分比被当作比例引用同样被拒绝（不同单位的另一方向）', () => {
    const result = validateNumbers('该选项占 25.53 的比例。', synthetic);
    assert.equal(result.ok, false);
    assert.equal(result.unmatched[0]!.issue, 'unit_mismatch');
    assert.equal(result.unmatched[0]!.matched_path, 'descriptive.variables[STAGE].frequencies[1].percent');
    assert.match(result.unmatched[0]!.reason!, /百分比/);
  });

  test('正确使用百分号时被接受', () => {
    const result = validateNumbers('该选项占 25.53%，共 12 人。', synthetic);
    assert.equal(result.ok, true, JSON.stringify(result.unmatched));
    const percent = result.numbers.find((entry) => entry.raw === '25.53%');
    assert.equal(percent?.unit, 'percent');
    assert.ok(percent?.matched_path?.endsWith('.percent'));
  });

  test('负号不影响溯源：引用幅度即视为引用该结果', () => {
    const result = validateNumbers('PRC 与 UI 呈负相关（r = 0.4）。', synthetic);
    assert.equal(result.ok, true, JSON.stringify(result.unmatched));
    assert.equal(result.numbers[0]!.matched_path, 'correlation.pairs[PRC|UI].r');
  });

  test('变量名与假设编号中的数字不会被误判为统计量', () => {
    assert.deepEqual(extractQuotedNumbers('H3、Q35、FSE1、STI6 均来自量表。'), []);
    // Metadata digits (ids, timestamps) must not become quotable "results".
    const values = collectBundleValues(synthetic);
    assert.equal(values.some((entry) => entry.path === 'project.id' && entry.value === 9), false);
    assert.equal(values.some((entry) => entry.path === 'generated_at'), false);
  });

  test('百分数字段被标记为百分比，普通字段不被标记', () => {
    const values = collectBundleValues(synthetic);
    const percent = values.find((entry) => entry.path.endsWith('frequencies[1].percent'));
    const alpha = values.find((entry) => entry.path === 'reliability.scales[FSE].cronbach_alpha');
    assert.equal(percent?.unit, 'percent');
    assert.equal(alpha?.unit, 'plain');
  });

  test('证据路径解析支持标识键、数组下标与文本路径', () => {
    assert.equal(resolveBundlePath(synthetic, 'hypotheses.results[H3].p_value').value, 0.013);
    assert.equal(resolveBundlePath(synthetic, 'correlation.pairs[PRC|UI].r').value, -0.4);
    assert.equal(resolveBundlePath(synthetic, 'caveats[0]').found, true);
    assert.equal(resolveBundlePath(synthetic, 'descriptive.variables[STAGE].n').value, 47);

    const missing = resolveBundlePath(synthetic, 'regression.ordinal.coefficients[STI].p_value');
    assert.equal(missing.found, false);
    assert.match(missing.reason!, /不存在|无法解析/);
  });

  test('容差窗口与常量一致（绝对 0.005 / 相对 0.5%）', () => {
    assert.equal(numbersMatch(47, 47), true);
    assert.equal(numbersMatch(47.3, 47), false, '0.3 超出 0.5% 相对容差（0.235）');
    assert.equal(numbersMatch(47.2, 47), true);
    assert.equal(numbersMatch(1, 1.004), true);
    assert.equal(numbersMatch(1, 1.006), false);
  });
});

/* ================================================================== */
/* Prompt construction                                                */
/* ================================================================== */

describe('提示词构造（纯函数）', () => {
  test('提示词包含真实统计量、研究问题、三重限制与结果包原文限定', () => {
    const h3 = hypothesisByCode('H3');
    const prompt = buildInterpretationPrompt({
      bundle: bundle as never,
      research_questions: ['家长的家庭教育需求结构如何？', '数字化服务需求受哪些因素影响？'],
      scope: { ...emptyScope(), section: 'hypotheses' },
    });

    // The actual engine value, not a placeholder.
    assert.ok(
      prompt.user.includes(`hypotheses.results[H3].r = ${String(h3.r)}`),
      '提示词必须包含 H3 的真实 r 值',
    );
    assert.ok(prompt.user.includes(`hypotheses.results[H3].p_value = ${String(h3.p_value)}`));
    assert.ok(prompt.user.includes('家长的家庭教育需求结构如何？'), '必须包含研究问题');
    assert.ok(prompt.user.includes(bundle.caveats[0]!), '必须逐字包含结果包的前提说明');
    assert.ok(prompt.user.includes(String(bundle.sample.analysable)), '必须包含有效样本量');

    // The three instructions the honesty of the feature depends on.
    assert.match(prompt.system, /禁止|不能/);
    assert.match(prompt.system, /因果/);
    assert.match(prompt.system, /inconclusive/);
    assert.match(prompt.system, /证据/);
    assert.match(prompt.system, /FACT/);
    assert.ok(prompt.prompt_hash.length === 64, '提示词哈希用于审计，必须是 SHA-256 十六进制');
  });

  test('提示词是纯函数：相同输入得到相同哈希，范围变化则不同', () => {
    const base = { bundle: bundle as never, research_questions: ['问题一'] };
    const first = buildInterpretationPrompt({ ...base, scope: emptyScope() });
    const second = buildInterpretationPrompt({ ...base, scope: emptyScope() });
    assert.equal(first.prompt_hash, second.prompt_hash);
    assert.equal(first.user, second.user);

    const focused = buildInterpretationPrompt({
      ...base,
      scope: { section: 'correlation', hypothesis_code: 'H3', focus: '只关注数字化服务需求' },
    });
    assert.notEqual(focused.prompt_hash, first.prompt_hash);
    assert.ok(focused.user.includes('只关注数字化服务需求'));
  });

  test('提示词中可引用的每一条路径都真的存在于结果包中', () => {
    const menu = buildEvidenceMenu(bundle as never);
    assert.ok(menu.length > 20, `证据清单过短：${menu.length}`);
    for (const entry of menu) {
      const resolved = resolveBundlePath(bundle, entry.path);
      assert.equal(resolved.found, true, `提示词公布了不存在的路径：${entry.path}`);
    }
    assert.ok(
      menu.some((entry) => entry.path === 'hypotheses.results[H3].p_value'),
      '假设检验的证据路径必须可引用',
    );
  });
});

/* ================================================================== */
/* Degraded mode                                                      */
/* ================================================================== */

describe('未配置 API 密钥时的降级模式', () => {
  test('状态接口如实告知不可用及原因', async () => {
    const response = await api<AiStatusData>(degradedCtx, 'GET', `/api/projects/${fixture.projectId}/ai/status`, {
      token: researcher.token,
    });
    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.configured, false);
    assert.equal(response.data.mode, 'degraded');
    assert.match(response.data.reason, /DEEPSEEK_API_KEY/);
    assert.equal(response.data.has_bundle, true);
    assert.equal(response.data.bundle_generated_at, bundle.generated_at);
    assert.equal(response.data.latest_mode, null, '尚未解释过，不应声称有过交互');
  });

  test('尚无解释记录时如实返回不可用', async () => {
    const response = await api<{ available: boolean; reason: string }>(
      degradedCtx,
      'GET',
      `/api/projects/${fixture.projectId}/ai/latest`,
      { token: researcher.token },
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.available, false);
    assert.match(response.data.reason, /AI 解释/);
  });

  test('解释请求返回降级的引擎摘要，而不是伪造的解释', async () => {
    const before = forbiddenFetchCalls;
    const response = await interpret(degradedCtx, researcher.token);
    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    assert.equal(data.mode, 'degraded');
    assert.equal(data.ai_unavailable?.code, 'missing_api_key');
    assert.match(data.ai_unavailable!.message, /DEEPSEEK_API_KEY/);
    assert.equal(data.prompt_hash, null, '未发送提示词时不得伪造哈希');
    assert.equal(data.usage, null);
    assert.equal(data.truncated, false);
    assert.equal(data.source_of_truth, 'analysis_bundle');
    assert.equal(forbiddenFetchCalls, before, '未配置密钥时不得发起任何网络请求');

    // The fallback is real content, and it is labelled as engine-derived.
    assert.ok(data.engine_summary, '降级模式必须给出引擎摘要');
    assert.equal(data.engine_summary!.derived_by, 'statistical_engine');
    assert.equal(data.engine_summary!.ai_generated, false);
    assert.ok(data.engine_summary!.text.length > 200, '摘要不能是空壳');
    assert.ok(data.engine_summary!.sections.length >= 6);
    assert.match(data.notice, /AI 解释当前不可用/);

    // No interpretations or recommendations are invented.
    assert.equal(data.layers.interpretations.length, 0);
    assert.equal(data.layers.recommendations.length, 0);
    assert.ok(data.layers.facts.length > 0);
    assert.ok(data.layers.statistical_findings.length > 0);
    assert.deepEqual(data.levels_used, ['FACT', 'STATISTICAL_FINDING']);
    assert.equal(data.statement_count, allStatements(data).length);

    // Caveats travel verbatim in every mode.
    assert.deepEqual(data.caveats, bundle.caveats);
  });

  test('引擎摘要只引用结果包中的数字，一个都不多', () => {
    const { summary, statements } = buildEngineDerivedSummary(bundle as never);
    const validation = validateNumbers(summary.text, bundle);
    assert.equal(
      validation.unmatched.length,
      0,
      `摘要中出现了结果包以外的数字：${JSON.stringify(validation.unmatched)}`,
    );
    for (const statement of statements) {
      assert.equal(
        validateNumbers(statement.text, bundle).unmatched.length,
        0,
        `摘要陈述引用了结果包以外的数字：${statement.text}`,
      );
    }
  });

  test('引擎摘要引用了真实的统计量，并且每条都有留痕', () => {
    const { summary, statements } = buildEngineDerivedSummary(bundle as never);
    const h3 = hypothesisByCode('H3');
    const fse = bundle.reliability.scales.find((scale) => scale.scale === 'FSE');

    assert.ok(summary.text.includes(String(bundle.sample.analysable)), '必须报告有效样本量');
    assert.ok(summary.text.includes(`r = ${String(h3.r)}`), '必须报告 H3 的真实相关系数');
    assert.ok(summary.text.includes(`p = ${String(h3.p_value)}`), '必须报告 H3 的真实 p 值');
    if (fse?.cronbach_alpha != null) {
      assert.ok(summary.text.includes(String(fse.cronbach_alpha)), '必须报告真实信度系数');
    }
    assert.ok(summary.text.includes(bundle.caveats[0]!), '前提说明必须逐字出现');
    assert.match(summary.text, /证据不足/, '必须保留三态判定措辞');
    assert.match(summary.text, /不等于证明两者之间没有关系/, '必须写明证据不足的含义');

    assert.ok(summary.text.length > 200, '摘要不能是空壳');
    assert.ok(summary.text.includes(bundle.caveats[0]!), '前提说明必须逐字出现');
    assert.ok(summary.text.includes('【事实】'), '摘要正文必须自带中文层级标签');
    assert.ok(summary.text.includes('【统计发现】'));
    assert.equal(summary.text.includes('【解释】'), false, '降级摘要不得出现解释层级');

    let withEvidence = 0;
    for (const statement of statements) {
      assert.ok(['FACT', 'STATISTICAL_FINDING'].includes(statement.level), '降级摘要不得出现解释或建议层级');
      for (const item of statement.evidence) {
        const resolved = resolveBundlePath(bundle, item.path);
        assert.equal(resolved.found, true, `留痕路径不存在：${item.path}`);
      }
      if (statement.evidence.length > 0) withEvidence += 1;
    }
    assert.ok(withEvidence >= statements.length - 2, '绝大多数摘要行必须可溯源');
  });
});

/* ================================================================== */
/* Live mode                                                          */
/* ================================================================== */

describe('实时模式的四层解析与证据留痕', () => {
  test('合规的模型输出被拆分为四层，并携带真实数值的证据', async () => {
    const analysable = bundle.sample.analysable;
    const h3 = hypothesisByCode('H3');
    const r = h3.r!;
    const p = h3.p_value!;

    scripted = {
      kind: 'content',
      content: [
        `[FACT] 进入分析的有效样本为 ${analysable} 份，另有 ${bundle.sample.excluded} 份被研究者排除。 证据: sample.analysable=${analysable}; sample.excluded=${bundle.sample.excluded}`,
        `[STATISTICAL_FINDING] 家庭教育困难（FED）与数字化服务需求（DSD）呈显著正相关（r = ${r}, p = ${p}, n = ${h3.n}）。 证据: hypotheses.results[H3].r=${r}; hypotheses.results[H3].p_value=${p}`,
        `[INTERPRETATION] 该 r = ${r} 的结果提示困难程度较高的家庭对数字化服务需求的报告值可能更高，但横截面数据不能说明先后顺序。 证据: hypotheses.results[H3].r=${r}`,
        `[RECOMMENDATION] 建议在服务设计上优先覆盖困难程度较高的家庭，并在后续研究中用纵向设计验证该提示。 证据: hypotheses.results[H3].p_value=${p}`,
      ].join('\n'),
    };

    const response = await interpret(liveCtx, researcher.token, { section: 'hypotheses' });
    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    assert.equal(data.mode, 'live');
    assert.equal(data.ai_unavailable, null);
    assert.equal(data.engine_summary, null, '实时模式不应返回引擎摘要');
    assert.deepEqual(data.levels_used, ['FACT', 'STATISTICAL_FINDING', 'INTERPRETATION', 'RECOMMENDATION']);

    assert.equal(data.layers.facts.length, 1);
    assert.equal(data.layers.statistical_findings.length, 1);
    assert.equal(data.layers.interpretations.length, 1);
    assert.equal(data.layers.recommendations.length, 1);
    assert.equal(data.statement_count, 4);
    assert.deepEqual(data.rejected_claims, []);
    assert.deepEqual(data.warnings, []);
    assert.equal(data.truncated, false);
    assert.equal(data.prompt_hash?.length, 64);
    assert.equal(data.model, 'deepseek-chat');
    assert.equal(data.usage?.total_tokens, 1500, '必须记录供应商报告的 token 用量');
    assert.deepEqual(data.caveats, bundle.caveats);
    assert.deepEqual(data.scope, { section: 'hypotheses', hypothesis_code: null, focus: null });

    // Evidence must quote the engine's own numbers, at the engine's own paths.
    const finding = data.layers.statistical_findings[0]!;
    const pEvidence = finding.evidence.find((item) => item.path === 'hypotheses.results[H3].p_value');
    assert.ok(pEvidence, `证据留痕缺少 p 值路径：${JSON.stringify(finding.evidence)}`);
    assert.equal(pEvidence!.value, p, '证据留痕必须引用结果包中真实的 p 值');
    const rEvidence = finding.evidence.find((item) => item.path === 'hypotheses.results[H3].r');
    assert.equal(rEvidence!.value, r);

    const fact = data.layers.facts[0]!;
    assert.equal(fact.level, 'FACT');
    assert.equal(fact.label_inferred, false);
    assert.equal(fact.hypothesis_code, null);
    const sampleEvidence = fact.evidence.find((item) => item.path === 'sample.analysable');
    assert.equal(sampleEvidence?.value, analysable);

    // The layering is visible in the Chinese prose itself, not only in the JSON
    // structure, so a quoted sentence still shows which level it came from.
    assert.equal(fact.labelled_text, `【事实】${fact.text}`);
    assert.equal(finding.labelled_text, `【统计发现】${finding.text}`);
    assert.equal(
      data.layers.recommendations[0]!.labelled_text,
      `【建议】${data.layers.recommendations[0]!.text}`,
    );
    assert.equal(
      data.layers.interpretations[0]!.labelled_text,
      `【解释】${data.layers.interpretations[0]!.text}`,
    );

    // A statement that mentions H3 is attributed to it, which is what lets the
    // report link an interpretation back to a hypothesis.
    assert.equal(data.layers.interpretations[0]!.hypothesis_code, 'H3');
  });

  test('发送给供应商的请求携带模型、密钥与研究者指定的关注范围', async () => {
    const h3 = hypothesisByCode('H3');
    scripted = {
      kind: 'content',
      content: `[STATISTICAL_FINDING] 相关系数为 r = ${h3.r}。 证据: hypotheses.results[H3].r=${h3.r}`,
    };

    const response = await interpret(liveCtx, researcher.token, {
      section: 'correlation',
      hypothesis_code: 'H3',
      focus: '只解释数字化服务需求相关的相关矩阵',
    });
    assert.equal(response.status, 200, JSON.stringify(response.error));

    const call = providerCalls[providerCalls.length - 1]!;
    assert.match(call.url, /\/chat\/completions$/);
    assert.equal(call.authorization, 'Bearer test-key-not-a-real-secret');
    assert.equal(call.model, 'deepseek-chat');
    assert.ok(call.body.includes('只解释数字化服务需求相关的相关矩阵'), '关注范围必须进入提示词');
    assert.ok(call.body.includes(`${h3.r}`), '提示词必须携带真实数值');
    assert.ok(call.body.includes('stream'), '必须显式声明非流式请求');
  });

  test('模型输出被截断时如实标注，已完成的部分仍然可用', async () => {
    const h3 = hypothesisByCode('H3');
    scripted = {
      kind: 'content',
      finish_reason: 'length',
      content: `[STATISTICAL_FINDING] 相关系数为 r = ${h3.r}。 证据: hypotheses.results[H3].r=${h3.r}`,
    };

    const response = await interpret(liveCtx, researcher.token);
    assert.equal(response.status, 200, JSON.stringify(response.error));
    assert.equal(response.data.mode, 'live');
    assert.equal(response.data.truncated, true);
    assert.ok(
      response.data.warnings.some((warning) => warning.includes('截断')),
      `必须提示输出被截断：${JSON.stringify(response.data.warnings)}`,
    );
    assert.equal(response.data.layers.statistical_findings.length, 1);
  });
});

/* ================================================================== */
/* Hallucination guard                                                */
/* ================================================================== */

describe('幻觉数字拦截', () => {
  test('结果包中不存在的数字会使整条陈述被剔除并上报', async () => {
    const h3 = hypothesisByCode('H3');
    const fabricated = fabricatedNumber();

    scripted = {
      kind: 'content',
      content: [
        `[STATISTICAL_FINDING] 家庭教育困难与数字化服务需求显著正相关（r = ${h3.r}）。 证据: hypotheses.results[H3].r=${h3.r}`,
        `[STATISTICAL_FINDING] 该模型的解释力达到 ${fabricated}，说明预测效果极强。 证据: hypotheses.results[H3].p_value=${h3.p_value}`,
      ].join('\n'),
    };

    const response = await interpret(liveCtx, researcher.token);
    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    assert.equal(data.rejected_claims.length, 1, JSON.stringify(data.rejected_claims));
    const rejection = data.rejected_claims[0]!;
    assert.equal(rejection.code, 'untraceable_number');
    assert.equal(rejection.quoted_number, fabricated);
    assert.equal(rejection.raw_number, String(fabricated));
    assert.match(rejection.reason, /结果包中不存在数值/);
    assert.match(rejection.text, /解释力达到/);

    // The offending statement is absent everywhere, and the good one survives.
    const serialised = JSON.stringify(data.layers);
    assert.equal(serialised.includes(String(fabricated)), false, '被拒绝的数字绝不能出现在结果中');
    assert.equal(serialised.includes('解释力达到'), false, '被拒绝的整条陈述必须一并移除');
    assert.equal(data.layers.statistical_findings.length, 1);
    assert.match(data.layers.statistical_findings[0]!.text, new RegExp(String(h3.r).replace('.', '\\.')));
  });

  test('伪造的证据路径使陈述因无法溯源而失败', async () => {
    const h3 = hypothesisByCode('H3');
    scripted = {
      kind: 'content',
      content: [
        `[STATISTICAL_FINDING] 有序回归显示信任显著提升使用意愿（B = ${h3.r}）。 证据: regression.ordinal.coefficients[NOT_A_TERM].b=${h3.r}`,
        `[FACT] 有效样本为 ${bundle.sample.analysable} 份。 证据: sample.NOT_A_FIELD=${bundle.sample.analysable}`,
      ].join('\n'),
    };

    const response = await interpret(liveCtx, researcher.token);
    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    // A valid number does not rescue a statement whose only declared trace is
    // broken: the number alone cannot say what the statement is about.
    assert.equal(data.layers.statistical_findings.length, 0);
    assert.ok(
      data.rejected_claims.some(
        (claim) => claim.code === 'evidence_path_not_found' || claim.code === 'no_evidence',
      ),
      JSON.stringify(data.rejected_claims),
    );
    assert.ok(data.rejected_claims.every((claim) => claim.reason.length > 0));
  });
});

/* ================================================================== */
/* Non-compliant output                                               */
/* ================================================================== */

describe('模型不遵守分层标签要求时', () => {
  test('输出仍被结构化解析，层级由措辞推断并显式标记', async () => {
    const analysable = bundle.sample.analysable;
    scripted = {
      kind: 'content',
      content: [
        '本次分析的有效样本量为 ' + String(analysable) + ' 份，均为已完成且未被研究者排除的样本。',
        `（证据：sample.analysable=${analysable}）`,
        '建议后续扩大样本量以提升检验效力，并说明排除样本的标准。',
      ].join('\n'),
    };

    const response = await interpret(liveCtx, researcher.token);
    assert.equal(response.status, 200, JSON.stringify(response.error));
    const data = response.data;

    // Well-formed payload: the four layers always exist, never one merged blob.
    for (const key of ['facts', 'statistical_findings', 'interpretations', 'recommendations'] as const) {
      assert.ok(Array.isArray(data.layers[key]), `层级 ${key} 必须是数组`);
    }
    assert.equal(data.mode, 'live');
    assert.ok(data.statement_count >= 1, '至少应保留可溯源的陈述');
    assert.ok(
      data.warnings.some((warning) => warning.includes('分层标签')),
      `必须提示模型未遵守标签要求：${JSON.stringify(data.warnings)}`,
    );

    const inferred = allStatements(data).filter((statement) => statement.label_inferred);
    assert.ok(inferred.length >= 1, '缺少标签的陈述必须标记为推断层级');
    assert.ok(
      inferred.every((statement) => ['FACT', 'STATISTICAL_FINDING', 'INTERPRETATION', 'RECOMMENDATION'].includes(statement.level)),
    );

    // The suggestion had no number and no valid evidence clause, so it is
    // reported rather than shipped as an untraceable recommendation.
    assert.equal(data.layers.recommendations.length, 0);
    assert.ok(
      data.rejected_claims.some((claim) => claim.code === 'no_evidence' && claim.text.includes('建议后续扩大样本量')),
      JSON.stringify(data.rejected_claims),
    );

    // The surviving statement keeps a real evidence trace.
    const survivor = allStatements(data)[0]!;
    const evidence = survivor.evidence.find((item) => item.path === 'sample.analysable');
    assert.equal(evidence?.value, analysable);
  });
});

/* ================================================================== */
/* Provider failure modes                                             */
/* ================================================================== */

describe('供应商异常时必须给出明确结果而非静默成功', () => {
  const cases: {
    name: string;
    script: ScriptedProvider;
    code: string;
    status: number | null;
    message: RegExp;
  }[] = [
    {
      name: 'HTTP 401（密钥无效）',
      script: { kind: 'raw', status: 401, body: '{"error":{"message":"Authentication Fails"}}' },
      code: 'provider_http_error',
      status: 401,
      message: /HTTP 401/,
    },
    {
      name: 'HTTP 500（服务端错误）',
      script: { kind: 'raw', status: 500, body: '{"error":{"message":"Internal Server Error"}}' },
      code: 'provider_http_error',
      status: 500,
      message: /HTTP 500/,
    },
    {
      name: '网络错误',
      script: { kind: 'throw', error: new TypeError('fetch failed') },
      code: 'network_error',
      status: null,
      message: /网络错误/,
    },
    {
      name: '请求超时',
      script: { kind: 'throw', error: Object.assign(new Error('The operation was aborted due to timeout'), { name: 'TimeoutError' }) },
      code: 'timeout',
      status: null,
      message: /超时/,
    },
    {
      name: '响应不是合法 JSON',
      script: { kind: 'raw', status: 200, body: '<html>502 Bad Gateway</html>', content_type: 'text/html' },
      code: 'malformed_json',
      status: 200,
      message: /合法 JSON/,
    },
    {
      name: '流式（SSE）响应',
      script: { kind: 'raw', status: 200, body: 'data: {"choices":[{"delta":{"content":"x"}}]}\n\ndata: [DONE]\n\n', content_type: 'text/event-stream' },
      code: 'unexpected_shape',
      status: 200,
      message: /流式/,
    },
    {
      name: '响应没有 choices',
      script: { kind: 'raw', status: 200, body: '{"id":"x","usage":{"total_tokens":3}}' },
      code: 'empty_choices',
      status: 200,
      message: /choices/,
    },
    {
      name: '内容为空',
      script: { kind: 'content', content: '   ' },
      code: 'empty_content',
      status: 200,
      message: /空内容/,
    },
  ];

  for (const item of cases) {
    test(`${item.name} → 降级并说明原因`, async () => {
      scripted = item.script;
      const response = await interpret(liveCtx, researcher.token);
      assert.equal(response.status, 200, `${item.name} 不应产生 500：${JSON.stringify(response.error)}`);
      const data = response.data;

      assert.equal(data.mode, 'degraded', `${item.name} 必须降级而不是假装成功`);
      assert.equal(data.ai_unavailable?.code, item.code);
      assert.equal(data.ai_unavailable?.provider_status, item.status);
      assert.match(data.ai_unavailable!.message, item.message);
      assert.ok(data.engine_summary, `${item.name} 仍应返回引擎摘要`);
      assert.ok(data.engine_summary!.text.length > 200);
      assert.equal(data.layers.interpretations.length, 0, '失败时不得生成解释');
      assert.ok(
        data.warnings.some((warning) => warning.includes('AI 调用失败')),
        `必须记录失败原因：${JSON.stringify(data.warnings)}`,
      );
      assert.equal(data.rejected_claims.length, 0);
      // The hash proves which prompt was attempted, even though no answer came back.
      assert.equal(data.prompt_hash?.length, 64);
    });
  }
});

/* ================================================================== */
/* Authorisation and preconditions                                    */
/* ================================================================== */

describe('鉴权与前置条件', () => {
  test('未登录访问四个接口均为 401', async () => {
    const paths: [string, 'GET' | 'POST'][] = [
      [`/api/projects/${fixture.projectId}/ai/status`, 'GET'],
      [`/api/projects/${fixture.projectId}/ai/latest`, 'GET'],
      [`/api/projects/${fixture.projectId}/ai/history`, 'GET'],
      [`/api/projects/${fixture.projectId}/ai/interpret`, 'POST'],
    ];
    for (const [path, method] of paths) {
      const response = await api(degradedCtx, method, path, { body: method === 'POST' ? {} : undefined });
      assert.equal(response.status, 401, `${method} ${path} 应要求登录`);
    }
  });

  test('他人项目不可见（403/404）', async () => {
    const outsider = await registerResearcher(degradedCtx, { name: '无关研究者' });
    const paths: [string, 'GET' | 'POST'][] = [
      [`/api/projects/${fixture.projectId}/ai/status`, 'GET'],
      [`/api/projects/${fixture.projectId}/ai/latest`, 'GET'],
      [`/api/projects/${fixture.projectId}/ai/history`, 'GET'],
      [`/api/projects/${fixture.projectId}/ai/interpret`, 'POST'],
    ];
    for (const [path, method] of paths) {
      const response = await api(degradedCtx, method, path, {
        token: outsider.token,
        body: method === 'POST' ? {} : undefined,
      });
      assert.ok(
        response.status === 403 || response.status === 404,
        `${method} ${path} 返回了意外状态码 ${response.status}`,
      );
    }
  });

  test('尚未运行统计分析时返回 400 与明确的中文说明', async () => {
    const project = await api<{ project: { id: string } }>(degradedCtx, 'POST', '/api/projects', {
      token: researcher.token,
      body: { title: '还没有统计结果的项目' },
    });
    assert.equal(project.status, 201);
    const projectId = project.data.project.id;

    const response = await interpret(degradedCtx, researcher.token, {}, projectId);
    assert.equal(response.status, 400);
    assert.equal(response.error?.code, 'VALIDATION_ERROR');
    assert.match(response.error!.message, /统计分析/);

    const status = await api<AiStatusData>(degradedCtx, 'GET', `/api/projects/${projectId}/ai/status`, {
      token: researcher.token,
    });
    assert.equal(status.status, 200);
    assert.equal(status.data.has_bundle, false);
    assert.equal(status.data.bundle_generated_at, null);
  });

  test('非法的解释范围与假设编号被拒绝', async () => {
    const badSection = await interpret(degradedCtx, researcher.token, { section: '因果推断' });
    assert.equal(badSection.status, 400);
    assert.match(badSection.error!.message, /section/);

    const badHypothesis = await interpret(degradedCtx, researcher.token, { hypothesis_code: 'H99' });
    assert.equal(badHypothesis.status, 400);
    assert.match(badHypothesis.error!.message, /H99/);
    assert.match(badHypothesis.error!.message, /H1/);

    const badType = await api(degradedCtx, 'POST', `/api/projects/${fixture.projectId}/ai/interpret`, {
      token: researcher.token,
      body: { focus: { nested: true } },
    });
    assert.equal(badType.status, 400);
    assert.match(badType.error!.message, /focus/);

    const badLimit = await api(degradedCtx, 'GET', `/api/projects/${fixture.projectId}/ai/history?limit=0`, {
      token: researcher.token,
    });
    assert.equal(badLimit.status, 400);
  });
});

/* ================================================================== */
/* Audit trail                                                        */
/* ================================================================== */

describe('AI 交互审计', () => {
  test('每一次尝试都留下一行记录，含模式与被拒绝数量', async () => {
    const response = await api<HistoryRow[]>(
      degradedCtx,
      'GET',
      `/api/projects/${fixture.projectId}/ai/history?limit=100`,
      { token: researcher.token },
    );
    assert.equal(response.status, 200, JSON.stringify(response.error));
    const rows = response.data;

    assert.equal(rows.length, interpretAttempts, '每次调用必须恰好留下一行审计记录');
    assert.ok(interpretAttempts >= 10, `审计样本过少：${interpretAttempts}`);

    for (const row of rows) {
      assert.ok(['live', 'degraded'].includes(row.mode), `模式异常：${row.mode}`);
      assert.equal(typeof row.rejected_claim_count, 'number');
      assert.equal(row.rejected_claim_count, row.rejected_claims.length);
      assert.equal(row.model, 'deepseek-chat');
      assert.equal(row.engine_version, bundle.engine_version);
      assert.equal(row.prompt_version, '1.0.0');
      assert.ok(row.created_at.length > 0);
      assert.ok(row.duration_ms === null || row.duration_ms >= 0);
    }

    // Modes must reflect what actually happened.
    assert.ok(rows.some((row) => row.mode === 'live'), '缺少实时模式记录');
    assert.ok(rows.some((row) => row.mode === 'degraded'), '缺少降级模式记录');

    // A missing key is recorded with no prompt hash and no raw response.
    const missingKey = rows.filter((row) => row.error_code === 'missing_api_key');
    assert.ok(missingKey.length >= 1);
    assert.equal(missingKey[0]!.prompt_hash, '');
    assert.equal(missingKey[0]!.raw_response, null);

    // Provider failures record the raw body for later diagnosis.
    const httpError = rows.find((row) => row.error_code === 'provider_http_error');
    assert.ok(httpError, '缺少供应商错误记录');
    assert.match(httpError!.raw_response ?? '', /Authentication Fails|Internal Server Error/);
    assert.ok(httpError!.prompt_hash.length === 64);
  });

  test('幻觉被拒绝的交互可完整回放：原始响应、校验结果与拒绝理由', async () => {
    const rows = await api<HistoryRow[]>(
      degradedCtx,
      'GET',
      `/api/projects/${fixture.projectId}/ai/history?limit=100`,
      { token: researcher.token },
    );

    // Pick the interaction whose rejection was caused by a quoted number, so the
    // raw provider response can be checked to contain that exact figure.
    const rejected = rows.data.find((row) =>
      row.rejected_claims.some((claim) => claim.raw_number !== null),
    );
    assert.ok(rejected, '审计记录中必须保留因数字被拒绝的交互');
    const claim = rejected!.rejected_claims.find((entry) => entry.raw_number !== null)!;

    assert.equal(rejected!.mode, 'live');
    assert.equal(claim.code, 'untraceable_number');
    assert.ok(rejected!.raw_response && rejected!.raw_response.includes('chatcmpl-test'), '必须保留原始响应');
    assert.ok(
      rejected!.raw_response!.includes(claim.raw_number!),
      '原始响应必须保留被拒绝的数字原样，便于事后复核',
    );
    assert.equal(rejected!.result?.mode, 'live');
    assert.equal(rejected!.result?.statement_count, 1, '被拒绝的陈述不进入校验结果');
    assert.equal(rejected!.result?.rejected_claims.length, rejected!.rejected_claim_count);
    assert.ok(
      rejected!.raw_response!.includes(rejected!.result!.layers.statistical_findings[0]!.text),
      '通过的陈述也必须能在原始响应中找到',
    );

    // Token usage reported by the provider is part of the audit record.
    const withUsage = rows.data.find((row) => row.total_tokens !== null);
    assert.equal(withUsage?.total_tokens, 1500);
  });

  test('latest 返回最近一次交互，包含失败的尝试', async () => {
    scripted = { kind: 'raw', status: 401, body: '{"error":{"message":"Authentication Fails"}}' };
    const failed = await interpret(liveCtx, researcher.token);
    assert.equal(failed.status, 200);

    const latest = await api<{
      available: boolean;
      id: string;
      mode: string;
      error_code: string | null;
      rejected_claim_count: number;
      result: InterpretData | null;
    }>(degradedCtx, 'GET', `/api/projects/${fixture.projectId}/ai/latest`, { token: researcher.token });

    assert.equal(latest.status, 200);
    assert.equal(latest.data.available, true);
    assert.equal(latest.data.id, failed.data.interaction_id);
    assert.equal(latest.data.mode, 'degraded');
    assert.equal(latest.data.error_code, 'provider_http_error');
    assert.equal(latest.data.result?.mode, 'degraded');
    assert.ok(latest.data.result?.engine_summary);

    const history = await api<HistoryRow[]>(
      degradedCtx,
      'GET',
      `/api/projects/${fixture.projectId}/ai/history?limit=5`,
      { token: researcher.token },
    );
    assert.equal(history.data[0]!.id, latest.data.id, '历史记录按时间倒序');
  });
});
