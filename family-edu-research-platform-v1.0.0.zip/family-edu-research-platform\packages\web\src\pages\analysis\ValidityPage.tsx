/**
 * Validity analysis (PHASE 6).
 *
 * Factor analysis is only meaningful when the correlation matrix is worth
 * factoring, so the instrument-level diagnostics (KMO overall, per-item MSA,
 * Bartlett) are shown BEFORE any loading, and the page states plainly when the
 * data do not support the analysis instead of printing loadings regardless.
 *
 * Every number here is the engine's: no extraction, rotation or thresholding
 * happens in the browser.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Alert, Badge, Card, CardHeader, LoadingBlock } from '../../components/ui';
import { BarChart } from '../../components/charts';
import {
  api,
  ApiClientError,
  type AnalysisValidityResponse,
  type EfaResult,
} from '../../lib/api';
import type { BadgeTone } from '../../lib/format';
import { formatPValue, formatStat } from '../../lib/format';
import {
  AnalysisPageHeader,
  AnalysisProjectGate,
  ErrorNotice,
  MethodNote,
  useAnalysisProject,
} from './shared';

const ADEQUACY: Record<string, { label: string; tone: BadgeTone }> = {
  marvelous: { label: '极佳（KMO ≥ 0.90）', tone: 'success' },
  meritorious: { label: '良好（0.80—0.89）', tone: 'success' },
  middling: { label: '中等（0.70—0.79）', tone: 'info' },
  mediocre: { label: '勉强（0.60—0.69）', tone: 'warning' },
  miserable: { label: '较差（0.50—0.59）', tone: 'warning' },
  unacceptable: { label: '不可接受（< 0.50）', tone: 'danger' },
  unknown: { label: '无法判定', tone: 'neutral' },
};

function EfaBlock({ scale, label, result }: { scale: string; label: string; result: EfaResult }): ReactNode {
  const factorCount = Math.max(result.factors_retained, 1);

  return (
    <Card>
      <CardHeader
        title={`${label}（${scale}）`}
        description={
          `整例有效样本 n = ${result.n} · 进入分析的条目 p = ${result.p} · ` +
          `提取方法 ${result.extraction === 'principal_component' ? '主成分分析' : result.extraction} · ` +
          `旋转 ${result.rotation === 'varimax' ? '最大方差法（varimax）' : '不旋转'} · ` +
          `按 Kaiser 准则（特征值 > 1）可提取 ${result.kaiser_factors} 个因子，实际保留 ${result.factors_retained} 个`
        }
      />

      <p className="text-sm leading-relaxed text-ink-700">{result.interpretation}</p>

      <div className="mt-4 grid gap-5 lg:grid-cols-2">
        <div className="overflow-x-auto">
          <h3 className="mb-2 text-sm font-medium text-ink-800">特征值与方差解释</h3>
          <table className="w-full min-w-[320px] text-sm">
            <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-3 py-2 text-left">成分</th>
                <th className="px-3 py-2 text-right">特征值</th>
                <th className="px-3 py-2 text-right">方差解释率</th>
                <th className="px-3 py-2 text-right">累积解释率</th>
                <th className="px-3 py-2 text-left">Kaiser</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {result.eigenvalues.map((eigenvalue, index) => (
                <tr key={`eigen-${index}`}>
                  <td className="px-3 py-2 text-ink-800">{`成分 ${index + 1}`}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-900">{formatStat(eigenvalue, 4)}</td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                    {formatStat((result.variance_explained[index] ?? 0) * 100, 2)}%
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums text-ink-700">
                    {formatStat((result.cumulative_variance[index] ?? 0) * 100, 2)}%
                  </td>
                  <td className="px-3 py-2 text-xs">
                    {eigenvalue > 1 ? <Badge tone="info">特征值 &gt; 1</Badge> : <span className="text-ink-400">—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {result.rotated_variance_explained.length > 0 && (
            <p className="mt-2 text-xs text-ink-500">
              旋转后各因子方差解释率：
              {result.rotated_variance_explained.map((value) => `${(value * 100).toFixed(2)}%`).join('、')}；
              旋转后累积解释率 {(result.rotated_cumulative_variance * 100).toFixed(2)}%。
            </p>
          )}
        </div>

        <div>
          <h3 className="mb-2 text-sm font-medium text-ink-800">碎石图（特征值）</h3>
          <BarChart
            data={result.scree.map((point) => ({
              label: `成分 ${point.component}`,
              value: point.eigenvalue,
              percent: (result.variance_explained[point.component - 1] ?? 0) * 100,
            }))}
            unit="λ"
            emptyText="没有可绘制的特征值。"
            caption={
              '条形长度为该成分的特征值，百分比为该成分解释的方差比例。' +
              'Kaiser 准则以特征值 1 为界：特征值大于 1 的成分才被视为一个因子，`Kaiser` 列已逐行标出。'
            }
          />
        </div>
      </div>

      <div className="mt-5 overflow-x-auto">
        <h3 className="mb-2 text-sm font-medium text-ink-800">因子负荷与共同度</h3>
        <table className="w-full min-w-[560px] text-sm">
          <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-3 py-2 text-left">条目</th>
              {Array.from({ length: factorCount }, (_, index) => (
                <th key={`f-${index}`} className="px-3 py-2 text-right">{`因子 ${index + 1}`}</th>
              ))}
              <th className="px-3 py-2 text-right">共同度</th>
              <th className="px-3 py-2 text-left">主因子</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-100">
            {result.loadings.map((loading) => (
              <tr key={loading.variable}>
                <td className="px-3 py-2">
                  <span className="text-ink-900">{loading.label}</span>
                  <span className="ml-2 font-mono text-[11px] text-ink-500">{loading.variable}</span>
                </td>
                {Array.from({ length: factorCount }, (_, index) => {
                  const value = loading.loadings[index];
                  const primary = loading.primary_factor === index + 1;
                  return (
                    <td
                      key={`l-${index}`}
                      className={`px-3 py-2 text-right tabular-nums ${
                        primary ? 'font-semibold text-brand-700' : 'text-ink-700'
                      }`}
                    >
                      {formatStat(value, 3)}
                    </td>
                  );
                })}
                <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                  {formatStat(loading.communality, 3)}
                </td>
                <td className="px-3 py-2 text-xs text-ink-600">
                  {`因子 ${loading.primary_factor}（${formatStat(loading.primary_loading, 3)}）`}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {(result.low_communality.length > 0 || result.cross_loading.length > 0) && (
        <div className="mt-3 space-y-2">
          {result.low_communality.length > 0 && (
            <Alert tone="warning" title="共同度偏低的条目">
              {result.low_communality.join('、')}
              ：共同度低于常用 0.40 惯例，说明保留的因子解释不了该条目的大部分变异，可考虑删除或单独处理。
            </Alert>
          )}
          {result.cross_loading.length > 0 && (
            <Alert tone="warning" title="存在交叉负荷的条目">
              <ul className="list-disc space-y-1 pl-4">
                {result.cross_loading.map((item) => (
                  <li key={item.variable}>
                    {item.variable}：在因子 {item.factors.join('、')} 上的负荷为{' '}
                    {item.loadings.map((value) => formatStat(value, 3)).join('、')}，均达到 0.40，结构归属不清晰。
                  </li>
                ))}
              </ul>
            </Alert>
          )}
        </div>
      )}

      {result.warnings.length > 0 && (
        <ul className="mt-3 list-disc space-y-1 pl-4 text-xs text-amber-800">
          {result.warnings.map((warning) => (
            <li key={warning}>{warning}</li>
          ))}
        </ul>
      )}
    </Card>
  );
}

export function ValidityPage(): ReactNode {
  const state = useAnalysisProject();
  const { projectId } = state;

  const [data, setData] = useState<AnalysisValidityResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    setError(null);
    try {
      setData(await api.analysis.validity(projectId));
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '无法加载效度分析结果。');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const adequacy = ADEQUACY[data?.overall_kmo.adequacy ?? 'unknown'] ?? ADEQUACY['unknown']!;

  return (
    <AnalysisProjectGate state={state}>
      <div className="space-y-6">
        <AnalysisPageHeader
          title="Validity"
          subtitle="效度分析：因素分析适切性（KMO / Bartlett）与各量表的探索性因素分析。"
          state={state}
        />

        {error && <ErrorNotice message={error} />}

        {loading && !data ? (
          <LoadingBlock label="正在计算效度指标…" />
        ) : !data ? null : (
          <>
            <MethodNote>
              <p>{data.note}</p>
              <p>引擎版本 {data.engine_version}。KMO 与 Bartlett 基于所有量表条目；各量表的因素分析单独进行。</p>
            </MethodNote>

            {data.warnings.length > 0 && (
              <Alert tone="warning" title="整体提示">
                <ul className="list-disc space-y-1 pl-4">
                  {data.warnings.map((warning) => (
                    <li key={warning}>{warning}</li>
                  ))}
                </ul>
              </Alert>
            )}

            <div className="grid gap-4 lg:grid-cols-2">
              <Card>
                <CardHeader
                  title="KMO 取样适切性"
                  description="KMO 比较变量间简单相关与偏相关的大小；值越低说明变量间的共同变异越难以归结为少数因子。"
                  actions={<Badge tone={adequacy.tone}>{adequacy.label}</Badge>}
                />
                <p className="text-3xl font-semibold tabular-nums text-ink-900">
                  {formatStat(data.overall_kmo.overall, 3)}
                </p>
                <p className="mt-2 text-sm leading-relaxed text-ink-700">{data.overall_kmo.interpretation}</p>

                {data.overall_kmo.per_variable.length > 0 && (
                  <div className="mt-4 overflow-x-auto">
                    <table className="w-full min-w-[320px] text-sm">
                      <thead className="bg-ink-50 text-xs uppercase tracking-wide text-ink-500">
                        <tr>
                          <th className="px-3 py-2 text-left">变量（MSA）</th>
                          <th className="px-3 py-2 text-right">取样适切性</th>
                          <th className="px-3 py-2 text-left">提示</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-ink-100">
                        {data.overall_kmo.per_variable.map((item) => (
                          <tr key={item.variable}>
                            <td className="px-3 py-2 font-mono text-xs text-ink-800">{item.variable}</td>
                            <td className="px-3 py-2 text-right tabular-nums text-ink-800">
                              {formatStat(item.msa, 3)}
                            </td>
                            <td className="px-3 py-2 text-xs">
                              {item.msa !== null && item.msa < 0.5 ? (
                                <span className="text-amber-700">低于 0.50，是拉低整体 KMO 的主要来源</span>
                              ) : (
                                <span className="text-ink-400">—</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </Card>

              <Card>
                <CardHeader
                  title="Bartlett 球形检验"
                  description="检验相关矩阵是否显著偏离单位矩阵；显著是进行因素分析的前提之一。"
                  actions={
                    <Badge tone={data.overall_bartlett.unavailable ? 'warning' : 'info'}>
                      {data.overall_bartlett.unavailable ? '无法计算' : '已计算'}
                    </Badge>
                  }
                />
                <dl className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <dt className="text-xs uppercase tracking-wide text-ink-500">χ²</dt>
                    <dd className="mt-1 tabular-nums text-ink-900">{formatStat(data.overall_bartlett.chi_square, 3)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs uppercase tracking-wide text-ink-500">自由度</dt>
                    <dd className="mt-1 tabular-nums text-ink-900">{data.overall_bartlett.degrees_of_freedom}</dd>
                  </div>
                  <div>
                    <dt className="text-xs uppercase tracking-wide text-ink-500">显著性</dt>
                    <dd className="mt-1 tabular-nums text-ink-900">
                      {formatPValue(data.overall_bartlett.p_value)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs uppercase tracking-wide text-ink-500">相关矩阵行列式</dt>
                    <dd className="mt-1 tabular-nums text-ink-900">
                      {data.overall_bartlett.determinant === null
                        ? '—'
                        : data.overall_bartlett.determinant.toExponential(3)}
                    </dd>
                  </div>
                </dl>
                <p className="mt-3 text-sm leading-relaxed text-ink-700">
                  {data.overall_bartlett.interpretation}
                </p>
              </Card>
            </div>

            {data.scale_efa.length === 0 ? (
              <Alert tone="warning" title="没有可做因素分析的量表">
                该问卷未定义量表，或量表条目不足以构成相关矩阵，因此没有探索性因素分析结果。
              </Alert>
            ) : (
              data.scale_efa.map((entry) => (
                <EfaBlock key={entry.scale} scale={entry.scale} label={entry.label} result={entry.result} />
              ))
            )}
          </>
        )}
      </div>
    </AnalysisProjectGate>
  );
}
