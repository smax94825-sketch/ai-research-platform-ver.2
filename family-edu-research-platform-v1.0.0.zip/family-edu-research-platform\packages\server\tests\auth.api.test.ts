/**
 * Authentication API tests.
 *
 * Covers the full account lifecycle over real HTTP: registration, login,
 * session lookup, logout with token revocation, and the authorisation
 * boundaries between researchers.
 */

import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { api, createTestContext, registerResearcher, type TestContext } from './helpers.js';

let ctx: TestContext;

before(async () => {
  ctx = await createTestContext();
});

after(async () => {
  await ctx.close();
});

describe('健康检查', () => {
  test('GET /api/health 返回服务与数据库状态', async () => {
    const response = await api<{ status: string; env: string; database: string; researchers: number }>(
      ctx,
      'GET',
      '/api/health',
    );
    assert.equal(response.status, 200);
    assert.equal(response.data.status, 'ok');
    assert.equal(response.data.env, 'test');
    assert.equal(response.data.database, 'in-memory');
    assert.equal(typeof response.data.researchers, 'number');
  });
});

describe('研究者注册', () => {
  test('注册成功返回研究者信息与 JWT', async () => {
    const response = await api<{
      researcher: { id: string; name: string; email: string };
      token: string;
      token_type: string;
      expires_in: number;
    }>(ctx, 'POST', '/api/auth/register', {
      body: { name: '张研究', email: 'Register1@Test.Local', password: 'Password123', affiliation: '某大学' },
    });

    assert.equal(response.status, 201);
    assert.ok(response.data.token.split('.').length === 3);
    assert.equal(response.data.token_type, 'Bearer');
    assert.equal(response.data.expires_in, 3600);
    assert.equal(response.data.researcher.name, '张研究');
  });

  test('邮箱统一转为小写存储', async () => {
    const response = await api<{ researcher: { email: string } }>(ctx, 'POST', '/api/auth/register', {
      body: { name: 'A', email: 'MixedCase@Test.Local', password: 'Password123' },
    });
    assert.equal(response.status, 201);
    assert.equal(response.data.researcher.email, 'mixedcase@test.local');
  });

  test('响应中绝不包含密码哈希等敏感字段', async () => {
    const response = await api<Record<string, unknown>>(ctx, 'POST', '/api/auth/register', {
      body: { name: 'B', email: 'nodata@test.local', password: 'Password123' },
    });
    const serialised = JSON.stringify(response.data);
    assert.ok(!serialised.includes('password'));
    assert.ok(!serialised.includes('scrypt$'));
    assert.ok(!('token_version' in (response.data.researcher as object)));
  });

  test('重复邮箱注册返回 409 冲突', async () => {
    await api(ctx, 'POST', '/api/auth/register', {
      body: { name: 'C', email: 'dup@test.local', password: 'Password123' },
    });
    const second = await api(ctx, 'POST', '/api/auth/register', {
      body: { name: 'D', email: 'DUP@test.local', password: 'Password123' },
    });
    assert.equal(second.status, 409);
    assert.equal(second.error?.code, 'CONFLICT');
  });

  test('校验失败返回 400 并附带逐字段错误', async () => {
    const response = await api<never>(ctx, 'POST', '/api/auth/register', {
      body: { name: '', email: 'not-an-email', password: '123' },
    });
    assert.equal(response.status, 400);
    assert.equal(response.error?.code, 'VALIDATION_ERROR');
    assert.ok(Array.isArray(response.error?.details));
    assert.ok((response.error?.details as unknown[]).length >= 3);
  });

  test('缺失请求体不会导致 500', async () => {
    const response = await api(ctx, 'POST', '/api/auth/register', { body: {} });
    assert.equal(response.status, 400);
  });
});

describe('登录', () => {
  test('正确凭据返回可用令牌', async () => {
    await api(ctx, 'POST', '/api/auth/register', {
      body: { name: 'Login', email: 'login@test.local', password: 'Password123' },
    });
    const response = await api<{ token: string; researcher: { email: string } }>(
      ctx,
      'POST',
      '/api/auth/login',
      { body: { email: 'login@test.local', password: 'Password123' } },
    );
    assert.equal(response.status, 200);
    assert.ok(response.data.token.length > 20);
  });

  test('邮箱大小写不影响登录', async () => {
    const response = await api(ctx, 'POST', '/api/auth/login', {
      body: { email: 'LOGIN@TEST.LOCAL', password: 'Password123' },
    });
    assert.equal(response.status, 200);
  });

  test('错误密码返回 401', async () => {
    const response = await api(ctx, 'POST', '/api/auth/login', {
      body: { email: 'login@test.local', password: 'WrongPassword1' },
    });
    assert.equal(response.status, 401);
    assert.equal(response.error?.code, 'UNAUTHORIZED');
  });

  test('不存在的账号与错误密码返回完全相同的提示（防账号枚举）', async () => {
    const unknown = await api(ctx, 'POST', '/api/auth/login', {
      body: { email: 'ghost@test.local', password: 'Password123' },
    });
    const wrongPassword = await api(ctx, 'POST', '/api/auth/login', {
      body: { email: 'login@test.local', password: 'WrongPassword1' },
    });
    assert.equal(unknown.status, wrongPassword.status);
    assert.equal(unknown.error?.message, wrongPassword.error?.message);
  });

  test('缺少字段返回 400', async () => {
    const response = await api(ctx, 'POST', '/api/auth/login', { body: { email: 'a@b.com' } });
    assert.equal(response.status, 400);
  });
});

describe('受保护资源与令牌校验', () => {
  test('无令牌访问返回 401', async () => {
    const response = await api(ctx, 'GET', '/api/auth/me');
    assert.equal(response.status, 401);
    assert.equal(response.error?.code, 'UNAUTHORIZED');
  });

  test('伪造令牌返回 401', async () => {
    const response = await api(ctx, 'GET', '/api/auth/me', { token: 'not.a.jwt' });
    assert.equal(response.status, 401);
  });

  test('有效令牌返回当前研究者', async () => {
    const researcher = await registerResearcher(ctx, { name: 'Me Test' });
    const response = await api<{ id: string; email: string }>(ctx, 'GET', '/api/auth/me', {
      token: researcher.token,
    });
    assert.equal(response.status, 200);
    assert.equal(response.data.id, researcher.id);
    assert.equal(response.data.email, researcher.email);
  });

  test('Authorization 头格式错误时返回 401', async () => {
    const researcher = await registerResearcher(ctx);
    const response = await api(ctx, 'GET', '/api/auth/me', {
      headers: { authorization: researcher.token },
    });
    assert.equal(response.status, 401);
  });
});

describe('退出登录与令牌撤销', () => {
  test('退出后原令牌立即失效', async () => {
    const researcher = await registerResearcher(ctx);

    const before = await api(ctx, 'GET', '/api/auth/me', { token: researcher.token });
    assert.equal(before.status, 200);

    const logout = await api<{ ok: boolean; token_version: number }>(ctx, 'POST', '/api/auth/logout', {
      token: researcher.token,
    });
    assert.equal(logout.status, 200);
    assert.equal(logout.data.ok, true);
    assert.equal(logout.data.token_version, 1);

    const after = await api(ctx, 'GET', '/api/auth/me', { token: researcher.token });
    assert.equal(after.status, 401, '注销后旧令牌必须失效');
  });

  test('退出后可以重新登录并获得新令牌', async () => {
    const researcher = await registerResearcher(ctx);
    await api(ctx, 'POST', '/api/auth/logout', { token: researcher.token });

    const relogin = await api<{ token: string }>(ctx, 'POST', '/api/auth/login', {
      body: { email: researcher.email, password: researcher.password },
    });
    assert.equal(relogin.status, 200);

    const me = await api(ctx, 'GET', '/api/auth/me', { token: relogin.data.token });
    assert.equal(me.status, 200);
  });

  test('撤销只影响该账号，不影响其他研究者的会话', async () => {
    const a = await registerResearcher(ctx);
    const b = await registerResearcher(ctx);

    await api(ctx, 'POST', '/api/auth/logout', { token: a.token });

    assert.equal((await api(ctx, 'GET', '/api/auth/me', { token: a.token })).status, 401);
    assert.equal((await api(ctx, 'GET', '/api/auth/me', { token: b.token })).status, 200);
  });
});

describe('未知接口', () => {
  test('返回结构化 404 而不是 HTML', async () => {
    const response = await api(ctx, 'GET', '/api/does-not-exist');
    assert.equal(response.status, 404);
    assert.equal(response.error?.code, 'NOT_FOUND');
  });
});

describe('审计日志', () => {
  test('注册、登录与退出都会写入审计记录', () => {
    const actions = ctx.db
      .all<{ action: string }>('SELECT action FROM audit_logs')
      .map((row) => row.action);
    assert.ok(actions.includes('researcher.register'));
    assert.ok(actions.includes('researcher.login'));
    assert.ok(actions.includes('researcher.logout'));
  });
});
