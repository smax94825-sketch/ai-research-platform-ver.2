/**
 * UI rendering tests.
 *
 * The components are mounted in a real DOM (jsdom) and driven through actual
 * events, so these assertions cover hooks, conditional rendering and handler
 * wiring — the parts a type checker cannot verify.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, before, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { stubFetch, jsonResponse, clearContainer, closeDom, configureApi, type FetchCall } from './dom';
import { click, flush, queryAll, render, submit, text, typeInto, unmount } from './render';

configureApi('http://127.0.0.1:4000');

// Components are imported after the DOM globals exist.
const { LoginPage } = await import('../src/pages/LoginPage');
const { RegisterPage } = await import('../src/pages/RegisterPage');
const { QuestionPreview } = await import('../src/components/QuestionPreview');
const { Layout } = await import('../src/components/Layout');
const { DistributionBarChart, QuotaProgressList } = await import('../src/components/DistributionChart');
const { AuthProvider } = await import('../src/lib/auth');
const formatModule = await import('../src/lib/format');
const apiModule = await import('../src/lib/api');

import type { Question } from '@ferp/shared';
import type { Distribution, QuotaProgress } from '../src/lib/api';

/* ------------------------------------------------------------------ */
/* Fixtures                                                           */
/* ------------------------------------------------------------------ */

function makeQuestion(overrides: Partial<Question>): Question {
  return {
    id: 'q-1',
    questionnaire_id: 'qn-1',
    question_code: 'Q1',
    question_text: '测试题干',
    question_type: 'single',
    options: {},
    required: true,
    dimension: null,
    variable_name: null,
    sort_order: 1,
    section: null,
    help_text: null,
    logic: null,
    scoring_rule: null,
    created_at: '2026-01-01T00:00:00.000Z',
    updated_at: '2026-01-01T00:00:00.000Z',
    ...overrides,
  };
}

beforeEach(async () => {
  await unmount();
  clearContainer();
  // The whole suite shares one process and one jsdom, so a token left behind by
  // another test file would make the login tests observe a bootstrap request
  // they did not stub.
  window.localStorage.clear();
});

after(async () => {
  await unmount();
  closeDom();
});

/* ================================================================== */
/* Format helpers                                                     */
/* ================================================================== */

describe('展示层格式化', () => {
  test('时长格式化：秒 → 分秒', () => {
    assert.equal(formatModule.formatDuration(444), '7分24秒');
    assert.equal(formatModule.formatDuration(45), '45秒');
  });

  test('缺失统计量显示为破折号，而不是伪造的 0', () => {
    assert.equal(formatModule.formatDuration(null), '—');
    assert.equal(formatModule.formatDuration(undefined), '—');
    assert.equal(formatModule.formatPercent(null), '—');
    assert.equal(formatModule.formatStat(null), '—');
  });

  test('百分比保留一位小数', () => {
    assert.equal(formatModule.formatPercent(91.34), '91.3%');
    assert.equal(formatModule.formatPercent(100), '100.0%');
  });

  test('题型与状态标签有中文映射', () => {
    assert.equal(formatModule.questionTypeLabel('likert'), '李克特量表');
    assert.equal(formatModule.questionTypeLabel('knowledge_test'), '知识测试题');
    assert.equal(formatModule.projectStatusMeta('collecting').label, '收集中');
    assert.equal(formatModule.questionnaireStatusMeta('published').label, '已发布');
  });

  test('长文本按字符截断并追加省略号', () => {
    assert.equal(formatModule.truncate('一二三四五六', 4), '一二三四…');
    assert.equal(formatModule.truncate('短', 10), '短');
  });
});

/* ================================================================== */
/* Login page                                                         */
/* ================================================================== */

describe('登录页', () => {
  test('渲染登录表单、标题与注册入口', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(LoginPage))),
    );

    const content = text();
    assert.match(content, /家庭教育科研智能研究平台/);
    assert.match(content, /研究者登录/);
    assert.match(content, /注册研究者账号/);

    assert.equal(queryAll('input[type="email"]').length, 1);
    assert.equal(queryAll('input[type="password"]').length, 1);
    assert.equal(queryAll('button[type="submit"]').length, 1);
  });

  test('表单字段标注为必填', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(LoginPage))),
    );
    const email = queryAll('input[type="email"]')[0]!;
    const password = queryAll('input[type="password"]')[0]!;
    assert.equal((email as HTMLInputElement).required, true);
    assert.equal((password as HTMLInputElement).required, true);
  });

  test('登录失败时展示服务端错误信息', async () => {
    const fetchStub = stubFetch(() =>
      jsonResponse({ error: { code: 'UNAUTHORIZED', message: '邮箱或密码不正确。', details: null } }, 401),
    );

    try {
      await render(
        createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(LoginPage))),
      );

      await typeInto(queryAll('input[type="email"]')[0]!, 'demo@ferp.local');
      await typeInto(queryAll('input[type="password"]')[0]!, 'WrongPassword1');

      const form = queryAll('form')[0]!;
      await submit(form);
      await flush();

      assert.match(text(), /邮箱或密码不正确/);
      assert.equal(fetchStub.calls.length, 1);
      assert.match(fetchStub.calls[0]!.url, /\/api\/auth\/login$/);
      assert.equal(fetchStub.calls[0]!.method, 'POST');
    } finally {
      fetchStub.restore();
    }
  });

  test('登录成功后写入令牌', async () => {
    const fetchStub = stubFetch((call: FetchCall) => {
      if (call.url.endsWith('/api/auth/login')) {
        return jsonResponse({
          data: {
            researcher: { id: 'r1', name: '示例研究者', email: 'demo@ferp.local', affiliation: null, created_at: '', updated_at: '' },
            token: 'header.payload.signature',
            token_type: 'Bearer',
            expires_in: 3600,
          },
        });
      }
      return jsonResponse({ data: null });
    });

    try {
      await render(
        createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(LoginPage))),
      );
      await typeInto(queryAll('input[type="email"]')[0]!, 'someone@example.test');
      await typeInto(queryAll('input[type="password"]')[0]!, 'FixturePass123');
      await submit(queryAll('form')[0]!);
      await flush();

      assert.equal(window.localStorage.getItem('ferp.token'), 'header.payload.signature');
      const body = fetchStub.calls[0]!.body as { email: string; password: string };
      assert.equal(body.email, 'someone@example.test');
    } finally {
      fetchStub.restore();
      window.localStorage.removeItem('ferp.token');
    }
  });
});

/* ================================================================== */
/* Register page                                                      */
/* ================================================================== */

describe('注册页', () => {
  test('实时提示密码强度要求', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(RegisterPage))),
    );

    const passwordInputs = queryAll('input[type="password"]');
    assert.equal(passwordInputs.length, 2, '应有密码与确认密码两个输入框');

    await typeInto(passwordInputs[0]!, 'abc');
    assert.match(text(), /密码长度至少为 8 个字符/);
    assert.match(text(), /密码需包含至少一个数字/);

    await typeInto(passwordInputs[0]!, 'Password123');
    assert.ok(!/密码长度至少为 8 个字符/.test(text()), '合规密码不应再提示长度不足');
    assert.ok(!/密码需包含至少一个数字/.test(text()), '合规密码不应再提示缺少数字');
  });

  test('两次密码不一致时禁用提交并给出提示', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(RegisterPage))),
    );
    const passwordInputs = queryAll('input[type="password"]');

    await typeInto(passwordInputs[0]!, 'Password123');
    await typeInto(passwordInputs[1]!, 'Password124');

    assert.match(text(), /两次输入的密码不一致/);
    const submitButton = queryAll('button[type="submit"]')[0] as HTMLButtonElement;
    assert.equal(submitButton.disabled, true);
  });
});

/* ================================================================== */
/* Question renderer                                                  */
/* ================================================================== */

describe('题目渲染（受访者视角）', () => {
  test('单选题渲染全部选项与题号', async () => {
    const question = makeQuestion({
      question_type: 'single',
      question_text: '您是否使用过家庭教育机构？',
      variable_name: 'FIUU',
      options: {
        choices: [
          { value: '1', label: '从未使用' },
          { value: '2', label: '使用过1—2次' },
        ],
      },
    });

    await render(createElement(QuestionPreview, { question, value: null, readOnly: true }));

    assert.match(text(), /Q1/);
    assert.match(text(), /从未使用/);
    assert.match(text(), /使用过1—2次/);
    assert.equal(queryAll('input[type="radio"]').length, 2);
    assert.equal(queryAll('input[type="checkbox"]').length, 0);
  });

  test('多选题渲染复选框，互斥选项带标注', async () => {
    const question = makeQuestion({
      question_type: 'multiple',
      options: {
        choices: [
          { value: '1', label: '社区家长学校' },
          { value: '7', label: '以上都不知道', exclusive: true },
        ],
      },
    });

    await render(createElement(QuestionPreview, { question, value: [], readOnly: true }));

    assert.equal(queryAll('input[type="checkbox"]').length, 2);
    assert.match(text(), /互斥选项/);
  });

  test('矩阵题渲染行列表格与行变量说明', async () => {
    const question = makeQuestion({
      question_type: 'matrix',
      question_code: 'Q35',
      variable_name: 'FED',
      question_text: '请评价困难程度：',
      options: {
        matrix: {
          rows: [
            { value: '1', label: '缺乏科学方法' },
            { value: '2', label: '没有足够时间' },
          ],
          columns: [
            { value: '1', label: '没有困难' },
            { value: '5', label: '困难非常大' },
          ],
        },
      },
    });

    await render(createElement(QuestionPreview, { question, value: {}, readOnly: true }));

    assert.equal(queryAll('table').length, 1);
    assert.equal(queryAll('tbody tr').length, 2);
    assert.equal(queryAll('input[type="radio"]').length, 4);
    assert.match(text(), /FED1/);
    assert.match(text(), /FED2/);
  });

  test('知识测试题说明计分规则', async () => {
    const question = makeQuestion({
      question_type: 'knowledge_test',
      question_code: 'Q12',
      options: {
        choices: [
          { value: '1', label: '正确', isCorrect: true },
          { value: '2', label: '错误' },
          { value: '3', label: '不清楚' },
        ],
      },
    });

    await render(createElement(QuestionPreview, { question, value: null, readOnly: true }));

    assert.match(text(), /知识测试题/);
    assert.match(text(), /不清楚/);
    assert.match(text(), /答错计 0 分/);
  });

  test('敏感题渲染匿名与拒答说明', async () => {
    const question = makeQuestion({
      question_type: 'single',
      question_code: 'Q32',
      required: false,
      question_text: '过去12个月内，您是否曾采取过身体上的惩罚？',
      options: {
        choices: [
          { value: '1', label: '从未' },
          { value: '5', label: '不愿回答', sensitiveNonResponse: true },
        ],
      },
    });

    await render(createElement(QuestionPreview, { question, value: null, readOnly: true }));

    assert.match(text(), /敏感题/);
    assert.match(text(), /单独编码为缺失/);
    assert.match(text(), /不愿回答/);
  });

  test('必答题显示星号；校验失败时给出提示', async () => {
    const question = makeQuestion({ required: true });
    await render(createElement(QuestionPreview, { question, value: null, readOnly: true, invalid: true }));
    assert.match(text(), /必答题/);
    assert.match(text(), /请先作答后/);
  });

  test('分页题渲染为章节标题块，不产生作答控件', async () => {
    const question = makeQuestion({
      question_type: 'page_break',
      question_text: '第五部分　家庭教育自我效能',
    });
    await render(createElement(QuestionPreview, { question, value: null, readOnly: true }));

    assert.match(text(), /第五部分/);
    assert.equal(queryAll('input').length, 0);
  });

  test('点击选项会回传作答值', async () => {
    const received: unknown[] = [];
    const question = makeQuestion({
      question_type: 'likert',
      options: {
        choices: [
          { value: '1', label: '非常不同意' },
          { value: '5', label: '非常同意' },
        ],
      },
    });

    await render(
      createElement(QuestionPreview, {
        question,
        value: null,
        onChange: (value: unknown) => received.push(value),
      }),
    );

    const buttons = queryAll('button');
    assert.equal(buttons.length, 2);
    await click(buttons[1]!);
    assert.deepEqual(received, ['5']);
  });

  test('下拉题渲染 select 与占位选项', async () => {
    const question = makeQuestion({
      question_type: 'dropdown',
      options: { choices: [{ value: '1', label: '省会城市' }] },
    });
    await render(createElement(QuestionPreview, { question, value: null, readOnly: true }));
    assert.equal(queryAll('select').length, 1);
    assert.match(text(), /请选择/);
  });

  test('多行文本题渲染 textarea 并携带长度限制', async () => {
    const question = makeQuestion({
      question_type: 'textarea',
      options: { maxLength: 500, placeholder: '请简要描述' },
    });
    await render(createElement(QuestionPreview, { question, value: null, readOnly: true }));
    const textarea = queryAll('textarea')[0] as HTMLTextAreaElement;
    assert.ok(textarea);
    assert.equal(textarea.maxLength, 500);
  });
});

/* ================================================================== */
/* Layout navigation                                                  */
/* ================================================================== */

describe('后台导航', () => {
  test('渲染规范要求的分组与菜单项', async () => {
    await render(
      createElement(
        MemoryRouter,
        null,
        createElement(AuthProvider, null, createElement(Layout)),
      ),
    );
    await flush();

    const content = text();
    for (const label of [
      'Dashboard',
      'Research Projects',
      'Builder',
      'Logic',
      'Preview',
      'Publish',
      'Responses',
      'Quality',
      'Regression',
      'Hypothesis Testing',
      'AI Research Assistant',
      'Insights',
      'Reports',
      'Export',
      'Settings',
    ]) {
      assert.ok(content.includes(label), `导航缺少 ${label}`);
    }
  });

  test('未实现的功能标注所属阶段而不是伪装成可用', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(Layout))),
    );
    await flush();

    const content = text();
    // PHASE 7/8/9 shipped, so no sidebar entry may still advertise a phase tag or
    // claim to be unavailable.
    assert.ok(!/PHASE \d/.test(content), '已实现的功能不应再显示阶段标签');
    assert.ok(!content.includes('该功能将在'), '不应再有指向未来阶段的提示');
    assert.ok(!content.includes('PHASE 3'), 'PHASE 3 已实现，不应再显示阶段标签');
    assert.ok(!content.includes('PHASE 4'), 'PHASE 4 已实现，不应再显示阶段标签');
    assert.ok(!content.includes('PHASE 6'), 'PHASE 6 已实现，不应再显示阶段标签');
  });

  test('统计分析相关菜单项（PHASE 6）已是真实链接', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(Layout))),
    );
    await flush();

    const hrefs = queryAll('a').map((element) => element.getAttribute('href'));
    for (const href of [
      '/analysis',
      '/analysis/descriptive',
      '/analysis/reliability',
      '/analysis/validity',
      '/analysis/correlation',
      '/analysis/regression',
      '/analysis/comparison',
      '/analysis/hypotheses',
    ]) {
      assert.ok(hrefs.includes(href), `${href} 应为真实链接`);
    }
  });

  test('数据收集相关菜单项（PHASE 3/4）已是真实链接', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(Layout))),
    );
    await flush();

    const hrefs = queryAll('a').map((element) => element.getAttribute('href'));
    assert.ok(hrefs.includes('/collection/responses'), 'Responses 应为真实链接');
    assert.ok(hrefs.includes('/collection/samples'), 'Samples 应为真实链接');
    assert.ok(hrefs.includes('/collection/sources'), 'Sources 应为真实链接');
    assert.ok(hrefs.includes('/collection/quality'), 'Quality 应为真实链接');
  });

  test('智能分析相关菜单项（PHASE 7/8/9）已是真实链接', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(Layout))),
    );
    await flush();

    const links = queryAll('a').map((element) => ({
      label: element.textContent ?? '',
      href: element.getAttribute('href'),
    }));
    const expected: { label: string; href: string }[] = [
      { label: 'AI Research Assistant', href: '/ai' },
      { label: 'Insights', href: '/competition' },
      { label: 'Reports', href: '/report' },
      { label: 'Export', href: '/export' },
    ];
    for (const item of expected) {
      const link = links.find((candidate) => candidate.label.includes(item.label));
      assert.ok(link, `${item.label} 应为真实链接`);
      assert.equal(link!.href, item.href, `${item.label} 应指向 ${item.href}`);
    }
  });

  test('已实现的功能是真实链接', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(Layout))),
    );
    await flush();

    const hrefs = queryAll('a').map((element) => element.getAttribute('href'));
    assert.ok(hrefs.includes('/'));
    assert.ok(hrefs.includes('/projects'));
    assert.ok(hrefs.includes('/builder'));
    assert.ok(hrefs.includes('/settings'));
  });

  test('页脚声明数据真实性原则', async () => {
    await render(
      createElement(MemoryRouter, null, createElement(AuthProvider, null, createElement(Layout))),
    );
    await flush();
    assert.match(text(), /所有统计结果均来自数据库真实数据/);
  });
});

/* ================================================================== */
/* Chart components                                                   */
/* ================================================================== */

function makeDistribution(overrides: Partial<Distribution>): Distribution {
  return {
    variable_name: 'UI',
    question_code: 'Q50',
    label: '我愿意使用AI辅助的家庭教育服务。',
    question_type: 'likert',
    kind: 'scale',
    base_n: 4,
    n: 4,
    counts: [
      { value: '4', label: '比较同意', count: 3, percent: 75 },
      { value: '5', label: '非常同意', count: 1, percent: 25 },
    ],
    mean: 4.25,
    sd: 0.5,
    median: 4,
    missing: 0,
    sensitive_nonresponse: 0,
    ...overrides,
  };
}

describe('分布图组件', () => {
  test('条形图渲染类别、人数与百分比', async () => {
    await render(createElement(DistributionBarChart, { distribution: makeDistribution({}) }));
    const content = text();
    assert.match(content, /比较同意/);
    assert.match(content, /3 人 · 75.0%/);
    assert.match(content, /非常同意/);
  });

  test('无有效作答时明确说明，而不是画空图', async () => {
    await render(
      createElement(DistributionBarChart, {
        distribution: makeDistribution({ n: 0, counts: [], missing: 3, sensitive_nonresponse: 1 }),
      }),
    );
    assert.match(text(), /暂无有效作答/);
    assert.match(text(), /缺失 3/);
    assert.match(text(), /敏感拒答 1/);
  });

  test('敏感拒答会在完整性说明中单独标出', async () => {
    const { DataCompletenessNote } = await import('../src/components/DistributionChart');
    await render(
      createElement(DataCompletenessNote, {
        distribution: makeDistribution({ n: 3, base_n: 4, sensitive_nonresponse: 1, missing: 0 }),
      }),
    );
    const content = text();
    assert.match(content, /敏感拒答 1/);
    assert.match(content, /未并入任何类别/);
  });

  test('配额进度渲染目标、当前值与掌握情况', async () => {
    const progress: QuotaProgress[] = [
      { dimension: 'STAGE', category: '小学', target_n: 300, current_n: 318, percent: 106, met: true },
      { dimension: 'STAGE', category: '初中', target_n: 300, current_n: 189, percent: 63, met: false },
    ];
    await render(createElement(QuotaProgressList, { progress }));

    const content = text();
    assert.match(content, /小学/);
    assert.match(content, /318\/300/);
    assert.match(content, /初中/);
    assert.match(content, /189\/300/);
  });

  test('无配额时不渲染任何内容', async () => {
    await render(createElement(QuotaProgressList, { progress: [] }));
    assert.equal(text().trim(), '');
  });
});

/* ================================================================== */
/* API client                                                         */
/* ================================================================== */

describe('API 客户端', () => {
  test('登录请求不携带 Authorization 头', async () => {
    const fetchStub = stubFetch(() => jsonResponse({ data: {} }));
    try {
      await apiModule.api.auth.login({ email: 'a@b.com', password: 'Password123' });
      assert.equal(fetchStub.calls[0]!.headers['authorization'], undefined);
      assert.equal(fetchStub.calls[0]!.headers['content-type'], 'application/json');
    } finally {
      fetchStub.restore();
    }
  });

  test('已登录时自动附带 Bearer 令牌', async () => {
    window.localStorage.setItem('ferp.token', 'token-abc');
    const fetchStub = stubFetch(() => jsonResponse({ data: { items: [], total: 0, limit: 50, offset: 0 } }));
    try {
      await apiModule.api.projects.list();
      assert.equal(fetchStub.calls[0]!.headers['authorization'], 'Bearer token-abc');
    } finally {
      fetchStub.restore();
      window.localStorage.removeItem('ferp.token');
    }
  });

  test('查询参数被正确序列化，空值被忽略', async () => {
    const fetchStub = stubFetch(() => jsonResponse({ data: { items: [], total: 0, limit: 50, offset: 0 } }));
    try {
      await apiModule.api.projects.list({ search: '家庭教育', limit: 10 });
      const url = new URL(fetchStub.calls[0]!.url);
      assert.equal(url.searchParams.get('search'), '家庭教育');
      assert.equal(url.searchParams.get('limit'), '10');
      assert.equal(url.searchParams.get('status'), null);
    } finally {
      fetchStub.restore();
    }
  });

  test('服务端错误被转换为带 code 与字段明细的异常', async () => {
    const fetchStub = stubFetch(() =>
      jsonResponse(
        {
          error: {
            code: 'VALIDATION_ERROR',
            message: '题目定义校验失败，共 1 处问题。',
            details: [{ field: 'question_code', message: '题号不能为空。' }],
          },
        },
        400,
      ),
    );
    try {
      await assert.rejects(
        () => apiModule.api.projects.list(),
        (error: unknown) => {
          assert.ok(error instanceof apiModule.ApiClientError);
          const apiError = error as InstanceType<typeof apiModule.ApiClientError>;
          assert.equal(apiError.status, 400);
          assert.equal(apiError.code, 'VALIDATION_ERROR');
          assert.deepEqual(apiError.fieldErrors, [{ field: 'question_code', message: '题号不能为空。' }]);
          return true;
        },
      );
    } finally {
      fetchStub.restore();
    }
  });

  test('401 会清除本地令牌（避免无限重试）', async () => {
    window.localStorage.setItem('ferp.token', 'expired-token');
    const fetchStub = stubFetch(() =>
      jsonResponse({ error: { code: 'UNAUTHORIZED', message: '登录状态无效。', details: null } }, 401),
    );
    try {
      await assert.rejects(() => apiModule.api.auth.me());
      assert.equal(window.localStorage.getItem('ferp.token'), null);
    } finally {
      fetchStub.restore();
    }
  });
});
