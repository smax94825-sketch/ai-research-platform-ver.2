/**
 * Row <-> domain mappers.
 *
 * The database stores JSON payloads as TEXT and booleans as INTEGER, so all
 * shape conversion is centralised here. Every read path goes through a mapper,
 * which guarantees the API never leaks `password_hash` or raw JSON strings.
 */

import type {
  Hypothesis,
  ProjectSettings,
  ProjectStatus,
  Question,
  QuestionLogic,
  Questionnaire,
  QuestionnaireStatus,
  ResearchProject,
  Researcher,
  ScoringRule,
  QuestionOptions,
  QuestionType,
  QuotaConfig,
} from '@ferp/shared';
import { normalizeLogic } from '@ferp/shared';

/* ------------------------------------------------------------------ */
/* JSON helpers                                                       */
/* ------------------------------------------------------------------ */

export function parseJson<T>(value: unknown, fallback: T): T {
  if (value === null || value === undefined) return fallback;
  if (typeof value !== 'string') return fallback;
  const trimmed = value.trim();
  if (trimmed === '') return fallback;
  try {
    return JSON.parse(trimmed) as T;
  } catch {
    // Corrupt JSON must not crash a whole listing endpoint.
    return fallback;
  }
}

export function toJson(value: unknown): string | null {
  if (value === undefined || value === null) return null;
  return JSON.stringify(value);
}

function toBool(value: unknown): boolean {
  return value === 1 || value === true || value === '1';
}

/* ------------------------------------------------------------------ */
/* Researchers                                                        */
/* ------------------------------------------------------------------ */

export interface ResearcherRow {
  id: string;
  name: string;
  email: string;
  password_hash: string;
  affiliation: string | null;
  role: string;
  token_version: number;
  created_at: string;
  updated_at: string;
}

/** Public projection — deliberately excludes password_hash and token_version. */
export function toResearcher(row: ResearcherRow): Researcher {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    affiliation: row.affiliation,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

/** Row shape of `respondents`, including the PHASE 3 session columns. */
export interface RespondentRow {
  id: string;
  questionnaire_id: string;
  project_id: string;
  anonymous_id: string;
  source: string;
  started_at: string;
  completed_at: string | null;
  duration_seconds: number | null;
  status: string;
  quality_score: number | null;
  ip_hash: string | null;
  user_agent: string | null;
  created_at: string;
  session_token: string | null;
  consent_given_at: string | null;
  current_question_code: string | null;
  answered_count: number | null;
  last_activity_at: string | null;
  completed_via: string | null;
  review_status: string | null;
  review_note: string | null;
  reviewed_at: string | null;
  reviewed_by: string | null;
  /* PHASE 4 — data quality engine */
  quality_severity: string | null;
  quality_computed_at: string | null;
  quality_engine_version: string | null;
  answer_signature: string | null;
}

/* ------------------------------------------------------------------ */
/* Projects                                                           */
/* ------------------------------------------------------------------ */

export interface ProjectRow {
  id: string;
  researcher_id: string;
  title: string;
  description: string | null;
  background: string | null;
  objectives: string | null;
  research_questions: string | null;
  hypotheses: string | null;
  target_population: string | null;
  target_sample_size: number | null;
  start_date: string | null;
  end_date: string | null;
  status: string;
  quota_config: string | null;
  settings: string | null;
  created_at: string;
  updated_at: string;
}

export function toProject(row: ProjectRow): ResearchProject {
  return {
    id: row.id,
    researcher_id: row.researcher_id,
    title: row.title,
    description: row.description,
    background: row.background,
    objectives: row.objectives,
    research_questions: parseJson<string[]>(row.research_questions, []),
    hypotheses: parseJson<Hypothesis[]>(row.hypotheses, []),
    target_population: row.target_population,
    target_sample_size: row.target_sample_size,
    start_date: row.start_date,
    end_date: row.end_date,
    status: row.status as ProjectStatus,
    quota_config: parseJson<QuotaConfig | null>(row.quota_config, null),
    settings: parseJson<ProjectSettings | null>(row.settings, null),
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

/* ------------------------------------------------------------------ */
/* Questionnaires                                                     */
/* ------------------------------------------------------------------ */

export interface QuestionnaireRow {
  id: string;
  project_id: string;
  title: string;
  description: string | null;
  version: string;
  status: string;
  share_token: string | null;
  is_current: number;
  locked: number;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export function toQuestionnaire(row: QuestionnaireRow): Questionnaire {
  return {
    id: row.id,
    project_id: row.project_id,
    title: row.title,
    description: row.description,
    version: row.version,
    status: row.status as QuestionnaireStatus,
    share_token: row.share_token,
    is_current: toBool(row.is_current),
    locked: toBool(row.locked),
    published_at: row.published_at,
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}

/* ------------------------------------------------------------------ */
/* Questions                                                          */
/* ------------------------------------------------------------------ */

export interface QuestionRow {
  id: string;
  questionnaire_id: string;
  question_code: string;
  question_text: string;
  question_type: string;
  options: string | null;
  required: number;
  dimension: string | null;
  variable_name: string | null;
  sort_order: number;
  section: string | null;
  help_text: string | null;
  logic: string | null;
  scoring_rule: string | null;
  created_at: string;
  updated_at: string;
}

export function toQuestion(row: QuestionRow): Question {
  return {
    id: row.id,
    questionnaire_id: row.questionnaire_id,
    question_code: row.question_code,
    question_text: row.question_text,
    question_type: row.question_type as QuestionType,
    options: parseJson<QuestionOptions>(row.options, {}),
    required: toBool(row.required),
    dimension: row.dimension,
    variable_name: row.variable_name,
    sort_order: row.sort_order,
    section: row.section,
    help_text: row.help_text,
    logic: row.logic ? normalizeLogic(parseJson<QuestionLogic>(row.logic, { rules: [] })) : null,
    scoring_rule: parseJson<ScoringRule | null>(row.scoring_rule, null),
    created_at: row.created_at,
    updated_at: row.updated_at,
  };
}
