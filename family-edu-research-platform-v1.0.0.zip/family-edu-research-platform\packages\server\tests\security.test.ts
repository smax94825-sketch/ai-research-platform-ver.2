/**
 * Password hashing and JWT tests.
 *
 * These are the security boundary of the platform: a flaw here would expose
 * every researcher account, so the negative cases (tampering, algorithm
 * substitution, expiry) are covered as thoroughly as the happy path.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';

import {
  hashPassword,
  validatePasswordStrength,
  verifyPassword,
} from '../src/security/password.js';
import { decodeJwtUnsafe, signJwt, verifyJwt } from '../src/security/jwt.js';

const SECRET = 'unit-test-secret-value-0123456789';

/* ------------------------------------------------------------------ */
/* Password hashing                                                   */
/* ------------------------------------------------------------------ */

describe('密码哈希（scrypt）', () => {
  test('哈希结果包含算法与参数，且不含明文密码', () => {
    const hash = hashPassword('Password123');
    const parts = hash.split('$');
    assert.equal(parts.length, 6);
    assert.equal(parts[0], 'scrypt');
    assert.ok(Number(parts[1]) >= 16384, 'N 参数偏小，强度不足');
    assert.ok(!hash.includes('Password123'));
  });

  test('同一密码两次哈希结果不同（随机盐）', () => {
    const a = hashPassword('Password123');
    const b = hashPassword('Password123');
    assert.notEqual(a, b);
  });

  test('正确密码校验通过', () => {
    const hash = hashPassword('Password123');
    assert.equal(verifyPassword('Password123', hash).ok, true);
  });

  test('错误密码校验失败', () => {
    const hash = hashPassword('Password123');
    assert.equal(verifyPassword('Password124', hash).ok, false);
    assert.equal(verifyPassword('', hash).ok, false);
    assert.equal(verifyPassword('password123', hash).ok, false, '大小写必须敏感');
  });

  test('Unicode 密码在校验前做 NFKC 规范化，兼容不同输入法', () => {
    const hash = hashPassword('密码ＡＢＣ123');
    assert.equal(verifyPassword('密码ＡＢＣ123', hash).ok, true);
  });

  test('当前参数下不需要重新哈希', () => {
    const hash = hashPassword('Password123');
    assert.equal(verifyPassword('Password123', hash).needsRehash, false);
  });

  test('弱参数哈希在校验成功时标记为需要升级', () => {
    const weak = hashPassword('Password123', { N: 1024, r: 8, p: 1 });
    const result = verifyPassword('Password123', weak);
    assert.equal(result.ok, true);
    assert.equal(result.needsRehash, true);
  });

  test('篡改格式的哈希一律校验失败且不抛错', () => {
    for (const bad of [
      '',
      'plaintext',
      'scrypt$16384$8$1$onlyfive',
      'bcrypt$10$abc$def$ghi$jkl',
      'scrypt$0$8$1$c2FsdA==$aGFzaA==',
      'scrypt$abc$8$1$c2FsdA==$aGFzaA==',
      'scrypt$32768$8$1$$',
      'scrypt$999999999$8$1$c2FsdA==$aGFzaA==',
    ]) {
      const result = verifyPassword('Password123', bad);
      assert.equal(result.ok, false, `应拒绝非法哈希: ${bad}`);
      assert.equal(result.needsRehash, false);
    }
  });

  test('同一盐与密码产生确定性哈希（可复现验证）', () => {
    const hash = hashPassword('Password123');
    assert.equal(verifyPassword('Password123', hash).ok, true);
    assert.equal(verifyPassword('Password123', hash).ok, true);
  });
});

describe('密码强度策略', () => {
  test('接受符合策略的密码', () => {
    assert.equal(validatePasswordStrength('FixturePass123').valid, true);
  });

  test('拒绝过短密码', () => {
    const result = validatePasswordStrength('Ab1');
    assert.equal(result.valid, false);
    assert.ok(result.errors.some((e) => e.includes('8')));
  });

  test('拒绝纯数字或纯字母密码', () => {
    assert.equal(validatePasswordStrength('12345678').valid, false);
    assert.equal(validatePasswordStrength('abcdefgh').valid, false);
  });

  test('拒绝非字符串输入', () => {
    assert.equal(validatePasswordStrength(undefined).valid, false);
    assert.equal(validatePasswordStrength(12345678).valid, false);
  });

  test('拒绝超长密码（防止 DoS）', () => {
    assert.equal(validatePasswordStrength('A1' + 'x'.repeat(300)).valid, false);
  });
});

/* ------------------------------------------------------------------ */
/* JWT                                                                */
/* ------------------------------------------------------------------ */

describe('JWT 签发与校验', () => {
  test('签发后可校验，且声明完整', () => {
    const token = signJwt({ sub: 'researcher-1', tv: 0, email: 'a@b.com' }, SECRET, 3600);
    const result = verifyJwt(token, SECRET);
    assert.equal(result.valid, true);
    if (!result.valid) return;
    assert.equal(result.payload.sub, 'researcher-1');
    assert.equal(result.payload.tv, 0);
    assert.equal(result.payload.email, 'a@b.com');
    assert.equal(typeof result.payload.iat, 'number');
    assert.equal(result.payload.exp - result.payload.iat, 3600);
  });

  test('令牌为三段式，且头部固定为 HS256', () => {
    const token = signJwt({ sub: 'r1', tv: 0 }, SECRET, 3600);
    const segments = token.split('.');
    assert.equal(segments.length, 3);
    const header = JSON.parse(Buffer.from(segments[0]!, 'base64url').toString('utf8')) as {
      alg: string;
      typ: string;
    };
    assert.deepEqual(header, { alg: 'HS256', typ: 'JWT' });
  });

  test('使用错误密钥校验失败', () => {
    const token = signJwt({ sub: 'r1', tv: 0 }, SECRET, 3600);
    const result = verifyJwt(token, 'a-completely-different-secret-value');
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.equal(result.error, 'bad_signature');
  });

  test('篡改载荷会导致签名校验失败', () => {
    const token = signJwt({ sub: 'r1', tv: 0 }, SECRET, 3600);
    const [header, , signature] = token.split('.');
    const forgedPayload = Buffer.from(
      JSON.stringify({ sub: 'victim', tv: 0, iat: 1, exp: 9999999999 }),
    ).toString('base64url');
    const forged = `${header}.${forgedPayload}.${signature}`;
    const result = verifyJwt(forged, SECRET);
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.equal(result.error, 'bad_signature');
  });

  test('拒绝 alg:none 的令牌（算法混淆攻击）', () => {
    const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
    const payload = Buffer.from(
      JSON.stringify({ sub: 'attacker', tv: 0, iat: 1, exp: 9999999999 }),
    ).toString('base64url');
    const result = verifyJwt(`${header}.${payload}.`, SECRET);
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.ok(result.error === 'bad_algorithm' || result.error === 'malformed');
  });

  test('拒绝把算法改为 HS512 的令牌', () => {
    const header = Buffer.from(JSON.stringify({ alg: 'HS512', typ: 'JWT' })).toString('base64url');
    const payload = Buffer.from(
      JSON.stringify({ sub: 'attacker', tv: 0, iat: 1, exp: 9999999999 }),
    ).toString('base64url');
    const signature = createHmac('sha512', SECRET)
      .update(`${header}.${payload}`)
      .digest('base64url');
    const result = verifyJwt(`${header}.${payload}.${signature}`, SECRET);
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.equal(result.error, 'bad_algorithm');
  });

  test('过期令牌被拒绝', () => {
    const token = signJwt({ sub: 'r1', tv: 0 }, SECRET, -10);
    const result = verifyJwt(token, SECRET);
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.equal(result.error, 'expired');
  });

  test('尚未生效的令牌被拒绝', () => {
    const future = Math.floor(Date.now() / 1000) + 3600;
    const token = signJwt({ sub: 'r1', tv: 0, iat: future }, SECRET, 7200);
    const result = verifyJwt(token, SECRET);
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.equal(result.error, 'not_yet_valid');
  });

  test('允许 60 秒内的时钟偏移', () => {
    const slightlyFuture = Math.floor(Date.now() / 1000) + 30;
    const token = signJwt({ sub: 'r1', tv: 0, iat: slightlyFuture }, SECRET, 3600);
    assert.equal(verifyJwt(token, SECRET).valid, true);
  });

  test('拒绝格式错误的令牌', () => {
    for (const bad of ['', 'abc', 'a.b', 'a.b.c.d', '!!!.@@@.###']) {
      const result = verifyJwt(bad, SECRET);
      assert.equal(result.valid, false, `应拒绝: ${bad}`);
    }
  });

  test('缺少 sub 的载荷被拒绝', () => {
    const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
    const payload = Buffer.from(JSON.stringify({ tv: 0, iat: 1, exp: 9999999999 })).toString(
      'base64url',
    );
    const signature = createHmac('sha256', SECRET)
      .update(`${header}.${payload}`)
      .digest('base64url');
    const result = verifyJwt(`${header}.${payload}.${signature}`, SECRET);
    assert.equal(result.valid, false);
    if (result.valid) return;
    assert.equal(result.error, 'malformed');
  });

  test('空密钥拒绝签发', () => {
    assert.throws(() => signJwt({ sub: 'r1', tv: 0 }, '', 3600), /must not be empty/);
  });

  test('decodeJwtUnsafe 可读取声明但不做校验', () => {
    const token = signJwt({ sub: 'r1', tv: 3 }, SECRET, 3600);
    const payload = decodeJwtUnsafe(token);
    assert.equal(payload?.sub, 'r1');
    assert.equal(payload?.tv, 3);
  });

  test('token_version 声明可携带用于撤销校验', () => {
    const token = signJwt({ sub: 'r1', tv: 7 }, SECRET, 3600);
    const result = verifyJwt(token, SECRET);
    assert.equal(result.valid, true);
    if (!result.valid) return;
    assert.equal(result.payload.tv, 7);
  });
});
