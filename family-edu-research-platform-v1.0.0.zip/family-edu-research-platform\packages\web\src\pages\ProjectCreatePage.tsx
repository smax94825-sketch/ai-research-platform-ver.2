import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Alert, Button, Card, CardHeader, Field, Input, Textarea } from '../components/ui';
import { api, ApiClientError, type TemplateSummary } from '../lib/api';

type Mode = 'template' | 'blank';

export function ProjectCreatePage(): ReactNode {
  const navigate = useNavigate();

  const [mode, setMode] = useState<Mode>('template');
  const [template, setTemplate] = useState<TemplateSummary | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [background, setBackground] = useState('');
  const [objectives, setObjectives] = useState('');
  const [population, setPopulation] = useState('');
  const [sampleSize, setSampleSize] = useState('1000');
  const [questionsText, setQuestionsText] = useState('');
  const [hypothesesText, setHypothesesText] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Load the available template so the "use template" card shows real numbers.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const templates = await api.templates.list();
        if (cancelled) return;
        const first = templates[0] ?? null;
        setTemplate(first);
        if (first) {
          setTitle(first.default_project.title);
          setDescription(first.default_project.description);
          setPopulation(first.default_project.target_population);
          setSampleSize(String(first.default_project.target_sample_size));
          setQuestionsText(
            Array.from({ length: first.default_project.research_question_count }, (_, i) => `研究问题 ${i + 1}`).join('\n'),
          );
          setHypothesesText(
            Array.from({ length: first.default_project.hypothesis_count }, (_, i) => `H${i + 1} 待检验假设`).join('\n'),
          );
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiClientError ? err.message : '无法加载研究模板。');
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  function switchMode(next: Mode): void {
    setMode(next);
    setError(null);
    if (next === 'blank') {
      setTitle('');
      setDescription('');
      setBackground('');
      setObjectives('');
      setPopulation('');
      setQuestionsText('');
      setHypothesesText('');
      setSampleSize('300');
    } else if (template) {
      setTitle(template.default_project.title);
      setDescription(template.default_project.description);
      setPopulation(template.default_project.target_population);
      setSampleSize(String(template.default_project.target_sample_size));
      setQuestionsText(
        Array.from({ length: template.default_project.research_question_count }, (_, i) => `研究问题 ${i + 1}`).join('\n'),
      );
      setHypothesesText(
        Array.from({ length: template.default_project.hypothesis_count }, (_, i) => `H${i + 1} 待检验假设`).join('\n'),
      );
    }
  }

  async function handleSubmit(event: FormEvent): Promise<void> {
    event.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const researchQuestions = questionsText
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line.length > 0);

      const hypotheses = hypothesesText
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line.length > 0)
        .map((line, index) => {
          const match = /^(H\d+)\s+(.*)$/.exec(line);
          return {
            code: match?.[1] ?? `H${index + 1}`,
            statement: match?.[2]?.trim() || line,
            status: 'untested' as const,
          };
        });

      const result = await api.projects.create({
        title: title.trim(),
        description: description.trim() || null,
        background: background.trim() || null,
        objectives: objectives.trim() || null,
        research_questions: researchQuestions,
        hypotheses,
        target_population: population.trim() || null,
        target_sample_size: Number(sampleSize) || null,
        start_date: startDate || null,
        end_date: endDate || null,
        template: mode === 'template' ? (template?.key ?? null) : null,
      });

      navigate(`/projects/${result.project.id}`, { replace: true });
    } catch (err) {
      if (err instanceof ApiClientError) {
        const fieldErrors = err.fieldErrors;
        setError(
          fieldErrors.length > 0
            ? `${err.message} ${fieldErrors.map((item) => item.message).join(' ')}`
            : err.message,
        );
      } else {
        setError('创建研究项目失败，请稍后重试。');
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <Link to="/projects" className="text-sm text-ink-500 hover:text-ink-800">
          ← 返回项目列表
        </Link>
        <h1 className="mt-2 text-xl font-semibold text-ink-900">新建研究项目</h1>
        <p className="mt-1 text-sm text-ink-500">
          填写研究设计信息。研究问题与假设将以"待检验"状态保存——平台不会预设任何研究结论。
        </p>
      </div>

      {/* Mode selector -------------------------------------------------- */}
      <div className="grid gap-4 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => switchMode('template')}
          className={`rounded-lg border p-4 text-left transition-colors ${
            mode === 'template'
              ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500'
              : 'border-ink-200 bg-white hover:border-ink-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-ink-900">使用研究模板</p>
            {mode === 'template' && <span className="text-xs font-medium text-brand-700">已选择</span>}
          </div>
          <p className="mt-2 text-sm text-ink-600">
            {template
              ? `「${template.title} ${template.version}」——自动载入 ${template.question_count} 道题目、${template.section_count} 个部分、完整研究设计与 H1—H8 假设。`
              : '正在读取模板…'}
          </p>
        </button>

        <button
          type="button"
          onClick={() => switchMode('blank')}
          className={`rounded-lg border p-4 text-left transition-colors ${
            mode === 'blank'
              ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500'
              : 'border-ink-200 bg-white hover:border-ink-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-ink-900">新建空白项目</p>
            {mode === 'blank' && <span className="text-xs font-medium text-brand-700">已选择</span>}
          </div>
          <p className="mt-2 text-sm text-ink-600">
            从零开始设计问卷，适用于其他研究主题或自建量表。
          </p>
        </button>
      </div>

      {error && (
        <Alert tone="danger" title="创建失败">
          {error}
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        <Card>
          <CardHeader title="研究基本信息" />
          <div className="space-y-4">
            <Field label="研究名称" required>
              <Input
                required
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="例如：家庭教育认知、实践与社会支持需求研究"
              />
            </Field>

            <Field label="研究背景">
              <Textarea
                rows={3}
                value={background}
                onChange={(event) => setBackground(event.target.value)}
                placeholder="说明研究缘起、政策背景与已有研究的不足。"
              />
            </Field>

            <Field label="研究目的">
              <Textarea
                rows={3}
                value={objectives}
                onChange={(event) => setObjectives(event.target.value)}
                placeholder="列出本研究要达成的目标。"
              />
            </Field>

            <Field label="研究对象">
              <Input
                value={population}
                onChange={(event) => setPopulation(event.target.value)}
                placeholder="例如：育有学前至高中阶段子女、且主要承担家庭教育责任的家长或监护人。"
              />
            </Field>

            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="目标样本量" hint="正整数；低于 30 时统计效力可能不足。">
                <Input
                  type="number"
                  min={1}
                  max={100000}
                  value={sampleSize}
                  onChange={(event) => setSampleSize(event.target.value)}
                />
              </Field>
              <Field label="调查开始时间">
                <Input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} />
              </Field>
              <Field label="调查结束时间">
                <Input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} />
              </Field>
            </div>
          </div>
        </Card>

        <Card>
          <CardHeader
            title="研究问题与研究假设"
            description="每行一条。假设将以「待检验」状态保存，只有在统计引擎完成检验后才会被标注为支持或不支持。"
          />
          <div className="grid gap-4 lg:grid-cols-2">
            <Field label="研究问题（每行一条）">
              <Textarea
                rows={8}
                value={questionsText}
                onChange={(event) => setQuestionsText(event.target.value)}
                placeholder={'家长的家庭教育认知水平如何？\n政府公共服务的知晓度如何？'}
              />
            </Field>
            <Field label="研究假设（每行一条，可写为「H1 假设内容」）">
              <Textarea
                rows={8}
                value={hypothesesText}
                onChange={(event) => setHypothesesText(event.target.value)}
                placeholder={'H1 家庭教育知识水平与自我效能呈正向关系。'}
              />
            </Field>
          </div>
        </Card>

        <Card>
          <CardHeader title="数据采集与伦理" />
          <ul className="space-y-1.5 text-sm text-ink-600">
            <li>· 平台默认采用匿名调查，不收集姓名、身份证号、精确住址、学校名称与手机号。</li>
            <li>· 受访者可以拒绝回答任何问题，敏感题的"不愿回答"将单独编码为缺失，不会并入任何类别。</li>
            <li>· 系统不会自动删除任何样本，只会标记可疑数据并交由研究者判断。</li>
            <li>· 问卷一旦发布即锁定，后续修改需建立新版本，以保证作答数据与题目版本严格对应。</li>
          </ul>
        </Card>

        <div className="flex items-center justify-end gap-3">
          <Link to="/projects">
            <Button>取消</Button>
          </Link>
          <Button type="submit" variant="primary" loading={submitting}>
            {mode === 'template' ? '创建项目并载入 58 题问卷' : '创建空白项目'}
          </Button>
        </div>
      </form>
    </div>
  );
}
