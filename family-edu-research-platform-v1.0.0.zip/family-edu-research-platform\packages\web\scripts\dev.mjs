/**
 * Development runner: rebuilds CSS on change, bundles JS on change, and serves
 * the result.
 *
 * esbuild and Tailwind are launched as child processes with `stdio: 'inherit'`
 * because this environment blocks piped stdio for spawned processes; inherit
 * also keeps their coloured output flowing to the same terminal.
 */

import { spawn } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const repoRoot = resolve(root, '..', '..');

const isWindows = process.platform === 'win32';
const bin = (name) => resolve(repoRoot, 'node_modules', '.bin', isWindows ? `${name}.cmd` : name);

const children = [];

function run(label, command, args) {
  const child = spawn(command, args, {
    cwd: root,
    stdio: 'inherit',
    shell: isWindows,
  });
  child.on('exit', (code) => {
    if (code !== 0 && code !== null) console.error(`[ferp-web] ${label} 退出，代码 ${code}`);
  });
  children.push(child);
  return child;
}

// 1. Tailwind in watch mode.
run('tailwind', bin('tailwindcss'), [
  '-i',
  './src/styles/tailwind.css',
  '-o',
  './dist/assets/app.css',
  '--watch',
]);

// 2. esbuild in watch mode.
run('esbuild', bin('esbuild'), [
  'src/main.tsx',
  '--bundle',
  '--outfile=dist/assets/app.js',
  '--format=esm',
  '--target=es2020',
  '--jsx=automatic',
  '--sourcemap',
  '--watch=forever',
  '--log-level=warning',
]);

// 3. Ensure index.html exists, then serve.
run('copy-html', process.execPath, [resolve(here, 'copy-html.mjs')]);

setTimeout(() => {
  run('serve', process.execPath, [resolve(here, 'serve.mjs')]);
}, 1200);

function shutdown() {
  for (const child of children) {
    if (!child.killed) child.kill();
  }
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
