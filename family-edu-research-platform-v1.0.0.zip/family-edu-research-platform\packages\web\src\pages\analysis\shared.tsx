/**
 * Shared scaffolding for the statistical analysis console (PHASE 6).
 *
 * Every analysis page follows the same contract, so it lives here once:
 *  - the project selector is driven by `?project=`, so a page can be linked to;
 *  - the API's own Chinese `reason` is always preferred over an empty chart
 *    when an analysis cannot be computed;
 *  - the methodological note under each heading is part of the page, because a
 *    number without its assumptions is not a finding.
 */

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Alert, Button, EmptyState, LoadingBlock, Select } from '../../components/ui';
import { api, ApiClientError, type ProjectListResult } from '../../lib/api';

/* ------------------------------------------------------------------ */
/* Project selection                                                  */
/* ------------------------------------------------------------------ */

export interface AnalysisProjectState {
  /** Null until the project list has loaded. */
  projects: ProjectListResult | null;
  projectId: string;
  /** Switch project and mirror the choice into the URL. */
  selectProject: (projectId: string) => void;
  loading: boolean;
  error: string | null;
}

export function useAnalysisProject(): AnalysisProjectState {
  const [searchParams, setSearchParams] = useSearchParams();
  const [projects, setProjects] = useState<ProjectListResult | null>(null);
  const [projectId, setProjectId] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const list = await api.projects.list({ limit: 200 });
        if (cancelled) return;
        setProjects(list);
        setProjectId(searchParams.get('project') ?? list.items[0]?.id ?? '');
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ApiClientError ? err.message : '无法加载研究项目。');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // The initial project is resolved once; later changes go through selectProject.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectProject = useCallback(
    (next: string) => {
      setProjectId(next);
      setSearchParams({ project: next });
    },
    [setSearchParams],
  );

  return { projects, projectId, selectProject, loading, error };
}

/** Standard load/empty shell shared by every analysis page. */
export function AnalysisProjectGate({
  state,
  children,
}: {
  state: AnalysisProjectState;
  children: ReactNode;
}): ReactNode {
  if (state.loading && !state.projects) return <LoadingBlock label="正在加载研究项目…" />;

  if (!state.projects) {
    return (
      <Alert tone="danger" title="无法加载研究项目">
        {state.error ?? '请稍后重试。'}
      </Alert>
    );
  }

  if (state.projects.items.length === 0) {
    return (
      <EmptyState
        title="还没有研究项目"
        description="统计分析需要先有研究项目与已收集的样本数据。"
        action={
          <Link to="/projects/new">
            <Button variant="primary">新建研究项目</Button>
          </Link>
        }
      />
    );
  }

  return <>{children}</>;
}

/* ------------------------------------------------------------------ */
/* Page header                                                        */
/* ------------------------------------------------------------------ */

export function AnalysisPageHeader({
  title,
  subtitle,
  state,
  actions,
}: {
  title: string;
  subtitle: ReactNode;
  state: AnalysisProjectState;
  actions?: ReactNode;
}): ReactNode {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div className="min-w-0">
        <h1 className="text-xl font-semibold text-ink-900">{title}</h1>
        <p className="mt-1 text-sm text-ink-500">{subtitle}</p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <label className="flex items-center gap-2 text-sm text-ink-600">
          当前研究项目
          <Select
            className="min-w-56"
            value={state.projectId}
            onChange={(event) => state.selectProject(event.target.value)}
          >
            {(state.projects?.items ?? []).map((project) => (
              <option key={project.id} value={project.id}>
                {project.title}
              </option>
            ))}
          </Select>
        </label>
        {actions}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Methodological note                                                */
/* ------------------------------------------------------------------ */

/**
 * The short "how was this computed" statement that accompanies every result.
 * Deliberately visible rather than collapsed: these are the assumptions a
 * reader needs in order to judge the numbers above them.
 */
export function MethodNote({ title = '方法说明', children }: { title?: string; children: ReactNode }): ReactNode {
  return (
    <div className="rounded-md border border-ink-200 bg-ink-50 px-3.5 py-3">
      <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">{title}</p>
      <div className="mt-1 space-y-1 text-xs leading-relaxed text-ink-600">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Availability                                                       */
/* ------------------------------------------------------------------ */

interface MaybeUnavailable {
  available?: boolean;
  reason?: string | null;
}

/**
 * Extract the API's own explanation when an analysis reports `available: false`.
 *
 * The console never substitutes an empty chart for an analysis the engine
 * refused to run: the reason is the result.
 */
export function unavailableReason(payload: unknown): string | null {
  if (!payload || typeof payload !== 'object') return null;
  const candidate = payload as MaybeUnavailable;
  if (candidate.available !== false) return null;
  return typeof candidate.reason === 'string' && candidate.reason.trim() !== ''
    ? candidate.reason
    : '该分析当前不可用。';
}

export function UnavailableNotice({ reason, title = '该分析暂不可用' }: { reason: string; title?: string }): ReactNode {
  return (
    <Alert tone="warning" title={title}>
      {reason}
    </Alert>
  );
}

/* ------------------------------------------------------------------ */
/* Small helpers                                                      */
/* ------------------------------------------------------------------ */

/**
 * Measurement level in Chinese.
 *
 * This matters on screen, not just in prose: whether a mean is even defined
 * depends on it, which is why nominal variables show 「—」 instead of a number.
 */
export const MEASUREMENT_LABELS: Record<string, string> = {
  nominal: '名义（分类）',
  ordinal: '有序',
  interval: '等距',
  ratio: '等比',
  count: '计数',
  text: '文本',
};

export function measurementLabel(dataType: string): string {
  return MEASUREMENT_LABELS[dataType] ?? dataType;
}

export function ErrorNotice({ message }: { message: string }): ReactNode {
  return (
    <Alert tone="danger" title="加载失败">
      {message}
    </Alert>
  );
}
