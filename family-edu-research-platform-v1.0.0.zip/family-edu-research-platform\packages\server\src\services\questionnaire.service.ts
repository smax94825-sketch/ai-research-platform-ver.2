/**
 * Questionnaire service — creation from research templates, versioning,
 * publish and share-token handling.
 *
 * Version-control rule enforced here (spec §46): once a questionnaire is
 * published it is locked. Editing a locked instrument would break the
 * correspondence between collected responses and the questions that produced
 * them, so the only way forward is `createNewVersion`, which clones the
 * instrument under a new version number and leaves historical data untouched.
 */

import {
  buildFamilyEduV4Template,
  validateQuestionnaireForPublish,
  validateLogic,
  type Questionnaire,
  type Question,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { generateShareToken, newId, nextVersion, nowIso } from '../util/ids.js';
import {
  insertRow,
  updateRow,
} from '../db/index.js';
import {
  toQuestion,
  toQuestionnaire,
  type QuestionRow,
  type QuestionnaireRow,
} from './mappers.js';

/* ------------------------------------------------------------------ */
/* Reads                                                              */
/* ------------------------------------------------------------------ */

export function listQuestionnaires(db: Db, projectId: string): Questionnaire[] {
  return db
    .all<QuestionnaireRow>(
      'SELECT * FROM questionnaires WHERE project_id = ? ORDER BY is_current DESC, created_at DESC',
      [projectId],
    )
    .map(toQuestionnaire);
}

export function findQuestionnaireById(db: Db, id: string): Questionnaire | undefined {
  const row = db.get<QuestionnaireRow>('SELECT * FROM questionnaires WHERE id = ?', [id]);
  return row ? toQuestionnaire(row) : undefined;
}

export function requireQuestionnaire(db: Db, id: string): Questionnaire {
  const found = findQuestionnaireById(db, id);
  if (!found) throw ApiError.notFound('问卷不存在。');
  return found;
}

/**
 * Ownership-scoped lookup: resolves the questionnaire only when it belongs to a
 * project owned by this researcher. Returns undefined otherwise, so callers can
 * report 404 without leaking the existence of another researcher's data.
 */
export function findQuestionnaireForResearcher(
  db: Db,
  questionnaireId: string,
  researcherId: string,
): Questionnaire | undefined {
  const row = db.get<QuestionnaireRow>(
    `SELECT q.* FROM questionnaires q
       JOIN research_projects p ON p.id = q.project_id
      WHERE q.id = ? AND p.researcher_id = ?`,
    [questionnaireId, researcherId],
  );
  return row ? toQuestionnaire(row) : undefined;
}

export function requireQuestionnaireForResearcher(
  db: Db,
  questionnaireId: string,
  researcherId: string,
): Questionnaire {
  const found = findQuestionnaireForResearcher(db, questionnaireId, researcherId);
  if (!found) throw ApiError.notFound('问卷不存在，或您没有访问权限。');
  return found;
}

export function getCurrentQuestionnaire(db: Db, projectId: string): Questionnaire | undefined {
  const row = db.get<QuestionnaireRow>(
    'SELECT * FROM questionnaires WHERE project_id = ? ORDER BY is_current DESC, created_at DESC LIMIT 1',
    [projectId],
  );
  return row ? toQuestionnaire(row) : undefined;
}

export function findQuestionnaireByShareToken(db: Db, token: string): Questionnaire | undefined {
  const row = db.get<QuestionnaireRow>('SELECT * FROM questionnaires WHERE share_token = ?', [token]);
  return row ? toQuestionnaire(row) : undefined;
}

export function listQuestions(db: Db, questionnaireId: string): Question[] {
  return db
    .all<QuestionRow>(
      'SELECT * FROM questions WHERE questionnaire_id = ? ORDER BY sort_order ASC',
      [questionnaireId],
    )
    .map(toQuestion);
}

export function findQuestionById(db: Db, id: string): Question | undefined {
  const row = db.get<QuestionRow>('SELECT * FROM questions WHERE id = ?', [id]);
  return row ? toQuestion(row) : undefined;
}

/** Count collected responses — used for the "collection has started" checks. */
export function countResponses(db: Db, questionnaireId: string): number {
  const value = db.scalar<number>(
    'SELECT COUNT(*) AS n FROM respondents WHERE questionnaire_id = ?',
    [questionnaireId],
  );
  return Number(value ?? 0);
}

/* ------------------------------------------------------------------ */
/* Create                                                             */
/* ------------------------------------------------------------------ */

export interface TemplateQuestionSeedLike {
  question_code: string;
  question_text: string;
  question_type: string;
  options: unknown;
  required: boolean;
  dimension: string | null;
  variable_name: string | null;
  section: string | null;
  help_text: string | null;
  logic: unknown;
  scoring_rule: unknown;
}

function insertQuestions(
  db: Db,
  questionnaireId: string,
  seeds: readonly TemplateQuestionSeedLike[],
): number {
  const timestamp = nowIso();
  seeds.forEach((seed, index) => {
    insertRow(db, 'questions', {
      id: newId(),
      questionnaire_id: questionnaireId,
      question_code: seed.question_code,
      question_text: seed.question_text,
      question_type: seed.question_type,
      options: JSON.stringify(seed.options ?? {}),
      required: seed.required ? 1 : 0,
      dimension: seed.dimension,
      variable_name: seed.variable_name,
      sort_order: index + 1,
      section: seed.section,
      help_text: seed.help_text,
      logic: seed.logic ? JSON.stringify(seed.logic) : null,
      scoring_rule: seed.scoring_rule ? JSON.stringify(seed.scoring_rule) : null,
      created_at: timestamp,
      updated_at: timestamp,
    });
  });
  return seeds.length;
}

/**
 * Create a questionnaire pre-loaded from a research template.
 * Currently the only shipped template is the V4.0 family-education instrument.
 */
export function createQuestionnaireFromTemplate(
  db: Db,
  projectId: string,
  templateKey: string,
  options: { title?: string; version?: string } = {},
): Questionnaire {
  const template = buildFamilyEduV4Template();
  if (templateKey !== template.key) {
    throw ApiError.validation(`未知的研究模板：${templateKey}。`, {
      available: [template.key],
    });
  }

  const id = newId();
  const timestamp = nowIso();
  db.transaction(() => {
    insertRow(db, 'questionnaires', {
      id,
      project_id: projectId,
      title: options.title ?? template.title,
      description: template.description,
      version: options.version ?? template.version,
      status: 'draft',
      share_token: null,
      is_current: 1,
      locked: 0,
      published_at: null,
      created_at: timestamp,
      updated_at: timestamp,
    });
    insertQuestions(db, id, template.questions);
  });

  return requireQuestionnaire(db, id);
}

export function createEmptyQuestionnaire(
  db: Db,
  projectId: string,
  options: { title: string; description?: string | null; version?: string },
): Questionnaire {
  const id = newId();
  const timestamp = nowIso();
  insertRow(db, 'questionnaires', {
    id,
    project_id: projectId,
    title: options.title,
    description: options.description ?? null,
    version: options.version ?? 'V1.0',
    status: 'draft',
    share_token: null,
    is_current: 1,
    locked: 0,
    published_at: null,
    created_at: timestamp,
    updated_at: timestamp,
  });
  return requireQuestionnaire(db, id);
}

/* ------------------------------------------------------------------ */
/* Update                                                             */
/* ------------------------------------------------------------------ */

export interface QuestionnairePatch {
  title?: string;
  description?: string | null;
}

/** Guard: refuse structural edits on a locked (already fielded) instrument. */
export function assertEditable(questionnaire: Questionnaire): void {
  if (questionnaire.locked || questionnaire.status === 'published') {
    throw ApiError.locked(
      `问卷 ${questionnaire.version} 已发布并处于锁定状态，无法直接修改。` +
        '请使用「建立新版本」复制问卷后再编辑，以保证已收集数据与题目版本的对应关系。',
      { questionnaire_id: questionnaire.id, version: questionnaire.version, status: questionnaire.status },
    );
  }
}

export function updateQuestionnaire(db: Db, id: string, patch: QuestionnairePatch): Questionnaire {
  const questionnaire = requireQuestionnaire(db, id);
  assertEditable(questionnaire);

  const update: Record<string, unknown> = { updated_at: nowIso() };
  if (patch.title !== undefined) {
    if (patch.title.trim().length === 0) throw ApiError.validation('问卷标题不能为空。');
    update['title'] = patch.title.trim();
  }
  if (patch.description !== undefined) update['description'] = patch.description;

  updateRow(db, 'questionnaires', update, { id });
  return requireQuestionnaire(db, id);
}

/* ------------------------------------------------------------------ */
/* Versioning                                                         */
/* ------------------------------------------------------------------ */

/** Store an immutable snapshot of the current instrument definition. */
export function snapshotQuestionnaire(db: Db, questionnaireId: string, label?: string): string {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  const questions = listQuestions(db, questionnaireId);
  const id = newId();
  insertRow(db, 'questionnaire_snapshots', {
    id,
    questionnaire_id: questionnaireId,
    version: questionnaire.version,
    label: label ?? null,
    snapshot_json: JSON.stringify({ questionnaire, questions }),
    question_count: questions.length,
    created_at: nowIso(),
  });
  return id;
}

/**
 * Clone a questionnaire (with all its questions) into a new version.
 * The original keeps its data and its `locked` flag; the clone starts as a
 * fresh draft and becomes the project's current instrument.
 */
export function createNewVersion(
  db: Db,
  questionnaireId: string,
  kind: 'minor' | 'major' = 'minor',
): Questionnaire {
  const source = requireQuestionnaire(db, questionnaireId);
  const questions = listQuestions(db, questionnaireId);
  const newQuestionnaireId = newId();
  const timestamp = nowIso();

  db.transaction(() => {
    // Snapshot the outgoing version before it is superseded.
    snapshotQuestionnaire(db, questionnaireId, `副本创建于 ${timestamp}`);

    db.run('UPDATE questionnaires SET is_current = 0, updated_at = ? WHERE project_id = ?', [
      timestamp,
      source.project_id,
    ]);

    insertRow(db, 'questionnaires', {
      id: newQuestionnaireId,
      project_id: source.project_id,
      title: source.title,
      description: source.description,
      version: nextVersion(source.version, kind),
      status: 'draft',
      share_token: null,
      is_current: 1,
      locked: 0,
      published_at: null,
      created_at: timestamp,
      updated_at: timestamp,
    });

    insertQuestions(
      db,
      newQuestionnaireId,
      questions.map((question) => ({
        question_code: question.question_code,
        question_text: question.question_text,
        question_type: question.question_type,
        options: question.options,
        required: question.required,
        dimension: question.dimension,
        variable_name: question.variable_name,
        section: question.section,
        help_text: question.help_text,
        logic: question.logic,
        scoring_rule: question.scoring_rule,
      })),
    );
  });

  return requireQuestionnaire(db, newQuestionnaireId);
}

/* ------------------------------------------------------------------ */
/* Publish                                                            */
/* ------------------------------------------------------------------ */

export interface PublishResult {
  questionnaire: Questionnaire;
  share_token: string;
  /** Non-blocking advisories (unreachable questions, non-contiguous ordering). */
  warnings: string[];
  logic_issues: { questionCode: string; severity: string; message: string }[];
}

/**
 * Publish a questionnaire: validate, lock, snapshot and mint a share token.
 * Re-publishing an already published instrument returns its existing token
 * instead of minting a second one, so printed QR codes keep working.
 */
export function publishQuestionnaire(db: Db, questionnaireId: string): PublishResult {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  const questions = listQuestions(db, questionnaireId);

  if (questions.length === 0) {
    throw ApiError.validation('问卷没有任何题目，无法发布。请先添加题目或使用研究模板。');
  }

  const validation = validateQuestionnaireForPublish(
    questions.map((question) => ({
      question_code: question.question_code,
      question_type: question.question_type,
      question_text: question.question_text,
      sort_order: question.sort_order,
      logic: question.logic,
    })),
  );
  if (!validation.valid) {
    throw ApiError.validation(
      `问卷校验未通过，共 ${validation.errors.length} 处问题。`,
      validation.errors,
    );
  }

  const logicIssues = validateLogic(questions);
  const blockingLogicErrors = logicIssues.filter((issue) => issue.severity === 'error');
  if (blockingLogicErrors.length > 0) {
    throw ApiError.validation(
      `问卷逻辑存在 ${blockingLogicErrors.length} 处错误，无法发布。`,
      blockingLogicErrors,
    );
  }

  if (questionnaire.status === 'published' && questionnaire.share_token) {
    return {
      questionnaire,
      share_token: questionnaire.share_token,
      warnings: validation.warnings.map((w) => w.message),
      logic_issues: logicIssues,
    };
  }

  const timestamp = nowIso();
  const token = questionnaire.share_token ?? generateShareToken();

  db.transaction(() => {
    // Normalise ordering so the stored instrument is contiguous.
    questions.forEach((question, index) => {
      if (question.sort_order !== index + 1) {
        updateRow(db, 'questions', { sort_order: index + 1, updated_at: timestamp }, { id: question.id });
      }
    });

    updateRow(
      db,
      'questionnaires',
      {
        status: 'published',
        share_token: token,
        is_current: 1,
        locked: 1,
        published_at: questionnaire.published_at ?? timestamp,
        updated_at: timestamp,
      },
      { id: questionnaireId },
    );

    snapshotQuestionnaire(db, questionnaireId, '发布时快照');
  });

  return {
    questionnaire: requireQuestionnaire(db, questionnaireId),
    share_token: token,
    warnings: validation.warnings.map((w) => w.message),
    logic_issues: logicIssues,
  };
}

/** Close collection without destroying the instrument or its data. */
export function closeQuestionnaire(db: Db, questionnaireId: string): Questionnaire {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  if (questionnaire.status !== 'published') {
    throw ApiError.validation('只有已发布的问卷可以关闭收集。');
  }
  updateRow(
    db,
    'questionnaires',
    { status: 'closed', updated_at: nowIso() },
    { id: questionnaireId },
  );
  return requireQuestionnaire(db, questionnaireId);
}

/* ------------------------------------------------------------------ */
/* Serialisation helper                                               */
/* ------------------------------------------------------------------ */

/** Full instrument payload used by the builder and the public survey. */
export interface InstrumentPayload {
  questionnaire: Questionnaire;
  questions: Question[];
  response_count: number;
}

export function buildInstrumentPayload(db: Db, questionnaireId: string): InstrumentPayload {
  const questionnaire = requireQuestionnaire(db, questionnaireId);
  return {
    questionnaire,
    questions: listQuestions(db, questionnaireId),
    response_count: countResponses(db, questionnaireId),
  };
}
