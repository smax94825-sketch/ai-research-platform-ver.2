/**
 * Sample management (PHASE 3).
 *
 * Listing, filtering and channel reporting over collected respondents.
 * Every query is scoped by `researcher_id` through a join on the owning
 * project, so a researcher can never page through someone else's sample.
 */

import type { Respondent, RespondentStatus, ReviewStatus } from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { requireProject } from './project.service.js';
import { toRespondent } from './collection.service.js';
import type { RespondentRow } from './mappers.js';

const STATUSES: readonly RespondentStatus[] = ['in_progress', 'completed', 'abandoned'];
const REVIEW_STATUSES: readonly ReviewStatus[] = ['unreviewed', 'accepted', 'flagged', 'excluded'];

export interface ListRespondentsOptions {
  status?: string;
  source?: string;
  reviewStatus?: string;
  /** PHASE 4: filter by the severity the quality engine assigned. */
  qualitySeverity?: string;
  /** Only samples the engine flagged with at least one rule. */
  flaggedOnly?: boolean;
  /** Free-text match on the anonymous id (e.g. "A001"). */
  search?: string;
  /** ISO date lower bound on started_at. */
  from?: string;
  /** ISO date upper bound on started_at. */
  to?: string;
  limit?: number;
  offset?: number;
}

export interface RespondentPage {
  items: Respondent[];
  total: number;
  limit: number;
  offset: number;
  summary: {
    total: number;
    completed: number;
    in_progress: number;
    abandoned: number;
    by_review_status: Record<ReviewStatus, number>;
  };
}

export function listRespondents(
  db: Db,
  projectId: string,
  researcherId: string,
  options: ListRespondentsOptions = {},
): RespondentPage {
  requireProject(db, projectId, researcherId);

  const limit = Math.min(Math.max(options.limit ?? 50, 1), 500);
  const offset = Math.max(options.offset ?? 0, 0);

  if (options.status && !STATUSES.includes(options.status as RespondentStatus)) {
    throw ApiError.validation(`未知的样本状态：${options.status}。`);
  }
  if (options.reviewStatus && !REVIEW_STATUSES.includes(options.reviewStatus as ReviewStatus)) {
    throw ApiError.validation(`未知的审核状态：${options.reviewStatus}。`);
  }

  const clauses = ['project_id = ?'];
  const params: unknown[] = [projectId];

  if (options.status) {
    clauses.push('status = ?');
    params.push(options.status);
  }
  if (options.source) {
    clauses.push('source = ?');
    params.push(options.source);
  }
  if (options.reviewStatus) {
    clauses.push('COALESCE(review_status, \'unreviewed\') = ?');
    params.push(options.reviewStatus);
  }
  if (options.qualitySeverity) {
    const allowed = ['clean', 'info', 'warning', 'critical', 'unscored'];
    if (!allowed.includes(options.qualitySeverity)) {
      throw ApiError.validation(`未知的质量等级：${options.qualitySeverity}。`);
    }
    if (options.qualitySeverity === 'unscored') {
      clauses.push('quality_score IS NULL');
    } else {
      clauses.push('quality_severity = ?');
      params.push(options.qualitySeverity);
    }
  }
  if (options.flaggedOnly) {
    clauses.push('EXISTS (SELECT 1 FROM quality_flags f WHERE f.respondent_id = respondents.id)');
  }
  if (options.search && options.search.trim() !== '') {
    clauses.push('anonymous_id LIKE ?');
    params.push(`%${options.search.trim()}%`);
  }
  if (options.from) {
    clauses.push('started_at >= ?');
    params.push(options.from);
  }
  if (options.to) {
    // Upper bound is inclusive of the whole day.
    clauses.push('started_at <= ?');
    params.push(`${options.to}T23:59:59.999Z`);
  }

  const where = clauses.join(' AND ');
  const total = Number(
    db.scalar<number>(`SELECT COUNT(*) AS n FROM respondents WHERE ${where}`, params) ?? 0,
  );

  const rows = db.all<RespondentRow>(
    `SELECT * FROM respondents WHERE ${where}
      ORDER BY started_at DESC, id DESC
      LIMIT ? OFFSET ?`,
    [...params, limit, offset],
  );

  const statusCounts = db.get<{ total: number; completed: number; in_progress: number; abandoned: number }>(
    `SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress,
        SUM(CASE WHEN status = 'abandoned' THEN 1 ELSE 0 END) AS abandoned
       FROM respondents WHERE project_id = ?`,
    [projectId],
  );

  const reviewRows = db.all<{ review_status: string | null; n: number }>(
    `SELECT COALESCE(review_status, 'unreviewed') AS review_status, COUNT(*) AS n
       FROM respondents WHERE project_id = ? GROUP BY COALESCE(review_status, 'unreviewed')`,
    [projectId],
  );
  const byReview: Record<ReviewStatus, number> = {
    unreviewed: 0,
    accepted: 0,
    flagged: 0,
    excluded: 0,
  };
  for (const row of reviewRows) {
    if ((REVIEW_STATUSES as readonly string[]).includes(row.review_status ?? '')) {
      byReview[row.review_status as ReviewStatus] = Number(row.n);
    }
  }

  return {
    items: rows.map(toRespondent),
    total,
    limit,
    offset,
    summary: {
      total: Number(statusCounts?.total ?? 0),
      completed: Number(statusCounts?.completed ?? 0),
      in_progress: Number(statusCounts?.in_progress ?? 0),
      abandoned: Number(statusCounts?.abandoned ?? 0),
      by_review_status: byReview,
    },
  };
}

/* ------------------------------------------------------------------ */
/* Channel reporting (spec §16)                                       */
/* ------------------------------------------------------------------ */

export interface SourceBreakdownItem {
  source: string;
  total: number;
  completed: number;
  in_progress: number;
  abandoned: number;
  /** Completed share of this channel's samples, or null when it has none. */
  completion_rate: number | null;
  /** Completed samples the researcher has explicitly excluded. */
  excluded: number;
}

export interface SourceBreakdown {
  items: SourceBreakdownItem[];
  total: number;
}

export function getSourceBreakdown(
  db: Db,
  projectId: string,
  researcherId: string,
): SourceBreakdown {
  requireProject(db, projectId, researcherId);

  const rows = db.all<{
    source: string;
    total: number;
    completed: number;
    in_progress: number;
    abandoned: number;
    excluded: number;
  }>(
    `SELECT
        source,
        COUNT(*) AS total,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) AS in_progress,
        SUM(CASE WHEN status = 'abandoned' THEN 1 ELSE 0 END) AS abandoned,
        SUM(CASE WHEN COALESCE(review_status, 'unreviewed') = 'excluded' THEN 1 ELSE 0 END) AS excluded
       FROM respondents
      WHERE project_id = ?
      GROUP BY source
      ORDER BY total DESC, source ASC`,
    [projectId],
  );

  const items = rows.map((row) => {
    const total = Number(row.total);
    const completed = Number(row.completed);
    return {
      source: row.source,
      total,
      completed,
      in_progress: Number(row.in_progress),
      abandoned: Number(row.abandoned),
      excluded: Number(row.excluded),
      completion_rate: total > 0 ? Math.round((completed / total) * 10000) / 100 : null,
    };
  });

  return {
    items,
    total: items.reduce((sum, item) => sum + item.total, 0),
  };
}
