/**
 * Analysis routes (PHASE 5).
 *
 * Two access patterns:
 *  - `GET .../analysis/<type>` runs one analysis on demand — used by the
 *    console's per-analysis pages.
 *  - `POST .../analysis/run` builds and PERSISTS the complete bundle, which is
 *    the artifact the AI assistant, the report generator and the competition
 *    analysis consume. Those layers never recompute statistics, which is what
 *    keeps every number they quote traceable to an engine run.
 */

import { Router } from 'express';
import type { Db } from '../db/index.js';
import type { Config } from '../config.js';
import { currentResearcher, requireAuth } from '../middleware/auth.js';
import {
  buildAnalysisBundle,
  getLatestBundle,
  listStoredAnalyses,
  loadAnalysableSample,
  runComparisons,
  runCorrelation,
  runRegression,
  ANALYSIS_ENGINE_VERSION,
  DEFAULT_COMPARISON_DEPENDENTS,
  DEFAULT_COMPARISON_FACTOR,
  DEFAULT_CORRELATION_VARIABLES,
  DEFAULT_REGRESSION_DEPENDENT,
  DEFAULT_REGRESSION_PREDICTORS,
} from '../services/analysis.service.js';
import { requireProject } from '../services/project.service.js';
import {
  describeDataset,
  reliabilityReport,
  validityReport,
  testAllHypotheses,
} from '@ferp/shared';
import { asyncHandler } from '../util/errors.js';

export interface AnalysisRouterContext {
  db: Db;
  config: Config;
}

/** Parse a comma-separated query parameter into a trimmed list. */
function parseList(value: unknown): string[] | undefined {
  if (typeof value !== 'string' || value.trim() === '') return undefined;
  return value
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item !== '');
}

export function createAnalysisRouter(ctx: AnalysisRouterContext): Router {
  const router = Router();
  router.use(requireAuth(ctx));

  /* ---------------------------------------------------------------- */
  /* Dataset inventory                                                 */
  /* ---------------------------------------------------------------- */

  router.get(
    '/:projectId/analysis/dataset',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);

      const loaded = loadAnalysableSample(ctx.db, projectId);
      const { dataset, summary } = loaded;
      const descriptive = describeDataset(dataset);

      res.json({
        data: {
          engine_version: ANALYSIS_ENGINE_VERSION,
          sample: summary,
          n_respondents: dataset.n_respondents,
          variable_count: dataset.variables.length,
          derived_variable_count: dataset.variables.filter((variable) => variable.is_derived).length,
          empty_variables: dataset.empty_variables,
          variables: dataset.variables.map((variable) => {
            const stats = descriptive.variables.find((item) => item.variable === variable.name);
            return {
              name: variable.name,
              label: variable.label,
              dimension: variable.dimension,
              question_code: variable.question_code,
              data_type: variable.data_type,
              n: stats?.n ?? 0,
              missing: stats?.missing ?? 0,
              is_derived: variable.is_derived,
              sources: variable.sources,
            };
          }),
          available: {
            correlation_variables: DEFAULT_CORRELATION_VARIABLES.filter((name) =>
              dataset.by_name.has(name),
            ),
            regression_dependent: dataset.by_name.has(DEFAULT_REGRESSION_DEPENDENT)
              ? DEFAULT_REGRESSION_DEPENDENT
              : null,
            regression_predictors: DEFAULT_REGRESSION_PREDICTORS.filter((name) =>
              dataset.by_name.has(name),
            ),
            comparison_factor: dataset.by_name.has(DEFAULT_COMPARISON_FACTOR)
              ? DEFAULT_COMPARISON_FACTOR
              : null,
            comparison_dependents: DEFAULT_COMPARISON_DEPENDENTS.filter((name) =>
              dataset.by_name.has(name),
            ),
          },
          note:
            '分析样本仅包含已完成且未被研究者排除的样本。所有统计基于整例删除（listwise），' +
            '缺失值不插补；各分析的有效 n 可能不同，请以各结果中报告的 n 为准。',
        },
      });
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Individual analyses                                               */
  /* ---------------------------------------------------------------- */

  router.get(
    '/:projectId/analysis/descriptive',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset, summary } = loadAnalysableSample(ctx.db, projectId);
      res.json({ data: { engine_version: ANALYSIS_ENGINE_VERSION, sample: summary, ...describeDataset(dataset) } });
    }),
  );

  router.get(
    '/:projectId/analysis/reliability',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset } = loadAnalysableSample(ctx.db, projectId);
      res.json({ data: { engine_version: ANALYSIS_ENGINE_VERSION, ...reliabilityReport(dataset) } });
    }),
  );

  router.get(
    '/:projectId/analysis/validity',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset } = loadAnalysableSample(ctx.db, projectId);
      res.json({ data: { engine_version: ANALYSIS_ENGINE_VERSION, ...validityReport(dataset) } });
    }),
  );

  router.get(
    '/:projectId/analysis/correlation',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset } = loadAnalysableSample(ctx.db, projectId);
      const variables = parseList(req.query['variables']);
      const result = runCorrelation(dataset, variables);

      if (!result) {
        res.json({
          data: {
            engine_version: ANALYSIS_ENGINE_VERSION,
            available: false,
            reason:
              '可用的连续/有序变量少于 2 个，或有效样本不足 4 例，无法计算相关矩阵。' +
              '请先收集更多样本，或检查所选变量是否存在变异。',
          },
        });
        return;
      }
      res.json({ data: { engine_version: ANALYSIS_ENGINE_VERSION, available: true, ...result } });
    }),
  );

  router.get(
    '/:projectId/analysis/regression',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset } = loadAnalysableSample(ctx.db, projectId);

      const dependent = typeof req.query['dependent'] === 'string' ? req.query['dependent'] : undefined;
      const predictors = parseList(req.query['predictors']);
      const result = runRegression(dataset, dependent ?? DEFAULT_REGRESSION_DEPENDENT, predictors ?? DEFAULT_REGRESSION_PREDICTORS);

      if (!result) {
        res.json({
          data: {
            engine_version: ANALYSIS_ENGINE_VERSION,
            available: false,
            reason: '因变量或自变量不存在，或没有可用的自变量。',
          },
        });
        return;
      }
      res.json({ data: { engine_version: ANALYSIS_ENGINE_VERSION, available: true, ...result } });
    }),
  );

  router.get(
    '/:projectId/analysis/comparisons',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset } = loadAnalysableSample(ctx.db, projectId);

      const factor = typeof req.query['factor'] === 'string' ? req.query['factor'] : DEFAULT_COMPARISON_FACTOR;
      const dependents = parseList(req.query['dependents']) ?? DEFAULT_COMPARISON_DEPENDENTS;
      const results = runComparisons(dataset, factor, dependents);

      res.json({
        data: {
          engine_version: ANALYSIS_ENGINE_VERSION,
          factor,
          comparisons: results,
          available: results.length > 0,
          reason:
            results.length === 0
              ? `分组变量 ${factor} 不存在，或所选因变量在该分组下有效样本不足。`
              : null,
        },
      });
    }),
  );

  router.get(
    '/:projectId/analysis/hypotheses',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const { dataset } = loadAnalysableSample(ctx.db, projectId);
      const report = testAllHypotheses(dataset);
      res.json({ data: { engine_version: ANALYSIS_ENGINE_VERSION, ...report } });
    }),
  );

  /* ---------------------------------------------------------------- */
  /* Full bundle                                                       */
  /* ---------------------------------------------------------------- */

  /**
   * Run every analysis and persist the bundle.
   * Idempotent in the sense that it is safe to run repeatedly; each run stores a
   * new, timestamped set of results rather than overwriting history.
   */
  router.post(
    '/:projectId/analysis/run',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const bundle = buildAnalysisBundle(ctx.db, projectId, researcher.id, { persist: true });
      res.json({ data: bundle });
    }),
  );

  /** The most recently persisted bundle, or a clear signal that none exists. */
  router.get(
    '/:projectId/analysis/bundle',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      requireProject(ctx.db, projectId, researcher.id);
      const bundle = getLatestBundle(ctx.db, projectId, researcher.id);

      if (!bundle) {
        res.json({
          data: {
            available: false,
            reason:
              '尚未运行过完整统计分析。请先执行「运行全部分析」，' +
              '之后 AI 解释、研究报告与创业洞察才能基于真实的统计结果生成。',
          },
        });
        return;
      }
      res.json({ data: { available: true, ...bundle } });
    }),
  );

  /** Audit trail of every stored analysis run, for reproducibility. */
  router.get(
    '/:projectId/analysis/history',
    asyncHandler((req, res) => {
      const researcher = currentResearcher(req);
      const projectId = req.params['projectId']!;
      const analysisType = typeof req.query['type'] === 'string' ? req.query['type'] : undefined;
      const rows = listStoredAnalyses(ctx.db, projectId, researcher.id, analysisType);
      res.json({
        data: rows.map((row) => ({
          id: row.id,
          analysis_type: row.analysis_type,
          engine_version: row.engine_version,
          sample_n: row.sample_n,
          created_at: row.created_at,
          parameters: row.parameters,
        })),
      });
    }),
  );

  return router;
}
