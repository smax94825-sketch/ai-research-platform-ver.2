/**
 * Question list (left column of the builder).
 *
 * Reordering uses explicit up/down buttons rather than drag-and-drop: the
 * questionnaire order is a research-design decision that must also work with a
 * keyboard, and the server owns the authoritative order.
 */

import { useMemo, type ReactNode } from 'react';
import { QUESTION_TYPES, QUESTION_TYPE_LABELS, type Question, type QuestionType } from '@ferp/shared';
import { Badge, Button } from '../ui';
import { truncate } from '../../lib/format';

interface QuestionListProps {
  questions: Question[];
  selectedId: string | null;
  editable: boolean;
  nextCode: string;
  onSelect: (id: string) => void;
  onMove: (id: string, direction: 'up' | 'down') => void;
  onDuplicate: (id: string) => void;
  onDelete: (id: string) => void;
  onAdd: (type: QuestionType) => void;
  busy: boolean;
}

export function QuestionList({
  questions,
  selectedId,
  editable,
  nextCode,
  onSelect,
  onMove,
  onDuplicate,
  onDelete,
  onAdd,
  busy,
}: QuestionListProps): ReactNode {
  const grouped = useMemo(() => {
    const groups: { section: string; items: Question[] }[] = [];
    for (const question of questions) {
      const section = question.section ?? '未分组';
      const last = groups[groups.length - 1];
      if (last && last.section === section) last.items.push(question);
      else groups.push({ section, items: [question] });
    }
    return groups;
  }, [questions]);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-ink-200 px-3 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-ink-900">题目列表</h2>
          <span className="text-xs text-ink-500">{questions.length} 题</span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <select
            className="ferp-input py-1 text-xs"
            disabled={!editable || busy}
            value=""
            onChange={(event) => {
              if (event.target.value) onAdd(event.target.value as QuestionType);
            }}
          >
            <option value="">+ 添加题目（{nextCode}）</option>
            {QUESTION_TYPES.map((type) => (
              <option key={type} value={type}>
                {QUESTION_TYPE_LABELS[type]}
              </option>
            ))}
          </select>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-2 py-2">
        {questions.length === 0 && (
          <p className="px-2 py-6 text-center text-xs text-ink-400">
            该问卷还没有题目。可以从上方下拉菜单添加题目，或返回项目页按模板载入 58 题。
          </p>
        )}

        {grouped.map((group) => (
          <div key={group.section} className="mb-3">
            <p className="px-2 pb-1 text-[11px] font-semibold text-ink-400" title={group.section}>
              {truncate(group.section, 22)}
            </p>
            <ul className="space-y-0.5">
              {group.items.map((question) => {
                const index = questions.findIndex((item) => item.id === question.id);
                const isSelected = question.id === selectedId;
                return (
                  <li key={question.id}>
                    <div
                      className={`group flex items-start gap-1.5 rounded-md px-2 py-1.5 text-sm ${
                        isSelected ? 'bg-brand-50 ring-1 ring-brand-300' : 'hover:bg-ink-100'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => onSelect(question.id)}
                        className="min-w-0 flex-1 text-left"
                      >
                        <span className="flex items-center gap-1.5">
                          <span className="font-mono text-[11px] text-ink-500">{question.question_code}</span>
                          {question.required && <span className="text-[10px] text-red-500">*</span>}
                          {question.logic && question.logic.rules.length > 0 && (
                            <span className="rounded bg-amber-100 px-1 text-[10px] text-amber-700">逻辑</span>
                          )}
                        </span>
                        <span className="mt-0.5 block truncate text-xs text-ink-700">
                          {question.question_type === 'page_break'
                            ? `【章节】${question.question_text}`
                            : truncate(question.question_text || '（未填写题干）', 26)}
                        </span>
                      </button>

                      {editable && (
                        <span className="hidden shrink-0 flex-col gap-0.5 group-hover:flex">
                          <button
                            type="button"
                            disabled={busy || index === 0}
                            onClick={() => onMove(question.id, 'up')}
                            className="rounded px-1 text-[10px] text-ink-500 hover:bg-ink-200 disabled:opacity-30"
                            title="上移"
                          >
                            ▲
                          </button>
                          <button
                            type="button"
                            disabled={busy || index === questions.length - 1}
                            onClick={() => onMove(question.id, 'down')}
                            className="rounded px-1 text-[10px] text-ink-500 hover:bg-ink-200 disabled:opacity-30"
                            title="下移"
                          >
                            ▼
                          </button>
                        </span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="border-t border-ink-200 px-3 py-2">
        <p className="mb-2 text-[11px] text-ink-500">
          题型覆盖：单选 / 多选 / 李克特 / 矩阵 / 文本 / 数字 / 下拉 / 排序 / 知识测试 / 分页
        </p>
        <div className="flex flex-wrap gap-1">
          {(['single', 'multiple', 'likert', 'matrix', 'knowledge_test'] as QuestionType[]).map((type) => (
            <Badge key={type} tone="neutral">
              {QUESTION_TYPE_LABELS[type]}
            </Badge>
          ))}
        </div>
      </div>
    </div>
  );
}
