/**
 * Analysis service (PHASE 5).
 *
 * Bridges stored responses to the statistical engine: it loads the collected
 * sample, builds the numeric dataset, runs the requested analyses and persists
 * each result so that every number a later phase reports (AI interpretation,
 * research report, competition insights) can be traced back to an engine run.
 *
 * Two integrity rules are enforced here rather than left to callers:
 *  - Only samples the researcher has NOT excluded feed the analysis, and the
 *    number of excluded samples is carried in the result so the exclusion is
 *    visible in every report.
 *  - Every analysis reports the exact n it used and the listwise deletion it
 *    performed, so a reader can always tell how much of the sample was used.
 */

import {
  DEFAULT_HYPOTHESES,
  FAMILY_EDU_V4_COMPOSITES,
  FAMILY_EDU_V4_SCALES,
  FAMILY_EDU_V4_TEMPLATE,
  buildDataset,
  chooseRegressionModel,
  correlationMatrixWithTests,
  describeDataset,
  kruskalWallis,
  mannWhitneyU,
  olsRegression,
  oneWayAnova,
  ordinalLogistic,
  reliabilityReport,
  testAllHypotheses,
  validityReport,
  type AnovaResult,
  type CorrelationMatrixResult,
  type Dataset,
  type DatasetRow,
  type DescriptiveReport,
  type HypothesisReport,
  type KruskalWallisResult,
  type MannWhitneyResult,
  type OlsResult,
  type OrdinalLogitResult,
  type RegressionModelChoice,
  type ReliabilityReport,
  type ValidityReport,
} from '@ferp/shared';
import type { Db } from '../db/index.js';
import { ApiError } from '../util/errors.js';
import { newId, nowIso } from '../util/ids.js';
import { requireProject } from './project.service.js';
import { getCurrentQuestionnaire, listQuestions, countResponses } from './questionnaire.service.js';
import { parseJson } from './mappers.js';

/* ------------------------------------------------------------------ */
/* Analysis constants                                                 */
/* ------------------------------------------------------------------ */

export const ANALYSIS_ENGINE_VERSION = '1.0.0';

/** Variables the correlation matrix uses by default (spec §24). */
export const DEFAULT_CORRELATION_VARIABLES = ['FSE', 'FED', 'PSA', 'STI', 'DSD', 'UI', 'WTP'];

/** Default regression specification (spec §25): UI ~ DSD + STI + PSA + FSE + FED. */
export const DEFAULT_REGRESSION_DEPENDENT = 'UI';
export const DEFAULT_REGRESSION_PREDICTORS = ['DSD', 'STI', 'PSA', 'FSE', 'FED'];

/** Group comparisons the console surfaces by default (spec §27). */
export const DEFAULT_COMPARISON_FACTOR = 'STAGE';
export const DEFAULT_COMPARISON_DEPENDENTS = ['FED', 'UI', 'WTP'];

/* ------------------------------------------------------------------ */
/* Bundle shape                                                       */
/* ------------------------------------------------------------------ */

export interface ComparisonResult {
  dependent: string;
  dependent_label: string;
  factor: string;
  factor_label: string;
  groups: number;
  anova: AnovaResult | null;
  /** Non-parametric counterpart, always reported so the conclusion can be checked. */
  mann_whitney: MannWhitneyResult | null;
  kruskal_wallis: KruskalWallisResult | null;
  recommended: 'parametric' | 'nonparametric';
  recommendation_reason: string;
  screening: {
    variable: string;
    group: string;
    n: number;
    skewness: number | null;
    acceptable: boolean;
    reason: string;
  }[];
}

export interface RegressionBlock {
  auto_selection: RegressionModelChoice;
  /** Always computed: the specification explicitly asks for the linear model. */
  ols: OlsResult | null;
  /** Computed when the outcome is ordinal — the statistically preferable model. */
  ordinal: OrdinalLogitResult | null;
  recommendation: string;
}

export interface SampleSummary {
  respondents_total: number;
  completed: number;
  in_progress: number;
  abandoned: number;
  excluded: number;
  /** Completed and not excluded — the analysis base. */
  analysable: number;
  /** Rows actually passed to the engine. */
  rows_loaded: number;
  sources: { source: string; total: number }[];
}

export interface AnalysisBundle {
  engine_version: string;
  generated_at: string;
  project: { id: string; title: string };
  questionnaire: { id: string; title: string; version: string; question_count: number } | null;
  sample: SampleSummary;
  dataset_summary: {
    n_respondents: number;
    variable_count: number;
    derived_variable_count: number;
    empty_variables: string[];
    variables: { name: string; label: string; data_type: string; n: number; missing: number }[];
    /** Composite variables available for analysis, with their item sources. */
    composites: { name: string; label: string; sources: string[] }[];
  };
  descriptive: DescriptiveReport;
  reliability: ReliabilityReport;
  validity: ValidityReport;
  correlation: CorrelationMatrixResult | null;
  regression: RegressionBlock | null;
  comparisons: ComparisonResult[];
  hypotheses: HypothesisReport;
  /** Statements that must accompany any downstream interpretation. */
  caveats: string[];
}

/* ------------------------------------------------------------------ */
/* Instrument origin                                                  */
/* ------------------------------------------------------------------ */

/**
 * Decide whether a questionnaire is derived from the V4.0 template.
 *
 * The database does not record which template a questionnaire was seeded from,
 * so origin is inferred from content. Two things must hold: the questionnaire
 * shares at least half of the template's question codes, and — enforced later by
 * the dataset builder — every item a composite needs is actually present. The
 * inference has consequences: it is what makes the engine materialise construct
 * variables such as FSE and attach scale definitions for reliability analysis.
 * The threshold sits at half rather than higher because a researcher who deletes
 * a third of the template's questions is still running this study, and losing
 * every derived construct silently would be the worse failure. A custom
 * instrument that merely happens to reuse a code like Q22 cannot pass the second
 * condition for a multi-item construct, so it is not relabelled either.
 */
export function isTemplateDerived(questionCodes: string[]): boolean {
  const templateCodes = new Set(
    FAMILY_EDU_V4_TEMPLATE.questions.map((question) => question.question_code),
  );
  if (templateCodes.size === 0) return false;
  const overlap = questionCodes.filter((code) => templateCodes.has(code)).length;
  return overlap / templateCodes.size >= 0.5;
}

/* ------------------------------------------------------------------ */
/* Loading                                                            */
/* ------------------------------------------------------------------ */

export interface LoadedSample {
  dataset: Dataset;
  summary: SampleSummary;
  questions: ReturnType<typeof listQuestions>;
  questionnaire: ReturnType<typeof getCurrentQuestionnaire>;
}

/**
 * Load the analysable sample.
 *
 * Excluded samples are NOT silently dropped: their count travels in
 * `SampleSummary.excluded` so every downstream report can state the exclusion.
 */
export function loadAnalysableSample(db: Db, projectId: string): LoadedSample {
  const questionnaire = getCurrentQuestionnaire(db, projectId);
  if (!questionnaire) {
    throw ApiError.validation('该项目还没有问卷，无法进行统计分析。');
  }
  const questions = listQuestions(db, questionnaire.id);

  const statusRows = db.all<{ status: string; n: number }>(
    'SELECT status, COUNT(*) AS n FROM respondents WHERE questionnaire_id = ? GROUP BY status',
    [questionnaire.id],
  );
  const statusCounts = new Map(statusRows.map((row) => [row.status, Number(row.n)]));
  const excluded = Number(
    db.scalar<number>(
      `SELECT COUNT(*) AS n FROM respondents
        WHERE questionnaire_id = ? AND COALESCE(review_status, 'unreviewed') = 'excluded'`,
      [questionnaire.id],
    ) ?? 0,
  );

  const sourceRows = db.all<{ source: string; n: number }>(
    'SELECT source, COUNT(*) AS n FROM respondents WHERE questionnaire_id = ? GROUP BY source',
    [questionnaire.id],
  );

  const respondents = db.all<{ id: string }>(
    `SELECT id FROM respondents
      WHERE questionnaire_id = ?
        AND status = 'completed'
        AND COALESCE(review_status, 'unreviewed') <> 'excluded'
      ORDER BY started_at ASC`,
    [questionnaire.id],
  );

  const rows: DatasetRow[] = [];
  if (respondents.length > 0) {
    // One query for all answers, grouped in memory — far cheaper than N queries.
    const ids = respondents.map((row) => row.id);
    const placeholders = ids.map(() => '?').join(', ');
    const answerRows = db.all<{ respondent_id: string; question_code: string; answer: string | null }>(
      `SELECT respondent_id, question_code, answer FROM responses WHERE respondent_id IN (${placeholders})`,
      ids,
    );

    const byRespondent = new Map<string, Record<string, unknown>>();
    for (const row of answerRows) {
      const existing = byRespondent.get(row.respondent_id) ?? {};
      existing[row.question_code] = parseJson<unknown>(row.answer, null);
      byRespondent.set(row.respondent_id, existing);
    }

    for (const respondent of respondents) {
      rows.push({
        respondent_id: respondent.id,
        answers: (byRespondent.get(respondent.id) ?? {}) as DatasetRow['answers'],
      });
    }
  }

  // Derived construct variables (FSE, DSD, UI …) and scale definitions are what
  // make the analysis match the research design; without them the default
  // correlation and regression specifications would reference variables that
  // never exist. They are applied only to a template-derived instrument.
  const templateDerived = isTemplateDerived(
    questions.map((question) => question.question_code),
  );

  const dataset = buildDataset(questions, rows, {
    composites: templateDerived ? FAMILY_EDU_V4_COMPOSITES : [],
    scales: templateDerived ? FAMILY_EDU_V4_SCALES : [],
  });

  const summary: SampleSummary = {
    respondents_total: countResponses(db, questionnaire.id),
    completed: statusCounts.get('completed') ?? 0,
    in_progress: statusCounts.get('in_progress') ?? 0,
    abandoned: statusCounts.get('abandoned') ?? 0,
    excluded,
    analysable: rows.length,
    rows_loaded: rows.length,
    sources: sourceRows.map((row) => ({ source: row.source, total: Number(row.n) })),
  };

  return { dataset, summary, questions, questionnaire };
}

/* ------------------------------------------------------------------ */
/* Individual analyses                                                */
/* ------------------------------------------------------------------ */

/** Correlation matrix over the requested variables, defaulting to the spec set. */
export function runCorrelation(
  dataset: Dataset,
  requested?: string[],
): CorrelationMatrixResult | null {
  const candidates = requested && requested.length >= 2 ? requested : DEFAULT_CORRELATION_VARIABLES;
  const available = candidates.filter((name) => {
    const variable = dataset.by_name.get(name);
    if (!variable) return false;
    // A variable with no variance cannot correlate with anything.
    const present = variable.values.filter((value) => value !== null);
    return present.length >= 4 && new Set(present).size > 1;
  });

  if (available.length < 2) return null;
  return correlationMatrixWithTests(dataset, available);
}

/**
 * Regression block.
 *
 * The specification asks for a linear model on UI (§25) and, separately, insists
 * that ordinal outcomes must not be forced through OLS (§26). Both are honoured:
 * the linear model is always produced, the ordinal model is produced whenever the
 * outcome is ordinal, and the block states which one should be treated as
 * primary and why. Silently picking one would hide the choice from the reader.
 */
export function runRegression(
  dataset: Dataset,
  dependentName: string = DEFAULT_REGRESSION_DEPENDENT,
  predictorNames: string[] = DEFAULT_REGRESSION_PREDICTORS,
): RegressionBlock | null {
  if (!dataset.by_name.has(dependentName)) return null;

  const predictors = predictorNames.filter((name) => dataset.by_name.has(name));
  if (predictors.length === 0) return null;

  const autoSelection = chooseRegressionModel(dataset, dependentName);
  const ols = olsRegression(dataset, dependentName, predictors);

  const ordinal =
    autoSelection.model === 'ordinal_logit'
      ? ordinalLogistic(dataset, dependentName, predictors)
      : null;

  const recommendation =
    autoSelection.model === 'ordinal_logit'
      ? `因变量 ${dependentName} 为有序分类变量，建议以有序 Logistic 回归（比例优势模型）为主要结论；` +
        '同时给出线性回归结果供对照，但线性模型对有序因变量会违反等距假设，并可能产生超出取值范围的预测值。'
      : `因变量 ${dependentName} 的测量层次适合线性模型，以 OLS 结果为主要结论。`;

  return { auto_selection: autoSelection, ols, ordinal, recommendation };
}

/**
 * Group comparisons for the requested dependent variables against one factor.
 *
 * The screening rule decides which estimator is *recommended*; the other is
 * still returned, because hiding it would make the conclusion impossible to
 * check.
 */
export function runComparisons(
  dataset: Dataset,
  factorName: string = DEFAULT_COMPARISON_FACTOR,
  dependentNames: string[] = DEFAULT_COMPARISON_DEPENDENTS,
): ComparisonResult[] {
  const factor = dataset.by_name.get(factorName);
  if (!factor) return [];

  const results: ComparisonResult[] = [];

  for (const dependentName of dependentNames) {
    const dependent = dataset.by_name.get(dependentName);
    if (!dependent) continue;

    const present = dependent.values.filter((value) => value !== null);
    if (present.length < 6 || new Set(present).size < 2) continue;

    const anova = oneWayAnova(dataset, dependentName, factorName);
    const kruskal = kruskalWallis(dataset, dependentName, factorName);

    const groupCodes = [...new Set(
      factor.values
        .filter((value): value is number => value !== null)
        .map((value) => Math.round(value)),
    )].sort((a, b) => a - b);

    let mannWhitney: MannWhitneyResult | null = null;
    if (groupCodes.length === 2) {
      const [firstCode, secondCode] = groupCodes as [number, number];
      const first: number[] = [];
      const second: number[] = [];
      for (let index = 0; index < dependent.values.length; index += 1) {
        const dependentValue = dependent.values[index];
        const factorValue = factor.values[index];
        if (dependentValue == null || factorValue == null) continue;
        if (Math.round(factorValue) === firstCode) first.push(dependentValue);
        else if (Math.round(factorValue) === secondCode) second.push(dependentValue);
      }
      if (first.length >= 3 && second.length >= 3) {
        mannWhitney = mannWhitneyU(first, second, {
          a: factor.value_labels[String(firstCode)] ?? `组 ${firstCode}`,
          b: factor.value_labels[String(secondCode)] ?? `组 ${secondCode}`,
        });
      }
    }

    const allGroupsAcceptable = anova.groups.every((group) => group.n >= 20);
    const noDistributionWarning = !anova.warnings.some((warning) => warning.includes('方差不齐'));

    results.push({
      dependent: dependentName,
      dependent_label: dependent.label,
      factor: factorName,
      factor_label: factor.label,
      groups: groupCodes.length,
      anova,
      mann_whitney: mannWhitney,
      kruskal_wallis: kruskal,
      recommended: allGroupsAcceptable && noDistributionWarning ? 'parametric' : 'nonparametric',
      recommendation_reason:
        allGroupsAcceptable && noDistributionWarning
          ? '各组样本量与方差齐性未触发警告，以参数检验（ANOVA）为主要结论，非参数检验作为稳健性对照。'
          : '数据触发了组样本量或方差齐性警告，建议以 Kruskal–Wallis 检验为主要结论，以降低对分布假设的依赖。',
      screening: groupCodes.map((code) => {
        const label = factor.value_labels[String(code)] ?? `类别 ${code}`;
        const values: number[] = [];
        for (let index = 0; index < factor.values.length; index += 1) {
          const factorValue = factor.values[index];
          const dependentValue = dependent.values[index];
          if (factorValue == null || dependentValue == null) continue;
          if (Math.round(factorValue) === code) values.push(dependentValue);
        }

        if (values.length < 3) {
          return {
            variable: dependentName,
            group: label,
            n: values.length,
            skewness: null,
            acceptable: false,
            reason: '样本量过少，无法评估分布形态。',
          };
        }

        const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
        const m2 = values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / values.length;
        const m3 = values.reduce((sum, value) => sum + (value - mean) ** 3, 0) / values.length;
        const skewness = m2 > 0 ? m3 / m2 ** 1.5 : 0;
        const acceptable = Math.abs(skewness) <= 1 || values.length >= 30;

        return {
          variable: dependentName,
          group: label,
          n: values.length,
          skewness: Math.round(skewness * 10000) / 10000,
          acceptable,
          reason: acceptable
            ? '偏度在可接受范围内（或样本量足够大）。'
            : '偏度超出可接受范围且样本量不足，参数检验的正态性假设可能不成立。',
        };
      }),
    });
  }

  return results;
}

/* ------------------------------------------------------------------ */
/* Bundle                                                             */
/* ------------------------------------------------------------------ */

export interface BuildBundleOptions {
  /** Persist each analysis into `analysis_results` for traceability. */
  persist?: boolean;
  hypothesisCodes?: string[];
}

/**
 * Build the complete analysis bundle.
 *
 * This is the single artefact the AI assistant, the report generator and the
 * competition analysis consume — none of them re-derive statistics, which is
 * what keeps every number they quote traceable to an engine run.
 */
export function buildAnalysisBundle(
  db: Db,
  projectId: string,
  researcherId: string,
  options: BuildBundleOptions = {},
): AnalysisBundle {
  const project = requireProject(db, projectId, researcherId);
  const loaded = loadAnalysableSample(db, projectId);
  const { dataset, summary, questions, questionnaire } = loaded;

  const descriptive = describeDataset(dataset);
  const reliability = reliabilityReport(dataset);
  const validity = buildValidity(dataset);
  const correlation = runCorrelation(dataset);
  const regression = runRegression(dataset);
  const comparisons = runComparisons(dataset, DEFAULT_COMPARISON_FACTOR, DEFAULT_COMPARISON_DEPENDENTS);

  const hypotheses = testAllHypotheses(
    dataset,
    options.hypothesisCodes
      ? DEFAULT_HYPOTHESES.filter((definition) => options.hypothesisCodes!.includes(definition.code))
      : DEFAULT_HYPOTHESES,
  );

  const measures = dataset.variables.filter((variable) => variable.data_type !== 'text');

  const bundle: AnalysisBundle = {
    engine_version: ANALYSIS_ENGINE_VERSION,
    generated_at: nowIso(),
    project: { id: project.id, title: project.title },
    questionnaire: questionnaire
      ? {
          id: questionnaire.id,
          title: questionnaire.title,
          version: questionnaire.version,
          question_count: questions.filter((question) => question.question_type !== 'page_break').length,
        }
      : null,
    sample: summary,
    dataset_summary: {
      n_respondents: dataset.n_respondents,
      variable_count: dataset.variables.length,
      derived_variable_count: dataset.variables.filter((variable) => variable.is_derived).length,
      empty_variables: dataset.empty_variables,
      variables: measures.map((variable) => {
        const stats = descriptive.variables.find((item) => item.variable === variable.name);
        return {
          name: variable.name,
          label: variable.label,
          data_type: variable.data_type,
          n: stats?.n ?? 0,
          missing: stats?.missing ?? 0,
        };
      }),
      composites: dataset.variables
        .filter((variable) => variable.is_derived && variable.sources.length > 1)
        .map((variable) => ({
          name: variable.name,
          label: variable.label,
          sources: variable.sources,
        })),
    },
    descriptive,
    reliability,
    validity,
    correlation,
    regression,
    comparisons,
    hypotheses,
    caveats: buildCaveats(descriptive, summary, comparisons, validity),
  };

  if (options.persist !== false) persistBundle(db, projectId, questionnaire?.id ?? null, researcherId, bundle);

  return bundle;
}

/** Validity analysis (KMO, Bartlett, EFA per declared scale). */
function buildValidity(dataset: Dataset): ValidityReport {
  return validityReport(dataset);
}
/** Statements that must accompany any downstream use of the bundle. */
function buildCaveats(
  descriptive: DescriptiveReport,
  summary: SampleSummary,
  comparisons: ComparisonResult[],
  validity: ValidityReport,
): string[] {
  const caveats: string[] = [
    '本研究采用横截面问卷调查数据，所有关联结论均为变量间的共变关系，不能据此推断因果关系。',
    `分析基于 ${summary.analysable} 份已完成且未被排除的样本；各统计量另有其自身的有效 n，解读时应以各结果中报告的 n 为准。`,
    '缺失值未做插补，均采用整例删除；因此不同分析的有效样本量可能不同。',
  ];

  if (summary.excluded > 0) {
    caveats.push(
      `分析已排除 ${summary.excluded} 份由研究者人工判定为不适用的样本；排除原因记录在质量与样本审核模块中，` +
        '对应的排除标准应在方法部分如实报告。',
    );
  }
  if (summary.analysable < 100) {
    caveats.push(`有效样本量 ${summary.analysable} 偏小，参数估计与检验效力有限，结论的稳健性需进一步验证。`);
  }
  if (summary.analysable < (summary.completed ?? 0)) {
    caveats.push('部分已完成样本因在分析变量上存在缺失而被整例删除，未进入本次分析。');
  }

  const emptyVariables = descriptive.unusable_variables.map((item) => item.variable);
  if (emptyVariables.length > 0) {
    caveats.push(`以下变量没有任何有效作答，未参与分析：${emptyVariables.join('、')}。`);
  }

  if (validity.overall_kmo.overall === null) {
    caveats.push(
      '效度分析中的 KMO 无法计算（相关矩阵接近奇异或变量不足），本数据不宜直接进行因素分析。',
    );
  }

  const nonparametric = comparisons.filter((item) => item.recommended === 'nonparametric');
  if (nonparametric.length > 0) {
    caveats.push(
      `以下组间比较建议以非参数检验为主要结论（分布形态或组样本量触发警告）：` +
        `${nonparametric.map((item) => item.dependent).join('、')}。`,
    );
  }

  caveats.push(
    '所有统计量由平台的统计引擎计算，可由原始数据完全复现；AI 仅对统计结果进行解释，不参与计算，也不会修改任何数据。',
  );

  return caveats;
}

/* ------------------------------------------------------------------ */
/* Persistence                                                        */
/* ------------------------------------------------------------------ */

function persistAnalysis(
  db: Db,
  projectId: string,
  questionnaireId: string | null,
  researcherId: string,
  analysisType: string,
  parameters: unknown,
  result: unknown,
  sampleN: number | null,
): string {
  const id = newId();
  db.run(
    `INSERT INTO analysis_results
       (id, project_id, questionnaire_id, analysis_type, parameters, result_json, sample_n, engine_version, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id,
      projectId,
      questionnaireId,
      analysisType,
      JSON.stringify(parameters ?? {}),
      JSON.stringify(result ?? null),
      sampleN,
      ANALYSIS_ENGINE_VERSION,
      researcherId,
      nowIso(),
    ],
  );
  return id;
}

/** Persist the whole bundle plus one row per analysis, for reproducibility. */
function persistBundle(
  db: Db,
  projectId: string,
  questionnaireId: string | null,
  researcherId: string,
  bundle: AnalysisBundle,
): void {
  db.transaction(() => {
    persistAnalysis(db, projectId, questionnaireId, researcherId, 'descriptive', {}, bundle.descriptive, bundle.dataset_summary.n_respondents);
    persistAnalysis(db, projectId, questionnaireId, researcherId, 'reliability', {}, bundle.reliability, bundle.dataset_summary.n_respondents);
    persistAnalysis(db, projectId, questionnaireId, researcherId, 'validity', {}, bundle.validity, bundle.dataset_summary.n_respondents);
    if (bundle.correlation) {
      persistAnalysis(db, projectId, questionnaireId, researcherId, 'correlation', { variables: bundle.correlation.variables }, bundle.correlation, bundle.dataset_summary.n_respondents);
    }
    if (bundle.regression) {
      persistAnalysis(db, projectId, questionnaireId, researcherId, 'regression', { dependent: bundle.regression.ols?.dependent ?? null }, bundle.regression, bundle.regression.ols?.n ?? bundle.regression.ordinal?.n ?? null);
    }
    for (const comparison of bundle.comparisons) {
      persistAnalysis(db, projectId, questionnaireId, researcherId, 'group_comparison', { dependent: comparison.dependent, factor: comparison.factor }, comparison, comparison.anova?.groups.reduce((sum, group) => sum + group.n, 0) ?? null);
    }
    persistAnalysis(db, projectId, questionnaireId, researcherId, 'hypothesis_testing', {}, bundle.hypotheses, bundle.dataset_summary.n_respondents);
    // The bundle itself is stored last so a reader can always retrieve exactly
    // the input set the AI and report layers were given.
    persistAnalysis(db, projectId, questionnaireId, researcherId, 'bundle', {}, bundle, bundle.dataset_summary.n_respondents);
  });
}

export interface StoredAnalysis {
  id: string;
  analysis_type: string;
  engine_version: string;
  sample_n: number | null;
  created_at: string;
  parameters: unknown;
  result: unknown;
}

export function listStoredAnalyses(
  db: Db,
  projectId: string,
  researcherId: string,
  analysisType?: string,
): StoredAnalysis[] {
  requireProject(db, projectId, researcherId);
  const rows = db.all<{
    id: string;
    analysis_type: string;
    engine_version: string;
    sample_n: number | null;
    created_at: string;
    parameters: string | null;
    result_json: string;
  }>(
    analysisType
      ? 'SELECT * FROM analysis_results WHERE project_id = ? AND analysis_type = ? ORDER BY created_at DESC'
      : 'SELECT * FROM analysis_results WHERE project_id = ? ORDER BY created_at DESC',
    analysisType ? [projectId, analysisType] : [projectId],
  );

  return rows.map((row) => ({
    id: row.id,
    analysis_type: row.analysis_type,
    engine_version: row.engine_version,
    sample_n: row.sample_n,
    created_at: row.created_at,
    parameters: parseJson<unknown>(row.parameters, {}),
    result: parseJson<unknown>(row.result_json, null),
  }));
}

/** Retrieve the most recent persisted bundle. */
export function getLatestBundle(
  db: Db,
  projectId: string,
  researcherId: string,
): AnalysisBundle | null {
  const rows = listStoredAnalyses(db, projectId, researcherId, 'bundle');
  return (rows[0]?.result as AnalysisBundle | undefined) ?? null;
}
