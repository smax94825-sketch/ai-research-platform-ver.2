/**
 * Migration 001 — initial schema.
 *
 * The schema is written in portable SQL (TEXT/INTEGER/REAL, no engine-specific
 * types) so the same DDL runs on SQLite for local research use and on
 * PostgreSQL for a shared deployment. Timestamps are stored as ISO-8601 UTC
 * strings; JSON payloads are stored as TEXT and (de)serialised in the
 * repository layer.
 *
 * Tables beyond PHASE 1/2 (respondents, responses, quality_flags,
 * analysis_results, research_reports, questionnaire_snapshots) are created now
 * so that later phases add behaviour without a destructive migration.
 */

export const MIGRATION_001_INIT = `
-- ------------------------------------------------------------------ --
-- Researchers / authentication                                       --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS researchers (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  email           TEXT NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  affiliation     TEXT,
  role            TEXT NOT NULL DEFAULT 'researcher',
  -- Incremented on logout / password change so issued JWTs can be revoked.
  token_version   INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL
);

-- ------------------------------------------------------------------ --
-- Research projects                                                  --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS research_projects (
  id                  TEXT PRIMARY KEY,
  researcher_id       TEXT NOT NULL REFERENCES researchers(id) ON DELETE CASCADE,
  title               TEXT NOT NULL,
  description         TEXT,
  background          TEXT,
  objectives          TEXT,
  research_questions  TEXT NOT NULL DEFAULT '[]',
  hypotheses          TEXT NOT NULL DEFAULT '[]',
  target_population   TEXT,
  target_sample_size  INTEGER,
  start_date          TEXT,
  end_date            TEXT,
  status              TEXT NOT NULL DEFAULT 'draft',
  quota_config        TEXT,
  settings            TEXT,
  created_at          TEXT NOT NULL,
  updated_at          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_projects_researcher ON research_projects(researcher_id);

-- ------------------------------------------------------------------ --
-- Questionnaires (versioned; one current version per project)         --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS questionnaires (
  id            TEXT PRIMARY KEY,
  project_id    TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  description   TEXT,
  version       TEXT NOT NULL DEFAULT 'V1.0',
  status        TEXT NOT NULL DEFAULT 'draft',
  share_token   TEXT UNIQUE,
  is_current    INTEGER NOT NULL DEFAULT 1,
  -- Set once the first response arrives; further edits require a new version.
  locked        INTEGER NOT NULL DEFAULT 0,
  published_at  TEXT,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_questionnaires_project ON questionnaires(project_id);

-- Immutable snapshots taken at publish time, so a response can always be
-- traced back to the exact instrument that produced it.
CREATE TABLE IF NOT EXISTS questionnaire_snapshots (
  id                TEXT PRIMARY KEY,
  questionnaire_id  TEXT NOT NULL REFERENCES questionnaires(id) ON DELETE CASCADE,
  version           TEXT NOT NULL,
  label             TEXT,
  snapshot_json     TEXT NOT NULL,
  question_count    INTEGER NOT NULL DEFAULT 0,
  created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_snapshots_questionnaire ON questionnaire_snapshots(questionnaire_id);

-- ------------------------------------------------------------------ --
-- Questions                                                          --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS questions (
  id                TEXT PRIMARY KEY,
  questionnaire_id  TEXT NOT NULL REFERENCES questionnaires(id) ON DELETE CASCADE,
  question_code     TEXT NOT NULL,
  question_text     TEXT NOT NULL DEFAULT '',
  question_type     TEXT NOT NULL,
  options           TEXT NOT NULL DEFAULT '{}',
  required          INTEGER NOT NULL DEFAULT 1,
  dimension         TEXT,
  variable_name     TEXT,
  sort_order        INTEGER NOT NULL DEFAULT 0,
  section           TEXT,
  help_text         TEXT,
  logic             TEXT,
  scoring_rule      TEXT,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_questions_questionnaire ON questions(questionnaire_id, sort_order);
CREATE UNIQUE INDEX IF NOT EXISTS idx_questions_code ON questions(questionnaire_id, question_code);

-- ------------------------------------------------------------------ --
-- Responses (PHASE 3+)                                               --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS respondents (
  id               TEXT PRIMARY KEY,
  questionnaire_id TEXT NOT NULL REFERENCES questionnaires(id) ON DELETE CASCADE,
  project_id       TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  anonymous_id     TEXT NOT NULL,
  source           TEXT NOT NULL DEFAULT 'direct',
  started_at       TEXT NOT NULL,
  completed_at     TEXT,
  duration_seconds INTEGER,
  status           TEXT NOT NULL DEFAULT 'in_progress',
  quality_score    REAL,
  -- Salted hash only; raw IP is never stored.
  ip_hash          TEXT,
  user_agent       TEXT,
  created_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_respondents_questionnaire ON respondents(questionnaire_id);
CREATE INDEX IF NOT EXISTS idx_respondents_project ON respondents(project_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_respondents_anon ON respondents(questionnaire_id, anonymous_id);

CREATE TABLE IF NOT EXISTS responses (
  id             TEXT PRIMARY KEY,
  respondent_id  TEXT NOT NULL REFERENCES respondents(id) ON DELETE CASCADE,
  question_id    TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  question_code  TEXT NOT NULL,
  answer         TEXT,
  created_at     TEXT NOT NULL,
  updated_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_responses_respondent ON responses(respondent_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_responses_unique ON responses(respondent_id, question_id);

-- Data-quality findings. Flags are advisory: the platform never deletes a
-- respondent automatically, a researcher decides.
CREATE TABLE IF NOT EXISTS quality_flags (
  id             TEXT PRIMARY KEY,
  respondent_id  TEXT NOT NULL REFERENCES respondents(id) ON DELETE CASCADE,
  project_id     TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  rule_code      TEXT NOT NULL,
  severity       TEXT NOT NULL DEFAULT 'warning',
  detail         TEXT,
  resolved       INTEGER NOT NULL DEFAULT 0,
  resolved_note  TEXT,
  created_at     TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_flags_project ON quality_flags(project_id);

-- ------------------------------------------------------------------ --
-- Analysis / AI / reports (PHASE 5+)                                 --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS analysis_results (
  id               TEXT PRIMARY KEY,
  project_id       TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  questionnaire_id TEXT REFERENCES questionnaires(id) ON DELETE SET NULL,
  analysis_type    TEXT NOT NULL,
  parameters       TEXT NOT NULL DEFAULT '{}',
  result_json      TEXT NOT NULL,
  sample_n         INTEGER,
  engine_version   TEXT NOT NULL DEFAULT '1.0.0',
  created_by       TEXT REFERENCES researchers(id) ON DELETE SET NULL,
  created_at       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_analysis_project ON analysis_results(project_id, analysis_type);

CREATE TABLE IF NOT EXISTS research_reports (
  id          TEXT PRIMARY KEY,
  project_id  TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  report_type TEXT NOT NULL DEFAULT 'research_report',
  title       TEXT NOT NULL,
  content     TEXT NOT NULL,
  sections    TEXT,
  created_by  TEXT REFERENCES researchers(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reports_project ON research_reports(project_id);

-- ------------------------------------------------------------------ --
-- Audit trail                                                        --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS audit_logs (
  id            TEXT PRIMARY KEY,
  researcher_id TEXT REFERENCES researchers(id) ON DELETE SET NULL,
  action        TEXT NOT NULL,
  entity        TEXT,
  entity_id     TEXT,
  detail        TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_researcher ON audit_logs(researcher_id, created_at);
`;

export const MIGRATION_002_COLLECTION = `
-- ------------------------------------------------------------------ --
-- PHASE 3: respondent sessions, consent and researcher review        --
-- ------------------------------------------------------------------ --

-- Per-respondent session credential. The public survey client stores this and
-- sends it with every autosave, so a respondent can resume after a refresh
-- without the platform ever knowing who they are. It is a bearer secret, kept
-- distinct from the row id so that ids can be logged/displayed safely.
ALTER TABLE respondents ADD COLUMN session_token TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS idx_respondents_session_token ON respondents(session_token);

-- Consent must be recorded explicitly: the ethics statement requires that
-- participation is voluntary and informed, and "they clicked start" is not by
-- itself evidence that consent was captured.
ALTER TABLE respondents ADD COLUMN consent_given_at TEXT;

-- Resume support: which question the respondent was on, and how far they got.
ALTER TABLE respondents ADD COLUMN current_question_code TEXT;
ALTER TABLE respondents ADD COLUMN answered_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE respondents ADD COLUMN last_activity_at TEXT;
ALTER TABLE respondents ADD COLUMN completed_via TEXT;

-- Researcher review. The platform NEVER auto-deletes a sample; a human decides.
ALTER TABLE respondents ADD COLUMN review_status TEXT NOT NULL DEFAULT 'unreviewed';
ALTER TABLE respondents ADD COLUMN review_note TEXT;
ALTER TABLE respondents ADD COLUMN reviewed_at TEXT;
ALTER TABLE respondents ADD COLUMN reviewed_by TEXT REFERENCES researchers(id) ON DELETE SET NULL;

-- Channel reporting (spec §16) groups by (project, source).
CREATE INDEX IF NOT EXISTS idx_respondents_source ON respondents(project_id, source);
CREATE INDEX IF NOT EXISTS idx_respondents_status ON respondents(questionnaire_id, status);
`;

export const MIGRATION_003_QUALITY = `
-- ------------------------------------------------------------------ --
-- PHASE 4: data quality engine                                       --
-- ------------------------------------------------------------------ --

-- Each flag now records how many points it cost and which engine version
-- produced it, so a score can always be explained and reproduced. Scores are
-- deliberately NOT stable across engine versions: changing a threshold must not
-- silently rewrite history, so the version travels with the value.
ALTER TABLE quality_flags ADD COLUMN score_impact REAL NOT NULL DEFAULT 0;
ALTER TABLE quality_flags ADD COLUMN label TEXT;
ALTER TABLE quality_flags ADD COLUMN engine_version TEXT NOT NULL DEFAULT '1.0.0';

CREATE INDEX IF NOT EXISTS idx_flags_respondent ON quality_flags(respondent_id);

-- Summary of the latest evaluation, kept on the respondent row so the sample
-- list can filter and sort without joining the flags table.
ALTER TABLE respondents ADD COLUMN quality_severity TEXT;
ALTER TABLE respondents ADD COLUMN quality_computed_at TEXT;
ALTER TABLE respondents ADD COLUMN quality_engine_version TEXT;

-- Canonical answer-vector signature, computed once at completion.
-- Storing it turns duplicate-submission detection from an O(n x m) scan into a
-- single GROUP BY, which matters because it runs on every submission.
ALTER TABLE respondents ADD COLUMN answer_signature TEXT;
CREATE INDEX IF NOT EXISTS idx_respondents_signature ON respondents(project_id, answer_signature);
`;

export const MIGRATION_004_AI = `
-- ------------------------------------------------------------------ --
-- PHASE 7: AI interpretation audit trail                             --
-- ------------------------------------------------------------------ --

-- Every interaction with the language model is recorded, including the ones
-- that FAILED or ran in degraded mode. Two reasons: a statement in a report must
-- be traceable to the exact prompt and raw reply that produced it, and a rejected
-- (hallucinated) claim has to remain visible after the fact instead of vanishing
-- with the response. The raw response is stored verbatim, so a later audit can
-- re-run validation without having to trust this code path.
CREATE TABLE IF NOT EXISTS ai_interactions (
  id                 TEXT PRIMARY KEY,
  project_id         TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  researcher_id      TEXT REFERENCES researchers(id) ON DELETE SET NULL,
  -- Version of the statistical engine whose bundle was the source of truth.
  engine_version     TEXT NOT NULL,
  -- 'live' when the model answered, 'degraded' when it could not be used.
  mode               TEXT NOT NULL,
  model              TEXT NOT NULL,
  -- Hash of the exact prompt sent, so identical inputs can be recognised.
  prompt_hash        TEXT NOT NULL,
  prompt_version     TEXT NOT NULL DEFAULT '1.0.0',
  -- Token accounting as reported by the provider; NULL when it did not report.
  prompt_tokens      INTEGER,
  completion_tokens  INTEGER,
  total_tokens       INTEGER,
  duration_ms        INTEGER,
  -- Scope actually requested (section / hypothesis code), for reproducibility.
  scope              TEXT NOT NULL DEFAULT '{}',
  raw_response       TEXT,
  -- The validated, layered result exactly as it was returned to the caller.
  result_json        TEXT NOT NULL,
  rejected_claims    TEXT NOT NULL DEFAULT '[]',
  rejected_count     INTEGER NOT NULL DEFAULT 0,
  error_code         TEXT,
  error_message      TEXT,
  created_at         TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_project ON ai_interactions(project_id, created_at);
`;

export const MIGRATION_005_INSIGHT = `
-- ------------------------------------------------------------------ --
-- PHASE 9: competition (entrepreneurship) insight reports            --
-- ------------------------------------------------------------------ --

-- The competition report is stored whole, together with the analysis run it was
-- derived from. It is a pure function of that bundle, so keeping the pair means
-- every business claim in it can be re-derived and audited later instead of
-- being taken on trust.
CREATE TABLE IF NOT EXISTS insight_reports (
  id                       TEXT PRIMARY KEY,
  project_id               TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
  questionnaire_id         TEXT,
  -- Which analysis run the report was derived from (both fields travel in the bundle).
  analysis_engine_version  TEXT,
  analysis_generated_at    TEXT,
  engine_version           TEXT NOT NULL,
  sample_n                 INTEGER,
  blocks_total             INTEGER NOT NULL DEFAULT 0,
  blocks_available         INTEGER NOT NULL DEFAULT 0,
  -- Per-project monotonic sequence. created_at alone cannot order two runs made
  -- in the same millisecond, and an audit trail whose order is ambiguous is not
  -- an audit trail; a sequence column is also portable, unlike SQLite rowid.
  run_seq                  INTEGER NOT NULL DEFAULT 1,
  report_json              TEXT NOT NULL,
  created_by               TEXT REFERENCES researchers(id) ON DELETE SET NULL,
  created_at               TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_insight_reports_project
  ON insight_reports(project_id, run_seq DESC);
`;

export const MIGRATIONS = [
  { id: '001_init', name: 'Initial schema (researchers, projects, questionnaires, questions, responses)', sql: MIGRATION_001_INIT },
  { id: '002_collection', name: 'PHASE 3 respondent sessions, consent, progress and researcher review', sql: MIGRATION_002_COLLECTION },
  { id: '003_quality', name: 'PHASE 4 data quality engine (flag scoring, signatures) and quota support', sql: MIGRATION_003_QUALITY },
  { id: '004_ai', name: 'PHASE 7 AI interpretation layer: ai_interactions audit trail', sql: MIGRATION_004_AI },
  { id: '005_insight', name: 'PHASE 9 competition insight reports (persisted, bundle-traceable, auditable)', sql: MIGRATION_005_INSIGHT },
] as const;