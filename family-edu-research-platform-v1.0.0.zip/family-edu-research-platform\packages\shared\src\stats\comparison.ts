/**
 * Group comparison (PHASE 5).
 *
 * The engine reports BOTH a parametric and a non-parametric result for every
 * comparison and states which one it recommends and why. Presenting only one
 * would hide the choice; presenting both lets a reviewer check whether the
 * conclusion survives the distributional assumption.
 */

import {
  chiSquareUpperTailP,
  fUpperTailP,
  normalCdf,
  roundTo,
  studentTQuantile,
  studentTTwoTailedP,
} from './special.js';
import {
  classifyCohensD,
  classifyCramersV,
  classifyEtaSquared,
  meanDifference,
  ranks,
  type EffectMagnitude,
} from './association.js';
import type { Dataset, DatasetVariable } from './dataset.js';
import { completeCases } from './dataset.js';

/* ------------------------------------------------------------------ */
/* Assumption screening                                               */
/* ------------------------------------------------------------------ */

export interface NormalityScreening {
  variable: string;
  group?: string;
  n: number;
  skewness: number | null;
  kurtosis: number | null;
  /** True when the group passes the engine's screening rule. */
  acceptable: boolean;
  reason: string;
}

/**
 * Screen a group for the normality assumption using its shape rather than a
 * formal test.
 *
 * Rationale: Shapiro–Wilk on large samples flags trivial departures, and on
 * small samples has almost no power — so the screening is based on skewness /
 * kurtosis plus the central-limit heuristic, and the rule is stated explicitly
 * so it can be challenged. The non-parametric result is always reported
 * alongside, so the assumption never silently decides the conclusion.
 */
export function screenGroup(values: number[], variable: string, group?: string): NormalityScreening {
  const n = values.length;
  if (n < 3) {
    return {
      variable,
      group,
      n,
      skewness: null,
      kurtosis: null,
      acceptable: false,
      reason: `n = ${n}，样本过少，无法评估分布形态，建议采用非参数检验。`,
    };
  }

  const mean = values.reduce((sum, value) => sum + value, 0) / n;
  let m2 = 0;
  let m3 = 0;
  let m4 = 0;
  for (const value of values) {
    const deviation = value - mean;
    m2 += deviation ** 2;
    m3 += deviation ** 3;
    m4 += deviation ** 4;
  }
  m2 /= n;
  m3 /= n;
  m4 /= n;

  if (m2 === 0) {
    return {
      variable,
      group,
      n,
      skewness: null,
      kurtosis: null,
      acceptable: false,
      reason: '该组无变异，无法进行对比检验。',
    };
  }

  const g1 = m3 / m2 ** 1.5;
  const g2 = m4 / m2 ** 2 - 3;
  const skewness = n > 2 ? (Math.sqrt(n * (n - 1)) / (n - 2)) * g1 : g1;
  const kurtosis = n > 3 ? ((n - 1) / ((n - 2) * (n - 3))) * ((n + 1) * g2 + 6) : g2;

  const withinShape = Math.abs(skewness) <= 1 && Math.abs(kurtosis) <= 2;
  const largeEnough = n >= 30;

  return {
    variable,
    group,
    n,
    skewness: roundTo(skewness, 4),
    kurtosis: roundTo(kurtosis, 4),
    acceptable: withinShape || largeEnough,
    reason: withinShape
      ? `偏度 ${roundTo(skewness, 3)}、峰度 ${roundTo(kurtosis, 3)} 在可接受范围内。`
      : largeEnough
        ? `偏度 ${roundTo(skewness, 3)}、峰度 ${roundTo(kurtosis, 3)} 偏离正态，但 n = ${n} ≥ 30，依据中心极限定理参数检验仍较稳健；同时报告非参数结果以供对照。`
        : `偏度 ${roundTo(skewness, 3)}、峰度 ${roundTo(kurtosis, 3)} 偏离正态且 n = ${n} < 30，建议以非参数检验为准。`,
  };
}

/* ------------------------------------------------------------------ */
/* Parametric comparison                                              */
/* ------------------------------------------------------------------ */

export interface TTestResult {
  method: 'student' | 'welch';
  group_a: string;
  group_b: string;
  n_a: number;
  n_b: number;
  mean_a: number;
  mean_b: number;
  sd_a: number;
  sd_b: number;
  mean_difference: number;
  t: number;
  degrees_of_freedom: number;
  p_value: number;
  ci_lower: number | null;
  ci_upper: number | null;
  cohens_d: number | null;
  hedges_g: number | null;
  effect_size: EffectMagnitude | null;
  /** Levene's test for equal variances, which decides Student vs Welch. */
  levene: { statistic: number; p_value: number; equal_variances: boolean } | null;
  interpretation: string;
}

function sampleStats(values: number[]): { n: number; mean: number; variance: number; sd: number } {
  const n = values.length;
  const mean = n > 0 ? values.reduce((sum, value) => sum + value, 0) / n : Number.NaN;
  const variance =
    n > 1 ? values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (n - 1) : 0;
  return { n, mean, variance, sd: Math.sqrt(variance) };
}

/**
 * Levene's test (median-centred, i.e. the Brown–Forsythe variant).
 *
 * Robustness to non-normality matters more than the classical mean-centred
 * version here, because questionnaire scales are frequently skewed.
 *
 * Accepts any number of groups, because testing only the first two groups of a
 * four-group comparison would report "equal variances" while saying nothing
 * about the other two — and that verdict is what decides whether the parametric
 * result may be trusted. `labels` is used only for the returned interpretation.
 */
export function leveneTest(
  groups: number[][],
  labels: string[],
): { statistic: number; p_value: number; equal_variances: boolean; degrees_of_freedom: number } | null {
  if (groups.length < 2) return null;
  if (groups.some((group) => group.length < 3)) return null;

  const transformed = groups.map((group) => {
    const sorted = [...group].sort((left, right) => left - right);
    const median =
      sorted.length % 2 === 1
        ? sorted[(sorted.length - 1) / 2]!
        : (sorted[sorted.length / 2 - 1]! + sorted[sorted.length / 2]!) / 2;
    return group.map((value) => Math.abs(value - median));
  });

  const k = transformed.length;
  const all = transformed.flat();
  const grandMean = all.reduce((sum, value) => sum + value, 0) / all.length;

  let numerator = 0;
  let denominator = 0;
  for (const group of transformed) {
    const mean = group.reduce((sum, value) => sum + value, 0) / group.length;
    numerator += group.length * (mean - grandMean) ** 2;
    for (const value of group) denominator += (value - mean) ** 2;
  }

  const df1 = k - 1;
  const df2 = all.length - k;
  if (df2 <= 0 || denominator === 0) return null;

  const statistic = (numerator / df1) / (denominator / df2);
  const pValue = fUpperTailP(statistic, df1, df2);

  return {
    statistic: roundTo(statistic, 4),
    p_value: roundTo(pValue, 6),
    equal_variances: pValue >= 0.05,
    degrees_of_freedom: df1,
  };
}

export function independentTTest(
  groupA: number[],
  groupB: number[],
  labels: { a: string; b: string },
  options: { confidence?: number } = {},
): TTestResult {
  const statsA = sampleStats(groupA);
  const statsB = sampleStats(groupB);
  const levene = leveneTest([groupA, groupB], [labels.a, labels.b]);
  const useStudent = levene === null ? true : levene.equal_variances;

  const difference = statsA.mean - statsB.mean;
  const confidence = options.confidence ?? 0.95;

  let t: number;
  let df: number;

  if (useStudent) {
    const pooledVariance =
      ((statsA.n - 1) * statsA.variance + (statsB.n - 1) * statsB.variance) /
      Math.max(statsA.n + statsB.n - 2, 1);
    const standardError = Math.sqrt(pooledVariance * (1 / statsA.n + 1 / statsB.n));
    t = standardError > 0 ? difference / standardError : Number.NaN;
    df = statsA.n + statsB.n - 2;
  } else {
    // Welch–Satterthwaite.
    const varianceA = statsA.variance / statsA.n;
    const varianceB = statsB.variance / statsB.n;
    const standardError = Math.sqrt(varianceA + varianceB);
    t = standardError > 0 ? difference / standardError : Number.NaN;
    const denominator =
      varianceA ** 2 / Math.max(statsA.n - 1, 1) + varianceB ** 2 / Math.max(statsB.n - 1, 1);
    df = denominator > 0 ? (varianceA + varianceB) ** 2 / denominator : statsA.n + statsB.n - 2;
  }

  const pValue = Number.isFinite(t) ? studentTTwoTailedP(t, Math.max(df, 1)) : Number.NaN;
  const critical = studentTQuantile(1 - (1 - confidence) / 2, Math.max(df, 1));

  let standardErrorForCi: number;
  if (useStudent) {
    const pooledVariance =
      ((statsA.n - 1) * statsA.variance + (statsB.n - 1) * statsB.variance) /
      Math.max(statsA.n + statsB.n - 2, 1);
    standardErrorForCi = Math.sqrt(pooledVariance * (1 / statsA.n + 1 / statsB.n));
  } else {
    standardErrorForCi = Math.sqrt(statsA.variance / statsA.n + statsB.variance / statsB.n);
  }

  const meanDiff = meanDifference(groupA, groupB, labels, options);

  return {
    method: useStudent ? 'student' : 'welch',
    group_a: labels.a,
    group_b: labels.b,
    n_a: statsA.n,
    n_b: statsB.n,
    mean_a: roundTo(statsA.mean, 4),
    mean_b: roundTo(statsB.mean, 4),
    sd_a: roundTo(statsA.sd, 4),
    sd_b: roundTo(statsB.sd, 4),
    mean_difference: roundTo(difference, 4),
    t: roundTo(t, 4),
    degrees_of_freedom: roundTo(df, 4),
    p_value: Number.isFinite(pValue) ? roundTo(pValue, 6) : Number.NaN,
    ci_lower: Number.isFinite(standardErrorForCi)
      ? roundTo(difference - critical * standardErrorForCi, 4)
      : null,
    ci_upper: Number.isFinite(standardErrorForCi)
      ? roundTo(difference + critical * standardErrorForCi, 4)
      : null,
    cohens_d: meanDiff.cohens_d,
    hedges_g: meanDiff.hedges_g,
    effect_size: meanDiff.effect_size,
    levene,
    interpretation:
      `${useStudent ? 'Student t 检验（方差齐性成立）' : 'Welch t 检验（方差不齐，已校正自由度）'}：` +
      `t(${roundTo(df, 2)}) = ${roundTo(t, 3)}, p = ${Number.isFinite(pValue) ? (pValue < 0.001 ? '< .001' : roundTo(pValue, 3)) : 'NA'}。` +
      `${labels.a}（M = ${roundTo(statsA.mean, 3)}, SD = ${roundTo(statsA.sd, 3)}, n = ${statsA.n}）与 ` +
      `${labels.b}（M = ${roundTo(statsB.mean, 3)}, SD = ${roundTo(statsB.sd, 3)}, n = ${statsB.n}）。` +
      `${meanDiff.effect_size ? ` ${meanDiff.effect_size.text}。` : ''}` +
      '组间差异反映的是群体关联，横截面数据不能据此推断因果。',
  };
}

/* ------------------------------------------------------------------ */
/* One-way ANOVA                                                      */
/* ------------------------------------------------------------------ */

export interface AnovaGroupDescriptive {
  group: string;
  n: number;
  mean: number;
  sd: number;
  minimum: number;
  maximum: number;
}

export interface AnovaResult {
  dependent: string;
  dependent_label: string;
  factor: string;
  groups: AnovaGroupDescriptive[];
  /** Between-groups sum of squares. */
  ss_between: number;
  ss_within: number;
  ss_total: number;
  df_between: number;
  df_within: number;
  ms_between: number;
  ms_within: number;
  f: number;
  p_value: number;
  eta_squared: number | null;
  partial_eta_squared: number | null;
  omega_squared: number | null;
  effect_size: EffectMagnitude | null;
  /** Post-hoc pairwise Welch t tests with Holm adjustment. */
  post_hoc: {
    group_a: string;
    group_b: string;
    mean_difference: number;
    t: number;
    p_raw: number;
    p_adjusted: number;
    significant: boolean;
  }[];
  homogeneity: {
    statistic: number;
    p_value: number;
    equal_variances: boolean;
    degrees_of_freedom: number;
  } | null;
  interpretation: string;
  warnings: string[];
}

/** Holm–Bonferroni adjustment, which controls the family-wise error rate. */
function holmAdjust(pValues: number[]): number[] {
  const indexed = pValues.map((value, index) => ({ value, index }));
  indexed.sort((left, right) => left.value - right.value);

  const adjusted = new Array<number>(pValues.length).fill(1);
  let running = 0;
  for (let rank = 0; rank < indexed.length; rank += 1) {
    const entry = indexed[rank]!;
    const candidate = Math.min(1, (indexed.length - rank) * entry.value);
    running = Math.max(running, candidate);
    adjusted[entry.index] = running;
  }
  return adjusted;
}

export function oneWayAnova(
  dataset: Dataset,
  dependentName: string,
  factorName: string,
): AnovaResult {
  const dependent = dataset.by_name.get(dependentName);
  const factor = dataset.by_name.get(factorName);

  const empty = (reason: string): AnovaResult => ({
    dependent: dependentName,
    dependent_label: dependent?.label ?? dependentName,
    factor: factorName,
    groups: [],
    ss_between: 0,
    ss_within: 0,
    ss_total: 0,
    df_between: 0,
    df_within: 0,
    ms_between: 0,
    ms_within: 0,
    f: 0,
    p_value: Number.NaN,
    eta_squared: null,
    partial_eta_squared: null,
    omega_squared: null,
    effect_size: null,
    post_hoc: [],
    homogeneity: null,
    interpretation: reason,
    warnings: [reason],
  });

  if (!dependent || !factor) return empty('因变量或分组变量不存在于数据集中。');

  const selection = completeCases(dataset, [dependentName, factorName]);
  if (selection.n < 4) return empty(`有效样本 n = ${selection.n} 过小，无法进行方差分析。`);

  const responses = selection.columns[0]!;
  const groupCodes = selection.columns[1]!;

  const byGroup = new Map<number, number[]>();
  for (let index = 0; index < responses.length; index += 1) {
    const code = groupCodes[index]!;
    const bucket = byGroup.get(code) ?? [];
    bucket.push(responses[index]!);
    byGroup.set(code, bucket);
  }

  const orderedCodes = [...byGroup.keys()].sort((a, b) => a - b);
  if (orderedCodes.length < 2) return empty('分组变量在该子样本中只有一个水平，无法进行组间比较。');

  const labelFor = (code: number): string => factor.value_labels[String(Math.round(code))] ?? `组 ${code}`;

  const groups: AnovaGroupDescriptive[] = orderedCodes.map((code) => {
    const values = byGroup.get(code)!;
    const stats = sampleStats(values);
    const sorted = [...values].sort((a, b) => a - b);
    return {
      group: labelFor(code),
      n: stats.n,
      mean: roundTo(stats.mean, 4),
      sd: roundTo(stats.sd, 4),
      minimum: sorted[0]!,
      maximum: sorted[sorted.length - 1]!,
    };
  });

  const allValues = responses;
  const grandMean = allValues.reduce((sum, value) => sum + value, 0) / allValues.length;

  let ssBetween = 0;
  let ssWithin = 0;
  for (const code of orderedCodes) {
    const values = byGroup.get(code)!;
    const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
    ssBetween += values.length * (mean - grandMean) ** 2;
    for (const value of values) ssWithin += (value - mean) ** 2;
  }
  const ssTotal = ssBetween + ssWithin;

  const dfBetween = orderedCodes.length - 1;
  const dfWithin = allValues.length - orderedCodes.length;
  const msBetween = dfBetween > 0 ? ssBetween / dfBetween : Number.NaN;
  const msWithin = dfWithin > 0 ? ssWithin / dfWithin : Number.NaN;
  const f = msWithin > 0 ? msBetween / msWithin : Number.NaN;
  const pValue = Number.isFinite(f) ? fUpperTailP(f, dfBetween, dfWithin) : Number.NaN;

  const etaSquared = ssTotal > 0 ? ssBetween / ssTotal : null;
  const partialEtaSquared = ssTotal > 0 ? ssBetween / (ssBetween + ssWithin) : null;
  const omegaSquared =
    msWithin > 0 && dfBetween > 0
      ? (ssBetween - dfBetween * msWithin) / (ssTotal + msWithin)
      : null;

  const warnings: string[] = [];
  // Homogeneity is assessed across ALL groups, not a pair: the verdict decides
  // whether the parametric result may be trusted for the whole comparison.
  const homogeneity = leveneTest(
    orderedCodes.map((code) => byGroup.get(code)!),
    orderedCodes.map((code) => labelFor(code)),
  );
  if (homogeneity === null) {
    warnings.push(
      '方差不齐性检验（Levene）无法计算：需要每个分组至少有 3 例有效作答。' +
        '在方差齐性未经验证的情况下，建议以 Kruskal–Wallis 非参数检验的结果为主要结论。',
    );
  } else if (!homogeneity.equal_variances) {
    warnings.push(
      'Levene 检验提示方差不齐，ANOVA 的方差齐性假设可能不成立，' +
        '建议同时参考 Welch ANOVA 或非参数 Kruskal–Wallis 检验的结果。',
    );
  }
  const smallGroups = groups.filter((group) => group.n < 20);
  if (smallGroups.length > 0) {
    warnings.push(
      `以下组的样本量小于 20：${smallGroups.map((group) => `${group.group}(${group.n})`).join('、')}，组间均值估计不够稳定。`,
    );
  }

  const postHoc: AnovaResult['post_hoc'] = [];
  const rawPValues: number[] = [];
  const pairsList: { a: number; b: number; meanDifference: number; t: number; p: number }[] = [];

  for (let i = 0; i < orderedCodes.length; i += 1) {
    for (let j = i + 1; j < orderedCodes.length; j += 1) {
      const valuesA = byGroup.get(orderedCodes[i]!)!;
      const valuesB = byGroup.get(orderedCodes[j]!)!;
      if (valuesA.length < 3 || valuesB.length < 3) continue;
      const statsA = sampleStats(valuesA);
      const statsB = sampleStats(valuesB);
      const varianceA = statsA.variance / statsA.n;
      const varianceB = statsB.variance / statsB.n;
      const standardError = Math.sqrt(varianceA + varianceB);
      if (!Number.isFinite(standardError) || standardError === 0) continue;
      const t = (statsA.mean - statsB.mean) / standardError;
      const denominator =
        varianceA ** 2 / (statsA.n - 1) + varianceB ** 2 / (statsB.n - 1);
      const df = denominator > 0 ? (varianceA + varianceB) ** 2 / denominator : statsA.n + statsB.n - 2;
      const p = studentTTwoTailedP(t, Math.max(df, 1));
      pairsList.push({ a: i, b: j, meanDifference: statsA.mean - statsB.mean, t, p });
      rawPValues.push(p);
    }
  }

  const adjusted = holmAdjust(rawPValues);
  pairsList.forEach((pair, index) => {
    postHoc.push({
      group_a: labelFor(orderedCodes[pair.a]!),
      group_b: labelFor(orderedCodes[pair.b]!),
      mean_difference: roundTo(pair.meanDifference, 4),
      t: roundTo(pair.t, 4),
      p_raw: roundTo(pair.p, 6),
      p_adjusted: roundTo(adjusted[index] ?? 1, 6),
      significant: (adjusted[index] ?? 1) < 0.05,
    });
  });

  const effect = etaSquared === null ? null : classifyEtaSquared(etaSquared);

  return {
    dependent: dependentName,
    dependent_label: dependent.label,
    factor: factorName,
    groups,
    ss_between: roundTo(ssBetween, 4),
    ss_within: roundTo(ssWithin, 4),
    ss_total: roundTo(ssTotal, 4),
    df_between: dfBetween,
    df_within: dfWithin,
    ms_between: roundTo(msBetween, 4),
    ms_within: roundTo(msWithin, 4),
    f: roundTo(f, 4),
    p_value: Number.isFinite(pValue) ? roundTo(pValue, 6) : Number.NaN,
    eta_squared: etaSquared === null ? null : roundTo(etaSquared, 4),
    partial_eta_squared: partialEtaSquared === null ? null : roundTo(partialEtaSquared, 4),
    omega_squared: omegaSquared === null ? null : roundTo(omegaSquared, 4),
    effect_size: effect,
    post_hoc: postHoc,
    homogeneity,
    interpretation:
      `单因素方差分析：因变量 ${dependent.label}，分组变量 ${factor.label}（${orderedCodes.length} 组），` +
      `F(${dfBetween}, ${dfWithin}) = ${roundTo(f, 3)}，` +
      `p ${Number.isFinite(pValue) ? (pValue < 0.001 ? '< .001' : `= ${roundTo(pValue, 3)}`) : '= NA'}，` +
      `n = ${allValues.length}。${effect ? ` ${effect.text}。` : ''}` +
      (postHoc.length > 0
        ? `多重比较采用 Welch t 检验并以 Holm 法校正，${postHoc.filter((pair) => pair.significant).length} 对差异达到显著。`
        : '') +
      '组间差异描述的是样本中的关联，不等同于分组变量造成了差异。',
    warnings,
  };
}

/* ------------------------------------------------------------------ */
/* Non-parametric comparison                                          */
/* ------------------------------------------------------------------ */

export interface MannWhitneyResult {
  group_a: string;
  group_b: string;
  n_a: number;
  n_b: number;
  /** Mann–Whitney U for group A. */
  u: number;
  /** U converted to the common U' for reporting the smaller value. */
  u_min: number;
  /** Normal approximation with tie and continuity correction. */
  z: number;
  p_value: number;
  /** Rank-biserial correlation, the effect size for U. */
  rank_biserial_r: number;
  effect_size: EffectMagnitude | null;
  median_a: number;
  median_b: number;
  mean_rank_a: number;
  mean_rank_b: number;
  /** True when a tie correction was applied. */
  tie_corrected: boolean;
  interpretation: string;
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  if (sorted.length === 0) return Number.NaN;
  return sorted.length % 2 === 1
    ? sorted[(sorted.length - 1) / 2]!
    : (sorted[sorted.length / 2 - 1]! + sorted[sorted.length / 2]!) / 2;
}

export function mannWhitneyU(
  groupA: number[],
  groupB: number[],
  labels: { a: string; b: string },
): MannWhitneyResult {
  const nA = groupA.length;
  const nB = groupB.length;
  const combined = [...groupA, ...groupB];
  const combinedRanks = ranks(combined);

  const ranksA = combinedRanks.slice(0, nA);
  const ranksB = combinedRanks.slice(nA);

  const sumRanksA = ranksA.reduce((sum, value) => sum + value, 0);
  const sumRanksB = ranksB.reduce((sum, value) => sum + value, 0);

  const uA = sumRanksA - (nA * (nA + 1)) / 2;
  const uB = sumRanksB - (nB * (nB + 1)) / 2;
  const u = Math.min(uA, uB);

  // Tie correction: reduce the variance of the rank sum.
  const counts = new Map<number, number>();
  for (const value of combined) counts.set(value, (counts.get(value) ?? 0) + 1);
  let tieSum = 0;
  for (const count of counts.values()) {
    if (count > 1) tieSum += count ** 3 - count;
  }
  const n = nA + nB;
  const tieCorrected = tieSum > 0;

  const meanU = (nA * nB) / 2;
  const varianceU = tieCorrected
    ? ((nA * nB) / 12) * (n + 1 - tieSum / (n * (n - 1)))
    : (nA * nB * (n + 1)) / 12;

  let z = varianceU > 0 ? (uA - meanU) / Math.sqrt(varianceU) : 0;
  // Continuity correction.
  if (varianceU > 0) {
    const correction = uA > meanU ? -0.5 : 0.5;
    z = (uA - meanU + correction) / Math.sqrt(varianceU);
  }

  const pValue = 2 * (1 - normalCdf(Math.abs(z)));
  const rankBiserial = nA * nB > 0 ? (2 * uA) / (nA * nB) - 1 : 0;

  return {
    group_a: labels.a,
    group_b: labels.b,
    n_a: nA,
    n_b: nB,
    u: roundTo(uA, 4),
    u_min: roundTo(u, 4),
    z: roundTo(z, 4),
    p_value: roundTo(pValue, 6),
    rank_biserial_r: roundTo(rankBiserial, 4),
    effect_size: classifyCohensD(rankBiserial * 2),
    median_a: roundTo(median(groupA), 4),
    median_b: roundTo(median(groupB), 4),
    mean_rank_a: roundTo(sumRanksA / Math.max(nA, 1), 4),
    mean_rank_b: roundTo(sumRanksB / Math.max(nB, 1), 4),
    tie_corrected: tieCorrected,
    interpretation:
      `Mann–Whitney U 检验（秩和检验）：U = ${roundTo(u, 3)}，Z = ${roundTo(z, 3)}（${tieCorrected ? '已做结点校正，' : ''}含连续性校正），` +
      `p = ${pValue < 0.001 ? '< .001' : roundTo(pValue, 3)}。` +
      `${labels.a} 中位数 ${roundTo(median(groupA), 3)}（n = ${nA}），${labels.b} 中位数 ${roundTo(median(groupB), 3)}（n = ${nB}）。` +
      `秩二列相关 r = ${roundTo(rankBiserial, 3)}。该检验比较的是分布位置，对正态性要求低，但因不假设分布形态，` +
      '结果不能用均值差描述。',
  };
}

export interface KruskalWallisResult {
  dependent: string;
  factor: string;
  groups: { group: string; n: number; median: number; mean_rank: number }[];
  /** Kruskal–Wallis H statistic. */
  h: number;
  degrees_of_freedom: number;
  p_value: number;
  /** Epsilon-squared effect size. */
  epsilon_squared: number | null;
  effect_size: EffectMagnitude | null;
  tie_corrected: boolean;
  interpretation: string;
  warnings: string[];
}

export function kruskalWallis(
  dataset: Dataset,
  dependentName: string,
  factorName: string,
): KruskalWallisResult {
  const dependent = dataset.by_name.get(dependentName);
  const factor = dataset.by_name.get(factorName);

  const empty = (reason: string): KruskalWallisResult => ({
    dependent: dependentName,
    factor: factorName,
    groups: [],
    h: 0,
    degrees_of_freedom: 0,
    p_value: Number.NaN,
    epsilon_squared: null,
    effect_size: null,
    tie_corrected: false,
    interpretation: reason,
    warnings: [reason],
  });

  if (!dependent || !factor) return empty('因变量或分组变量不存在于数据集中。');

  const selection = completeCases(dataset, [dependentName, factorName]);
  if (selection.n < 4) return empty(`有效样本 n = ${selection.n} 过小，无法进行 Kruskal–Wallis 检验。`);

  const responses = selection.columns[0]!;
  const groupCodes = selection.columns[1]!;

  const byGroup = new Map<number, number[]>();
  for (let index = 0; index < responses.length; index += 1) {
    const code = groupCodes[index]!;
    const bucket = byGroup.get(code) ?? [];
    bucket.push(responses[index]!);
    byGroup.set(code, bucket);
  }

  const orderedCodes = [...byGroup.keys()].sort((a, b) => a - b);
  if (orderedCodes.length < 2) return empty('分组变量只有一个水平，无法进行组间比较。');

  const labelFor = (code: number): string => factor.value_labels[String(Math.round(code))] ?? `组 ${code}`;

  const allRanks = ranks(responses);
  let rankIndex = 0;
  const rankByGroup = new Map<number, number[]>();
  for (let index = 0; index < responses.length; index += 1) {
    const code = groupCodes[index]!;
    const bucket = rankByGroup.get(code) ?? [];
    bucket.push(allRanks[index]!);
    rankByGroup.set(code, bucket);
    rankIndex += 1;
  }
  void rankIndex;

  const n = responses.length;
  let h = 0;
  const groups = orderedCodes.map((code) => {
    const values = byGroup.get(code)!;
    const groupRanksLocal = rankByGroup.get(code)!;
    const sumRanks = groupRanksLocal.reduce((sum, value) => sum + value, 0);
    h += (sumRanks ** 2) / values.length;
    return {
      group: labelFor(code),
      n: values.length,
      median: roundTo(median(values), 4),
      mean_rank: roundTo(sumRanks / values.length, 4),
    };
  });
  h = (12 / (n * (n + 1))) * h - 3 * (n + 1);

  const counts = new Map<number, number>();
  for (const value of responses) counts.set(value, (counts.get(value) ?? 0) + 1);
  let tieSum = 0;
  for (const count of counts.values()) if (count > 1) tieSum += count ** 3 - count;
  const tieCorrected = tieSum > 0;
  if (tieCorrected) h /= 1 - tieSum / (n ** 3 - n);

  const df = orderedCodes.length - 1;
  const pValue = chiSquareUpperTailP(Math.max(h, 0), df);

  const epsilonSquared = n > 1 ? h / ((n ** 2 - 1) / (n + 1)) : null;
  const warnings: string[] = [];
  const smallGroups = groups.filter((group) => group.n < 5);
  if (smallGroups.length > 0) {
    warnings.push(
      `以下组的样本量小于 5：${smallGroups.map((group) => `${group.group}(${group.n})`).join('、')}，` +
        '卡方近似在此情况下不准确。',
    );
  }
  if (tieCorrected) {
    warnings.push('数据存在结点（相同取值），已对 H 统计量进行结点校正。');
  }

  return {
    dependent: dependentName,
    factor: factorName,
    groups,
    h: roundTo(h, 4),
    degrees_of_freedom: df,
    p_value: roundTo(pValue, 6),
    epsilon_squared: epsilonSquared === null ? null : roundTo(epsilonSquared, 4),
    effect_size: epsilonSquared === null ? null : classifyEtaSquared(epsilonSquared),
    tie_corrected: tieCorrected,
    interpretation:
      `Kruskal–Wallis H 检验：H(${df}) = ${roundTo(h, 3)}，` +
      `p = ${pValue < 0.001 ? '< .001' : roundTo(pValue, 3)}，n = ${n}，比较 ${orderedCodes.length} 组。` +
      (epsilonSquared !== null ? ` ε² = ${roundTo(epsilonSquared, 3)}（效应量）。` : '') +
      '该检验是秩和检验的多组推广，不假设正态分布，结论应表述为"各组分布位置存在差异"而非"均值存在差异"。',
    warnings,
  };
}

/* ------------------------------------------------------------------ */
/* Categorical association                                            */
/* ------------------------------------------------------------------ */

export interface ChiSquareResult {
  row_variable: string;
  column_variable: string;
  /** Observed counts, rows are the row variable's categories. */
  observed: number[][];
  expected: number[][];
  row_labels: string[];
  column_labels: string[];
  row_totals: number[];
  column_totals: number[];
  chi_square: number;
  degrees_of_freedom: number;
  p_value: number;
  /** χ² / n, an alternative effect size for 2×2 tables. */
  phi: number | null;
  cramers_v: number | null;
  effect_size: EffectMagnitude | null;
  n: number;
  /** Cells with expected count < 5, which invalidates the χ² approximation. */
  low_expected_cells: { row: string; column: string; expected: number }[];
  /** Standardised residuals, useful for locating the association. */
  standardized_residuals: number[][];
  interpretation: string;
  warnings: string[];
}

export function chiSquareTest(
  dataset: Dataset,
  rowVariableName: string,
  columnVariableName: string,
): ChiSquareResult {
  const rowVariable = dataset.by_name.get(rowVariableName);
  const columnVariable = dataset.by_name.get(columnVariableName);

  const empty = (reason: string): ChiSquareResult => ({
    row_variable: rowVariableName,
    column_variable: columnVariableName,
    observed: [],
    expected: [],
    row_labels: [],
    column_labels: [],
    row_totals: [],
    column_totals: [],
    chi_square: 0,
    degrees_of_freedom: 0,
    p_value: Number.NaN,
    phi: null,
    cramers_v: null,
    effect_size: null,
    n: 0,
    low_expected_cells: [],
    standardized_residuals: [],
    interpretation: reason,
    warnings: [reason],
  });

  if (!rowVariable || !columnVariable) return empty('行变量或列变量不存在于数据集中。');

  const selection = completeCases(dataset, [rowVariableName, columnVariableName]);
  if (selection.n < 4) return empty(`有效样本 n = ${selection.n} 过小，无法进行卡方检验。`);

  const rowCodes = [...new Set(selection.columns[0]!.map((value) => Math.round(value)))].sort((a, b) => a - b);
  const columnCodes = [...new Set(selection.columns[1]!.map((value) => Math.round(value)))].sort((a, b) => a - b);

  if (rowCodes.length < 2 || columnCodes.length < 2) {
    return empty('行或列变量只有一个类别，无法构成列联表。');
  }

  const rowIndex = new Map(rowCodes.map((code, index) => [code, index]));
  const columnIndex = new Map(columnCodes.map((code, index) => [code, index]));

  const observed: number[][] = Array.from({ length: rowCodes.length }, () =>
    new Array<number>(columnCodes.length).fill(0),
  );
  for (let index = 0; index < selection.n; index += 1) {
    const row = rowIndex.get(Math.round(selection.columns[0]![index]!))!;
    const column = columnIndex.get(Math.round(selection.columns[1]![index]!))!;
    observed[row]![column] = observed[row]![column]! + 1;
  }

  const rowTotals = observed.map((row) => row.reduce((sum, value) => sum + value, 0));
  const columnTotals = columnCodes.map((_, columnIndexValue) =>
    observed.reduce((sum, row) => sum + row[columnIndexValue]!, 0),
  );
  const total = rowTotals.reduce((sum, value) => sum + value, 0);

  const expected: number[][] = observed.map((_, row) =>
    columnTotals.map((columnTotal) => (rowTotals[row]! * columnTotal) / total),
  );

  let chiSquare = 0;
  const standardizedResiduals: number[][] = observed.map((row, rowIndexValue) =>
    row.map((value, columnIndexValue) => {
      const expectedValue = expected[rowIndexValue]![columnIndexValue]!;
      if (expectedValue <= 0) return 0;
      chiSquare += (value - expectedValue) ** 2 / expectedValue;
      return roundTo((value - expectedValue) / Math.sqrt(expectedValue), 4);
    }),
  );

  const df = (rowCodes.length - 1) * (columnCodes.length - 1);
  const pValue = df > 0 ? chiSquareUpperTailP(chiSquare, df) : Number.NaN;

  const minimumDimension = Math.min(rowCodes.length, columnCodes.length);
  const phi = rowCodes.length === 2 && columnCodes.length === 2 ? Math.sqrt(chiSquare / total) : null;
  const cramersV = total > 0 ? Math.sqrt(chiSquare / (total * (minimumDimension - 1))) : null;

  const lowExpected = expected.flatMap((row, rowIndexValue) =>
    row
      .map((value, columnIndexValue) => ({
        row: rowVariable.value_labels[String(rowCodes[rowIndexValue]!)] ?? `行${rowIndexValue + 1}`,
        column: columnVariable.value_labels[String(columnCodes[columnIndexValue]!)] ?? `列${columnIndexValue + 1}`,
        expected: roundTo(value, 2),
      }))
      .filter((cell) => cell.expected < 5),
  );

  const warnings: string[] = [];
  const lowExpectedShare = (lowExpected.length / (rowCodes.length * columnCodes.length)) * 100;
  if (lowExpectedShare > 20) {
    warnings.push(
      `有 ${roundTo(lowExpectedShare, 1)}% 的单元格期望频数小于 5（超过 20% 的经验界限），` +
        '卡方近似可能不准确，建议合并类别或采用 Fisher 精确检验。',
    );
  } else if (lowExpected.length > 0) {
    warnings.push(
      `有 ${lowExpected.length} 个单元格期望频数小于 5，但占比未超过 20%，卡方检验结果仍可参考。`,
    );
  }
  if (total < 40) {
    warnings.push(`总样本 n = ${total} 偏小，列联表卡方检验的结论不稳定。`);
  }

  return {
    row_variable: rowVariableName,
    column_variable: columnVariableName,
    observed,
    expected: expected.map((row) => row.map((value) => roundTo(value, 4))),
    row_labels: rowCodes.map(
      (code) => rowVariable.value_labels[String(code)] ?? `类别 ${code}`,
    ),
    column_labels: columnCodes.map(
      (code) => columnVariable.value_labels[String(code)] ?? `类别 ${code}`,
    ),
    row_totals: rowTotals,
    column_totals: columnTotals,
    chi_square: roundTo(chiSquare, 4),
    degrees_of_freedom: df,
    p_value: Number.isFinite(pValue) ? roundTo(pValue, 6) : Number.NaN,
    phi: phi === null ? null : roundTo(phi, 4),
    cramers_v: cramersV === null ? null : roundTo(cramersV, 4),
    effect_size: cramersV === null ? null : classifyCramersV(cramersV, minimumDimension),
    n: total,
    low_expected_cells: lowExpected,
    standardized_residuals: standardizedResiduals,
    interpretation:
      `列联表卡方检验：${rowVariable.label} × ${columnVariable.label}，` +
      `χ²(${df}) = ${roundTo(chiSquare, 3)}，` +
      `p ${Number.isFinite(pValue) ? (pValue < 0.001 ? '< .001' : `= ${roundTo(pValue, 3)}`) : '= NA'}，n = ${total}。` +
      (cramersV !== null ? ` Cramér's V = ${roundTo(cramersV, 3)}。` : '') +
      '卡方检验只能说明两变量是否独立，不能说明关联的方向或强度来源；' +
      '标准化残量可用于定位具体是哪些单元格偏离期望。显著结果不代表因果关系。',
    warnings,
  };
}

/* ------------------------------------------------------------------ */
/* Automatic test selection                                           */
/* ------------------------------------------------------------------ */

export interface ComparisonPlan {
  parametric: {
    method: 't_test' | 'anova';
    groups: number;
    reason: string;
  };
  nonparametric: {
    method: 'mann_whitney' | 'kruskal_wallis';
    reason: string;
  };
  /** Which result the engine recommends as primary. */
  recommended: 'parametric' | 'nonparametric';
  recommendation_reason: string;
  screening: NormalityScreening[];
}

/**
 * Decide which comparison to lead with.
 *
 * Both results are always computed; this only decides which one is presented as
 * primary, and the reason is always stated. The non-parametric result is never
 * hidden, because that is what lets a reader check the conclusion.
 */
export function planComparison(
  dataset: Dataset,
  dependentName: string,
  factorName: string,
): ComparisonPlan {
  const dependent = dataset.by_name.get(dependentName);
  const factor = dataset.by_name.get(factorName);

  const selection = completeCases(dataset, [dependentName, factorName]);
  const responses = selection.columns[0] ?? [];
  const groupCodes = selection.columns[1] ?? [];

  const byGroup = new Map<number, number[]>();
  for (let index = 0; index < responses.length; index += 1) {
    const code = groupCodes[index]!;
    const bucket = byGroup.get(code) ?? [];
    bucket.push(responses[index]!);
    byGroup.set(code, bucket);
  }

  const labelFor = (code: number): string =>
    factor?.value_labels[String(Math.round(code))] ?? `组 ${code}`;

  const screening = [...byGroup.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([code, values]) => screenGroup(values, dependentName, labelFor(code)));

  const groupCount = byGroup.size;
  const allAcceptable = screening.every((entry) => entry.acceptable);

  return {
    parametric: {
      method: groupCount <= 2 ? 't_test' : 'anova',
      groups: groupCount,
      reason:
        groupCount <= 2
          ? '两组比较使用独立样本 t 检验（根据 Levene 检验自动选择 Student 或 Welch）。'
          : `多于两组（${groupCount} 组）使用单因素方差分析，并给出 Holm 校正后的两两比较。`,
    },
    nonparametric: {
      method: groupCount <= 2 ? 'mann_whitney' : 'kruskal_wallis',
      reason:
        groupCount <= 2
          ? '同时给出 Mann–Whitney U 检验作为非参数对照，不依赖正态性假设。'
          : `同时给出 Kruskal–Wallis H 检验作为非参数对照，适用于 ${groupCount} 组。`,
    },
    recommended: allAcceptable ? 'parametric' : 'nonparametric',
    recommendation_reason: allAcceptable
      ? '各组分布形态未超出可接受范围（或样本量足够大），以参数检验为主要结论，非参数结果作为稳健性对照。'
      : `部分组的分布形态超出可接受范围且样本量不足：${screening
          .filter((entry) => !entry.acceptable)
          .map((entry) => `${entry.group}(${entry.reason})`)
          .join('；')}。建议以非参数检验为主要结论。`,
    screening,
  };
}

export type { DatasetVariable };
