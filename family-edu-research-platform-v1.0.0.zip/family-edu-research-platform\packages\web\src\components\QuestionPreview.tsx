/**
 * Question renderer.
 *
 * Renders a question exactly as the respondent will see it. The builder preview
 * and the flow simulator both use this component, so what a researcher previews
 * is genuinely what a respondent gets — not a second, drifting implementation.
 */

import type { ReactNode } from 'react';
import type { Question } from '@ferp/shared';
import { questionTypeLabel } from '../lib/format';

export type AnswerValue =
  | string
  | string[]
  | number
  | Record<string, string>
  | null
  | undefined;

interface QuestionPreviewProps {
  question: Question;
  value: AnswerValue;
  onChange?: (value: AnswerValue) => void;
  /** Read-only rendering (e.g. a static preview thumbnail). */
  readOnly?: boolean;
  /** Highlight missing required answers. */
  invalid?: boolean;
  compact?: boolean;
}

export function QuestionPreview({
  question,
  value,
  onChange,
  readOnly = false,
  invalid = false,
  compact = false,
}: QuestionPreviewProps): ReactNode {
  const choices = question.options.choices ?? [];
  const interactive = !readOnly && typeof onChange === 'function';

  if (question.question_type === 'page_break') {
    return (
      <div className="rounded-md border-l-4 border-brand-500 bg-brand-50 px-4 py-3">
        <p className="text-sm font-semibold text-brand-900">{question.question_text || '（章节标题）'}</p>
        {question.help_text && <p className="mt-1 text-xs text-brand-800">{question.help_text}</p>}
      </div>
    );
  }

  return (
    <div className={compact ? '' : 'rounded-md border border-ink-200 bg-white p-4'}>
      <div className="flex items-start gap-2">
        <span className="shrink-0 font-mono text-xs text-ink-400">{question.question_code}</span>
        <div className="min-w-0 flex-1">
          <p className={`text-sm ${invalid ? 'font-medium text-red-700' : 'text-ink-900'}`}>
            {question.question_text || '（未填写题干）'}
            {question.required && <span className="ml-1 text-red-600">*</span>}
          </p>
          {question.help_text && <p className="mt-1 text-xs text-ink-500">{question.help_text}</p>}
          {invalid && <p className="mt-1 text-xs text-red-600">本题为必答题，请先作答后再继续。</p>}
        </div>
        <span className="shrink-0 rounded bg-ink-100 px-1.5 py-0.5 text-[10px] text-ink-500">
          {questionTypeLabel(question.question_type)}
        </span>
      </div>

      <div className="mt-3">
        <QuestionBody
          question={question}
          value={value}
          interactive={interactive}
          onChange={onChange}
          compact={compact}
        />
      </div>

      {choices.some((choice) => choice.sensitiveNonResponse) && (
        <p className="mt-3 rounded bg-amber-50 px-2 py-1.5 text-xs text-amber-800">
          敏感题：受访者可选择「不愿回答」，该选项在统计中单独编码为缺失，不会被并入任何实质性类别。
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Type-specific bodies                                               */
/* ------------------------------------------------------------------ */

interface BodyProps {
  question: Question;
  value: AnswerValue;
  interactive: boolean;
  onChange?: (value: AnswerValue) => void;
  compact: boolean;
}

function QuestionBody({ question, value, interactive, onChange, compact }: BodyProps): ReactNode {
  const choices = question.options.choices ?? [];

  switch (question.question_type) {
    case 'single':
    case 'knowledge_test': {
      return (
        <ul className="space-y-1.5">
          {choices.map((choice) => {
            const checked = String(value ?? '') === String(choice.value);
            return (
              <li key={choice.value}>
                <label className="flex cursor-pointer items-start gap-2 text-sm text-ink-800">
                  <input
                    type="radio"
                    name={question.id}
                    className="mt-0.5 h-4 w-4 border-ink-300 text-brand-600 focus:ring-brand-500"
                    checked={checked}
                    disabled={!interactive}
                    onChange={() => onChange?.(String(choice.value))}
                  />
                  <span className="flex-1">
                    {choice.label}
                    {choice.exclusive && <span className="ml-1 text-xs text-ink-400">（互斥选项）</span>}
                    {choice.sensitiveNonResponse && (
                      <span className="ml-1 text-xs text-amber-700">（计为缺失）</span>
                    )}
                  </span>
                </label>
              </li>
            );
          })}
          {question.question_type === 'knowledge_test' && (
            <li className="pt-1 text-xs text-ink-500">
              知识测试题：答对计分、答错计 0 分，「不清楚」计 0 分并单独统计。
            </li>
          )}
        </ul>
      );
    }

    case 'multiple': {
      const selected = Array.isArray(value) ? value.map(String) : [];
      const toggle = (code: string, exclusive: boolean): void => {
        if (!onChange) return;
        if (exclusive) {
          onChange(selected.includes(code) ? [] : [code]);
          return;
        }
        const withoutExclusive = selected.filter(
          (item) => !choices.find((choice) => String(choice.value) === item)?.exclusive,
        );
        onChange(
          withoutExclusive.includes(code)
            ? withoutExclusive.filter((item) => item !== code)
            : [...withoutExclusive, code],
        );
      };
      return (
        <ul className="space-y-1.5">
          {choices.map((choice) => (
            <li key={choice.value}>
              <label className="flex cursor-pointer items-start gap-2 text-sm text-ink-800">
                <input
                  type="checkbox"
                  className="mt-0.5 h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500"
                  checked={selected.includes(String(choice.value))}
                  disabled={!interactive}
                  onChange={() => toggle(String(choice.value), choice.exclusive === true)}
                />
                <span className="flex-1">
                  {choice.label}
                  {choice.exclusive && <span className="ml-1 text-xs text-ink-400">（互斥选项）</span>}
                </span>
              </label>
            </li>
          ))}
        </ul>
      );
    }

    case 'dropdown':
      return (
        <select
          className="ferp-input max-w-sm"
          value={String(value ?? '')}
          disabled={!interactive}
          onChange={(event) => onChange?.(event.target.value)}
        >
          <option value="">请选择…</option>
          {choices.map((choice) => (
            <option key={choice.value} value={choice.value}>
              {choice.label}
            </option>
          ))}
        </select>
      );

    case 'likert': {
      const columns = choices.length > 0 ? choices : [];
      return (
        <div className="flex flex-wrap gap-2">
          {columns.map((choice) => {
            const checked = String(value ?? '') === String(choice.value);
            return (
              <button
                key={choice.value}
                type="button"
                disabled={!interactive}
                onClick={() => onChange?.(String(choice.value))}
                className={`min-w-24 rounded-md border px-3 py-2 text-sm transition-colors ${
                  checked
                    ? 'border-brand-600 bg-brand-50 font-medium text-brand-800'
                    : 'border-ink-300 bg-white text-ink-700 hover:border-ink-400'
                } ${interactive ? '' : 'cursor-default'}`}
              >
                <span className="block text-xs text-ink-400">{choice.value}</span>
                {choice.label}
              </button>
            );
          })}
        </div>
      );
    }

    case 'matrix': {
      const rows = question.options.matrix?.rows ?? [];
      const cols = question.options.matrix?.columns ?? [];
      const current = (value && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, string>)
        : {});
      return (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[520px] border-collapse text-sm">
            <thead>
              <tr>
                <th className="border-b border-ink-200 px-2 py-2 text-left font-medium text-ink-600">
                  项目
                </th>
                {cols.map((col) => (
                  <th
                    key={col.value}
                    className="border-b border-ink-200 px-2 py-2 text-center text-xs font-medium text-ink-600"
                  >
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.value} className="even:bg-ink-50/60">
                  <td className="border-b border-ink-100 px-2 py-2 text-ink-800">{row.label}</td>
                  {cols.map((col) => (
                    <td key={col.value} className="border-b border-ink-100 px-2 py-2 text-center">
                      <input
                        type="radio"
                        name={`${question.id}-${row.value}`}
                        className="h-4 w-4 border-ink-300 text-brand-600 focus:ring-brand-500"
                        checked={current[row.value] === String(col.value)}
                        disabled={!interactive}
                        onChange={() => onChange?.({ ...current, [row.value]: String(col.value) })}
                        aria-label={`${row.label} - ${col.label}`}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-2 text-xs text-ink-500">
            行变量：
            {rows.map((row) => `${question.variable_name ?? question.question_code}${row.value}`).join('、')}
          </p>
        </div>
      );
    }

    case 'ranking': {
      const order = Array.isArray(value) ? value.map(String) : [];
      const remaining = choices.filter((choice) => !order.includes(String(choice.value)));
      return (
        <div className="space-y-2">
          {order.length > 0 && (
            <ol className="space-y-1">
              {order.map((code, index) => {
                const choice = choices.find((item) => String(item.value) === code);
                return (
                  <li
                    key={code}
                    className="flex items-center gap-2 rounded border border-ink-200 bg-ink-50 px-2 py-1.5 text-sm"
                  >
                    <span className="w-5 text-center font-mono text-xs text-ink-500">{index + 1}</span>
                    <span className="flex-1 text-ink-800">{choice?.label ?? code}</span>
                    {interactive && (
                      <button
                        type="button"
                        className="text-xs text-ink-500 hover:text-red-600"
                        onClick={() => onChange?.(order.filter((item) => item !== code))}
                      >
                        移除
                      </button>
                    )}
                  </li>
                );
              })}
            </ol>
          )}
          {remaining.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {remaining.map((choice) => (
                <button
                  key={choice.value}
                  type="button"
                  disabled={!interactive}
                  className="rounded border border-dashed border-ink-300 px-2 py-1 text-sm text-ink-600 hover:border-brand-500 hover:text-brand-700"
                  onClick={() => onChange?.([...order, String(choice.value)])}
                >
                  + {choice.label}
                </button>
              ))}
            </div>
          )}
          {!interactive && order.length === 0 && (
            <p className="text-xs text-ink-400">受访者按需要程度依次点击排序（1＝最需要）。</p>
          )}
        </div>
      );
    }

    case 'text':
      return (
        <input
          type="text"
          className="ferp-input max-w-md"
          placeholder={question.options.placeholder ?? '请输入'}
          maxLength={question.options.maxLength}
          value={typeof value === 'string' ? value : ''}
          readOnly={!interactive}
          onChange={(event) => onChange?.(event.target.value)}
        />
      );

    case 'textarea':
      return (
        <textarea
          className="ferp-input"
          rows={compact ? 3 : 4}
          placeholder={question.options.placeholder ?? '请输入'}
          maxLength={question.options.maxLength}
          value={typeof value === 'string' ? value : ''}
          readOnly={!interactive}
          onChange={(event) => onChange?.(event.target.value)}
        />
      );

    case 'number':
      return (
        <input
          type="number"
          className="ferp-input max-w-40"
          min={question.options.min}
          max={question.options.max}
          step={question.options.step}
          value={typeof value === 'number' || typeof value === 'string' ? String(value) : ''}
          readOnly={!interactive}
          onChange={(event) => onChange?.(event.target.value)}
        />
      );

    case 'date':
      return (
        <input
          type="date"
          className="ferp-input max-w-48"
          value={typeof value === 'string' ? value : ''}
          readOnly={!interactive}
          onChange={(event) => onChange?.(event.target.value)}
        />
      );

    default:
      return <p className="text-sm text-ink-400">未知题型：{String(question.question_type)}</p>;
  }
}
