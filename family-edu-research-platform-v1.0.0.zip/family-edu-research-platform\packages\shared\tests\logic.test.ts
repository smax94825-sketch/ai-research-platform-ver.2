/**
 * Conditional logic engine tests.
 *
 * The skip-logic behaviour is a research-integrity feature: if a "从未使用"
 * respondent were still asked the satisfaction question, the resulting data
 * would contain structurally impossible answers.
 */

import { test, describe } from 'node:test';
import assert from 'node:assert/strict';

import {
  describeRule,
  evaluateCondition,
  evaluateRule,
  isQuestionRequired,
  isQuestionVisible,
  nextQuestion,
  normalizeLogic,
  previousQuestion,
  resolveFlowPath,
  resolveJumpTarget,
  sortQuestions,
  validateLogic,
  visibleQuestions,
  FAMILY_EDU_V4_TEMPLATE,
  END_OF_QUESTIONNAIRE,
  type AnswerMap,
  type LogicRule,
  type Question,
  type QuestionSeed,
} from '../src/index.js';

/** Minimal Question factory for tests that need synthetic instruments. */
function q(
  code: string,
  type: Question['question_type'],
  sortOrder: number,
  logic: Question['logic'] = null,
  extra: Partial<Question> = {},
): Question {
  return {
    id: `id-${code}`,
    questionnaire_id: 'qn-test',
    question_code: code,
    question_text: `问题 ${code}`,
    question_type: type,
    options: {},
    required: true,
    dimension: null,
    variable_name: code,
    sort_order: sortOrder,
    section: null,
    help_text: null,
    logic,
    scoring_rule: null,
    created_at: '2025-01-01T00:00:00.000Z',
    updated_at: '2025-01-01T00:00:00.000Z',
    ...extra,
  };
}

const seeds: QuestionSeed[] = FAMILY_EDU_V4_TEMPLATE.questions;
const v4: Question[] = seeds.map((seed, index) => ({
  id: `seed-${seed.question_code}`,
  questionnaire_id: 'qn-v4',
  question_code: seed.question_code,
  question_text: seed.question_text,
  question_type: seed.question_type,
  options: seed.options,
  required: seed.required,
  dimension: seed.dimension,
  variable_name: seed.variable_name,
  sort_order: index + 1,
  section: seed.section,
  help_text: seed.help_text,
  logic: seed.logic,
  scoring_rule: seed.scoring_rule,
  created_at: '2025-01-01T00:00:00.000Z',
  updated_at: '2025-01-01T00:00:00.000Z',
}));

/* ------------------------------------------------------------------ */

describe('条件运算符求值', () => {
  const answers: AnswerMap = {
    Q1: '2',
    Q4: '3',
    Q17: ['1', '4', '6'],
    Q35: { '1': '4', '2': '2' },
    Q9: 4,
    Q57: '希望有专家指导',
  };

  test('eq 比较字符串与数字时不区分类型', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q1', operator: 'eq', value: '2' }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q9', operator: 'eq', value: 4 }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q9', operator: 'eq', value: '4' }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q1', operator: 'eq', value: '1' }, answers), false);
  });

  test('eq 对多选题在任一所选值命中时为真', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q17', operator: 'eq', value: '4' }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q17', operator: 'eq', value: '8' }, answers), false);
  });

  test('neq 对所有已选值均不等时为真', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q17', operator: 'neq', value: '8' }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q17', operator: 'neq', value: '1' }, answers), false);
  });

  test('in / not_in 支持候选列表', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q4', operator: 'in', value: ['3', '4'] }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q4', operator: 'in', value: ['1', '2'] }, answers), false);
    assert.equal(evaluateCondition({ questionCode: 'Q4', operator: 'not_in', value: ['1', '2'] }, answers), true);
  });

  test('数值比较运算符按数值而非字典序比较', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q9', operator: 'gte', value: 4 }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q9', operator: 'gt', value: 4 }, answers), false);
    assert.equal(evaluateCondition({ questionCode: 'Q9', operator: 'lt', value: 10 }, answers), true);
    assert.equal(evaluateCondition({ questionCode: 'Q9', operator: 'lte', value: 3 }, answers), false);
  });

  test('数值比较对非数值作答返回 false 而不是抛错', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q57', operator: 'gt', value: 3 }, answers), false);
  });

  test('contains_any / contains_all 针对多选题集合', () => {
    assert.equal(
      evaluateCondition({ questionCode: 'Q17', operator: 'contains_any', value: ['6', '7'] }, answers),
      true,
    );
    assert.equal(
      evaluateCondition({ questionCode: 'Q17', operator: 'contains_all', value: ['1', '6'] }, answers),
      true,
    );
    assert.equal(
      evaluateCondition({ questionCode: 'Q17', operator: 'contains_all', value: ['1', '9'] }, answers),
      false,
    );
  });

  test('answered / not_answered 识别空白作答', () => {
    const sparse: AnswerMap = { Q1: '1', Q2: '', Q3: [], Q4: null };
    assert.equal(evaluateCondition({ questionCode: 'Q1', operator: 'answered' }, sparse), true);
    assert.equal(evaluateCondition({ questionCode: 'Q2', operator: 'answered' }, sparse), false);
    assert.equal(evaluateCondition({ questionCode: 'Q3', operator: 'not_answered' }, sparse), true);
    assert.equal(evaluateCondition({ questionCode: 'Q4', operator: 'not_answered' }, sparse), true);
    assert.equal(evaluateCondition({ questionCode: 'Q99', operator: 'not_answered' }, sparse), true);
  });

  test('矩阵作答在 eq 下按其行值匹配', () => {
    assert.equal(evaluateCondition({ questionCode: 'Q35', operator: 'eq', value: '4' }, answers), true);
  });

  test('未知运算符直接抛错，绝不静默通过', () => {
    assert.throws(
      () =>
        evaluateCondition(
          { questionCode: 'Q1', operator: 'unknown_op' as never, value: '1' },
          answers,
        ),
      /Unsupported logic operator/,
    );
  });
});

describe('规则组合（AND / OR）', () => {
  const ruleAnd: LogicRule = {
    id: 'r-and',
    match: 'all',
    conditions: [
      { questionCode: 'Q4', operator: 'eq', value: '3' },
      { questionCode: 'Q9', operator: 'gte', value: '4' },
    ],
    action: { type: 'jump_to', target: 'END' },
  };
  const ruleOr: LogicRule = { ...ruleAnd, id: 'r-or', match: 'any' };

  test('all 需要全部条件成立', () => {
    assert.equal(evaluateRule(ruleAnd, { Q4: '3', Q9: 5 }), true);
    assert.equal(evaluateRule(ruleAnd, { Q4: '3', Q9: 2 }), false);
  });

  test('any 只需一个条件成立', () => {
    assert.equal(evaluateRule(ruleOr, { Q4: '3', Q9: 2 }), true);
    assert.equal(evaluateRule(ruleOr, { Q4: '1', Q9: 2 }), false);
  });

  test('兼容旧版单条件 when 写法', () => {
    const legacy: LogicRule = {
      id: 'r-legacy',
      when: { questionCode: 'Q1', operator: 'eq', value: '1' },
      action: { type: 'show' },
    };
    assert.equal(evaluateRule(legacy, { Q1: '1' }), true);
    assert.equal(evaluateRule(legacy, { Q1: '2' }), false);
  });

  test('无条件的规则永不触发', () => {
    assert.equal(evaluateRule({ id: 'r-empty', action: { type: 'show' } }, {}), false);
  });
});

describe('题目可见性', () => {
  test('无逻辑规则的题目默认可见', () => {
    assert.equal(isQuestionVisible(q('Q1', 'single', 1), {}), true);
  });

  test('hide 规则命中时隐藏', () => {
    const question = q('Q2', 'single', 2, {
      rules: [
        {
          id: 'r1',
          conditions: [{ questionCode: 'Q1', operator: 'eq', value: '1' }],
          action: { type: 'hide' },
        },
      ],
    });
    assert.equal(isQuestionVisible(question, { Q1: '1' }), false);
    assert.equal(isQuestionVisible(question, { Q1: '2' }), true);
  });

  test('存在 show 规则时默认隐藏，命中后才显示', () => {
    const question = q('Q3', 'single', 3, {
      rules: [
        {
          id: 'r1',
          conditions: [{ questionCode: 'Q1', operator: 'neq', value: '1' }],
          action: { type: 'show' },
        },
      ],
    });
    assert.equal(isQuestionVisible(question, { Q1: '1' }), false);
    assert.equal(isQuestionVisible(question, { Q1: '2' }), true);
    assert.equal(isQuestionVisible(question, {}), true, '未作答时 neq 成立，题目应可见');
  });

  test('hide 优先于 show', () => {
    const question = q('Q4', 'single', 4, {
      rules: [
        { id: 'r1', conditions: [{ questionCode: 'X', operator: 'eq', value: '1' }], action: { type: 'show' } },
        { id: 'r2', conditions: [{ questionCode: 'Y', operator: 'eq', value: '1' }], action: { type: 'hide' } },
      ],
    });
    assert.equal(isQuestionVisible(question, { X: '1', Y: '1' }), false);
    assert.equal(isQuestionVisible(question, { X: '1', Y: '2' }), true);
  });

  test('分页题永远可见（结构性题目）', () => {
    const page = q('P1', 'page_break', 5, {
      rules: [{ id: 'r1', conditions: [{ questionCode: 'X', operator: 'eq', value: '1' }], action: { type: 'hide' } }],
    });
    assert.equal(isQuestionVisible(page, { X: '1' }), true);
  });

  test('require 规则可动态将题目变为必答', () => {
    const question = q('Q5', 'single', 6, {
      rules: [
        {
          id: 'r1',
          conditions: [{ questionCode: 'Q1', operator: 'eq', value: '1' }],
          action: { type: 'require' },
        },
      ],
    }, { required: false });
    assert.equal(isQuestionRequired(question, {}), false);
    assert.equal(isQuestionRequired(question, { Q1: '1' }), true);
  });

  test('visibleQuestions 过滤未作答路径下不可见的题目', () => {
    const instrument = [
      q('Q10', 'single', 1),
      q('Q11', 'multiple', 2, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'Q10', operator: 'neq', value: '1' }],
            action: { type: 'show' },
          },
        ],
      }),
    ];
    assert.deepEqual(
      visibleQuestions(instrument, { Q10: '1' }).map((x) => x.question_code),
      ['Q10'],
    );
    assert.deepEqual(
      visibleQuestions(instrument, { Q10: '2' }).map((x) => x.question_code),
      ['Q10', 'Q11'],
    );
  });
});

describe('导航与跳转（真实 V4.0 问卷）', () => {
  const indexOf = (code: string): number => v4.findIndex((item) => item.question_code === code);

  test('选择"从未使用"时 Q39 直接跳转到 Q41，跳过 Q40', () => {
    const result = nextQuestion(v4, { Q39: '1' }, indexOf('Q39'));
    assert.equal(result.finished, false);
    assert.equal(result.question?.question_code, 'Q41');
  });

  test('使用过机构时 Q39 顺序进入 Q40', () => {
    for (const answer of ['2', '3', '4']) {
      const result = nextQuestion(v4, { Q39: answer }, indexOf('Q39'));
      assert.equal(result.question?.question_code, 'Q40', `Q39=${answer} 时应进入 Q40`);
    }
  });

  test('resolveJumpTarget 只在条件命中时返回目标', () => {
    const q39 = v4.find((item) => item.question_code === 'Q39')!;
    assert.equal(resolveJumpTarget(q39, { Q39: '1' }), 'Q41');
    assert.equal(resolveJumpTarget(q39, { Q39: '2' }), null);
  });

  test('Q10 选择"从未听说"时 Q11 不出现在作答路径中', () => {
    const path = resolveFlowPath(v4, { Q10: '1' });
    assert.ok(!path.includes('Q11'), '从未听说该法的受访者不应被询问了解渠道');
    assert.ok(path.includes('Q10'));
    assert.ok(path.includes('Q12'));
  });

  test('Q10 选择"了解"时 Q11 出现在作答路径中', () => {
    const path = resolveFlowPath(v4, { Q10: '3' });
    assert.ok(path.includes('Q11'));
  });

  test('默认路径按题号顺序覆盖全部 58 题（无跳转触发时）', () => {
    const path = resolveFlowPath(v4, {});
    assert.equal(path.length, 58);
    assert.equal(path[0], 'Q1');
    assert.equal(path[57], 'Q58');
  });

  test('最后一道题之后流程结束', () => {
    const result = nextQuestion(v4, {}, indexOf('Q58'));
    assert.equal(result.finished, true);
    assert.equal(result.question, null);
    assert.equal(result.index, -1);
  });

  test('向后导航可回到上一题，且跳过隐藏题', () => {
    const back = previousQuestion(v4, { Q39: '2' }, indexOf('Q40'));
    assert.equal(back.question?.question_code, 'Q39');
  });

  test('向后导航不会越过第一题', () => {
    const back = previousQuestion(v4, {}, 0);
    assert.equal(back.index, -1);
    assert.equal(back.finished, false);
  });

  test('跳转到 END 立即结束问卷', () => {
    const instrument = [
      q('A1', 'single', 1, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'A1', operator: 'eq', value: '9' }],
            action: { type: 'jump_to', target: END_OF_QUESTIONNAIRE },
          },
        ],
      }),
      q('A2', 'single', 2),
    ];
    const result = nextQuestion(instrument, { A1: '9' }, 0);
    assert.equal(result.finished, true);
  });

  test('跳转目标不存在时抛出明确错误，而不是静默走错分支', () => {
    const instrument = [
      q('B1', 'single', 1, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'B1', operator: 'eq', value: '1' }],
            action: { type: 'jump_to', target: 'B404' },
          },
        ],
      }),
    ];
    assert.throws(() => nextQuestion(instrument, { B1: '1' }, 0), /does not exist/);
  });

  test('向后跳转在作答路径中可被解析', () => {
    const instrument = [
      q('C1', 'single', 1),
      q('C2', 'single', 2, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'C2', operator: 'eq', value: '1' }],
            action: { type: 'jump_to', target: 'C1' },
          },
        ],
      }),
      q('C3', 'single', 3),
    ];
    // The cycle guard must terminate rather than hang.
    const path = resolveFlowPath(instrument, { C2: '1' });
    assert.ok(path.length <= instrument.length + 1);
  });

  test('sortQuestions 按 sort_order 排序，不依赖数组顺序', () => {
    const shuffled = [q('Z', 'single', 3), q('X', 'single', 1), q('Y', 'single', 2)];
    assert.deepEqual(sortQuestions(shuffled).map((x) => x.question_code), ['X', 'Y', 'Z']);
  });
});

describe('逻辑校验器', () => {
  test('V4.0 模板自身的逻辑图完全有效', () => {
    const issues = validateLogic(v4);
    const errors = issues.filter((i) => i.severity === 'error');
    assert.deepEqual(errors, [], `模板存在逻辑错误：${JSON.stringify(errors, null, 2)}`);
  });

  test('检出指向不存在题目的跳转目标', () => {
    const instrument = [
      q('D1', 'single', 1, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'D1', operator: 'eq', value: '1' }],
            action: { type: 'jump_to', target: 'D99' },
          },
        ],
      }),
    ];
    const issues = validateLogic(instrument);
    assert.ok(issues.some((i) => i.severity === 'error' && i.message.includes('D99')));
  });

  test('检出条件引用了不存在的题目', () => {
    const instrument = [
      q('E1', 'single', 1),
      q('E2', 'single', 2, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'E404', operator: 'eq', value: '1' }],
            action: { type: 'hide' },
          },
        ],
      }),
    ];
    const issues = validateLogic(instrument);
    assert.ok(issues.some((i) => i.message.includes('E404')));
  });

  test('检出自我跳转（死循环）', () => {
    const instrument = [
      q('F1', 'single', 1, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'F1', operator: 'eq', value: '1' }],
            action: { type: 'jump_to', target: 'F1' },
          },
        ],
      }),
    ];
    const issues = validateLogic(instrument);
    assert.ok(issues.some((i) => i.message.includes('自身')));
  });

  test('检出缺少条件的无效规则', () => {
    const instrument = [q('G1', 'single', 1, { rules: [{ id: 'r1', action: { type: 'hide' } }] })];
    const issues = validateLogic(instrument);
    assert.ok(issues.some((i) => i.message.includes('缺少条件')));
  });

  test('依赖本题自身的向后跳转判为错误（无法退出的循环作答）', () => {
    const instrument = [
      q('H1', 'single', 1),
      q('H2', 'single', 2, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'H2', operator: 'eq', value: '1' }],
            action: { type: 'jump_to', target: 'H1' },
          },
        ],
      }),
    ];
    const issues = validateLogic(instrument);
    assert.ok(
      issues.some((i) => i.severity === 'error' && i.message.includes('之前') && i.message.includes('循环')),
      '作答本题后立即被送回前面的题目，属于设计缺陷，应判为错误',
    );
  });

  test('不依赖本题的向后跳转仅给出警告', () => {
    const instrument = [
      q('H1', 'single', 1),
      q('H2', 'single', 2),
      q('H3', 'single', 3, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'H2', operator: 'eq', value: '1' }],
            action: { type: 'jump_to', target: 'H1' },
          },
        ],
      }),
    ];
    const issues = validateLogic(instrument);
    assert.ok(issues.some((i) => i.severity === 'warning' && i.message.includes('之前')));
    assert.ok(!issues.some((i) => i.severity === 'error'), '受控回跳不应被判为错误');
  });

  test('必然触发的向后跳转被流程遍历检出为循环', () => {
    // `K1 not_answered` is true on the empty baseline answers, so the backward
    // jump always fires and the flow walk must detect that it revisits K1.
    const instrument = [
      q('K1', 'single', 1),
      q('K2', 'single', 2, {
        rules: [
          {
            id: 'r1',
            conditions: [{ questionCode: 'K1', operator: 'not_answered' }],
            action: { type: 'jump_to', target: 'K1' },
          },
        ],
      }),
    ];
    const issues = validateLogic(instrument);
    assert.ok(
      issues.some((i) => i.severity === 'error' && i.message.includes('循环')),
      `应检出循环跳转，实际得到：${JSON.stringify(issues)}`,
    );
  });

  test('V4.0 模板不含任何循环跳转错误', () => {
    assert.ok(!validateLogic(v4).some((i) => i.severity === 'error' && i.message.includes('循环')));
  });
});

describe('规则可读化与规范化', () => {
  test('describeRule 生成人类可读的 IF…THEN 描述', () => {
    const rule: LogicRule = {
      id: 'r1',
      conditions: [{ questionCode: 'Q39', operator: 'eq', value: '1' }],
      action: { type: 'jump_to', target: 'Q41' },
    };
    const text = describeRule(rule, { '1': '从未使用' });
    assert.match(text, /^IF Q39 = 从未使用 THEN 跳转至 Q41$/);
  });

  test('describeRule 对多条件使用"且"、对 any 使用"或"', () => {
    const base: LogicRule = {
      id: 'r1',
      conditions: [
        { questionCode: 'A', operator: 'eq', value: '1' },
        { questionCode: 'B', operator: 'eq', value: '2' },
      ],
      action: { type: 'show' },
    };
    assert.match(describeRule(base), /且/);
    assert.match(describeRule({ ...base, match: 'any' }), /或/);
  });

  test('describeRule 对无值运算符不输出多余符号', () => {
    const rule: LogicRule = {
      id: 'r1',
      conditions: [{ questionCode: 'A', operator: 'answered' }],
      action: { type: 'require' },
    };
    assert.equal(describeRule(rule), 'IF A 已作答 THEN 本题必答');
  });

  test('normalizeLogic 对脏数据返回空规则集而不抛错', () => {
    assert.deepEqual(normalizeLogic(null), { rules: [] });
    assert.deepEqual(normalizeLogic('garbage'), { rules: [] });
    assert.deepEqual(normalizeLogic({}), { rules: [] });
    assert.deepEqual(normalizeLogic({ rules: 'nope' }), { rules: [] });
  });

  test('normalizeLogic 保留合法的规则对象', () => {
    const result = normalizeLogic({
      rules: [{ id: 'x', conditions: [], action: { type: 'hide' } }, null, 42],
    });
    assert.equal(result.rules.length, 1);
    assert.equal(result.rules[0]?.id, 'x');
  });
});
