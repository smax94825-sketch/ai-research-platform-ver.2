/**
 * Data export page tests (PHASE 8).
 *
 * An export is a file a researcher will publish, so these tests check that the
 * page cannot misrepresent one:
 *   1. every export button exists and is wired to the right endpoint, with the
 *      bearer token attached (a plain link would be answered with 401),
 *   2. the "missing values are exported as empty, never as 0" promise is on the
 *      screen in Chinese, together with the sensitive-refusal rule,
 *   3. a project with no analysis bundle still offers the raw data and the
 *      codebook, says plainly that the analysis workbook cannot be produced, and
 *      disables exactly that one button.
 */

// eslint-disable-next-line import/order -- must run before react-dom is evaluated
import './setup';

import { test, describe, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { MemoryRouter } from 'react-router-dom';

import { clearContainer, closeDom, jsonResponse, stubFetch, type FetchCall } from './dom';
import { fileResponse, stubDownloadHost } from './download';
import { click, flush, queryAll, render, text } from './render';

const { ExportPage } = await import('../src/pages/report/ExportPage');

/* ================================================================== */
/* Fixtures                                                           */
/* ================================================================== */

const PROJECTS = {
  items: [
    {
      id: 'p-1',
      researcher_id: 'r-1',
      title: '家庭教育投入研究',
      description: null,
      background: null,
      objectives: null,
      research_questions: [],
      hypotheses: [],
      target_population: null,
      target_sample_size: 1000,
      start_date: null,
      end_date: null,
      status: 'analyzing',
      quota_config: null,
      settings: null,
      created_at: '2026-01-01T00:00:00.000Z',
      updated_at: '2026-01-01T00:00:00.000Z',
    },
  ],
  total: 1,
  limit: 200,
  offset: 0,
};

const BUNDLE_READY = {
  available: true,
  engine_version: '1.0.0',
  generated_at: '2026-02-01T09:30:00.000Z',
};

const BUNDLE_MISSING = {
  available: false,
  engine_version: '1.0.0',
  reason:
    '尚未运行过完整统计分析。请先执行「运行全部分析」，之后 AI 解释、研究报告与创业洞察才能基于真实的统计结果生成。',
};

const NO_BUNDLE_XLSX_MESSAGE =
  '尚未运行完整统计分析，无法导出分析结果工作簿。请先在「分析」页面执行「运行全部分析」，再导出结果。';

/** The file name the server assigns, per endpoint (built from the project name). */
const FILENAMES: Record<string, string> = {
  'dataset.csv': '家庭教育投入研究-20260302-dataset.csv',
  'dataset.json': '家庭教育投入研究-20260302-dataset.json',
  'codebook.csv': '家庭教育投入研究-20260302-codebook.csv',
  spss: '家庭教育投入研究-20260302-spss.zip',
  'spss/syntax': '家庭教育投入研究-20260302-spss.sps',
  'spss/data': '家庭教育投入研究-20260302-spss-data.csv',
  'results.xlsx': '家庭教育投入研究-20260302.xlsx',
};

/** Every endpoint this page must be able to reach. */
const EXPECTED_PATHS = Object.keys(FILENAMES);

function suffixOf(url: string): string {
  return url.replace(/^.*\/export\//, '');
}

function stubExportApi(options: { bundle?: unknown; xlsxStatus?: number } = {}) {
  return stubFetch((call: FetchCall) => {
    const url = call.url;
    if (url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
    if (url.includes('/analysis/bundle')) {
      return jsonResponse({ data: options.bundle ?? BUNDLE_READY });
    }
    if (url.includes('/export/results.xlsx') && options.xlsxStatus === 400) {
      return jsonResponse(
        { error: { code: 'VALIDATION_ERROR', message: NO_BUNDLE_XLSX_MESSAGE } },
        400,
      );
    }
    const suffix = suffixOf(url);
    const filename = FILENAMES[suffix];
    if (filename) {
      return fileResponse(`content of ${suffix}`, filename, 'text/csv; charset=utf-8');
    }
    return jsonResponse({ data: null });
  });
}

function buttonWith(label: string): Element {
  const button = queryAll('button').find((element) => (element.textContent ?? '').includes(label));
  assert.ok(button, `未找到「${label}」按钮`);
  return button!;
}

async function renderPage(): Promise<void> {
  await render(createElement(MemoryRouter, null, createElement(ExportPage)));
  await flush();
  await flush();
}

beforeEach(() => {
  clearContainer();
  window.localStorage.clear();
});

after(() => {
  // The suite shares one process and one jsdom: leave no token behind.
  window.localStorage.clear();
  closeDom();
});

/* ================================================================== */
/* Buttons and wiring                                                 */
/* ================================================================== */

describe('数据导出页', () => {
  test('每个导出按钮都存在，并接到正确的接口路径与令牌', async () => {
    window.localStorage.setItem('ferp.token', 'test-token');
    const stub = stubExportApi();
    const host = stubDownloadHost();
    try {
      await renderPage();

      const labels = [
        '下载 dataset.csv',
        '下载 dataset.json',
        '下载 codebook.csv',
        '下载 SPSS 压缩包（.zip）',
        '仅下载 .sps 语法',
        '仅下载 SPSS 数据 CSV',
        '下载 results.xlsx',
      ];
      for (const label of labels) {
        assert.ok(buttonWith(label), `缺少导出按钮：${label}`);
      }

      for (const label of labels) {
        await click(buttonWith(label));
        await flush();
      }

      const exportCalls = stub.calls.filter((call) => call.url.includes('/export/'));
      const requested = exportCalls.map((call) => suffixOf(call.url)).sort();
      assert.deepEqual(requested, EXPECTED_PATHS.slice().sort(), '每个按钮必须接到各自的接口');

      for (const call of exportCalls) {
        assert.equal(call.method, 'GET');
        assert.equal(call.headers['authorization'], 'Bearer test-token', '下载必须携带令牌');
      }

      assert.equal(host.clicks.length, 7, '每次点击都应触发一次浏览器下载');
      const downloads = host.clicks.map((anchor) => anchor.getAttribute('download'));
      assert.deepEqual(downloads, EXPECTED_PATHS.map((path) => FILENAMES[path]));
    } finally {
      host.restore();
      stub.restore();
    }
  });

  test('下载后显示服务端返回的文件名，并说明命名由服务端决定', async () => {
    const stub = stubExportApi();
    const host = stubDownloadHost();
    try {
      await renderPage();

      assert.match(text(), /文件名由服务端按项目名称与导出日期生成/);
      assert.match(text(), /平台不在前端重复实现这套命名规则/);

      await click(buttonWith('下载 codebook.csv'));
      await flush();

      assert.match(text(), /已下载为：家庭教育投入研究-20260302-codebook\.csv/);
      assert.equal(host.clicks[0]!.getAttribute('download'), FILENAMES['codebook.csv']);
    } finally {
      host.restore();
      stub.restore();
    }
  });

  test('下载接口报错时显示服务端的中文原因，而不是给出损坏的文件', async () => {
    const stub = stubExportApi({ xlsxStatus: 400 });
    const host = stubDownloadHost();
    try {
      await renderPage();
      await click(buttonWith('下载 results.xlsx'));
      await flush();

      assert.match(text(), /尚未运行完整统计分析，无法导出分析结果工作簿/);
      assert.match(text(), /再导出结果/);
      assert.equal(host.clicks.length, 0, '失败时不得触发下载');
    } finally {
      host.restore();
      stub.restore();
    }
  });

  /* ================================================================ */
  /* The missing-value promise                                        */
  /* ================================================================ */

  test('如实说明缺失值导出为空、敏感拒答不作为数据导出', async () => {
    const stub = stubExportApi();
    try {
      await renderPage();

      const content = text();
      assert.match(content, /缺失值一律导出为空/);
      assert.match(content, /绝不写成 0/);
      assert.match(content, /空单元格就是「没有这个值」，不是「值为零」/);
      assert.match(content, /敏感拒答不作为数据导出/);
      assert.match(content, /选择「不愿回答」的题目与未作答同样按缺失处理/);
      assert.match(content, /既不做插补，\s*也不会作为一种类别出现在数据文件、编码簿或任何统计量中/);

      // The export base is stated too: excluded samples are not silently missing.
      assert.match(content, /导出的样本范围是「可分析样本」/);
      assert.match(content, /文件行数与收集总数可能不同，这不是丢数据/);

      // Each file says what it holds and what opens it.
      assert.match(content, /带 UTF-8 BOM，Excel 直接双击即可正确显示中文/);
      assert.match(content, /变量字典（变量名、题目、维度、测量层次、编码方式/);
      assert.match(content, /SPSS 的 \/TYPE=TXT 会把 BOM 当作第一个变量名的一部分/);
      assert.match(content, /描述统计、信度、效度、相关、回归、组间比较与假设检验等结果表/);
      assert.match(content, /适用工具：Excel、SPSS、R、Stata、Python（pandas）等所有统计软件。/);
    } finally {
      stub.restore();
    }
  });

  /* ================================================================ */
  /* No analysis bundle                                               */
  /* ================================================================ */

  test('没有分析结果包时：原始数据仍可导出，分析工作表明确不可导出', async () => {
    const stub = stubExportApi({ bundle: BUNDLE_MISSING });
    const host = stubDownloadHost();
    try {
      await renderPage();

      const content = text();
      assert.match(content, /尚未运行完整统计分析：分析结果工作表无法导出/);
      assert.match(content, /请先执行「运行全部分析」/, '必须原样展示接口给出的原因');
      assert.match(content, /原始数据（dataset\.csv \/ dataset\.json）、变量字典（codebook\.csv）与 SPSS 文件\s*现在就可以导出/);
      assert.match(content, /只有依赖结果包的/);
      assert.match(content, /平台不会临时重算或留空/);

      // Exactly one button is disabled — only the workbook needs the bundle.
      const xlsx = buttonWith('下载 results.xlsx');
      assert.equal(xlsx.hasAttribute('disabled'), true, '分析结果工作簿必须停用');
      assert.match(content, /需要先运行全部分析/);

      for (const label of ['下载 dataset.csv', '下载 dataset.json', '下载 codebook.csv']) {
        assert.equal(buttonWith(label).hasAttribute('disabled'), false, `${label} 仍应可用`);
      }

      // And a click on an available file really works.
      await click(buttonWith('下载 dataset.csv'));
      await flush();
      assert.equal(host.clicks.length, 1);
      assert.ok(
        stub.calls.some((call) => call.url.endsWith('/export/dataset.csv')),
        '原始数据导出应仍然可用',
      );
    } finally {
      host.restore();
      stub.restore();
    }
  });

  test('无法确认结果包状态时如实说明，按钮保持可用', async () => {
    const stub = stubFetch((call: FetchCall) => {
      if (call.url.includes('/api/projects?')) return jsonResponse({ data: PROJECTS });
      if (call.url.includes('/analysis/bundle')) {
        return jsonResponse({ error: { code: 'NETWORK_ERROR', message: '服务暂时不可用。' } }, 500);
      }
      return jsonResponse({ data: null });
    });
    try {
      await renderPage();

      const content = text();
      assert.match(content, /无法确认统计结果包状态/);
      assert.match(content, /服务暂时不可用。/);
      assert.equal(
        buttonWith('下载 results.xlsx').hasAttribute('disabled'),
        false,
        '未知状态不应假装确定：按钮保持可用，由服务端给出拒绝原因',
      );
    } finally {
      stub.restore();
    }
  });
});
