﻿/**
 * X/Y scatter plot with an optional fitted line.
 *
 * Point identification is available two ways, and neither requires a mouse:
 * every point is focusable (tab order) and carries its identity in an
 * `aria-label`/`<title>`, and focusing or hovering it draws the label next to
 * the point. Labels are therefore obtainable by keyboard and by screen reader,
 * not only by pointing at a 4-pixel circle.
 *
 * The fitted line is always supplied by the caller — this component never
 * estimates one, so a line on screen is always a line the engine computed.
 */

import { useState, type ReactNode } from 'react';
import { formatStat } from '../../lib/format';
import { ChartCaption, ChartEmpty, FONT, FONT_SMALL, ResponsiveSvg, axisTicks } from './primitives';

export interface ScatterPoint {
  x: number;
  y: number;
  label: string;
}

export interface ScatterPlotProps {
  points: ScatterPoint[];
  xLabel?: string;
  yLabel?: string;
  /** Least-squares line supplied by the caller, e.g. { intercept: 1.2, slope: 0.4 }. */
  fit?: { intercept: number; slope: number } | null;
  emptyText?: string;
  caption?: ReactNode;
}

const WIDTH = 680;
const HEIGHT = 360;
const MARGIN = { left: 56, right: 14, top: 14, bottom: 46 };

export function ScatterPlot({
  points,
  xLabel,
  yLabel,
  fit,
  emptyText = '暂无可展示的散点数据。',
  caption,
}: ScatterPlotProps): ReactNode {
  const [active, setActive] = useState<number | null>(null);

  if (points.length === 0) return <ChartEmpty text={emptyText} />;

  const plotWidth = WIDTH - MARGIN.left - MARGIN.right;
  const plotHeight = HEIGHT - MARGIN.top - MARGIN.bottom;

  const xs = points.map((point) => point.x);
  const ys = points.map((point) => point.y);
  const xMin = Math.min(...xs);
  const xMax = Math.max(...xs);
  const yMin = Math.min(...ys);
  const yMax = Math.max(...ys);
  const pad = (min: number, max: number) => (max === min ? Math.max(Math.abs(max) * 0.1, 1) : (max - min) * 0.06);

  const domainX: [number, number] = [xMin - pad(xMin, xMax), xMax + pad(xMin, xMax)];
  const domainY: [number, number] = [yMin - pad(yMin, yMax), yMax + pad(yMin, yMax)];

  const scaleX = (value: number) =>
    MARGIN.left + ((value - domainX[0]) / (domainX[1] - domainX[0])) * plotWidth;
  const scaleY = (value: number) =>
    MARGIN.top + plotHeight - ((value - domainY[0]) / (domainY[1] - domainY[0])) * plotHeight;

  const plotRight = MARGIN.left + plotWidth;
  const plotBottom = MARGIN.top + plotHeight;

  return (
    <div>
      <ResponsiveSvg width={WIDTH} height={HEIGHT} label="散点图">
        <rect
          x={MARGIN.left}
          y={MARGIN.top}
          width={plotWidth}
          height={plotHeight}
          fill="#fbfcfd"
          stroke="#d5dae3"
          strokeWidth={1}
        />

        {axisTicks(domainX[0], domainX[1], 5).map((tick) => (
          <g key={`x-${tick}`}>
            <line x1={scaleX(tick)} y1={plotBottom} x2={scaleX(tick)} y2={plotBottom + 4} stroke="#b1bac9" />
            <text x={scaleX(tick)} y={plotBottom + 17} fontSize={FONT_SMALL} fill="#68778e" textAnchor="middle">
              {formatStat(tick, tick % 1 === 0 ? 0 : 2)}
            </text>
          </g>
        ))}
        {axisTicks(domainY[0], domainY[1], 4).map((tick) => (
          <g key={`y-${tick}`}>
            <line x1={MARGIN.left - 4} y1={scaleY(tick)} x2={MARGIN.left} y2={scaleY(tick)} stroke="#b1bac9" />
            <text x={MARGIN.left - 8} y={scaleY(tick) + 4} fontSize={FONT_SMALL} fill="#68778e" textAnchor="end">
              {formatStat(tick, tick % 1 === 0 ? 0 : 2)}
            </text>
          </g>
        ))}

        {fit && (
          <line
            x1={scaleX(domainX[0])}
            y1={scaleY(fit.intercept + fit.slope * domainX[0])}
            x2={scaleX(domainX[1])}
            y2={scaleY(fit.intercept + fit.slope * domainX[1])}
            stroke="#c8222c"
            strokeWidth={1.5}
          />
        )}

        {points.map((point, index) => (
          <g key={`${point.label}-${index}`}>
            <circle
              cx={scaleX(point.x)}
              cy={scaleY(point.y)}
              r={active === index ? 5 : 3.5}
              fill={active === index ? '#1f47f5' : '#598eff'}
              fillOpacity={active === index ? 1 : 0.75}
              stroke="#ffffff"
              strokeWidth={0.5}
              tabIndex={0}
              role="img"
              aria-label={`${point.label}：x = ${formatStat(point.x, 2)}，y = ${formatStat(point.y, 2)}`}
              onMouseEnter={() => setActive(index)}
              onMouseLeave={() => setActive(null)}
              onFocus={() => setActive(index)}
              onBlur={() => setActive(null)}
            >
              <title>{`${point.label}（x = ${formatStat(point.x, 2)}, y = ${formatStat(point.y, 2)}）`}</title>
            </circle>
            {active === index && (
              <text
                x={scaleX(point.x) + (scaleX(point.x) > plotRight - 120 ? -8 : 8)}
                y={scaleY(point.y) - 8}
                fontSize={FONT}
                fill="#22262e"
                textAnchor={scaleX(point.x) > plotRight - 120 ? 'end' : 'start'}
              >
                {`${point.label}（${formatStat(point.x, 2)}, ${formatStat(point.y, 2)}）`}
              </text>
            )}
          </g>
        ))}

        {xLabel && (
          <text x={MARGIN.left + plotWidth / 2} y={HEIGHT - 8} fontSize={FONT} fill="#444d5e" textAnchor="middle">
            {xLabel}
          </text>
        )}
        {yLabel && (
          <text
            x={14}
            y={MARGIN.top + plotHeight / 2}
            fontSize={FONT}
            fill="#444d5e"
            textAnchor="middle"
            transform={`rotate(-90 14 ${MARGIN.top + plotHeight / 2})`}
          >
            {yLabel}
          </text>
        )}
      </ResponsiveSvg>

      <ChartCaption>
        {caption ?? `共 ${points.length} 个数据点。`}
        {' 使用 Tab 键或鼠标悬停可查看每个点的名称与坐标。'}
        {fit && ` 拟合直线：y = ${formatStat(fit.intercept, 3)} + ${formatStat(fit.slope, 3)} x（由引擎计算）。`}
      </ChartCaption>
    </div>
  );
}
