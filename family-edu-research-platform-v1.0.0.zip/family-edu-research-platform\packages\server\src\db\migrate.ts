/**
 * Migration runner.
 *
 * Migrations are embedded as TypeScript modules rather than loose .sql files so
 * the compiled output is self-contained (no asset-copy build step) and the
 * exact DDL applied is guaranteed to match the code that ran it.
 *
 * Each migration runs inside a transaction and is recorded in
 * `schema_migrations`, so re-running is a no-op and a partial failure rolls
 * back completely.
 */

import type { Db } from './index.js';
import { MIGRATIONS } from './migrations.js';

export interface MigrationRecord {
  id: string;
  name: string;
  applied_at: string;
}

const ENSURE_TABLE = `
CREATE TABLE IF NOT EXISTS schema_migrations (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  applied_at  TEXT NOT NULL
);
`;

export function ensureMigrationsTable(db: Db): void {
  db.exec(ENSURE_TABLE);
}

export function appliedMigrations(db: Db): MigrationRecord[] {
  ensureMigrationsTable(db);
  return db.all<MigrationRecord>('SELECT id, name, applied_at FROM schema_migrations ORDER BY id');
}

export interface MigrateResult {
  applied: string[];
  skipped: string[];
}

/**
 * Apply every pending migration in id order.
 * Safe to call on every boot; already-applied migrations are skipped.
 */
export function migrate(db: Db): MigrateResult {
  ensureMigrationsTable(db);
  const done = new Set(appliedMigrations(db).map((row) => row.id));
  const applied: string[] = [];
  const skipped: string[] = [];

  const pending = [...MIGRATIONS].sort((a, b) => a.id.localeCompare(b.id));

  for (const migration of pending) {
    if (done.has(migration.id)) {
      skipped.push(migration.id);
      continue;
    }
    db.transaction(() => {
      db.exec(migration.sql);
      db.run('INSERT INTO schema_migrations (id, name, applied_at) VALUES (?, ?, ?)', [
        migration.id,
        migration.name,
        new Date().toISOString(),
      ]);
    });
    applied.push(migration.id);
  }

  return { applied, skipped };
}

/** Drop every platform table — used by `db:reset` and by the test harness. */
export function dropAllTables(db: Db): void {
  const tables = db.all<{ name: string }>(
    "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'",
  );
  db.exec('PRAGMA foreign_keys = OFF');
  for (const { name } of tables) {
    db.exec(`DROP TABLE IF EXISTS "${name}"`);
  }
  db.exec('PRAGMA foreign_keys = ON');
}

/** Verify the core tables exist; used as a database health check. */
export function listTables(db: Db): string[] {
  return db
    .all<{ name: string }>(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name",
    )
    .map((row) => row.name);
}
